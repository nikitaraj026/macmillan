package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_PublishToInstructorCatalog extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, PublihDestinationInstructorStore, InstructorCatalogUrl;
	String CMSProjectISBN, SupplementaryInstructorResourcesID, SupplementaryCourseManagementID,
			MarketingContentSampleChapterID;
	String NewSupplementaryInstructorResourcesName, NewSupplementaryCourseManagementName,
			NewMarketingContentSampleChapterName;
	String ContentTypeSupplementaryInstructorResources, ContentTypeSupplementaryCourseManagement,
			ContentTypeMarketingSampleChapter;
	String PageSelectionAllPages, InstructorCatalogISBN, InstructorCatalogBookTitle, CMSRepository, DAMRepository;
	String SupplementaryInstructorResourcesNameWithSpecialChar;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		CMSProjectISBN = getData("ProjectISBNNo4");
		InstructorCatalogISBN = getData("InstructorCatalogBookNameAndISBN.Book1.ISBN");
		InstructorCatalogBookTitle = getData("InstructorCatalogBookNameAndISBN.Book1.Title");
		SupplementaryInstructorResourcesID = getData("InstructorCatalogAssetsID.SupplementaryInstructorResources");
		SupplementaryCourseManagementID = getData("InstructorCatalogAssetsID.SupplementaryCourseManagement");
		MarketingContentSampleChapterID = getData("InstructorCatalogAssetsID.MarketingContentSampleChapter");
		NewSupplementaryInstructorResourcesName = getStringWithDateAndTimes("AutomationInstructor");
		SupplementaryInstructorResourcesNameWithSpecialChar = (getStringWithDateAndTimes("AutomationInstructor"))+"#%+-_?";
		NewSupplementaryCourseManagementName = getStringWithDateAndTimes("AutomationCourseManagement");
		NewMarketingContentSampleChapterName = getStringWithDateAndTimes("AutomationSampleChapter");
		ContentTypeSupplementaryInstructorResources = getData(
				"TypesOfContent.Supplementary Content>Instructor Resources");
		ContentTypeSupplementaryCourseManagement = getData("TypesOfContent.Supplementary Content>Course Management");
		ContentTypeMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		PageSelectionAllPages = getData("PageSelection.All Pages");
		InstructorCatalogUrl = getData("Link.InstructorCatalog");
		CMSRepository = getData("Repository.CMS");
		DAMRepository = getData("Repository.DAM");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step1:ADD the Resources to the CMS Project.
	@Test(priority = 2)
	public void Step1_ADD_The_Supplementary_And_Marketing_Content_To_Project() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(SupplementaryInstructorResourcesID);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(CMSProjectISBN);

		test.Contentpage.SearchForAnItem(SupplementaryCourseManagementID);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(CMSProjectISBN);

		test.Contentpage.SearchForAnItem(MarketingContentSampleChapterID);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(CMSProjectISBN);

	}

	// step2:: Rename the Resource for the identification of new Publish
	@Test(priority = 3, dependsOnMethods = "Step1_ADD_The_Supplementary_And_Marketing_Content_To_Project")
	public void Step2_Rename_The_Assets() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(MarketingContentSampleChapterID);
		test.Contentpage.ClickOpenAssertOnContentTab();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(NewMarketingContentSampleChapterName);
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited(NewMarketingContentSampleChapterName);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(SupplementaryInstructorResourcesID);
		test.Contentpage.ClickOpenAssertOnContentTab();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(NewSupplementaryInstructorResourcesName);
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited(NewSupplementaryInstructorResourcesName);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(SupplementaryCourseManagementID);
		test.Contentpage.ClickOpenAssertOnContentTab();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(NewSupplementaryCourseManagementName);
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited(NewSupplementaryCourseManagementName);
	}

	// Step3:: Publish the Content to Instructor Catalog Application.
	@Test(priority = 4, dependsOnMethods = "Step2_Rename_The_Assets")
	public void Publish_The_Content_To_Instructor_Store() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(CMSProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.DeleteISBN_From_IS_PublishWindow(CMSProjectISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(CMSProjectISBN);
		test.projectView.SearchForISBNIn_IS_Publish_Window(InstructorCatalogISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(InstructorCatalogISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(InstructorCatalogISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeMarketingSampleChapter,
				NewMarketingContentSampleChapterName,true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,
				ContentTypeSupplementaryCourseManagement, NewSupplementaryCourseManagementName,true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,
				ContentTypeSupplementaryInstructorResources, NewSupplementaryInstructorResourcesName,true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// Step4:: Wait for Publish Operation To Complete
	@Test(priority = 5, dependsOnMethods = "Publish_The_Content_To_Instructor_Store")
	public void Step5_Wait_For_Publish_Operation_To_Complete() {
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Complete", "1");
	}

	// Step5::Launch the Instructor Catalog Application
	@Test(priority = 6, dependsOnMethods = "Step5_Wait_For_Publish_Operation_To_Complete")
	public void Launch_Instructor_Catalog_Application() {
		test.projectView.OpenNewTabOntheCurrentWindow();
		test.projectView.changeWindow(1);
		test.launchApplication(InstructorCatalogUrl);
	}

	// Step6:: Search for the Product on Instructor Catalog Application
	@Test(priority = 7, dependsOnMethods = "Launch_Instructor_Catalog_Application")
	public void Navigate_To_Product_Details_Page() {
		test.InstructorCatalog.SearchforAnProduct(InstructorCatalogISBN);
		test.InstructorCatalog.verifyUserIsOnSearchPage();
		test.InstructorCatalog.ClickBookTitle(InstructorCatalogBookTitle);
		test.InstructorCatalog.VerifyOnProjectDetailPage();
	}

	// Step6::Verify that 'Supplementary Content> Instructor Resources' and
	// 'Supplementary Content> Course Management', Sample Chapters assets are
	// displaying under the published ISBN in Instructor Catalog STG tier.
	// BS-2404
	@Test(priority = 7, dependsOnMethods = "Navigate_To_Product_Details_Page")
	public void Verify_Publish_Asset_Are_Displayed_On_Instructor_Catalog() {
		test.InstructorCatalog.ClickResourcesTab();
		test.InstructorCatalog.VerifyUserIsOnResourceTab();
		test.InstructorCatalog.ExpandResourceType("NA");
		test.InstructorCatalog.VerifyResourceIsDisplayed(NewSupplementaryInstructorResourcesName);
		test.InstructorCatalog.ExpandResourceType("Coursepacks");
		test.InstructorCatalog.ExpandSubResourceType("NA");
		test.InstructorCatalog.VerifyResourceIsDisplayed(NewSupplementaryCourseManagementName);
		test.InstructorCatalog.ClickLookInside();
		test.InstructorCatalog.VerifyResourceOnLookInsideWindow(NewMarketingContentSampleChapterName);
		test.InstructorCatalog.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// Step7:: Add/Rename The Content
	@Test(priority = 8)
	public void Add_And_Rename_The_Content_To_Project() {
		test.HomePage.changeWindow(0);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(SupplementaryInstructorResourcesID);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(CMSProjectISBN);
		test.Contentpage.ClickOpenAssertOnContentTab();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(SupplementaryInstructorResourcesNameWithSpecialChar);
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited(SupplementaryInstructorResourcesNameWithSpecialChar);

	}

	// Step8:: Publish the Content with Special Character to Instructor Catalog
	// Application.
	@Test(priority = 9, dependsOnMethods = "Add_And_Rename_The_Content_To_Project")
	public void Publish_The_Content_To_Instructor_Store_With_Special_Character() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(CMSProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.DeleteISBN_From_IS_PublishWindow(CMSProjectISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(CMSProjectISBN);
		test.projectView.SearchForISBNIn_IS_Publish_Window(InstructorCatalogISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(InstructorCatalogISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(InstructorCatalogISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,
				ContentTypeSupplementaryInstructorResources, SupplementaryInstructorResourcesNameWithSpecialChar,true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// Step9:: Wait for Publish Operation To Complete
	@Test(priority = 10, dependsOnMethods = "Publish_The_Content_To_Instructor_Store_With_Special_Character")
	public void Step9_Wait_For_Publish_Operation_To_Complete() {
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Complete", "1");
	}

	// Step10::Launch the Instructor Catalog Application
	@Test(priority = 11, dependsOnMethods = "Step9_Wait_For_Publish_Operation_To_Complete")
	public void Launch_Instructor_Catalog_Applications() {
		test.projectView.OpenNewTabOntheCurrentWindow();
		test.projectView.changeWindow(1);
		test.launchApplication(InstructorCatalogUrl);
	}

	// Step11:: Search for the Product on Instructor Catalog Application
	@Test(priority = 12, dependsOnMethods = "Launch_Instructor_Catalog_Applications")
	public void Navigate_To_Product_Details_Pages() {
		test.InstructorCatalog.SearchforAnProduct(InstructorCatalogISBN);
		test.InstructorCatalog.verifyUserIsOnSearchPage();
		test.InstructorCatalog.ClickBookTitle(InstructorCatalogBookTitle);
		test.InstructorCatalog.VerifyOnProjectDetailPage();
	}

	// Step6::Verify that 'Supplementary Content> Instructor Resources' and
	// 'Supplementary Content> Course Management', Sample Chapters assets are
	// displaying under the published ISBN in Instructor Catalog STG tier.
	// BS-2404
	@Test(priority = 13, dependsOnMethods = "Navigate_To_Product_Details_Pages")
	public void Verify_Publish_Asset_With_Special_Character_Displayed_On_Instructor_Catalog() {
		test.InstructorCatalog.ClickResourcesTab();
		test.InstructorCatalog.VerifyUserIsOnResourceTab();
		test.InstructorCatalog.ExpandResourceType("NA");
		test.InstructorCatalog.VerifyResourceIsDisplayed(SupplementaryInstructorResourcesNameWithSpecialChar);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
