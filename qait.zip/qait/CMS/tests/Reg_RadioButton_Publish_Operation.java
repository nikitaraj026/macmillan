package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_RadioButton_Publish_Operation extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String ISBN, TypesOfContentEnhancedEpub, PublihDestinationCoreSource, PublihDestinationVitalSource;
	String TypeOfContentCFI,TypesOfContentFlatEpub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypeOfContentCFI = getData("TypesOfContent.Project Support Materials>CFI");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// 1.login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step:: Add the Epub and CFI File to Project
	@Test(priority = 2)
	public void Add_The_Epub_And_CFI_file() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.SelectContentOnContentTab(ISBN + ".epub",TypesOfContentEnhancedEpub );
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.Contentpage.SearchForAnItem(ISBN + "_CFI.csv");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_CFI.csv",TypeOfContentCFI);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN);
	}

	// 1.Project view> Verify that if user Publishes both EPUB and CFI file to
	// CoreSource by selecting second radio button in step 1 of Publish window, then
	// after successful Publish initiation, both the files are displaying under
	// Publish Details tab
	// BS-1999
	@Test(priority = 3) //##### Functionality Removed #####: Note this should be tested for Flat Epub with CFI From Frost
	public void Publish_EPUB_CFI_To_CourseSource() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links and ePub");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentFlatEpub, ISBN + "_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(2);
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_EPUB.epub");
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_CFI.csv");
		test.projectView.ClickCloseButton();
	}

	// 2.Project view> Verify that if user Publishes both EPUB and CFI file to
	// VitalSource by selecting second radio button in step 1 of Publish window,
	// then after successful Publish initiation, both the files are displaying under
	// Publish Details tab
	// BS-1999
	@Test(priority = 4)
	public void Publish_EPUB_CFI_To_VitalSource() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links and ePub");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub, ISBN + ".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(2);
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + ".epub");
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_CFI.csv");
		test.projectView.ClickCloseButton();
	}

	// 3.Project view> Verify that if user Publishes only EPUB file to CoreSource/
	// VitalSource by selecting First radio button in step 1 of Publish window, then
	// after successful Publish initiation, only the EPUB file is displaying under
	// Publish Details tab
	// BS-1999
	@Test(priority = 5)
	public void Publish_Epub_To_CoreSource_VitalSource_With_First_Radio_Button() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish ePub only");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub, ISBN + ".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(1);
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + ".epub");
		test.projectView.ClickCloseButton();

		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish ePub only");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentFlatEpub, ISBN + "_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(1);
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_EPUB.epub");
		test.projectView.ClickCloseButton();
	}

	// 4.Project view> Verify that if user Publishes only CFI file to CoreSource/
	// VitalSource by selecting Third radio button in step 1 of Publish window, then
	// after successful Publish initiation, only the CFI file is displaying under
	// Publish Details tab
	// BS-1999
	@Test(priority = 6)
	public void Publish_CFI_To_CoreSource_VitalSource_With_Third_Radio_Button() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypeOfContentCFI, ISBN + "_CFI.csv",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN + "_CFI.csv");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(1);
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_CFI.csv");
		test.projectView.ClickCloseButton();

		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(1);
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_CFI.csv");
		test.projectView.ClickCloseButton();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
