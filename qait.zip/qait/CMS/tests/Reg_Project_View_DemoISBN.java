package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_View_DemoISBN extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, ISBN2, NonStandardMsg;
	String ExistingDummyISBN, FrostEmail, FrostPassword, ProjectTitle, LookForProject, AddFieldProjectISBN;
	String DemoISBN, FrostHistoryUpdate,TypesOfContentFlatEpub,ContentTypeCoverDesign;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		NonStandardMsg = getData("NonStandardMsg");
		ISBN2 = getData("ProjectISBNNo1");
		ExistingDummyISBN = "TestISBN-201904081451";
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		ProjectTitle = getData("ProjectTitle1");
		LookForProject = getData("LookFor.project");
		AddFieldProjectISBN = getData("SearchTypeAdvanceSearch.Project ISBN");
		DemoISBN = getStringWithDateAndTimes("TestISBN");
		FrostHistoryUpdate = getData("CVHistoryFrost");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		ContentTypeCoverDesign = getData("TypesOfContent.Covers>Cover Design");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1."Project View> Step 3:
	// 1) Verify that User is able to enter Alpha Numeric values in the Search
	// box."
	// BS-2704
	@Test(priority = 2)
	public void Verify_User_Is_Able_To_Enter_Alpha_Numeric_In_SearchBox() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool("Automation1234Z");
		test.projectView.VerifyNonStandardProjectMessage("Automation1234Z", NonStandardMsg);
	}

	// 2.2) Verify that when user clicks on the Search button, then search
	// action is only run for the ISBN field and not on rest fields like Author,
	// Title, Short Title and Search results are displayed according to that.
	// BS-2704
	@Test(priority = 3)
	public void Verify_Search_Action_Is_Only_Run_For_The_ISBN() {
		test.projectView.VerifyProjectColoumHidden();
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ISBN);
		test.projectView.VerifyColoumOfProject();
	}

	// 3.3) Verify that if user enters the exact 13 digit ISBN which is
	// available in the CMS, then on clicking the Search button, the exact
	// single result is displayed.
	// BS-2704
	@Test(priority = 4)
	public void Verify_If_User_Enters_Exact_13_Digit_ISBN_Single_Project_Displayed() {
		test.projectView.VerifySingleProjectDisplayedOnAuhoringTool();
	}

	// 4.4) Verify that no results are returned if user clicks on the Search
	// icon after entering ISBN value that does not exist in CMS.
	// BS-2704
	@Test(priority = 5)
	public void Verify_No_Results_Are_Returned_On_Incorrect_ISBN() {
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool("1212121212129");
		test.projectView.VerifyNonStandardProjectMessage("1212121212129", NonStandardMsg);
	}

	// 5.Verify that if entered ISBN or dummy ISBN already available in CMS is
	// found, then user is able to select the same and can click the Push
	// button.
	// BS-2687
	@Test(priority = 6)
	public void Verify_If_ISBN_Or_DummyISBN_Exist_User_Is_Able_To_Select_Them() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ISBN2);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(ISBN2);
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ExistingDummyISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(ExistingDummyISBN);
		test.projectView.ClickPushOnPushToAuthoringTool();
	}

	// 6.Verify that that Project gets created at Frost end for ISBN13 value/
	// Dummy ISBN.
	// BS-2687
	@Test(priority = 7)
	public void Verify_Projects_Gets_Created_At_Frost() {
		test.projectView.verifyOnProjectView();
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ISBN2, ProjectTitle);
		test.projectView.DeleteProjectFromFrost(ProjectTitle);

		test.projectView.VerifyProjectIsCreatedAtFrost(ExistingDummyISBN, ExistingDummyISBN);
		test.projectView.DeleteProjectFromFrost(ExistingDummyISBN);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 7."Verify that following message is displayed if entered demo ISBN is not
	// found:
	// ABC is a non-standard project name.
	// Do you wish to continue and push this asset using this project name? with
	// Yes or No radio buttons."
	// Verify that No is selected by Default.
	// BS-2687
	@Test(priority = 8)
	public void Verify_NonStandard_Project_Message_With_Radio_Burtton() {
		test.projectView.changeWindow(0);
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool("Automation1234Z");
		test.projectView.VerifyNonStandardProjectMessage("Automation1234Z", NonStandardMsg);
		test.projectView.VerifyYesOrNoButtonForDemoISBN("Yes");
		test.projectView.VerifyYesOrNoButtonForDemoISBN("No");
		test.projectView.VerifyYesOrNoButtonSelected("No");
	}

	// 8.Verify that Push button will be enabled for users to click and proceed
	// if user selects 'Yes'
	// Verify that Push button remains disabled if No is selected.
	// BS-2687
	@Test(priority = 9)
	public void Verify_PushButton_Enables_If_User_Selects_Yes() {
		test.projectView.VerifyPushButtonDisabledAuthoringTool();
		test.projectView.ClickYESNoForDemoISBN("Yes");
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
	}

	// 9.Verify that user is not able to Search these demo ISBNs using Generic
	// and Advanced Search.
	// BS-2687
	@Test(priority = 10)
	public void Verify_User_Not_Able_To_Search_Demo_ISBNs_In_Generic_And_Advanced_Search() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(ExistingDummyISBN);
		test.ProjectPage.VerifyprojectNotDisplayed(ISBN);

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.EnterTextIntoSearchBox(ExistingDummyISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyProjectNotDispalyedOnSearchPage(ISBN);
	}

	// 10.Verify that warning message will not display for Demo ISBNs that are
	// already created in CMS
	// BS-2687
	@Test(priority = 11)
	public void Verify_Warning_Message_Will_Not_Display_For_existing_Demo_ISBN() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ExistingDummyISBN);
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
	}

	// 11.Project view: Verify that ISBN which was used in Step 3 while pushing the
	// epub to Frost is displaying in Workflow History table under Workflow Status
	// History/ Publish History column
	// BS-2698
	@Test(priority = 12)
	public void Verify_ISBN_Used_For_Pushing_Epub_Display_In_WorkFlow_History() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN2 + "_EPUB.epub");
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_EPUB.epub",TypesOfContentFlatEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN2 + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN2 + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ISBN2);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(ISBN2);
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(ISBN2);
	}

	// 12.Verify that similar entry is recorded in Content view> Content History
	// table under Action Type column
	// BS-2698
	@Test(priority = 13)
	public void Verify_Push_Entry_Recorded_In_ContentView() {
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostHistoryUpdate + "" + ISBN2);
	}

	// 13.Verify that when ePub is pushed to Frost via Content view, then ISBN which
	// was used in Step 3 is displaying in Content History table under Action Type
	// column
	// BS-2698
	@Test(priority = 14)
	public void Verify_Epub_Push_Via_ContentView_HistoryTable_is_Updated() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.UploadContentToFrost(ISBN);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostHistoryUpdate + "" + ISBN);
	}

	// 14.Verify that this entry is not reflecting in the Workflow History of the
	// Project view of the ISBN that was used in step 3 while pushing the ePub via
	// Content view.
	// BS-2698
	@Test(priority = 15)
	public void Verify_If_Epub_Push_Via_ContentView_ProjectView_History_Table_Is_Not_Updated() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyFrostPushActionInWorkFlowHistoryIsNotUpdated(ISBN);
	}

	// 15.Verify that when 'Other Asset' is pushed via Project view, then only the
	// single entry is recorded in the History table, however, the same entry
	// reflects into the Content's Content History table.
	// BS-2698
	@Test(priority = 16)
	public void Verify_ContentHistory_Table_Updated_for_pushing_OtherAssets() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Other", ISBN2 + "_FC.jpg");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN2 + "_FC.jpg");
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(ISBN2);

		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_FC.jpg",ContentTypeCoverDesign);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostHistoryUpdate + "" + ISBN2);
	}

	// 16.Project view: Verify that DEMO ISBN which was used in Step 3 while pushing
	// the epub to Frost is displaying in Workflow History table under Workflow
	// Status History/ Publish History column
	// BS-2698
	@Test(priority = 17)
	public void Verify_DemoISBN_Used_For_Pushing_Epub_Display_In_WorkFlow_History() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN2 + "_EPUB.epub");
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_EPUB.epub",TypesOfContentFlatEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN2 + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN2 + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.VerifyNonStandardProjectMessage(DemoISBN, NonStandardMsg);
		test.projectView.ClickYESNoForDemoISBN("Yes");
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(DemoISBN);
	}

	// 17.Verify that similar entry is recorded in Content view> Content History
	// table under Action Type column for DemoISBN
	// BS-2698
	@Test(priority = 18)
	public void Verify_Push_Entry_Recorded_In_ContentView_For_DemoISBN() {
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostHistoryUpdate + "" + DemoISBN);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}