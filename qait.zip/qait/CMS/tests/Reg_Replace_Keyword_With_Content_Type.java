package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Replace_Keyword_With_Content_Type extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String FacetContentType, FacetRepository, FacetSubjects;
	String FacetTitle, FacetContentState, MarketingAuthorImage;
	String SeeMoreLink, FacetLinkImageLinked, TypeOfContentMarketingAuthorImage;
	String LookForAsset, AdvanceSearchTypeContentType;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		FacetContentType = getData("FacetType.Content Type");
		FacetRepository = getData("FacetType.Repository");
		FacetSubjects = getData("FacetType.Subjects");
		FacetTitle = getData("FacetType.Title");
		FacetContentState = getData("FacetType.Content State");
		MarketingAuthorImage = getData("MarketingAuthorImage");
		SeeMoreLink = getData("SeeMoreLink");
		FacetLinkImageLinked = getData("TypesOfContent.Images>Image Linked");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		LookForAsset = getData("LookFor.Assets");
		AdvanceSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// "A)For Contents Tab/ Generic Search> 'Content':
	// 1) Verify that 'Contents Type' filter appears in the left navigation pane:"
	// BS-3091
	@Test(priority = 2)
	public void Verify_Contents_Type_Filter_On_Contents_Tab_Generic_Search() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.VerifyFacetTitle(FacetContentType);
		test.Contentpage.SearchForAnItem("test");
		test.Contentpage.VerifyFacetTitle(FacetContentType);
	}

	// 2) Verify that by default 5 filter facet links appear in 'Content Type'
	// filter in the left navigation pane (Highest from the top)
	// BS-3091
	@Test(priority = 3)
	public void Verify_Default_5_Filter_Facet_Links() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.VerifyFacetTitle(FacetRepository);
		test.Contentpage.VerifyFacetTitle(FacetContentType);
		test.Contentpage.VerifyFacetTitle(FacetSubjects);
		test.Contentpage.VerifyFacetTitle(FacetTitle);
		test.Contentpage.VerifyFacetTitle(FacetContentState);

		test.Contentpage.SearchForAnItem("test");
		test.Contentpage.VerifyFacetTitle(FacetRepository);
		test.Contentpage.VerifyFacetTitle(FacetContentType);
		test.Contentpage.VerifyFacetTitle(FacetSubjects);
		test.Contentpage.VerifyFacetTitle(FacetTitle);
		test.Contentpage.VerifyFacetTitle(FacetContentState);

	}

	// 3) Verify that top 5 facet links appear in 'Content Type' filter is sorted by
	// results count in the descending order
	// BS-3091
	@Test(priority = 4)
	public void Verify_Default_5_Filter_Facet_Links_Are_In_Descending_Order() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.verifyFacetLinkArrangedInDescendingOrder(FacetContentType);
		test.Contentpage.SearchForAnItem("test");
		test.Contentpage.verifyFacetLinkArrangedInDescendingOrder(FacetContentType);

	}

	// 4) Verify that 'See More' link appears if there are more than 5 facet links
	// under the 'Content Type' section in the left navigation pane
	// BS-3091
	@Test(priority = 5)
	public void Verify_See_More_Link_Appears_If_There_Are_more_Than_5_Facet_Links() {
		test.Contentpage.SearchForAnItem(MarketingAuthorImage);
		test.Contentpage.verifyFacetLinkNotDisplayed(FacetContentType, SeeMoreLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.verifyFacetLinkIsDisplayed(FacetContentType, SeeMoreLink);
		test.Contentpage.SearchForAnItem("test");
		test.Contentpage.verifyFacetLinkIsDisplayed(FacetContentType, SeeMoreLink);
	}

	// 7) Verify that count of results appearing with the facet link matches with
	// the count of results on the search results page that appears after clicking
	// on the filter:
	// BS-3091
	@Test(priority = 6)
	public void Verify_Count_Of_Results_Matches_Facet_Link() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.Contentpage.verifyOnSeeMorePopup(FacetContentType);
		test.Contentpage.verifyCorrectCountOfAssetFromSeeMoreLink(FacetLinkImageLinked);
		test.Contentpage.SearchForAnItem("test");
		test.Contentpage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.Contentpage.verifyOnSeeMorePopup(FacetContentType);
		test.Contentpage.verifyCorrectCountOfAssetFromSeeMoreLink(FacetLinkImageLinked);
	}

	// 8) Verify that if user selects any Content type from the available Content
	// type facet list, then only that is displayed under the facet and results
	// corresponding to the same are displayed to the right of the page.
	// BS-3091
	@Test(priority = 7)
	public void Verify_Only_Selected_Content_Displayed_On_Facet_List() {
		test.Contentpage.verifyOnlyOneFacetLinkDisplayed(FacetContentType);
		test.Contentpage.verifyContentTypeDisplayedForAsset(FacetLinkImageLinked);
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.verifyContentTypeDisplayedForAsset(FacetLinkImageLinked);
	}

	// 5) Verify that all the supported 43 content types that are available in CMS
	// are available under ‘Content type’ filter
	// BS-3091
	@Test(priority = 8)
	public void Verify_all_Supported_43_Content_Types() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.Contentpage.verifyAllContentTypesAreDisplayedOnSeeMorePopup();
	}

	// 9) Verify that user is able to use the filter box inside the + See more
	// pop-up as expected
	// BS-3091
	@Test(priority = 9)
	public void Verify_User_Able_To_Use_The_Filter_Box() {
		test.Contentpage.enterTextFilterSearchBar(FacetLinkImageLinked);
		test.Contentpage.VerifyLinkDisplayedOnSeeMorePopup(FacetLinkImageLinked);
		test.Contentpage.VerifyLinkNotDisplayedOnSeeMorePopup(TypeOfContentMarketingAuthorImage);
		test.Contentpage.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
	}

	// "B) For Advanced Search> 'Assets' 1) Verify that 'Contents Type' filter
	// appears in the left navigation pane"
	// BS-3091
	@Test(priority = 10)
	public void Verify_Contents_Type_Filter_On_Contents_Tab_Advance_Search() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyFacetTitle(FacetContentType);
	}

	// 2) Verify that by default 5 filter facet links appear in 'Content Type'
	// filter in the left navigation pane (Highest from the top)
	// BS-3091
	@Test(priority = 11)
	public void Verify_Default_5_Filter_Facet_Links_AdvanceSearch() {
		test.SearchPage.VerifyFacetTitle(FacetRepository);
		test.SearchPage.VerifyFacetTitle(FacetContentType);
		test.SearchPage.VerifyFacetTitle(FacetSubjects);
		test.SearchPage.VerifyFacetTitle(FacetTitle);
		test.SearchPage.VerifyFacetTitle(FacetContentState);
	}

	// 3) Verify that top 5 facet links appear in 'Content Type' filter is sorted by
	// results count in the descending order
	// BS-3091
	@Test(priority = 12)
	public void Verify_Default_5_Filter_Facet_Links_Are_In_Descending_Order_AdvanceSearch() {
		test.SearchPage.verifyFacetLinkArrangedInDescendingOrder(FacetContentType);
	}

	// 4) Verify that 'See More' link appears if there are more than 5 facet links
	// under the 'Content Type' section in the left navigation pane
	// BS-3091
	@Test(priority = 13)
	public void Verify_See_More_Link_Appears_If_There_Are_more_Than_5_Facet_Links_AdvanceSearch() {
		test.Contentpage.verifyFacetLinkIsDisplayed(FacetContentType, SeeMoreLink);
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvanceSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
		test.SearchPage.EnterTextIntoSearchBox(MarketingAuthorImage);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.verifyFacetLinkNotDisplayed(FacetContentType, SeeMoreLink);

	}

	// 5) Verify that all the supported 43 content types that are available in CMS
	// are available under ‘Content type’ filter
	// BS-3091
	@Test(priority = 14)
	public void Verify_all_Supported_43_Content_Types_AdvanceSearch() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.SearchPage.verifyAllContentTypesAreDisplayedOnSeeMorePopup();
	}

	// 7) Verify that count of results appearing with the facet link matches with
	// the count of results on the search results page that appears after clicking
	// on the filter
	// BS-3091
	@Test(priority = 15)
	public void Verify_Count_Of_Results_Matches_Facet_Link_AdvanceSearch() {
		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.SearchPage.verifyOnSeeMorePopup(FacetContentType);
		test.SearchPage.verifyCorrectCountOfAssetFromSeeMoreLink(FacetLinkImageLinked);
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox("Automation");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.SearchPage.verifyOnSeeMorePopup(FacetContentType);
		test.SearchPage.verifyCorrectCountOfAssetFromSeeMoreLink(TypeOfContentMarketingAuthorImage);
	}

	// 8) Verify that if user selects any Content type from the available Content
	// type facet list, then only that is displayed under the facet and results
	// corresponding to the same are displayed to the right of the page.
	// BS-3091
	@Test(priority = 16)
	public void Verify_Only_Selected_Content_Displayed_On_Facet_List_AdvanceSearch() {
		test.SearchPage.verifyOnlyOneFacetLinkDisplayed(FacetContentType);
	}

	// 9) Verify that user is able to use the filter box inside the + See more
	// pop-up as expected
	// BS-3091
	@Test(priority = 19)
	public void Verify_User_Able_To_Use_The_Filter_Box_AdvanceSearch() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.SearchPage.enterTextFilterSearchBar(FacetLinkImageLinked);
		test.SearchPage.VerifyLinkDisplayedOnSeeMorePopup(FacetLinkImageLinked);
		test.SearchPage.VerifyLinkNotDisplayedOnSeeMorePopup(TypeOfContentMarketingAuthorImage);
	}
	
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
