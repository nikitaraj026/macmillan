package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Search_Page_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, LookForAsset, LookForProject, LookForBoth;
	String AssetName, ISBN, ThisPageSelection, AllPageSelection;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		LookForAsset = getData("LookFor.Assets");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		AssetName = getData("DamContent");
		ISBN = getData("ProjectISBNNO");
		ThisPageSelection = getData("PageSelection.This Page");
		AllPageSelection = getData("PageSelection.All Pages");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutFromApplication() {
		test.HomePage.LogoutFromApplication();
	}

	// 1.Verify that a pop up named as 'Advanced Search' gets opened on a user click
	// at 'Advanced Search' link present beside normal search box
	@Test(priority = 1)
	public void Verify_Advance_Search_Pop_Up_On_click_Advanced_Search() {

		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();

	}

	// 2.Verify that a user is able to make a successful search using advanced
	// search
	@Test(priority = 2)
	public void Verify_Advanced_Search_Functionality() {
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.VerifyAdvanceSearchForAsset(ISBN);

	}

	// 3.Verify that Reset button resets the data to default
	@Test(priority = 3)
	public void Verify_Reset_Button_Is_Working() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyResetButton();
	}

	// 4.Verify that a successful user search leads a user to navigate at search
	// results page
	@Test(priority = 4)
	public void Verify_Search_Leads_To_results_page() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.SearchPage.VerifyResultAreAccordingToSearchedText(ISBN);
	}

	// 5.Verify that application starts providing search suggestion as soon as a
	// user starts entering a valid search string
	@Test(priority = 5)
	public void Verify_Suggestion_Are_Provided_For_Search() {
		test.SearchPage.VerifySuggestionAreProvided(ISBN);
	}

	// 6.Verify that added new field is displayed only once in the middle section of
	// the pop-up
	@Test(priority = 6)
	public void Verify_Added_New_Field_Is_Displayed_Only_Once() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp("Content Type");
		test.SearchPage.VerifyCountOfNewFieldAdded(1);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp("Content Type");
		test.SearchPage.SelectContentTypeInAddedField("2", getData("TypesOfContent.Enhanced ePub > Full Package"));
		test.SearchPage.AND_OR_Option_Select("OR");
		test.SearchPage.VerifyCountOfNewFieldAdded(2);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp("Author");
		test.SearchPage.VerifyCountOfNewFieldAdded(3);
	}

	// 7.Verify that 'PSL' has been removed from the 'Publish Destination' drop-down
	// present under Advanced Search.
	@Test(priority = 7)
	public void Verify_PSL_Has_Been_Removed_From_Publish_Destination_In_Advance_Search() {

		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp("Publish Destination");
		test.SearchPage.VerifyPSL_IsNotDisplayed();
	}

	// 8.Advance Search: Verify the Select All feature
	@Test(priority = 9)
	public void Verify_Select_All_Feature_On_AdvanceSearch() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(ThisPageSelection);
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.VerifyContentsAreNotSelected();
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.VerifyContentsAreSelected();

		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(AllPageSelection);
		test.SearchPage.VerifyAllDisplayedInAssertCount("All");
	}

	// 9.Generic Search: Verify the Select All feature
	@Test(priority = 10)
	public void Verify_Select_All_Feature_On_GenericSearch() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(ThisPageSelection);
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTab();
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.Contentpage.SelectPageType(AllPageSelection);
		test.Contentpage.VerifyAllDisplayedInAssertCount("All");
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
