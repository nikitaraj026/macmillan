package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Reg_Home_Page_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DAMLink, LookForAsset, LookForProject,
			LookForBoth;
	String Elvis, ProjectISBNNO, NonAdminEmail, NonAdminPassword, ISBN, Noncmsassert, PassResetEmail,
			CurrentResetPassword;
	String SelectPageThisPage,TypesOfContentEnhancedEpub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		Elvis = getData("NonCMSAssert.Elvis");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ProjectISBNNO = getData("ProjectISBNNo1");
		Noncmsassert = getData("DamContent");
		PassResetEmail = getData("PasswordResetAccount.email");
		CurrentResetPassword = PropFileHandler.readPropertyFromDataFile("currentPassword");
		LookForAsset = getData("LookFor.Assets");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		SelectPageThisPage = getData("PageSelection.This Page");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}


	// 1.Verify that a user gets landed on 'Dashboard' tab after a successful login
	// into the application
	@Test(priority = 1)
	public void Verify_That_User_Landed_On_Dashboard_After_login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.DashBordIsDisplayed();
	}

	// 2.Verify that 'Macmillan Learning CMS' logo is present at the top left
	@Test(priority = 2)
	public void Verify_That_Macmillan_Learning_CMS_Logo_Is_Present() {
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyMacmillanLogoIsPresent();
	}

	// 3.Verify that user is navigated to Dashboard page on clicking the Macmillan
	// logo
	@Test(priority = 3)
	public void Verify_User_Navigated_to_Dashboard_Page_On_Clicking_Macmillan_Logo() {
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyMacmillanLogoIsPresent();
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.DashBordIsDisplayed();
	}

	// 4.Verify that a total of 3 tabs are presented 'Dashboard', 'Projects',
	// 'Content' in the homepage
	@Test(priority = 4)
	public void Three_tabs_Are_Displayed() {
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyContentTabIsDisplayed();
		test.HomePage.VerifyProjectTabIsDisplayed();
	}

	// 5.Verify that a user profile button is present at the top right of window
	@Test(priority = 5)
	public void Verify_User_Profile_Button_Is_Present() {
		test.HomePage.VerifyProfileButton();
	}

	// 6.Verify that Generic Search Field and drop down button with options 'All
	// Types', 'Projects' and 'Contents' is present at top middle of the window
	@Test(priority = 6)
	public void Search_Field_And_Drop_Down_Button_With_Options_IsDisplyed() {
		test.HomePage.VerifySearchFieldIsDisplayed();
		test.HomePage.VerifyUserAbleToSelectOptionsInNormalSearch();
	}

	// 7.Verify that on clicking the user profile button drop down appear with Edit
	// Account and logout option
	@Test(priority = 7)
	public void Verify_EditAccount_And_Logout_Options() {
		test.HomePage.VerifyProfileButton();
		test.HomePage.clickUserName();
		test.HomePage.VerifyEditAccountDisplayed();
		test.HomePage.VerifyLogoutDisplayed();
	}

	// 8.Verify that Logout button leads to logout application and user is
	// successfully able to log out of the application
	@Test(priority = 8)
	public void Verify_Logout_button_leads_To_Logout_Application() {
		test.HomePage.clickLogOut();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
	}

	// 9.Verify that clicking on the Edit Account, Account pop-up opens
	@Test(priority = 9)
	public void Verify_Clicking_On_The_Edit_Account_Account_PopUp_Opens() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyProfileButton();
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.VerifyAccountPopUp();
	}

	// 10.Verify that Account pop-up have two tabs 'General information' and 'Reset
	// Password'
	@Test(priority = 10)
	public void Verify_Account_PopUp_Have_Two_Tabs() {
		test.HomePage.verifyGeneralInformation();
		test.HomePage.verifyResetPassword();
	}

	// 11.Verify that General information tab in the Account pop-up have two fields
	// Full Name and Email Address(Displaying relevant info) also Cancel button
	@Test(priority = 11)
	public void Verify_Full_Name_And_Email_Address_On_General_Information() {
		test.HomePage.VerfiyFullNameAndEmailIDIsDisplayed();
		test.HomePage.VerifyCancelButton();
	}

	// 12.Verify that clicking on the cancel button present in the General
	// information tab in the Account pop-up closes the pop-up
	@Test(priority = 12)
	public void Verify_Calcel_Button_Closes_Account_PopUp() {
		test.HomePage.VerifyCancelButton();
		test.HomePage.clickCancelButton();
		test.HomePage.VerifyAccountPopUpClosed();
	}

	// 13.Verify that user is not able to Edit the Full Name and Email Address
	// Fields present in the General information tab
	@Test(priority = 13)
	public void Verify_User_Not_Able_To_Edit_Fields_Present_In_General_Information() {
		test.HomePage.VerifyProfileButton();
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.VerifyAccountPopUp();
		test.HomePage.VerifyGeneralInformationFieldsNotEditable();
	}

	// 14."Verify that Reset Password tab in the Account pop-up have three fields
	// Old Password, New Password and Confirm Password"
	@Test(priority = 14)
	public void Verify_Reset_Password_Tab_Have_Three_Fields() {
		test.HomePage.ClickResetPassword();
		test.HomePage.VerifyAllThreeFiledsAreDisplayed();
	}

	// 15.Verify that Reset Password tab in the Account pop-up have two buttons
	// Update , cancel and also have have link "Show password on screen"
	@Test(priority = 15)
	public void Verify_Update_cancel_And_Show_Password_On_Screen() {
		test.HomePage.VerifyUpdateButton();
		test.HomePage.VerifyCancelButton();
		test.HomePage.VerifyShowPasswordOnScreen();
	}

	// 16.Verify that a user is successfully able to update/reset the password for
	// his/her own user account
	@Test(priority = 16)
	public void Verify_User_Is_Able_To_UpdateAndReset_Password() throws IOException {
		test.HomePage.LogoutFromApplication();
		test.loginpage.enterEmailAddress(PassResetEmail);
		test.loginpage.enterUserPassword(CurrentResetPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
		test.HomePage.ResetPassword();
	}

	// 17.Verify that new password field must display message"Invalid input, should
	// have at least 8 character" if user has entered less than 8 Character in new
	// password
	@Test(priority = 17)
	public void Verify_New_Password_Field_Must_Display_Message_on_Less_Than_8_Character_Password() {
		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
	}

	// 18.Verify that new password field must display message"Should have at least
	// one uppercase" if user has not entered any character in UPPER CASE in new
	// password
	@Test(priority = 18)
	public void Verify_New_Password_Field_Must_Display_Message_on_Least_One_Uppercase() {
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForLessThan8Character();
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForOneUppercase();
	}

	// 19.Verify that new password field must display message"Should have at least
	// one number" if user has not entered any number character in new password
	@Test(priority = 19)
	public void Verify_New_Password_Field_Must_Display_Message_on_Least_One_Number() {
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForOneNumber();
	}

	// 20.Verify that new password field must display message"Should have at least
	// one lowercase" if user has not entered any character of the new password in
	// lowercase
	@Test(priority = 20)
	public void Verify_New_Password_Field_Must_Display_Message_on_Least_One_LowerCase() {
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForOneLowerCase();
	}

	// 21.Verify that message "Password does not match" is displayed if user enters
	// different passwords in the new password and confirm password field
	@Test(priority = 21)
	public void Verify_If_User_Enters_Different_Passwords_In_New_And_Confirm_Password_Field_Error_MessageDispalyed() {
		test.HomePage.VerifyUserGetsErrorMessageIfNewAndConformFieldsAreNotSame();

	}

	// 22.Verify that error message is displayed if user enters old password
	// incorrect
	@Test(priority = 22)
	public void Verify_Error_Message_Is_Displayed_If_User_Enters_Old_Password_Incorrect() {
		test.HomePage.VerifyUnableToResetOnIncorrectOldPassword();
		test.HomePage.clickXButtonOnRestPassword();
	}

	// 23.Verify that Update button in the Reset password tab is not active if any
	// of the 2 fields have invalid data in it
	@Test(priority = 23)
	public void Verify_Update_Button_Is_Disabled_If_Any_Of_The_2_Fields_Have_Invalid_Data() {
		test.HomePage.EnterValuesInSecondAndThirdPasswordFiled("Password", "");
		test.HomePage.VerifyUpdateButtonDisable();

		test.HomePage.EnterValuesInSecondAndThirdPasswordFiled("", "Password");
		test.HomePage.VerifyUpdateButtonDisable();
	}

	// 24.Verify that clicking on "Show password on screen" link shows the password
	// entered in all the 3 fields
	@Test(priority = 24)
	public void Verify_Show_Password_On_Screen_Link_Shows_The_Password_Entered_In_All_The_3_Fields() {
		test.HomePage.EnterValuesInSecondAndThirdPasswordFiled("TestPassword1", "TestPassword");
		test.HomePage.clickShowpasswordLink();
		test.HomePage.VerifyUserIsAbleToSeePassword();
	}

	// 25.Verify that clicking on the cancel button present in the Reset Password
	// tab in the Account pop-up closes the pop-up
	@Test(priority = 25)
	public void Verify_Clicking_On_The_Cancel_Button_Closes_Reset_Password_Tab() {
		test.HomePage.clickCancelButtonOnRestPassword();
		test.HomePage.verifyResetPasswordPopUpClosed();
	}

	// 26.Verify that clicking on the X icon close the account pop-up
	@Test(priority = 26)
	public void Verify_Clicking_On_The_X_Button_Closes_Reset_Password_Tab() {
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
		test.HomePage.clickXButtonOnRestPassword();
		test.HomePage.verifyResetPasswordPopUpClosed();
	}

	// 27.Verify that user is not able to reset the password if user enters the
	// incorrect old password
	@Test(priority = 27)
	public void Verify_User_Is_Not_Able_To_Reset_The_Password_On_Incorrect_Old_Password() {
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
		test.HomePage.VerifyUnableToResetOnIncorrectOldPassword();
	}

	// 28.Verify that a upload content button is present at dashboard tab
	@Test(priority = 28)
	public void Verify_Upload_Content_Button_Is_Present_At_Dashboard() {
		test.refreshPage();
		test.HomePage.VerifyUploadContentButtonIsPresent();
	}

	// 29.Verify that the facets present on the left side of the window
	@Test(priority = 29)
	public void Verify_Facets_Links_Present_On_Left_Side() {
		test.HomePage.VerifyFacetLinksPresentAtLeftSide();
	}

	// 30.Verify that 3 categories of facets: Title, Project Status and Project Type
	// are present
	@Test(priority = 30)
	public void Verify_3_Categories_Of_Facets() {
		test.HomePage.VerifyFacetLinksPresentAtLeftSide();
	}

	// 31.Verify on clicking the Dashboard tab, user is able to navigate to
	// Dashboard page
	@Test(priority = 31)
	public void Verify_On_Clicking_Dashboard_User_Navigate_To_Dashboard() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();

	}

	// 32.Verify on clicking the Projects tab user able to navigate on Projects page
	@Test(priority = 32)
	public void Verify_On_Clicking_Projects_User_Navigate_To_Projects_Page() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
	}

	// 33.Verify on clicking the content tab user able to navigate on content page
	@Test(priority = 33)
	public void Verify_On_Clicking_content_User_Navigate_To_content_Page() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
	}

	// 34.Verify that a user click on any of these facets leads a user to search
	// results page
	@Test(priority = 34)
	public void Verify_Facet_Link_Leads_User_To_Desired_Search_Page() {
		test.HomePage.ClickDashBord();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickOnFacetLinks();
	}

	// 36.Verify a user is able to choose between ALL, Project and Content while
	// making a normal search query
	@Test(priority = 36)
	public void Verify_User_Is_Able_To_Choose_Between_ALL_Project_And_Content_In_Normal_Search() {
		test.HomePage.ClickDashBord();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyUserAbleToSelectOptionsInNormalSearch();
	}

	// 37.Verify that a user search leads a user to navigate at search results page
	@Test(priority = 37)
	public void Verify_User_Search_Leads_User_To_Desired_Search_Page() {
		test.Contentpage.SearchForAnItem(ISBN);
		test.SearchPage.VerifyResultAreAccordingToSearchedText(ISBN);
	}

	// 38.Verify that application starts providing search suggestion as soon as a
	// user starts entering a valid search string
	@Test(priority = 38)
	public void Verify_Suggestion_Are_Provided_For_Search() {
		test.HomePage.ClickDashBord();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.SearchPage.VerifySuggestionAreProvided(ISBN);
	}

	// 39.Verify that a pop up named as 'Advanced Search' gets opened on a user
	// click at 'Advanced Search' link present beside normal search box
	@Test(priority = 39)
	public void Verify_Advanced_Search_PopUp_Opens_on_Clicking_Advanced_Search_Link() {
		test.refreshPage();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
	}

	// 40."Verify that the advanced search pop has Look For drop downSearch
	// fieldfield paneAdd new field drop downAdd, Search, Cancel buttons"
	@Test(priority = 40)
	public void Verify_Advanced_Search_PopUp_Has_Various_Field() {
		test.HomePage.VerifyVeriousFieldOnAdvancedSearchPopUp();
	}

	// 41.Verify that user is able to select between the Assets / projects or both
	// from the Look For drop down
	@Test(priority = 41)
	public void Verify_User_Is_Able_Select_Options_From_Look_For_Drop_Down() {
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.SelectLookFor(LookForBoth);
	}

	// 42.Verify that hovering the mouse over Help icon (?) help pane is open and
	// display the information
	@Test(priority = 42)
	public void Verify_User_Mouse_Hover_Over_Help_Icon_Display_Information() {
		test.HomePage.VerifyHelpInfoDisplayedOnMouseHover();
	}

	// 43."Verify that 13 options are available in Add a new field drop down list if
	// Assets are selected in the look for drop down"
	@Test(priority = 43)
	public void Verify_13_Options_Are_Available_In_Add_new_Field_If_Assets_Selected_In_LookFor() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.HomePage.Verify14OptionsInAddNewField();
	}

	// 44."Verify that 13 options are available in Add a new field drop down list if
	// the Project is selected in the look for drop down"
	@Test(priority = 44)
	public void Verify_13_Options_Are_Available_In_Add_new_Field_If_Project_Selected_In_LookFor() {
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.HomePage.Verify13OptionsInAddNewField();
	}

	// 45.Verify that user is able to add a new field to add pane on selecting and
	// clicking on the add button in the Advanced Search pop up
	@Test(priority = 45)
	public void Verify_User_Is_Able_To_Add_New_Field_To_Add_Pane() {
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.HomePage.AddNewFieldInAdvancedSearchPopUpAndVerify();
	}

	// 46.Verify that user is able to Select options from newly added field
	@Test(priority = 46)
	public void Verify_User_Is_Able_To_Select_Options_From_Newly_Added_Field() {
		test.HomePage.SelectContentTypeInNewAddedField();
	}

	// 47.Verify that fields added have And/ OR dropdown to the left
	@Test(priority = 47)
	public void Verify_AndOR_Field_Is_Displayed() {
		test.HomePage.clickAddOnAdvSearch();
		test.HomePage.VerifyAndOrFiledOnAdvSearch();
	}

	// 48.Verify that user is able to make advanced search
	@Test(priority = 48)
	public void Verify_User_Is_Able_To_Make_Advanced_Search() {
		test.HomePage.SearchTextInAdvanceSearch(ISBN);
		test.HomePage.VerifyResultAreAccordingToSearchedText(ISBN);
	}

	// 49.Verify that Cancel button in Advanced Search pop up closes the same
	@Test(priority = 49)
	public void Verify_Cancel_Button_In_Advanced_Search_PopUp_Closes_The_PopUp() {
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.HomePage.clickCancelButtonOnAdvPopUp();
		test.HomePage.verifyAdvanceSearchPopUpClosed();
	}

	// 51.Verify that user is able to navigate to the respective project view from
	// favourite Projects section
	@Test(priority = 51)
	public void Verify_User_Is_Able_To_Navigate_To_Project_View_From_Recent_Projects() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickOnA_Project();
		test.projectView.verifyOnProjectView();
	}

	// 52.Verify that "Show all" link is available under the Recent Project towards
	// right of the window
	@Test(priority = 52)
	public void Verify_User_Show_All_Project_Link_Available_Under_The_Recent_Project() {
		test.HomePage.ClickDashBord();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.AddProjectsToFavorite("7");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
	}

	// 53.Verify that Show all Project link is working
	@Test(priority = 53)
	public void Verify_Show_AllProjectLinkWorking() {
		test.HomePage.VerifyShowAllButtonDisplayAllProject();
		test.HomePage.RemoveAllProjectFromFavorite();
	}

	// 54.Verify that on clicking upload content button upload content pop-up opens
	@Test(priority = 54)
	public void Verify_Clicking_Upload_Content_Opens_PopUp() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
	}

	// 55.Verify that upload content pop up has Browse button and able to browse the
	// file
	@Test(priority = 55)
	public void Verify_Browse_Button_Is_Able_To_Browse_On_PopUp() {
		test.HomePage.VerifyBrowseButton();
		test.HomePage.SelectFileUsingBrowseButton(ProjectISBNNO + ".epub");
	}

	// 56.Verify that upload content pop up have Content type drop down and able to
	// select the type of the content
	@Test(priority = 56)
	public void Verify_Upload_Content_PopUp_Has_Content_Type() {
		test.HomePage.VerifyContentTypeSelectTypeOfContent();
	}

	// 57.Verify that various fields are available in upload content pop-up
	@Test(priority = 57)
	public void Verify_Various_Fields_In_Upload_Content_PopUp() {
		test.HomePage.VerifyVariousFieldsInUploadContentPopUp();
	}

	// 58.Verify that upload content pop-up have Add/Remove Projects and Upload
	// button
	@Test(priority = 58)
	public void Verify_AddRemove_Projects_And_Upload_Button_On_PopUp() {
		test.HomePage.VerifyAddRemoveAndUploadButton();
	}

	// 59.Verify that user is able to add/remove Subject Keyword Taxonomy from the
	// button present right of the field in the upload content pop-up
	// @Test(priority=59) ##!!!!! Functionality Removed !!!!!!##
	public void Verify_User_Is_Able_To_AddRemove_Subject_Keyword_Taxonomy() {
		test.HomePage.ClickAddKeywordTaxonomy();
		test.HomePage.RemoveSubjectKeywordTaxonomyFunctionalityandVerify();
	}

	// 60.Verify that user is able to to select Relationship type from the
	// Relationship Type dropdown
	// @Test(priority=60) ##!!!!! Functionality Removed !!!!!!##
	public void Verify_User_Able_To_Select_Relationship_Type_From_Relationship_Dropdown() {
		test.HomePage.VerifyUserIsAbleToSelectRelationshipType();
	}

	// 61.Verify that user is able to to select Relationship target from the
	// Relationship Target dropdown
	// @Test(priority=61) ##!!!!! Functionality Removed !!!!!!##
	public void Verify_User_Able_To_Select_Relationship_Target_From_Relationship_Dropdown() {
		test.HomePage.VerifyUserIsAbleToSelectRelationshipTarget();
	}

	// 62.Verify that clicking on the Add/Remove Projects button open the add/remove
	// project pop up
	@Test(priority = 62)
	public void Verify_Clicking_AddRemove_Button_Open_AddRemovePopUp() {
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
	}

	// 63.Verify that Add/remove project pop up has Search field and clear link
	// beside search field
	@Test(priority = 63)
	public void Verify_Project_PopUp_Has_Search_Field_And_Clear_Link() {
		test.HomePage.VerifySearchFieldAndClearLinkOnAddRemoveProjectPopUp();
	}

	// 64.Verify that Add/remove project pop up has two pane Available and Selected
	// with the Author , Title, Short Title, isbn information
	@Test(priority = 64)
	public void Verify_AddRemove_PopUp_Has_Available_And_Selected_Pane() {
		test.HomePage.VerifyAvailableAndSelectedPane();
	}

	// 65.Verify that Add/remove project pop up has Select , unselect, Done and
	// cancel button
	@Test(priority = 65)
	public void Verify_AddRemove_PopUp_Has_Select_Unselect_Done_And_Cancel_Button() {
		test.HomePage.VerifySelectUselectDoneCancelButton();
	}

	// 66.Verify in the Add/remove projects pop up user is able to select project
	// from the Available pane on clicking on the Select button
	@Test(priority = 66)
	public void Verify_User_Is_Able_To_Select_Project_From_The_Available_Pane() {
		test.HomePage.SearchProjectInAddRemovePopUp(ProjectISBNNO);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(ProjectISBNNO);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(ProjectISBNNO);
	}

	// 67.Verify in the Add/remove projects pop up user is able to deselect project
	// from the Selected pane on clicking on the unelect button
	@Test(priority = 67)
	public void Verify_User_Is_Able_To_Deselect_Project_From_The_Selected_Pane() {
		test.HomePage.MoveProjectFromSelectedPaneToAvailablePane(ProjectISBNNO);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(ProjectISBNNO);
	}

	// 68.Verify that user is able to add /remove projects and click on the done
	// button close the pop up
	@Test(priority = 68)
	public void Verify_User_Is_Able_To_Add_projects_And_Clicking_Done_Button_Closes_PopUp() {
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(ProjectISBNNO);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(ProjectISBNNO);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.VerifyAddToProjectPopUpNotDisplayed();
	}

	// 69.Verify that clicking on the cancel button pop-up close and changes made
	// are Not saved
	@Test(priority = 69)
	public void Verify_Clicking_On_Cancel_Button_PopUp_Close_Changes_Are_Not_Saved() {
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.ClickCancelOnAddRemove();
		//test.HomePage.handleAlert("Cancel"); Need To Conform
		test.HomePage.VerifyAddToProjectPopUpNotDisplayed();
		test.HomePage.clickXButtonUploadContent();
	}

	// 70.Verify that entering all valid field in the upload content pop up user is
	// able to upload a content
	@Test(priority = 70)
	public void Verify_Upload_Content_PopUp_Enable_User_To_Upload_Content() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickUploadContent();
		test.HomePage.UploadEnhancedEpubAndAssociateFromHomePage(ISBN, ProjectISBNNO);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ProjectISBNNO+".epub",TypesOfContentEnhancedEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 71.Verify that user is able to upload Flat Epub and validate the metadata
	// ingested at CMS end, also can associate the Flat epub to the project from the
	// same.
	@Test(priority = 71)
	public void Verify_User_Is_Able_To_Upload_Flat_Epub_And_Associate_Epub() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickUploadContent();
		test.HomePage.UploadFlatEpubAndAssociateFromHomePage(ISBN, ProjectISBNNO);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 72.Verify that user is successfully able to upload Enhanced Epub and validate
	// the metadata ingested at CMS end
	@Test(priority = 72)
	public void Verify_User_Is_Able_To_Upload_Enhanced_Epub_And_Associate_Epub() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickUploadContent();
		test.HomePage.UploadEnhancedEpubAndAssociateFromHomePage(ISBN, ProjectISBNNO);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 73.Verify that user is successfully able to upload Covers>Cover Design
	// content type and validate the metadata ingested at CMS end
	@Test(priority = 73)
	public void Verify_User_Is_Able_To_Upload_CoversCoverDesign_And_Associate_Content() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickUploadContent();
		test.HomePage.UploadCoversCoverDesignAndAssociateFromHomePage(ProjectISBNNO, ISBN);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ProjectISBNNO);
		test.ContentView.DeleteContentFromCMS();
	}

	// 74.Verify that user is successfully able to upload 'Others' content type and
	// validate the metadata ingested at CMS end
	@Test(priority = 74)
	public void Verify_User_Is_Able_To_Upload_Others_And_Associate_Content() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickUploadContent();
		test.HomePage.UploadOthersContentAndAssociateFromHomePage(ISBN);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 75.Verify that user is successfully able to upload XHTML content type and
	// validate the metadata ingested at CMS end
	@Test(priority = 75)
	public void Verify_User_Is_Able_To_Upload_XHTML_And_Associate_Content() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickUploadContent();
		test.HomePage.UploadXHTMLContentAndAssociateFromHomePage(ISBN);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 76. Verify that while doing Generic search view: ePub labels are appearing on
	// grid view for the generic search results page
	@Test(priority = 76)
	public void Verify_In_Generic_Search_EPub_Labels_Are_Appearing_On_Grid_View() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyFlatIsDisplayed();
		test.Contentpage.VerifyEnhancedIsDisplayed();
	}

	// 77.Verify that reset button is present bottom left of the advance search pop
	// up
	@Test(priority = 77)
	public void Verify_Reset_Button_Present_On_Advance_Search_PopUp() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.VerifyResetButtonIsDispaled();
	}

	// 78.Ensure that clicking on the reset button in the advance search pop up
	// reset all field in the pop up
	@Test(priority = 78)
	public void Verify_Reset_Button_Is_Working() {
		test.SearchPage.VerifyResetButton();
	}

	// 79.Verify that on the advance search result page user is able to select all
	// result displayed on page
	@Test(priority = 79)
	public void Verify_User_Is_Able_To_Select_All_In_Result_Page() {
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectNumberFromResultDropDown("20");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyContentsAreSelected();
	}

	// 80.Verify that selection of assets are maintained if user selects all the
	// content of the search result page and then change Result number(eg 20 to 50)
	@Test(priority = 80)
	public void Verify_Selection_Of_Assets_Are_Maintained_If_Result_Number_Is_Changed() {
		test.SearchPage.SelectNumberFromResultDropDown("10");
		test.SearchPage.VerifyContentsAreSelected();
	}

	// 81.Verify that selection of assets are maintained if user selects all the
	// content of the search result page and then change Result number(eg 20 to 10)
	@Test(priority = 81)
	public void Verify_Selection_Of_Assets_Are_Maintained_If_Result_Number_Is_Changed_To_Higher() {
		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.SelectNumberFromResultDropDown("10");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.SelectNumberFromResultDropDown("20");
		test.SearchPage.VerifyContentsAreSelected(10);
	}

	// 82.Verify that if user check on the radio button top 4 links are activated
	@Test(priority = 82)
	public void Verify_Top_4_Links_Are_Activated_On_Clicking_Radio_Button() {
		test.Contentpage.Verify_Links_Are_Activated();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
