package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_ProjectView_Publish_Operation extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN;
	String SupplementryContentIR, MarketingContentAuthorImage;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare,
			PublihDestinationVitalSource;
	String PublihDestinationInstructorStore, TypesOfContentEnhancedEpub, TypesOfContentSupplementaryInstructorResources,
			TypesOfContentMarketingAuthorImage;
	String AuthorId, MarketingContentSampleChapter,DistributableEPubISBN;
	String TestISBN, TestISBN2, CMSRepository, DAMRepository,TypesOfContentFlatEpub;
	String LookForProject, AdvanceSearchProjectType, ProjectTypeAncillaryManufacturedAndOnline,TypeOfContentSampleChapter;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNo1");
		TestISBN = getData("ProjectISBNNo2");
		TestISBN2 = getData("ProjectISBNNo4");
		SupplementryContentIR = getData("DamContent");
		MarketingContentAuthorImage = getData("MarketingAuthorImage");
		MarketingContentSampleChapter = getData("MarketingSampleChapter");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentSupplementaryInstructorResources = getData(
				"TypesOfContent.Supplementary Content>Instructor Resources");
		TypesOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		TypeOfContentSampleChapter=getData("TypesOfContent.Marketing Content>Sample Chapter");
		AuthorId = getData("Author.id");
		CMSRepository = getData("Repository.CMS");
		DAMRepository = getData("Repository.DAM");
		LookForProject = getData("LookFor.project");
		AdvanceSearchProjectType = getData("SearchTypeAdvanceSearch.Project Type");
		ProjectTypeAncillaryManufacturedAndOnline = getData("ProjectType.Ancillary/IRM (Manufactured and Online)");
		DistributableEPubISBN=getData("DistributableEPubISBN");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// 1.login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 2. Add Dam Asset, Author Image and Sample chapter to Project
	@Test(priority = 2)
	public void Setup_Test_Data_On_Project() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(SupplementryContentIR);
		test.Contentpage.SelectContentOnContentTab(SupplementryContentIR,TypesOfContentSupplementaryInstructorResources);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.Contentpage.SearchForAnItem(MarketingContentAuthorImage);
		test.Contentpage.SelectContentOnContentTab(MarketingContentAuthorImage,TypesOfContentMarketingAuthorImage);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.Contentpage.SearchForAnItem(MarketingContentSampleChapter);
		test.Contentpage.SelectContentOnContentTab(MarketingContentSampleChapter,TypeOfContentSampleChapter);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);
	}

	// 1.Verify that appropriate success message is displayed on publishing the
	// approved Assets to available publish destinations.
	// 2."Verify that for the case of Normal Publish to any Publish destination,
	// following message is displayed:Publish action for the following project/s was
	// successful.<Bullet> ISBN13 i.e. Default ISBN"
	// BS-2628
	// BS-2677
	@Test(priority = 3)
	public void Verify_Appropriate_Success_Message_Displayed_On_Publishing_Assets() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN + "_EPUB.epub",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN + "_EPUB.epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(DAMRepository,
				TypesOfContentSupplementaryInstructorResources, SupplementryContentIR,true);
		test.projectView.Select_Assert_Displayed_In_Step3(SupplementryContentIR);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentMarketingAuthorImage,
				MarketingContentAuthorImage,true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentEnhancedEpub,
				ISBN + ".epub",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentEnhancedEpub,
				ISBN + ".epub",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 3."Verify that if user deletes the default ISBN and adds a different ISBN and
	// then perform a Publish, following message is displayed:
	// Publish action for the following project/s was successful.
	// <Bullet> ISBN13 i.e. the additional ISBN"
	// BS-2677
	@Test(priority = 4)
	public void Verify_Upadted_Publish_Message_Removing_Default_ISBN() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN);
		test.projectView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentMarketingAuthorImage,
				MarketingContentAuthorImage,true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(TestISBN);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 4."Verify that for the case of multiple ISBN Publish at a moment to
	// Instructor Store Publish destination, following message is displayed:
	// Publish action for the following project/s was successful.
	// <Bullet> ISBN13 i.e. Default ISBN
	// <Bullet> ISBN13 i.e. additional ISBN 1
	// <Bullet> ISBN13 i.e. additional ISBN 2...etc"
	// BS-2677
	@Test(priority = 5)
	public void Verify_Upadted_Publish_Message_With_Multiple_ISBNs() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.SearchForISBNIn_IS_Publish_Window(TestISBN2);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN2);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN2);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentMarketingAuthorImage,
				MarketingContentAuthorImage,true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN, TestISBN, TestISBN2);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(3);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 5."Verify that for the case of multiple ISBN Publish at a moment to
	// Instructor Store Publish destination (without the default ISBN), following
	// message is displayed:
	// Publish action for the following project/s was successful.
	// <Bullet> ISBN13 i.e. additional ISBN 1
	// <Bullet> ISBN13 i.e. additional ISBN 2...etc"
	// BS-2677
	@Test(priority = 6)
	public void Verify_Upadted_Publish_Message_Without_default_And_Multiple_ISBNs() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN);
		test.projectView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.SearchForISBNIn_IS_Publish_Window(TestISBN2);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN2);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN2);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentMarketingAuthorImage,
				MarketingContentAuthorImage,true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(TestISBN, TestISBN2);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(2);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 6."Project view> Publish: Verify that following order of radio buttons is now
	// available when CoreSource is selected as the Publish destination:
	// 1) Publish ePub only
	// 2) Publish content links and ePub
	// 3) Publish content links only"
	// BS-2931
	@Test(priority = 7)
	public void Verify_Publish_Radio_Buttons_Sequence_For_ProjectView_CoreSource() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishRadioButtonSequence("Publish ePub only", "Publish content links and ePub",
				"Publish content links only");
	}

	// 7."Project view> Publish: Verify that following order of radio buttons is now
	// available when VitalSource is selected as the Publish destination:
	// 1) Publish ePub only
	// 2) Publish content links and ePub
	// 3) Publish content links only"
	// BS-2931
	@Test(priority = 8)
	public void Verify_Publish_Radio_Buttons_Sequence_For_ProjectView_VitalSource() {
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.VerifyPublishRadioButtonSequence("Publish ePub only", "Publish content links and ePub",
				"Publish content links only");
	}

	// 8.Project view> Publish: Verify that correct tool tips are available in front
	// of each updated option
	// BS-2931
	@Test(priority = 9)
	public void Verify_Correct_Tool_Tips_For_Publish_Radio_Button() {
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyToolTips("Publish ePub only", PublihDestinationCoreSource);
		test.projectView.VerifyToolTips("Publish content links and ePub", PublihDestinationCoreSource);
		test.projectView.VerifyToolTips("Publish content links only", PublihDestinationCoreSource);

		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.VerifyToolTips("Publish ePub only", PublihDestinationVitalSource);
		test.projectView.VerifyToolTips("Publish content links and ePub", PublihDestinationVitalSource);
		test.projectView.VerifyToolTips("Publish content links only", PublihDestinationVitalSource);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 9."Content view> Publish: Verify that following order of radio buttons is now
	// available when CoreSource is selected as the Publish destination:
	// 1) Publish ePub only
	// 2) Publish content links and ePub
	// 3) Publish content links only"
	// BS-2931
	//@Test(priority = 10) ## Functionality Removed ##
	public void Verify_Publish_Radio_Buttons_Sequence_For_ContentView_CoreSource() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.VerifyPublishRadioButtonSequence("Publish ePub only", "Publish content links and ePub",
				"Publish content links only");
	}

	// 10. "Content view> Publish: Verify that following order of radio buttons is
	// now available when VitalSource is selected as the Publish destination:
	// 1) Publish ePub only
	// 2) Publish content links and ePub
	// 3) Publish content links only"
	@Test(priority = 11)
	public void Verify_Publish_Radio_Buttons_Sequence_For_ContentView_VitalSource() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.VerifyPublishRadioButtonSequence("Publish ePub only", "Publish content links and ePub",
				"Publish content links only");
	}

	// 11.Content view> Publish: Verify that correct tool tips are available in
	// front of each updated option
	@Test(priority = 12)
	public void Verify_Correct_Tool_Tips_For_Publish_Radio_Button_ContentView() {
		test.ContentView.VerifyPublishPopUpDisplayed();
		/*test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.clickFirstToolTipAndVerifyOutputOnPlatform(PublihDestinationCoreSource);
		test.ContentView.clickThirdToolTipAndVerifyOutputOnPlatfrom(PublihDestinationCoreSource);
		test.ContentView.clickSecondToolTipAndVerifyOutput();*/
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.clickFirstToolTipAndVerifyOutputOnPlatform(PublihDestinationVitalSource);
		test.ContentView.clickThirdToolTipAndVerifyOutputOnPlatfrom(PublihDestinationVitalSource);
		test.ContentView.clickSecondToolTipAndVerifyOutput();
	}

	// 12.Verified that the Auto-suggestion list is getting filtered out on each key
	// stroke made in the 'Select ISBN' search box.
	@Test(priority = 13)
	public void Verify_Auto_Suggestion_List_Getting_Filtered_In_Select_ISBN_SearchBox() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyAutosuggestionListIsFilteredOutOnAdding(ISBN);
	}

	// 13.Verified that if user copies and pastes the ISBN13 into the search box,
	// then single result is displayed in the auto-suggestion list and user can
	// select that ISBN from the list as well.
	@Test(priority = 14)
	public void Verify_Single_Result_If_User_Pastes_ISBN13() {
		test.projectView.CopyPaste_ISBNIn_IS_Publish_Window(TestISBN);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.VerifySingleResultDisplayedOn_IS_AutoSuggestion();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
	}

	// 14.Verified that filtered list gets modified on deleting the numbers from the
	// Search box.
	@Test(priority = 15)
	public void Verify_Filtered_List_Modify_On_Deleting() {
		test.projectView.VerifyAutosuggestionListIsFilteredOutOnDeleting(TestISBN);
	}

	// 15.Verified that user can add the ISBN into the table by clicking the 'ADD'
	// button.
	@Test(priority = 16)
	public void Verify_User_Can_Add_ISBN_Via_Add_Button() {
		test.projectView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN);
	}

	// 16."Verified that if user enters or pastes a value which does not exist in
	// CMS, then following message is displayed just below the search box:
	// No results found for XXXXX"
	@Test(priority = 17)
	public void Verify_Error_Message_If_User_Enters_Or_Pastes_ISBN() {
		test.projectView.EnterISBNIn_IS_Publish_Window("TestForIncorrectISBN_MSG");
		test.projectView.VerifyInCorrectISBNMessageOn_IS("TestForIncorrectISBN_MSG");

		test.projectView.CopyPaste_ISBNIn_IS_Publish_Window("TestForIncorrectISBN_MSG");
		test.projectView.VerifyInCorrectISBNMessageOn_IS("TestForIncorrectISBN_MSG");
	}

	// 17.Verified Auto-suggestion list gets filtered out for pasting the ISBN
	// numbers in chunks as well.
	@Test(priority = 18)
	public void Verify_AutoSuggestion_List_Filters_For_Pasting_ISBN_In_Chunks() {
		test.projectView.CopyPaste_ISBNIn_IS_Publish_Window(ISBN.substring(0, ISBN.length() - 5));
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
	}

	// 18.Verified the same for multiple Project types available in CMS i.e. Online
	// course and Distributable ePub
	@Test(priority = 19)
	public void Verify_AutoSuggestion_List_Filters_For_DistributableEPub_Project() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(DistributableEPubISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyAutosuggestionListIsFilteredOutOnAdding(ISBN);
		test.projectView.CopyPaste_ISBNIn_IS_Publish_Window(TestISBN);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.VerifySingleResultDisplayedOn_IS_AutoSuggestion();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}