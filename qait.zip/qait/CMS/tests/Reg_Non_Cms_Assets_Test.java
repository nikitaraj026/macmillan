package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Non_Cms_Assets_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, DamContent, DownloadStartMsg;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		DamContent = getData("DamContent");
		DownloadStartMsg = getData("DownloadStartMsg");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify "Upload new version" functionality is not available for non cms
	// assets in Version details tab
	@Test(priority = 2)
	public void Verify_Upload_New_Version_Functionality_Not_Available_For_Non_CMS_Assets() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickVersionDetails();
		test.NonCmsAssets.VerifyFunctionalityIsDisabled();
	}

	// 2.Verify that a user successfully able to approve a non cms asset
	@Test(priority = 3)
	public void Verify_User_Is_Able_To_Approve_Non_Cms_Asset() {
		test.NonCmsAssets.VerifyUserIsableToApproveOrUnapprove();
	}

	// 3.Verify that a user successfully able to Unapprove a non cms asset
	@Test(priority = 4)
	public void Verify_User_Is_Able_To_Unapprove_Non_Cms_Asset() {
		test.NonCmsAssets.VerifyUserIsableToApproveOrUnapprove();
	}

	// 4.Verify that a user is able to Download an non cms asset from Download
	// content button
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Download_Non_Cms_Asset() {
		test.ContentView.ClickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "");
	}

	// 5.Verify that a user is unable to edit an non cms asset
	@Test(priority = 6)
	public void Verify_User_Is_Unable_To_Edit_An_Non_Cms_Asset() {
		test.NonCmsAssets.VerifyFunctionalityIsDisabled();
	}

	// 6.Verify that a user is unable to delete an non cms asset
	@Test(priority = 7)
	public void Verify_User_Is_Unable_To_Delete_An_Non_Cms_Asset() {
		test.NonCmsAssets.VerifyFunctionalityIsDisabled();
	}

	// 7.Verify that user is able to Publish an approved asset
	@Test(priority = 8)
	public void Verify_User_Is_able_Publish_Non_Cms_Assets() {
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDamContentAndPublish(DamContent);
		test.refreshPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.SelectDamContentAndPublishUnApproved(DamContent);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
