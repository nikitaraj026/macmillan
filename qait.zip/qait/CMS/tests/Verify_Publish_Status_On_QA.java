package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import org.testng.ITestContext;
import org.testng.ITestResult;
import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Verify_Publish_Status_On_QA extends Parent_Test {
	CMSTestInitiator test;
	String ProjectISBN1, ProjectISBN2;
	String baseURL,AdminEmail,AdminPassword,homePageLink,loginPageLink,DamContent;
	String MarketingAuthorImage,MarketingAuthorSampleName;
	String NameOfSuite,MarketingSampleChapter,MarketingSampleChapterName;
	
	private void initVars() {
	baseURL = getData("baseUrl");
	AdminEmail=getData("Admin.email");
	AdminPassword=getData("Admin.password");
	homePageLink=getData("Link.HomePageLink");
	loginPageLink=getData("Link.loginPageLink");
	ProjectISBN1=getData("ProjectISBNNO");
	ProjectISBN2=getData("ProjectISBNNo1");
	DamContent=getData("DamContent");
	MarketingAuthorImage = getData("MarketingAuthorImage");
	MarketingAuthorSampleName=getData("MarketingAuthorSampleImage");
	MarketingSampleChapter=getData("MarketingSampleChapter");
	MarketingSampleChapterName=getData("MarketingSampleChapterName");
	}
	
	@BeforeSuite
    @Parameters({ "suiteType", "productID", "suiteID" })
    public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID, @Optional("0") String suiteID,ITestContext ctx) {
        beforeSuiteMethod(suiteType, productID, suiteID);
        NameOfSuite=ctx.getSuite().getName();
    }
	

    @BeforeClass
    public void start_test_Session() {
        test = new CMSTestInitiator();
        initVars();
        test.launchApplication(baseURL);
    }

    @BeforeMethod
    public void handleTestMethodName(Method method) {
        test.stepStartMessage(method.getName());
    }
    
    //Login in into Application.
    @Test(priority=1)
    public void Login_In_Into_Application() {
    	test.loginpage.verifyEmailTextBoxDislayed();
    	test.loginpage.verifyPasswordTextBoxDisplayed();
    	test.loginpage.verifyLogInButtonDisplayed();
    	test.loginpage.enterEmailAddress(AdminEmail);
    	test.loginpage.enterUserPassword(AdminPassword);
    	test.loginpage.clickLogInButton();
    	test.HomePage.verifyOnhomePage(homePageLink);
    }
    
    //Check publish Status for the Enhanced Rpub published.
    @Test(priority=2)
    public void Verify_Publish_Status_For_Enhanced_Epubs(){
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN1+".epub");
		test.Contentpage.opentheSearchContent(ProjectISBN1+".epub");
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN1+".epub");
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN1+".epub");
    	
    	
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN2+".epub");
		test.Contentpage.opentheSearchContent(ProjectISBN2+".epub");
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN2+".epub");
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN2+".epub");
    }
    
    
    //Check publish Status for Flat Epub Published.
    @Test(priority=3)
    public void Verify_Publish_Status_For_Flat_Epubs(){
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN1+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ProjectISBN1+"_EPUB.epub");
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN1+"_EPUB.epub");
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN1+"_EPUB.epub");
    	
    	
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN2+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ProjectISBN2+"_EPUB.epub");
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN2+"_EPUB.epub");
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN2+"_EPUB.epub");
    }
    
    //Check publish Status of Cover_Design Asset. 
    @Test(priority=4)
    public void Verify_Publish_Status_For_CoverDesign_Asset(){
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN1+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ProjectISBN1+"_FC.jpg");
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN1+"_FC.jpg");
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN1+"_FC.jpg");
    	
    	
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN2+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ProjectISBN2+"_FC.jpg");
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN2+"_FC.jpg");
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN2+"_FC.jpg");
    }
    
    //Verify Publish Status of Dam Asset Published.
    @Test(priority=5)
    public void Verify_Publish_Status_For_Dam_Asset(){
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(DamContent);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.Contentpage.opentheSearchContent(DamContent);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(DamContent);
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(DamContent);
    }
    
    
    //Check publish Status of Marketing Content Author Image
    @Test(priority=6)
    public void Verify_Publish_Status_For_MarketingContentAuthorImage(){
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(MarketingAuthorImage);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.Contentpage.opentheSearchContent(MarketingAuthorImage);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingAuthorImage);
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingAuthorImage);
    	
    	System.out.println("NAME OF SUITE::"+NameOfSuite);
    	if(NameOfSuite.equalsIgnoreCase("CMS_Full_Regression_TestNG"))
    	{
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(MarketingAuthorSampleName);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.Contentpage.opentheSearchContent(MarketingAuthorSampleName);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingAuthorSampleName);
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingAuthorSampleName);
    	
    	test.refreshPage();
    	test.ContentView.waitForLoaderToDisappear();
    	test.ContentView.DeleteContentFromCMS();
    	}
    }
    
    //Check publish Status for Marketing Content Sample Chapter
    @Test(priority=7)
    public void Verify_Publish_Status_For_MarketingContentSampleChapter(){
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(MarketingSampleChapter);
    	test.Contentpage.waitForLoaderToDisappear();;
    	test.Contentpage.opentheSearchContent(MarketingSampleChapter);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingSampleChapter);
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingSampleChapter);
    	
    	System.out.println("NAME OF SUITE::"+NameOfSuite);
    	if(NameOfSuite.equalsIgnoreCase("CMS_Full_Regression_TestNG"))
    	{
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(MarketingSampleChapterName);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.Contentpage.opentheSearchContent(MarketingSampleChapterName);
    	test.Contentpage.waitForLoaderToDisappear();
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingSampleChapterName);
    	test.ContentView.NavigateToPageNoInPublishDetail(2);
    	test.ContentView.VerifyPublishStatusofTheContent(MarketingSampleChapterName);
    	
    	test.refreshPage();
    	test.ContentView.waitForLoaderToDisappear();
    	test.ContentView.DeleteContentFromCMS();
    	}
    }
    
    //Check publish Status of CFI Content
    @Test(priority=7)
    public void Verify_Publish_Status_For_CFI_Content(){
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN1+"_CFI.csv");
		test.Contentpage.opentheSearchContent(ProjectISBN1+"_CFI.csv");
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN1+"_CFI.csv");
    	
    	test.HomePage.ClickContentTab();
    	test.Contentpage.VerifyOnContentTab();
    	test.Contentpage.SearchForAnItem(ProjectISBN2+"_CFI.csv");
		test.Contentpage.opentheSearchContent(ProjectISBN2+"_EPUB.epub");
    	test.ContentView.VerifyOnContentViewPage();
    	test.ContentView.ClickPublishDetail();
    	test.ContentView.VerifyPublishStatusofTheContent(ProjectISBN2+"_CFI.csv");
    }
    
    @AfterMethod
   	public void onFailure(ITestResult result)
   	{
   		afterMethod(test, result, this.getClass().getName()); 
   	}
    
    @AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
