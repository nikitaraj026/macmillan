package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Reg_Home_Page_Dec_Release extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DAMLink, LookForAsset, LookForProject,
			LookForBoth;
	String Elvis, ProjectISBNNO, NonAdminEmail, NonAdminPassword, ISBN, Noncmsassert, PassResetEmail,
			CurrentResetPassword;
	String OrganisedDownloadMsg, OrganisedDownloadMsgAdv, DownloadStartMsg, DamContent, DownloadStartMsgAdv;
	String TypesOfContentEnhancedEpub, TypesOfContentFlatEpub, TypesOfContentBatchEnhanced,
			TypeOfContentMarketingSampleChapter, TypesOfContentBatchFlat, AdvSearchTypeAuthor, AdvSearchTypeContentType;
	String AdvSearchTypePublishDestination, projectTitle, TypeOfContentCoverDesign, AdvSearchTypeRepository,
			TypeOfContentMarketingAuthorImage;
	String DMS_Email, DMS_Password, MarketingAuthorImage, MarketingSampleChapter, AuthorName, AuthorId,
			AuthorSampleImage, MarketingSampleChapterName;
	String NewTitle = "Automation Edited Title.";
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationVitalSource,
			PublihDestinationInstructorStore,CMSRepository;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		Elvis = getData("NonCMSAssert.Elvis");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ProjectISBNNO = getData("ProjectISBNNo1");
		Noncmsassert = getData("DamContent");
		PassResetEmail = getData("PasswordResetAccount.email");
		CurrentResetPassword = PropFileHandler.readPropertyFromDataFile("currentPassword");
		LookForAsset = getData("LookFor.Assets");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsg");
		OrganisedDownloadMsgAdv = getData("OrganisedDownloadMsgAdv");
		DownloadStartMsg = getData("DownloadStartMsg");
		DownloadStartMsgAdv = getData("DownloadStartMsgAdv");
		DamContent = getData("DamContent");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentBatchEnhanced = getData("TypesOfContent.Flat ePub > Batch");
		TypesOfContentBatchFlat = getData("TypesOfContent.Enhanced ePub > Batch");
		TypeOfContentCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		TypeOfContentMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		AdvSearchTypeAuthor = getData("SearchTypeAdvanceSearch.Author");
		AdvSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		AdvSearchTypePublishDestination = getData("SearchTypeAdvanceSearch.Publish Destination");
		AdvSearchTypeRepository = getData("SearchTypeAdvanceSearch.Repository");
		projectTitle = getData("ProjectTitle");
		DMS_Email = getData("DMSUser.email");
		DMS_Password = getData("DMSUser.password");
		MarketingAuthorImage = getData("MarketingAuthorImage");
		AuthorSampleImage = getData("MarketingAuthorSampleImage");
		MarketingSampleChapterName = getData("MarketingSampleChapterName");
		AuthorName = getData("Author.Name");
		AuthorId = getData("Author.id");
		MarketingSampleChapter = getData("MarketingSampleChapter");
		CMSRepository=getData("Repository.CMS");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that the unmarked Project keeps on displaying in the favorite
	// table. However, count in the facet link is displayed for the current
	// Favorite project(s) only.
	// BS-2224
	@Test(priority = 2)
	public void Verify_Unmarked_Project_Are_Displayed_In_Favorite_Table_Facet_Link_Updates() {
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.ProjectPage.SearchForProject(ProjectISBNNO);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ProjectISBNNO);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.VerifyProjectIsAddedAsFavorite(ProjectISBNNO);
		test.HomePage.VerifyCountOfFavoriteProject(2);

		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.VerifyCountOfFavoriteProject(1);

		test.HomePage.RemoveProjectFromFavorite(ProjectISBNNO);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ProjectISBNNO);
		test.HomePage.VerifyCountOfFavoriteProject(0);
	}

	// 2.Verify that the unmarked Project disappears from the favorite table if
	// user refreshes the page, or navigate back to the Dashboard from any other
	// page.
	// BS-2224
	@Test(priority = 3)
	public void Verify_Unmarked_Project_Disappears_From_The_Favorite_Table_If_User_Refreshes_Page() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.VerifyProjectIsRemovedFromFavorite(ISBN);

		test.HomePage.clickProjectTab(); /////////// ------>When User Navigates
											/////////// to other Page...
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.clickProjectTab();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsRemovedFromFavorite(ISBN);
	}

	// 3.Verify that the recently unmarked project remains in the Favorite table
	// even if user changes the view from List to Grid or vice versa. Same is
	// the case with Show All/ Show Less button (i.e. Unfavorite project will
	// keep on displaying until and unless user refreshes the page)
	// BS-2224
	@Test(priority = 4)
	public void Verify_Recently_Unmarked_Project_Remains_In_Favorite_Table_Even_If_User_Changes_View_Or_Click_Show_All() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectsToFavorite("8");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.clickShowLessButton();
		test.HomePage.clickShowAllButton();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.clickGridView();
		test.HomePage.VerifyProjectIsAddedAsFavoriteInGridView(projectTitle);
	}

	// 4.Verify that now with the implementation of this feature, user can mark
	// the Project as Favorite if marked UnFavorite accidentally/mistakenly.
	// BS-2224
	@Test(priority = 5)
	public void Verify_User_Can_Mark_The_Project_As_Favorite_If_Marked_UnFavorite_Accidentally() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
	}

	// 5.Verify that the Project that is marked as Favorite at last will appear
	// on the top of the table after refreshing the page.
	// BS-2224
	@Test(priority = 6)
	public void Verify_The_Project_Marked_Favorite_At_Last_Will_Appear_On_The_Top_Of_The_Table() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.AddProjectsToFavorite("3");
		test.ProjectPage.SearchForProject(ProjectISBNNO);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ProjectISBNNO);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectDisplayedInTopOfTable(ProjectISBNNO);
	}

	// 6.Verify default message appears if user unFavorites all and refreshes
	// the page
	// BS-2224
	@Test(priority = 7)
	public void Verify_Default_Message_Appears_If_User_UnFavorites_All_Project() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.AddProjectsToFavorite("4");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.VerifyMessageForNoFavoriteProjectsIsDisplayed();
	}

	// 7."Verify for Advanced Search> Download Content functionality for
	// following cases: a) Single CMS Asset: No Toaster message is displayed and
	// download is started."
	// BS-BS-2529
	@Test(priority = 8)
	public void Verify_For_Advanced_Search_When_Downloading_Single_CMS_Asset_No_Toaster_Message_And_Download_Is_Started()
			throws IOException {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentCoverDesign);
		test.SearchPage.EnterTextIntoSearchBox(ISBN + "_FC.jpg");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectAssetOnSearchPage(ISBN + "_FC.jpg");
		test.SearchPage.clickDownloadContent();
		test.Contentpage.VerifyMessageNotDisplayedOnDownloadingContent();
		test.SearchPage.VerifyDownloadIsStartedFromAdvanceSearch(ISBN + "_FC.jpg");
	}

	// 8."Verify for Advanced Search> Download Content functionality for
	// following cases: b) Single Non CMS Asset/ multiple CMS Asset/ multiple
	// non-CMS asset: Toaster message is displayed and download link is
	// received."
	// BS-BS-2529
	@Test(priority = 9)
	public void Verify_For_Advanced_Search_Download_Message_Is_Displayed_For_Single_Multiple_Non_CMS_Asset()
			throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear(); ///// ------Single Non CMS
													///// Content
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeRepository);
		test.SearchPage.SelectContentTypeInNewAddedField("DAM");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectContents(1);
		test.SearchPage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsgAdv, "");
		test.refreshPage();

		test.HomePage.waitForLoaderToDisappear(); ///// ------Multiple Non CMS
													///// Content
		test.SearchPage.SelectContents(2);
		test.SearchPage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsgAdv, "");

		test.refreshPage(); ///// -------Multiple CMS Content.
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeRepository);
		test.SearchPage.SelectContentTypeInNewAddedField("CMS");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectContents(2);
		test.SearchPage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsgAdv, "");
	}

	// 9."Verify that new Content type 'Marketing Content>Author Image' has been
	// in the following locations: 1. Upload content pop-up 2. Upload content
	// pop-up in Project view 3. Advanced Search Content type list"
	// BS-2394
	@Test(priority = 10)
	public void Verify_Content_Type_Marketing_Content_Author_Image_In_Upload_Functionality() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingAuthorImage);
		test.HomePage.clickXButtonUploadContent();

		test.HomePage.clickProjectTab();
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectContentTypeInUploadContentPopup(TypeOfContentMarketingAuthorImage);
		test.projectView.clickXButtonUploadContent();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
	}

	// 10."Verify that only the new Content type 'Marketing Content>Author
	// Image' is displayed in the Content Type list for DMS user in the
	// following locations:
	// 1. Upload content pop-up
	// 2. Upload content pop-up in Project view
	// 3. Advanced Search Content type list"
	// BS-2557
	@Test(priority = 11)
	public void Verify_Only_Marketing_Content_Author_Image_Displayed_In_Upload_For_DMS_User() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(DMS_Email);
		test.loginpage.enterUserPassword(DMS_Password);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.VerifyContentTypeNotDisplayedInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.VerifyContentTypeNotDisplayedInUploadContentPopUp(TypeOfContentCoverDesign);
		test.HomePage.VerifyContentTypeNotDisplayedInUploadContentPopUp(TypesOfContentFlatEpub);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingAuthorImage);
		test.HomePage.clickXButtonUploadContent();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.VerifyContentTypeNotDisplayedInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.projectView.VerifyContentTypeNotDisplayedInUploadContentPopUp(TypeOfContentCoverDesign);
		test.projectView.VerifyContentTypeNotDisplayedInUploadContentPopUp(TypesOfContentFlatEpub);
		test.projectView.SelectContentTypeInUploadContentPopup(TypeOfContentMarketingAuthorImage);
		test.projectView.clickXButtonUploadContent();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.EnterTextIntoSearchBox(MarketingAuthorImage);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.VerifyElementNotDisplayedAddedField("1", TypesOfContentEnhancedEpub);
		test.SearchPage.VerifyElementNotDisplayedAddedField("1", TypeOfContentCoverDesign);
		test.SearchPage.VerifyElementNotDisplayedAddedField("1", TypesOfContentFlatEpub);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
	}

	// 11."Verify that as soon as user selects the Author Image content type
	// from the list, following fields are displayed in the upload window:
	// 1) Browse (Mandatory)
	// 2) Content Type (Mandatory)
	// 3) Author Name search field (Mandatory)
	// 4) Title (Optional)
	// 5) Description (Optional)
	// 6) Upload Button"
	// BS-2557
	@Test(priority = 12)
	public void Verify_Mandatory_And_Optional_Field_For_Author_Image_Content_Type() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingAuthorImage);
		test.HomePage.VerifyBrowseButtonIsMandatory();
		test.HomePage.VerifyContentTypeIsIsMandatory();
		test.HomePage.VerifyAuthorNameIsMandatory();
		test.HomePage.VerifyTitleIsOptional();
		test.HomePage.VerifyDescriptionIsOptional();
		test.HomePage.VerifyUploadButtonOnUploadPopup();
	}

	// 12.Verify that Background text for Author name field is Search for Author
	// Name with a Search Icon to the right most
	// BS-2557
	@Test(priority = 13)
	public void Verify_Background_Text_For_Author_Name_Field() {
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.VerifyAuthorFieldsBackground();
	}

	// 13.Verify that Search icon changes to cross icon as soon as user types in
	// BS-2557
	@Test(priority = 14)
	public void Verify_Search_Icon_Changes_To_Cross_Icon_As_User_Types() {
		test.HomePage.VerifySearchIconOnAuthorField();
		test.HomePage.EnterTextInAuthorField("Sandeep", true);
		test.HomePage.VerifyRemoveIconOnAuthorField();
	}

	// 14.Verify that Search results for Author name are getting displayed as
	// soon as user types in the 3rd letter
	// BS-2557
	@Test(priority = 15)
	public void Verify_Search_Results_For_Author_Name_Are_Displayed() {
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.EnterTextInAuthorField("Sa", false);
		test.HomePage.VerifySuggestionForAuthorName_NotDisplayedInUploadContent();
		test.HomePage.EnterTextInAuthorField("San", false);
		test.HomePage.VerifySuggestionforAuthorNameDisplayedInUploadContent();

	}

	// 15.Verify that Title value will be automatically filled with the Author
	// Name user selects in this asset upload modal as soon as users selects the
	// Author Name from the Author Name field.
	// BS-2557
	@Test(priority = 16)
	public void Verify_Title_Value_Is_Automatically_Filled_With_Author_Name() {
		test.HomePage.EnterTextInAuthorField(AuthorName, true);
		test.HomePage.VerifySuggestionforAuthorNameDisplayedInUploadContent();
		test.HomePage.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.HomePage.VerifyAuthorNameInTitleField(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
	}

	// 16.Verify that User can edit the Title value/ Description to his own.
	// BS-2557
	@Test(priority = 17)
	public void Verify_User_Can_Edit_Title_And_Description() {
		test.HomePage.EnterTextIntoTitleField("Automation Edited Title " + AuthorName);
		test.HomePage.EnterTextIntoDescriptionField("Edited Descrition Field from Automation");
		test.HomePage.clickXButtonUploadContent();
	}

	// 17.Verify that Upload button is disabled until all the mandatory fields
	// are filled
	// BS-2557
	@Test(priority = 18)
	public void Verify_Upload_Button_Is_Disabled_Until_All_Mandatory_Fields_Are_Filled() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.VerifyUploadButtonIsDisabled();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingAuthorImage);
		test.HomePage.VerifyUploadButtonIsDisabled();
		test.HomePage.SelectImageFileUsingBrowseButton(ISBN);
		test.HomePage.VerifyUploadButtonIsDisabled();
		test.HomePage.EnterTextInAuthorField(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId), true);
		test.HomePage.VerifySuggestionforAuthorNameDisplayedInUploadContent();
		test.HomePage.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.HomePage.EnterTextIntoTitleField(AuthorSampleImage);
		test.HomePage.VerifyUploadButtonIsEnabled();

	}

	// 18.Verify that user is able to upload the Author Image successfully when
	// all the mandatory fields are filled and user clicks on the Upload button
	// BS-2557
	@Test(priority = 19)
	public void Verify_User_Is_Able_To_Upload_The_Author_Image_Successfully() {
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.ClickCloseOnpublishPopup();
	}

	// 19.Verify that Image file name has been updated as AuthorKey.jpg/ .png
	// BS-2557
	@Test(priority = 20)
	public void Verify_Image_File_Name_Updated_As_AuthorKey_jpg() {
		test.ContentView.VerifyFileNameIsAuthorKey(AuthorId);
	}

	// 20.Delete the Uploaded Marketing Content Author Image
	@Test(priority = 21)
	public void Delete_The_Uploaded_Content() {
		test.ContentView.VerifyOnContentViewPage();
		// test.ContentView.DeleteContentFromCMS(); /// Delete the Uploaded
		// content...
	}

	// DeleteTheUploadedContent===>
	@Test(priority = 22)
	public void DeleteTheUploaded_Marketing_Content_Author_Image() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AuthorSampleImage);
		test.Contentpage.SelectContentOnContentTab(AuthorSampleImage,TypeOfContentMarketingAuthorImage);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		test.Contentpage.VerifySuccessMessageOnDeleteingTheContent();
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
	}

	// 21.Verify that CMS user can select the Marketing Content>Sample Chapter
	// as the Content type in the 'Dashboard> Upload Content' pop-up window.
	// BS-2405
	@Test(priority = 23)
	public void Verify_That_CMS_User_Can_Select_Marketing_Content_Sample_Chapter_In_DashBoardUploadContent() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectImageFileUsingBrowseButton(ISBN);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingSampleChapter);
		test.HomePage.clickXButtonUploadContent();
	}

	// 22.Verify that CMS user can select the Marketing Content>Sample Chapter
	// as the Content type in the 'Project view> Upload Content' pop-up window.
	// BS-2405
	@Test(priority = 24)
	public void Verify_That_CMS_User_Can_Select_Marketing_Content_Sample_Chapter_In_ProjectViewUploadContent() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectContentTypeInUploadContentPopup(TypeOfContentMarketingSampleChapter);
		test.projectView.SelectImageFileUsingBrowseButton(ISBN);
		test.projectView.EnterTextIntoTitleField("Automation Uploaded Title..");
		test.projectView.ClickUploadOnUploadContentPopUpAndVerifyMsg();
	}

	// 23.Verified that Sample chapter uploaded via Project view is
	// automatically gets attached to the default Project
	// BS-2405
	@Test(priority = 25)
	public void Verify_Sample_Chapter_Uploaded_Via_ProjectView_Automatically_Associate() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 24."Verify that following fields are getting displayed in the Upload
	// Content pop-up window as soon as user selects the Marketing
	// Content>Sample Chapter in the Content Type field:
	// a) Select file (Browse)
	// b) Content Type
	// c) Title
	// d) Description
	// e) Upload button"
	// BS-2405
	@Test(priority = 26)
	public void Verify_All_The_Field_For_Sample_Chapter_In_Upload_Content_PopUp() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingSampleChapter);
		test.HomePage.VerifyBrowseButton();
		test.HomePage.VerifyContentTypeInUploadContentPopup();
		test.HomePage.VerifyTitleInUploadContentPopup();
		test.HomePage.VerifyDescriptionInUploadContentPopUp();
		test.HomePage.VerifyUploadButton();
	}

	// 25.Verify that Select file, Content Type and Title fields are mandatory
	// and thus tagged with red asterisk mark, also, Description field is
	// optional
	// BS-2405
	@Test(priority = 27)
	public void Verify_Mandatory_And_Optional_Field_For_Sample_Chapter_Content_Type() {
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.VerifyBrowseButtonIsMandatory();
		test.HomePage.VerifyContentTypeIsIsMandatory();
		test.HomePage.VerifyTitleIsMandatory();
		test.HomePage.VerifyDescriptionIsOptional();
		test.HomePage.VerifyUploadButtonOnUploadPopup();
	}

	// 26.Verify that Upload button is disabled until all the mandatory fields
	// are filled
	// BS-2405
	@Test(priority = 28)
	public void Verify_Upload_Button_Disabled_Until_All_The_Mandatory_Fields_Are_Filled() {
		test.HomePage.VerifyUploadButtonIsDisabled();
		test.HomePage.SelectImageFileUsingBrowseButton(ISBN);
		test.HomePage.VerifyUploadButtonIsDisabled();
	}

	// 27.Verify that Upload button gets activated once all the madatory fields
	// are filled
	// BS-2405
	@Test(priority = 29)
	public void Verify_Upload_Button_Activates_Once_Madatory_Fields_Are_Filled() {
		test.HomePage.EnterTextIntoTitleField(MarketingSampleChapterName);
		test.HomePage.VerifyUploadButtonIsEnabled();
	}

	// 28.Verify that user is successfully able to upload the Sample Chapter and
	// navigates to Content view page on clicking Upload button
	// BS-2405
	@Test(priority = 30)
	public void Verify_User_Successfully_Uploads_Sample_Chapter_And_Navigates_To_ContentView() {
		test.HomePage.clickUploadButton();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
	}

	// 29.Verify that user is able to edit the Asset's Title and Description
	// from Content page view after the Upload action
	// BS-2405
	@Test(priority = 31)
	public void Verify_User_Is_Able_To_Edit_Asset_Title_Description_From_ContentView() throws IOException {
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle();
		test.ContentView.EditAssetDetail();
		test.ContentView.VerifyTitleIsEdited();
		test.ContentView.VerifyDetailUpdated();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(MarketingSampleChapterName);
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited(MarketingSampleChapterName);
	}

	// 30."Verify that user is able to Publish the Sample Chapter to following
	// locations via Content view page:Palgrave, CoreSource, Instructor Store,
	// VS"
	// BS-2405
	@Test(priority = 32)
	public void Verify_User_Is_Able_To_Publish_The_Sample_Chapter_To_Various_Destination_ContentView() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore); // Publish
																						// to
																						// Instructor
																						// Store.
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ProjectISBNNO);
		test.ContentView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ProjectISBNNO);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(ProjectISBNNO);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource); // Publish
																					// to
																					// Core
																					// Source.
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave); // Publish
																				// to
																				// Palgrave.
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource); // Publish
																					// to
																					// Vital
																					// source.
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 31."Verify that user is able to Publish the Sample Chapter to following
	// locations via Project view page: Palgrave, CoreSource, Instructor Store,
	// VS, Courseware"
	@Test(priority = 33)
	public void Verify_User_Is_Able_To_Publish_The_Sample_Chapter_To_Various_Destination_ProjectView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView
				.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentMarketingSampleChapter,MarketingSampleChapter,true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView
		.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentMarketingSampleChapter,MarketingSampleChapter,true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView
		.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentMarketingSampleChapter,MarketingSampleChapter,true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView
		.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentMarketingSampleChapter,MarketingSampleChapter,true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 32."Verify that list of Author names with their Author keys is getting
	// displayed while searching for 'Author Name' in:
	// a) Dashboard> Upload Content pop-up window"
	// BS-2357
	@Test(priority = 34)
	public void Verify_Author_Names_And_Authorkeys_Is_Getting_Displayed_Dashboard_UploadContent() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingAuthorImage);
		test.HomePage.EnterTextInAuthorField(AuthorName.substring(0, AuthorName.indexOf(" ")), true);
		test.HomePage.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.HomePage.VerifyAuthorNameInTitleField(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.HomePage.clickXButtonUploadContent();
	}

	// 33."Verify that list of Author names with their Author keys is getting
	// displayed while searching for 'Author Name' in:
	// b) Project View> Upload Content pop-up window"
	// BS-2357
	@Test(priority = 35)
	public void Verify_Author_Names_And_Authorkeys_Is_Getting_Displayed_Dashboard_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectContentTypeInUploadContentPopup(TypeOfContentMarketingAuthorImage);
		test.projectView.EnterTextInAuthorField(AuthorName);
		test.projectView.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.projectView.VerifyAuthorNameInTitleField(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.projectView.clickXButtonUploadContent();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}