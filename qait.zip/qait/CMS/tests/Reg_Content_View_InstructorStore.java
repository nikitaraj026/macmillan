package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Content_View_InstructorStore extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String NonAdminEmail, NonAdminPassword, ISBN, ISBN1, PublihDestinationCoreSource, PublihDestinationPalgrave,
			PublihDestinationVitalSource;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, DamContent,
			PublihDestinationInstructorStore;
	String ProjectTitle1, DMS_Email, DMS_Password, TypeOfContentMarketingAuthorImage,
			TypeOfContentMarketingSampleChapter;
	String LookForAsset, LookForProject, AdvSearchTypeContentType, DMSPublishErrorProjectView, MarketingSampleChapter;
	String MarketingAuthorImage, AuthorId, DMSPublishErrorContentView, AdvSearchTypeProjectType;
	String ProjectTypeAncillaryManufacturedAndOnline, ProjectTypeAncillaryOnlineOnly, ProjectTypeAncillaryLectureSlides;
	String ProjectTypeAncillaryPrintedTestBank, ProjectTypeAncillaryTestBank, ProjectTypeAncillaryAccessCard,
			ProjectTypeEnhancedePub;
	String ProjectTypeOther, ProjectTypePDFebook, ProjectTypePrint, ProjectTypeDistributableEPub,
			ProjectTypeOnlineCourseAchieve;
	String ProjectTypeOnlineCourseIntellusOpenCourse, ProjectTypeOnlineCourseInternetOnline,
			ProjectTypeOnlineCourseLaunchPadFull;
	String ProjectTypeOnlineCourseLaunchPadSolo, ProjectTypeOnlineCourseReadandPractice,
			ProjectTypeOnlineCourseSaplingHomeworkStandalone;
	String ProjectTypeOnlineCourseSaplingHomework_w_ebook, ProjectTypeOnlineCourseSaplingPlusE_BookOnly,
			ProjectTypeOnlineCourseSaplingPlusHomeworkOnly;
	String NoAssertToPublishMessage, NoAssetSelected, InstructorStoreNoISBN, TypesOfContentEnhancedEpub,
			TypesOfContentFlatEpub;
	String PageSelectionAllPage, AuthorName, TypesOfContentInstructorResourcese;
	String TypesOfContentStudentResources, TypeOfContentCourseManagement, TypeOfContentCoverDesign;
	String CMSRepository;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		AuthorId = getData("Author.id");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		TypeOfContentMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DamContent = getData("DamContent");
		MarketingSampleChapter = getData("MarketingSampleChapter");
		ProjectTitle1 = getData("ProjectTitle1");
		DMS_Email = getData("DMSUser.email");
		DMS_Password = getData("DMSUser.password");
		LookForAsset = getData("LookFor.Assets");
		LookForProject = getData("LookFor.project");
		AdvSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		AdvSearchTypeProjectType = getData("SearchTypeAdvanceSearch.Project Type");
		DMSPublishErrorProjectView = getData("DMSPublishErrorProjectView");
		MarketingAuthorImage = getData("MarketingAuthorImage");
		DMSPublishErrorContentView = getData("DMSPublishErrorContentView");
		ProjectTypeAncillaryManufacturedAndOnline = getData("ProjectType.Ancillary/IRM (Manufactured and Online)");
		ProjectTypeAncillaryOnlineOnly = getData("ProjectType.Ancillary/IRM (Online Only)");
		ProjectTypeAncillaryLectureSlides = getData("ProjectType.Ancillary/Lecture Slides");
		ProjectTypeAncillaryPrintedTestBank = getData("ProjectType.Ancillary/Printed Test Bank");
		ProjectTypeAncillaryTestBank = getData("ProjectType.Ancillary/Test Bank");
		ProjectTypeAncillaryAccessCard = getData("ProjectType.AncillaryAccess Card");
		ProjectTypeEnhancedePub = getData("ProjectType.Enhanced ePub");
		ProjectTypeOther = getData("ProjectType.Other");
		ProjectTypePDFebook = getData("ProjectType.PDF ebook");
		ProjectTypePrint = getData("ProjectType.Print");
		ProjectTypeDistributableEPub = getData("ProjectType.Distributable ePub");
		ProjectTypeOnlineCourseAchieve = getData("ProjectType.Online Course/Achieve");
		ProjectTypeOnlineCourseIntellusOpenCourse = getData("ProjectType.Online Course/Intellus Open Course");
		ProjectTypeOnlineCourseInternetOnline = getData("ProjectType.Online Course/Internet (Online)");
		ProjectTypeOnlineCourseLaunchPadFull = getData("ProjectType.Online Course/LaunchPad Full");
		ProjectTypeOnlineCourseLaunchPadSolo = getData("ProjectType.Online Course/LaunchPad Solo");
		ProjectTypeOnlineCourseReadandPractice = getData("ProjectType.Online Course/Read and Practice");
		ProjectTypeOnlineCourseSaplingHomeworkStandalone = getData(
				"ProjectType.Online Course/Sapling Homework (standalone)");
		ProjectTypeOnlineCourseSaplingHomework_w_ebook = getData("ProjectType.Online Course/Sapling Homework w/ ebook");
		ProjectTypeOnlineCourseSaplingPlusE_BookOnly = getData("ProjectType.Online Course/Sapling Plus e-Book Only");
		ProjectTypeOnlineCourseSaplingPlusHomeworkOnly = getData(
				"ProjectType.Online Course/Sapling Plus Homework Only");
		NoAssertToPublishMessage = getData("InstructorStoreNoAsset");
		NoAssetSelected = getData("InstructorStoreNoAssetSelected");
		InstructorStoreNoISBN = getData("InstructorStoreNoISBN");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		PageSelectionAllPage = getData("PageSelection.All Pages");
		AuthorName = getData("Author.Name");
		TypesOfContentInstructorResourcese = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		TypesOfContentStudentResources = getData("TypesOfContent.Supplementary Content>Student Resources");
		TypeOfContentCourseManagement = getData("TypesOfContent.Supplementary Content>Course Management");
		TypeOfContentCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		CMSRepository = getData("Repository.CMS");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1."B) Content View Verify that Publish table for Content view is
	// displaying with following column headers:
	// 1) User
	// 2) Destination
	// 3) Published Date
	// 4) Published Project ISBN
	// 5) Publish Status"
	// BS-2478
	@Test(priority = 2)
	public void Verify_Publish_Table_Column_Headers_For_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(MarketingAuthorImage);
		test.Contentpage.opentheSearchContent(MarketingAuthorImage);
		test.Contentpage.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyHeaderOfPublishTab();
	}

	// 2."B) Content View Verify that appropriate User, Destination, Published
	// Date, Publish Status is getting displayed for each individual Publish
	// operation"
	// BS-2478
	@Test(priority = 3)
	public void Verify_Appropriate_Publish_Information_Is_Displayed() {
		test.ContentView.VerifyPublishDetailsAreDisplayed();
	}

	// 3."B) Content View Verify that when asset is published via Content view
	// page, then Published Project ISBN field will be displayed as Blank"
	// BS-2478
	@Test(priority = 4)
	public void Verify_If_Asset_Published_Via_Content_View_Then_ISBN_Field_Is_Blank() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyISBN_Not_Displayed_On_PublishDetail();
	}

	// 4."B) Content View Verify that when asset is published via Project view
	// page, then 'Publish Destinations' link is getting displayed under
	// Published Project ISBN column, on clicking the same, user is displayed
	// with all the ISBNs from which that asset was published at that moment."
	// BS-2478
	@Test(priority = 5)
	public void Verify_When_Asset_Is_Published_Via_ProjectView_Then_ISBN_Displayed_In_PublishDestinations_Link() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingAuthorImage,
				MarketingAuthorImage, true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(MarketingAuthorImage);
		test.Contentpage.opentheSearchContent(MarketingAuthorImage);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyPublishWasOnCorrectDestinationAndISBN(PublihDestinationInstructorStore, ISBN);
	}

	// 5."B) Content View Verify that on clicking the 'Publish Destinations'
	// link, Modal pop up containing details of published ISBNs gets open as
	// follows:
	// 1) ISBN
	// 2) ISBN-10
	// 3) Author
	// 4) Title
	// 5) Edition
	// 6) Copyright Year"
	// BS-2478
	@Test(priority = 6)
	public void Verify_Published_Project_ISBN_Coloum_Header() {
		test.ContentView.VerifyPublishProjectISBN_Header();
		test.ContentView.ClickX_OnWindow();
	}

	// 6.Verify that User is successfully able to Push the ePubs/ other type
	// assets to Frost application via Push to Authoring tool window available
	// in Project view.
	// BS-2512
	@Test(priority = 7)
	public void Verify_User_Successfully_Able_To_Push_ePubs_Other_Assets_To_Frost_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectEnhancedEpubOnAuthoringToolAndPush(ISBN1, ISBN1);

		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectFcOnAuthoringToolAndPush(ISBN1);

	}

	// 7.Verify that User is successfully able to Push the ePubs/ other type
	// assets to Frost application via Push to Authoring tool window available
	// in Content view.
	// BS-2512
	@Test(priority = 8)
	public void Verify_User_Successfully_Able_To_Push_ePubs_Other_Assets_To_Frost_ContentView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1 + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN1 + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.UploadContentToFrost(ISBN1);

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1 + "_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN1 + "_FC.jpg");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.UploadContentToFrost(ISBN1);
	}

	// 8.Verify that Project is getting created at Frost end successfully.
	// BS-2512
	@Test(priority = 9)
	public void Verify_Project_Is_Created_At_Frost_End() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ISBN1, ProjectTitle1);
		test.projectView.LogoutFromFrost();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 9."Verify that for a DMS user, only the following content types are
	// available in Dashboard> Upload Content window:
	// 1) Marketing Content>Author Image
	// 2) Marketing Content>Sample Chapter"
	// BS-2665
	@Test(priority = 10)
	public void Verify_DMS_User_can_Only_See_Marketing_Content_AuthorImage_And_Sample_Chapter_In_UploadContent_DashBoard() {
		test.projectView.changeWindow(0);
		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(DMS_Email);
		test.loginpage.enterUserPassword(DMS_Password);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingAuthorImage);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingSampleChapter);
		test.HomePage.VerifyCountOfContentTypesDisplayedInUploadContentWindow(3);
		test.HomePage.clickXButtonUploadContent();
	}

	// 10."Verify that for a DMS user, only the following content types are
	// available in Project view> Upload Content window:
	// 1) Marketing Content>Author Image
	// 2) Marketing Content>Sample Chapter"
	// BS-2665
	@Test(priority = 11)
	public void Verify_DMS_User_can_Only_See_Marketing_Content_AuthorImage_And_Sample_Chapter_In_UploadContent_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectContentTypeInUploadContentPopup(TypeOfContentMarketingAuthorImage);
		test.projectView.SelectContentTypeInUploadContentPopup(TypeOfContentMarketingSampleChapter);
		test.HomePage.VerifyCountOfContentTypesDisplayedInUploadContentWindow(3);
		test.HomePage.clickXButtonUploadContent();
	}

	// 11."Verify that for a DMS user, only the following content types are
	// available in Advanced Search> Content type dropdown for 'Assets' and
	// 'Assets and Projects':
	// 1) Marketing Content>Author Image
	// 2) Marketing Content>Sample Chapter"
	// BS-2665
	@Test(priority = 12)
	public void Verify_DMS_User_can_Only_See_Marketing_Content_AuthorImage_And_Sample_Chapter_In_AdvancedSearch() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingSampleChapter);
		test.SearchPage.VerifyCountOfAvailableOptionsInAddedField("1", 2);
	}

	// 12."Project View: Verify that following error message is getting
	// displayed in the publish window if DMS user tries to publish ANY asset to
	// ANY destination OTHER THAN Author Image or Sample Chapter from Project
	// view: You do not have permission to publish this project"
	// BS-2665
	@Test(priority = 13)
	public void Verify_Error_Message_If_DMS_User_Tries_To_publish_Any_NonMarketingContent_ProjectView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentCoverDesign,
				ISBN + "_FC.jpg", true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN + "_FC.jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorProjectView);
		test.projectView.refreshPage();
		test.HomePage.waitForLoaderToDisappear();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN + "_EPUB.epub", true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorProjectView);
		test.projectView.refreshPage();
		test.HomePage.waitForLoaderToDisappear();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN + "_EPUB.epub", true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorProjectView);
		test.projectView.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
	}

	// 13."Project View: Verify that user is successfully able to Publish assets
	// of following content type:
	// 1) Marketing Content>Author Image
	// 2) Marketing Content>Sample Chapter"
	// BS-2665
	@Test(priority = 14)
	public void Verify_DMS_User_Is_Able_To_Publish_Marketing_Content_AuthorImage_And_SampleChapter() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter, true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter, true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingAuthorImage,
				MarketingAuthorImage, true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 14."Content view: Verify that following error message appears when DMS
	// user tries to publish an asset of ANY content type except Marketing
	// Content>Author Image/ Sample Chapter to any destination: You do not have
	// permission to publish this asset"
	// BS-2665
	@Test(priority = 15)
	public void Verify_Error_Message_Appears_When_DMS_User_Tries_To_Publish_Asset_Other_Than_Marketing_Content_From_ContentView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN1 + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN1 + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorContentView);
		test.ContentView.ClickX_OnWindow(); // Close Publish Window

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN1 + "_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN1 + "_FC.jpg");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorContentView);
		test.ContentView.ClickX_OnWindow(); // Close Publish Window
	}

	// 15.Content view: Verify that DMS user is successfully able to publish the
	// asset of Marketing Content>Author Image content type from Content page
	// view to any destination
	// BS-2665
	@Test(priority = 16)
	public void Verify_DMS_User_Is_Successfully_Able_To_Publish_The_MarketingContent_Asset() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(MarketingAuthorImage);
		test.Contentpage.opentheSearchContent(MarketingAuthorImage);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(MarketingSampleChapter);
		test.Contentpage.opentheSearchContent(MarketingSampleChapter);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 16.Verify that error message is displayed if user hits the Publish button
	// without approving the asset
	// BS-2665
	@Test(priority = 17)
	public void Verify_Error_Message_For_Publishing_UnApprove_Asset() {
		test.refreshPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsNotPublished();
	}

	// 17."Verify that for following Project types in CMS, Publish destination
	// should display the Instructor Store destination as selected by default
	// and not changeable [Disabled]:
	// 1) Ancillary/IRM (Manufactured and Online)
	// 2) Ancillary/IRM (Online Only)
	// 3) Ancillary/Lecture Slides
	// 4) Ancillary/Printed Test Bank
	// 5) Ancillary/Test Bank
	// 6) AncillaryAccess Card
	// 7) Other
	// 8) PDF ebook
	// 9) Print"
	// BS-2603
	@Test(priority = 18)
	public void Verify_Instructor_Store_Destination_Selected_By_Default_And_Not_Changeable_For_Projects() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeProjectType);
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeAncillaryManufacturedAndOnline);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeAncillaryOnlineOnly);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeAncillaryLectureSlides);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();

		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeProjectType);
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeAncillaryPrintedTestBank);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeAncillaryTestBank);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeAncillaryAccessCard);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypePDFebook);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypePrint);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyPublishDestinationOnPublishPopIsDisabled();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 18."Verify that for following Project types in CMS, Publish destination
	// should display the Instructor Store destination as selected by default
	// and is changeable [Enabled]:
	// 1) Distributable ePub
	// 2) Online Course/Achieve
	// 3) Online Course/Intellus Open Course
	// 4) Online Course/Internet (Online)
	// 5) Online Course/LaunchPad Full
	// 6) Online Course/LaunchPad Solo
	// 7) Online Course/Read and Practice
	// 8) Online Course/Sapling Homework (standalone)
	// 9) Online Course/Sapling Homework w/ ebook
	// 10) Online Course/Sapling Plus e-Book Only
	// 11) Online Course/Sapling Plus Homework Only"
	// BS-2603
	@Test(priority = 19)
	public void Verify_Instructor_Store_Destination_Selected_By_Default_And_is_Changeable_For_Projects() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeProjectType);
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeDistributableEPub);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseAchieve);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseIntellusOpenCourse);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseInternetOnline);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeProjectType);
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseInternetOnline);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseLaunchPadFull);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseLaunchPadSolo);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseReadandPractice);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseSaplingHomeworkStandalone);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeProjectType);
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseSaplingHomework_w_ebook);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseSaplingPlusE_BookOnly);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeOnlineCourseSaplingPlusHomeworkOnly);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationCoreSource);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 19."Verify that following message displays when no asset is associated to
	// Project and user opens the Publish window: No content associated with
	// this project to publish"
	// BS-2603
	@Test(priority = 20)
	public void Verify_Error_Message_Display_If_No_Asset_Is_Associated_To_Project() {
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN("9897989798061");
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyErrorMessageOnBottomOfPublishWindow(NoAssertToPublishMessage);
	}

	// 20."Verify that following message displays when assets are associated to
	// the project but not selected from Step 2: Please select at least one
	// asset to publish"
	// BS-2603
	@Test(priority = 21)
	public void Verify_Error_Message_Display_If_No_Asset_Selected_In_Step2() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyErrorMessageOnBottomOfPublishWindow(NoAssetSelected);
	}

	// 21."Verify that following message displays when the default ISBN is
	// deleted and no ISBN is available in Step 1 provided that assets are
	// associated to that project: There are no ISBNs selected to Publish"
	// BS-2603
	@Test(priority = 22)
	public void Verify_Error_Message_Display_If_No_ISBN_Available_In_Step_1() {
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN);
		test.projectView.VerifyErrorMessageOnBottomOfPublishWindow(InstructorStoreNoISBN);
	}

	// 22.Verify that User is able to publish associated asset(s) to Default
	// ISBN for projects
	// BS-2603
	@Test(priority = 23)
	public void Verify_User_Is_Able_To_Publish_Associated_Asset_To_Default_ISBN() {
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingAuthorImage,
				MarketingAuthorImage, true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter, true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPage);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 23.Verify that User is able to publish associated asset(s) to Additional
	// ISBN (deleting the default one) for projects
	// BS-2603
	@Test(priority = 24)
	public void Verify_User_Is_Able_To_Publish_Associated_Asset_To_ISBN_Other_Than_Default() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN1);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN1);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN1);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingAuthorImage,
				MarketingAuthorImage, true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter, true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPage);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 24.Verify that User is able to publish associated asset(s) to Default as well
	// as Additional ISBNs for projects
	// BS-2603
	@Test(priority = 25)
	public void Verify_User_Is_Able_To_Publish_Associated_Asset_To_Default_And_Other_ISBN() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN1);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN1);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN1);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingAuthorImage,
				MarketingAuthorImage, true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter, true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPage);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 25.Verify that Publish tab displays the published instance correctly for
	// projects
	// BS-2603
	@Test(priority = 26)
	public void Verify_Publish_Tab_Displays_The_published_Instance_Correctly() {
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationInstructorStore);
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN1);
		test.projectView.ClickCloseButton();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(MarketingAuthorImage);
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(MarketingSampleChapter);
		test.projectView.ClickCloseButton();
	}

	// 26."Project View: Verify that Published Project ISBN pop up in Publish
	// details tab displays the Published ISBN(s) details in user favorable time"
	// BS-2682
	@Test(priority = 27)
	public void Verify_Published_Project_ISBN_PopUp_Display_ISBN_In_User_Favorable_Time() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.HomePage.VerifyProjectTabIsDisplayed();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 27."Content view:Verify that Published Project ISBN pop up in Publish details
	// tab displays the Published ISBN(s) details in user favorable time"
	// BS-2682
	@Test(priority = 28)
	public void Verify_Published_Project_ISBN_PopUp_Display_ISBN_In_User_Favorable_Time_ContentView() {
		test.projectView.ClickOpenAssetOnProjectView(ISBN + ".epub", TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.ClickPublishDestinationOnPublishDetail();
		test.ContentView.VerifyISBNDisplayedInPublishProjectPopUpFavourableTime(ISBN);
	}

	// 28."Content view: Verify that Author Image with Author name along with Author
	// key is getting displayed for Marketing content> Author Image Content type
	// when the Publish destination is selected as Instructor Store"
	// BS-2639
	@Test(priority = 29)
	public void Verify_AuthorImage_And_AuthorName_Displayed_with_Authorkey() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(MarketingAuthorImage);
		test.Contentpage.opentheSearchContent(MarketingAuthorImage);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.VerifyAuthorImageInStep2PublishWindow();
		test.ContentView
				.VerifyAuthorNameAndIdInStep2PublishWindow(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
	}

	// 29."Content view: Verify that File name along with selected radio button is
	// getting displayed for Marketing content> Author Image Content type when the
	// Publish destination is selected other than Instructor Store"
	// BS-2639
	@Test(priority = 30)
	public void Verify_Selected_Radio_Button_FileName_For_AuthorImage_Publish_Destination_Other_Than_InstructorStore() {
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(AuthorId + ".jpg");
		test.ContentView.ClickX_OnWindow();
	}

	// 30."Content view: Verify that File name along with selected radio button is
	// getting displayed for all the rest content type assets for each publish
	// destinations"
	// BS-2639
	@Test(priority = 31)
	public void Verify_Selected_Radio_Button_FileName_For_AuthorImage_For_Other_Assets_PublishWindow() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + ".epub");

		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + ".epub");

		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + ".epub");

		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + ".epub");
		test.ContentView.ClickX_OnWindow();

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN + "_FC.jpg");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + "_FC.jpg");

		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + "_FC.jpg");

		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + "_FC.jpg");

		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
		test.ContentView.VerifyFileNameOnStep2PublishWindow(ISBN + "_FC.jpg");
		test.ContentView.ClickX_OnWindow();
	}

	// 31."Verify that following field labels are displaying in Content view page
	// for IR, SR or rest Content types except CM:
	// 1) Content Type
	// 2) Resource Type
	// 3) Title
	// 4) Description
	// 5) Default Access Level (Achieve)
	// 6) Subject Heading Taxonomy
	// 7) Subject Keyword Taxonomy
	// 8) Product Data
	// 9) Repository
	// 10) Rights Details (Lumina)"
	// BS-2390
	@Test(priority = 32)
	public void Verify_Various_Fields_Of_Content_Details_Tab_For_IR_SR_Resource() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentInstructorResourcese);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VariousFieldOfContentDetails(TypesOfContentInstructorResourcese);

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentStudentResources);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VariousFieldOfContentDetails(TypesOfContentStudentResources);
	}

	// 32."Verify that following field labels are displaying in Content view page
	// for CM resource:
	// 1) Content Type
	// 2) Resource Type
	// 3) Title
	// 4) Description
	// 5) Default Access Level (Achieve)
	// 6) Subject Heading Taxonomy
	// 7) Subject Keyword Taxonomy
	// 8) Product Data
	// 9) Repository
	// 10) Course Management Demo Link"
	// BS-2390
	@Test(priority = 33)
	public void Verify_Various_Fields_Of_Content_Details_Tab_For_CM_Resource() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentCourseManagement);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VariousFieldOfContentDetails(TypeOfContentCourseManagement);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
