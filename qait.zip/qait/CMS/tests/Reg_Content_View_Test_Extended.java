package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Content_View_Test_Extended extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String NonAdminEmail, NonAdminPassword, ISBN, ISBN1, PublihDestinationCoreSource, PublihDestinationPalgrave,
			PublihDestinationVitalSource;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, DamContent;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DamContent = getData("DamContent");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 61.Verify the lumina rights details for the asset (if any) appear in the
	// content tab
	@Test(priority = 2)
	public void Verify_Lumina_Rights_Details_For_The_Asset() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.VerifyLuminaRightsDetails("NA", "NA");
	}

	// 62.Verify that Content Contacts field and Add button is appearing on the
	// content Details tab
	@Test(priority = 3)
	public void Verify_Add_Button_Appearing_On_Content_Details_tab() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyAddEmailButton();
	}

	// 63.Verify that "Invalid email address" message is displayed if invalid email
	// address is enter in Content Contacts
	@Test(priority = 4)
	public void Verify_Message_Is_Displayed_If_Invalid_Email_Address_Is_Entered() {
		test.ContentView.VerifyMessageOnInvalidEmailAddress();
	}

	// 64.Verify that user is able to add valid Project contact (email id) and click
	// on the add button
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Add_Valid_Email_Adderss() {
		test.ContentView.AddEmailAddress(NonAdminEmail);
		test.ContentView.VerifyEmailIsAdded(NonAdminEmail);
	}

	// 65.Verify that added email is displayed under the table with two columns
	// Email Id and Action
	@Test(priority = 6)
	public void Verify_Email_Id_And_Action_Is_Displayed_In_Added_Email() {
		test.ContentView.VerifyTableHeader();
	}

	// 66.Verify that user can not add same email id twice
	@Test(priority = 7)
	public void Verify_User_Can_Not_Add_Same_Email_Id() {
		test.ContentView.AddEmailAddress(NonAdminEmail);
		test.ContentView.VerifyEmailExistErrorMSG();
	}

	// 67.Verify that user can successfully remove the added email
	@Test(priority = 8)
	public void Verify_User_Can_Successfully_Remove_Added_Email() {
		test.ContentView.RemoveAddedEmail(NonAdminEmail);
	}

	// 68.Verify that Clicking on the Publish Details tab Navigates To Publish
	// Details
	@Test(priority = 9)
	public void Verify_Clicking_Publish_Details_Navigates_To_Publish_Details() {
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyOnPublishDetailPage();
	}

	// 69."Verify that Publish details has the table with following details:
	// 1. User
	// 2. Destination
	// 3. Published Date
	// 4. ISBN
	// 5. Publish Status"
	@Test(priority = 10)
	public void Verify_Publish_Details_Tab_Has_Details() {
		test.ContentView.VerifyHeaderOfPublishTab();
	}

	// 70.Verify that Publish Details has Refresh link
	@Test(priority = 11)
	public void Verify_Publish_Details_Has_Refresh_Link() {
		test.ContentView.VerifyRefreshLink();
	}

	// 71.Verify that clicking on the refresh link refresh the Publish details
	@Test(priority = 12)
	public void Verify_Clicking_Refresh_Link_Refresh_Publish_Details() {
		test.ContentView.ClickRefreshLink();
	}

	// 72.Verify that clicking on the Version Details tab Navigates To Version
	// Details
	@Test(priority = 13)
	public void Verify_Clicking_Version_Details_Navigates_To_Version_Details() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickOnVersionDetail();
	}

	// 73."Verify that Version details as following button:
	// 1 .Upload a new version
	// 2. Download
	// 3. Approve
	// 4. Unapprove"
	@Test(priority = 14)
	public void Verify_Version_Details_Functionality() {
		test.ContentView.CheckVersionDetailFunctionality();
		// test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN+".epub");
	}

	// 74."Verify that Version details has table with following information:
	// 1. Version
	// 2. Status
	// 3.Published in ISBN
	// 4.Date Upload
	// 5.Upload by"
	@Test(priority = 15)
	public void Verify_Version_Detail_Tab_Has_Coloums() {
		test.ContentView.CheckForColoumsInVersionDetail();
	}

	// 75.Verify that clicking on the Upload a new version button open the pop up
	@Test(priority = 16)
	public void Verify_clicking_Upload_New_Version_Opens_PopUp() {
		test.ContentView.Verify_Upload_Functionality_On_Version_Detail();
	}

	// 76."Verify that upload a new version
	// pop up has following button
	// 1. Select files
	// 2. Finish
	// 3. Cancel button "
	@Test(priority = 17)
	public void Verify_Upload_New_Version_Has_Select_Finish_Cancel_Button() {
		test.ContentView.ClickUploadNewVersion();
		test.ContentView.VerifButtonsOnUploadVersion();
	}

	// 77.Verify that clicking on the select file button upload the file
	@Test(priority = 18)
	public void Verify_User_Able_To_Upload_New_version_Of_File() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN+"_FC.jpg");
		test.ContentView.ClickOnVersionDetail();
		test.ContentView.ClickUploadNewVersion();
		test.ContentView.UploadNewVersionOfContent(ISBN+"_FC.jpg");
	}

	// 78.Verify that after uploading file in popup and click on the finish button
	// uploads the file and closes the popup
	@Test(priority = 19)
	public void Verify_Uploading_File_PopUp_Is_Closed() {
		test.ContentView.VerifyUploadNewVersionPopUpClosed();
	}

	// 79.Verify that is incorrect file is select by clicking on the Select files
	// button this"File name does not match with the previous version!!" message
	// should display
	@Test(priority = 20)
	public void Verify_Error_Message_Displayed_When_Incorrect_File_Is_Selected() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.ClickOnVersionDetail();
		test.ContentView.ClickUploadNewVersion();
		test.ContentView.SelectIncorrectFileInUploadVersion(ISBN1);
		test.ContentView.VerifyErrorMessageOnUploadIncorrectFileNameOnVersionDetailTab();
	}

	// 80.Verify that uploaded files details is displayed in the Version details tab
	// with the previous file version detail
	@Test(priority = 21)
	public void Verify_Uploaded_Files_Details_Is_Displayed_In_Version_Details_Tab() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.ClickOnVersionDetail();
		test.ContentView.VerifyNewVersionOnVersionDetailsTab();
		test.ContentView.PrintTheInfoemationOfTheTable();

	}

	// 81.Verify that user is able to download the files from version details tab by
	// selecting single file and clicking on the download button
	@Test(priority = 22)
	public void Verify_User_Is_Able_To_Download_Files_From_Version_Details_Tab() {
		test.ContentView.verifyUserIsAbleToDownload();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN + "_FC.jpg");
	}

	// 82.Verify that clicking on the approve button changes the Status of selected
	// content to approve
	@Test(priority = 23)
	public void Verify_User_Approve_Button_Changes_Status_To_Approve() {
		test.ContentView.CheckApproveButtonFunctionality();
	}

	// 83.Verify that clicking on the Unapprove button changes the Status of
	// selected content to unapprove
	@Test(priority = 24)
	public void Verify_User_Uapprove_Button_Changes_Status_To_Uapprove() {
		test.ContentView.CheckUapproveButtonFunctionality();
	}

	// 84.Verify that clicking on the delete button opens the pop up with Delete
	// Content pop having intended text
	@Test(priority = 25)
	public void Verify_Clicking_On_The_Delete_Button_Opens_The_PopUp() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.ClickUploadContent();
		test.Contentpage.UploadContentFromContentPage(ISBN1);
		test.ContentView.ClickDelete();
		test.ContentView.VerifyDeletePopUp();
	}

	// 85.Verify that Confirm delete button is disabled till Delete is not entered
	// in the field above Confirm delete button
	@Test(priority = 26)
	public void Verify_Delete_Button_Is_Disabled_Till_Delete_Entered() {
		test.ContentView.VerifyDeletebuttonDisabled();
	}

	// 86.Verify that confirm delete button is activated as Delete keyword is
	// entered in the field
	@Test(priority = 27)
	public void Verify_Delete_Button_Activates_When_Delete_Keyword_Entered() {
		test.ContentView.EnterDeleteInTextBox();
		test.ContentView.VerifyDeletebuttonEnabled();
	}

	// 87.Verify that clicking on the confirm delete button Deletes the content
	// message displays "Content successfully deleted"
	@Test(priority = 28)
	public void Verify_Clicking_On_Confirm_Delete_Deletes_The_Content() {
		test.ContentView.ClickConformDelete();
	}

	// 88.Verify that content view page has Associated project heading below the
	// system Metadata
	@Test(priority = 29)
	public void Verify_Associated_project_Heading() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.verifyAssociatedProjectLabel();
	}

	// 89."Verify that content view page has Associated project heading with the
	// following details:
	// Thumbnail of the project
	// ISBN
	// Created Date
	// User type
	// Version Type"
	@Test(priority = 30)
	public void Verify_Associated_Project_Details_Are_Shown() {
		test.ContentView.VerifyAssociatedProjectDetail();
	}

	// 90.Verify that beside the Associated project heading has Add/remove projects
	// button
	@Test(priority = 31)
	public void Verify_AddRemove_Projects_Button() {
		test.ContentView.VerifyAddremoveButton();
	}

	// 91.Verify that clicking on the Add/remove project button pop up open
	@Test(priority = 32)
	public void Verify_Clicking_AddRemove_Button_Opens_Pop_Up() {
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
	}

	// 92.Verify that the Content History heading is present below the Associated
	// project heading
	@Test(priority = 33)
	public void Verify_Content_History_Heading_Below_Associated_Project() {
		test.refreshPage();
		test.ContentView.VerifyHistoryIsDisplayed();
	}

	// 93."Verify that content history has the table with following details:
	// Action Type
	// Action Time
	// Created By
	// Note"
	@Test(priority = 34)
	public void Verify_Content_History_Table_Coloums() {
		test.ContentView.VerifyColoumsOnHistoryTable();
	}

	// 94.Verify that pagination appears if there is more history and user can move
	// back and forth below the table present in the Content history
	@Test(priority = 35)
	public void Verify_Pagination_Bar_Appears_If_There_Are_More_History() {
		test.ContentView.verifyPaginationBarIsAppering();
		test.ContentView.VerifyBackAndForthNavigationpaginationBar();
	}

	// 95.Verify that content view page has comments heading and pane at bottom of
	// the page
	@Test(priority = 36)
	public void Verify_Content_View_Page_Has_Comments_Heading() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN+"_EPUB.epub");
		test.ContentView.VerifyCommentSection();
	}

	// 96.Verify that comment section has comment pane and post button
	@Test(priority = 37)
	public void Verify_Comment_Section_Has_Comment_Pane_And_Post_Button() {
		test.ContentView.VerifyCommentSectionPaneAndPostButton();
	}

	// 97.Verify that post button is disable if comment pane is blank
	@Test(priority = 38)
	public void Verify_Post_Button_Disable_If_Comment_Pane_Is_Blank() {
		test.ContentView.VerifyPostButtonDisable();
	}

	// 98.Verify that post button is activated when comment is present in comment
	// pane
	@Test(priority = 39)
	public void Verify_post_Button_Is_Activated_If_Comment_Is_Present() throws IOException {
		test.ContentView.VerifyPostButtonActive();
	}

	// 199.Verify that user can Edit his own comment only
	@Test(priority = 40)
	public void Verify_User_Can_Edit_His_Comment() throws IOException {
		test.refreshPage();
		test.ContentView.VerifyUserIsAbleToEditComment(AdminEmail);
	}

	// 100.Verify that user can Delete his own comment only
	@Test(priority = 41)
	public void Verify_User_Can_Delete_His_Comment() {
		test.refreshPage();
		test.ContentView.VerifyUserIsAbleToDeleteComment(AdminEmail);
	}

	// 101.Verify that one user can not delete or edit comment made by other user
	@Test(priority = 42)
	public void Verify_User_Can_Not_Delete_Edit_Comment_Made_By_Other_User() {
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(NonAdminEmail);
		test.loginpage.enterUserPassword(NonAdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyUserIsNotAbleToDeleteMsg(AdminEmail);
		test.ContentView.VerifyUserIsnotAbleToEditMsg(AdminEmail);
	}

	// 102.Verify that a user is allowed add a comment and all the comments are
	// displayed at the bottom of project view page
	@Test(priority = 43)
	public void Verify_User_Is_Allowed_To_Add_Comment_And_All_Comments_Are_Displayed_At_Bottom()
			throws NumberFormatException, IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN+"_EPUB.epub");
		test.ContentView.AddCommentAndVerifyIt();
	}

	// 103.Verify that Content history is not getting updated while updating the
	// Content Contacts field (Adding a new email)
	@Test(priority = 44)
	public void Verify_Content_History_Is_Not_Getting_Updated_While_Adding_Email() {
		test.ContentView.AddEmailAddress(NonAdminEmail);
		test.ContentView.VerifyContentHistoryIsNotUpdated();
	}

	// 104.Verify that Content history is not getting updated while updating the
	// Content Contacts field (Deleting a new email)
	@Test(priority = 45)
	public void Verify_Content_History_Is_Not_Getting_Updated_Deleting_Adding_Email() {
		test.ContentView.RemoveAddedEmail(NonAdminEmail);
		test.ContentView.VerifyContentHistoryIsNotUpdated();
	}

	// 105.Verify that user can Publish the enhanced ePub by selecting the third
	// option and only the ePub is getting published.
	@Test(priority = 46)
	public void Verify_User_Can_Publish_Enhanced_EPub_By_Selecting_Third_Option() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectPublishRadioButton("Publish ePub only");
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.VerifyPublishWasOnCorrectDestination(PublihDestinationVitalSource);
	}

	// 106."Verify that on the publish modal window First radio button label should
	// be read as: Publish content links and ePub (with info icon)"
	//@Test(priority = 47) ####### Functionality obsolete #######
	public void Verify_Publish_Modal_Window_First_Radio_Button_Label() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyFirstRadioButtonAndToolTip();
	}

	// 107.Verify that First radio button tooltip should be read as:CMS sends CFI
	// content links to Courseware and publishes ePub to CoreSource with this
	// action.
	//@Test(priority = 48) ####### Functionality obsolete #######
	public void Verify_First_Radio_Button_ToolTip_Info_IS_Correct() {
		test.ContentView.clickFirstToolTipAndVerifyOutputOnPlatform(PublihDestinationCoreSource);
	}

	// 108."Verify that on the publish modal window Second radio button label should
	// be read as:Publish content links only (with info icon)"
	//@Test(priority = 49) ####### Functionality obsolete #######
	public void Verify_Publish_Modal_Window_Second_Radio_Button_Label() {
		test.ContentView.VerifySecondRadioButtonAndToolTip();
	}

	// 109.Verify that on the publish modal window beside Second radio button
	// tooltip should be read as:CMS sends CFI content links to Courseware with this
	// action.
	//@Test(priority = 50) ####### Functionality obsolete #######
	public void Verify_Second_Radio_Button_ToolTip_Info_IS_Correct() {
		test.ContentView.clickSecondToolTipAndVerifyOutput();
	}

	// 110."Verify that on the publish modal window Third radio button label should
	// be read as: Publish ePub only (with info icon)"
	//@Test(priority = 51) ####### Functionality obsolete #######
	public void Verify_Publish_Modal_Window_Third_Radio_Button_Label() {
		test.ContentView.VerifyThirdRadioButtonAndToolTip();
	}

	// 111.Verify that on the publish modal window beside Third radio button tooltip
	// should be read as:CMS publishes ePub to CoreSource with this action.
	//@Test(priority = 52)  ####### Functionality obsolete #######
	public void Verify_Third_Radio_Button_ToolTip_Info_IS_Correct() {
		test.ContentView.clickThirdToolTipAndVerifyOutputOnPlatfrom(PublihDestinationCoreSource);
	}

	// 112.Verify that in the publish modal window destination drop down should have
	// option VitalSource
	@Test(priority = 53)
	public void Verify_Publish_Modal_Window_Destination_Has_VitalSource() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
	}

	// 113.Verify that as soon as the user selects the Vital Source destination
	// platform, three additional options available
	@Test(priority = 54)
	public void Verify_3_option_When_User_Select_Vital_Source_Platform() {
		test.ContentView.VerifyThreeOptionsDisplayedInPublish();
	}

	// 114.Verify that as soon as the user selects the Vital Source destination
	// platform, three additional options available with tooltip
	@Test(priority = 55)
	public void Verify_Tool_Tips_On_Vital_Source_Platform() {
		test.ContentView.clickFirstToolTipAndVerifyOutputOnPlatform(PublihDestinationVitalSource);
		test.ContentView.clickSecondToolTipAndVerifyOutput();
		test.ContentView.clickThirdToolTipAndVerifyOutputOnPlatfrom(PublihDestinationVitalSource);
	}

	// 115.Verify that user should be able to publish the epub successfully to
	// VitalSource
	@Test(priority = 56)
	public void Verify_User_Is_Able_To_Publish_Epub_To_Vital_Source() {
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

	}

	// 116.Verify that user is able to track the publish status under the publish
	// details tab of both content and project when published to Vital source
	@Test(priority = 57)
	public void Verify_User_Is_Able_To_Track_Publish_Status_Under_Publish_Details_Tab() {
		test.ContentView.VerifyPublishWasOnCorrectDestination(PublihDestinationVitalSource);
	}

	// 117.Verify that in the version history table, a new link will be provided
	// next to the ‘Unapprove’ link, named ‘Delete Version’
	@Test(priority = 58)
	public void Verify_Delete_Version_Button_Is_Visiable_In_Version_Details_Tab() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN+"_FC.jpg");
		test.ContentView.clickVersionDetails();
		test.ContentView.VerifyDeleteButtonInVersionDetailTab();
	}

	// 118.Verify that Delete button is disabled when no version is selected
	@Test(priority = 59)
	public void Verify_Delete_Button_Disabled_When_No_Version_Selected() {
		test.ContentView.VerifyVersionDetailDeleteButtonDisabled();
	}

	// 119.Verify that Delete button is disabled when multiple versions are selected
	@Test(priority = 60)
	public void Verify_Delete_Button_Disabled_When_Multiple_Version_Selected() {
		test.ContentView.SelectMultipleVersionOnDetailVersionTab();
		test.ContentView.VerifyVersionDetailDeleteButtonDisabled();
	}

	// 120.Verify that Delete button is disabled when content is from another
	// repository (other than cms)
	@Test(priority = 61)
	public void Verify_Delete_Button_Disabled_When_Content_Is_From_Another_Repository() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.clickVersionDetails();
		test.ContentView.SelectSingleVersionOnDetailVersionTab();
		test.ContentView.VerifyVersionDetailDeleteButtonDisabled();
	}

	// 121.Verify that Clicking on delete button a modal window will show for users
	// to confirm the action
	@Test(priority = 62)
	public void Verify_Clicking_Delete_Button_Modal_Window_PopUp() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN+"_FC.jpg");
		test.ContentView.clickVersionDetails();
		test.ContentView.SelectSingleVersionOnDetailVersionTab();
		test.ContentView.ClickDeleteButtonOnVerTab();
		test.ContentView.VerifyDeleteVersionPopUp();
		test.ContentView.ClickX_OnWindow();
	}

	// 122.Verify that once the action is complete the page will refresh
	// automatically
	@Test(priority = 63)
	public void Verify_Once_Version_Deleted_Page_Refresh_Automatically() {
		test.ContentView.clickVersionDetails();
		test.ContentView.ClickUploadNewVersion();
		test.ContentView.UploadNewVersionOfContent(ISBN+"_FC.jpg");
		test.ContentView.clickVersionDetails();
		test.ContentView.ClickDeleteButtonOnVerTab();
		test.ContentView.VerifyDeleteVersionPopUp();
		test.ContentView.ClickConformDeleteOnVersionDetail();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}