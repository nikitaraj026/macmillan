package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Home_Page_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DAMLink;
	String ISBN1, NonAdminEmail, NonAdminPassword, ISBN, PassResetEmail, CurrentResetPassword, ProjectISBNNOUpload;
	String ProjectTitle,TypesOfContentEnhancedEpub;
	boolean runable;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		ProjectISBNNOUpload = getData("ProjectISBNNo3");
		PassResetEmail = getData("PasswordResetAccount.email");
		CurrentResetPassword = PropFileHandler.readPropertyFromDataFile("currentPassword");
		ProjectTitle=getData("ProjectTitle1");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());

	}

	// 1.Verify that user full name and email address is displayed under the General
	// Information tab of Account pop up
	@Test(priority = 1)
	public void Verify_User_Full_Name_And_Email_Is_Displayed_In_General_Information() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.VerfiyFullNameAndEmailIDIsDisplayed();
	}
	
	

	// 2.Verify that a user is successfully able to update/reset the password for
	// his/her own user account and is able to login with updated password`
	@Test(priority = 2)
	public void Verify_User_Is_Able_To_UpdateAndReset_Password() throws IOException {
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(PassResetEmail);
		test.loginpage.enterUserPassword(CurrentResetPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
		test.HomePage.ResetPassword();
		test.HomePage.LogoutFromApplication();
		test.loginpage.enterEmailAddress(PassResetEmail);
		test.loginpage.enterUserPassword(PropFileHandler.readPropertyFromDataFile("currentPassword"));
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 3.Verify that user can log out from the application on clicking the Logout
	// link available under Welcome User name! link
	@Test(priority = 3)
	public void Verify_User_Is_Able_To_LogOut() {
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 4.Verify that facet links are available to the left of the page and on
	// clicking them user navigates to the concerned searched results and clicking
	// See more link opens the relevant Pop up
	@Test(priority = 4)
	public void Verify_That_UserCan_Navigate_To_Facet_Links() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickOnFacetLinks();
	}

	// 5.Verify that user is successfully able to upload content and can associate
	// the content to the project from the same pop up.
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Upload_And_Associate_Content() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.UploadEnhancedEpubAndAssociateFromHomePage(ISBN, ProjectISBNNOUpload);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ProjectISBNNOUpload+".epub",TypesOfContentEnhancedEpub);
		test.ContentView.ConfirmContentIsAssociateToProject(ISBN);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 6.Verify that user is not able to change the password if incorrect old
	// password is entered
	@Test(priority = 6)
	public void Verify_User_Not_Able_To_Change_The_Password_If_Incorrect_Old_Password_Entered() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
		test.HomePage.VerifyUnableToResetOnIncorrectOldPassword();
	}

	// 7.Verify that following message appears under Dashboard when no project is
	// marked as Favorite: Your favorite [Star icon] projects will appear here.
	@Test(priority = 7)
	public void Verify_Favorite_Project_Message_Appears_On_No_Favorite_Project() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.VerifyMessageForNoFavoriteProjectsIsDisplayed();
		test.HomePage.VerifyFavoriteTableIsNotDisplayed();
	}

	// 8.Verify that Favorite tab appears under Dashboard with the project which has
	// been marked as Favorite with Checkbox(Grayed out), Folder & Star icon,
	// Author, Title, Short Title, ISBN, Publication date, CMS Project Status
	// details with view icon to navigate to respective project in List view
	@Test(priority = 8)
	public void Verify_Favorite_Table_In_Dashbord_Has_Appropriate_Coloum() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyAllTheColoumsOfFavoriteTable();
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 9.Verify that recent 5 Favorite projects will appear in Dashboard page along
	// with Show All button [If Favorite count is more than 5], clicking the same
	// displays the list of all the the Favorite projects
	@Test(priority = 9)
	public void Verify_Recent_5_Favorite_Projects_Appear_On_Dashboard_With_Show_All_Button() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject("9897");
		test.ProjectPage.AddProjectsToFavorite("8");
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyShowAllButtonDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.VerifyShowAllButtonDisplayAllProject();
		test.HomePage.RemoveAllProjectFromFavorite();

	}

	// 10.Verify that user can unmark the Project from Favorite by clicking the Star
	// icon, also the relevant toaster message appears above in the screen. Those
	// Projects will remain in the dashboard until the page is refreshed.
	@Test(priority = 10)
	public void Verify_User_Can_Unmark_Project_From_Favorite() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN); /// Grayed Out...
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.VerifyProjectIsRemovedFromFavorite(ISBN);
	}

	// 11.Verify that Favorite facet is available as the top facet and clicking the
	// same from any page makes the user to navigate to Dashboard
	@Test(priority = 11)
	public void Verify_Favorite_Facet_Navigate_To_Dashboard() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.HomePage.clickProjectLinkOnFacet();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.clickProjectTab();
		test.HomePage.clickProjectLinkOnFacet();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 12.Verify that changes made to a Project after marking it as Favorite should
	// be displayed in the Favorite table as well
	@Test(priority = 12)
	public void Verify_If_Project_Status_Is_Changed_It_Should_Reflected_On_The_Dashboard() {
		test.HomePage.ClickDashBord();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ChangeProjectStatusAndVerifyOnTheDashboard(ISBN);
	}
	
	//13.Verify that view icon available for each row has been replaced by hyperlinking the complete row
	@Test(priority = 13)
	public void Verify_Hyper_Linked_Row_On_DashBord() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.OpenProjectOnFavoriteDashBoard(ISBN);
		test.projectView.verifyOnProjectView();
	}
	
	// 14.Verify that user can unmark the Project from Favorite by clicking the Star
	// icon in LIST and GRID view both, also the relevant toaster message appears to
	// the top right position in the screen. Those Projects will remain in the
	// dashboard until the page is refreshed.
	@Test(priority = 14)
	public void Verify_User_Can_Mark_Unmark_Favorite_On_LIST_And_GRID_View() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(ISBN1);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN1);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN1);
		test.HomePage.RemoveProjectFromFavorite(ISBN1);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN1);
		test.HomePage.clickGridView();
		test.HomePage.VerifyProjectIsAddedAsFavoriteInGridView(ProjectTitle);
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickListView();
		test.HomePage.VerifyProjectIsRemovedFromFavorite(ISBN1);
		test.HomePage.clickGridView();
		test.HomePage.VerifyProjectRemovedFromFavoriteInGridView(ProjectTitle);
		
		
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(ISBN1);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN1);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickGridView();
		test.HomePage.VerifyProjectIsAddedAsFavoriteInGridView(ProjectTitle);
		test.HomePage.RemoveProjectFromFavoriteInGridView(ProjectTitle);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.VerifyProjectIsAddedAsFavoriteInGridView(ProjectTitle);
		test.HomePage.ClickListView();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN1);
		test.HomePage.clickGridView();
		test.HomePage.AddProjectToFavoriteInGridView(ProjectTitle);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
	}
	
	//15.Grid view> Verify that following metadata is displaying: Author, Title, Edition and ISBN under Project thumbnail
	@Test(priority = 15)
	public void Verify_Project_Metadata_On_Favorite_Tab_GRID_View() {
		test.HomePage.VerifyProjectDetailGridViewFavoriteTab();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}