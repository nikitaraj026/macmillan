package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

public class Reg_AuthorImage_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String PublihDestinationInstructorStore, SampleAuthorImage, ISBN, ContentTypeAuthorImage;
	String AuthorName, AuthorId, EditTitle, LookForAsset;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		SampleAuthorImage = getData("MarketingAuthorSampleImage");
		ISBN = getData("ProjectISBNNO");
		ContentTypeAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		AuthorName = getData("Author.Name");
		AuthorId = getData("Author.id");
		EditTitle = getStringWithDateAndTimes("Automation");
		LookForAsset = getData("LookFor.Assets");
		ContentTypeAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that user is navigated to Publish window and Content view for
	// the same is active in background after clicking the Upload button in the
	// Upload content pop up.
	// BS-2583
	@Test(priority = 2)
	public void Verify_User_Is_Navigate_To_PublishWindow_And_ContentView_After_Clicking_The_Upload_Button() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeAuthorImage);
		test.HomePage.SelectImageFileUsingBrowseButton(ISBN);
		test.HomePage.EnterTextInAuthorField(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId), true);
		test.HomePage.VerifySuggestionforAuthorNameDisplayedInUploadContent();
		test.HomePage.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyPublishPopUpDisplayed();
	}

	// 2.Verify that 'Instructor Store' is selected as the Publish destination
	// by default
	// BS-2583
	@Test(priority = 3)
	public void Verify_InstructorStore_Is_Selected_By_Default() {
		test.ContentView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
	}

	// 3."Verified that in Step 2 following is getting displayed:
	// a) Image preview
	// b) Author Name - First Name, Last Name, Author Key"
	// BS-2583
	@Test(priority = 4)
	public void Verify_Author_Name_And_Image_Preview_On_publish_Window() {
		test.ContentView.VerifyAuthorImageInStep2PublishWindow();
		test.ContentView
				.VerifyAuthorNameAndIdInStep2PublishWindow(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
	}

	// 4.Verify that Image file name is getting updated as AuthorKey.jpg/ .png
	// in the Publish window/ Content view page.
	// BS-2583
	@Test(priority = 5)
	public void Verify_Image_File_Name_Is_Getting_Updated_As_AuthorKey() {
		test.ContentView.VerifyStep3PublishWindowNameOfAsset(AuthorId + ".jpg");
		test.ContentView.ClickCloseOnpublishPopup();
		test.ContentView.VerifyFileNameIsAuthorKey(AuthorId);
	}

	// 5.Verify that Success message is getting displayed when user hits the
	// Publish button after approving the asset.
	// BS-2583
	@Test(priority = 6)
	public void Verify_Success_Message_On_Publishing_Approved_Asset() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.VerifyPublishPopIsClosed();
		test.ContentView.VerifyOnContentViewPage();
	}

	// 6.Verify that error message appears if user hits the Publish button
	// without approving the Asset.
	// BS-2583
	@Test(priority = 7)
	public void Verify_Error_Message_On_Publishing_Unapproved_Asset() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsNotPublished();
	}

	// 7.Verify that user can click outside the Publish window anytime and this
	// action closes the Publish window.
	// BS-2583
	//@Test(priority = 8)  ##Functionality Removed##
	public void Verify_PublisWindow_Closes_clicking_OutSide_PublishWindow() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.ClickContentView();
		test.ContentView.VerifyPublishPopIsClosed();
	}

	// 8.Verify that user is able to Edit the Asset's Title and Description
	// fields after the asset is uploaded to CMS.
	// BS-2583
	@Test(priority = 9)
	public void Verify_User_Is_Able_To_Edit_Asset_Title_And_Description() throws IOException {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(EditTitle);
		test.ContentView.EditAssetDetail();
		test.ContentView.VerifyTitleIsEdited(EditTitle);
		test.ContentView.VerifyDetailUpdated();
	}

	// 9."Verify that user is able to Search for Author Image from:
	// 1) Generic Search
	// 2) Advanced Search"
	// BS-2583
	@Test(priority = 10)
	public void Verify_Search_For_Author_Image_From_Advance_And_GenericSearch() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(EditTitle);
		test.Contentpage.opentheSearchContent(EditTitle);
		test.ContentView.VerifyOnContentViewPage();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp("Content Type");
		test.SearchPage.SelectContentTypeInNewAddedField(ContentTypeAuthorImage);
		test.SearchPage.EnterTextIntoSearchBox(EditTitle);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnAssetOnSearchPage(EditTitle);
		test.ContentView.VerifyOnContentViewPage();

	}

	// 10.Verify that Publish status is displayed as Complete after a while in
	// Publish Details tab.
	// BS-2583
	@Test(priority = 11)
	public void Verify_Publish_Status_Is_Displayed_As_Complete() {
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyPublishStatus("1", "Complete");
	}

	// 11.Delete the Uploaded Author Image
	@Test(priority = 12)
	public void Delete_The_Uploaded_Author_Image() {
		test.ContentView.DeleteContentFromCMS();
	}

	// 12."Verify that the Vertical scroll bar has been implemented successfully
	// for the Author Name list in following workflows:
	// a) Dashboard> Upload Content button
	// BS-2664
	@Test(priority = 13)
	public void Verify_Vertical_Scroll_Bar_in_Author_Name_Field_DashBord_UploadContent() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeAuthorImage);
		test.HomePage.EnterTextInAuthorField("Sand", true);
		test.HomePage.VerifyScrollBarOnUploadContentField("Author Name");
		test.HomePage.clickXButtonUploadContent();
	}

	// 13."Verify that the Vertical scroll bar has been implemented successfully
	// for the Author Name list in following workflows:
	// b) Dashboard> Project view> Upload Content button"
	// BS-2664
	@Test(priority = 14)
	public void Verify_Vertical_Scroll_Bar_in_Author_Name_Field_ProjectView_UploadContent() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectContentTypeInUploadContentPopup(ContentTypeAuthorImage);
		test.projectView.EnterTextInAuthorField("Sande");
		test.projectView.VerifyScrollBarOnUploadContentField("Author Name");

	}

	// 14.Verify that user is able to scroll up and down using mouse roll over/
	// Up/Down arrow buttons available.
	// BS-2664
	@Test(priority = 15)
	public void Verify_User_Is_Able_To_Scroll_Using_Author_Name_Field_ScrollBar() {
		test.projectView.VerifyScrollBarIsWorkingOnUploadContent();
	}

	// 15.Verify that user is able to select the Author name from the scrolled
	// list successfully.
	// BS-2664
	@Test(priority = 16)
	public void Verify_User_Is_Able_To_Select_The_Author_Name() {
		test.projectView.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.projectView.clickXButtonUploadContent();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
