package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_AdvanceSearch extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String AdvSearchTypeInstructorStoreAuthor, LookForAsset, LookForProject, LookForBoth;
	String DropDownValueContains, AuthorName, ISBN, ContentTypeCFI, TitleForFile, AdvanceSearchTypeContentType;
	String DestinationVitalSource, TypesOfContentEnhancedEpub, SelectPageAll, SelectPageThisPage, SelectPageNone;
	String AuthorID, AdvSearchTypePublishDestination, PublihDestinationCatalog, PublihDestinationInstructorStore;
	String PageSelectionThisPage, AdvanceSearchTypeCopyrightYear, AdvanceSearchTypeDiscipline, AdvanceSearchTypeTitle;
	String AdvanceSearchTypeAuthor, AdvanceSearchTypeSubGroup, AdvanceSearchTypeEdition, AdvanceSearchTypeProjectType;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		AdvSearchTypeInstructorStoreAuthor = getData("SearchTypeAdvanceSearch.Instructor Store Author Name");
		AdvSearchTypePublishDestination = getData("SearchTypeAdvanceSearch.Publish Destination");
		LookForAsset = getData("LookFor.Assets");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		DropDownValueContains = getData("AdvanceSearchDropDownValues.contains");
		AuthorName = getData("Author.Name");
		AuthorID = getData("Author.id");
		ISBN = getData("ProjectISBNNO");
		ContentTypeCFI = getData("TypesOfContent.Project Support Materials>CFI");
		TitleForFile = "Test New Content Type CFI";
		AdvanceSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		AdvanceSearchTypeCopyrightYear = getData("SearchTypeAdvanceSearch.Copyright Year");
		AdvanceSearchTypeDiscipline = getData("SearchTypeAdvanceSearch.Discipline");
		AdvanceSearchTypeTitle = getData("SearchTypeAdvanceSearch.Title");
		AdvanceSearchTypeAuthor = getData("SearchTypeAdvanceSearch.Author");
		AdvanceSearchTypeSubGroup = getData("SearchTypeAdvanceSearch.Sub Group");
		AdvanceSearchTypeProjectType = getData("SearchTypeAdvanceSearch.Project Type");
		AdvanceSearchTypeEdition = getData("SearchTypeAdvanceSearch.Edition");
		DestinationVitalSource = getData("PublishDestination.VitalSource");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		SelectPageAll = getData("PageSelection.All Pages");
		SelectPageThisPage = getData("PageSelection.This Page");
		SelectPageNone = getData("PageSelection.None");
		PublihDestinationCatalog = getData("PublishDestination.Catalog");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		PageSelectionThisPage = getData("PageSelection.This Page");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that a new value as 'Instructor Store Author Name' has been added in
	// the 'Add a new field' dropdown when 'Assets' is selected in 'Look for'
	// dropdown.
	// BS-2561
	@Test(priority = 2)
	public void Verify_Instructor_Store_Author_Name() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeInstructorStoreAuthor);
	}

	// 2.Verify that this newly added value is not available in the 'Add a new
	// field' dropdown if 'Projects' or 'Assets and Projects' is selected in 'Look
	// for' dropdown.
	// BS-2561
	@Test(priority = 3)
	public void Verify_Instructor_Store_Author_Name_Not_Displayed() {
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvSearchTypeInstructorStoreAuthor);
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvSearchTypeInstructorStoreAuthor);
	}

	// 3.Verify that after clicking the Add button, the newly added field
	// 'Instructor Store Author Name' gets added to the query section with a
	// dropdown and a keyword box.
	// BS-2561
	@Test(priority = 4)
	public void Verify_DropDown_And_KeywordBox() {
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeInstructorStoreAuthor);
		test.SearchPage.SelectTextFromInAddedDropDown(1, DropDownValueContains);
		test.SearchPage.EnterTextFromInAddedInputBar(1, AuthorName);
	}

	// 4.Verify that Autosuggestion Author Names list is appearing properly as soon
	// as user starts typing in the keyword box
	// BS-2561
	@Test(priority = 5)
	public void Verify_Autosuggestion_For_Author_Names_List() {
		test.SearchPage.EnterTextFromInAddedInputBar(1, AuthorName.split(" ")[0]);
		test.SearchPage.VerifySuggestionOnAdvanceSearchPopupAddedInputBar(1);
		test.SearchPage.EnterTextFromInAddedInputBar(1, AuthorName.split(" ")[1]);
		test.SearchPage.VerifySuggestionOnAdvanceSearchPopupAddedInputBar(1);
		test.SearchPage.EnterTextFromInAddedInputBar(1, AuthorID);
		test.SearchPage.VerifySuggestionOnAdvanceSearchPopupAddedInputBar(1);
		test.SearchPage.EnterTextFromInAddedInputBar(1, "S");
		test.SearchPage.VerifySuggestionOnAdvanceSearchPopupAddedInputBar(1);
	}

	// 5.Verify that clicking the Search button results into the Searched results
	// page(s).
	// BS-2561
	@Test(priority = 6)
	public void Verify_Clicking_Search_Button_Navigate_To_Results_Page() {
		test.SearchPage.EnterTextFromInAddedInputBar(1, AuthorName);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyResultAreAccordingToSearchedText(AuthorName);
	}

	// 6.Verify that 'CFI' Content type has been updated to 'Project Support
	// Materials>CFI.csv in following workflows:
	// 1) Content tab> List view
	// 2) Content view page> Content details tab
	// 3) Content view> Publish> Step 3
	// 4) Content view> Push to Authoring tool> Step 2> List and Grid
	// 5) Project view> Associated Content section
	// 6) Project view> Filter Associated content section
	// 7) Project view> Upload Content> Content type
	// 8) Project view> Push to Authoring tool window> Step 2
	// 9) Project view> Publish> Step 2 and Step 3
	// 10) Home> Upload Content> Content Type
	// 11) Home> Advanced Search> Content type list
	// 12) Home> Generic Search and Advanced Search results page."
	// BS-1251
	@Test(priority = 7)
	public void Verify_CFI_Content_Type_Updated_To_Project_Support_Materials_CFI_csv() {
		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton("9897989798041_CFI.csv");
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeCFI);
		test.HomePage.EnterTextIntoTitleField(TitleForFile);
		test.HomePage.clickUploadButton();

		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentSubtypeInContentView(ContentTypeCFI);
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyContentTypeInPublishWindow(ContentTypeCFI);
		test.ContentView.ClickX_OnWindow();

		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyContentSubtypeInPushToAuthoringToolGridView(ContentTypeCFI);
		test.ContentView.VerifyListView();
		test.ContentView.VerifyContentSubtypeInPushToAuthoringToolListView(ContentTypeCFI);
		test.ContentView.ClickX_OnWindow();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.VerifyContentType(ContentTypeCFI);
		test.Contentpage.SelectContentOnContentTab(TitleForFile, ContentTypeCFI);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.FilterContent(ContentTypeCFI);
		test.projectView.VerifyContentTypeInAssociatedContent(ContentTypeCFI);

		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectFileUsingBrowseButton("9897989798041_CFI.csv");
		test.projectView.SelectContentTypeInUploadContentPopup(ContentTypeCFI);
		test.projectView.clickXButtonUploadContent();

		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.ClickOtherOnPushToAuthoringTool();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Other", ISBN + "_CFI.csv");
		test.projectView.VerifyContentSubtypeInPushToAuthoringToolGridView(ContentTypeCFI);
		test.projectView.ClickListViewOnPushToAuthoringTool();
		test.projectView.VerifyContentSubtypeInPushToAuthoringToolListView(ContentTypeCFI);
		test.projectView.ClickCloseButton();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeCFI, ISBN + "_CFI.csv", true);
		test.projectView.VerifyContentTypeDisplayedInStep3PublishWindow(ContentTypeCFI);
		test.projectView.ClickCloseButton();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvanceSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(ContentTypeCFI);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyContentType(ContentTypeCFI);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_CFI.csv");
		test.Contentpage.VerifyContentType(ContentTypeCFI);

	}

	// 7.Verify that user is able to Publish the CFI files via Second radio button
	// in Publish window of Project view
	// BS-1251
	@Test(priority = 8)
	public void Verify_User_Able_To_Publish_CFI_Files_Via_Second_Radio_Button() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(DestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links and ePub");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub, ISBN + ".epub",
				true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + ".epub");
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_CFI.csv");
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(2);
		test.projectView.ClickCloseButton();
		test.projectView.WaitforpublishToComplete("Success", "1");
	}

	// 8.Verify that user is able to Publish the CFI files via Content view
	// BS-1251
	@Test(priority = 9)
	public void Verify_User_Able_To_Publish_CFI_Via_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_CFI.csv");
		test.Contentpage.opentheSearchContent(ISBN + "_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickPublishDetail();
		test.ContentView.WaitforpublishToComplete("Complete", "1");
	}

	// 9."Content Tab: Verify that pointer icon remains as is when user hovers just
	// below the grayed out four links that are available at the top i.e.
	// a) Organized Download
	// b) Download Content
	// c) Add to Project
	// d) Delete"
	// BS-2896
	@Test(priority = 10)
	public void Verify_Pointer_Icon_For_Grayed_Out_Four_Links() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.verifyHandIconNotDisplayedOnGrayedOutLink();
	}

	// 10."Generic Search page: Verify that pointer icon remains as is when user
	// hovers just below the grayed out four links that are available at the top
	// i.e.
	// a) Organized Download
	// b) Download Content
	// c) Add to Project
	// d) Delete"
	// BS-2896
	@Test(priority = 11)
	public void Verify_Pointer_Icon_For_Grayed_Out_Four_Links_Generic_Search() {
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.verifyHandIconNotDisplayedOnGrayedOutLink();
	}

	// 11."Advanced Search page: Verify that pointer icon remains as is when user
	// hovers just below the grayed out four links that are available at the top
	// i.e.
	// a) Organized Download
	// b) Download Content
	// c) Add to Project
	// d) Delete"
	// BS-2896
	@Test(priority = 12)
	public void Verify_Pointer_Icon_For_Grayed_Out_Four_Links_Advance_Search() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.verifyHandIconNotDisplayedOnGrayedOutLink();
	}

	// 12.Verify that proper Hand icon is getting displayed on hovering the Select
	// All dropdown options i.e. All Pages, This Page and None option.
	// a) Generic Search
	// BS-2890
	@Test(priority = 13)
	public void Verify_Hand_Icon_On_All_Select_All_DropDown_Options_Generic_Search() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyHandIconOnSelectAllOption(SelectPageThisPage);
		test.Contentpage.VerifyHandIconOnSelectAllOption(SelectPageAll);
		test.Contentpage.VerifyHandIconOnSelectAllOption(SelectPageNone);
	}

	// 13."Verify the same for following available workflows:
	// b) Advanced Search"
	// BS-2890
	@Test(priority = 14)
	public void Verify_Hand_Icon_On_All_Select_All_DropDown_Options_Advanced_Search() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyHandIconOnSelectAllOption(SelectPageThisPage);
		test.SearchPage.VerifyHandIconOnSelectAllOption(SelectPageAll);
		test.SearchPage.VerifyHandIconOnSelectAllOption(SelectPageNone);

	}

	// 14."Verify the same for following available workflows:
	// c) Step 3 of Publish window"
	// BS-2890
	@Test(priority = 15)
	public void Verify_Hand_Icon_On_All_Select_All_DropDown_Options_Publish_Window() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.VerifyHandIconOnSelectAllOption(SelectPageThisPage);
		test.projectView.VerifyHandIconOnSelectAllOption(SelectPageAll);
		test.projectView.VerifyHandIconOnSelectAllOption(SelectPageNone);
	}

	// 15.Verify that Pointer icon is getting displayed if user hovers to the
	// neighborhood of the Select All options.
	// BS-2890
	@Test(priority = 16)
	public void Verify_Pointer_Icon_On_Neighborhood_Of_Select_All() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem("test");
		test.Contentpage.VerifyHandIconNotDisplayedNearPageSelection();
	}

	// 16.4) Verified that Autosuggestion list of Author name displays again if user
	// enters some irrelevant text and use the Delete/ Backspace key and then again
	// key the letters in the box.
	// BS-3028
	@Test(priority = 17)
	public void Verify_Autosuggestion_List_Of_Author_Name() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeInstructorStoreAuthor);
		test.SearchPage.EnterTextFromInAddedInputBar(1, "Icorrect Text");
		test.SearchPage.VerifySuggestionOnAdvanceSearchPopupAddedInputBarNotDisplayed(1);
		test.SearchPage.EnterTextFromInAddedInputBar(1, AuthorName);
		test.SearchPage.VerifySuggestionOnAdvanceSearchPopupAddedInputBar(1);

	}

	// 1) Verify that 'Catalog' option is replaced by the 'Instructor Store' option
	// in the dropdown list of Publish destination in Advanced Search pop-up when
	// user looks for 'Assets':
	// BS-2781
	@Test(priority = 18)
	public void Verify_Instructor_Store_Option_Looks_For_Assets() {
		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypePublishDestination);
		test.SearchPage.VerifyTextNotDisplayedInAddedDropDown(1, PublihDestinationCatalog);
		test.SearchPage.SelectTextFromInAddedDropDown(1, PublihDestinationInstructorStore);
	}

	// 2) Verify that 'Catalog' option is replaced by the 'Instructor Store' option
	// in the dropdown list of Publish destination in Advanced Search pop-up when
	// user looks for 'Projects':
	// BS-2781
	@Test(priority = 19)
	public void Verify_Instructor_Store_Option_Looks_For_Projects() {
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypePublishDestination);
		test.SearchPage.VerifyTextNotDisplayedInAddedDropDown(1, PublihDestinationCatalog);
		test.SearchPage.SelectTextFromInAddedDropDown(1, PublihDestinationInstructorStore);
	}

	// 3) Verify that 'Catalog' option is replaced by the 'Instructor Store' option
	// in the dropdown list of Publish destination in Advanced Search pop-up when
	// user looks for 'Assets and Projects':
	// BS-2781
	@Test(priority = 20)
	public void Verify_Instructor_Store_Option_Looks_For_Assets_And_Projects() {
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypePublishDestination);
		test.SearchPage.VerifyTextNotDisplayedInAddedDropDown(1, PublihDestinationCatalog);
		test.SearchPage.SelectTextFromInAddedDropDown(1, PublihDestinationInstructorStore);
	}

	// 4) Verify that the search results page contains assets for 'Instructor store'
	// Publish destination when search is performed:
	// BS-2781
	@Test(priority = 21)
	public void Verify_Search_Results_Page_Contains_Assets() {
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypePublishDestination);
		test.SearchPage.SelectTextFromInAddedDropDown(1, PublihDestinationInstructorStore);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.VerifyContentsAreSelected();
	}

	// 1) Verify that on clicking the Reset button, all the 14 options dedicated to
	// ‘Assets’ category are getting displayed in the ‘Add a new field' drop-down as
	// ‘Assets’ get selected by default in the Look For field.
	// BS-1964
	@Test(priority = 22)
	public void Verify_Reset_Button_Functionality_On_AdvanceSearch() {
		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeCopyrightYear);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeDiscipline);
		test.SearchPage.ClickResetButton();
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeCopyrightYear);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeDiscipline);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeContentType);
		test.SearchPage.ClickX_OnWindow();
	}

	// 2) Verify that if user has made an Advanced Search with 'Projects' category,
	// then on opening the Advanced Search window again, options for Project
	// category are displaying in the 'Add a New field' dropdown.
	// BS-1964
	@Test(priority = 23)
	public void Verify_Reset_Button_Functionality_On_AdvanceSearch_Scenario2() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeCopyrightYear);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeAuthor);

		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeContentType);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeTitle);
		test.SearchPage.ClickX_OnWindow();

	}

	// 3) Verify that if user has made an Advanced Search with 'Assets and Projects'
	// category, then on opening the Advanced Search window again, options for
	// Assets and Projects category are displaying in the 'Add a New field'
	// dropdown.
	// BS-1964
	@Test(priority = 24)
	public void Verify_Reset_Button_Functionality_On_AdvanceSearch_Scenario3() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeContentType);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeAuthor);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeDiscipline);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeCopyrightYear);
		test.SearchPage.ClickX_OnWindow();
	}

	// 4) Verify that after #2 or #3, if user clicks on Reset button, then all the
	// 14 options dedicated to ‘Assets’ category are getting displayed in the ‘Add a
	// new field' drop-down as ‘Assets’ get selected by default in the Look For
	// field.
	// BS-1964
	@Test(priority = 24)
	public void Verify_Reset_Button_Functionality_On_AdvanceSearch_Scenario4() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeCopyrightYear);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeAuthor);

		test.SearchPage.ClickResetButton();
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvSearchTypeInstructorStoreAuthor);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeContentType);

		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeSubGroup);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeEdition);

		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeContentType);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeAuthor);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeDiscipline);
		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeCopyrightYear);

		test.SearchPage.ClickResetButton();
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvSearchTypeInstructorStoreAuthor);
		test.SearchPage.VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(AdvanceSearchTypeContentType);

		test.SearchPage.VerifyFieldNotDisplayedInAddNewFiled(AdvanceSearchTypeProjectType);
		test.SearchPage.ClickX_OnWindow();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}