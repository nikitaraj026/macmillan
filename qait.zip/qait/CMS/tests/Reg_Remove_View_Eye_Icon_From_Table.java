package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Remove_View_Eye_Icon_From_Table extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String TestISBN, TestISBN2,SearchTypeAllType;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		TestISBN = getData("ProjectISBNNO");
		TestISBN2 = getData("ProjectISBNNo1");
		SearchTypeAllType = getData("SearchType.All Types");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// "A) DashBoard> Favorites tab
	// 1) Verified that View column and eye icon has been removed from the table
	// view."
	// BS-3084
	@Test(priority = 2)
	public void Verify_View_Coloum_And_Eye_Icon_Removed_Favorites_Table() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("3");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyViewColoumNotDisplayedOnFavoriteTable();
		test.HomePage.verifyEyeIconNotDisplayedOnFavoriteTable();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();

	}

	// 2) Verified that each row is clickable in the table view.
	// BS-3084
	@Test(priority = 3)
	public void Verify_Each_Row_Is_Clickable_Favorite_Table() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(TestISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(TestISBN);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(TestISBN2);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(TestISBN2);

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.OpenProjectOnFavoriteDashBoard(TestISBN);
		test.projectView.verifyOnProjectView();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.OpenProjectOnFavoriteDashBoard(TestISBN2);
		test.projectView.verifyOnProjectView();
	}

	// 3) Verified that view action is not getting performed on clicking the
	// Favorite/star icon and Checkbox column in the table.
	// BS-3084
	@Test(priority = 4)
	public void Verify_View_Action_Not_Getting_Performed_On_Clicking_Star_Icon_And_Checkbox_Column() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.RemoveProjectFromFavorite(TestISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyUserIsNotNavigatedToProjectView();
		test.HomePage.clickCheckBoxOnFavoriteTable();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyUserIsNotNavigatedToProjectView();
	}

	// 4) Verified that user is able to mark/ un-mark the Projects as Favorite on
	// clicking the Star icon available in the table.
	// BS-3084
	@Test(priority = 5)
	public void Verify_User_Able_To_Mark_UnMark_Projects_As_Favorite() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(TestISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(TestISBN);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(TestISBN2);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(TestISBN2);

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.RemoveProjectFromFavorite(TestISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.RemoveProjectFromFavorite(TestISBN2);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();

		test.HomePage.RemoveProjectFromFavorite(TestISBN);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
		test.HomePage.RemoveProjectFromFavorite(TestISBN2);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
	}

	// 5) Verified that checkbox area in the table is not clickable and red icon
	// appears to indicate the same.
	// BS-3084
	//@Test(priority = 6) Functionality Removed After Sprint 150 and 151 deployment.
	public void Verify_Checkbox_Are_Not_Clickable_And_Red_Icon_Appears() {
		test.HomePage.verifyCheckBoxAreDisabledOnOnFavoriteTable();
	}

	// 6) Verified that entire table row gets highlighted on hovering the cursor on
	// any row available in the table
	// BS-3084
	@Test(priority = 7)
	public void Verify_Entire_Table_Row_Gets_Highlighted_On_Hovering() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyTableRowGetsHighlightedOnHover();
	}

	// 7) Verified that user is navigated to Project view page on clicking over an
	// entry that is available for the Project in the table.
	// BS-3084
	@Test(priority = 8)
	public void Verify_User_Is_Navigates_To_Project_View_On_Clicking_An_Entry() {
		test.HomePage.OpenProjectOnFavoriteDashBoard(TestISBN);
		test.projectView.verifyOnProjectView();
	}

	// "B) Projects tab:
	// 1) Verified that View column and eye icon has been removed from the table
	// view."
	// "C) Generic Search with ‘Projects’:
	// 1) Verified that View column and eye icon has been removed from the table
	// view."
	// BS-3084
	@Test(priority = 9)
	public void Verify_View_Coloum_And_Eye_Icon_Removed_ProjectTab_Table() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.VerifyViewColoumNotDisplayedOnProjectTabTable();
		test.ProjectPage.verifyEyeIconNotDisplayedOnProjectTabTable();

		test.ProjectPage.SearchForProject(TestISBN);
		test.ProjectPage.VerifyViewColoumNotDisplayedOnProjectTabTable();
		test.ProjectPage.verifyEyeIconNotDisplayedOnProjectTabTable();
	}

	// 2) Verified that each row is clickable in the table view.
	// BS-3084
	@Test(priority = 10)
	public void Verify_Each_Row_Clickable_on_ProjectTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.openAnProjectOnProjectTab();
		test.projectView.verifyOnProjectView();

		test.ProjectPage.SearchForProject(TestISBN);
		test.ProjectPage.openAnProjectOnProjectTab();
		test.projectView.verifyOnProjectView();
	}

	// 3) Verified that view action is not getting performed on clicking the
	// Favorite/star icon and Checkbox column in the table.
	// BS-3084
	@Test(priority = 11)
	public void Verify_View_Action_Not_Getting_Performed_On_Clicking_Star_Icon_And_Checkbox_Column_Project_Tab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("1");
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("2");
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.ClickCheckBoxOnProjectTab();
		test.ProjectPage.VerifyOnProjectPage();

		test.ProjectPage.SearchForProject(TestISBN);
		test.ProjectPage.AddProjectsToFavorite("1");
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.AddProjectsToFavorite("2");
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.ClickCheckBoxOnProjectTab();

	}

	// 4) Verified that user is able to mark/ un-mark the Projects as Favorite on
	// clicking the Star icon available in the table.
	// BS-3084
	@Test(priority = 12)
	public void Verify_User_Able_To_Mark_Unmark_The_Projects_As_Favorite_ProjectTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("5");
		test.ProjectPage.RemoveProjectFromFavorite();

		test.ProjectPage.SearchForProject("98979897");
		test.ProjectPage.AddProjectsToFavorite("5");
		test.ProjectPage.RemoveProjectFromFavorite();
	}

	// 5) Verified that checkbox area in the table is not clickable and red icon
	// appears to indicate the same.
	// BS-3084
	@Test(priority = 13)
	public void Verify_Checkbox_Area_In_Table_Not_Clickable() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();

		test.ProjectPage.SearchForProject("98979897");
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
	}

	// 6) Verified that entire table row gets highlighted on hovering the cursor on
	// any row available in the table
	// BS-3084
	@Test(priority = 14)
	public void Verify_Entire_Table_Row_Gets_Highlighted_On_Hovering_ProjectTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.verifyTableRowGetsHighlightedOnHover();

		test.ProjectPage.SearchForProject(TestISBN);
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
	}

	// "D) Generic Search with ‘Content’:
	// 1) Verified that View column and eye icon has been removed from the table
	// view."
	// BS-3084
	@Test(priority = 15)
	public void Verify_View_Coloum_And_Eye_Icon_Removed_ContentTab_Table() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.verifyViewColoumNotDisplayedOnContentTab();
		test.Contentpage.verifyEyeIconNotDisplayedOnContentTab();
	}

	// 2) Verified that each row is clickable in the table view.
	// BS-3084
	@Test(priority = 16)
	public void Verify_Each_Row_Clickable_on_ContentTab() {
		test.Contentpage.ClickOpenAssertOnContentTab();
		test.ContentView.ClickContentView();
	}

	// 3) For Content Entry: Verified that checkbox is clickable for a Content’s
	// entry, however user is not able to navigate to Content view page on clicking
	// the same.
	// BS-3084
	@Test(priority = 17)
	public void Verify_Clicking_Checkbox_User_Is_Not_Navigated_To_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.selectContent("1");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnContentTab();
	}

	// 4) Verified that entire table row gets highlighted on hovering the cursor on
	// any row available in the table.
	// BS-3084
	@Test(priority = 18)
	public void Verify_Entire_Table_Row_Gets_Highlighted_On_Hovering_ContentTab() {
		test.Contentpage.verifyTableRowGetsHighlightedOnHover();
	}

	// 6) For Content Entry: Found that user is not navigating to Content’s view
	// page on clicking the area next to file icon column.
	// BS-3084
	@Test(priority = 19)
	public void Verify_User_Naviagte_To_ContentView_Clicking_Area_Next_To_File_Icon() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSearchType(SearchTypeAllType);
		test.Contentpage.SearchForAnItemWithOutSearchType("test");
		test.Contentpage.clickAreaNextToFileIcon();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.verifyUserIsNotNavigatedToContentView();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
