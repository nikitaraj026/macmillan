package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_BS_3218_User_Not_Able_To_Edit_Asset extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String TestDataImageFile, TestDataPDFFile, TestDataEpub, TestDataCFI, ContentTypeCourseManagement,
			ContentTypeSupplementaryInstructorResources, ContentTypeSampleChapter, ContentTypeCFI;
	String AssetTitleCourseManagement, AssetTitleInstructorResources, AssetTitleSampleChapter, ContentTypeAuthorImage,
			AssetTitleAuthorImage, AssetTitleCFIFile, ContentTypeEnhancedePub, AssetTitleEpub;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare,
			PublihDestinationVitalSource, PublihDestinationInstructorStore,ISBN,AuthorName,AuthorId;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		TestDataImageFile = getData("TestData.ImageFile");
		TestDataPDFFile = getData("TestData.TestPDF2");
		TestDataEpub = getData("TestData.TestEpub4");
		TestDataCFI = getData("TestData.CSVFile");
		ContentTypeCourseManagement = getData("TypesOfContent.Supplementary Content>Course Management");
		ContentTypeSupplementaryInstructorResources = getData(
				"TypesOfContent.Supplementary Content>Instructor Resources");
		ContentTypeSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		ContentTypeAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		ContentTypeCFI = getData("TypesOfContent.Project Support Materials>CFI");
		ContentTypeEnhancedePub = getData("TypesOfContent.Enhanced ePub > Full Package");
		AssetTitleCourseManagement = getStringWithDateAndTimes("AutoCourseManagement");
		AssetTitleInstructorResources = getStringWithDateAndTimes("AutoInstructorResources");
		AssetTitleSampleChapter = getStringWithDateAndTimes("AutoSampleChapter");
		AssetTitleAuthorImage = getStringWithDateAndTimes("AuthorImage");
		AssetTitleCFIFile = getStringWithDateAndTimes("AutoCFI");
		AssetTitleEpub = getStringWithDateAndTimes("Autoepub");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		ISBN = getData("ProjectISBNNO");
		AuthorName = getData("Author.Name");
		AuthorId = getData("Author.id");
		
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step::Upload CM IR, SC, Author Image, CFI and Epub assets for Testing
	@Test(priority = 2)
	public void Upload_Asset_For_Testing() {
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestDataImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeCourseManagement);
		test.HomePage.EnterTextIntoTitleField(AssetTitleCourseManagement);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestDataImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeSupplementaryInstructorResources);
		test.HomePage.EnterTextIntoTitleField(AssetTitleInstructorResources);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestDataPDFFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeSampleChapter);
		test.HomePage.EnterTextIntoTitleField(AssetTitleSampleChapter);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestDataImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeAuthorImage);
		test.HomePage.EnterTextInAuthorField(AuthorName,true);
		test.HomePage.VerifySuggestionforAuthorNameDisplayedInUploadContent();
		test.HomePage.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.HomePage.EnterTextIntoTitleField(AssetTitleAuthorImage);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.ClickX_OnWindow();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestDataCFI);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeCFI);
		test.HomePage.EnterTextIntoTitleField(AssetTitleCFIFile);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestDataEpub);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeEnhancedePub);
		test.HomePage.EnterTextIntoTitleField(AssetTitleEpub);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// Verify that user is able to edit the Content details for CM IR, SC, Author
	// Image, CFI and Epub assets uploaded via CMS
	@Test(priority = 3)
	public void Verify_User_able_To_Edit_Assets() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleCourseManagement);
		test.Contentpage.opentheSearchContent(AssetTitleCourseManagement);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test");
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test Second Round");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test Second Round");
		
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleInstructorResources);
		test.Contentpage.opentheSearchContent(AssetTitleInstructorResources);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test");
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test Second Round");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test Second Round");
		
		
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleSampleChapter);
		test.Contentpage.opentheSearchContent(AssetTitleSampleChapter);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test");
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test Second Round");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test Second Round");
		
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleAuthorImage);
		test.Contentpage.opentheSearchContent(AssetTitleAuthorImage);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test");
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test Second Round");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test Second Round");
		
		
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleCFIFile);
		test.Contentpage.opentheSearchContent(AssetTitleCFIFile);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test");
		test.ContentView.ClickPublishLink();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test Second Round");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test Second Round");
		
		
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleEpub);
		test.Contentpage.opentheSearchContent(AssetTitleEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test");
		/*test.ContentView.verifyStructuralValidationIsComplete();
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("New Edited Title For Test Second Round");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("New Edited Title For Test Second Round");*/
		
	}
	
	//Step:: Delete All the Uploaded Test Data
	@Test(priority=4)
	public void Delete_The_Uploaded_Test_Data() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleAuthorImage);
		test.Contentpage.SelectContentOnContentTab(AssetTitleAuthorImage,ContentTypeAuthorImage);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleCourseManagement);
		test.Contentpage.SelectContentOnContentTab(AssetTitleCourseManagement,ContentTypeCourseManagement);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleInstructorResources);
		test.Contentpage.SelectContentOnContentTab(AssetTitleInstructorResources,ContentTypeSupplementaryInstructorResources);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleSampleChapter);
		test.Contentpage.SelectContentOnContentTab(AssetTitleSampleChapter,ContentTypeSampleChapter);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleCFIFile);
		test.Contentpage.SelectContentOnContentTab(AssetTitleCFIFile,ContentTypeCFI);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleEpub);
		test.Contentpage.SelectContentOnContentTab(AssetTitleEpub,ContentTypeEnhancedePub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}

	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
