package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Content_View_Tab_Ticket_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String NonAdminEmail, NonAdminPassword, ISBN, ISBN1, PublihDestinationCoreSource, PublihDestinationPalgrave,
			PublihDestinationVitalSource;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, DamContent,
			DownloadStartMsg;
	String LOMacmillanCalculus, MacStatement, PublihDestinationCourseWare, TypesOfContentFlatEpub,
			TypesOfContentEnhancedEpub, TypeOfContentFlatBatchEpub,ContentTypeCoverDesign,ContentTypeCFI;
	String BatchEpubISBN, TypesOfContentBatchEnhanced, AdvSearchTypeContentType, TypeOfContentMarketingAuthorImage;
	String DMS_Email, DMS_Password, AuthorName, AuthorId, PublihDestinationInstructorStore, MarketingAuthorSampleImage;
	String NewTitle = "Automation Edited Title.",TypesOfContentInstructorResources,CMSRepository,DAMRepository;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DamContent = getData("DamContent");
		DownloadStartMsg = getData("DownloadStartMsg");
		MacStatement = getData("LOS.macmillan calculus");
		LOMacmillanCalculus = getData("Framework.macmillan calculus");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypeOfContentFlatBatchEpub = getData("TypesOfContent.Flat ePub > Batch");
		TypesOfContentBatchEnhanced = getData("TypesOfContent.Enhanced ePub > Batch");
		ContentTypeCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		ContentTypeCFI = getData("TypesOfContent.Project Support Materials>CFI");
		BatchEpubISBN = getData("BatchEpub");
		AdvSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		DMS_Email = getData("DMSUser.email");
		DMS_Password = getData("DMSUser.password");
		AuthorName = getData("Author.Name");
		AuthorId = getData("Author.id");
		MarketingAuthorSampleImage = getData("MarketingAuthorSampleImage");
		TypesOfContentInstructorResources=getData("TypesOfContent.Supplementary Content>Instructor Resources");
		CMSRepository=getData("Repository.CMS");
		DAMRepository=getData("Repository.DAM");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that hyperlink in filename is disabled when user tries to push
	// enhanced epub to the authoring tool through content view page
	// BS-2013
	@Test(priority = 2)
	public void Verify_Hyperlink_In_Filename_For_Enhanced_Epub_Is_Disable_In_Push_To_The_Authoring_Tool() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN+".epub",TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyHyperLinkDisabledInPushToAuthoringTool();

	}

	// 2.Verify that hyperlink in filename is disabled when user tries to push cover
	// design to the authoring tool through content view page
	// BS-2013
	@Test(priority = 3)
	public void Verify_Hyperlink_In_Filename_For_Cover_Design_Is_Disable_In_Push_To_The_Authoring_Tool() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_FC.jpg",ContentTypeCoverDesign);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyHyperLinkDisabledInPushToAuthoringTool();
	}

	// 3.Verify that the step 3 label name reads as 'Step 3 Select Project ISBN' in
	// Push to authoring tool window in Content View
	// BS-1916
	@Test(priority = 4)
	public void Verify_Correct_Label_Is_Displayed_In_Step3_Of_Push_To_Authoring_Tool() {
		test.ContentView.VerifyStep3LabelOfPushToAuthoringTool();
	}

	// 4.Verify that only a single result is displayed when user searches with exact
	// 13 digit ISBN in Add / Remove Project pop-up from Associated contents section
	// via CONTENT view
	// BS-1653
	@Test(priority = 5)
	public void Verify_In_Add_Content_To_Project_Only_A_Single_Result_Is_Displayed_For_Exact_13_Digit_ISBN_In_Content_View() {
		test.refreshPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.SearchProjectInAddRemovePopUp(ISBN1);
		test.ContentView.VerifyOneProjectDisplayed();
	}

	// 5.Verify that the count of downloaded assets matches with the selected assets
	// to be downloaded for Content view workflow
	// BS-1582
	@Test(priority = 6)
	public void Veirify_Count_Of_Downloaded_Assets_Matches_With_The_Selected_Assets() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.ClickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "");
	}

	// 6.Verify that ISBN column has been renamed as Published Project ISBN
	// BS-1943
	@Test(priority = 7)
	public void Verify_ISBN_Column_Has_Been_Renamed_To_Published_Project_ISBN() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyISBNColoumRenamed();
	}

	// 7.Verify that ISBN of the Project from which the respective asset is
	// published will be displayed under the same
	// BS-1943
	@Test(priority = 8)
	public void Verify_ISBN_Of_Project_From_Which_Asset_Is_Published_Is_Displayed_Under_PublishDetail() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentEnhancedEpub,ISBN1+".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN1);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.ClickOpenAssetOnProjectView(ISBN1+".epub",TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyPublishWasOnCorrectDestinationAndISBN(PublihDestinationVitalSource, ISBN1);
	}

	// 8.Verify that if asset is published via Content view, then the ISBN field
	// will remain blank
	// BS-1943
	@Test(priority = 9)
	public void Verify_If_Asset_Published_Via_Content_View_Then_ISBN_Field_Is_Blank() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN1+"_EPUB.epub");
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyISBN_Not_Displayed_On_PublishDetail();
	}

	// 9.Verify that 'Learning Objective' is appearing as a subtab in Content view
	// BS- 2257
	@Test(priority = 10)
	public void Verify_Learning_Objective_Tab_Is_Appearing_In_Content_View() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyLearningObjectiveTabDisplayed();
	}

	// 10.Verify that Searchbox is displaying under the Learning objective tab in
	// Content View .
	// BS- 2257
	@Test(priority = 11)
	public void Verify_Searchbox_Displayed_Under_The_Learning_Objective_In_Content_View() {
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifySearchBoxDisplayedForLO();
	}

	// 11.Verify that user can add the LOF as well as LOS to the Content .
	// BS- 2257
	@Test(priority = 12)
	public void Verify_User_Can_Add_LOF_As_Well_As_LOS_To_Content() {
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnAddingLearningObjectiveStatement();
		test.ContentView.VerifyLearningObjectiveStatementAdded(MacStatement);
		test.ContentView.RemoveLOS_Statement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnRemovingLearningObjectiveStatement();
	}

	// 12.Verify that the added LOF is displayed in tabular format with column
	// headers as Framework Name and Action
	// BS- 2257
	@Test(priority = 13)
	public void Verify_Added_LOF_Displayed_In_Tabular_Format_With_Column_Headers() {
		test.refreshPage();
		test.ContentView.waitForLoaderToAppearAndDisappear();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkTableIsDisplayed();
		test.ContentView.VerifyFrameworkHeaderIsDisplayed();

		test.refreshPage(); /// For Project View Page////
		test.projectView.waitForLoaderToAppearAndDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOMacmillanCalculus);
		test.projectView.VerifyFrameWorkTableIsDisplayed();
		test.projectView.VerifyFrameworkHeaderIsDisplayed();

	}

	// 13.Verify that user can clear the Search text box field by clicking on the
	// cross icon
	// BS-2258
	@Test(priority = 14)
	public void Verify_That_User_Can_Clear_Search_Text_Box_By_Clicking_Cross_Icon() {
		test.refreshPage();
		test.projectView.waitForLoaderToAppearAndDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.EnterTextIntoLOF_SearchBox(LOMacmillanCalculus);
		test.projectView.ClickCrossIconOnLOF_SearchBox();

		test.HomePage.ClickContentTab(); //// For Content View Page...
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.EnterTextIntoLOF_SearchBox(LOMacmillanCalculus);
		test.ContentView.ClickCrossIconOnLOF_SearchBox();
	}

	// 14.Verify that user is allowed to enter any term in the search box
	// BS-2258
	@Test(priority = 15)
	public void Verify_That_User_Is_Allowed_To_Enter_Any_Term_In_Search_Box() {

		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.EnterTextIntoLOF_SearchBox("m");
		test.ContentView.VerifySuggesationBoxDisplayedIn_LOF_Section();

		test.refreshPage(); /// For Project View Page////
		test.HomePage.waitForLoaderToAppearAndDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.EnterTextIntoLOF_SearchBox("m");
		test.projectView.VerifySuggesationBoxDisplayedIn_LOF_Section();
	}

	// 15.Verify that deletion of framework will not be possible if at least one
	// LO-statement is added - warning message "You can not delete a framework if
	// some LO statements are associated."
	// BS-2258
	@Test(priority = 16)
	public void Verify_Deletion_Of_Framework_Is_Not_possible_If_At_Least_One_LO_Statement_Is_Added() {
		test.refreshPage();
		test.HomePage.waitForLoaderToAppearAndDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnAddingLearningObjectiveStatement();
		test.ContentView.RemoveFameworkFromContentWithoutMessage(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkCanNotBeRemovedMessageIsDisplayed();
		test.ContentView.RemoveLOS_Statement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnRemovingLearningObjectiveStatement();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.VerifyMessageDispalyedOnRemovingFamework();
	}

	// 16.Verify that a new section Learning Objective Framework is displayed.
	// BS- 2259
	@Test(priority = 17)
	public void Verify_New_Section_Learning_Objective_Framework_Is_Displayed() {
		test.refreshPage();
		test.HomePage.waitForLoaderToAppearAndDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickLearningObjectives();
		test.ContentView.LearningObjectiveFrameworkSectionIsDisplayed();
	}

	// 17.Verify that instant search for searching the LO from the LOF
	// BS- 2259
	@Test(priority = 18)
	public void Verify_Instant_Search_For_LO_From_The_LOF() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.EnterTextIntoLOF_SearchBox("m");
		test.ContentView.VerifySuggesationBoxDisplayedIn_LOF_Section();
	}

	// 18.Verify that Learning Objective Statements section displays the list of LOS
	// depending upon the selected framework in Learning Objective Frameworks
	// section
	// BS- 2259
	@Test(priority = 19)
	public void Verify_Learning_Objective_Statements_Section_Displays_List_Of_LOS() {
		test.refreshPage();
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.verifyLOS_SectionIsDisplayed();
		test.ContentView.VerifyLearningObjectiveStatementIsDisplayedInsuggestion(MacStatement);
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.VerifyMessageDispalyedOnRemovingFamework();
	}

	// 19.Verified that the LOS section is not available when LOF is not added,
	// hence Add button is not displayed
	// BS- 2259
	@Test(priority = 20)
	public void Verify_LOS_Section_Is_Not_Available_When_LOF_Is_Not_Added() {
		test.refreshPage();
		test.HomePage.waitForLoaderToAppearAndDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();
		test.ContentView.VerifyLOS_IsNotDisplayed();
	}

	// 20.Verify that only the Learning objective statements are available in the
	// search list not the levels
	// BS- 2259
	@Test(priority = 21)
	public void Verify_Only_Learning_Objective_Statements_Are_Available_In_Search_List_Not_Levels() {
		test.refreshPage();
		test.HomePage.waitForLoaderToAppearAndDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.LevelsAreNotDisplayedInLOS(MacStatement);
	}

	// 21."Verify that below column headers are available in the LOS table Name
	// Domain Level Action"
	// BS- 2259
	@Test(priority = 22)
	public void Verify_Column_Headers_Are_Available_In_The_LOS_Table() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnAddingLearningObjectiveStatement();
		test.ContentView.VerifyLOS_TableHeaders();
	}

	// 22.Verify that Delete icon is displayed under Action column under LOS
	// section. Clicking the same deletes the added Learning objective statement
	// BS- 2259
	@Test(priority = 23)
	public void Verify_Delete_Icon_Is_Displayed_Under_Action_Column_Clicking_The_Same_Deletes_LOS() {
		test.ContentView.VerifyLearningObjectiveStatementAdded(MacStatement);
		test.ContentView.RemoveLOS_Statement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnRemovingLearningObjectiveStatement();
		test.ContentView.VerifyLearningObjectiveStatementIsNotDisplayed(MacStatement);
	}

	// 23.Verify that cross button in the search box will help to clear out the text
	// in the search field
	// BS- 2259
	@Test(priority = 24)
	public void Verify_Cross_Button_In_Search_Box_Will_Clear_Out_The_Text_In_The_Search_Field() {
		test.ContentView.EnterTextInLOS_SearchBox(MacStatement);
		test.ContentView.ClickCrossIconOnLOS_SearchBox();
	}

	// 24. Verify that Add button remains disabled when there is no text in the
	// Search box
	// BS- 2259
	@Test(priority = 25)
	public void Verify_Add_Button_Remains_Disabled_When_There_Is_No_Text_In_The_Search_Box() {
		test.ContentView.EnterTextInLOS_SearchBox(" ");
		test.ContentView.VerifyLOS_AddButtonDisabled();

	}

	// 25.Verify that Add button gets active only when the complete name of the LOS
	// is present in the search box
	// BS- 2259
	@Test(priority = 26)
	public void Verify_Add_Button_Gets_Active_Only_When_Complete_Name_Of_LOS_Is_Present() {
		test.ContentView.EnterTextInLOS_SearchBox(MacStatement);
		test.ContentView.VerifyLOS_AddButtonEnable();
	}

	// 26.Verify that warning message is displayed when the entered term in search
	// box does not matches with any result
	// BS- 2259
	@Test(priority = 27)
	public void Verify_Warning_Message_Is_Displayed_When_Entered_Term_Does_Not_Matches_With_Any_Result() {
		test.ContentView.EnterTextIntoLOF_SearchBox("1234");
		test.ContentView.VerifyWarningMessageDisplayedInLOFSection();
	}

	// 27.Verify that nothing happens on pressing/hitting ENTER when no framework is
	// associated with the content
	// BS-2344
	@Test(priority = 28)
	public void Verify_Nothing_Happens_On_Pressing_Or_Hitting_ENTER_When_No_Framework_Is_Associated() {
		test.refreshPage();
		test.HomePage.waitForLoaderToAppearAndDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.EnterTextIntoLOF_SearchBox("");
		test.ContentView.PressEnterOnLOF_Search();
		test.ContentView.Verify_No_Message_Is_Displayed_On_Pressing_The_Enter();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus); // Verify Framework is notDeleted...
	}

	// 28.Verify that no message displays on pressing/hiting ENTER in LOF section
	// when Statement is associated with the content
	@Test(priority = 29)
	public void Verify_Nothing_Happens_On_Pressing_Or_Hitting_ENTER_In_LOF_Section_When_Statement_Is_Associated() {
		test.ContentView.AddLearningObjectiveStatement(MacStatement);
		test.ContentView.VerifyLearningObjectiveStatementAdded(MacStatement);
		test.ContentView.EnterTextIntoLOF_SearchBox("");
		test.ContentView.PressEnterOnLOF_Search();
		test.ContentView.Verify_No_Message_Is_Displayed_On_Pressing_The_Enter();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus); // Verify Framework is not Deleted...
		test.ContentView.VerifyLearningObjectiveStatementAdded(MacStatement); // Verify Statement is not Deleted...
	}

	// 29.Verify that no message displays on pressing/hiting ENTER in LOS section
	// when Statement is associated with the content
	@Test(priority = 30)
	public void Verify_Nothing_Happens_On_Pressing_Or_Hitting_ENTER_In_LOS_Section_When_Statement_Is_Associated() {
		test.ContentView.EnterTextInLOS_SearchBox("");
		test.ContentView.Verify_No_Message_Is_Displayed_On_Pressing_The_Enter();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus); // Verify Framework is not Deleted...
		test.ContentView.VerifyLearningObjectiveStatementAdded(MacStatement); // Verify Statement is not Deleted...
	}

	// 30.Verify that the timestamps for a published asset is displaying same in
	// Project view as well as in Content view.
	// BS-1998
	@Test(priority = 31)
	public void Verify_Timestamps_For_Published_Asset_Is_Displaying_Same_In_Project_And_Content_View() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN1+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN1);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.VerifyTimeStampsForPublishedFlatEpubIsSame(PublihDestinationCoreSource, ISBN1);
	}

	// 31.Verify by publishing the assets to Palgrave publish destination
	// BS-1998
	@Test(priority = 32)
	public void Verify_Timestamps_For_Published_Asset_To_Palgrave_Publish_Destination() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN1+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN1);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.VerifyTimeStampsForPublishedFlatEpubIsSame(PublihDestinationPalgrave, ISBN1);
	}

	// 32.Verify by publishing the assets to Courseware publish destination
	// BS-1998
	@Test(priority = 33)
	public void Verify_Timestamps_For_Published_Asset_To_Courseware_Publish_Destination() {
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(DAMRepository,TypesOfContentInstructorResources,DamContent,true);
		test.projectView.Select_Assert_Displayed_In_Step3(DamContent);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.VerifyTimeStampsForPublishedContentIsSame(PublihDestinationCourseWare, DamContent);
	}

	// 33.Verify by publishing the assets to VitalSource publish destination
	// BS-1998
	@Test(priority = 34)
	public void Verify_Timestamps_For_Published_Asset_To_VitalSource_Publish_Destination() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN1+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN1);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.VerifyTimeStampsForPublishedFlatEpubIsSame(PublihDestinationVitalSource, ISBN1);
	}

	// 34.Verify that Content Type > Content Subtype has been updated in Content
	// view page> Content details tab
	// BS-2235
	@Test(priority = 35)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Content_Details_Tab() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN1+"_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentSubtypeInContentView(TypesOfContentFlatEpub);

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1+".epub");
		test.Contentpage.opentheSearchContent(ISBN1+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentSubtypeInContentView(TypesOfContentEnhancedEpub);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.FilterContent(TypeOfContentFlatBatchEpub);
		test.projectView.ClickOpenAssetOnProjectView(BatchEpubISBN+"_EPUB.epub",TypeOfContentFlatBatchEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentSubtypeInContentView(TypeOfContentFlatBatchEpub);

		test.ContentView.navigateBack();
		test.projectView.waitForLoaderToAppearAndDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.FilterContent(TypesOfContentBatchEnhanced);
		test.projectView.ClickOpenAssetOnProjectView(BatchEpubISBN+".epub",TypesOfContentBatchEnhanced);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentSubtypeInContentView(TypesOfContentBatchEnhanced);

	}

	// 35.Verify that Content Type > Content Subtype has been updated in Content
	// view page> Publish window> Step 3
	// BS-2235
	@Test(priority = 36)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Step3_Publish_Window() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyContentTypeInPublishWindow(TypesOfContentBatchEnhanced);

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.FilterContent(TypeOfContentFlatBatchEpub);
		test.projectView.ClickOpenAssetOnProjectView(BatchEpubISBN+"_EPUB.epub",TypeOfContentFlatBatchEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyContentTypeInPublishWindow(TypeOfContentFlatBatchEpub);

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1+".epub");
		test.Contentpage.opentheSearchContent(ISBN1+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyContentTypeInPublishWindow(TypesOfContentEnhancedEpub);

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN1+"_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyContentTypeInPublishWindow(TypesOfContentFlatEpub);
	}

	// 36.Verify that Content Type > Content Subtype has been updated in Content
	// view page> Push to Authoring tool window
	// BS-2235
	@Test(priority = 37)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Push_To_Authoring_Tool() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN1+"_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyContentSubtypeInPushToAuthoringToolGridView(TypesOfContentFlatEpub);
		test.ContentView.ClickCloseIconOnPushToAuthoringTool();

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1+".epub");
		test.Contentpage.opentheSearchContent(ISBN1+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPushToAuthoringTool();
		test.ContentView.VerifyContentSubtypeInPushToAuthoringToolGridView(TypesOfContentEnhancedEpub);
		test.ContentView.ClickCloseIconOnPushToAuthoringTool();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.FilterContent(TypeOfContentFlatBatchEpub);
		test.projectView.ClickOpenAssetOnProjectView(BatchEpubISBN+"_EPUB.epub",TypeOfContentFlatBatchEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPushToAuthoringTool();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyContentSubtypeInPushToAuthoringToolGridView(TypeOfContentFlatBatchEpub);
		test.ContentView.ClickCloseIconOnPushToAuthoringTool();

		test.ContentView.navigateBack();
		test.projectView.waitForLoaderToAppearAndDisappear();
		test.projectView.verifyOnProjectView();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.FilterContent(TypesOfContentBatchEnhanced);
		test.projectView.ClickOpenAssetOnProjectView(BatchEpubISBN+".epub",TypesOfContentBatchEnhanced);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPushToAuthoringTool();
		test.ContentView.VerifyContentSubtypeInPushToAuthoringToolGridView(TypesOfContentBatchEnhanced);
	}

	// 37."Verifiy that user is able to check the Projects displaying under
	// 'Selected' section and can move them to 'Available' section by clicking the
	// 'Unselect button for following workflows: a) When Project ISBNs are already
	// associated"
	// BS-1997
	@Test(priority = 38)
	public void Verify_User_Is_Able_To_Move_Content_From_Selected_To_Available_Section_When_ISBNs_Already_Associated() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.ClickOpenAssetOnProjectView(ISBN1+"_CFI.csv",ContentTypeCFI);
		test.projectView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.SelectProjectInSelectedPane(ISBN1);
		test.ContentView.ClickUnselectButton();
		test.ContentView.VerifyProjectNotDisplayedInSelectedPane(ISBN1);
	}

	// 38."Verify that the Table column header has been renamed to 'CMS Project
	// Status' from 'Project Status' for below workflows: c) Content view page>
	// More> View Usage Details"
	// BS-2212
	@Test(priority = 39)
	public void Verify_The_Table_Column_Header_Has_Been_Renamed_To_CMS_Project_Status() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewUsageDetails();
		test.ContentView.VerifyViewUsageDetailPopUpDisplay();
		test.ContentView.VerifyColoumOfUsageDetailPopUp();
	}

	// 39."Content view page> Download Content functionality for following cases: a)
	// Single CMS Asset: Download starts right away"
	// BS-2529
	@Test(priority = 40)
	public void Verify_For_Content_View_When_Downloading_Single_CMS_Asset_No_Toaster_Message_And_Download_Is_Started() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickDownloadContent();
		test.Contentpage.VerifyMessageNotDisplayedOnDownloadingContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN + ".epub");
	}

	// 40."Content view page> Download Content functionality for following cases: b)
	// Single Non CMS Asset: Toaster message is displayed and download link is
	// received."
	// BS-2529
	@Test(priority = 41)
	public void Verify_For_Content_View_When_Downloading_Single_Non_CMS_Asset_Toaster_Message_Is_Displayed() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "");
	}

	// 41.Verify that New content type is displaying in Content view page
	// BS-2394
	@Test(priority = 42)
	public void Verify_Marketing_Content_Author_Image_Displayed_In_Content_View() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentSubtypeInContentView(TypeOfContentMarketingAuthorImage);
	}

	// 42.Verify that user is navigated to Publish window while the Content view for
	// the same is active in background after clicking the Upload button in the pop
	// up.
	// BS-2583
	@Test(priority = 43)
	public void Verify_User_Is_Navigated_To_Publish_Window_In_Content_View_After_Uploading_Marketing_Content() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(DMS_Email);
		test.loginpage.enterUserPassword(DMS_Password);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingAuthorImage);
		test.HomePage.SelectImageFileUsingBrowseButton(ISBN);
		test.HomePage.EnterTextInAuthorField(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId), true);
		test.HomePage.VerifySuggestionforAuthorNameDisplayedInUploadContent();
		test.HomePage.SelectAuthorName(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
		test.HomePage.EnterTextIntoTitleField(MarketingAuthorSampleImage);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyPublishPopUpDisplayed();
	}

	// 43.Verify that 'Instructor Store' is selected as the Publish destination by
	// default.
	// BS-2583
	@Test(priority = 44)
	public void Verify_Instructor_Store_Is_Selected_As_Default() {
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
	}

	// 44."Verify that in Step 2 following is getting displayed:
	// 1) Image preview
	// 2) Author Name - Last Name, First Name, Author Key"
	// BS-2583
	@Test(priority = 45)
	public void Verify_Author_Image_And_Author_Name_Key_In_Step2_Publish_Window() {
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyAuthorImageInStep2PublishWindow();
		test.ContentView
				.VerifyAuthorNameAndIdInStep2PublishWindow(test.HomePage.CombineAuthorNameAndId(AuthorName, AuthorId));
	}

	// 45.Verify that success message is getting displayed when user hits the
	// Publish button after approving the asset
	// BS-2583
	@Test(priority = 46)
	public void Verify_Success_Message_Is_Displayed_After_Publishing() {
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 46.Verify that error message appears if user hits the Publish button without
	// approving the content
	// BS-2583
	@Test(priority = 47)
	public void Verify_Error_Message_Is_Displayed_On_Publishing_Unapprove_Asset() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsNotPublished();
	}

	// 47.Verify that user is navigated back to Content view after publishing the
	// asset
	// BS-2583
	@Test(priority = 48)
	public void Verify_User_on_Content_View_Page() {
		test.ContentView.VerifyOnContentViewPage();
	}

	// 48.Verify that user can click outside the Publish window anytime and this
	// action closes the Publish window
	// BS-2583
	@Test(priority = 49)
	public void Verify_publish_Window_Closes_On_Cliking_Outside_Publish_Window() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.ClickContentView();
		test.ContentView.VerifyPublishPopIsClosed();
	}

	// 49.Verify that user is able to Edit the Asset's Title and Description after
	// the Upload action from Content page view
	// BS-2583
	@Test(priority = 50)
	public void Verify_Able_To_Edit_The_Asset_Title_And_Description_After_The_Upload_Action() throws IOException {

		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(NewTitle);
		test.ContentView.EditAssetDetail();
		test.ContentView.VerifyTitleIsEdited();
		test.ContentView.VerifyDetailUpdated();
	}

	// 50."Verify that user is able to Search for Author Image from:
	// 1) Generic Search
	// 2) Advanced Search"
	@Test(priority = 51)
	public void Verify_User_Is_Able_To_Search_For_Author_Image() {
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(NewTitle);
		test.Contentpage.opentheSearchContent(NewTitle);
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.EnterTextIntoSearchBox(NewTitle);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.SelectAssetOnSearchPage(NewTitle);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}