package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_View_Tab_Ticket_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, NonAdminEmail, NonAdminPassword,
			PublihDestinationVitalSource;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare,
			PublihDestinationCatalog, ISBN2, DamContent;
	String DownloadStartMsg, ISBNwithoutEnhancedEpub;
	String OrganisedDownloadMsg, LOMacmillanCalculus, LoPrinciplesOfEconomics, LoPrinciplesOfMacroeconomics,
			PrinciplesOfMicroeconomics;
	String TypesOfContentEnhancedEpub, TypesOfContentFlatEpub, TypesOfContentBatchEnhanced, TypesOfContentBatchFlat;
	String TypeOfContentMarketingAuthorImage, MarketingAuthorImage, PageSelectionAllPages, PageSelectionNone,TypesOfContentInstructorResources;
	String CMSRepository,DAMRepository,ContentTypeCoverDesign;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		ISBNwithoutEnhancedEpub = getData("ProjectWithoutEnhanceEpub");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationCatalog = getData("PublishDestination.Catalog");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		DamContent = getData("DamContent");
		DownloadStartMsg = getData("DownloadStartMsg");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsgProjectView");
		LOMacmillanCalculus = getData("Framework.macmillan calculus");
		LoPrinciplesOfEconomics = getData("Framework.Principles of Economics");
		LoPrinciplesOfMacroeconomics = getData("Framework.Principles of Macroeconomics");
		PrinciplesOfMicroeconomics = getData("Framework.Principles of Microeconomics");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentBatchEnhanced = getData("TypesOfContent.Enhanced ePub > Batch");
		TypesOfContentBatchFlat = getData("TypesOfContent.Flat ePub > Batch");
		ContentTypeCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		MarketingAuthorImage = getData("MarketingAuthorImage");
		PageSelectionAllPages = getData("PageSelection.All Pages");
		PageSelectionNone = getData("PageSelection.None");
		TypesOfContentInstructorResources=getData("TypesOfContent.Supplementary Content>Instructor Resources");
		CMSRepository=getData("Repository.CMS");
		DAMRepository=getData("Repository.DAM");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that hyperlink in filename is disabled when user tries to push to
	// the authoring tool through project view page
	// BS-2013
	@Test(priority = 2)
	public void Verify_Hyperlink_In_Filename_Is_Disable_In_Push_To_The_Authoring_Tool() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyHyperLinkDisabledInPushToAuthoringTool();
	}

	// 2.Verify that the step 3 label name reads as 'Step 3: Select Project ISBN and
	// / or Push' in Push to authoring tool window in Project View
	// BS-1916
	@Test(priority = 3)
	public void Verify_Correct_Label_Is_Displayed_In_Step3_Of_Push_To_Authoring_Tool() {
		test.projectView.VerifyStep3LabelOfPushToAuthoringTool();
	}

	// 3.Verify that only a single result is displayed when user searches with exact
	// 13 digit ISBN in Add / Remove Project pop-up from Upload content workflow via
	// PROJECT VIEW
	// BS-1653
	@Test(priority = 4)
	public void Verify_In_Add_Content_To_Project_Only_A_Single_Result_Is_Displayed_For_Exact_13_Digit_ISBN_In_Project_View() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.ClickAddRemoveProject();
		test.projectView.VerifyAddtoProjectpopUp();
		test.projectView.SearchProjectInAddRemovePopUp(ISBN2);
		test.projectView.VerifyOneProjectDisplayedOnAddRemoveProject();
	}

	// 4.Verify that the message appear when user performs the Organized download
	// via Project view
	// BS-1582
	@Test(priority = 5)
	public void Verify_Message_On_Organized_Download_Via_Project_View() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		int Count = test.projectView.GetCountOfNumberOfAssetAssociatedToProject();
		test.projectView.clickTopLinkMore();
		test.projectView.clickOrganisedDownload();
		test.projectView.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.projectView.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, Count);
	}

	// 5.Verify that 3 buttons are appearing when destination is selected as
	// Courseware in Publish popup
	// BS-2050
	@Test(priority = 6)
	public void Verify_3_Buttons_Are_Appearing_In_Publish_PopUp_For_Courseware() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyMetadataButtonsOnCourseware();

	}

	// 6.Verify that the tagged Instructor or Student metadata is getting removed
	// successfully on clicking the 'Clear Access-Level Metadata'
	// BS-2050
	@Test(priority = 7)
	public void Verify_On_Clicking_The_Clear_Access_Level_Metadata_Tagged_Metadata_Is_Removed() {
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub");
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToInstructorResource();
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.VerifyAssertAreRemovesFromInstructorOrStudentResource();
	}

	// 7."Verify that below message appears under the tree repository on clicking
	// the 'Clear Access-Level Metadata' button (provided that some asset is
	// selected). X asset/s cleared from Instructor / student Resource type."
	// BS-2050
	@Test(priority = 8)
	public void Verify_Message_Appers_on_Clicking_Clear_Access_Level_Metadata() {
		//test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub");
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.VerifyAssertAreRemovesFromInstructorOrStudentResource();
	}

	// 8.Verify that 'i' or 's' badges get removed from the left of the asset name
	// after clicking the 'Clear Access-Level Metadata' button
	// BS-2050
	@Test(priority = 9)
	public void Verify_I_S_Badges_Get_Removed_From_The_Left_Of_Asset_Clicking_Clear_Access_Level_Metadata() {
		test.refreshPage();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub");
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToInstructorResource();
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(ISBN + "_EPUB.epub");
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.VerifyAssertAreRemovesFromInstructorOrStudentResource();
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert(ISBN + "_EPUB.epub");

		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(ISBN + "_EPUB.epub");
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.VerifyAssertAreRemovesFromInstructorOrStudentResource();
		test.projectView.Verify_S_Badge_Is_Not_Dispalyed_On_Assert(ISBN + "_EPUB.epub");
	}

	// 9.Verified that if user has tagged an asset with Instructor/ Student metadata
	// > Selects it to publish in 'Manual publish' tab > Moves to 'Update Content
	// Metadata' tab and removes the Instructor/ Student metadata for that asset> In
	// Step 3, message appears 'Please select only Supplementary Content>Instructor
	// / Student Resources'
	// BS-2050
	@Test(priority = 10)
	public void Verify_That_Only_Tagged_Asset_Can_Be_Published() {
		test.projectView.ClickManualPublish();
		test.projectView.VerifySelectOnlyInstructorOrStudentResourcesMessageIsDisplayed();

		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub");
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToInstructorResource();
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(ISBN + "_EPUB.epub");

		test.projectView.ClickManualPublish();
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub",true);
		test.projectView.VerifySelectOnlyInstructorOrStudentResourcesMessageIsNotDisplayed();
	}

	// 10.Verify that 'i' and 's' badges are displaying by default for the
	// Supplementary content> Instructor/ Student resource assets depending upon the
	// content type provided from DAM side only when 'Courseware' is selected in the
	// Publish window
	// BS-2221
	@Test(priority = 11)
	public void Verify_I_Or_S_Badges_Are_Displayed_By_Default_For_Supplementary_Content() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(DAMRepository,TypesOfContentInstructorResources,DamContent,true);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(DamContent);
	}

	// 11.Verify that user is not able to modify the metadata for the default
	// Instructor/ Student resource i.e. not able to overwrite the metadata
	// BS-2221
	@Test(priority = 12)
	public void Verify_User_Is_Not_Able_To_Modify_Metadata_For_Default_Instructor_Or_Student_Resource() {
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(DAMRepository,TypesOfContentInstructorResources,DamContent);
	}

	// 12.Verify that 'Learning Objective' is appearing as a subtab in Project view
	// BS- 2257
	@Test(priority = 13)
	public void Verify_Learning_Objective_Tab_Is_Appearing_As_A_subtab() {
		test.refreshPage();
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyLearningObjectiveTabDisplayed();
	}

	// 13.Verify that Searchbox is displaying under the Learning objective tab in
	// Project View .
	// BS-2257
	@Test(priority = 14)
	public void Verify_Searchbox_Displayed_Under_The_Learning_Objective_In_Project_View() {
		test.projectView.clickLearningObjectives();
		test.projectView.VerifySearchBoxDisplayedForLO();
	}

	// 14.Verify that user can only add the LOF to the Project. There is no section
	// available for LOS.
	// BS-2257
	@Test(priority = 15)
	public void Verify_User_Can_Only_Add_LOF_To_Project_And_LOS_Is_Not_Displayed() {
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyLOS_IsNotDisplayed();
	}

	// 15.Verify that Add button remains disabled when there is no text in the
	// Search box
	// BS-2257
	@Test(priority = 16)
	public void Verify_Add_Button_Remains_Disabled_When_There_Is_No_Text_In_The_Search_Box() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.EnterTextIntoLOF_SearchBox(" ");
		test.projectView.VerifyLOF_AddButtonDisabled();

		test.HomePage.ClickContentTab(); //// For Content View Page...
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.EnterTextIntoLOF_SearchBox(" ");
		test.ContentView.VerifyLOF_AddButtonDisabled();
	}

	// 16.Verify that Add button becomes active as soon as the Framework is selected
	// from the list.
	// BS-2257
	@Test(priority = 17)
	public void Verify_Add_Button_Becomes_Active_As_Soon_As_Framework_Is_Selected() {
		test.refreshPage();
		test.ContentView.waitForLoaderToAppearAndDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.EnterTextIntoLOF_SearchBox(LOMacmillanCalculus);
		test.ContentView.SelectTheFrameWorkFromSuggestionBox(LOMacmillanCalculus);
		test.ContentView.VerifyLOF_AddButtonEnable();

		test.HomePage.clickProjectTab(); ///// For Project View Page
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.SelectTheFrameWorkFromSuggestionBox(LOMacmillanCalculus);
		test.projectView.VerifyLOF_AddButtonEnable();
	}

	// 17.Verify that all Assets are selected in Section 3 when assets are of more
	// than 1 page
	// BS-2098
	@Test(priority = 18)
	public void VVerify_User_Is_Able_To_Select_All_The_Assets_Displayed_In_Step_3_Of_Publish_Window() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.VerifyAllTheAssetsAreSelectedToPublishInStep3();
	}

	// 18.Verify that selected assets remain selected even after navigating to other
	// page
	// BS-2098
	@Test(priority = 19)
	public void Verify_Selected_Assets_Remain_Selected_Even_After_Navigating_To_Other_Page() {
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyAllTheAssetsAreSelectedInStep3AfterNavigatingToOtherPage();
	}

	// 19.Verify that all assts are deselcted on unchecking select all checkbox
	// BS-2098
	@Test(priority = 20)
	public void Verify_All_Assts_Are_Deselcted_On_Unchecking_Select_All_Checkbox() {
		test.refreshPage();
		test.projectView.waitForLoaderToAppearAndDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionNone); // To_Deselcted_All_Assts
		test.projectView.VerifyAllTheAssetsAreDeselctedToPublishInStep3();
	}

	// 20.Verify that user user can select multiple Assets across the pages
	// available (without using Select All) and the selection made is maintained
	// across the pages
	// BS-2098
	@Test(priority = 21)
	public void Verify_User_Can_Select_Multiple_Assets_Across_The_Pages_Available() {
		test.projectView.ClickPageNumberInStep3OfPublishWindow(1);
		test.projectView.SelectMultipleAssertInStep3PublishWindow(2);
		test.projectView.ClickPageNumberInStep3OfPublishWindow(2);
		test.projectView.ClickPageNumberInStep3OfPublishWindow(1);
	}

	// 21.Verify that only the selected Assets can be Approved/ Unapproved
	// BS-2098
	@Test(priority = 22)
	public void Verify_Only_The_Selected_Assets_Can_Be_Approved_Unapproved() {
		test.projectView.VerifyStatusOfContentsInStep3OfPublishWindow();
	}

	// 22.Verify that Adding a LOF in Project view is getting displayed under
	// Learning Objectives tab for the Content view as well
	// BS-2277
	@Test(priority = 23)
	public void Verify_LOF_Added_To_The_Project_Reflects_In_Each_Associated_Content() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOMacmillanCalculus);
		test.projectView.VerifyFrameWorkIsAddedToAssociatedContent(LOMacmillanCalculus);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
	}

	// 23.Verify that Removing the added LOF from Project view is not getting
	// removed from the Content view
	// BS-2277
	@Test(priority = 24)
	public void Verify_Removing_LOF_From_Project_View_Is_Not_Removed_From_The_Content_View() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN+"_EPUB.epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);

		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);

		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN+"_EPUB.epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
	}

	// 24.Verify that Adding a LOF in Content view is not reflected in the Project
	// view
	// BS-2277
	@Test(priority = 25)
	public void Verify_LOF_Added_In_Content_View_Is_Not_Reflected_In_Project_View() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);

		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.verifyFrameworkIsNotAddedToProjectView(LOMacmillanCalculus);

	}

	// 25.Verify that LOF that are inherited by Content view from the Project view
	// continues to display in Content view though the content has been
	// un-associated from that Project.
	// BS-2277
	@Test(priority = 26)
	public void Verify_LOF_Inherited_By_Content_View_Continues_To_Display_After_Unassociated_From_Project() {
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOMacmillanCalculus);

		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_FC.jpg",ContentTypeCoverDesign);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);

		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN);
	}

	// 26.Verify that On the event of multiple association of a single asset with
	// multiple projects: Adding LOF to any project displays in the that Content's
	// Content view as well. In case of same LOF, they appear only once in Content
	// view.
	// BS-2277
	@Test(priority = 27)
	public void Verify_If_Asset_Has_Multiple_Projects_Association_LOF_Added_To_Project_Displays_in_Content_View() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN+"_FC.jpg");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();

		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN2);

		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);

		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromContent(LoPrinciplesOfEconomics);
		test.projectView.AddLearningObjective(LoPrinciplesOfEconomics);

		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_FC.jpg",ContentTypeCoverDesign);
		test.projectView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LoPrinciplesOfEconomics);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.RemoveContentFromProject(ISBN2);

	}

	// 27.Verify that All the LOF that are added in that Project automatically
	// appears in the content view as soon as that content is associated with the
	// Project
	// BS-2277
	@Test(priority = 28)
	public void Verify_All_LOF_Added_To_Project_Automatically_Appears_In_Content_View_Associated_To_Project() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();
		test.projectView.AddLearningObjective(LoPrinciplesOfEconomics);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_FC.jpg",ContentTypeCoverDesign);
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();

		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LoPrinciplesOfEconomics);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);

	}

	// 28.Verify that Associating a Content with a Project (both have the same LOF
	// earlier) : LOF is appearing only once i.e. no duplicacy is observed
	// BS-2277
	@Test(priority = 29) // Dependent on Test cases 27
	public void Verify_Associating_A_Content_With_Project_Added_LOF_Is_Appearing_Only_once() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.RemoveContentFromProject(ISBN);

		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN);

		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyNoDublicateFrameworkIsDisplayed();

		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 29.Verify that Associating a Content with a Project (both have different LOF
	// earlier) : LOF is appearing as clubbed.
	// BS-2277
	@Test(priority = 30)
	public void Verify_Associating_Content_With_Project_LOF_Appearing_As_Clubbed() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();
		test.projectView.AddLearningObjective(LoPrinciplesOfMacroeconomics);
		test.projectView.AddLearningObjective(PrinciplesOfMicroeconomics);

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN+"_FC.jpg");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();
		test.ContentView.AddLearningObjective(LoPrinciplesOfEconomics);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN2);

		test.refreshPage();
		test.ContentView.waitForLoaderToAppearAndDisappear();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyNoDublicateFrameworkIsDisplayed();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LoPrinciplesOfEconomics);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LoPrinciplesOfMacroeconomics);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(PrinciplesOfMicroeconomics);
	}

	// 30.Verify that On the event of multiple association of a single asset with
	// multiple projects: The LOF already added to all the Projects are appearing in
	// the associated Content's Content view. In case of same LOF, they appear only
	// once in Content view.
	// BS-2277
	@Test(priority = 31)
	public void Verify_LOF_Of_Both_The_Project_Are_Displayed_To_The_Content_Associated() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN+"_FC.jpg");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();

		test.ContentView.ClickAddRemoveProject();// Adding Content to Both the project...
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN2);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();
		test.projectView.AddLearningObjective(LoPrinciplesOfEconomics);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LoPrinciplesOfEconomics);
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOMacmillanCalculus);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();
		test.projectView.AddLearningObjective(LoPrinciplesOfMacroeconomics);
		test.projectView.AddLearningObjective(PrinciplesOfMicroeconomics);

		test.HomePage.ClickContentTab(); /// Verifying Framework has been added to Content
		test.Contentpage.SearchForAnItem(ISBN+"_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN+"_FC.jpg");
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyNoDublicateFrameworkIsDisplayed();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LoPrinciplesOfEconomics);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LoPrinciplesOfMacroeconomics);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(PrinciplesOfMicroeconomics);

		test.ContentView.ClickAddRemoveProject();// Adding Content to Both the project...
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.RemoveContentFromProject(ISBN2);
	}

	// 31.Verify that push to authoring tool pop has modified GUI
	@Test(priority = 32)
	public void Verify_Modified_GUI_Of_Push_To_Authoring_Tool_PopUp() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		int AssetCount = test.projectView.GetAssetCountOnProjectViewForFlatAndEnhancedEpub();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifySubCategoriesInPushToAuthoringTool();
		test.projectView.verifyPaginationBarOnPushToAuthoringTool(AssetCount);
		test.projectView.ClickOtherOnPushToAuthoringTool();
		test.projectView.VerifyContentAreDisplayedInPushToAuthoringtool();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyEpubsOnlyRadioSelectedOnPushToAuthoringTool();
		test.projectView.VerifyLabelsForContentsOnPushToAuthoringTool();

	}

	// 32.Verify that Content Type > Content Subtype has been updated in Project
	// view page> Upload Content
	// BS-2235
	@Test(priority = 33)
	public void Verify_Content_Subtype_Has_Been_Updated_In_ProjectView_Upload_Content() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentEnhancedEpub);
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentFlatEpub);
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentBatchEnhanced);
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentBatchFlat);
	}

	// 33.Verify that Content Type > Content Subtype has been updated in Project
	// view page> Associated Content section
	// BS-2235
	@Test(priority = 34)
	public void Verify_Content_Subtype_Has_Been_Updated_In_ProjectView_Associated_Content() {
		test.refreshPage();
		test.projectView.verifyOnProjectView();
		test.projectView.FilterContent(TypesOfContentEnhancedEpub);
		test.projectView.VerifyContentTypeInAssociatedContent(TypesOfContentEnhancedEpub);
		test.projectView.FilterContent(TypesOfContentFlatEpub);
		test.projectView.VerifyContentTypeInAssociatedContent(TypesOfContentFlatEpub);
		test.projectView.FilterContent(TypesOfContentBatchEnhanced);
		test.projectView.VerifyContentTypeInAssociatedContent(TypesOfContentBatchEnhanced);
		test.projectView.FilterContent(TypesOfContentBatchFlat);
		test.projectView.VerifyContentTypeInAssociatedContent(TypesOfContentBatchFlat);
	}

	// 34.Verify that Content Type > Content Subtype has been updated in Project
	// view page> Publish window> Step 2 & Step 3
	// BS-2235
	@Test(priority = 35)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Publish_Window_Step2_And_Step_3() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyContentTypeDisplayedInStep2PublishWindow(TypesOfContentEnhancedEpub);
		test.projectView.VerifyContentTypeDisplayedInStep2PublishWindow(TypesOfContentFlatEpub);
		test.projectView.VerifyContentTypeDisplayedInStep2PublishWindow(TypesOfContentBatchEnhanced);
		test.projectView.VerifyContentTypeDisplayedInStep2PublishWindow(TypesOfContentBatchFlat);

		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentEnhancedEpub,ISBN+".epub",true);
		test.projectView.VerifyContentTypeDisplayedInStep3PublishWindow(TypesOfContentEnhancedEpub);

		test.projectView.ClickCloseButton();
		test.projectView.clickpublishLink();

		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub",true);
		test.projectView.VerifyContentTypeDisplayedInStep3PublishWindow(TypesOfContentFlatEpub);
	}

	// 35.Verify that Content Type > Content Subtype has been updated in Project
	// view page> Push to Authoring tool window
	// BS-2235
	// @Test(priority=36)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Push_To_Authoring_Tool_Window() {
		//////////////////// TO Automate//////////////////////
	}

	// 36.Verify that Content Type > Content Subtype has been updated in Project
	// view page> Filter Associated content section
	// BS-2235
	@Test(priority = 37)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Filter_Content_Section() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.FilterContent(TypesOfContentEnhancedEpub);
		test.projectView.FilterContent(TypesOfContentFlatEpub);
		test.projectView.FilterContent(TypesOfContentBatchEnhanced);
		test.projectView.FilterContent(TypesOfContentBatchFlat);
	}

	// 37.Verify that Content Type > Content Subtype has been updated in Project
	// view page> Asset Association window
	// BS-2235
	@Test(priority = 38)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Asset_Association_Window() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();

		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN + ".epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN + ".epub");
		test.projectView.VerifyContentTypeInAssociationPopup(TypesOfContentEnhancedEpub);

		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN + "_EPUB.Epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN + "_EPUB.Epub");
		test.projectView.VerifyContentTypeInAssociationPopup(TypesOfContentFlatEpub);
	}

	// 38.Verify that user is only able to edit the comment after clicking the edit
	// icon
	// BS-1993
	@Test(priority = 38)
	public void Verify_User_Is_Only_Able_To_Edit_Comment_After_Clicking_The_Edit_Icon()
			throws NumberFormatException, IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.AddCommentAndVerifyIt();
		test.projectView.VerifyUserNotAbleToEditCommentWithoutClickingEditIcon(AdminEmail);
	}

	// 39.Verify that user is only able to edit the comment that is made by him only
	// BS-1993
	@Test(priority = 39)
	public void Verify_User_Is_Only_Able_To_Edit_The_Comment_That_Is_Made_By_Him_Only() throws IOException {
		test.refreshPage();
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyUserIsAbleToEditComment(AdminEmail);
	}

	// 40.Verify that other user cannot see the edit icon to the right of another
	// person's comment
	// BS-1993
	@Test(priority = 40)
	public void Verify_Edit_Icon_To_Right_Of_Another_Person_Comment_Is_Not_Displayed() {
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(NonAdminEmail);
		test.loginpage.enterUserPassword(NonAdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyUserIsnotAbleToEditMsg(AdminEmail);
	}

	// 41.Verify that while user is editing the comment and clicks outside the box,
	// the changes are not saved
	// BS-1993
	@Test(priority = 41)
	public void Verify_Changes_Are_Not_Saved_If_User_Click_Outside_The_Comment_Section() {
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyClickingOutsideChangesAreNotSaved(AdminEmail);
	}

	// 42.Verify that the label name is displaying as Project ISBN 10: in CMS
	// BS-2359
	@Test(priority = 42)
	public void Verify_Label_Name_Is_Displaying_As_Project_ISBN_10() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.VerifyISBnDetailTabDisplayInformation();
	}

	// 43.Verify that user is successfully able to filter the newly added asset type
	// via Filter associated content filter
	// BS-2359
	@Test(priority = 43)
	public void Verify_User_Is_Successfully_Able_To_Filter_The_Marketing_Content_Author_Image() {
		test.projectView.verifyOnProjectView();
		test.projectView.FilterContent(TypeOfContentMarketingAuthorImage);
		test.projectView.VerifyContentDisplayedInAssociatedContent(MarketingAuthorImage);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}