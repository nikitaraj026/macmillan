package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_View_Test_Extended extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, NonAdminEmail, NonAdminPassword,
			PublihDestinationVitalSource;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare,
			PublihDestinationCatalog, ISBN2, DamContent;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, DownloadStartMsg,
			ISBNwithoutEnhancedEpub;
	String TypesOfContentFlatEpub, TypesOfContentEnhancedEpub,TypeOfContentCoverDesign,TypesOfContentInstructorResources;
	String CMSRepository,DAMRepository,FrostExportFull,ExportOptionEnhancedPub;
	 

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		ISBNwithoutEnhancedEpub = getData("ProjectWithoutEnhanceEpub");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationCatalog = getData("PublishDestination.Catalog");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		DamContent = getData("DamContent");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DownloadStartMsg = getData("DownloadStartMsg");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypeOfContentCoverDesign=getData("TypesOfContent.Covers>Cover Design");
		TypesOfContentInstructorResources=getData("TypesOfContent.Supplementary Content>Instructor Resources");
		CMSRepository=getData("Repository.CMS");
		DAMRepository=getData("Repository.DAM");
		FrostExportFull=getData("FrostExportType.Full");
		ExportOptionEnhancedPub=getData("FrostExportOptions.Enhanced ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 73."Verify that publish Asset categories in the publish pop up has table with
	// following columns 1. Name 2. Type 3. Status 4. Repository"
	@Test(priority = 2)
	public void Verify_Publish_Asset_Categories_Has_Related_Information() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.VerifyPublishAssetsDetailsAreProvided();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
	}

	// 74.Verify that if the Publish Assets Status is Not approved than it can't
	// publish
	@Test(priority = 3)
	public void Verify_If_Asset_Status_Is_Not_Approved_Than_It_Can_Not_Be_Publish() {
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentEnhancedEpub,ISBN+".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickUnApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful(ISBN);
	}

	// 75.Verify that publish pop up has the Publish and cancel button at the bottom
	@Test(priority = 4)
	public void Verify_Publish_Pop_Up_Has_Publish_And_Cancel_Button() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishAndCancelButtonOnPuplishPopUp();
	}

	// 76.Verify that user is able to publish using the publish button
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Publish_Using_Publish_Button() {
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCoreSource);
	}

	// 77.Verify that pop up is closed on clicking on the cancel button
	@Test(priority = 6)
	public void Verify_Publish_PopUp_Closed_clicking_Cancel_Button() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.clickCancelButtonOnPublishPopUp();
		test.projectView.VerifyPublishPopUpClosed();
	}

	// 78.Verify that if epub is not associated to this project then, on publishing
	// by selecting the second radio button, error message is displayed
	@Test(priority = 7)
	public void Verify_If_Epub_Is_Not_Associated_To_project_And_Second_Radio_Button_Is_Selected_Error_Message_Is_Displayed() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBNwithoutEnhancedEpub);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyErrorMessage(ISBNwithoutEnhancedEpub);
	}

	// 79.Verify that user cannot Publish the unapproved content on CoreSource
	// platform, error message is displayed
	@Test(priority = 8)
	public void Verify_User_Cannot_Publish_Unapproved_Content_On_CoreSource_Platform() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickUnApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful(ISBN);
	}

	// 80.Verify that user can Publish, only by selecting the SECOND radio button in
	// step 1 without selecting any asset from step 2.
	@Test(priority = 9)
	public void Verify_Selecting_SECOND_Radio_Button_In_Step1_Asset_Can_Be_publish_Without_Selecting_Any_Asset() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links and ePub");
		test.projectView.VerifyPublishButtonOnPublishPopUpDisabled();

		test.projectView.SelectRadioButtonOnPublish("Publish ePub only");
		test.projectView.VerifyPublishButtonOnPublishPopUpDisabled();

		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.VerifyPublishButtonOnPublishPopUpEnabled();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 81.Verify that user can publish the CFI links metadata to Algolia by
	// selecting the second radio button irrespective of the state (Approved/
	// Unapproved) of the ePub.
	@Test(priority = 10)
	public void Verify_CFI_File_Can_Be_Publish_UnapprovedORApproved_Selecting_Second_Radio_Button_In_Step2() {
		test.refreshPage();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentCoverDesign,ISBN+"_FC.jpg",true);
		test.projectView.SelectFCFile_DisplayedInStep3(ISBN);
		test.projectView.ClickUnApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentCoverDesign,ISBN+"_FC.jpg",true);
		test.projectView.SelectFCFile_DisplayedInStep3(ISBN);
		test.projectView.ClickUnApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 82.Verify that status of Publish action can be tracked under Publish Details
	// tab on CoreSource platform
	@Test(priority = 11)
	public void Verify_Publish_Action_Can_Be_Tracked_Under_Publish_Details_Tab() {
		test.refreshPage();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishDetailsAreDisplayed();
	}

	// 83."Verify that project view page has three tabs are appearing under Project
	// Status drop down 1. ISBN Details 2. Project Details 3. Publish Details"
	@Test(priority = 12)
	public void Verify_Project_View_Page_Has_Three_Tabs() {
		test.projectView.VerifySubTabAreDispalyed();
	}

	// 84."Verify that clicking on the ISBN Details tab is displayed with relevant
	// data"
	@Test(priority = 13)
	public void Verify_ISBN_Details_Tab_Display_Relevant_Information() {
		test.projectView.ClickISBnDetail();
		test.projectView.VerifyISBnDetailTabDisplayInformation();
	}

	// 85.Verify that Project details tab has project Contacts field and add button
	@Test(priority = 14)
	public void Verify_Project_Details_Tab_Has_Project_Contacts_Field_And_Add_Button() {
		test.projectView.clickProjectDetails();
		test.projectView.VerifyProjectContactAndAddButtonDisplayed();
	}

	// 86.Verify that user is able to add valid Project contact (email id) and click
	// on the add button
	@Test(priority = 15)
	public void Verify_User_Is_Able_To_Add_Valid_Email_Adderss() {
		test.projectView.AddEmailAddress(NonAdminEmail);
		test.projectView.VerifyEmailIsAdded(NonAdminEmail);
	}

	// 87.Verify that "Invalid email address" message is displayed if invalid email
	// address is enter in project contact
	@Test(priority = 16)
	public void Verify_Message_Is_Displayed_If_Invalid_Email_Address_Is_Entered() {
		test.projectView.VerifyMessageOnInvalidEmailAddress();
	}

	// 88.Verify that user can successfully remove the added email
	@Test(priority = 17)
	public void Verify_User_Can_Successfully_Remove_Added_Email() {
		test.ContentView.RemoveAddedEmail(NonAdminEmail);
	}

	// 89.Verify that clicking the Publish Details tab activate the publish Details
	// tab
	@Test(priority = 18)
	public void Verify_Clicking_On_Publish_Detail_Activate_PublishDetail() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyOnPublishDetailPage();
	}

	// 90."Verify that Publish details tab has following details: 1. User 2.
	// Destination 3. File Name 4. Published Date 5. Publish Status"
	@Test(priority = 19)
	public void Verify_Publish_Details_Tab_Has_Details() {
		test.projectView.VerifyHeaderOfPublishTab();
	}

	// 91.Verify that Publish details tab has Refresh link to refresh the details
	@Test(priority = 20)
	public void Verify_Publish_Details_Has_Refresh_Link() {
		test.projectView.VerifyRefreshLink();
	}

	// 92.Verify that clicking on the Refresh link refresh the details in the
	// publish tab
	@Test(priority = 21)
	public void Verify_Clicking_Refresh_Link_Refresh_Publish_Details() {
		test.projectView.ClickRefreshLink();
	}

	// 93.Verify that project view page has the Associated Content heading below the
	// System metadata
	@Test(priority = 22)
	public void Verify_Associated_Content_Heading() {
		test.refreshPage();
		test.projectView.verifyAssociatedContentLabel();
	}

	// 94."Verify that Associated Content has the following details: 1. Content
	// thumbnail 2. ISBN 3. Created date/time 4. User type 5. Content type
	@Test(priority = 23)
	public void Verify_Associated_Project_Details_Are_Shown() {
		test.projectView.VerifyAssociatedContentDetailDisplayed();
	}

	// 95.Verify that initial Frost status for the project in the Associated Content
	// is Not added to Frost under Associated Content heading
	// @Test(priority=24) ##### Functionality Removed #####
	public void Verify_Initial_Frost_Status_In_Associated_Content_Is_Not_Added_To_Frost() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.UploadEnhancedEpubFromProjectView(ISBN2);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.FilterContent(TypesOfContentEnhancedEpub);
		test.projectView.VerifyFrostStatusNotAdded(ISBN2);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+".epub",TypesOfContentEnhancedEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}


	// 97.Verify that content push back to cms from frost should have the status
	// Authored in Frost under Associated Content heading
	// @Test(priority=26) ##### Functionality Removed #####
	public void Verify_Content_Push_Back_To_Cms_From_Frost_Should_Have_Status_Authored_In_Frost() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(FrostMainProject, FrostIsbnToEnter);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, getData("FrostProject.ProjectNameToEnter"));
		test.projectView.OpenProjectOnFrost(getData("FrostProject.ProjectNameToEnter"));
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.LogoutFromFrost();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.VerifyCFIAndEnhancedEpubArePushed(FrostIsbnToEnter);
		test.projectView.FilterContent(TypesOfContentEnhancedEpub);
		test.projectView.VerifyFrostStatusAuthoredInFrost(FrostIsbnToEnter);
	}

	// Delete Project From Frost
	// @Test(priority=27) ##### Functionality Removed due to Upper Test Cases #####
	public void Delete_Project_From_Frost() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.ClickGoToFrost();
		test.ContentView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, getData("FrostProject.ProjectNameToEnter"));
		test.projectView.DeleteProjectFromFrost(getData("FrostProject.ProjectNameToEnter"));
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 98.Verify that project view page has the Workflow History heading below the
	// Associated Content under Associated Content heading
	@Test(priority = 28)
	public void Verify_Project_View_Page_Has_The_Workflow_History() {
		test.ContentView.changeWindow(0);
		test.projectView.VerifyHistoryIsdisplayed();
	}

	// 99.Verify that Flat and Enhanced labels are appearing for the ePub
	@Test(priority = 29)
	public void Verify_Epub_Labels_Are_Displayed() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.VerifyLablesAreDisplayed();
	}

	// 100.Verify that comments heading below the project view page
	@Test(priority = 30)
	public void Verify_Comment_Heading_Displayed_In_Project_View() {
		test.projectView.VerifyCommentSection();
	}

	// 101.Verify that comments heading has comment field and post button
	@Test(priority = 31)
	public void Verify_Comment_Field_And_Post_Button_On_Comment_Section() {
		test.projectView.VerifyCommentSectionPaneAndPostButton();
	}

	// 102.Verify that user is able to post the comment
	@Test(priority = 32)
	public void Verify_User_Is_Able_To_Add_Comment_And_View_It() throws IOException {
		test.projectView.AddCommentAndVerifyIt();
	}

	// 103.Verify that user can Edit his own comment only
	@Test(priority = 33)
	public void Verify_User_Can_Edit_His_Comment() throws IOException {
		test.projectView.VerifyUserIsAbleToEditComment(AdminEmail);
	}

	// 104.Verify that user can Delete his own comment only
	@Test(priority = 34)
	public void Verify_User_Can_Delete_His_Comment() {
		test.refreshPage();
		test.projectView.VerifyUserIsAbleToDeleteComment(AdminEmail);
	}

	// 105.Verify that one user can not delete or edit comment made by other user
	@Test(priority = 35)
	public void Verify_User_Can_Not_Delete_Edit_Comment_Made_By_Other_User() {
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(NonAdminEmail);
		test.loginpage.enterUserPassword(NonAdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.VerifyUserIsNotAbleToDeleteMsg(AdminEmail);
		test.projectView.VerifyUserIsnotAbleToEditMsg(AdminEmail);
	}

	// 106.Verify that a pagination bar is present at the bottom of Workflow History
	// heading which enables an end user to navigate back and forth
	@Test(priority = 36)
	public void Verify_Pagination_Bar_Appears_If_There_Are_More_History() {
		test.projectView.verifyPaginationBarIsAppering();
		test.projectView.VerifyBackAndForthNavigationpaginationBar();
	}

	// 107.Verify that clicking on the delete button opens the pop up with Delete
	// Content pop having desired text
	@Test(priority = 37)
	public void Verify_Clicking_Delete_Button_Opens_Delete_PopUp() {
		test.projectView.Verify_Clicking_Delete_Opens_PopUp();
	}

	// 108.Verify that Confirm delete button is disabled till Delete is not entered
	// in the field above Confirm delete button
	@Test(priority = 38)
	public void Verify_Delete_Button_Is_Disabled_Till_Delete_Entered() {
		test.projectView.VerifyDeletebuttonDisabled();
	}

	// 109.Verify that confirm delete button is activated as Delete keyword is
	// entered in the field
	@Test(priority = 39)
	public void Verify_Delete_Button_Activates_When_Delete_Keyword_Entered() {
		test.projectView.EnterDeleteInTextBox();
		test.projectView.VerifyDeletebuttonEnabled();
	}

	// 110.Verify that ‘Courseware’ is displaying in the Destination dropdown in
	// Publish window for Project view
	@Test(priority = 40)
	public void Verify_Courseware_Displayed_In_Destination_Dropdown_In_Publish_Window() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
	}

	// 111.Verify that ‘Courseware’ is displaying in the ‘Publish Destination’
	// dropdown in Advanced Search pop up.
	@Test(priority = 41)
	public void Verify_Courseware_Displayed_In_Publish_Destination_Of_Advanced_Search() {
		test.refreshPage();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUpAndVerify("Publish Destination");
		test.SearchPage.SelectContentTypeInNewAddedField("Courseware");
	}

	// 112.Verify that Destination is getting displayed as ‘Courseware’ for the
	// files that are published in Courseware platform under Publish details tab in
	// Project view
	@Test(priority = 42)
	public void Verify_Destination_Courseware_For_The_Files_Published_In_Courseware() {
		test.refreshPage();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(DAMRepository,TypesOfContentInstructorResources,DamContent,true);
		test.projectView.Select_Assert_Displayed_In_Step3(DamContent);
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCourseWare);
	}

	// 113.Verify that three options with radio buttons are appearing in step 1
	// under Destination dropdown in the publish pop-up
	@Test(priority = 43)
	public void Verify_Three_Options_With_Radio_Buttons_Are_Displayed_In_Step1() {
		test.refreshPage();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyThreeOptionsDisplayedInPublish();
	}

	// 114.Verify that options appear only when the Destination is set as CoreSource
	@Test(priority = 44)
	public void Verify_Three_Options_Only_Displayed_For_CoreSource() {
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.VerifyThreeOptionsNotDisplayedInPublish();
	}

	// 115.Verify that Workflow History has table with information
	@Test(priority = 45)
	public void Verify_That_Workflow_History_Has_Table_With_Information() {
		test.refreshPage();
		test.projectView.VerifyHistoryIsdisplayed();
	}

	// 116.Verify that epub is required to be approved to get Published.(When status
	// is unapproved)
	@Test(priority = 46)
	public void Verify_Approved_Epub_Can_Be_Published() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickUnApproveButtonOnPublishPopUp();
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 117.Verify that epub is required to be approved to get Published.(When Status
	// is approved)
	@Test(priority = 47)
	public void Verify_Reapproved_Epub_Can_Be_Published() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 118.Verify that Publish details for the enhanced ePub is displaying under
	// Publish details subtab
	@Test(priority = 48)
	public void Verify_Publish_Details_For_Enhanced_EPub_Displayed_Under_Publish_Details() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishDetailsAreDisplayed();
	}

	// 119.Verify that user can select the assets from the tree like structure in
	// case of manual Publish is selected
	@Test(priority = 49)
	public void Verify_User_Can_Select_Assets_From_Tree_Like_Structure_In_Step2() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN+"_EPUB.epub",true);
	}

	// 120.Verify that user is able to Approve/ Unapprove the assets displaying in
	// STEP 3.
	@Test(priority = 50)
	public void Verify_User_Is_Able_To_Approve_Unapprove_Assets_Displayed_In_STEP3() {
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.ClickUnApproveButtonOnPublishPopUp();

	}

	// 121.Verify that user is able to Publish the Approved content only and a
	// success message is displayed after clicking the Publish button.
	@Test(priority = 51)
	public void Verify_User_Is_Able_To_Publish_Approved_Content_Only_And_Success_Message_Is_Displayed() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentEnhancedEpub,ISBN2+".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.refreshPage();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentEnhancedEpub,ISBN2+".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickUnApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful(ISBN2);
	}

	// 122.Verify that Ellipses are appearing in step 3 for File name with more than
	// 20 characters.
	@Test(priority = 52)
	public void Verify_Ellipses_In_Step3_For_File_Name_More_Than_20_Characters() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN2+"_EPUB.epub",true);
		test.projectView.VerifyEllipsesForFileName(ISBN2);
	}

	// 123."Verify that on the publish modal window First radio button label should
	// be read as: Publish content links and ePub (with info icon)"
	@Test(priority = 53)
	public void Verify_First_Radio_Button_Label_On_Publish_Window() {
		test.projectView.SelectRadioButtonOnPublish("Publish content links and ePub");
	}

	// 124.Verify that First radio button tooltip should be read as:CMS sends CFI
	// content links to Courseware and publishes ePub to CoreSource with this
	// action.
	@Test(priority = 54)
	public void Verify_Tool_Tip_For_First_Radio_Button() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyToolTips("Publish content links and ePub", PublihDestinationCoreSource);
	}

	// 125."Verify that on the publish modal window Second radio button label should
	// be read as: Publish content links only (with info icon)"
	@Test(priority = 55)
	public void Verify_Second_Radio_Button_Label_On_Publish_Window() {
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
	}

	// 126.Verify that on the publish modal window beside Second radio button
	// tooltip should be read as:CMS sends CFI content links to Courseware with this
	// action.
	@Test(priority = 56)
	public void Verify_Tool_Tip_For_Second_Radio_Button() {
		test.projectView.VerifyToolTips("Publish content links only", PublihDestinationCoreSource);
	}

	// 127."Verify that on the publish modal window Third radio button label should
	// be read as: Publish ePub only (with info icon)"
	@Test(priority = 57)
	public void Verify_Third_Radio_Button_Label_On_Publish_Window() {
		test.projectView.SelectRadioButtonOnPublish("Publish ePub only");
	}

	// 128.Verify that on the publish modal window beside Third radio button tooltip
	// should be read as:CMS publishes ePub to CoreSource with this action.
	@Test(priority = 58)
	public void Verify_Tool_Tip_For_Third_Radio_Button() {
		test.projectView.VerifyToolTips("Publish ePub only", PublihDestinationCoreSource);
	}

	// 129.Verify that in the publish modal window destination drop down should have
	// option VitalSource
	@Test(priority = 59)
	public void Verify_Publish_Modal_Window_Has_VitalSource_as_Destination() {
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
	}

	// 130.Verify that as soon as the user selects the Vital Source destination
	// platform, three additional options available
	@Test(priority = 60)
	public void Verify_Three_Additional_Options_Available_For_VitalSource() {
		test.projectView.VerifyThreeOptionsDisplayedInPublish();
	}

	// 131.Verify that as soon as the user selects the Vital Source destination
	// platform, three additional options available with tooltip.
	@Test(priority = 61)
	public void Verify_Tool_Tips_For_Publish_Platform() {
		test.projectView.VerifyToolTips();
	}

	// 132.Verify that user should be able to publish the epub successfully to
	// VitalSource
	@Test(priority = 62)
	public void Verify_User_Is_Able_To_Publish_Epub_To_VitalSource() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentEnhancedEpub,ISBN2+".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 133.Verify that user should be able to track the publish status under the
	// publish details tab of both content and project when publish using vital
	// source.
	@Test(priority = 63)
	public void Verify_User_Is_Able_To_Track_Publish_Status_For_Content_And_Project_When_Publish_Using_VitalSource() {
		test.refreshPage();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationVitalSource);
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + ".epub");
	}

	// 134.Verified that when a content is associated to a project, and gets
	// published, then it is displaying under the ‘Project Association for this
	// Asset’ pop-up.
	@Test(priority = 64)
	public void Verify_When_Associated_Gets_Published_then_It_Is_Displayed_Under_Project_Association_Asset_PopUp() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.FilterContent(TypesOfContentFlatEpub);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN2+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.refreshPage();
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.projectView.ClickCloseButton();
	}

	// 135.Verify that data in the ‘Project Association for this Asset’ pop-up
	// reflects only once no matter if user is publishing the same content with same
	// ISBN.
	@Test(priority = 65)
	public void Verify_Information_In_Project_Association_PopUp_Reflects_Only_Once_Irrespective_of_Publishing_More_Than_One() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN2+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyCountOfAssetDisplayedOnAssociationPopUp();
	}

	// 136.Verify that the contents that are associated as well as published to the
	// same project are displaying under the Asset Association window.
	@Test(priority = 67)
	public void Verify_Associated_Content_When_Published_Is_Shown_Under_Asset_Association_Window() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");

	}

	// 137.Verify that user can search for the content that is displaying in the
	// Asset Association pop-up
	@Test(priority = 68)
	public void Verify_User_Can_Search_For_Asset_In_Asset_Association_Window() {
		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.refreshPage();
		test.projectView.FilterContent(TypesOfContentFlatEpub);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 138.Verify that the content that non-published content would neither be
	// displayed, nor it can be searched in the Asset Association window.
	@Test(priority = 69)
	public void Verify_Non_Published_Content_Is_Not_Displayed_On_Asset_Association_window() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(FrostMainProject + "_EPUB.epub");
		test.Contentpage.SelectContentOnContentTab(FrostMainProject + "_EPUB.epub", TypesOfContentFlatEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
		test.projectView.SearchForAssetOnAssetAssociationPopUp(FrostMainProject + "_EPUB.epub");
		test.projectView.VerifyAssetIsNotDisplayedOnAssetAssociationPopUp(FrostMainProject + "_EPUB.epub");
		test.refreshPage();
		test.projectView.ClickOpenAssetOnProjectView(FrostMainProject+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 139.Verified that content which is not related to the Project is also not
	// searchable or displayed in the Asset association window.
	@Test(priority = 70)
	public void Verify_Content_Not_Related_To_The_Project_Is_Not_Displayed_In_Asset_Association_window() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
		test.projectView.SearchForAssetOnAssetAssociationPopUp(FrostMainProject + ".epub");
		test.projectView.VerifyAssetIsNotDisplayedOnAssetAssociationPopUp(FrostMainProject + ".epub");
	}

	// 140.Verify that published asset will keep on displaying in the Asset
	// Association window.
	@Test(priority = 71)
	public void Verify_Published_Asset_Keep_On_Displaying_Even_When_Removed_From_Project_Asset_Association_window() {
		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN2 + ".epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN2 + ".epub");
	}

	// 141.Verify that Content published from two projects, then same Asset is
	// displaying in Asset Association window for both the Projects.
	@Test(priority = 72)
	public void Verify_When_Content_Published_From_Two_Projects_It_Is_Displayed_In_Both_Project() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.FilterContent(TypesOfContentFlatEpub);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN2+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.refreshPage();
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.FilterContent(TypesOfContentFlatEpub);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);

		/*test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.FilterContent(getData("TypesOfContent.Enhanced ePub > Full Package"));
		test.projectView.ClickOpenEnhancedEpubOnProjectView(ISBN2);*/ 
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(FrostMainProject);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentFlatEpub,ISBN2+"_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.refreshPage();
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
		test.projectView.SearchForAssetOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetDisplayedOnAssetAssociationPopUp(ISBN2 + "_EPUB.epub");
		test.refreshPage();
		test.projectView.FilterContent(TypesOfContentFlatEpub);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(FrostMainProject);
	}

	// 142.Verify that in the push to authoring tool pop -up should have Step 3 name
	// as "Select new Project ISBN"
	@Test(priority = 73)
	public void Verify_Label_Of_Step3_Of_Push_To_Authoring_Tool() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyStep3LabelOfPushToAuthoringTool();
	}

	// 143.Verify that user should be able to enter the ISBN in step 3 and clicking
	// on the search icon should display the results in the table below
	@Test(priority = 74)
	public void Verify_Project_Is_Displayed_In_Step3_On_Clicking_Search_Button() {
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ISBN2);
		test.projectView.VerifyProjectIsDisplayedOnAuthoringTool(ISBN2);
	}

	// 144.Verify that if user from the CMS sends ePub, FROST creates a new project
	// for that ISBN and generates the TOC from the ePub content.
	@Test(priority = 75)
	public void Verify_Project_Is_Created_At_Frost_End_And_Generates_An_Toc() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(FrostMainProject, FrostIsbnToEnter);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, getData("FrostProject.ProjectNameToEnter"));/// Need
																														/// To
																														/// Check
																														/// For
																														/// TOC
	}

	// Delete Project From Frost
	@Test(priority = 76)
	public void Delete_Project_From_Frost_2() {
		test.projectView.DeleteProjectFromFrost(getData("FrostProject.ProjectNameToEnter"));
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}