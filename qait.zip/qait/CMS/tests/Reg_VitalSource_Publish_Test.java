package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_VitalSource_Publish_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String EpubWith30Characters, TypesOfContentEnhancedEpub, TitleEpubWith30Characters, TestISBN;
	String PublihDestinationVitalSource, EpubWithHyphenCharacter, TitleEpubWithHyphenCharacter,
			EpubWithMoreThan30Character;
	String TitleEpubWithMoreThan30Character, EpubWithSpaceInFileName, TitleEpubWithSpaceInFileName;
	String EpubWithSpecialCharacter, TitleEpubWithSpecialCharacter, TestProjectISBN, PublishDestinationCourseWare;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		EpubWith30Characters = "VitalSourcePublishTest.epub";
		TitleEpubWith30Characters = "AutomationEpub30Char";
		TestISBN = getData("ProjectISBNNo6");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublishDestinationCourseWare = getData("PublishDestination.CourseWare");
		EpubWithHyphenCharacter = "VitalSource-PublishTest.epub";
		TitleEpubWithHyphenCharacter = "AutomationEpubWithHyphen";
		EpubWithMoreThan30Character = "VitalSourceMoreThan30CharacterPublishTest.epub";
		TitleEpubWithMoreThan30Character = "AutomationEpubWithMoreThan30Char";
		EpubWithSpaceInFileName = "VitalSource PublishTest.epub";
		TitleEpubWithSpaceInFileName = "AutomationEpubWithSpaceInFileName";
		EpubWithSpecialCharacter = "VitalSource&PublishTest.epub";
		TitleEpubWithSpecialCharacter = "AutomationEpubWithoutHypen";
		TestProjectISBN = getData("ProjectISBNNO");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// 1.login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}
	
	// Upload An Epub with character limit is within 30
	@Test(priority = 2)
	public void Upload_Epub_With_Character_Limit_Is_Within_30() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(EpubWith30Characters);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.EnterTextIntoTitleField(TitleEpubWith30Characters);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestISBN);
	}

	// 2.Verify that user is able to publish an ePub to VS provided that
	// character limit is within 30
	@Test(priority = 3)
	public void Verify_User_Able_To_Publish_EPub_To_VS_Character_Limit_Within_30() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TitleEpubWith30Characters, true);
		test.projectView.Select_Assert_Displayed_In_Step3(EpubWith30Characters);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.VerifyPublishButtonOnPublishPopUpEnabled();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Success", "1");
	}

	// Delete the Uploaded Epub.
	@Test(priority = 4)
	public void Delete_The_Uploaded_Epub() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TitleEpubWith30Characters);
		test.Contentpage.SelectContentOnContentTab(TitleEpubWith30Characters,TypesOfContentEnhancedEpub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

	}

	// Upload An Epub with character limit is within 30 and Special character
	// Hyphen

	@Test(priority = 5)
	public void Upload_Epub_With_Character_Limit_Is_Within_Special_Character_Hyphen() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(EpubWithHyphenCharacter);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.EnterTextIntoTitleField(TitleEpubWithHyphenCharacter);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestISBN);
	}

	// 3.Verify that user is able to publish an ePub to VS provided that
	// character limit is within 30 and only special character that is allowed is
	// Hyphen

	@Test(priority = 6)
	public void Verify_User_Able_To_Publish_EPub_To_VS_With_Hyphen() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TitleEpubWithHyphenCharacter, true);
		test.projectView.Select_Assert_Displayed_In_Step3(EpubWithHyphenCharacter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.VerifyPublishButtonOnPublishPopUpEnabled();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Success", "1");
	}

	// Delete the Uploaded Epub.
	@Test(priority = 7)
	public void Delete_The_Uploaded_Epub1() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TitleEpubWithHyphenCharacter);
		test.Contentpage.SelectContentOnContentTab(TitleEpubWithHyphenCharacter,TypesOfContentEnhancedEpub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

	}

	// Upload An Epub with more than 30 character
	@Test(priority = 8)
	public void Upload_Epub_With_More_Than_30_Character() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(EpubWithMoreThan30Character);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.EnterTextIntoTitleField(TitleEpubWithMoreThan30Character);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestISBN);
	}

	// 4.Verify that user not able to publish an ePub to VS provided that
	// character limit is more than 30
	@Test(priority = 9)
	public void Verify_User_Not_Able_To_Publish_EPub_To_VS_More_Than_30_Character() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TitleEpubWithMoreThan30Character, true);
		test.projectView.Select_Assert_Displayed_In_Step3(EpubWithMoreThan30Character);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.VerifyPublishButtonOnPublishPopUpEnabled();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Failed", "1");
	}

	// Delete the Uploaded Epub.
	@Test(priority = 10)
	public void Delete_The_Uploaded_Epub2() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TitleEpubWithMoreThan30Character);
		test.Contentpage.SelectContentOnContentTab(TitleEpubWithMoreThan30Character,TypesOfContentEnhancedEpub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

	}

	// Upload An Epub with Space in the File Name
	@Test(priority = 11)
	public void Upload_Epub_With_Space_In_File_Name() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(EpubWithSpaceInFileName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.EnterTextIntoTitleField(TitleEpubWithSpaceInFileName);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestISBN);
	}

	// 6.Verify that user is not able to publish an ePub to VS provided that
	// there are spaces
	@Test(priority = 12)
	public void Verify_User_Not_Able_To_Publish_EPub_To_VS_With_Space() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TitleEpubWithSpaceInFileName, true);
		test.projectView.Select_Assert_Displayed_In_Step3(EpubWithSpaceInFileName);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.VerifyPublishButtonOnPublishPopUpEnabled();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Failed", "1");
	}

	// Delete the Uploaded Epub.
	@Test(priority = 13)
	public void Delete_The_Uploaded_Epub3() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TitleEpubWithSpaceInFileName);
		test.Contentpage.SelectContentOnContentTab(TitleEpubWithSpaceInFileName,TypesOfContentEnhancedEpub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

	}

	// Upload An Epub with special character other than Hyphen.
	@Test(priority = 14)
	public void Upload_Epub_With_Special_Character_Other_Than_Hyphen() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(EpubWithSpecialCharacter);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.EnterTextIntoTitleField(TitleEpubWithSpecialCharacter);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestISBN);
	}

	// 5.Verify that user is not able to publish an ePub to VS provided that
	// there are spaces
	@Test(priority = 15)
	public void Verify_User_Not_Able_To_Publish_EPub_To_VS_Other_Than_Hyphen() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TitleEpubWithSpecialCharacter, true);
		test.projectView.Select_Assert_Displayed_In_Step3(EpubWithSpecialCharacter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.VerifyPublishButtonOnPublishPopUpEnabled();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Failed", "1");
	}

	// Delete the Uploaded Epub.
	@Test(priority = 16)
	public void Delete_The_Uploaded_Epub4() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TitleEpubWithSpecialCharacter);
		test.Contentpage.SelectContentOnContentTab(TitleEpubWithSpecialCharacter,TypesOfContentEnhancedEpub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

	}

	// "Content view:
	// 1) Verified that user is successfully able to Publish the asset(s) to
	// VitalSource destination by selecting any of the 03 options available in Step
	// 1 i.e.
	// a) Publish ePub only
	// b) Publish content links and ePub
	// c) Publish content links only"
	// BS-3252
	@Test(priority = 17)
	public void Verify_User_Able_To_Publish_Using_Radio_Button_ContentView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN + ".epub");
		test.Contentpage.opentheSearchContent(TestProjectISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectPublishRadioButton("Publish ePub only");
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectPublishRadioButton("Publish content links and ePub");
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectPublishRadioButton("Publish content links only");
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

	}

	// Step:: Verify the Publish to VitalSource is Successful
	// BS-3252
	@Test(priority = 18, dependsOnMethods = "Verify_User_Able_To_Publish_Using_Radio_Button_ContentView")
	public void Verify_Publish_To_VitalSource_Successful_ContentView() {
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyPublishWasOnCorrectDestination(PublihDestinationVitalSource);
		test.ContentView.WaitforpublishToComplete("Success", "1");
		test.ContentView.WaitforpublishToComplete("Success", "2");

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN + "_CFI.csv");
		test.Contentpage.opentheSearchContent(TestProjectISBN + "_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyPublishWasOnCorrectDestination(PublishDestinationCourseWare);
		test.ContentView.WaitforpublishToComplete("Complete", "1");
	}

	// "Project view:
	// 1) Verified that user is successfully able to Publish the asset(s) to
	// VitalSource destination by selecting any of the 03 options available in Step
	// 1 i.e.
	// a) Publish ePub only
	// b) Publish content links and ePub
	// c) Publish content links only"
	// BS-3252
	@Test(priority = 19)
	public void Verify_User_Able_To_Publish_Using_Radio_Button_ProjectView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish ePub only");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TestProjectISBN + ".epub", true);
		test.projectView.Select_Assert_Displayed_In_Step3(TestProjectISBN + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links and ePub");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TestProjectISBN + ".epub", true);
		test.projectView.Select_Assert_Displayed_In_Step3(TestProjectISBN + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TestProjectISBN + ".epub", true);
		test.projectView.Select_Assert_Displayed_In_Step3(TestProjectISBN + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
	}

	// Step:: Verify the Publish to VitalSource is Successful
	// BS-3252
	@Test(priority = 20, dependsOnMethods = "Verify_User_Able_To_Publish_Using_Radio_Button_ProjectView")
	public void Verify_Publish_To_VitalSource_Successful_ProjectView() {
		test.projectView.ClickPublishDetail();
		test.projectView.ClickRefreshLink();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublishDestinationCourseWare);
		test.projectView.WaitforpublishToComplete("Complete", "1");
		test.projectView.WaitforpublishToComplete("Success", "2");
		test.projectView.WaitforpublishToComplete("Success", "3");
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
