package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Reg_Select_All_Feature extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String ISBN, PassResetEmail, CurrentResetPassword, PageSelectionNone, PageSelectionThisPage, LookForAsset,
			PageSelectionAllPages;
	String OrganisedDownloadMsg;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		PassResetEmail = getData("PasswordResetAccount.email");
		CurrentResetPassword = PropFileHandler.readPropertyFromDataFile("currentPassword");
		PageSelectionNone = getData("PageSelection.None");
		PageSelectionThisPage = getData("PageSelection.This Page");
		PageSelectionAllPages = getData("PageSelection.All Pages");
		LookForAsset = getData("LookFor.Assets");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsg");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that letter D is in caps for the word Date in table column
	// header present on Dashboard
	// BS-2531
	@Test(priority = 2)
	public void Verify_D_Letter_In_Caps_For_Date_In_Table_Header_Dashboard() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("1");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyAllTheColoumsOfFavoriteTable();
	}

	// 2.Verify that letter D is in caps for the word Date in table column
	// header present on Project
	// BS-2531
	@Test(priority = 3)
	public void Verify_D_Letter_In_Caps_For_Date_In_Table_Header_Project() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.verifyColumnsAreDisplayed();
	}

	// 3.Verify that letter D is in caps for the word Date in table column
	// header present on Project> Generic Search Page
	// BS-2531
	@Test(priority = 4)
	public void Verify_D_Letter_In_Caps_For_Date_In_Table_Header_Project_Generic_Search() {
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.verifyColumnsAreDisplayedAfterSearch();
	}

	// 4.Verify that letter D is in caps for the word Date in table column
	// header present on Content tab page
	// BS-2531
	@Test(priority = 5)
	public void Verify_D_Letter_In_Caps_For_Date_In_Table_Header_Content_Tab_Page() {
		test.HomePage.ClickContentTab();
		test.Contentpage.verifyColumnsAreDisplayed();
	}

	// 5.Verify that one of the password validation message has been updated as
	// below for Edit Account> Reset Password workflow:
	// a) Should have at least one lowercase letter"
	@Test(priority = 6)
	public void Verify_Password_Validation_Message_For_LowerCase() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForOneLowerCase();
	}

	// 6.Verify that one of the password validation message has been updated as
	// below for Edit Account> Reset Password workflow:
	// b) Should have at least one uppercase letter"
	@Test(priority = 7)
	public void Verify_Password_Validation_Message_For_UpperCase() {
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForOneUppercase();
	}

	// 7.Verify that rest password validation messages are displaying accurately
	@Test(priority = 8)
	public void Verify_Password_Validation_Messages() {
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForLessThan8Character();
		test.HomePage.VerifyNewPasswordFieldDisplaysMessageForOneNumber();
		test.HomePage.VerifyUserGetsErrorMessageIfNewAndConformFieldsAreNotSame();
		test.HomePage.clickXButtonOnRestPassword();
	}

	// 8.Verify that user is successfully able to reset his password
	@Test(priority = 9)
	public void Verify_User_Successfully_Able_To_Reset_password() throws IOException {
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(PassResetEmail);
		test.loginpage.enterUserPassword(CurrentResetPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickUserName();
		test.HomePage.ClickEditAccount();
		test.HomePage.ClickResetPassword();
		test.HomePage.ResetPassword();

		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(getData("PasswordResetAccount.email"));
		test.loginpage.enterUserPassword(PropFileHandler.readPropertyFromDataFile("currentPassword"));
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 9.Generic Search:Verify that When no Asset is selected, None is displayed as
	// selected.
	// BS-2748
	@Test(priority = 10)
	public void Verify_When_No_Asset_Is_Selected_None_Is_Displayed_Generic_Search() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionNone);

		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);

		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionNone);
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTab();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionNone);

	}

	// 10.Advance Search:Verify that When no Asset is selected, None is displayed as
	// selected.
	// BS-2748
	@Test(priority = 11)
	public void Verify_When_No_Asset_Is_Selected_None_Is_Displayed_Advance_Search() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageIsSelectedInDropDown(PageSelectionNone);

		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);

		test.SearchPage.PageSelection(PageSelectionNone);
		test.SearchPage.VerifyContentsAreNotSelected();
		test.SearchPage.VerifyPageIsSelectedInDropDown(PageSelectionNone);
	}

	// 11.Generic Search:Verify that When 1 or more assets (less than the number of
	// assets on that page) are selected on the current page, then no option is
	// displayed as selected.
	// BS-2748
	@Test(priority = 12)
	public void Verify_Generic_Search_When_1_or_More_Assets_No_Option_Is_Displayed_SelectPage() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
	}

	// 12.Advance Search:Verify that When 1 or more assets (less than the number of
	// assets on that page) are selected on the Advance Search page, then no option
	// is displayed as selected.
	// BS-2748
	@Test(priority = 13)
	public void Verify_Advance_Search_When_1_or_More_Assets_No_Option_Is_Displayed_SelectPage() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectContents(2);
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
	}

	// 13.Generic Search:Verify that When Assets on ALL PAGES are selected, All
	// Pages option is displayed as Selected
	// BS-2748
	@Test(priority = 14)
	public void Verify_Generic_Search_All_Pages_Option_Is_Selected_When_Assets_On_ALL_PAGES_Are_Selected() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + " epub");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionAllPages);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionAllPages);
	}

	// 14.Advance Search:Verify that When Assets on ALL PAGES are selected, All
	// Pages option is displayed as Selected
	// BS-2748
	@Test(priority = 15)
	public void Verify_Advance_Search_All_Pages_Option_Is_Selected_When_Assets_On_ALL_PAGES_Are_Selected() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionAllPages);
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageIsSelectedInDropDown(PageSelectionAllPages);
	}

	// 15.Generic Search:Verify that When All assets on SINGLE page are selected,
	// This Page option is displayed as selected
	// BS-2748
	@Test(priority = 16)
	public void Verify_Generic_Search_This_Page_Option_Is_Selected_When_All_The_Asset_on_Page_Selected() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectAllTheContentOnPageManually();
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
	}

	// 16.Advance Search:Verify that When All assets on SINGLE page are selected,
	// This Page option is displayed as selected
	// BS-2748
	@Test(priority = 17)
	public void Verify_Advance_Search_This_Page_Option_Is_Selected_When_All_The_Asset_on_Page_Selected() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectAllTheContentsManually();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
	}

	// 17.Generic Search:Verify that When ‘This page’ is selected and user moves to
	// another page, then no option is displayed as selected
	// BS-2748
	@Test(priority = 18)
	public void Verify_GenericSearch_When_This_Page_Is_Selected_User_Moves_To_Another_Page_No_Option_Is_Selected() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
	}

	// 18.Advance Search:Verify that When ‘This page’ is selected and user moves to
	// another page, then no option is displayed as selected
	// BS-2748
	@Test(priority = 19)
	public void Verify_AdvanceSearch_When_This_Page_Is_Selected_User_Moves_To_Another_Page_No_Option_Is_Selected() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox("epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
	}

	// 19.Generic Search:Verify that when ‘This page’ selected on first page, user
	// moves to another page, user selects one or more assets on the second page,
	// then no option is displayed as selected.
	// BS-2748
	@Test(priority = 20)
	public void Verify_Generic_Search_When_This_Page_Selected_User_Moves_To_Next_And_Select_Asset_None_Displayed() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
	}

	// 20.Advance Search:Verify that when ‘This page’ selected on first page, user
	// moves to another page, user selects one or more assets on the second page,
	// then no option is displayed as selected.
	// BS-2748
	@Test(priority = 21)
	public void Verify_Advance_Search_When_This_Page_Selected_User_Moves_To_Next_And_Select_Asset_None_Displayed() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox("epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.SelectContents(2);
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
	}

	// 21.Generic Search:Verify that when ‘This page’ selected on first page, user
	// moves to another page, user selects ‘This page’ on second page, then This
	// Page option is displayed as selected.
	// BS-2748
	@Test(priority = 22)
	public void Verify_Generic_Search_When_ThisPage_Selected_User_Moves_To_Next_And_Select_ThisPage() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
	}

	// 22.Advance Search:Verify that when ‘This page’ selected on first page, user
	// moves to another page, user selects ‘This page’ on second page, then This
	// Page option is displayed as selected.
	// BS-2748
	@Test(priority = 23)
	public void Verify_Advance_Search_When_ThisPage_Selected_User_Moves_To_Next_And_Select_ThisPage() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox("epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
	}

	// 23.Generic Search:Verify that After Scenario #5, #6 and #7, user returns to
	// First page, then 'This Page' is displayed as selected.
	// BS-2748
	@Test(priority = 24)
	public void Verify_Generic_Searchs_This_Page_Is_Selected_When_User_Moves_To_First_Page() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
	}

	// 24.Advance Search:Verify that After Scenario #5, #6 and #7, user returns to
	// First page, then 'This Page' is displayed as selected.
	// BS-2748
	@Test(priority = 25)
	public void Verify_Advance_Searchs_This_Page_Is_Selected_When_User_Moves_To_First_Page() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox("epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);

		test.SearchPage.NavigateToPage("2");
		test.SearchPage.SelectContents(2);
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);

		test.SearchPage.NavigateToPage("2");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
	}

	// 25.Generic Search:Verify that User returns to first page, user un-selects one
	// asset on the first page, then No option is displayed as selected.
	// BS-2748
	@Test(priority = 26)
	public void Verify_Generic_Search_when_User_Returns_To_First_Page_UnSelects_One_Asset_No_Option_Displayed() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
		test.Contentpage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
	}

	// 26.Advance Search:Verify that User returns to first page, user un-selects one
	// asset on the first page, then No option is displayed as selected.
	// BS-2748
	@Test(priority = 27)
	public void Verify_Advance_Search_when_User_Returns_To_First_Page_UnSelects_One_Asset_No_Option_Displayed() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox("epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.SelectContents(1);
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionAllPages);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionNone);
		test.SearchPage.VerifyPageNotSelectedInDropDown(PageSelectionThisPage);
	}

	// 27.Generic Search:Verify that Selection of Assets across the pages is
	// maintained in case user changes the ‘Result Number’
	// BS-2748
	@Test(priority = 28)
	public void Verify_GenericSearch_Selection_Of_Assets_Maintained_Across_Pages() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
	}

	// 28.Advance Search:Verify that Selection of Assets across the pages is
	// maintained in case user changes the ‘Result Number’
	// BS-2748
	@Test(priority = 29)
	public void Verify_AdvanceSearch_Selection_Of_Assets_Maintained_Across_Pages() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox("epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectNumberFromResultDropDown("20");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(PageSelectionThisPage);
		test.SearchPage.SelectNumberFromResultDropDown("10");
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);

		test.SearchPage.NavigateToPage("2");
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageIsSelectedInDropDown(PageSelectionThisPage);
	}

	// 29.Verify the Select All/This page/None feature at Step 3 of Publish modal
	// window for Approve/ Unapprove functionality.
	// BS-2213
	@Test(priority = 30)
	public void Verify_Select_All_Feature_On_Publish_Modal_Window() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionThisPage);
		test.projectView.VerifyAllTheAssetsAreSelectedForPerticularPageOfPublishWindow();
		test.projectView.ClickPageNumberInStep3OfPublishWindow(2);
		test.projectView.VerifyAllTheAssetsAreNotSelectedForPerticularPageOfPublishWindow();
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.ClickPageNumberInStep3OfPublishWindow(1);
		test.projectView.VerifyAllTheAssetsAreSelectedToPublishInStep3();
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionNone);
		test.projectView.ClickPageNumberInStep3OfPublishWindow(1);
		test.projectView.VerifyNoTheAssetsAreSelectedToPublishInStep3();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
