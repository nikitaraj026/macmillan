package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Content_Tab_Ticket_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, DownloadStartMsg, ISBN, ISBN2, DamContent;
	String OrganisedDownloadMsg, DownloadStartMsgAdv, LookForProject, LookForBoth, LookForAsset;
	String ContentTypeInAdvSearch, TypesOfContentEnhancedEpub, TypesOfContentFlatEpub, TypesOfContentBatchEnhanced,
			TypesOfContentBatchFlat;
	String FrostIsbnToEnter, SortByTitle, SortByModified, SortByRepository,TypeOfContentCoverDesign,TypeOfContentCFI;
	String SearchAllType;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		DownloadStartMsg = getData("DownloadStartMsg");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		DamContent = getData("DamContent");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsg");
		DownloadStartMsgAdv = getData("DownloadStartMsgAdv");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		LookForAsset = getData("LookFor.Assets");
		ContentTypeInAdvSearch = getData("SearchTypeAdvanceSearch.Content Type");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentBatchEnhanced = getData("TypesOfContent.Flat ePub > Batch");
		TypesOfContentBatchFlat = getData("TypesOfContent.Enhanced ePub > Batch");
		TypeOfContentCoverDesign=getData("TypesOfContent.Covers>Cover Design");
		TypeOfContentCFI=getData("TypesOfContent.Project Support Materials>CFI");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		SortByTitle = getData("SortBy.Title");
		SortByModified = getData("SortBy.Modified");
		SortByRepository = getData("SortBy.Repository");
		SearchAllType= getData("SearchType.All Types");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that correct count of the assets to be downloaded should be
	// displayed in the toaster message for Home> Content Tab> Organized download
	// workflow
	// @BS-2148
	@Test(priority = 2)
	public void Verify_Correct_Assert_Count_Displayed_In_Toaster_Message_For_Organized_Download() {
		test.HomePage.ClickContentTab();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "1");
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		;
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "2");
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("10");
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "10");
	}

	// 2.Verify that correct count of the assets to be downloaded should be
	// displayed in the toaster message for Home> Content Tab> Download Content
	// workflow
	// @BS-2148
	@Test(priority = 3)
	public void Verify_Correct_Assert_Count_Displayed_In_Toaster_Message_For_Download_Content() throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickOpenRepository("CMS");
		// test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");
	}

	// 3.Verify that correct count of the assets to be downloaded should be
	// displayed in the toaster message when user has directly selected some of the
	// Assets and clicked the Download content link from the Advanced Search page
	// @BS-2148
	@Test(priority = 4)
	public void Verify_Correct_Assert_Count_Displayed_In_Toaster_Message_For_Advance_Search_Download_Content()
			throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN + " epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectAssetOnSearchPage(ISBN + ".epub");
		test.SearchPage.clickDownloadContent();
		test.SearchPage.VerifyDownloadIsStartedFromAdvanceSearch();

		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.SelectContents(2);
		test.SearchPage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsgAdv, "");
	}

	// 4.Verify that correct count of the assets to be downloaded should be
	// displayed in the toaster message when user has clicked on the Download
	// content link provided that user has made an Organized download earlier
	// @BS-2148
	@Test(priority = 5)
	public void Verify_Correct_Count_Of_Assets_To_Downloaded_Displayed_In_Download_Content_After_Organized_Download()
			throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectMultipleContentToDownload("5");
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "5");
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");
	}

	// 5.Verify that correct count of the assets to be downloaded should be
	// displayed in the toaster message when user has clicked on the Download
	// content link from Content Page view [Non-CMS assets]
	// @BS-2148
	@Test(priority = 6)
	public void Verify_Correct_Assert_Count_Displayed_In_Toaster_Message_For_Download_Content_For_Non_Cms_Assets()
			throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");

		test.Contentpage.SelectMultipleContentToDownload("6");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "4");// (6-2)

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("10");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "10");
	}

	// 6.Verify that only a single result is displayed when user searches with exact
	// 13 digit ISBN in 'Add Content to Project' pop-up from Content tab page
	// BS-1653
	@Test(priority = 7)
	public void Verify_In_Add_Content_To_Project_Only_A_Single_Result_Is_Displayed_For_Exact_13_Digit_ISBN() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.SelectContentOnContentTab(ISBN + ".epub", TypesOfContentEnhancedEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.SearchForProjectOnAddRemoveContent(ISBN2);
		test.Contentpage.VerifyOneProjectDisplayed();
	}

	// 7.Verify that the message appear when user performs the Organized download
	// via Content tab page
	// BS-1582
	@Test(priority = 8)
	public void Verify_Message_On_Organized_Download_Via_Content_Tab_Page() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.HomePage.ClickOpenRepository("CMS");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "1");
		test.refreshPage();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "2");
	}

	// 8.Verify message appears in Green text and light green background with a
	// cross icon to the right
	// BS-1582
	@Test(priority = 9)
	public void Verify_Message_Appears_In_Green_Text_And_Light_Green_Background_With_A_Cross_Icon() throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.VerifyColourAndCrossIconOnMessageDisplayed();
	}

	// 9.Verify that Success message appears when user adds single asset to single
	// project from Content Tab
	// BS-2023
	@Test(priority = 10)
	public void Verify_Success_Message_Appears_When_User_Adds_Single_Asset_To_Single_Project() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN2 + "_FC.jpg");
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_FC.jpg",TypeOfContentCoverDesign);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_FC.jpg", TypeOfContentCoverDesign);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 10.Verify that Success message appears when user adds multiple assets one
	// after another to same or different project from Content Tab without
	// refreshing the page.
	// BS-2023
	@Test(priority = 11)
	public void Verify_Success_Message_Appears_When_User_Adds_Multiple_Assets_One_After_Another() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN2);

		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN2);
	}

	// 11.Verify that Success message appears when user adds single asset to single
	// project from Generic Search page
	// BS-2023
	@Test(priority = 12)
	public void Verify_Success_Message_Appears_When_User_Adds_Single_Asset_To_Single_Project_From_Generic_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN2 + "_FC.jpg");
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_FC.jpg",TypeOfContentCoverDesign);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_FC.jpg", TypeOfContentCoverDesign);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 12.Verify that Success message appears when user adds multiple assets one
	// after another to same or different project from Generic search page without
	// refreshing the page.
	// BS-2023
	@Test(priority = 13)
	public void Verify_Success_Message_Appears_When_User_Adds_Multiple_assets_One_after_another_From_Generic_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN2);
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_FC.jpg",TypeOfContentCoverDesign);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_FC.jpg",TypeOfContentCoverDesign);// To Unselect the FC File

		test.Contentpage.SelectContentOnContentTab(ISBN2+"_Epub.epub",TypesOfContentFlatEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_FC.jpg", TypeOfContentCoverDesign);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);

		test.ContentView.navigateBack();
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 13.Verify that Success message appears when user adds single asset to single
	// project from Advanced Search page
	// BS-2023
	@Test(priority = 14)
	public void Verify_Success_Message_Appears_When_User_Adds_Single_Asset_project_From_Advanced_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN2);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectAssetOnSearchPage(ISBN2 + "_FC.jpg");
		test.SearchPage.ClickAddToProject();
		test.SearchPage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_FC.jpg",TypeOfContentCoverDesign);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 14.Verify that Success message appears when user adds multiple assets one
	// after another to same or different project from Advanced Search page without
	// refreshing the page.
	// BS-2023
	@Test(priority = 15)
	public void Verify_Success_Message_Appears_When_User_Adds_Multiple_Assets_One_After_Another_From_Advanced_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN2);
		test.SearchPage.ClickSearchButton();

		test.SearchPage.SelectAssetOnSearchPage(ISBN2 + "_FC.jpg");
		test.SearchPage.ClickAddToProject();
		test.SearchPage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);
		test.SearchPage.SelectAssetOnSearchPage(ISBN2 + "_FC.jpg"); // Unselect the File...

		test.SearchPage.SelectAssetOnSearchPage(ISBN2 + "_EPUB.epub");
		test.SearchPage.ClickAddToProject();
		test.SearchPage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_FC.jpg",TypeOfContentCoverDesign);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);

		test.ContentView.navigateBack();
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 15.Verify that Content Type > Content Subtype has been updated in Content tab
	// page
	// BS-2235
	@Test(priority = 16)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Content_Tab() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifySubtypeIsDisplayed();
	}

	// 16.Verify that Content Type > Content Subtype has been updated in Generic
	// Search Result page
	// BS-2235
	@Test(priority = 17)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Generic_Search_Page() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.VerifySubtypeIsDisplayed();
	}

	// 17.Verify that Content Type > Content Subtype has been updated in Advanced
	// Search Pop up> Content type dropdown
	// BS-2235
	@Test(priority = 18)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Advanced_Search_PopUp() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(ContentTypeInAdvSearch);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentEnhancedEpub);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentFlatEpub);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentBatchEnhanced);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentBatchFlat);
	}

	// 18.Verify that Content Type > Content Subtype has been updated in Advanced
	// Search page
	// BS-2235
	@Test(priority = 19)
	public void Verify_Content_Subtype_Has_Been_Updated_In_Advanced_Search_Page() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(ContentTypeInAdvSearch);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentEnhancedEpub);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifySubtypeIsDisplayedInAdvanceSearch();
	}

	// 19."Verifiy that user is able to check the Projects displaying under
	// 'Selected' section and can move them to 'Available' section by clicking the
	// 'Unselect button for following workflows:b) When Project ISBNs are added on
	// the go"
	// BS-1997
	@Test(priority = 20)
	public void Verify_User_Is_Able_To_Move_Content_From_Selected_To_Available_Section_When_ISBN_Are_Added_On_The_Go() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + " epub");
		test.Contentpage.SelectContentOnContentTab(ISBN + ".epub", TypesOfContentEnhancedEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.SearchForProjectOnAddRemoveContent(ISBN2);
		test.Contentpage.VerifyProjectDisplayedInAvailablePane(ISBN2);
		test.Contentpage.SelectProjectInAvailablePane(ISBN2);
		test.Contentpage.ClickSelectButtonAndVerifyContentMoved(ISBN2);

		test.Contentpage.VerifyProjectDisplayedInSelectedPane(ISBN2);
		test.Contentpage.SelectTheProjectOnSelectedContent(ISBN2);
		test.Contentpage.UnselectTheTheProjectOnSelectedContent();
		test.Contentpage.VerifyProjectNotDisplayedInSelectedPane(ISBN2);
	}

	// 20."Verifiy that user is able to check the Projects displaying under
	// 'Selected' section and can move them to 'Available' section by clicking the
	// 'Unselect button for following workflows:c) When some Project ISBNs are
	// already associated and more are added on the go"
	// BS-1997
	@Test(priority = 21)
	public void Verify_User_Is_Able_To_Move_Content_From_Selected_To_Available_Section_When_More_ISBN_Are_Added_On_The_Go() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN + "_CFI.csv");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_CFI.csv", TypeOfContentCFI);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();

		test.Contentpage.SearchForProjectOnAddRemoveContent(ISBN2);
		test.Contentpage.VerifyProjectDisplayedInAvailablePane(ISBN2);
		test.Contentpage.SelectProjectInAvailablePane(ISBN2);
		test.Contentpage.ClickSelectButtonAndVerifyContentMoved(ISBN2); // First Project is Added to Select Pane

		test.Contentpage.SearchForProjectOnAddRemoveContent(FrostIsbnToEnter);
		test.Contentpage.VerifyProjectDisplayedInAvailablePane(FrostIsbnToEnter);
		test.Contentpage.SelectProjectInAvailablePane(FrostIsbnToEnter);
		test.Contentpage.ClickSelectButtonAndVerifyContentMoved(ISBN2); // Second Project is Added to Select Pane

		test.Contentpage.VerifyProjectDisplayedInSelectedPane(ISBN2);
		test.Contentpage.VerifyProjectDisplayedInSelectedPane(FrostIsbnToEnter);
		test.Contentpage.SelectTheProjectOnSelectedContent(ISBN2);
		test.Contentpage.SelectTheProjectOnSelectedContent(FrostIsbnToEnter);
		test.Contentpage.UnselectTheTheProjectOnSelectedContent();
		test.Contentpage.VerifyProjectNotDisplayedInSelectedPane(ISBN2);
		test.Contentpage.VerifyProjectNotDisplayedInSelectedPane(FrostIsbnToEnter);
	}

	// 21.Verify that 'Select All' button under Selected section selects all the
	// Project ISBNs available under that section and user can move them to
	// 'Available' section.
	// BS-1997
	@Test(priority = 22)
	public void Verify_Select_All_Button_Moves_All_The_Project_To_Available_Section() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN + "_CFI.csv");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_CFI.csv", TypeOfContentCFI);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();

		test.Contentpage.SearchForProjectOnAddRemoveContent(FrostIsbnToEnter);
		test.Contentpage.VerifyProjectDisplayedInAvailablePane(FrostIsbnToEnter);
		test.Contentpage.SelectProjectInAvailablePane(FrostIsbnToEnter);
		test.Contentpage.ClickSelectButtonAndVerifyContentMoved(FrostIsbnToEnter); // First Project is Added to Select
																					// Pane

		test.Contentpage.SearchForProjectOnAddRemoveContent(ISBN2);
		test.Contentpage.VerifyProjectDisplayedInAvailablePane(ISBN2);
		test.Contentpage.SelectProjectInAvailablePane(ISBN2);
		test.Contentpage.ClickSelectButtonAndVerifyContentMoved(ISBN2); // Second Project is Added to Select Pane

		test.Contentpage.ClickSelectAllCheckBoxOnSelectedPane();
		test.Contentpage.UnselectTheTheProjectOnSelectedContent();
		test.Contentpage.VerifyNoProjectDisplayedInSelectedPane();
	}

	// 22.Verify that Pagination is getting updated as per the Projects left under
	// 'Selected' section.
	// BS-1997
	@Test(priority = 23)
	public void Verify_Pagination_Is_Updated_As_The_Projects_Removed_From_Selected_Pane() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN + "_CFI.csv");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_CFI.csv",TypeOfContentCFI);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();

		test.Contentpage.SearchForProjectOnAddRemoveContent("*");
		test.Contentpage.ClickSelectAllCheckBoxOnAvailablePane();
		test.Contentpage.ClickSelectButton();

		test.Contentpage.NavigateToPageNumberInAvailablePane("2");
		test.Contentpage.ClickSelectAllCheckBoxOnAvailablePane();
		test.Contentpage.ClickSelectButton();

		test.Contentpage.NavigateToPageNumberInAvailablePane("3");
		test.Contentpage.ClickSelectAllCheckBoxOnAvailablePane();
		test.Contentpage.ClickSelectButton();

		test.Contentpage.VerifyPaginationIsUpdatedAsProjectsRemovedFromSelectedPane();
	}

	// 23."Content Tab page> Download Content functionality for following cases: a)
	// Single CMS Asset : Download starts right away"
	// Bs-2529
	@Test(priority = 24)
	public void Verify_For_Content_Tab_When_Downloading_Single_CMS_Asset_No_Toaster_Message_And_Download_Is_Started()
			throws IOException {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_EPUB.epub", TypesOfContentFlatEpub);
		test.Contentpage.clickDownloadContent();
		test.Contentpage.VerifyMessageNotDisplayedOnDownloadingContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN + "_EPUB.epub");
	}

	// 24."Content Tab page> Download Content functionality for following cases: b)
	// Single Non CMS Asset/ multiple CMS Asset/ multiple non-CMS asset: Toaster
	// message is displayed and download link is received."
	// Bs-2529
	@Test(priority = 25)
	public void Verify_For_Content_Tab_Download_Message_Is_Displayed_For_Single_Multiple_Non_CMS_Asset()
			throws IOException {
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("1");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "1");

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("CMS");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");
	}

	// 25."Generic Search> Download Content functionality for following cases: a)
	// Single CMS Asset: Download starts right away"
	// Bs-2529
	@Test(priority = 26)
	public void Verify_For_Generic_Search_When_Downloading_Single_CMS_Asset_No_Toaster_Message_And_Download_Is_Started()
			throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.Contentpage.SearchForAnItem(ISBN + "_FC.jpg");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_FC.jpg", TypeOfContentCoverDesign);
		test.Contentpage.clickDownloadContent();
		test.Contentpage.VerifyMessageNotDisplayedOnDownloadingContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN + "_FC.jpg");
	}

	// 26."Generic Search> Download Content functionality for following cases: b)
	// Single Non CMS Asset/ multiple CMS Asset/ multiple non-CMS asset: Toaster
	// message is displayed and download link is received."
	// BS-2529
	@Test(priority = 27)
	public void Verify_For_Generic_Search_Download_Message_Is_Displayed_For_Single_Multiple_Non_CMS_Asset()
			throws IOException {
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem("DAM");
		test.Contentpage.SelectMultipleContentToDownload("1");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "1");

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("CMS");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");
	}

	// 27."Content tab page: Verify that when user checks the Select All button on a
	// page, then depending upon the assets displaying in that page, all the assets
	// available are getting checked"
	// BS-2599
	@Test(priority = 28)
	public void Verify_All_The_Assets_Available_Are_Getting_Checked_When_User_Checks_Select_All() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTab();
	}

	// 28."Content tab page: Verify that if user unchecks the Select All button,
	// then all the selected assets in that page gets de-selected"
	// BS-2599
	@Test(priority = 29)
	public void Verify_All_The_Selected_Assets_In_That_Page_Gets_DeSelected_If_User_Unchecks_The_Select_All() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.clickSelectAllOnContentTab(); // To Unselect the Content..
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTab();
	}

	// 29."Content tab page: Verify that when all the assets are selected, then if
	// user unselects any of the asset, the Select All checkbox gets de selected and
	// selects the same again, then Select All checkbox gets checked"
	// BS-2599
	@Test(priority = 30)
	public void Verify_If_User_Unselects_Any_Of_The_Asset_The_Select_All_Checkbox_Gets_DeSelected() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifySelectAllIsUnchecked();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifySelectAllIsChecked();
	}

	// 30."Content tab page: Verify that if user moves to next page after selecting
	// all the assets from page 1, then clicking Select All will select all the
	// assets of page 2 and on moving back to page 1 then selection is maintained."
	// BS-2599
	@Test(priority = 31)
	public void Verify_Selection_Is_Maintained_If_User_Moves_To_Next_Page() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
	}

	// 31."Content tab page: Verify that if user moves to next page after selecting
	// all the assets from page 1, then clicking Select All will select all the
	// assets of page 2 and clicking unselect will unselect the assets of page 2
	// only i.e. on moving back to page 1 the selection is maintained."
	// BS-2599
	@Test(priority = 32)
	public void Verify_Selection_Is_Maintained_for_Frist_Page_If_Assets_Of_Page_2_Are_unselected() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTab();
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
	}

	// 32."Content tab page: Verify that selection is maintained across the pages if
	// user modifies the Sort By setting."
	// BS-2599
	@Test(priority = 33)
	public void Verify_Selection_Is_Maintained_Across_The_Pages_If_User_Modifies_The_Sort_By() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.sortBy(SortByTitle);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.sortBy(SortByModified);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.sortBy(SortByTitle);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.sortBy(SortByModified);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.sortBy(SortByTitle);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.sortBy(SortByModified);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
	}

	// 33."Content tab page: Verify that if user has selected 100 assets using
	// select all, and then changes the number to 10, 20, or 50, then assets are
	// displayed selected in 10 pages, 5 pages and 2 pages with Select all checked"
	// BS-2599
	@Test(priority = 34)
	public void Verify_If_User_Changes_Number_In_Result_Number_DropDown_Selection_Are_Maintained_Accordingly() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectNumberFromResultDropDown("100");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.SelectNumberFromResultDropDown("50");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsChecked();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsChecked();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectNumberFromResultDropDown("50");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsChecked();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsChecked();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.Contentpage.NavigateToPage("3");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsUnchecked();
		test.Contentpage.VerifyContentsAreSelected(10);
	}

	// 34."Content tab page: Verify that if 10 assets are displaying in the page and
	// user has selected all, then on changing it to bigger number like 20, 50, 100,
	// the selected assets are retained however, Select All checkbox gets unchecked.
	// Changing back to 10 will select the Select All button again"
	// BS-2599
	@Test(priority = 35)
	public void Verify_User_Have_Selected_All_The_Asset_And_On_Changing_The_ResultNumber_To_Bigger_Value() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.VerifySelectAllIsChecked();

		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsUnchecked();
		test.Contentpage.VerifyContentsAreSelected(10);

		test.Contentpage.SelectNumberFromResultDropDown("50");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsUnchecked();
		test.Contentpage.VerifyContentsAreSelected(10);

		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsChecked();
		test.Contentpage.VerifyContentsAreSelected(10);
	}

	// 35."Content tab page: Verify that if user has selected 15 assets in continuos
	// manually when 20 assets are displaying on the page, then if user changes it
	// to 10, then for first page, Select All is checked and all the 10 are
	// displayed as selected and 5 assets are selected on the second page."
	// BS-2599
	@Test(priority = 36)
	public void Verify_User_Has_Selected_15_Assets_Manually_And_ResultNumber_Changed_To_10() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("15");
		test.Contentpage.VerifyContentsAreSelected(15);
		test.Contentpage.VerifySelectAllIsUnchecked();

		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.VerifySelectAllIsChecked();

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelected(5);
		test.Contentpage.VerifySelectAllIsUnchecked();

	}

	// 36."Content tab page: Verify that when user checks the Select All button on a
	// page, then depending upon the assets displaying in that page, all the assets
	// available are getting checked in grid View."
	// BS-2599
	@Test(priority = 37)
	public void Verify_All_The_Assets_Available_Are_Getting_Checked_When_User_Checks_Select_All_In_Grid_View() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTabGridView();
	}

	// 37."Content tab page: Verify that if user unchecks the Select All button,
	// then all the selected assets in that page gets de-selected in Grid View."
	// BS-2599
	@Test(priority = 38)
	public void Verify_All_The_Selected_Assets_In_That_Page_Gets_DeSelected_If_User_Unchecks_The_Select_All_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.clickSelectAllOnContentTabGridView(); // To Unselect the Content..
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTabGridView();
	}

	// 38."Content tab page: Verify that when all the assets are selected, then if
	// user unselects any of the asset, the Select All checkbox gets de selected and
	// selects the same again, then Select All checkbox gets checked in Grid view"
	// BS-2599
	@Test(priority = 39)
	public void Verify_If_User_Unselects_Any_Of_The_Asset_The_Select_All_Checkbox_Gets_DeSelected_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.SelectMultipleContentToDownloadGridView("2");
		test.Contentpage.VerifySelectAllIsUncheckedGridView();
		test.Contentpage.SelectMultipleContentToDownloadGridView("2");
		test.Contentpage.VerifySelectAllIsCheckedGridView();
	}

	// 39."Content tab page: Verify that if user moves to next page after selecting
	// all the assets from page 1, then clicking Select All will select all the
	// assets of page 2 and on moving back to page 1 then selection is maintained in
	// Grid View."
	// BS-2599
	@Test(priority = 40)
	public void Verify_Selection_Is_Maintained_If_User_Moves_To_Next_Page_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
	}

	// 40."Content tab page: Verify that if user moves to next page after selecting
	// all the assets from page 1, then clicking Select All will select all the
	// assets of page 2 and clicking unselect will unselect the assets of page 2
	// only i.e. on moving back to page 1 the selection is maintained in Grid View."
	// BS-2599
	@Test(priority = 41)
	public void Verify_Selection_Is_Maintained_for_Frist_Page_If_Assets_Of_Page_2_Are_unselected_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTabGridView();
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
	}

	// 41."Content tab page: Verify that selection is maintained across the pages if
	// user modifies the Sort By setting in Grid View."
	// BS-2599
	@Test(priority = 42)
	public void Verify_Selection_Is_Maintained_Across_The_Pages_If_User_Modifies_The_Sort_By_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.sortBy(SortByTitle);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.sortBy(SortByModified);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.sortBy(SortByTitle);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.sortBy(SortByModified);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.sortBy(SortByTitle);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.sortBy(SortByModified);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
	}

	// 42."Content tab page: Verify that if user has selected 100 assets using
	// select all, and then changes the number to 10, 20, or 50, then assets are
	// displayed selected in 10 pages, 5 pages and 2 pages with Select all checked
	// in Grid View."
	// BS-2599
	@Test(priority = 43)
	public void Verify_If_User_Changes_Number_In_Result_Number_DropDown_Selection_Are_Maintained_Accordingly_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.SelectNumberFromResultDropDown("100");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.SelectNumberFromResultDropDown("50");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsCheckedGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsCheckedGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectNumberFromResultDropDown("50");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsChecked();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsChecked();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

		test.Contentpage.NavigateToPage("3");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsUnchecked();
		test.Contentpage.VerifyContentsAreSelected(10);
	}

	// 43."Content tab page: Verify that if 10 assets are displaying in the page and
	// user has selected all, then on changing it to bigger number like 20, 50, 100,
	// the selected assets are retained however, Select All checkbox gets unchecked.
	// Changing back to 10 will select the Select All button again in GridView"
	// BS-2599
	@Test(priority = 44)
	public void Verify_User_Have_Selected_All_The_Asset_And_On_Changing_The_ResultNumber_To_Bigger_Value_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTabGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.VerifySelectAllIsCheckedGridView();

		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.VerifySelectAllIsUncheckedGridView();
		test.Contentpage.VerifyContentsAreSelectedGridView(10);

		test.Contentpage.SelectNumberFromResultDropDown("50");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsUncheckedGridView();
		test.Contentpage.VerifyContentsAreSelectedGridView(10);

		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifySelectAllIsCheckedGridView();
		test.Contentpage.VerifyContentsAreSelectedGridView(10);
	}

	// 44."Content tab page: Verify that if user has selected 15 assets in continuos
	// manually when 20 assets are displaying on the page, then if user changes it
	// to 10, then for first page, Select All is checked and all the 10 are
	// displayed as selected and 5 assets are selected on the second page in Grid
	// View."
	// BS-2599
	@Test(priority = 45)
	public void Verify_User_Has_Selected_15_Assets_Manually_And_ResultNumber_Changed_To_10_GridView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownloadGridView("15");
		test.Contentpage.VerifyContentsAreSelectedGridView(15);
		test.Contentpage.VerifySelectAllIsUncheckedGridView();

		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.VerifySelectAllIsCheckedGridView();

		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedGridView(5);
		test.Contentpage.VerifySelectAllIsUncheckedGridView();

	}

	// 45."Content tab page: Verify that if user selects all the assets in a page>
	// changes the view to Grid> then selection of assets should be maintained and
	// the Select All checkbox should be displayed as Checked"
	// BS-2599
	@Test(priority = 46)
	public void Verify_Selected_Asset_Are_Maintained_In_Grid_View() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.ClickGridView();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.VerifyContentsAreSelectedOnContantTabGridView();
		test.Contentpage.VerifySelectAllIsCheckedGridView();
	}

	// 46."Content tab page: Verify that count for the selected assets is displayed
	// right next to the Content heading"
	// BS-2599
	@Test(priority = 47)
	public void Verify_Count_For_Selected_Assets_Is_Displayed_Right_Next_To_Content_Heading() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(10);

		test.Contentpage.SelectNumberFromResultDropDown("20");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(10);
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(20);

		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(20);

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(2);
	}

	// 47."Content tab page: Verify that selection dissolves if user refreshes the
	// page or modified the search query"
	// BS-2599
	@Test(priority = 48)
	public void verify_Selection_Dissolves_If_User_Refreshes_The_Page_Or_Modified_The_Search_Query() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(2);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(0);

		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(2);
		test.Contentpage.SearchForAnItem(ISBN);
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(0);
	}

	// 48."Generic Search page: Verify that count for the selected assets is
	// displayed right next to the Content heading when the search is made with 'All
	// Types'"
	// BS-2599
	@Test(priority = 49)
	public void Verify_Count_For_Selected_Assets_Is_Displayed_Right_Next_To_Content_Heading_For_All_Types_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SelectSearchType(SearchAllType);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(2);
	}

	// 49."Generic Search page: Verify that selection dissolves if user refreshes
	// the page or modified the search query when the search is made with 'All
	// Types'"
	// BS-2599
	@Test(priority = 50)
	public void verify_Selection_Dissolves_If_User_Refreshes_The_Page_Or_Modified_The_Search_Query_For_All_Types_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectSearchType(SearchAllType);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(2);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(0);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}