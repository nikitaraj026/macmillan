package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Content_Tab_Test_Extended extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, DownloadStartMsg, ISBN, ISBN2, DamContent;
	String DownloadStartMsgMulti, OrganisedDownloadMsg, DownloadStartMsgAdv, LookForProject, LookForBoth, LookForAsset;
	String ContentTypeInAdvSearch, TypesOfContentEnhancedEpub, TypesOfContentFlatEpub, TypesOfContentBatchEnhanced,
			TypesOfContentBatchFlat;
	String FrostIsbnToEnter, SortByTitle, SortByModified, SortByRepository, TypeAllSearch, ProjectSearch, ContentSearch;
	String MarketingAuthorImage, TypeOfContentMarketingAuthorImage, AdvSearchTypeContentType,
			PublihDestinationInstructorStore;
	String AuthorName, AuthorId, PageSelectionThisPage;
	String RepoBrightCove, BrightcoveMsg,CMSRepository,AdvSearchTypeRepository;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		DownloadStartMsg = getData("DownloadStartMsg");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		DamContent = getData("DamContent");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsg");
		DownloadStartMsgAdv = getData("DownloadStartMsgAdv");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		LookForAsset = getData("LookFor.Assets");
		ContentTypeInAdvSearch = getData("SearchTypeAdvanceSearch.Content Type");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentBatchEnhanced = getData("TypesOfContent.Flat ePub > Batch");
		TypesOfContentBatchFlat = getData("TypesOfContent.Enhanced ePub > Batch");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		SortByTitle = getData("SortBy.Title");
		SortByModified = getData("SortBy.Modified");
		SortByRepository = getData("SortBy.Repository");
		TypeAllSearch = getData("SearchType.All Types");
		ProjectSearch = getData("SearchType.Project");
		ContentSearch = getData("SearchType.content");
		MarketingAuthorImage = getData("MarketingAuthorImage");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		AdvSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		AuthorName = getData("Author.Name");
		AuthorId = getData("Author.id");
		PageSelectionThisPage = getData("PageSelection.This Page");
		RepoBrightCove = getData("NonCMSAssert.BrightCove");
		BrightcoveMsg = getData("BrightcoveMsg");
		CMSRepository=getData("Repository.CMS");
		
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1."Generic Search page: Verify that user should not be able to Select any
	// Project using Select All button when search is made for 'Projects'"
	// BS-2599
	@Test(priority = 2)
	public void VerifyUser_Is_Not_Able_To_Select_Any_Project_Using_Select_All_Button() {
		test.HomePage.ClickContentTab();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.SelectSearchType(ProjectSearch);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTab();
	}

	// 2."Advanced Search page: Verify when the search is made with 'Assets''/
	// 'Assets and Projects'. Make sure that no Projects are getting selected
	// while clicking Select All."
	// BS-2599
	@Test(priority = 3)
	public void Verify_No_Projects_Are_Getting_Selected_While_Clicking_Select_All() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.SearchPage.VerifyContentsAreSelected();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.VerifyProjectsAreNotSelected();
	}

	// 3."Advanced Search page: Verify that user should not be able to check the
	// Select All button when search is made for 'Projects' only"
	// BS-2599
	@Test(priority = 4)
	public void Verify_User_Not_Able_To_Check_Select_All_Button_When_Search_Is_Made_For_Projects() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionThisPage);
		test.SearchPage.VerifyProjectsAreNotSelected();
	}

	// 4."Advanced Search page: Verify that count for the selected assets is
	// displayed right next to the Content heading"
	// BS-2599
	@Test(priority = 5)
	public void Verify_Count_For_Selected_Assets_Displayed_Right_Next_To_Content_Heading() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.SelectContents(2);
		test.SearchPage.VerifyCountofSelectedAssetOnAdvanceSearch(2);
	}

	// 5."Verify that User can view the new content type in:
	// 1) Content tab
	// 2) Generic Search page
	// 3) Advanced Search page
	// 4) Push to authoring tool window
	// 5) Project View> Publish window
	// 6) Content view> Publish window
	// 7) Associated filter
	// BS-2394
	@Test(priority = 6)
	public void Verify_User_Can_View_The_New_Content_Type_In_All_General_Flow() {
		test.HomePage.ClickDashBord();
		test.Contentpage.SearchForAnItem(MarketingAuthorImage);
		test.Contentpage.VerifyContentType(TypeOfContentMarketingAuthorImage);
		test.Contentpage.SelectContentOnContentTab(MarketingAuthorImage,TypeOfContentMarketingAuthorImage);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.Contentpage.opentheSearchContent(MarketingAuthorImage);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyContentSubtypeInPushToAuthoringToolGridView(TypeOfContentMarketingAuthorImage);
		test.ContentView.ClickCloseIconOnPushToAuthoringTool();

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyContentTypeInPublishWindow(TypeOfContentMarketingAuthorImage);
		test.ContentView.ClickCloseOnpublishPopup();

		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.VerifyContentType(TypeOfContentMarketingAuthorImage);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.FilterContent(TypeOfContentMarketingAuthorImage);

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyContentTypeDisplayedInStep2PublishWindow(TypeOfContentMarketingAuthorImage);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentMarketingAuthorImage,
				MarketingAuthorImage,true);
		test.projectView.VerifyContentTypeDisplayedInStep3PublishWindow(TypeOfContentMarketingAuthorImage);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 6.Verify that user is able to perform Advanced search with this newly
	// added Content type
	// BS-2394
	@Test(priority = 7)
	public void Verify_User_Is_Able_To_Perform_Advanced_Search_For_Marketing_Author_Image() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.EnterTextIntoSearchBox(MarketingAuthorImage);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.VerifyContentType(TypeOfContentMarketingAuthorImage);
	}

	// 7.Verify Top 4 Grayed out links available at the top are not clickable for
	// 'Generic Search'.
	// BS-2640
	@Test(priority = 8)
	public void Verify_Top4_Grayed_Out_Links_Not_Clickable_For_Generic_Search() throws IOException {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.Verify_Links_Are_Deactivated();
	}

	// 8.Verify Top 4 Grayed out links available at the top are not clickable for '
	// Advanced Search'.
	// BS-2640
	@Test(priority = 9)
	public void Verify_Top4_Grayed_Out_Links_Not_Clickable_For_Advance_Search() throws IOException {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.Contentpage.Verify_Links_Are_Deactivated();
	}

	// 9.Verified that links become active once any asset is selected by the user.
	// BS-2640
	@Test(priority = 10)
	public void Verify_Links_Become_Active_Once_Any_Asset_Is_Selected_By_User() {
		test.SearchPage.SelectContents(1);
		test.Contentpage.Verify_Links_Are_Activated();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSingleContents();
		test.Contentpage.Verify_Links_Are_Activated();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.Verify_Links_Are_Activated();
	}
	
	//1. Remove the ‘Clear all’ link from the pop-up.
	//BS-1665
	@Test(priority = 11)
	public void Verify_Clear_All_Link_Removed_From_Add_Remove() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.verifyClearAllLinkNotDisplayedOnAddtoProjectpopUp();
	}
	
	//2. Cross icon should appear inside the 'Search Projects' text box on keying the text.
	//BS-1665
	@Test(priority = 12)
	public void Verify_X_Icon_Displayed_On_Add_Remove() {
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.SearchForProjectOnAddRemoveContent(ISBN);
		test.Contentpage.verifySearchFieldAnd_xIconOnAddtoProjectpopUp();
	}
	
	//3. Clicking on the ‘Cross’ icon should clear the keyed text from the Search box.
	//BS-1665
	@Test(priority = 13)
	public void Verify_Cross_Icon_Should_Clear_The_keyed_Text() {
		test.Contentpage.clickXIconOnAddRemoveProject();
		test.Contentpage.VerifyInputBoxClearOnAddRemoveProject();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
