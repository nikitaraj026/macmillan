package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_InstructorStore_Publish_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String ISBN, PassResetEmail, CurrentResetPassword, ProjectISBN, PublihDestinationInstructorStore;
	String TypeOfContentCourseManagement, CourseManagementAsset, TypeOfContentMarketingSampleChapter,
			MarketingSampleChapter;
	String selectAllPages, AuthorImageAsset,CMSRepository;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		ProjectISBN = getData("ProjectISBNNo2");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		TypeOfContentCourseManagement = getData("TypesOfContent.Supplementary Content>Course Management");
		CourseManagementAsset = getData("SupplementaryCourseManagement");
		AuthorImageAsset = getData("MarketingAuthorImage");
		TypeOfContentMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		MarketingSampleChapter = getData("MarketingSampleChapter");
		selectAllPages = getData("PageSelection.All Pages");
		CMSRepository=getData("Repository.CMS");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application and steup test Datas
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(CourseManagementAsset);
		test.Contentpage.SelectContentOnContentTab(CourseManagementAsset, TypeOfContentCourseManagement);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ProjectISBN);
		test.Contentpage.SearchForAnItem(MarketingSampleChapter);
		test.Contentpage.SelectContentOnContentTab(MarketingSampleChapter, TypeOfContentMarketingSampleChapter);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.AddSelectedContentToProject(ProjectISBN);
	}

	// 1) Verify that Publish status is displayed as Complete when single IR, CM
	// or SC asset is published with single ISBN to Instructor Store.
	// BS-2802
	@Test(priority = 2)
	public void Publish_single_CM_Asset_With_Single_ISBN() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ProjectISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentCourseManagement,
				CourseManagementAsset,true);
		test.projectView.Select_Assert_Displayed_In_Step3(CourseManagementAsset);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 2) Verify that Publish status is displayed as Complete when single IR, CM
	// or SC asset is published to additional ISBN (main ISBN is deleted) to
	// Instructor Store.
	// BS-2802
	@Test(priority = 3)
	public void Publish_single_CM_Asset_With_Single_ISBN_Without_Default_ISBN() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ProjectISBN);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ProjectISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ProjectISBN);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentCourseManagement,
				CourseManagementAsset,true);
		test.projectView.Select_Assert_Displayed_In_Step3(CourseManagementAsset);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 3) Verify that Publish status is displayed as Complete when single IR, CM
	// or SC asset is published with multiple ISBNs to Instructor Store.
	// BS-2802
	@Test(priority = 4)
	public void Publish_single_CM_Asset_With_Single_ISBN_With_Multiple_ISBN() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ProjectISBN);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentCourseManagement,
				CourseManagementAsset,true);
		test.projectView.Select_Assert_Displayed_In_Step3(CourseManagementAsset);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 4.Verify that CMS displays the Publish status as Complete when either SINGLE
	// or MULTIPLE IR, CM or SC assets are published to Instructor Store
	// destination.
	// BS-2780
	@Test(priority = 5)
	public void Publish_Multiple_Asset_To_Instructor() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ProjectISBN);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentCourseManagement,
				CourseManagementAsset,true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter,true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(selectAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 5.Content view: Verify that publish status is displayed as Complete when
	// user publishes an asset via Content view.
	// BS-2802
	@Test(priority = 6)
	public void publish_Asset_Via_Content_View() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AuthorImageAsset);
		test.Contentpage.opentheSearchContent(AuthorImageAsset);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 6.Verify that Publish status is displayed as Complete when single IR, CM
	// or SC asset is published with single ISBN to Instructor Store.
	@Test(priority = 7, dependsOnMethods = "Publish_single_CM_Asset_With_Single_ISBN")
	public void Verify_Publish_single_CM_Asset_With_Single_ISBN() throws InterruptedException {
		test.refreshPage();
		test.HomePage.logMessage("Waiting For Assets To be Publish On Instructore......");
		test.HomePage.hardWait(400); ///// Wait for Content To be Publish on
										///// Instructor Store///////
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishStatus("4", "Complete");
	}

	// 7. Verify that Publish status is displayed as Complete when single IR, CM
	// or SC asset is published to additional ISBN (main ISBN is deleted) to
	// Instructor Store.
	@Test(priority = 8, dependsOnMethods = "Publish_single_CM_Asset_With_Single_ISBN_Without_Default_ISBN")
	public void Verify_Publish_single_CM_Asset_With_Single_ISBN_Without_Default_ISBN() throws InterruptedException {
		test.projectView.VerifyPublishStatus("3", "Complete");
	}

	// 8. Verify that Publish status is displayed as Complete when single IR, CM
	// or SC asset is published with multiple ISBNs to Instructor Store.
	@Test(priority = 9, dependsOnMethods = "Publish_single_CM_Asset_With_Single_ISBN_Without_Default_ISBN")
	public void Verify_Publish_single_CM_Asset_With_Single_ISBN_With_Multiple_ISBN() throws InterruptedException {
		test.projectView.VerifyPublishStatus("2", "Complete");
	}

	// 9.Verify that CMS displays the Publish status as Complete when either SINGLE
	// or MULTIPLE IR, CM or SC assets are published to Instructor Store
	// destination.
	@Test(priority = 10, dependsOnMethods = "Publish_Multiple_Asset_To_Instructor")
	public void Verify_Publish_Multiple_Asset_To_Instructor_Status() {
		test.projectView.VerifyPublishStatus("1", "Complete");
	}

	// 10.Content view: Verify that publish status is displayed as Complete when
	// user publishes an asset via Content view.
	@Test(priority = 11/* , dependsOnMethods = "publish_Asset_Via_Content_View" */)
	public void Verify_publish_Status_When_User_Publishes_An_Asset_Via_Content_View() throws InterruptedException {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AuthorImageAsset);
		test.Contentpage.opentheSearchContent(AuthorImageAsset);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.WaitforpublishToComplete("1", "Complete");
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
