package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

public class Reg_Learning_Objective extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String LOF_GeneralChemistry, TestProjectISBN, TestProjectISBN1, LOF_IntroductoryBiology;
	String LOF_MacmillanCalculus, TestDataISBN, TypesOfContentCoverDesign, AssertTitle, LOF_OpenStaxUniversityPhysics;
	String LOS_OpenStaxUniversityPhysics, LOS_MacmillanCalculus;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestProjectISBN = getData("ProjectISBNNo1");
		TestProjectISBN1 = getData("ProjectISBNNo4");
		TestDataISBN = getData("ProjectISBNNO");
		LOF_GeneralChemistry = getData("Framework.General Chemistry (IGC)");
		LOF_IntroductoryBiology = getData("Framework.Introductory Biology");
		LOF_MacmillanCalculus = getData("Framework.macmillan calculus");
		LOF_OpenStaxUniversityPhysics = getData("Framework.OpenStax University Physics");
		LOS_OpenStaxUniversityPhysics = getData("LOS.OpenStax University Physics");
		LOS_MacmillanCalculus = getData("LOS.macmillan calculus");
		TypesOfContentCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		AssertTitle = getStringWithDateAndTimes("AutoCoverDesign");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// "A) Project view page> Learning Objectives tab:
	// 1) Verify that user is able to add a LOF to the Project."
	// BS-3182
	@Test(priority = 2)
	public void Verify_User_Is_Able_To_Add_LOF_To_The_Project() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOF_GeneralChemistry);
		test.projectView.AddLearningObjective(LOF_GeneralChemistry);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOF_GeneralChemistry);
	}

	// "A) Project view page> Learning Objectives tab:
	// 2) Verify that LOF added to the project reflects in the Learning objective
	// tab of each associated content to that project. "
	// BS-3182
	@Test(priority = 3)
	public void Verify_LOF_Added_To_The_Project_Reflects_In_Each_Associated_Content() {
		test.projectView.VerifyFrameWorkIsAddedToAssociatedContent(LOF_GeneralChemistry);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOF_GeneralChemistry);
	}

	// Step:: Add Learning objective FrameWork To Project
	// BS-3182
	@Test(priority = 4)
	public void Step_Add_Learning_Objective_FrameWork_To_Project() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();
		test.projectView.AddLearningObjective(LOF_GeneralChemistry);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOF_GeneralChemistry);
		test.projectView.AddLearningObjective(LOF_MacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOF_MacmillanCalculus);
		test.projectView.AddLearningObjective(LOF_IntroductoryBiology);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOF_IntroductoryBiology);
	}

	// Step:: Associate a content to project
	// BS-3182
	@Test(priority = 5)
	public void Step_Upload_And_Associate_Content_To_Project() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestDataISBN + "_FC.jpg");
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentCoverDesign);
		test.HomePage.EnterTextIntoTitleField(AssertTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestProjectISBN1);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestProjectISBN1);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.HomePage.waitForLoaderToDisappear();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN1);
	}

	// "A) Project view page> Learning Objectives tab:
	// 3)Verify that LOF already added to a Project reflects on the Content if that
	// content is added later."
	// BS-3182
	@Test(priority = 6)
	public void Verify_LOF_Displayed_To_Content_Added_Later() {
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_GeneralChemistry);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_MacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_IntroductoryBiology);
	}

	// "A) Project view page> Learning Objectives tab:
	// 4) Verify that Added LOF in the Project view does not delete from the content
	// view when the same is deleted from the Project view."
	// BS-3182
	@Test(priority = 7)
	public void Verify_LOF_Removed_From_Project_Is_Not_Removed_From_Content() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromContent(LOF_GeneralChemistry);
		test.projectView.VerifyFrameworkRemovedMessageDisplayed();
		test.projectView.ClickOpenAssetOnProjectView(AssertTitle, TypesOfContentCoverDesign);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_GeneralChemistry);
	}

	// "A) Project view page> Learning Objectives tab:
	// 5) Verify that relevant toaster messages are displayed on adding/ deleting
	// the LOF."
	// BS-3182
	@Test(priority = 8)
	public void Verify_Relevant_Toaster_Messages_On_Adding_Deleting_The_LOF() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOF_MacmillanCalculus);
		test.projectView.VerifyFrameworkRemovedMessageDisplayed();
		test.projectView.AddLearningObjective(LOF_MacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
	}

	// "A) Project view page> Learning Objectives tab:
	// 6) Verify that same LOF can not be added twice to a Project. "
	// BS-3182
	@Test(priority = 9)
	public void Verify_LOF_Can_Not_be_Aded_Twice() {
		test.projectView.VerifyNoDublicateFrameworkIsDisplayed();
		test.projectView.SelectTheFrameWorkFromSuggestionBox(LOF_MacmillanCalculus);
		test.projectView.VerifyLOF_AddButtonDisabled();
		test.projectView.ClickAddButtonOnLOF();
		test.projectView.VerifyNoDublicateFrameworkIsDisplayed();
	}

	// "B) Content View page> Learning Objectives tab:
	// 1) Verify that user is able to add a LOF to the Content. "
	// BS-3182
	@Test(priority = 10)
	public void Verify_User_Able_To_Add_LOF_To_Content() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssertTitle);
		test.Contentpage.opentheSearchContent(AssertTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickLearningObjectives();
		test.ContentView.AddLearningObjective(LOF_OpenStaxUniversityPhysics);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_OpenStaxUniversityPhysics);

	}

	// "B) Content View page> Learning Objectives tab:
	// 2) Verify that LOF added to the Content is limited to that Content only."
	// BS-3182
	@Test(priority = 11)
	public void Verify_LOF_Added_To_Content_Is_Limited_To_Content() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.clickLearningObjectives();
		test.projectView.verifyFrameworkIsNotAddedToProjectView(LOF_OpenStaxUniversityPhysics);
	}

	// "B) Content View page> Learning Objectives tab:
	// 3) Verify that same LOF/LOS can not be added twice to a Content. "
	@Test(priority = 12)
	public void Verify_LOF_LOS_Can_Not_Be_Added_Twice_To_Content() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssertTitle);
		test.Contentpage.opentheSearchContent(AssertTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickLearningObjectives();
		test.ContentView.SelectTheFrameWorkFromSuggestionBox(LOF_OpenStaxUniversityPhysics);
		test.ContentView.VerifyLOF_AddButtonDisabled();

		test.ContentView.AddLearningObjectiveStatement(LOS_OpenStaxUniversityPhysics);
		test.ContentView.VerifyMessageDispalyedOnAddingLearningObjectiveStatement();
		test.ContentView.VerifyLearningObjectiveStatementAdded(LOS_OpenStaxUniversityPhysics);
		test.ContentView.EnterTextInLOS_SearchBox(LOS_OpenStaxUniversityPhysics);
		test.ContentView.VerifyLOF_AddButtonDisabled();

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN1);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();
		test.projectView.AddLearningObjective(LOF_MacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.AddLearningObjective(LOF_OpenStaxUniversityPhysics);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveAllFrameWorkFromProject();
		test.projectView.AddLearningObjective(LOF_MacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.AddLearningObjective(LOF_OpenStaxUniversityPhysics);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssertTitle);
		test.Contentpage.opentheSearchContent(AssertTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(TestProjectISBN);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(TestProjectISBN1);
		test.refreshPage();
		test.ContentView.waitForLoaderToAppear();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyNoDublicateFrameworkIsDisplayed();
	}

	// "B) Content View page> Learning Objectives tab:
	// 4) Verify that user is able to add LOS only if LOF has already been added to
	// the Content. "
	@Test(priority = 13)
	public void Verify_That_User_Is_Able_To_Add_LOS_Only_If_LOF_Is_Added_To_Content() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN + ".epub");
		test.Contentpage.opentheSearchContent(TestProjectISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOF_MacmillanCalculus);
		test.ContentView.AddLearningObjective(LOF_MacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_MacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(LOS_MacmillanCalculus);
		test.ContentView.VerifyLearningObjectiveStatementAdded(LOS_MacmillanCalculus);
		test.ContentView.RemoveLOS_Statement(LOS_MacmillanCalculus);
		test.ContentView.RemoveFameworkFromContent(LOF_MacmillanCalculus);
		test.ContentView.VerifyUserIsNotAbleToAdd_LOS(LOS_MacmillanCalculus);
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();
		test.ContentView.VerifyLOS_IsNotDisplayed();
		test.ContentView.AddLearningObjective(LOF_MacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_MacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(LOS_MacmillanCalculus);
	}

	// "B) Content View page> Learning Objectives tab:
	// 5) Verify that user is able to delete the added LOS. Also, user can only
	// delete the framework from the content provided that LOS is not added to the
	// same. "
	@Test(priority = 14)
	public void Verify_User_Can_Delete_The_Framework_From_The_Content_Provided_LOS_Is_Not_Added() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(TestDataISBN + ".epub");
		test.Contentpage.opentheSearchContent(TestDataISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOF_MacmillanCalculus);
		test.ContentView.AddLearningObjective(LOF_MacmillanCalculus);
		test.ContentView.RemoveFameworkFromContent(LOF_MacmillanCalculus);
		test.ContentView.VerifyMessageDispalyedOnRemovingFamework();
		test.ContentView.AddLearningObjective(LOF_MacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOF_MacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(LOS_MacmillanCalculus);
		test.ContentView.RemoveFameworkFromContentWithoutMessage(LOF_MacmillanCalculus);
		test.ContentView.VerifyFrameworkCanNotBeRemovedMessageIsDisplayed();
	}
	
	//Delete The Uploaded Test Data
	@Test(priority=15)
	public void Verify_Delete_The_Uploaded_Test_Data() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssertTitle);
		test.Contentpage.SelectContentOnContentTab(AssertTitle,TypesOfContentCoverDesign);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}
	
	//"A) Project view> Learning Objectives tab:
	//1) Verified that a list of Learning Objective Frameworks appears as soon as user key in the text in Search box."
	//BS-3176
	@Test(priority=15)
	public void Verify_List_Of_Framework_Appers_When_User_Enter_Text_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN1);
		test.projectView.clickLearningObjectives();
		test.projectView.EnterTextIntoLOF_SearchBox("m");
		test.projectView.VerifySuggesationBoxDisplayedIn_LOF_Section();
	}
	
	//"A) Project view> Learning Objectives tab:
	//2) As of now, a total of 11 LOFs are available in CMS QA."
	//BS-3176
	@Test(priority=16)
	public void Verify_Total_11_LOF_In_ProjectView() {
		test.projectView.Verify_Count_Of_Framework_Displayed_In_SuggestionBox("13");
	}
	
	//"B) Content view> Learning Objectives tab:
	//1) Verified that a list of Learning Objective Frameworks appears as soon as user key in the text in Search box."
	//BS-3176
	@Test(priority=17)
	public void Verify_List_Of_Framework_Appers_When_User_Enter_Text_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestDataISBN + ".epub");
		test.Contentpage.opentheSearchContent(TestDataISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.EnterTextIntoLOF_SearchBox("m");
		test.ContentView.VerifySuggesationBoxDisplayedIn_LOF_Section();
	}
	
	//2) As of now, a total of 10 LOFs are available in CMS QA.
	//BS-3176
	@Test(priority=18)
	public void Verify_Total_11_LOF_In_ContentView() {
		test.ContentView.Verify_Count_Of_Framework_Displayed_In_SuggestionBox("13");
	}
	
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
	
	
}
