package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

public class Reg_AuthorName_Values_Content_Table extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String TestISBN, SearchTypeProject,UploadImageFile,ContentTypeImageSource;
	String FileTitle,TestISBN1;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		TestISBN = getData("ProjectISBNNO");
		TestISBN1 = getData("ProjectISBNNo2");
		SearchTypeProject = getData("SearchType.Project");
		UploadImageFile=getData("TestData.ImageFile");
		ContentTypeImageSource=getData("TypesOfContent.Images>Image Source");
		FileTitle=getStringWithDateAndTimes("AuthorFieldTest");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1) Verified that when user makes a search action for Asset(s) by selecting
	// 'All Types', then the values under Author column header displays as blank for
	// the assets that are displayed in the searched results table. However, for
	// Projects, Author names are displayed as expected.
	// BS-2528
	@Test(priority = 2)
	public void Verify_Author_Names_Filed_For_All_Types_Search() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItemWithOutSearchType("\"" + TestISBN + "\"");
		test.Contentpage.VerifyAuthorFiledBlankForAssets();
		test.Contentpage.VerifyAuthorFiledIsNotBlankForProject();
	}

	// 2) Verified that when user makes a search action for Asset(s) by selecting
	// 'Content', then the values under Author column header displays as blank for
	// the entire assets that are displayed in the searched results table.
	// BS-2528
	@Test(priority = 3)
	public void Verify_Author_Names_Filed_For_Content_Search() {
		test.Contentpage.SearchForAnItem("\"" + TestISBN + "\"");
		test.Contentpage.VerifyAuthorFiledBlankForAssets();
	}

	// 3) Verified that when user makes a search action for Project(s) by selecting
	// 'Project', then the values under Author column header displays Author names
	// for the Projects that are displayed in the searched results table as
	// expected.
	// BS-2528
	@Test(priority = 4)
	public void Verify_Author_Names_Filed_For_Project_Search() {
		test.Contentpage.SelectSearchType(SearchTypeProject);
		test.Contentpage.SearchForAnItemWithOutSearchType("\"" + TestISBN + "\"");
		test.Contentpage.VerifyAuthorFiledIsNotBlankForProject();
	}

	// 4) Verified that when navigates to Content tab> Any Facet: then the values
	// under Author column header displays as blank for the assets that are
	// displayed in the searched results table
	// BS-2528
	@Test(priority = 5)
	public void Verify_Author_Column_Field_When_Navigates_From_Facet() {
		test.HomePage.ClickContentTab();
		test.Contentpage.clickOnFacetLinks();
		test.Contentpage.VerifyAuthorFiledBlankForAssets();
	}

	// 5) Recently Visited tab: Verified that when user navigates to it, then the
	// values under Author column header displays as blank for the assets that are
	// displayed in the table. However, for Projects, Author names are displayed as
	// expected.
	// BS-2528
	@Test(priority = 6)
	public void Verify_Author_Column_Field_On_Recently_Visited_Tab() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyAuthorFiledIsNotBlankForProject();
		test.HomePage.VerifyAuthorFiledBlankForAssets();
	}
	
	//Step:: Upload a new Asset 
	@Test(priority = 7)
	public void Step_Upload_A_Asset() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(UploadImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN1);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN1);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN1);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// 6) For Fresh assets> Verified by associating that to multiple Project(s) and
	// searching for the same via Generic Search/ Recently visited tab.
	// BS-2528
	@Test(priority = 8)
	public void Verify_Author_Column_Field_For_Fresh_Asset() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem("\"" + FileTitle + "\"");
		test.Contentpage.VerifyAuthorFiledBlankForAssets();
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(FileTitle);
		test.HomePage.VerifyAuthorFiledBlankForAssets();
	}
	
	//Step:: Delete the Uploaded the Test Image
	@Test(priority = 9)
	public void Delete_The_Uploaded_Image() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem("\"" + FileTitle + "\"");
		test.Contentpage.SelectContentOnContentTab(FileTitle,ContentTypeImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
