package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.CustomFunctions.GetNewProjectISBN;
import static com.qait.automation.utils.FTPUtil.closesFTPConnection;
import static com.qait.automation.utils.FTPUtil.createsFTPConnectionWithOutPortNumber;
import static com.qait.automation.utils.FTPUtil.fetchFileNameFromFTP;
import static com.qait.automation.utils.FTPUtil.uploadSingleFile;
import static com.qait.automation.utils.XmlParser.SaveChangesToXML;
import static com.qait.automation.utils.XmlParser.UpdateXMLAttribute;
import static com.qait.automation.utils.XmlParser.setXmlFile;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Reg_Favorite_Deleteing_Project extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, UserEmail;
	String FTPUrl, FTPHostName, FtpPassword, FolderKlopotek, XMLDestination, SourceXML, UploadXmlLocation,
			FirstXmlFileName, SecondXmlFileName, TestImageTitle;
	String TestISBN1, TestISBN2, TestFileName, TypesOfContentImage, TestImageTitle2;

	private void initVars() {
		baseURL = getData("baseUrl");
		loginPageLink = getData("Link.loginPageLink");
		UserEmail = getData("PasswordResetAccount.email");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		FTPUrl = getData("HotFolderUserDetail.FTPUrl");
		FTPHostName = getData("HotFolderUserDetail.HostName");
		FtpPassword = getData("HotFolderUserDetail.Password");
		FolderKlopotek = getData("FTPFolders.klopotek");
		SourceXML = System.getProperty("user.dir") + getData("HotFolderXMLFiles.ProjectCreationXml");
		XMLDestination = System.getProperty("user.dir") + getData("HotFolderXMLFiles.SaveXmlLocation");
		TestFileName = getData("TestData.ImageFile");
		TypesOfContentImage = getData("TypesOfContent.Images>Image Source");
		TestImageTitle = getStringWithDateAndTimes("AutomationAsset");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);

	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// setup Test Data Project
	@Test(priority = 2)
	public void Step1_Setup_Test_Data_Projects() {
		TestISBN1 = GetNewProjectISBN();
		setXmlFile(SourceXML);
		UpdateXMLAttribute("BS", "ISBN", TestISBN1);
		UpdateXMLAttribute("BS", "Title", getStringWithDateAndTimes("AutomationProject"));
		FirstXmlFileName = getStringWithDateAndTimes("Project XML") + ".xml";
		UploadXmlLocation = XMLDestination + FirstXmlFileName;
		SaveChangesToXML(UploadXmlLocation);
		createsFTPConnectionWithOutPortNumber(FTPUrl);
		fetchFileNameFromFTP(FTPHostName, FtpPassword, FolderKlopotek);
		uploadSingleFile(UploadXmlLocation, "/" + FolderKlopotek + "/" + FirstXmlFileName);

		test.HotFolder.hardWait(3);
		TestISBN2 = GetNewProjectISBN();
		setXmlFile(SourceXML);
		UpdateXMLAttribute("BS", "ISBN", TestISBN2);
		UpdateXMLAttribute("BS", "Title", getStringWithDateAndTimes("AutomationProjects"));
		SecondXmlFileName = getStringWithDateAndTimes("Project XMLs") + ".xml";
		UploadXmlLocation = XMLDestination + SecondXmlFileName;
		SaveChangesToXML(UploadXmlLocation);
		uploadSingleFile(UploadXmlLocation, "/" + FolderKlopotek + "/" + SecondXmlFileName);
		test.HotFolder.waitForFileToPickedUpByScheduler(FolderKlopotek, FirstXmlFileName);
		test.HotFolder.waitForFileToPickedUpByScheduler(FolderKlopotek, SecondXmlFileName);
		closesFTPConnection();

	}

	// 1) User 1 marks Project A as Favorite> Confirm that Project A displays in
	// Favorites tab of User 1 > User 1 deleted the Project A> Confirm that Project
	// A is not displaying in the Favorites tab of User 1
	// BS-3441
	@Test(priority = 3, dependsOnMethods = "Step1_Setup_Test_Data_Projects")
	public void Verify_Project_Deleted_Not_Display_Scenario1() {
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(TestISBN1);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(TestISBN1);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(TestISBN1);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(TestISBN2);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(TestISBN2);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(TestISBN2);
		test.HomePage.OpenProjectOnFavoriteDashBoard(TestISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickDelete();
		test.projectView.EnterDeleteInTextBox();
		test.projectView.ClickConformDelete();
		test.projectView.VerifyProjectDeletedMessageIsDisplayed();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsRemovedFromFavorite(TestISBN1);
		test.HomePage.VerifyProjectIsRemovedFromFavorite(" "); // To test Blank Entry..
	}

	// 2) User 1 marks Project A as Favorite> Confirm that Project A displays in
	// Favorites tab of User 1 > User 2 deleted the Project A> Confirm that Project
	// A is not displaying in the Favorites tab of User 1
	// BS-3441
	@Test(priority = 4, dependsOnMethods = "Step1_Setup_Test_Data_Projects")
	public void Verify_Project_Deleted_Not_Display_Scenario2() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(TestISBN2);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(TestISBN2);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(TestISBN2);

		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(UserEmail);
		test.loginpage.enterUserPassword(PropFileHandler.readPropertyFromDataFile("currentPassword"));
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickDelete();
		test.projectView.EnterDeleteInTextBox();
		test.projectView.ClickConformDelete();

		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyProjectIsRemovedFromFavorite(TestISBN2);
		test.HomePage.VerifyProjectIsRemovedFromFavorite(" "); // To test Blank Entry..
	}

	// setup Test Data Project
	@Test(priority = 5)
	public void Step1_Setup_Test_Data_Projects_For_Recently_Visited() {
		TestISBN1 = GetNewProjectISBN();
		setXmlFile(SourceXML);
		UpdateXMLAttribute("BS", "ISBN", TestISBN1);
		UpdateXMLAttribute("BS", "Title", getStringWithDateAndTimes("AutomationProject"));
		FirstXmlFileName = getStringWithDateAndTimes("Project XML") + ".xml";
		UploadXmlLocation = XMLDestination + FirstXmlFileName;
		SaveChangesToXML(UploadXmlLocation);
		createsFTPConnectionWithOutPortNumber(FTPUrl);
		fetchFileNameFromFTP(FTPHostName, FtpPassword, FolderKlopotek);
		uploadSingleFile(UploadXmlLocation, "/" + FolderKlopotek + "/" + FirstXmlFileName);

		test.HotFolder.hardWait(3);
		TestISBN2 = GetNewProjectISBN();
		setXmlFile(SourceXML);
		UpdateXMLAttribute("BS", "ISBN", TestISBN2);
		UpdateXMLAttribute("BS", "Title", getStringWithDateAndTimes("AutomationProjects"));
		SecondXmlFileName = getStringWithDateAndTimes("Project XMLs") + ".xml";
		UploadXmlLocation = XMLDestination + SecondXmlFileName;
		SaveChangesToXML(UploadXmlLocation);
		uploadSingleFile(UploadXmlLocation, "/" + FolderKlopotek + "/" + SecondXmlFileName);
		test.HotFolder.waitForFileToPickedUpByScheduler(FolderKlopotek, FirstXmlFileName);
		test.HotFolder.waitForFileToPickedUpByScheduler(FolderKlopotek, SecondXmlFileName);
		closesFTPConnection();

	}

	// 3) User 1 navigates to Project A> Confirm that Project A displays in Recently
	// Visited tab of User 1 > User 1 deleted the Project A> Confirm that Project A
	// is not displaying in the Recently Visited tab of User 1
	// BS-3441
	@Test(priority = 6, dependsOnMethods = "Step1_Setup_Test_Data_Projects_For_Recently_Visited")
	public void Verify_Project_Deleted_Not_Display_Recently_Visited_Scenario1() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN1);
		test.projectView.verifyOnProjectView();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(TestISBN1);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickDelete();
		test.projectView.EnterDeleteInTextBox();
		test.projectView.ClickConformDelete();
		test.projectView.VerifyProjectDeletedMessageIsDisplayed();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(TestISBN1);
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(" "); // To test Blank Entry..

	}

	// 4) User 1 navigates to Project A> Confirm that Project A displays in the
	// Recently Visited tab of User 1 > User 2 deleted the Project A> Confirm that
	// Project A is not displaying in the Recently Visited tab of User 1
	// BS-3441
	@Test(priority = 7, dependsOnMethods = "Step1_Setup_Test_Data_Projects_For_Recently_Visited")
	public void Verify_Project_Deleted_Not_Display_Recently_Visited_Scenario2() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN2);
		test.projectView.verifyOnProjectView();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(TestISBN2);

		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(UserEmail);
		test.loginpage.enterUserPassword(PropFileHandler.readPropertyFromDataFile("currentPassword"));
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickDelete();
		test.projectView.EnterDeleteInTextBox();
		test.projectView.ClickConformDelete();
		test.projectView.VerifyProjectDeletedMessageIsDisplayed();

		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(TestISBN2);
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(" ");
	}

	// setup Test Data Project
	@Test(priority = 8)
	public void Step1_Setup_Test_Data_Projects_For_Recently_Favorite2() {
		TestISBN1 = GetNewProjectISBN();
		setXmlFile(SourceXML);
		UpdateXMLAttribute("BS", "ISBN", TestISBN1);
		UpdateXMLAttribute("BS", "Title", getStringWithDateAndTimes("AutomationProject"));
		FirstXmlFileName = getStringWithDateAndTimes("Project XML") + ".xml";
		UploadXmlLocation = XMLDestination + FirstXmlFileName;
		SaveChangesToXML(UploadXmlLocation);
		createsFTPConnectionWithOutPortNumber(FTPUrl);
		fetchFileNameFromFTP(FTPHostName, FtpPassword, FolderKlopotek);
		uploadSingleFile(UploadXmlLocation, "/" + FolderKlopotek + "/" + FirstXmlFileName);

		test.HotFolder.hardWait(3);
		TestISBN2 = GetNewProjectISBN();
		setXmlFile(SourceXML);
		UpdateXMLAttribute("BS", "ISBN", TestISBN2);
		UpdateXMLAttribute("BS", "Title", getStringWithDateAndTimes("AutomationProjects"));
		SecondXmlFileName = getStringWithDateAndTimes("Project XMLs") + ".xml";
		UploadXmlLocation = XMLDestination + SecondXmlFileName;
		SaveChangesToXML(UploadXmlLocation);
		uploadSingleFile(UploadXmlLocation, "/" + FolderKlopotek + "/" + SecondXmlFileName);
		test.HotFolder.waitForFileToPickedUpByScheduler(FolderKlopotek, FirstXmlFileName);
		test.HotFolder.waitForFileToPickedUpByScheduler(FolderKlopotek, SecondXmlFileName);
		closesFTPConnection();

	}

	// 5) User 1 marks Project A as Favorite and Visited the same> Confirm that
	// Project A displays in Favorites tab & Recently Visited tab of User 1 > User 1
	// deleted the Project A> Confirm that Project A is not displaying in the
	// Favorites tab and Recently Visited tab of User 1
	// BS-3441
	@Test(priority = 9, dependsOnMethods = "Step1_Setup_Test_Data_Projects_For_Recently_Favorite2")
	public void Verify_Project_Deleted_Not_Display_Recently_Favorite_Scenario3() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.AddProjectToFavorite();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(TestISBN1);
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(TestISBN1);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickDelete();
		test.projectView.EnterDeleteInTextBox();
		test.projectView.ClickConformDelete();
		test.projectView.VerifyProjectDeletedMessageIsDisplayed();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsRemovedFromFavorite(TestISBN1);
		test.HomePage.VerifyProjectIsRemovedFromFavorite(" ");
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(TestISBN1);
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(" ");
	}

	// 6) User 1 marks Project A as Favorite and Visited the same> Confirm that
	// Project A displays in Favorites tab & Recently Visited tab of User 1 > User 2
	// deleted the Project A> Confirm that Project A is not displaying in the
	// Favorites tab and Recently Visited tab of User 1
	// BS-3441
	@Test(priority = 10, dependsOnMethods = "Step1_Setup_Test_Data_Projects_For_Recently_Favorite2")
	public void Verify_Project_Deleted_Not_Display_Recently_Favorite_Scenario4() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.AddProjectToFavorite();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(TestISBN2);
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(TestISBN2);

		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(UserEmail);
		test.loginpage.enterUserPassword(PropFileHandler.readPropertyFromDataFile("currentPassword"));
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickDelete();
		test.projectView.EnterDeleteInTextBox();
		test.projectView.ClickConformDelete();
		test.projectView.VerifyProjectDeletedMessageIsDisplayed();

		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsRemovedFromFavorite(TestISBN2);
		test.HomePage.VerifyProjectIsRemovedFromFavorite(" ");
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(TestISBN2);
		test.HomePage.VerifyProjectNotDisplayedOnRecentlyVisitedListView(" ");
	}

	// Step:: Upload Sample Assets
	@Test(priority = 11)
	public void UploadTestDataViaUI() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestFileName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentImage);
		test.HomePage.EnterTextIntoTitleField(TestImageTitle);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		TestImageTitle2 = getStringWithDateAndTimes("AutomationAsset");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestFileName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentImage);
		test.HomePage.EnterTextIntoTitleField(TestImageTitle2);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

	}

	// 7) User 1 navigates to a Content A> Confirm that Content A displays in
	// Recently Visited tab of User 1 > User 1 deleted the Content A> Confirm that
	// Content A is not displaying in the Recently Visited tab of User 1.
	// BS-3441
	@Test(priority = 12)
	public void Verify_Content_Deleted_Not_Display_Recently_Scenario1() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestImageTitle);
		test.Contentpage.opentheSearchContent(TestImageTitle);
		test.ContentView.VerifyOnContentViewPage();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(TestImageTitle);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestImageTitle);
		test.Contentpage.opentheSearchContent(TestImageTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.verifyRecentlyVisitedRowIsNotBlank();
	}

	// 6) User 1 navigates to a Content A> Confirm that Content A displays in
	// Recently Visited tab of User 1 > User 2 deleted the Content A> Confirm that
	// Content A is not displaying in the Recently Visited tab of User 1.
	// BS-3441
	@Test(priority = 13)
	public void Verify_Content_Deleted_Not_Display_Recently_Scenario2() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestImageTitle2);
		test.Contentpage.opentheSearchContent(TestImageTitle2);
		test.ContentView.VerifyOnContentViewPage();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(TestImageTitle2);
		
		test.HomePage.LogoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(UserEmail);
		test.loginpage.enterUserPassword(PropFileHandler.readPropertyFromDataFile("currentPassword"));
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestImageTitle2);
		test.Contentpage.opentheSearchContent(TestImageTitle2);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();

		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.verifyRecentlyVisitedRowIsNotBlank();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
