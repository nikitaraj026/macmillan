package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Content_Tab_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, DownloadStartMsg, ISBN, ISBN2, DamContent,
			DownloadStartMsgMulti;
	String OrganisedDownloadMsg, ContentTypeInstructor,ContentTypeEnhancedePub,TypesOfContentFlatEpub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		DownloadStartMsg = getData("DownloadStartMsg");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		DamContent = getData("DamContent");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsg");
		ContentTypeInstructor = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		ContentTypeEnhancedePub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutfromApplication() {
		test.HomePage.clickUserName();
		test.HomePage.clickLogOut();
	}

	// 1.login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 2.Verify that user is able to navigate to content page
	@Test(priority = 2)
	public void Verify_User_Able_To_Navigate_To_Content_Page() {
		test.HomePage.VerifyContentTabIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
	}

	// 3."Verify that following categories of facets are appearing on the left side
	// of the window:
	// 1.Repository
	// 2.Keywords
	// 3. Subjects
	// 4. Title
	// 5. Content State"
	@Test(priority = 3)
	public void Categories_Of_Facets_Are_Appearing() {
		test.Contentpage.VerifyCategoriesOfFacets();
	}

	// 4.Verify that Content heading is appearing on the content page
	@Test(priority = 4)
	public void Verify_Content_Heading_Is_Appearing() {
		test.Contentpage.VerifyOnContentTab();
	}

	// 5.Verify that user navigates to dashboard after clicking on the home link
	// present under Content heading
	@Test(priority = 5)
	public void Verify_User_Navigates_Dashboard_On_Clicking_Home() {
		test.Contentpage.clickhomeLink();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 6.Verify that content page has table with all the content and info in it
	// (list view).
	@Test(priority = 6)
	public void Verify_All_The_Content_Info() {

		test.HomePage.ClickContentTab();
		test.Contentpage.verifyColumnsAreDisplayed();

	}

	// 7.Verify that a user is able to select multiple Contents using checkboxes or
	// by Select All checkbox from the table
	@Test(priority = 7)
	public void Verify_User_Is_Able_To_Select_Multiple_Contents_Using_Checkboxes_Or_By_Select_All_Checkbox() {
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyContentsAreSelected(2);
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();

	}

	// 8."Verify that content page has following links available at the top:
	// 1. Organized Download
	// 2. Download Content
	// 3. Add to Project
	// 4. Delete
	@Test(priority = 8)
	public void Content_Modify_Links_Available_At_The_Top() {
		test.Contentpage.VerifyallTheModifyLinksInContentTab();
	}

	// 9."Verify that 4 links are available at the top of the content page and are
	// in deactivated if no "content" is selected from the table"
	@Test(priority = 9)
	public void Verify_4_Links_Are_Deactivated_If_No_Content_Is_Selected() throws IOException {
		test.refreshPage();
		test.Contentpage.Verify_Links_Are_Deactivated();
	}

	// 10."Verify that following links are activated :
	// 1.Organized Download
	// 2.Download Content
	// 3.Add to Project
	// 4.Delete
	// the content is selected from the table"
	@Test(priority = 10)
	public void Verify_4_Links_Are_Activated_If_Content_Is_Selected() {
		test.Contentpage.SelectSingleContents();
		test.Contentpage.Verify_Links_Are_Activated();
	}

	// 11.Verify that clicking on the Organized Download link opens the Organized
	// Download pop up
	@Test(priority = 11)
	public void Verify_On_Clicking_Organized_Download_Opens_Organized_Download_popUp() {
		test.Contentpage.SearchForAnItem(ISBN + " epub");
		test.Contentpage.SelectContentOnContentTab(ISBN+".epub",ContentTypeEnhancedePub);
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.VerifyOrganizedDownloadPopUp();
	}

	// 12.Verify that Organized Download heading is appearing on the Organized
	// Download Pop up
	@Test(priority = 12)
	public void Organized_Download_Heading_Is_Appearing() {
		test.Contentpage.VerifyOrganizedDownloadPopUp();
	}

	// 13."Verify that the Organized Download pop up specify the folder structure in
	// the three categories :
	// Top level folder
	// 1st subfolder
	// 2nd sub-folder"
	@Test(priority = 13)
	public void Verify_Three_Categories_Folder_Structure() {
		test.Contentpage.OrganiseTheDownloadInThreeFolderStructure("ISBN", "Repository", "Content Type");
	}

	// 14."Verify that the Organized Download pop has the folder structure with one
	// of the following option:
	// 1. ISBN
	// 2. Content Type
	// 3. Repository"
	@Test(priority = 14)
	public void Verify_Option_Should_Not_Repeat_For_Next_Folder_If_Selected_In_Previous() {
		test.Contentpage.VerifyInOrganisedDoenloadSelectionShouldNotRepeat();
	}

	// 15.Verify that the Organized Download pop up has the Finish and cancel button
	@Test(priority = 15)
	public void Verify_Organised_Download_Has_Finish_And_Cancel_Button() {
		test.Contentpage.verifyFinishAndCancelButtonAreDisplayed();
	}

	// 16.Verify that toaster message is displayed when user clicks on the Finish
	// button in the Organized Download pop up
	@Test(priority = 16)
	public void Verify_Toster_Message_Is_Displayed_In_The_Organized_Download() {
		test.Contentpage.selectAllInOrganizedDownload();
		test.Contentpage.clickFinishButtonOnOrganizedDownload();
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "1");
	}

	// 17.Verify that clicking on the Cancel button on the Organized Download pop up
	// closes the pop up
	@Test(priority = 17)
	public void Verify_On_Clicking_Cancel_Button_The_Organized_Download_PopUp_Closes() {
		test.refreshPage();
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.clickCancelButtonOnOrganizedDownload();
		test.Contentpage.VerifyOrganizedDownloadPopUpClosed();
	}

	// 18.Verify that when user selects multiple contents and clicks on Download
	// Content, then a toaster message is displayed on the same page.
	@Test(priority = 18)
	public void Verify_User_Selects_Multiple_Contents_And_Download_Content() throws IOException {
		test.refreshPage();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");
	}

	// 19.Verify that clicking on the Download content selected content is
	// downloaded
	@Test(priority = 19)
	public void Verify_Selected_Content_Is_Downloaded() throws Exception {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_EPUB.epub", TypesOfContentFlatEpub);
		test.Contentpage.clickDownloadContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN + "_EPUB.epub");
		
	}

	// 20.Verify that clicking on the Add to Project opens the Add Content to
	// Project pop up
	@Test(priority = 20)
	public void Verify_Clicking_On_Add_To_Project_Opens_The_Add_Content() {
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
	}

	// 21.Verify that Add content to Project pop up has Search field and clear all
	// link "Clear all link replaced with 'x' icon" 
	@Test(priority = 21)
	public void Verify_Add_Content_To_Project_Search_Field_And_Clear_All_Link() {
		test.Contentpage.SearchForProjectOnAddRemoveContent(ISBN);
		test.Contentpage.verifySearchFieldAnd_xIconOnAddtoProjectpopUp();
	}

	// 22."Verify that Available and Selected pane is present with the table having
	// following information:
	// 1. Author
	// 2. Title
	// 3. Short Title
	// 4. ISBN"
	@Test(priority = 22)
	public void Verify_Available_And_Selected_Pane_Is_Present_In_Add_To_Project() {
		test.Contentpage.VerifyAvailableAndSelectedPane();

	}

	// 23.Verify that Select and Unselect button is present between the Available
	// and Selected pane
	@Test(priority = 23)
	public void Verify_Select_And_Unselect_Button_In_Add_To_Project() {
		test.Contentpage.VerifySelectAndUnselectButton();
	}

	// 24.Verify that Select and unselect button is deactivated if no content is
	// present
	@Test(priority = 24)
	public void Verify_Select_And_Unselect_Button_Deactivated_On_No_Content() {
		test.Contentpage.VerifySelectAndUnselectButtonIsDeactivated();
	}

	// 25.Verify that Select button is activated if content is present in the
	// Available pane
	@Test(priority = 25)
	public void Verify_Select_Button_Is_Activated_If_Project_Is_Selected() {
		test.Contentpage.Verify_Project_Is_Selected_And_Select_Button_Activated(ISBN);
	}

	// 26.Verify that clicking on the select button moves the content present in the
	// Available pune to Selected pane
	@Test(priority = 26)
	public void Verify_Select_Button_Moves_The_Content_Present_In_The_Available_Pune_To_Selected_Pane() {
		test.Contentpage.ClickSelectButtonAndVerifyContentMoved(ISBN);
	}

	// 27.Verify that unselect button is activated when content is present in the
	// Selected pane
	@Test(priority = 27)
	public void Verify_Unselect_Button_Is_Activated_When_Content_Is_Present() {
		test.Contentpage.SelectTheProjectOnSelectedContent(ISBN);
		test.Contentpage.Verify_Unselect_Button_Is_Activated();
	}

	// 28.Verify that user is able to push back Selected content to available pane
	// from the selected pane by clicking on the Unselect button
	@Test(priority = 28)
	public void Verify_User_Is_Able_To_Push_Back_Selected_Content_To_Available_Pane() {
		test.Contentpage.UnselectTheTheProjectOnSelectedContent();
		test.Contentpage.VerifySelectedProjectMovedToavailablepane(ISBN);
	}

	// 29."Verify that Add Content to Project has the Save and Cancel button"
	@Test(priority = 29)
	public void Verify_Save_And_Cancel_Button_On_Add_To_Project() {
		test.Contentpage.VerifySaveAndCancelButtonOnAddToProject();
	}

	// 30.Verify that Save button is deactivated if there is no content in the
	// selected pane
	@Test(priority = 30)
	public void Verify_Save_Button_Is_Deactivated_If_No_Project_In_Selected_Pane() {
		test.Contentpage.VerifySaveButtonIsDisabled();
	}

	// 31.Verify that Save button is activated if there is content in the selected
	// pane
	@Test(priority = 31)
	public void Verify_Save_Button_Is_Activated_If_There_Is_project_In_Selected_Pane() {
		test.Contentpage.ClickSelectButtonAndVerifyContentMoved(ISBN);
		test.Contentpage.VerifySaveButtonIsActive();

	}

	// 32.Verify that user is able to add content to project on clicking on the save
	// button
	@Test(priority = 32)
	public void Verify_User_Is_Able_To_Add_Content_To_Project_From_AddToProjectPopUp() {
		test.Contentpage.ClickSaveButtonOnAddToProjectAndVerifySuccessMsgDisplayed(ISBN);
	}

	// 33.Verify that clicking on the Cancel button on the Add content to project
	// pop up closes the pop up
	@Test(priority = 33)
	public void Verify_Cancel_Button_On_Add_To_Project_Closes_The_PopUp() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.clickCancelButtonOnAddToProject();
		test.Contentpage.VerifyAddToProjectPopUpNotDisplayed();
	}

	// 34.Verify that clicking on the Delete link delete the selected content
	@Test(priority = 34)
	public void Verify_Delete_Link_Delete_The_Selected_Content() {
		test.HomePage.ClickUploadContent();
		test.Contentpage.UploadContentFromContentPageToDelete(ISBN2);
		test.HomePage.ClickDashBord();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem("Delete Test");
		test.Contentpage.SelectContentOnContentTab("Delete Test", ContentTypeEnhancedePub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}

	// 35.Verify that content page has Result number drop down
	@Test(priority = 35)
	public void Verify_Content_Page_Has_Result_Number_Drop_Down() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyResultNumberDropDown();
	}

	// 36.Verify that user is able to select number how much result want to display
	// on the page from the Result Number Drop down
	@Test(priority = 36)
	public void Verify_User_Is_Able_To_Select_Number_From_Result_Drop_Down() {
		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.VerifyCorrectNumberOfContentAreDisPlayed("10");
	}

	// 37.Verify that content page has Sort by drop down
	@Test(priority = 37)
	public void Verify_Content_Page_Has_Sort_by_DropDown() {
		test.Contentpage.VerifySortByDropDownIsDisplayed();
	}

	// 38."Verify that Sort by drop down has following drop down list:
	// 1. Content type
	// 2. Repository
	// 3. Title
	// 4. Modified"
	@Test(priority = 38)
	public void Verify_All_The_SortBy_Options() {
		test.Contentpage.verifyAlltheOptionsInSortBy();
	}

	// 39.Verify that Content is sorted accordingly as selected in the sort by drop
	// down
	@Test(priority = 39)
	public void Content_Is_Sorted_Accordingly_By_SortBy() {
		test.Contentpage.verifyAlltheOptionsInSortBy();
	}

	// 40.Verify that Content page has Grid view and list view button above the
	// table
	@Test(priority = 40)
	public void Verify_Content_Page_Has_Grid_view_And_List_View_Button() {
		test.Contentpage.VerifyContentPageAsGridViewAndListView();
	}

	// 41.Verify that clicking on the Gridview button content should be displayed in
	// the grid form
	@Test(priority = 41)
	public void Verify_Clicking_On_Gridview_Content_Displayed_In_Grid_Form() {
		test.HomePage.ClickOpenRepository("CMS");
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyPreviewOfRepo("CMS");
		;
	}

	// 42.Verify that clicking on the List view button content should be displayed
	// in the grid form
	@Test(priority = 42)
	public void Verify_Clicking_List_View_Content_Displayed_In_List_View() {
		test.HomePage.ClickContentTab();
		test.Contentpage.clickListView();
		test.Contentpage.VerifyCorrectNumberOfContentAreDisPlayed("20");
	}

	// 43.Verify that a pagination bar is present at the bottom of Content page tab
	// which enables an end user to navigate back and forth
	@Test(priority = 43)
	public void Verify_pagination_Bar_which_Enables_Back_And_Forth_Navigation() {
		test.Contentpage.VerifyPaginationBarIsVisible();
		test.Contentpage.VerifyBackAndForthNavigationpaginationBar();
	}

	// 44.Verify that clicking on the delete button opens the Delete Content pop
	@Test(priority = 44)
	public void Verify_Clicking_Delete_Button_Opens_The_Delete_Content_PopUp() {

		test.HomePage.ClickUploadContent();
		test.Contentpage.UploadContentFromContentPageToDelete(ISBN2);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem("Delete Test");
		test.Contentpage.SelectContentOnContentTab("Delete Test", ContentTypeEnhancedePub);
		test.Contentpage.clickDeleteContentOnContentTab();

	}

	// 45.Verify that Confirm delete button is disabled till Delete is not entered
	// in the field above Confirm delete button
	@Test(priority = 45)
	public void Verify_Confirm_Delete_Button_Is_Disabled_Till_Delete_Not_Entered() {
		test.Contentpage.VerifyConformDeleteButtonDisabled();
	}

	// 46.Verify that confirm delete button is activated as Delete keyword is
	// entered in the field
	@Test(priority = 46)
	public void Verify_Confirm_Delete_Button_Is_Activated_As_Delete_Keyword_Entered() {
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.VerifyConformDeleteButtonActivated();
	}

	// 47.Verify that clicking on the confirm delete button Deletes the content
	// message displays "Content successfully deleted"
	@Test(priority = 47)
	public void Verify_Clicking_On_The_Confirm_Delete_Button_Deletes_Content() {
		test.Contentpage.ClickConformDelete();
	}

	// 48.Verify that in Gridview- User can navigate by clicking on the thumbnail or
	// the project name
	@Test(priority = 48)
	public void Verify_That_Gridview_User_Can_Navigate_By_Clicking_On_Thumbnail() {
		test.HomePage.ClickContentTab();
		test.Contentpage.ClickGridViewCheck();
		test.Contentpage.VerifyThumbnailViewIsWorking();
	}

	// 49.Verify that user is able to view assets of other repositories i.e. Elvis,
	// BrightCove, DAM, and CMS under CMS
	@Test(priority = 49)
	public void Verify_User_Is_Able_To_View_Assets_Of_Other_Repositories() {
		test.HomePage.ClickContentTab();
		test.Contentpage.clickListView();
		test.HomePage.ViewAssetsOfRepository("DAM");
		test.HomePage.ClickContentTab();
		test.HomePage.ViewAssetsOfRepository("CMS");
	}

	// 50.Verify that a user able to add these non cms assets into different
	// projects across CMS application
	@Test(priority = 50)
	public void Verify_User_Is_Able_To_Add_Non_Cms_Assets_To_Different_Projects() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.SelectContentOnContentTab(DamContent, ContentTypeInstructor);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.ClickOpenAssetOnProjectView(DamContent, ContentTypeInstructor);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN2);
	}

	// 51.Verify that a user is successfully able to publish non cms assets using
	// CMS
	@Test(priority = 51)
	public void Verify_User_Is_Successfully_Able_To_Publish_Non_Cms_Assets() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDamContentAndPublish(DamContent);
	}

	// 52.Verify that all the 4-links available at top works fine if user clicks
	// them after selecting all the contents via Select All and result no. set from
	// high to low
	@Test(priority = 52)
	public void Verify_4_Links_Available_Works_If_User_Clicks_Them_After_Selecting_All_Contents() throws IOException {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SelectNumberFromResultDropDown("10");
		test.Contentpage.clickSelectAllOnContentTab();
		test.Contentpage.Verify_Links_Are_Activated();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "10");

	}

	// 53.Verify that if user has selected a single asset of CMS repository and has
	// clicked the Download Content button, then Downloading starts right away
	@Test(priority = 53)
	public void Verify_Single_Asset_Download_Starts_Right_Away() throws IOException {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("CMS");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
