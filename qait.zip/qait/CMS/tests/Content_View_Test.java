package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Content_View_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DamContent;
	String NonAdminEmail, NonAdminPassword, ISBN, ISBN1, PublihDestinationCoreSource, PublihDestinationPalgrave,
			PublihDestinationVitalSource;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, LOMacmillanCalculus,
			MacStatement, FrostHistoryUpdate, UploadISBN,TypesOfContentFlatEpub,ContentTypeCFI;
	String FrostExportFull,ExportOptionEnhancedPub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		UploadISBN = getData("ProjectISBNNo3");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnter");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DamContent = getData("DamContent");
		LOMacmillanCalculus = getData("Framework.macmillan calculus");
		MacStatement = getData("LOS.macmillan calculus");
		FrostHistoryUpdate = getData("CVHistoryFrost");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		ContentTypeCFI = getData("TypesOfContent.Project Support Materials>CFI");
		FrostExportFull=getData("FrostExportType.Full");
		ExportOptionEnhancedPub=getData("FrostExportOptions.Enhanced ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}


	@Test(priority = 1)
	public void Verify_Following_Data_For_A_Content_Under_System_Metadata_Are_Displayed() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.VerifySystemMetadataHeadingAreDisplayed();
	}

	// 2.Verify that four subtabs are displaying as Content Details,
	// Relationships ETC
	@Test(priority = 2)
	public void Verify_All_The_SubTab_Are_Displayed_In_ContentView() {

		test.ContentView.VerifySubTabAreDispalyed();
	}

	// 3.Verify that user can add/ remove his/her email id as Content contact
	@Test(priority = 3)
	public void User_Can_Add_Remove_Email_From_Contant_Contact() {

		test.ContentView.AddAndRemoveEmailOnAContent(AdminEmail);
	}

	// 4.Verify that a user is presented with Version Details subtab which
	// empowers Uploading a new version of that asset,Approving / Unapproving
	// current version,Download any version of an asset (only one at a time)
	@Test(priority = 4)
	public void Verify_version_Detail_Tab_Fuctionality() {
		test.ContentView.ClickOnVersionDetail();
		test.ContentView.CheckVersionDetailFunctionality();

	}

	// 5. Verify_Link_At_The_Top Are Available Publish (Enables for epub when
	// Structural validation is completed, for rest content it remains
	// enabled,Download Content,Edit,Delete
	@Test(priority = 5)
	public void Link_At_The_Top_Are_Available_Publish_Edit_ETC() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyTopLinksAreAvailabe();
	}

	// 6. Verify that User can any time click on the status dropdown and click
	// on Revalidate to restart the validation process.
	@Test(priority = 100)
	public void zVerify_User_Is_Able_To_Revalidate_Any_Content() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.ClickRevalidate();

	}

	// 7.Verify that non-admin user can only see the workflow status as label
	@Test(priority = 7)
	// ******NO Non ADMIN USER On PROD ENV*******
	public void Verify_NonAdmin_User_Only_See_WorkFlow_label() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(NonAdminEmail);
		test.loginpage.enterUserPassword(NonAdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN1 + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN1 + "_EPUB.epub");
		test.ContentView.VerifyOnlyWorkFlowLabelIsDisplayed();
	}

	// 8.Verify that a user is successfully able to download an asset using this
	// button
	@Test(priority = 8)
	public void ZVerify_User_Is_Able_To_Download_Using_Download_Content() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickDownloadContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN + "_EPUB.epub");
	}

	// 9. Verify that user is able to view Rights details (if any), Usage
	// details and ePub files

	@Test(priority = 9)
	public void Verify_User_Is_Able_To_See_Right_Details() {
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewRightsDetails();
		test.ContentView.VerifyCorrectRightDetailMsgIsDisplayed();
	}

	// 10. Verify this enables only when the Structural validation has been
	// completed for ePub and remain enabled for other assets
	@Test(priority = 10)
	public void Verify_Push_To_Authoring_Tool_Enabled_For_Structural_Validation() {
		test.ContentView.VerifyPushToAuthoringToolIsEnabledOnlyForStructuralValidation();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN + "_FC.jpg");
		test.ContentView.VerifyPushToAuthoringToolIsEnabled();

	}

	// 11. Verify that user is able to Push the ePub to Frost
	@Test(priority = 11)
	public void Verify_User_Is_Able_To_Push_Epub_To_Frost() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.VerifyPushToAuthoringToolIsEnabledOnlyForStructuralValidation();
		test.ContentView.ClickPushToAuthoringTool();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.UploadContentToFrost(ISBN);
		test.ContentView.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostHistoryUpdate + "" + ISBN);
	}

	// 12.Verify that user is able to Push the FC files to Frost
	@Test(priority = 12)
	public void Verify_User_Is_Able_To_Push_Fc_To_Frost() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN + "_FC.jpg");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.UploadContentToFrost(ISBN);
		test.ContentView.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostHistoryUpdate + "" + ISBN);
	}

	// 13.Verify that an end user is successfully able to search projects and
	// thereby associate them with the respective content
	@Test(priority = 13)
	public void Verify_That_An_End_User_Is_Successfully_Able_To_Associate_Content_To_Project() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN1);
		test.ContentView.ConfirmContentIsAssociateToProject(ISBN1);
		test.ContentView.VerifyAssociatedProjectDetail();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_EPUB.epub", TypesOfContentFlatEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.RemoveContentFromProject(ISBN1);
	}

	// 14.Verify that content history is displayed
	@Test(priority = 14)
	public void Verify_History_Of_Content_Is_Displayed() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyHistoryIsDisplayed();
	}

	// 15.Verify that a user is allowed to add a comment and all the comments
	// are displayed at the bottom of Content view page
	@Test(priority = 15)
	public void Verify_User_Is_Able_To_Add_Comment_And_View_It() throws NumberFormatException, IOException {

		test.ContentView.AddCommentAndVerifyIt();
	}

	// 16.Verify that Publish link appears at the top for ePub (after Structural
	// validation has been completed) and for rest assets, it is always
	// available
	@Test(priority = 16)
	public void Verify_Publish_Link_Appears_At_The_Top_For_EPub_after_Structural_Validation_Enabled_For_Rest_Assets() {
		test.ContentView.VerifyPublishLinkIsEnabledOnlyForStructuralValidation();
		test.Contentpage.SearchForAnItem(ISBN + "_FC.jpg");
		test.Contentpage.opentheSearchContent(ISBN + "_FC.jpg");
		test.ContentView.VerifyPublishLinkIsEnabled();
	}

	// 17.Verify that three options are displaying under step 1 when the
	// Destination is selected as CoreSource

	@Test(priority = 17)
	public void Verify_Three_Option_Are_Displayed_When_Destination_selected_as_CoreSourceORVitalSource() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyPublishLinkIsEnabledOnlyForStructuralValidation();
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifyThreeOptionsNotDisplayedInPublish();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.VerifyThreeOptionsDisplayedInPublish();

	}

	// 18.Verify that tool tips are proper for the radio buttons
	@Test(priority = 18)
	public void Verify_Tool_Tips_Are_Proper_For_The_Radio_Buttons() {
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.clickFirstToolTipAndVerifyOutputOnPlatform(PublihDestinationVitalSource);
		test.ContentView.clickSecondToolTipAndVerifyOutput();
		test.ContentView.clickThirdToolTipAndVerifyOutputOnPlatfrom(PublihDestinationVitalSource);

	}

	// 19.Verify that user is able to Publish the content only if it is Approved
	// (CFI files can be published irrespective of the status)
	@Test(priority = 19)
	public void Verify_CFI_File_Can_Be_Publish_UnapprovedORApproved() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyPublishLinkIsEnabledOnlyForStructuralValidation();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyEpubCanBePublishIfApproved();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyEpubCanNotBePublishIfUnapproved();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_CFI.csv",ContentTypeCFI);
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyCFIFileCanBePublishIfApproved();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyCFIFileCanBePublishIfUnapproved();
	}

	// 20. Verify that Publish details can be tracked under Publish details tab
	// on Content view page
	@Test(priority = 20)
	public void Verify_User_Is_Able_To_View_Publish_Details() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyPublishDetailsAreDisplayed();
		test.ContentView.VerifyHeaderOfPublishTab();
	}

	// 21.Verify that following 3 destinations are available: 1) CoreSource 2)
	// Palgrave3) VitalSource
	@Test(priority = 21)
	public void Verify_3_Publish_Destination_Are_Available() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.ClickX_OnWindow();
	}

	// 22.Verify that a user is successfully able to edit, Delete an asset using
	// edit button
	@Test(priority = 22)
	public void Verify_User_Is_Able_To_Edit_And_Delete_Asset() throws IOException {
		test.HomePage.ClickContentTab();
		test.HomePage.ClickUploadContent();
		test.Contentpage.UploadContentFromContentPage(UploadISBN);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditAssetDetail();
		test.ContentView.VerifyDetailUpdated();
		test.ContentView.ClickEditLink();
		test.ContentView.DeleteContentFromCMS();

	}

	// 23.Verify that when file is freshly ingested, its state is File Ingested
	// > Structural Validation in Progress > Structural validation Complete
	@Test(priority = 23)
	public void Verify_State_Of_Freshly_Ingested_Is_File_Ingested() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.HomePage.ClickUploadContent();
		test.Contentpage.UploadContentFromContentPage(UploadISBN);
		test.ContentView.checkWorkFlowStatusIsFileIngested();
		test.ContentView.DeleteContentFromCMS();
	}

	// **********FROST********
	// 24.Verify that project of that ISBN will
	// get created at Frost which is entered by the user in step 3.
	@Test(priority = 24)
	public void Project_of_ISBN__Get_Created_And_associated_In_Frost_Entered_In_Step_3() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.ClickOpenAssetOnProjectView(FrostMainProject+"_EPUB.epub", TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.CheckWorkFlowStatus();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.UploadContentToFrost(FrostIsbnToEnter);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, FrostCreatedProjectName);
		test.projectView.OpenProjectOnFrost(FrostCreatedProjectName);
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.LogoutFromFrost();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		/*test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostIsbnToEnter);
		test.projectView.VerifyCFIAndEnhancedEpubArePushed(FrostIsbnToEnter);*/
	}

	// 25.Verify that Two additional files (Enhanced ePub and CFI file) are
	// received in from Frost and get associated with Project ISBN used while
	// Pushing the ePub/FC

	@Test(priority = 25, dependsOnMethods = "Project_of_ISBN__Get_Created_And_associated_In_Frost_Entered_In_Step_3")
	public void Verify_Two_Additional_Files_Recived_From_Frost() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FrostIsbnToEnter+".epub");
		test.Contentpage.opentheSearchContent(FrostIsbnToEnter+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(FrostIsbnToEnter);
		test.ContentView.DeleteContentFromCMS();
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FrostIsbnToEnter+"_CFI.csv");
		test.Contentpage.opentheSearchContent(FrostIsbnToEnter+"_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(FrostIsbnToEnter);
		test.ContentView.DeleteContentFromCMS();
		
		
		/*test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostIsbnToEnter);
		test.projectView.ClickOpenCFIFileOnProjectView(FrostIsbnToEnter);
		test.ContentView.DeleteContentFromCMS();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostIsbnToEnter);
		test.projectView.ClickOpenEnhancedEpubOnProjectView(FrostIsbnToEnter);
		test.ContentView.DeleteContentFromCMS();*/
	}

	// 26.Delete The Project From The Frost
	@Test(priority = 26, dependsOnMethods = "Verify_Two_Additional_Files_Recived_From_Frost")
	public void Delete_Project_from_Frost() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, FrostCreatedProjectName);
		test.projectView.DeleteProjectFromFrost(FrostCreatedProjectName);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}
	/// ********FROST********

	// 27."Verify that following is available in the Push to Authoring tool
	// window:
	// Step 1: Select Authoring Platform
	// Step 2: Selected Assets
	// - Retain CSS and Javascript & Clear CSS and Javascript) {These options
	// will be disabled for the assets other than EPubs}
	// Step 3: Select Project ISBN"
	@Test(priority = 27)
	public void Verify_Authoring_Tool_Has_Three_Section() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifySubCategoriesInPushToAuthoringTool();
		test.ContentView.VerifyViewButtonOnPushToAuthoringTool();
		test.ContentView.SelectCSSOption("clearCss");
		test.ContentView.SelectCSSOption("retainCss");
		test.ContentView.ClickX_OnWindow();
	}

	// 28.Verify that user is able to add a LOF to the Content
	@Test(priority = 28)
	public void Verify_User_Is_Able_To_Add_LOF_To_The_Content() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveAllFrameWorkFromContent();
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
	}

	// 29.Verify that LOF added to the Content is limited to that Content only
	@Test(priority = 29)
	public void Verify_LOF_Added_To_Content_Is_Limited_To_That_Content_Only() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);

		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);

		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.verifyFrameworkIsNotAddedToProjectView(LOMacmillanCalculus);
	}

	// 30.Verify that same LOF can not be added twice to a Content
	@Test(priority = 30)
	public void Verify_Same_LOF_Can_Not_Be_Added_Twice_To_Content() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);

		test.ContentView.SelectFramework(LOMacmillanCalculus);
		test.ContentView.AddButtonOnLearningObjectiveIsDisabled();
	}

	// 31.Verify that user is able to add LOS only if LOF has already been added
	// to the Content
	@Test(priority = 31)
	public void Verify_That_User_Is_Able_To_Add_LOS_Only_If_LOF_Is_Added_To_Content() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(MacStatement);
		test.ContentView.VerifyLearningObjectiveStatementAdded(MacStatement);
		test.ContentView.RemoveLOS_Statement(MacStatement);
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.VerifyUserIsNotAbleToAdd_LOS(MacStatement);
	}

	// 32.Verify that user is able to delete the added LOS. Also, user can only
	// delete the framework from the content provided that LOS is not added to
	// the same.
	@Test(priority = 32)
	public void Verify_User_Can_Delete_The_Framework_From_The_Content_Provided_LOS_Is_Not_Added() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjectiveStatement(MacStatement);
		test.ContentView.RemoveFameworkFromContentWithoutMessage(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkCanNotBeRemovedMessageIsDisplayed();
	}

	// 33.Verify that relevant toaster messages are displayed on adding/
	// deleting the LOF and LOS
	@Test(priority = 33)
	public void Verify_Relevant_Toaster_Messages_On_Adding_Deleting_The_LOF_And_LOS() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveAllLOS_ForContent();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.AddLearningObjective(LOMacmillanCalculus);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.AddLearningObjectiveStatement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnAddingLearningObjectiveStatement();
		test.ContentView.RemoveLOS_Statement(MacStatement);
		test.ContentView.VerifyMessageDispalyedOnRemovingLearningObjectiveStatement();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.VerifyMessageDispalyedOnRemovingFamework();
	}

	// 34.Verify that ISBN of the Project is displayed under 'Published Project
	// ISBN' column from which the asset has been published
	@Test(priority = 34)
	public void Verify_ISBN_Column_Has_Been_Renamed_To_Published_Project_ISBN() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyISBNColoumRenamed();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}