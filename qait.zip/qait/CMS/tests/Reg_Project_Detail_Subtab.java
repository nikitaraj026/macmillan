package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

import java.lang.reflect.Method;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_Detail_Subtab extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String TestISBN, RamdomEmail;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestISBN = getData("ProjectISBNNO");
		RamdomEmail = getStringWithDateAndTimes("Automation") + "@ABC.com";
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// " Project Details tab in Project View:
	// 1) Verify that newly project contact is retaining after refreshing the page"
	// BS-3536
	@Test(priority = 2)
	public void Verify_Newly_Added_Project_Contact_Retaining_After_Refresh() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickProjectDetails();
		test.projectView.AddEmailAddress(RamdomEmail);
		test.projectView.VerifyEmailIsAdded(RamdomEmail);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickProjectDetails();
		test.projectView.VerifyEmailIsAdded(RamdomEmail);

	}

	// 2) Verify that deleted project contact is not appearing under project
	// contacts section after refreshing the page
	// BS-3536
	@Test(priority = 3)
	public void Verify_Deleted_Project_Contact_Not_Appearing_After_Refreshing() {
		test.projectView.RemoveEmailFormProjectDetail(RamdomEmail);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickProjectDetails();
		test.projectView.VerifyEmailNotDisplayedOnProjectDetail(RamdomEmail);
	}

}
