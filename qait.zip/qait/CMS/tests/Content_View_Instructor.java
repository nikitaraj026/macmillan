package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Content_View_Instructor extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DamContent;
	String NonAdminEmail, NonAdminPassword, ISBN, ISBN1;
	String AdvSearchTypeContentType, TypeOfContentMarketingAuthorImage, PublihDestinationInstructorStore;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		DamContent = getData("DamContent");
		AdvSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into Application
	@Test(priority = 1)
	public void Loggin_Into_Application() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

	}

	// 1.Verify that 'Publish Destinations' link is displayed under 'Published
	// Project ISBN' column and clikcing the same opens the relevant pop-up
	// "Verify that Project publish details can be tracked under this tab in form of
	// a table with following column headers:
	// 1) User
	// 2) Destination
	// 3) Published Date
	// 4) Published Project ISBN
	// 5) Publish Status
	// along with a Refresh button."
	@Test(priority = 2)
	public void Verify_Clicking_Publish_Destinations_opens_The_Relevant_PopUp() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.ClickPublishDestinationOnPublishDetail();
		test.ContentView.VerifyPublishedProjectPopUpDisplayed();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.VerifyHeaderOfPublishTab();
		test.ContentView.VerifyRefreshLink();
	}
	
	

	// 2.Step 2: Verify that asset is selected by default. Also in case of
	// Author Image, Image preview is getting displayed when publish destination
	// is selected as 'Instructor Store' in step 1.
	//////////////////////////////// --------NO Marketing Author IMAGE on PROD
	@Test(priority = 3)
	public void Verify_Asset_Is_Selected_By_Default_Author_Image_Image_Preview_Is_Getting_Displayed() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypeOfContentMarketingAuthorImage);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyAuthorImageInStep2PublishWindow();
		test.ContentView.VerifyAuthorNameAndIdInStep2PublishWindow();
		test.ContentView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
	}

	// 3.Step 3: Verify that user can Approve/ Unapprove the asset
	@Test(priority = 4)
	public void Verify_User_Can_Approve_Unapprove_Asset() {
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
	}

	// 4.Verify that ASSET URL link gets generated for the static files published to
	// Courseware
	@Test(priority = 5)
	public void Verify_ASSET_URL_Link_Gets_Generated_For_Published_To_Courseware() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAssetURLLinkInPublishDetail();
	}
	
	

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}