package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.openqa.selenium.Keys;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_DemoISBN_Push_Back extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String ProjectISBN, FrostEmail, FrostPassword, FrostExportFull, ExportOptionSupersetEPub;
	String FrostLink, DemoISBN, NonStandardMsg, Workflow_Enhanced_ePub_Ingested,NewDemoISBN;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ProjectISBN = getData("FrostProject.MainProjectISBN");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		FrostLink = getData("Link.Frost");
		DemoISBN = getStringWithDateAndTimes("TestISBN");
		NonStandardMsg = getData("NonStandardMsg");
		Workflow_Enhanced_ePub_Ingested = getData("WorkFlowStatus.Enhanced ePub Ingested");
		FrostExportFull = getData("FrostExportType.Full");
		ExportOptionSupersetEPub = getData("FrostExportOptions.Superset ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that Projects are getting created at Frost end for the DEMO ISBN(s)
	// from which the asset was pushed.
	@Test(priority = 2)
	public void Verify_Projects_Getting_Created_At_Frost_End_For_DEMOISBN() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectClearCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.VerifyNonStandardProjectMessage(DemoISBN, NonStandardMsg);
		test.projectView.ClickYESNoForDemoISBN("Yes");
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
	}

	// 2.Verify that the status of the asset is getting updated to 'Added to Frost'.
	@Test(priority = 3)
	public void Verify_User_Is_Able_To_Push_Back_Content_to_CMS() {
		test.projectView.OpenProjectOnFrost(DemoISBN);
		test.projectView.ExportFilesToCms(ExportOptionSupersetEPub, FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(DemoISBN + ".epub");
		test.Contentpage.opentheSearchContent(DemoISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(DemoISBN);
		test.ContentView.ConfirmContentIsAssociateToProject(ProjectISBN);
		test.ContentView.DeleteContentFromCMS();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(DemoISBN + "_CFI.csv");
		test.Contentpage.opentheSearchContent(DemoISBN + "_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(DemoISBN);
		test.ContentView.ConfirmContentIsAssociateToProject(ProjectISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// Delete Project From Frost
	@Test(priority = 4)
	public void Delete_Project_From_Frost() {
		test.projectView.changeWindow(1);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.DeleteProjectFromFrost(DemoISBN);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// "Project view:
	// 8) Verified that Project status gets updated to 'Enhanced ePub Ingested'."
	@Test(priority = 5)
	public void Verify_Project_Status() {
		test.projectView.changeWindow(0);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyWorkFlowStatusIs(Workflow_Enhanced_ePub_Ingested);
	}

	// 1) Verify that warning message 'abc is a non-standard project....' appears
	// below the text box only if user has searched for some demo ISBN
	// BS-3018
	@Test(priority = 6)
	public void Verify_Warning_Message_Appears_Only_When_User_Search_Demo_ISBN() {
		NewDemoISBN=getStringWithDateAndTimes("TestISBN");
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(NewDemoISBN);
		test.projectView.VerifyNonStandardProjectMessage(NewDemoISBN, NonStandardMsg);
		test.projectView.ClearSearchResultOnPushToAutoringTool();
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
		test.projectView.enterTextIntoStep3SearchFieldOfpushToAuthoringTool(ProjectISBN);
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
	}

	// 2) Verify that warning message gets disappeared if user deletes the demo ISBN
	// from the ISBN Search box:
	// below the text box only if user has searched for some demo ISBN
	// BS-3018
	@Test(priority = 7)
	public void Verify_Warning_Message_Disappear_When_User_Deletes_Demo_ISBN() {
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(NewDemoISBN);
		test.projectView.VerifyNonStandardProjectMessage(NewDemoISBN, NonStandardMsg);
		test.projectView.enterTextIntoStep3SearchFieldOfpushToAuthoringTool(Keys.BACK_SPACE);
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
		test.projectView.clearStep3SearchFieldOfpushToAuthoringTool();
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
	}
	
	//4) Verify that searched ISBN get listed below text box on performing the correct search: 
	@Test(priority = 8)
	public void Verify_Searched_ISBN_Get_Listed_Below() {
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
		test.projectView.VerifyProjectIsDisplayedOnAuthoringTool(DemoISBN);
	}
	
	//5) Verify that warning message gets disappeared when user entered fresh input in the ISBN Search box: 
	@Test(priority = 9)
	public void Verify_Warning_Message_Disappear_When_User_Entered_Fresh_Input() {
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(NewDemoISBN);
		test.projectView.VerifyNonStandardProjectMessage(NewDemoISBN, NonStandardMsg);
		test.projectView.enterTextIntoStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
		test.projectView.enterTextIntoStep3SearchFieldOfpushToAuthoringTool(ProjectISBN);
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
	}
	
	
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
