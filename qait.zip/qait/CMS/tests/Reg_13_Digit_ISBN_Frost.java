package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

public class Reg_13_Digit_ISBN_Frost extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String TestProjectISBN, FlatEpubTitle, TestFlatEpub, TypesOfContentFlatEpub;
	String FrostEmail, FrostPassword, ProjectTitle, TestProjectISBN2, ProjectTitle2;
	String TestProjectISBN3, ProjectTitle3, FrostActionMessage, FrostLink, TestProjectISBN4;
	String FrostExportFull,ExportOptionEnhancedPub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestProjectISBN = getData("ProjectISBNNo2");
		TestProjectISBN2 = getData("ProjectISBNNo1");
		TestProjectISBN3 = getData("ProjectISBNNO");
		TestProjectISBN4 = getData("ProjectISBNNo4");
		FlatEpubTitle = getStringWithDateAndTimes("AutomationFlatEpub");
		TestFlatEpub = getData("TestData.FlatEpub");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		ProjectTitle = getData("ProjectTitle2");
		ProjectTitle2 = getData("ProjectTitle1");
		ProjectTitle3 = getData("ProjectTitle3");
		FrostActionMessage = getData("CVHistoryFrost");
		FrostLink = getData("Link.Frost");
		FrostExportFull=getData("FrostExportType.Full");
		ExportOptionEnhancedPub=getData("FrostExportOptions.Enhanced ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// "Project view:
	// 1) Verified that 'Push to Authoring tool' option gets activated only when the
	// Project status is 'Ready for Enhancements'."
	// BS-3253
	@Test(priority = 2)
	public void Verify_Push_To_Authoring_Tool_Gets_Activated_for_Ready_For_Enhancements() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectFileUsingBrowseButton(TestFlatEpub);
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentFlatEpub);
		test.projectView.EnterTextIntoTitleField(FlatEpubTitle);
		test.projectView.ClickUploadOnUploadContentPopUpAndVerifyMsg();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyPushToAuthoringToolIsEnabledOnlyForReadyForEnhancements();
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.VerifyPushToAuthoringToolIsEnabledOnlyForReadyForEnhancements();
	}

	// "Project view:
	// 2) Verified that user is able to Push an ePub to Normal 13-digit ISBN from
	// CMS to Frost."
	// BS-3253
	@Test(priority = 3)
	public void Verify_User_Able_To_Push_ePub_To_Normal_13_Digit_ISBN() {
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", FlatEpubTitle);
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(FlatEpubTitle);
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(TestProjectISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(TestProjectISBN);
		test.projectView.ClickPushOnPushToAuthoringTool();
	}

	// "Project view:
	// 3) Verified that Project is getting created at Frost end and user is able to
	// push back the epub package."
	// BS-3253
	@Test(priority = 4)
	public void Verify_Project_Is_Getting_Created_At_Frost_End() {
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(TestProjectISBN, ProjectTitle);

	}

	// "Project view:
	// 4) Verified that Enhanced ePub and CFI file is received from Frost end and
	// get associated with the ISBN13 which was used in Step 3 of Push to Authoring
	// tool window."
	// BS-3253
	@Test(priority = 5)
	public void Verify_Enhanced_ePub_And_CFI_Received_From_Frost() {
		test.projectView.OpenProjectOnFrost(ProjectTitle);
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN + ".epub");
		test.Contentpage.opentheSearchContent(TestProjectISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN + "_CFI.csv");
		test.Contentpage.opentheSearchContent(TestProjectISBN + "_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN);
	}

	// Step:: Push Asset To Frost with ISBN other than main ISBN and Verify Project
	// is Created at Frost End
	// BS-3253
	@Test(priority = 6)
	public void Step_Push_Asset_To_Frost_With_ISBN_Other_Than_Main_ISBN() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", FlatEpubTitle);
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(FlatEpubTitle);
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(TestProjectISBN2);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(TestProjectISBN2);
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(TestProjectISBN2, ProjectTitle2);
		test.projectView.OpenProjectOnFrost(ProjectTitle2);
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// "Project view:
	// 5) Verified that if some other ISBN13 is used in Step 3, then Project with
	// that ISBN will get created at Frost end and when the package is pushed back,
	// it gets associated to both the ISBN i.e. the entered one and the main ISBN
	// from which the Push to Authoring tool window was opened."
	// BS-3253
	@Test(priority = 7)
	public void Verify_Push_Back_Asset_Are_Associated_To_Both_ISBNs() {
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN2 + ".epub");
		test.Contentpage.opentheSearchContent(TestProjectISBN2 + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN);
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN2);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(TestProjectISBN);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN2 + "_CFI.csv");
		test.Contentpage.opentheSearchContent(TestProjectISBN2 + "_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN);
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN2);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(TestProjectISBN);
	}

	// Delete the uploaded Epub and Project from Frost
	// BS-3253
	@Test(priority = 8)
	public void Step_Delete_The_Test_Data() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FlatEpubTitle);
		test.Contentpage.SelectContentOnContentTab(FlatEpubTitle, TypesOfContentFlatEpub);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);

		test.projectView.VerifyProjectIsCreatedAtFrost(TestProjectISBN2, ProjectTitle2);
		test.projectView.DeleteProjectFromFrost(ProjectTitle2);

		test.projectView.VerifyProjectIsCreatedAtFrost(TestProjectISBN, ProjectTitle);
		test.projectView.DeleteProjectFromFrost(ProjectTitle);
	}

	// Step: Upload An Test Epub
	@Test(priority = 9)
	public void Step_Upload_An_Flat_Epub() {
		FlatEpubTitle = getStringWithDateAndTimes("AutomationFlatEpub");
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestFlatEpub);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentFlatEpub);
		test.HomePage.EnterTextIntoTitleField(FlatEpubTitle);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// "Content view:
	// 1) Verified that 'Push to Authoring tool' option gets activated only when the
	// Workflow status is 'Structural Validation is Completed'."
	// BS-3253
	@Test(priority = 10)
	public void Verify_Push_To_Authoring_Tool_activate_For_Structural_Validation_Completed() {
		test.ContentView.VerifyPushToAuthoringToolIsEnabledOnlyForStructuralValidation();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN3 + ".epub");
		test.Contentpage.opentheSearchContent(TestProjectISBN3 + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyPushToAuthoringToolIsEnabledOnlyForStructuralValidation();
	}

	// "Content view:
	// 2) Verified that user is able to Push the ePub to Normal existing 13-digit
	// ISBN from CMS to Frost."
	// BS-3253
	@Test(priority = 11)
	public void Verify_User_Able_To_Push_Content() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN3 + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(TestProjectISBN3 + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SearchProjectOnAuthoringTool(TestProjectISBN4);
		test.ContentView.SelectProjectOnAuthoringTool(TestProjectISBN4);
		test.ContentView.ClickPushOnAuthoringTool();
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostActionMessage + TestProjectISBN4);

	}

	// "Content view:
	// 3) Verified that Project is getting created at Frost end and user is able to
	// push back the epub package."
	// BS-3253
	@Test(priority = 12)
	public void Verify_Project_Getting_Created_At_Frost_And_Able_To_Push_Back() {
		test.ContentView.OpenNewTabOntheCurrentWindow();
		test.ContentView.changeWindow(1);
		test.launchApplication(FrostLink);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(TestProjectISBN4, ProjectTitle3);
		test.projectView.OpenProjectOnFrost(ProjectTitle3);
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestProjectISBN4 + ".epub");
		test.Contentpage.opentheSearchContent(TestProjectISBN4 + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN4);
		test.ContentView.DeleteContentFromCMS();

		test.Contentpage.SearchForAnItem(TestProjectISBN4 + "_CFI.csv");
		test.Contentpage.opentheSearchContent(TestProjectISBN4 + "_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(TestProjectISBN4);
		test.ContentView.DeleteContentFromCMS();
	}

	// Delete the uploaded Epub
	// BS-3253
	@Test(priority = 13)
	public void Step_Delete_The_Test_Data2() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FlatEpubTitle);
		test.Contentpage.SelectContentOnContentTab(FlatEpubTitle, FlatEpubTitle);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}
}
