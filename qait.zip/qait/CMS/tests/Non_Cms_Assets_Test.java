package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Non_Cms_Assets_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, DamContent, DownloadStartMsg, DownloadBrightCoveMsg;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		DamContent = getData("DamContent");
		DownloadStartMsg = getData("DownloadStartMsg");
		DownloadBrightCoveMsg = getData("BrightcoveMsg");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutFromApplication() {
		test.HomePage.LogoutFromApplication();
	}

	// 1. Verify that a user successfully able to approve/unapprove a non cms asset
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Approve_Unapprove_Non_Cms_Asset() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.ClickOnVersionDetail();
		test.NonCmsAssets.VerifyUserIsableToApproveOrUnapprove();

	}
	
	

	// 2.Verify that a user is able to Download an non cms asset from Download
	// content button
	@Test(priority = 2)
	public void Verify_User_Is_Able_To_Download_Non_Cms_Asset() throws IOException {
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "1");
		test.HomePage.clickProjectTab();
		test.HomePage.ClickContentTab();
		test.Contentpage.clickDownloadContent();
		test.HomePage.ClickOpenRepository("BrightCove");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadBrightCoveMsg, "");
	}

	// 3.Verify that a user is unable to edit, delete, upload a new version of a non
	// cms asset
	@Test(priority = 3)
	public void Verify_User_Is_Unable_To_Edit_Delete_Upload_NonCmsAssets() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.NonCmsAssets.VerifyFunctionalityIsDisabled();
	}

	// 4.Verify that a user is successfully able to publish non cms assets using CMS
	@Test(priority = 4)
	public void Verify_User_Is_able_Publish_Non_Cms_Assets() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDamContentAndPublish(DamContent);
	}
	
	

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
