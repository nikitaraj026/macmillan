package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Project_View_Instructor extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, NonAdminEmail, NonAdminPassword;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare, ProjectISBNNO,
			DamContent;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword,
			PublihDestinationVitalSource;
	String LOMacmillanCalculus, selectAllPages, PublihDestinationInstructorStore;
	String TypesOfContentEnhancedEpub, TypesOfContentFlatEpub, DemoISBN;
	String AllPage, CMSRepository, TypesOfContentImage, AssertTitle;
	String NotVisibleToStudents, FileISBN;
	String TestImageFile, TypesOfContentInstructorResources, InstructorFileTitle, TypesOfContentStudentResources;
	String StudentFileTitle,FrostExportFull,ExportOptionSupersetEPub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ProjectISBNNO = getData("ProjectISBNNo1");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		DamContent = getData("DamContent");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnter");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		LOMacmillanCalculus = getData("Framework.macmillan calculus");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		AllPage = getData("PageSelection.All Pages");
		DemoISBN = getStringWithDateAndTimes("TestISBN");
		CMSRepository = getData("Repository.CMS");
		TypesOfContentImage = getData("TypesOfContent.Images>Image Source");
		AssertTitle = getStringWithDateAndTimes("AutomationStudentVisibility");
		NotVisibleToStudents = getData("Visibility.Not Visible to Students");
		FileISBN = getData("FileISBN");
		TestImageFile = getData("TestData.ImageFile");
		TypesOfContentInstructorResources = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		InstructorFileTitle = getStringWithDateAndTimes("Automation_IR");
		TypesOfContentStudentResources = getData("TypesOfContent.Supplementary Content>Student Resources");
		StudentFileTitle = getStringWithDateAndTimes("Automation_SR");
		FrostExportFull=getData("FrostExportType.Full");
		ExportOptionSupersetEPub=getData("FrostExportOptions.Superset ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login into Application
	@Test(priority = 1)
	public void loginIntoApplication() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1)Step 1: Verify that Instructor store as the Publish destination is
	// selected by default
	// 2)Step 1: Verify that user is able to add multiple ISBNs in Step 1 when
	// 'Instructor Store' is selected
	@Test(priority = 2)
	public void Verify_Files_And_Published_Project_ISBN_Link_In_Case_of_Multiple_Publish() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ProjectISBNNO);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ProjectISBNNO);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ProjectISBNNO);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
	}

	// 3.Step 3: Verify that user is able to Approve/ Unapprove the selected
	// Assets
	@Test(priority = 3)
	public void Verify_user_Is_Able_To_Approve_Unapprove_Selected_Assets() {
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.VerifyStatusOfContentsInStep3OfPublishWindow();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
	}

	// 4.Step 2: Verify that Associated assets are displayed under the tree
	// structure and user can select the same.
	@Test(priority = 4)
	public void Verify_Associated_Assets_Are_Displayed_Under_Tree_Structure_And_User_Can_Select_The_Same() {
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentEnhancedEpub,
				ISBN + ".epub", true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN + "_EPUB.epub", true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(AllPage);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 5.Verify that 'Files' link appear (for single or multiple file publish) and
	// Published Project ISBNs link appears for each publish. Clicking the same
	// opens the relevant pop-up windows.
	@Test(priority = 5)
	public void Verify_Files_Link_And_Published_Project_ISBNs_Link() {
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + ".epub");
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + "_EPUB.epub");
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(2);
		test.projectView.ClickCloseButton();
		test.projectView.Verify_PublishedProjectISBN_LinkIsDisplayed();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.ClickCloseButton();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentEnhancedEpub,
				ISBN + ".epub", true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN + ".epub");
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(1);
		test.projectView.ClickCloseButton();
		test.projectView.Verify_PublishedProjectISBN_LinkIsDisplayed();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.ClickCloseButton();
	}

	// 6.Verify tool tips are available for all the instances of ellipsis
	@Test(priority = 6)
	public void Verify_Tool_Tips_Available_For_Push_To_Authoring_Tool() {
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyToolTipsOnAuthoringToolGrid();
		test.projectView.ClickCloseButton();
		test.ProjectPage.waitForLoaderToDisappear();
	}

	// 7."Step 1: Verify that following Publish destinations are available in
	// Step 1:
	// 1) Palgrave
	// 2) Courseware
	// 3) Instructor Store
	// 4) CoreSource
	// 5) VitalSource"
	@Test(priority = 7)
	public void Verify_All_The_Publish_Destination() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 8.Verify that user can enter a demoISBN in step 3 and Push the epub with
	// the same at Frost
	@Test(priority = 8)
	public void Verify_User_Can_Enter_Demo_ISBN_In_Step_3_And_Push_Epub() {
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN + "_EPUB.epub");
		test.projectView.EnterDemoISBNInPushToAuhoringTool(DemoISBN);
		test.projectView.ClickYESNoForDemoISBN("Yes");
		test.projectView.ClickPushOnPushToAuthoringTool();
	}

	// 9.Verify that same demoISBN gets created at Frost end
	@Test(priority = 9)
	// ***** Not Authorized to perform Frost related Functionality on PROD ******
	public void Verify_DemoISBN_Gets_Created_At_Frost_End() {
		test.projectView.verifyOnProjectView();
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
	}

	// 10.Verify that additional ePub sent to Frost retains its name without
	// extension
	@Test(priority = 10)
	// ***** Not Authorized to perform Frost related Functionality on PROD ******
	public void Verify_Additional_ePub_Sent_To_Frost_Retains_Its_Name_Without_Extension() {
		test.projectView.changeWindow(0);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ISBN + "_EPUB.epub");
		test.projectView.EnterDemoISBNInPushToAuhoringTool(DemoISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(DemoISBN);
		test.projectView.ClickPushOnPushToAuthoringTool();
		test.projectView.logMessage("Waiting for " + ISBN + "_EPUB.epub to be created at frost end....");
		test.projectView.hardWait(130); /// waiting for File To be Moved to Frost.
		test.projectView.changeWindow(1);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.OpenProjectOnFrost(DemoISBN);
		test.projectView.verifyAdditionalFileInFrost(ISBN + "_EPUB");
		/*
		 * test.projectView.navigateBack(); test.projectView.waitForLoaderToDisappear();
		 * test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		 * test.projectView.waitForLoaderToDisappear();
		 * test.projectView.DeleteProjectFromFrost(DemoISBN);
		 * test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		 */
	}

	// 11.Verify that epub pushed back in case of Demo ISBN from Frost is getting
	// associated to the Demo ISBN and main ISBN from which Push was initiated in
	// CMS
	@Test(priority = 11)
	// ***** Not Authorized to perform Frost related Functionality on PROD ******
	public void Verify_Epub_Pushed_Back_Getting_Associated_To_Demo_And_Main_ISBN() {
		test.projectView.ExportFilesToCms(ExportOptionSupersetEPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(DemoISBN + ".epub");
		test.Contentpage.opentheSearchContent(DemoISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(DemoISBN);
		test.ContentView.ConfirmContentIsAssociateToProject(ISBN);
		test.ContentView.DeleteContentFromCMS();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(DemoISBN + "_CFI.csv");
		test.Contentpage.opentheSearchContent(DemoISBN + "_CFI.csv");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(DemoISBN);
		test.ContentView.ConfirmContentIsAssociateToProject(ISBN);
		test.ContentView.DeleteContentFromCMS();

	}

	// Step:: Delete the DEMO ISBN From Frost
	@Test(priority=12)
	public void Delete_The_Created_ISBN_From_Frost() {
		test.projectView.changeWindow(1);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.ClickFrostHomeLink();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.waitForLoaderToDisappear();
		test.projectView.DeleteProjectFromFrost(DemoISBN);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 12.Verify that entry of the Pushed action gets recorded in the Workflow
	// History of Project containing the ISBN details
	@Test(priority = 13)
	public void Verify_Frost_Pushed_Action_Gets_Recorded_In_Workflow_History() {
		test.projectView.changeWindow(0);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(DemoISBN);
	}

	// Step:: Upload an Test Image
	@Test(priority=14)
	public void Upload_An_Test_Image_For_Student_Visiblity_Testing() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(FileISBN + "_FC.jpg");
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentImage);
		test.HomePage.EnterTextIntoTitleField(AssertTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(ISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(ISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.HomePage.waitForLoaderToDisappear();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
	}

	// 12.Step 2: Verify that when 'Courseware' is selected in Step1, then user can
	// add/modify visibility metadata to any content
	@Test(priority=15)
	public void Verify_User_Can_Modify_Visibility_Of_Content() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyInstructorOnlyMetadataButtonDisabled();
		test.projectView.VerifyStudentOnlyMetadataButtonDisabled();
		test.projectView.VerifyClearAccessLevelMetadataButtonDisabled();
		test.projectView.VerifyNotVisibleToStudentDisabled();
		test.projectView.VerifyVisibleToStudentButtonDisabled();
		test.projectView.VerifyResetToOriginalSystemStatusDisabled();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(CMSRepository,
				TypesOfContentImage, AssertTitle);
		test.projectView.VerifyVisibleToStudentButtonButtonEnabled();
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyMessageOnAddingVisibleToStudent();
		test.projectView.VerifyAssetIsVisibleToStudent(AssertTitle);
		test.projectView.VerifyNotVisibleToStudentButtonButtonEnabled();
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyMessageOnAddingNotVisibleToStudent();
		test.projectView.VerifyAssetIsNotVisibleToStudent(AssertTitle);
	}

	// 13.Verify that correct visibility state is getting captured under the
	// Published details tab
	@Test(priority=16)
	public void Verify_Correct_Visibility_State_Captured_In_Published_Details_Tab() {
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToInstructorResource();
		test.projectView.ClickManualPublish();
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentImage, AssertTitle,
				true);
		test.projectView.Select_Assert_Displayed_In_Step3(FileISBN + "_FC.jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyVisibilityOfAssetOnPublishedFileDetailPopup(AssertTitle, NotVisibleToStudents);
	}

	// 14. Delete the Uplaoed Image For Testing
	@Test(priority=17)
	public void Delete_The_Uploaded_Image() {
		test.projectView.ClickCloseButton();
		test.projectView.ClickOpenAssetOnProjectView(AssertTitle, TypesOfContentImage);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}

	// 15.Upload Test Instructor and student resource
	@Test(priority = 18)
	public void Upload_Test_Instructor_And_Student_Supplementary_Resource() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentInstructorResources);
		test.HomePage.EnterTextIntoTitleField(InstructorFileTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(ISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(ISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(ISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentStudentResources);
		test.HomePage.EnterTextIntoTitleField(StudentFileTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(ISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(ISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(ISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

	}

	// 15.Step 2: Verify that eye icon for Visible and eye icon with cross for Not
	// visible metadata is displayed along with asset title in Step 2. Also, by
	// default IR are Not visible and SR are visible to students
	@Test(priority = 19)
	public void Verify_Default_Visibility_Scenario_For_IR_SR_Resources() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.VerifyFileIsDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentInstructorResources,
				InstructorFileTitle);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert_Manual_Publish(InstructorFileTitle);
		test.projectView.VerifyAssetIsNotVisibleToStudentManualPublish(InstructorFileTitle);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentInstructorResources, InstructorFileTitle);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(InstructorFileTitle);
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);
		test.projectView.ClickCloseButton();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.VerifyFileIsDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentStudentResources,
				StudentFileTitle);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert_ManualPublish(StudentFileTitle);
		test.projectView.VerifyAssetIsVisibleToStudentManualPublish(StudentFileTitle);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentStudentResources, StudentFileTitle);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(StudentFileTitle);
		test.projectView.VerifyAssetIsVisibleToStudent(StudentFileTitle);

	}

	// Delete The Uploaded Content
	@Test(priority = 20)
	public void Delete_The_Uploaded_IR_SR_Asset() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(StudentFileTitle);
		test.Contentpage.SelectContentOnContentTab(StudentFileTitle, TypesOfContentStudentResources);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(InstructorFileTitle);
		test.Contentpage.SelectContentOnContentTab(InstructorFileTitle,TypesOfContentInstructorResources);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}
	
	// 16.Verify that user is able to publish CFI to Courseware using third radio
	// button 'Publish content links only' (Do not Select CFI from Step 2 Select
	// Assets Section)
	@Test(priority=21)
	public void Verify_User_Able_To_Publish_CFI_Using_Third_Radio_Button() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links only");
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCourseWare);
		test.projectView.WaitforpublishToComplete("Complete", "1");
		
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
