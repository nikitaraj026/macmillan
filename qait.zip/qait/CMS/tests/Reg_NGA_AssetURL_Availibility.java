package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.awt.HeadlessException;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_NGA_AssetURL_Availibility extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String FileTitle, PushToAuthoringToolHttpLinks, ContentTypeImageSource, TestImageforNGA;
	String DAMInstructorResource;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		FileTitle = getStringWithDateAndTimes("NGA_Automation_Test");
		PushToAuthoringToolHttpLinks = getData("PushToAuthoringTool.Https link");
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
		TestImageforNGA = "AutoMation NGA_!@#$%ÀÁÂÃÄÅ.jpg";
		DAMInstructorResource = getData("DamContent");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

	}

	// Step:: Upload Test Image
	@Test(priority = 2)
	public void Upload_Test_Image() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadButtonOnUploadPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
	}

	// 1. Verified that once the Asset is pushed to NGA, user can access the
	// generated URL via Publish Details tab though the status is In-Progress.
	// BS-3098
	@Test(priority = 3)
	public void Verify_URL_Generates_When_Status_Is_InProgress() {
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyPushStatusOnPublishDetails("In Progress");
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyURL_IsDisplayed();
		test.ContentView.ClickX_OnWindow();
	}

	// 2.Verified that until the status gets 'Completed', the URL does not deliver
	// the asset. The Pushed asset only loads when the status gets Completed.
	// BS-3098
	@Test(priority = 4)
	public void Verify_URL_Does_Not_Deliver_The_Asset_Till_Complete_Status() {
		test.ContentView.VerifyCopyedURLIsNotAbleToLoad();
	}

	// 3.Verified that User is able to copy the generated URL successfully while the
	// status is 'In-Progress'/ 'Completed' by clicking the Copy icon.
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Copy_AssetURL()
			throws HeadlessException, UnsupportedFlavorException, IOException {
		test.ContentView.changeWindow(0);
		test.ContentView.CopyAssetUrlFromIconAndVerify();
	}

	// 4.Verified that 'Complete' status is displayed once the push action gets
	// completed.
	// BS-3098
	@Test(priority = 6)
	public void Verify_Complete_Status_Displayed() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyNGAPushOperationCompletes();
	}

	// 5. Delete Uploaded Image
	@Test(priority = 7)
	public void Delete_The_Uploaded_Image1() {
		test.ContentView.DeleteContentFromCMS();
	}

	// 6. CMS.DAM Asset::Verified that once the Asset is pushed to NGA, user can
	// access the generated URL via Publish Details tab though the status is
	// In-Progress.
	// BS-3098
	@Test(priority = 8)
	public void Verify_URL_Generates_When_Status_Is_InProgress_For_Dam_Asset() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(DAMInstructorResource);
		test.Contentpage.opentheSearchContent(DAMInstructorResource);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyPushStatusOnPublishDetails("In Progress");
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyURL_IsDisplayed();
		test.ContentView.ClickX_OnWindow();
	}

	// 7.CMS.DAM Asset::Verified that until the status gets 'Completed', the URL
	// does not deliver the asset. The Pushed asset only loads when the status gets
	// Completed.
	// BS-3098
	@Test(priority = 9)
	public void Verify_URL_Does_Not_Deliver_The_Asset_Till_Complete_Status_Dam_Asset() {
		test.ContentView.VerifyCopyedURLIsNotAbleToLoad();
	}

	// 8.CMS.DAM Asset::Verified that User is able to copy the generated URL
	// successfully while the status is 'In-Progress'/ 'Completed' by clicking the
	// Copy icon.
	// BS-3098
	@Test(priority = 10)
	public void Verify_User_Is_Able_To_Copy_AssetURL_DAM_Asset()
			throws HeadlessException, UnsupportedFlavorException, IOException {
		test.ContentView.changeWindow(0);
		test.ContentView.CopyAssetUrlFromIconAndVerify();
	}

	// 9.CMS.DAM Asset::Verified that 'Complete' status is displayed once the push
	// action gets completed.
	// BS-3098
	@Test(priority = 11)
	public void Verify_Complete_Status_Displayed_DamAsset() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyNGAPushOperationCompletes();
	}

	// 10.Verify that Push to NGA Authoring is not appearing in Bold format
	@Test(priority = 12)
	public void Verify_Push_To_NGA_Authoring_Is_Not_Appearing_In_Bold() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyPushToNGA_EntryNotBoldInHistoryTable();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
