package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_UserName_Capturing extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String TestISBN, PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare;
	String TypesOfContentEnhancedEpub, TestData, InstructorResourceAsset, MarketingSampleChapter;
	String TypesOfContentInstructorResources, PublihDestinationInstructorStore, TypeOfContentMarketingSampleChapter;
	String PublihDestinationVitalSource, BatchEpubISBN, ContentTypeImageSource, FileTitle, PushToAuthoringToolHttpLinks;
	String UploadISBN, FileTitleEpubFlow, PushToAuthoringToolFrost, TypesOfContentFlatEpub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestISBN = getData("UserNameISBN");
		TestData = getData("ProjectISBNNO");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		InstructorResourceAsset = getData("DamContent");
		MarketingSampleChapter = getData("MarketingSampleChapter");
		TypesOfContentInstructorResources = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		TypeOfContentMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		BatchEpubISBN = getData("BatchEpub");
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
		FileTitle = getStringWithDateAndTimes("NGA_Automation_Test");
		PushToAuthoringToolHttpLinks = getData("PushToAuthoringTool.Https link");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		UploadISBN = getData("ProjectISBNNo1");
		PushToAuthoringToolFrost = getData("PushToAuthoringTool.Frost");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step:: Test Test Data
	@Test(priority = 2)
	public void Set_Test_Data_on_Project() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestData);
		test.Contentpage.SelectContentOnContentTab(TestData + ".epub", TypesOfContentEnhancedEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(TestISBN);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(InstructorResourceAsset);
		test.Contentpage.SelectContentOnContentTab(InstructorResourceAsset, TypesOfContentInstructorResources);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(TestISBN);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(MarketingSampleChapter);
		test.Contentpage.SelectContentOnContentTab(MarketingSampleChapter, TypeOfContentMarketingSampleChapter);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(TestISBN);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestData + "_EPUB.epub");
		test.Contentpage.SelectContentOnContentTab(TestData + "_EPUB.epub", TypesOfContentFlatEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(TestISBN);
	}

	// "Project view> Workflow History: When Publish process completes.
	// a) sandeep.singh.contractor@macmillan.com is captured for IS, Palgrave,
	// CoreSource, Courseware
	// b) sandeep.singh.contractor@macmillan.com is captured for VS (In-Progress
	// entry), however, cms.user@macmillan.com is captured for VS (Success entry)"
	// BS-3092
	@Test(priority = 2)
	public void Verify_UserName_Captured_after_publish_Operation_ProjectView() throws InterruptedException {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentFlatEpub,
				TestData + "_EPUB.epub", true);
		test.projectView.Select_Assert_Displayed_In_Step3(TestData + "_EPUB.epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyActionInWorkFlowHistory("Publish to " + PublihDestinationCoreSource);
		test.projectView.VerifyUserNameWorkFlowHistory(AdminEmail);

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TestData + ".epub", true);
		test.projectView.Select_Assert_Displayed_In_Step3(TestData + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyActionInWorkFlowHistory("Publish to " + PublihDestinationPalgrave);
		test.projectView.VerifyUserNameWorkFlowHistory(AdminEmail);

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("DAM", TypesOfContentInstructorResources,
				InstructorResourceAsset, true);
		test.projectView.Select_Assert_Displayed_In_Step3(InstructorResourceAsset);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyActionInWorkFlowHistory("Publish to " + PublihDestinationCourseWare);
		test.projectView.VerifyUserNameWorkFlowHistory(AdminEmail);

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter, true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyActionInWorkFlowHistory("Publish to " + PublihDestinationInstructorStore);
		test.projectView.VerifyUserNameWorkFlowHistory(AdminEmail);

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestData);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectRadioButtonOnPublish("Publish content links and ePub");
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				TestData + ".epub", true);
		test.projectView.Select_Assert_Displayed_In_Step3(TestData + ".epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.hardWait(100); // waiiting for (IN PROGRESS) Status
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyActionInWorkFlowHistory(
				"Publish to " + PublihDestinationVitalSource + ", " + PublihDestinationCourseWare);
		test.projectView.VerifyUserNameWorkFlowHistory(AdminEmail); // For In Progress Entry...
		test.projectView.ClickPublishDetail();
		test.projectView.WaitforpublishToComplete("Success", "1");
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyActionInWorkFlowHistory(
				"Publish to " + PublihDestinationVitalSource + ", " + PublihDestinationCourseWare);
		test.projectView.VerifyUserNameWorkFlowHistory("cms.user@macmillan.com"); // For Success Entry..

	}

	// 2.Project view> Workflow History: Verify CMS Username is displayed in
	// WorkFlow History table for Push to Frost initiation Process.
	// BS-3092
	@Test(priority = 3)
	public void Verify_UserName_Captured_after_Frost_Operation_ProjectView() {
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(TestData + ".epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(TestISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(TestISBN);
		test.projectView.ClickPushOnPushToAuthoringTool();
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyActionInWorkFlowHistory("Push to frost");
		test.projectView.VerifyUserNameWorkFlowHistory(AdminEmail);

	}

	// 3.Content View> Content History: Verify During Organized Download from
	// Project view or Download from Content view, CMS Username is displayed in
	// Content History table
	// BS-3092
	@Test(priority = 4)
	public void Verify_UserName_Captured_During_Organized_Download() {
		test.projectView.clickTopLinkMore();
		test.projectView.clickOrganisedDownload();
		test.projectView.OrganisedDownloadInThreeLevelStructure("ISBN", "Repository", "Content Type");
		test.projectView.selectAllInOrganizedDownload();
		test.projectView.clickFinishButtonOnOrganizedDownload();
		test.projectView.ClickOpenAssetOnProjectView(TestData + ".epub", TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.hardWait(5);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Download");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);
		test.ContentView.navigateBack();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(MarketingSampleChapter, TypeOfContentMarketingSampleChapter);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.hardWait(5);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Download");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestData + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(TestData + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickDownloadContent();
		test.ContentView.hardWait(5);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyHistoryIsDisplayed();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Download");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);

	}

	// 4.Content view> Content History: Verify when Publish process completes,CMS
	// Username is displayed in Content History table.
	// BS-3092
	@Test(priority = 5)
	public void Verify_UserName_Captured_Publish_Process_Completes() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickPublishDetail();
		test.ContentView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Publish to " + PublihDestinationCoreSource);
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);
	}

	// 5.Content view> Content history: Verify when User updates the Content, CMS
	// Username is displayed in Content History table.
	// BS-3092
	@Test(priority = 6)
	public void Verify_UserName_Captured_When_User_Updates_Content() {
		test.ContentView.ClickEditLink();
		test.ContentView.EditDescription(getStringWithDateAndTimes("New Description"));
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyContentHistoryTableActionUpdated("updated");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);
	}

	// 6.Content view> Content history: Verify when user Revalidates the Content,
	// CMS Username is displayed in Content History table.
	// BS-3092
	@Test(priority = 7)
	public void Verify_UserName_Captured_When_User_Revalidate_Content() {
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(BatchEpubISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(BatchEpubISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickRevalidate();
		test.ContentView.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Revalidate");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);
	}

	// Step:: Upload Sample Image.
	@Test(priority = 8)
	public void Step1_Upload_Sample_Image() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(TestData + "_FC.jpg");
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();

	}

	// 7.Content view> Content history: Verify when Push to NGA process completes,
	// CMS Username is displayed in Content History table.
	// BS-3092
	@Test(priority = 9)
	public void Verify_UserName_Captured_When_Push_To_NGA_Process_Completes() {
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.VerifyNGAPushOperationCompletes();
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Push to https link");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);
	}

	// 8."Content view> Content History: When Publish process completes
	// a) sandeep.singh.contractor@macmillan.com is captured for IS, Palgrave,
	// CoreSource
	// b) cms.user@macmillan.com is captured for VS (Success entry), no in-progress
	// entry is recorded here"
	// BS-3092
	@Test(priority = 10)
	public void Verify_UserName_Captured_after_publish_Operation_ContentView() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickPublishDetail();
		test.ContentView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Publish to " + PublihDestinationCoreSource);
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickPublishDetail();
		test.ContentView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Publish to " + PublihDestinationPalgrave);
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(MarketingSampleChapter);
		test.Contentpage.opentheSearchContent(MarketingSampleChapter);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickPublishDetail();
		test.ContentView.WaitforpublishToComplete("Complete", "1");
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Publish to " + PublihDestinationInstructorStore);
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestData + ".epub");
		test.Contentpage.opentheSearchContent(TestData + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
		test.ContentView.ClickPublishDetail();
		test.ContentView.WaitforpublishToComplete("Success", "1");
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Publish to " + PublihDestinationVitalSource);
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated("cms.user@macmillan.com");

	}

	// Upload An Epub for ePub's workflow status
	@Test(priority = 12)
	public void Upload_Epub_For_ePub_WorkFlow_Status() {
		FileTitleEpubFlow = getStringWithDateAndTimes("EpubAutomationTesting");
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.EnterTextIntoTitleField(FileTitleEpubFlow);
		test.HomePage.SelectFileUsingBrowseButton(UploadISBN + ".epub");
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(FileTitleEpubFlow);
		test.Contentpage.opentheSearchContent(FileTitleEpubFlow);
		test.ContentView.VerifyOnContentViewPage();
	}

	// 9.Content view> Content history: ePub's workflow status changes like File
	// Ingested, Structural Validation in Progress, Structural Validation Complete
	// etc - cms.user@macmillan.com will display in Content History table.
	// BS-3092
	@Test(priority = 13)
	public void Verify_UserName_Captured_File_Ingested_Structural_Validation_In_Progress() throws InterruptedException {
		test.ContentView.VerifyContentHistoryTableActionUpdated("Workflow update: File Ingested");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);
		test.ContentView.logMessage("waiting for workflow status to change 'Structural Validation in Progress'.......");
		test.ContentView.hardWait(80); // wait for status to Structural Validation in Progress entry
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(FileTitleEpubFlow);
		test.Contentpage.opentheSearchContent(FileTitleEpubFlow);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Workflow update: Structural Validation in Progress");
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated("cms.user@macmillan.com");
	}

	// Delete the Uploaded the Content
	@Test(priority = 14)
	public void Delete_The_uploaded_Test_Image() {
		test.ContentView.DeleteContentFromCMS();
	}

	// 10.Publish details tab> Authoring Platform Push Details section CMS Username
	// is displayed in Authoring Platform Push Details Table.
	// BS-3092
	@Test(priority = 15)
	public void Verify_UserName_Captured_In_Authoring_Platform_Push_Details_Table() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.VerifyUserEmailDisplayedOnAuthoringPlatformPushDetails(AdminEmail);
	}

	// 11."Upload Version via UI/ Hotfolder> Version Details tab
	// a) via UI: sandeep.singh.contractor@macmillan.com is captured
	// b) Via Hotfolder: cms.user@macmillan.com is captured"
	// BS-3092
	@Test(priority = 16)
	public void Verify_UserName_Captured_Upload_Version_In_Version_Details_Tab() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestData + "_FC.jpg");
		test.Contentpage.opentheSearchContent(TestData + "_FC.jpg");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickVersionDetails();
		test.ContentView.ClickUploadNewVersion();
		test.ContentView.UploadNewVersionOfContent(TestData + "_FC.jpg");
		test.ContentView.VerifyUploadedByVersionTab(AdminEmail);
	}

	// 12."Project View> System metadata
	// a) Created By: cms.user@macmillan.com is captured
	// b) Modified By: cms.user@macmillan.com is displaying"
	// BS-3092
	@Test(priority = 17)
	public void Verify_CMS_User_Displayed_For_System_Metadata_ProjectView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestData);
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyUserEmailModifiedBy("cms.user@macmillan.com");
		test.projectView.VerifyUserEmailCreatedBy("cms.user@macmillan.com");
	}

	// 13."Content view> System metadata
	// Created By:
	// a) cms.user@macmillan.com is captured if asset is imported via Hotfolder.
	// b) sandeep.singh.contractor@macmillan.com is captured when asset is uploaded
	// via UI.
	// Modified By:
	// a) CMS User is captured instead of cms.user@macmillan.com if asset's version
	// is updated via Hotfolder.
	// b) sandeep.singh.contractor@macmillan.com is captured when asset is updated
	// via UI. "
	// BS-3092
	@Test(priority = 18)
	public void Verify_CMS_User_Displayed_For_System_Metadata_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyUserEmailCreatedBy(AdminEmail);
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle("AutomationTestEdit");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited("AutomationTestEdit");
		test.ContentView.VerifyUserEmailModifiedBy(AdminEmail);

	}

	// 14.Upload Content via UI/ Hotfolder> Version Details tab
	// a) via UI: sandeep.singh.contractor@macmillan.com is captured
	// b) Via Hotfolder: cms.user@macmillan.com is captured
	// BS-3092
	@Test(priority = 19)
	public void Verify_CMS_User_Displayed_For_Uploaded_Content_VersionDetail_Tab() {
		test.ContentView.clickVersionDetails();
		test.ContentView.VerifyUploadedByVersionTab(AdminEmail);
	}

	// Delete the Uploaded the Content
	@Test(priority = 20)
	public void Delete_The_uploaded_Test_Image_NGA() {
		test.ContentView.DeleteContentFromCMS();
	}

	// 15.Content view> Content history: Verify for Push to Frost initiation
	// Process, CMS Username is displayed in Content History table.
	// BS-3092
	@Test(priority = 21)
	public void Verify_UserName_Captured_after_Frost_Operation_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(TestData + "_FC.jpg");
		test.Contentpage.opentheSearchContent(TestData + "_FC.jpg");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolFrost);
		test.ContentView.SearchProjectOnAuthoringTool(TestISBN);
		test.ContentView.SelectProjectOnAuthoringTool(TestISBN);
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.ClickX_OnWindow();
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView
				.VerifyContentHistoryTableActionUpdated("Workflow update: Push to frost Under ISBN-" + TestISBN);
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);

	}

	// "Verified that column header has been renamed from 'User' to 'Username' in
	// following locations:
	// a) Project view page> Publish details tab> Publish History table
	// BS-2898
	@Test(priority = 22)
	public void Verify_Coloum_Username_In_Publish_History_Table_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyHeaderOfPublishTab();

	}

	// "Verified that column header has been renamed from 'User' to 'Username' in
	// following locations:
	// b) Content view page> Publish details tab> Publish History table
	// BS-2898
	@Test(priority = 23)
	public void Verify_Coloum_Username_In_Publish_History_Table_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(TestData + "_FC.jpg");
		test.Contentpage.opentheSearchContent(TestData + "_FC.jpg");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyHeaderOfPublishTab();
	}

	// "Verified that column header has been renamed from 'User' to 'Username' in
	// following locations:
	// c) Content view page> Publish details tab> Authoring Platform Push Details
	// table
	@Test(priority = 24)
	public void Verify_Coloum_Username_In_Authoring_Platform_Push_Details_ContentView() {
		test.ContentView.VerifyTableHeaderForAuthoringPlatformPushDetails();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
