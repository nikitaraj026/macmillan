package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_BrightCove_Asset_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String BrightCoveAssetWithoutLumiaID, AdvSearchTypeRepository, RepoBrightCove;
	String BrightCoveAssetWithLumiaID, BrightCoveAssetNameWithID, DBKey, PNF, BrightcoveMsg;
	String BrightCoveAssetNameWithoutID, ISBN2, TypesOfContentRichMediaContentVideo;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		BrightCoveAssetWithoutLumiaID = getData("BrightCoveAssetWithoutLumiaID");
		BrightCoveAssetNameWithoutID = getData("NameAssetWithoutLumiaID");
		AdvSearchTypeRepository = getData("SearchTypeAdvanceSearch.Repository");
		RepoBrightCove = getData("NonCMSAssert.BrightCove");
		BrightCoveAssetWithLumiaID = getData("BrightCoveAssetWithLumiaID.AssetID");
		BrightCoveAssetNameWithID = getData("BrightCoveAssetWithLumiaID.Name");
		DBKey = getData("BrightCoveAssetWithLumiaID.DBKey");
		PNF = getData("BrightCoveAssetWithLumiaID.PNF");
		BrightcoveMsg = getData("BrightcoveMsg");
		ISBN2 = getData("ProjectISBNNo1");
		TypesOfContentRichMediaContentVideo = getData("TypesOfContent.Rich Media Content>Video");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1."1) When the BC asset has no Rights Metadata:
	// a) Verified that NA is displayed under 'Lumina Asset DB Key' and 'PFN'
	// column headers since no values are available for the same."
	// BS-2477
	@Test(priority = 2)
	public void Verify_NA_Displayed_Under_DBKey_And_PFN_Column_When_BC_Asset_Has_No_Rights_Metadata() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.EnterTextIntoSearchBox(BrightCoveAssetWithoutLumiaID);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeRepository);
		test.SearchPage.SelectContentTypeInNewAddedField(RepoBrightCove);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyLuminaRightsDetails("NA", "NA");
	}

	// 2."1) When the BC asset has no Rights Metadata:
	// Verify that clicking on the 'View Rights Details' displays the following
	// message:
	// 'Rights Details Not Available. Please contact Rights team for details.'"
	// BS-2477
	@Test(priority = 3)
	public void Verify_Correct_Message_Displayed_for_No_Rights_Metadata() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewRightsDetails();
		test.ContentView.VerifyCorrectRightDetailMsgIsDisplayed();
	}

	// 3."2) When the BC asset has Rights Metadata:
	// a) Verified that six digit numeric value is getting displayed under
	// 'Lumina Asset DB Key' and 'PFN' column headers of Lumina Rights Details
	// table present under Content Details tab."
	// BS-2477
	@Test(priority = 4)
	public void Verify_DBKey_And_PFN_Column_Values_When_BC_Asset_Has_Rights_Metadata() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.EnterTextIntoSearchBox(BrightCoveAssetWithLumiaID);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyLuminaRightsDetails(DBKey, PNF);
	}

	// 4."2) When the BC asset has Rights Metadata:
	// b) Verified that on clicking 'More> View Rights Details', user is
	// navigated to Rights Platform page in a new tab containing the Content ID,
	// Asset DB ID, PFN and other respective information."
	// BS-2477
	@Test(priority = 5)
	public void Verify_When_BC_Asset_Has_Rights_Metadata_clicking_ViewRightsDetails() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewRightsDetails();
		test.ContentView.VerifyMessageWhileRightsDetailsAreOpening();
		test.ContentView.changeWindow(1);
		test.ContentView.VerifyOnRightPlatformApplication();
		test.ContentView.VerifyAssetIDOnRightPlatform(BrightCoveAssetWithLumiaID);
		test.ContentView.VerifyAssetDB_Key_And_PNF(DBKey, PNF);
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 5."Verify that following message is displayed when user selects a SINGLE/
	// MULTIPLE BC asset and clicks on 'Download Content' link:
	// BrightCove assets cannot be downloaded."
	// BS-2328
	@Test(priority = 6)
	public void Verify_Message_Displayed_If_User_Select_SINGLE_MULTIPLE_BC_Asset_And_Clicks_Download_Content() {
		test.HomePage.changeWindow(0);
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.HomePage.ClickOpenRepository(RepoBrightCove);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(BrightcoveMsg, "");

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(BrightcoveMsg, "");
	}

	// 6."Verify that following message is displayed when user selects a SINGLE/
	// MULTIPLE BC asset and clicks on 'Organized Download' link:
	// BrightCove assets cannot be downloaded."
	// BS-2328
	@Test(priority = 7)
	public void Verify_Message_Displayed_If_User_Select_SINGLE_MULTIPLE_BC_Asset_And_Clicks_Download_Content_Organized_Download() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.HomePage.ClickOpenRepository(RepoBrightCove);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(BrightcoveMsg, "");

		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(BrightcoveMsg, "");
	}

	// 7.Verify that user is not able to delete the BC assets
	// BS-2328
	@Test(priority = 8)
	public void Verify_User_Cannnot_Delete_BrightCove_Assets() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.VerifyDeletePopupDisplayed();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		test.Contentpage.VerifyNoContentToDeleteMsgDisplayed();
	}

	// 8.Verify that user is able to add the BC asset(s) to multiple projects
	// using 'Add to Project' link
	// BS-2328
	@Test(priority = 9)
	public void Verify_User_Is_Able_To_Add_BC_Asset_Using_Add_To_Project() {
		test.Contentpage.SearchForAnItem(BrightCoveAssetNameWithoutID);
		test.Contentpage.SelectContentOnContentTab(BrightCoveAssetNameWithoutID,TypesOfContentRichMediaContentVideo);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2);

		test.Contentpage.SearchForAnItem(BrightCoveAssetNameWithID);
		test.Contentpage.SelectContentOnContentTab(BrightCoveAssetNameWithID,TypesOfContentRichMediaContentVideo);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(BrightCoveAssetNameWithoutID, TypesOfContentRichMediaContentVideo);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN2);

		test.ContentView.navigateBack();
		test.ContentView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(BrightCoveAssetNameWithID, TypesOfContentRichMediaContentVideo);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN2);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
