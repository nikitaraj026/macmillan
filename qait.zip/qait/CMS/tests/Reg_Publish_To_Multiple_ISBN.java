package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Publish_To_Multiple_ISBN extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String ISBN, ISBN2, ISBN3, AuthorImage, DestinationInstructorStore, DestinationCoreSource;
	String DestinationPalgrave, DestinationCourseWare, DestinationVitalSource, ContentTypeFlatEpubFullPackage;
	String InstructorResourceAsset, ContentTypeInstructorResource, ContentTypeAuthorImage, AuthorId, CMSRepository,
			DAMRepository, PageSelectionAllPages, TestISBN;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNo6");
		ISBN2 = getData("ProjectISBNNo3");
		ISBN3 = getData("ProjectISBNNo2");
		TestISBN = getData("ProjectISBNNO");
		AuthorImage = getData("MarketingAuthorImage");
		DestinationInstructorStore = getData("PublishDestination.Instructor Store");
		DestinationCoreSource = getData("PublishDestination.CoreSource");
		DestinationPalgrave = getData("PublishDestination.Palgrave");
		DestinationCourseWare = getData("PublishDestination.CourseWare");
		DestinationVitalSource = getData("PublishDestination.VitalSource");
		ContentTypeFlatEpubFullPackage = getData("TypesOfContent.Flat ePub > Full Package");
		InstructorResourceAsset = getData("DamContent");
		ContentTypeInstructorResource = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		ContentTypeAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		AuthorId = getData("Author.id");
		CMSRepository = getData("Repository.CMS");
		DAMRepository = getData("Repository.DAM");
		PageSelectionAllPages = getData("PageSelection.All Pages");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step1:: Add the Assets to the Project.
	@Test(priority = 2)
	public void Step1_Add_Asset_To_Project() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN2 + "_EPUB.epub");
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_EPUB.epub", ContentTypeFlatEpubFullPackage);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.Contentpage.SearchForAnItem(AuthorImage);
		test.Contentpage.SelectContentOnContentTab(AuthorImage,ContentTypeAuthorImage);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN);

		test.Contentpage.SearchForAnItem(InstructorResourceAsset);
		test.Contentpage.SelectContentOnContentTab(InstructorResourceAsset,ContentTypeInstructorResource);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN);
	}

	// 1.Verify that user is able to Publish to Palgrave via default ISBN only
	// BS-2959
	@Test(priority = 3)
	public void Verify_User_Is_Able_To_Publish_To_Palgrave_Via_Default_ISBN_Only() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(DestinationInstructorStore);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN3);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN3);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN3);
		test.projectView.selectDestinationOfPublish(DestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeFlatEpubFullPackage,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN2 + "_EPUB.epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 2.Verify that user is able to Publish to Courseware via default ISBN only
	// BS-2959
	@Test(priority = 4)
	public void Verify_User_Is_Able_To_Publish_To_Courseware_Via_Default_ISBN_Only() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(DestinationInstructorStore);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN3);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN3);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN3);
		test.projectView.selectDestinationOfPublish(DestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(DAMRepository, ContentTypeInstructorResource,
				InstructorResourceAsset,true);
		test.projectView.Select_Assert_Displayed_In_Step3(InstructorResourceAsset);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 3.Verify that user is able to Publish to CoreSource via default ISBN only
	// BS-2959
	@Test(priority = 4)
	public void Verify_User_Is_Able_To_Publish_To_CoreSource_Via_Default_ISBN_Only() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(DestinationInstructorStore);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN3);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN3);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN3);
		test.projectView.selectDestinationOfPublish(DestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeFlatEpubFullPackage,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN2 + "_EPUB.epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 4.Verify that user is able to Publish to VitalSource via default ISBN only
	// BS-2959
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Publish_To_VitalSource_Via_Default_ISBN_Only() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN3);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN3);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN3);
		test.projectView.selectDestinationOfPublish(DestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeFlatEpubFullPackage,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN2 + "_EPUB.epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 5.Verify that user is able to publish to Single/multiple ISBNs to Instructor
	// Store
	// BS-2959
	@Test(priority = 6)
	public void Verify_User_Can_Publish_Single_multiple_ISBN_To_Instructor_Store() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(DestinationInstructorStore);
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN3);
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN3);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN3);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeAuthorImage, AuthorImage,true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(2);
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN, ISBN3);
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(2);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN3);
		test.projectView.ClickCloseButton();

		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(DestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeAuthorImage, AuthorImage,true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId + ".jpg");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 6.Verify that if user deletes the default ISBN when IS is selected> then
	// selects a new destination> able to publish successfully to the default ISBN
	// BS-2959
	@Test(priority = 7)
	public void Verify_User_successfully_Publish_After_deleteing_Default_ISBN() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(DestinationInstructorStore);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN);
		test.projectView.selectDestinationOfPublish(DestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeFlatEpubFullPackage,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.Select_Assert_Displayed_In_Step3(ISBN2 + "_EPUB.epub");
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.VerifyCountOfISBNsDisplayedOnPublishMessage(1);
		test.projectView.VerifyPublishedISBNOnPublishMessage(ISBN);
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 7.Verify that Approve/ Unapprove buttons remain disabled if no Content is
	// selected on Step 2 Select Assets
	// BS-2930
	@Test(priority = 8)
	public void Verify_Approve_Unapprove_Buttons_Disabled_If_No_Content_Selected_On_Step2() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyApproveButtonOnPublishPopUpDisabled();
		test.projectView.VerifyUnapproveButtonOnPublishPopUpDisabled();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.VerifyApproveButtonOnPublishPopUpDisabled();
		test.projectView.VerifyUnapproveButtonOnPublishPopUpDisabled();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
	}

	// 8.Verify that Select all Button is not Dispalyed in step 3 if no Content are
	// Selected on Step 2 Select Assets section of publish Window.
	// BS-2930
	@Test(priority = 9)
	public void Verify_Select_All_Button_Not_Dispalyed_In_Step3_If_No_Content_Selected_On_Step2() {
		test.projectView.VerifyPageSelectionDropDownNotDisplayed();
	}

	// 9.Verify that Approve/ Unapprove buttons gets enabled if user clicks on 'All
	// Pages' option in step 3 provided that Assets are available in Step 3.
	// BS-2930
	@Test(priority = 10)
	public void Verify_Approve_Unapprove_Buttons_Enabled_If_Content_Selected_On_Step2() {
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, ContentTypeFlatEpubFullPackage,
				TestISBN + "_EPUB.epub",true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.VerifyApproveButtonOnPublishPopUpEnabled();
		test.projectView.VerifyUnapproveButtonOnPublishPopUpEnabled();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
