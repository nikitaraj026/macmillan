package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Content_Page_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, DownloadStartMsg, ISBN, ISBN2, DamContent,
			OrganisedDownloadMsg;
	String ContentTypeInstructor, SelectPageAll, SelectPageThisPage, SelectPageNone, BrightcoveMsg, ISBN3;
	String FacetContentType, FacetLinkImageLinked, TypesOfContentEnhancedEpub, TypesOfContentFlatEpub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		DownloadStartMsg = getData("DownloadStartMsg");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		ISBN3 = getData("ProjectISBNNo3");
		DamContent = getData("DamContent");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsg");
		ContentTypeInstructor = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		SelectPageAll = getData("PageSelection.All Pages");
		SelectPageThisPage = getData("PageSelection.This Page");
		SelectPageNone = getData("PageSelection.None");
		BrightcoveMsg = getData("BrightcoveMsg");
		FacetContentType = getData("FacetType.Content Type");
		FacetLinkImageLinked = getData("TypesOfContent.Images>Image Linked");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutFromApplication() {
		test.HomePage.LogoutFromApplication();
	}

	// 1.Verify that Result Number dropdown, Sort By dropdown, Grid and List view
	// buttons are available
	@Test(priority = 1)
	public void VerifyResultNumberDropdownEtcElementAreDisplayed() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyFilterOprions();
		test.Contentpage.selectContent("1");
		test.Contentpage.VerifyModifyOptions();

	}

	// 2.Verify that projects are displayed in the table with following columns:1)
	// Title2) File Name etc
	@Test(priority = 2)
	public void verifyColumnsAreDisplayed() {
		test.Contentpage.verifyColumnsAreDisplayed();
	}

	// 3.Verify that ePub labels for Flat and Enhanced ePubs are displaying in Grid
	// view
	@Test(priority = 3)
	public void VerifyThatEPubLabelsFoFlatAndEnhancedEPubsAreDisplayingInGridview() {
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyFlatIsDisplayed();
		test.Contentpage.VerifyEnhancedIsDisplayed();
	}

	// 4. Verify that a user is able to select multiple Contents using checkboxes or
	// by Select All checkbox
	@Test(priority = 4)
	public void VerifyUserIsAbleToSelectMultipleContentsUsingCheckboxesOrBySelectAllCheckbox() {
		test.Contentpage.clickListView();
		test.Contentpage.SelectContentsUsingCheckboxesOrBySelectAllCheckbox();
	}

	// 5.Verify that a pagination bar is present at the bottom of Contents tab
	@Test(priority = 5)
	public void VerifyPaginationBarIsPresent() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.VerifyPaginationBarIsVisible();
		test.Contentpage.VerifyBackAndForthNavigationpaginationBar();

	}

	// 6.Verify that if user downloads a single content, then downloading starts
	// right away and if user selects multiple contents and clicks on Download
	// Content, then a message is displayed for CMS Asset
	@Test(priority = 6)
	public void Verify_User_Is_Able_To_Download_Single_AND__Multiple_CMS_ASSET() throws IOException {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.HomePage.ClickOpenRepository("CMS");
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");

		test.Contentpage.SearchForAnItem("\"" + ISBN + ".epub\"");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab();
	}

	// 7.Verify that if user downloads a single content Or multiple contents and
	// clicks on Download Content, then a message is displayed for Non-CMS Asset
	@Test(priority = 7)
	public void Verify_User_Is_Able_To_Download_Single_AND_Multiple_Non_CMS_Asset() throws IOException {
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "1");

	}

	// 8.Verify that user is able to organize his download with upto three level
	// folder structure as ISBN, Content Type and Repository
	@Test(priority = 8)
	public void Test_User_Is_Able_To_Organize_His_Download_Upto_ThreeL_Level_Folder_Structure() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + " epub");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "1");
	}

	// 9.Verify that a user is successfully able to add multiple assets into a
	// project using Add to project button present on Content tab
	@Test(priority = 9)
	public void Verify_User_Is_Successfully_Able_To_Add_Multiple_Assets() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN + " epub");
		test.Contentpage.SelectContentOnContentTab(ISBN + "_EPUB.epub", TypesOfContentFlatEpub);
		test.Contentpage.SelectContentOnContentTab(ISBN + ".epub", TypesOfContentEnhancedEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.ClickOpenAssetOnProjectView(ISBN + "_EPUB.epub", TypesOfContentFlatEpub);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN2);// File with ISBN To be removed
		test.ContentView.navigateBack();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(ISBN + ".epub", TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN2);// File with ISBN To be removed
	}

	// 10.Verify that a user is successfully able to delete cms assets only using
	// delete button present on Content tab
	@Test(priority = 10)
	public void Verify_User_Is_Successfully_Able_To_Delete_Cms_Asset() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickUploadContent();
		test.Contentpage.UploadContentFromContentPageToDelete(ISBN3);
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem("Delete Test");
		test.Contentpage.DeleteCheckedContent("Delete Test");
	}

	// 11. Verify that Preview of assets are appearing properly for all the
	// repositories assets
	@Test(priority = 11)
	public void Preview_Of_Assets_Are_Appearing_For_All_Repo() {
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("CMS");
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyPreviewOfRepo("CMS");

		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyPreviewOfRepo("DAM");

		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("BrightCove");
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyPreviewOfRepo("BrightCove");

	}

	// 12. Verify that a user is able to add these non cms assets into different
	// projects across CMS application
	@Test(priority = 12)
	public void Verify_User_Is_Able_To_Add_NonCMS_Asset_To_Project() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.clickListView();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.SelectContentOnContentTab(DamContent, ContentTypeInstructor);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2); // Continued in Next test Case

	}

	// 13.Verify that Success message is displayed when user adds Assets to projects
	@Test(priority = 13)
	public void Verify_Success_Message_Is_Displayed_On_Adding_Content_To_Project() {
		test.Contentpage.Verify_Success_Message_Is_Displayed_On_Adding_Content_To_Project(ISBN2);
		test.HomePage.clickProjectTab();
		test.ProjectPage.clickListView();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.ClickOpenAssetOnProjectView(DamContent, ContentTypeInstructor);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN2);
	}

	// 14.Verify that facet links are available to the left of the page and on
	// clicking them user navigates to the concerned searched results and clicking
	// See more link opens the relevant Pop up
	@Test(priority = 14)
	public void VerifyThatUserCanNavigateToFacetLinks() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.clickOnFacetLinks();
	}

	// 15.Verify that user is able to access the assets of other repositories i.e.
	// Elvis, BrightCove, DAM, and CMS under CMS
	@Test(priority = 15)
	public void Verify_User_Is_Able_To_Access_The_Assets_Of_Other_Repositories() {
		test.HomePage.ClickContentTab();
		test.HomePage.ViewAssetsOfRepository("CMS");
		test.HomePage.ClickContentTab();
		test.HomePage.ViewAssetsOfRepository("DAM");
		test.HomePage.ClickContentTab();
		test.HomePage.ViewAssetsOfRepository("BrightCove");
	}

	// 16.Verify that Organized Download, Download content, Add to Project, and
	// Delete links are available at the top which remains disabled by default and
	// becomes active once a content is selected
	@Test(priority = 16)
	public void Verify_Top_Links_Are_Disabled_Until_A_Content_Is_Selected() throws IOException {
		test.HomePage.ClickContentTab();
		test.Contentpage.Verify_Links_Are_Deactivated();
		test.Contentpage.SelectSingleContents();
		test.Contentpage.Verify_Links_Are_Activated();
	}

	// 17.Verify that number of selected assets are displayed along with the Content
	// heading.
	@Test(priority = 17)
	public void Verify_Count_Of_Selectd_Asset_Displayed_With_The_Content_Heading() {
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(1);
		test.Contentpage.SelectSingleContents();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.VerifyCountofSelectedAssetOnContantTab(2);
	}

	// 18.Verify that a user is able to select multiple Contents using checkboxes or
	// by Select Page Feature, And this selection is maintained across the pages
	// available until the Content tab page is refreshed.
	@Test(priority = 18)
	public void Verify_User_Is_Able_To_Select_Multiple_Contents_Using_Checkboxes_Or_By_Select_Page_Feature() {
		test.Contentpage.SearchForAnItem("9897");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(SelectPageThisPage);
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.NavigateToPage("1");
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreSelectedOnContantTab();
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyContentsAreNotSelectedOnContantTab();
	}

	// 19.Verify that proper download/ warning message is displayed when user tries
	// to Download Brightcove assets single or with other repositories assets
	@Test(priority = 19)
	public void Verify_Proper_Download_Message_For_Brightcove_Assets() throws IOException {
		test.HomePage.ClickContentTab();
		test.HomePage.ViewAssetsOfRepository("BrightCove");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(BrightcoveMsg, "");
	}

	// 20.Verify that tool tips are available for instances of ellipsis
	@Test(priority = 20)
	public void Verify_Tool_Tips_Are_Available_For_Instances_Of_Ellipsis() {
		test.Contentpage.VerifyToolTipForEllipsis();
	}

	// 21.Verify that Elvis repository has been removed
	@Test(priority = 21)
	public void Verify_Elvis_Repository_Removed() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.VerifyElvisRepositoryRemoved();
	}

	// Verify that Content type Facet with +See more pop-up is available in left
	// navigation bar and user can click on any filter to get the relevant output
	@Test(priority = 22)
	public void Verify_Content_Type_Facet_With_SeeMore_gets_Relevant_Output() {
		test.Contentpage.clickOnFacetLinks(FacetContentType, FacetLinkImageLinked);
		test.Contentpage.VerifySearchPageLabel(FacetLinkImageLinked);
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.Contentpage.verifyOnSeeMorePopup(FacetContentType);
		test.Contentpage.OpenLinkOnSeeMorePopupWindow(FacetLinkImageLinked);
		test.Contentpage.VerifySearchPageLabel(FacetLinkImageLinked);

	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}