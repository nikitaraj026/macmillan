package com.qait.CMS.tests;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Push_To_Authoring_Tool extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String ISBN, PushToAuthoringToolHttpLinks, TypesOfContentEnhancedEpub;
	String NonStandardMsg, DemoISBN;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		PushToAuthoringToolHttpLinks = getData("PushToAuthoringTool.Https link");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Project view: Verify that Step 3 in Push to Authoring tool window gets
	// hidden if user selects the 'Other Assets' option from Step 2 of the same
	// window.
	// BS-2902
	@Test(priority = 2)
	public void Verify_Step3_In_Push_To_Authoring_Tool_Gets_Hidden_User_Selects_Other_Assets() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.ClickOtherOnPushToAuthoringTool();
		test.projectView.VerifyStep3OfPushToAuthoringToolNotDisplayed();
	}

	// 2.Project view: Verify that Step 3 appears again if user selects the 'Epubs
	// only (Default option)' from Step 2 of the same window.
	// BS-2902
	@Test(priority = 3)
	public void Verify_Step3_Appears_Again_If_User_Selects_Epubs_Only() {
		test.projectView.ClickEpubRadioOnPushToAuthoringTool();
		test.projectView.VerifyStep3OfPushToAuthoringToolIsDisplayed();
	}

	// 3."Project view> Push to Authoring tool window: Verify that tool tip is
	// available for the List/ Grid view button as following in step 2 when Frost is
	// selected as:
	// List View
	// Grid View"
	// BS-1604
	@Test(priority = 4)
	public void Verify_Tool_Tip_Displayed_For_List_And_Grid_ProjectView() {
		test.projectView.VerifyToolTipsOnAuthoringToolGrid();
		test.projectView.ClickListViewOnPushToAuthoringTool();
		test.projectView.VerifyToolTipsOnAuthoringToolList();
		test.projectView.ClickCloseButton();
	}

	// 4."Content view> Push to Authoring tool window: Verify that tool tip is
	// available for the List/ Grid view button as following in step 2 when Frost is
	// selected as:
	// List View
	// Grid View"
	// BS-1604
	@Test(priority = 5)
	public void Verify_Tool_Tip_Displayed_For_List_And_Grid_ContentView() {
		test.projectView.ClickOpenAssetOnProjectView(ISBN + ".epub", TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyToolTipsOnAuthoringToolGrid();
		test.ContentView.VerifyListView();
		test.ContentView.VerifyToolTipsOnAuthoringToolList();

	}

	// 5."Content view> Push to Authoring tool window: Verify that tool tip is
	// available for the List/ Grid view button as following in step 2 when NGA
	// Authoring is selected:
	// List View
	// Grid View"
	// BS-1604
	@Test(priority = 5)
	public void Verify_Tool_Tip_Displayed_For_List_And_Grid_ContentView_For_NGA() {
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.VerifyToolTipsOnAuthoringToolList();
		test.ContentView.ClickViewIconOnPushToAutoringTool();
		test.ContentView.VerifyToolTipsOnAuthoringToolGrid();
		test.ContentView.ClickX_OnWindow();
	}

	
	

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}