package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_RightsPlatform_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String BrightCoveAssetWithoutLumiaID, BrightCoveAssetNameWithoutID, AdvSearchTypeRepository, RepoBrightCove;
	String BrightCoveAssetWithLumiaID, BrightCoveAssetNameWithID, DBKey, PNF;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		BrightCoveAssetWithoutLumiaID = getData("BrightCoveAssetWithoutLumiaID");
		BrightCoveAssetNameWithoutID = getData("NameAssetWithoutLumiaID");
		AdvSearchTypeRepository = getData("SearchTypeAdvanceSearch.Repository");
		RepoBrightCove = getData("NonCMSAssert.BrightCove");
		BrightCoveAssetWithLumiaID = getData("BrightCoveAssetWithLumiaID.AssetID");
		BrightCoveAssetNameWithID = getData("BrightCoveAssetWithLumiaID.Name");
		DBKey = getData("BrightCoveAssetWithLumiaID.DBKey");
		PNF = getData("BrightCoveAssetWithLumiaID.PNF");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that Rights details are available under Content Details tab in
	// Content view page
	// BS-982
	@Test(priority = 2)
	public void Verify_Rights_Details_On_Content_Details_Tab() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.EnterTextIntoSearchBox(BrightCoveAssetWithLumiaID);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickLuminaRightDetail();
	}

	// 2.Verify that the value available under 'Lumina Asset DB key' and 'PFN' is
	// hyperlinked and hand icon appears on hovering the same
	// BS-982
	@Test(priority = 3)
	public void Verify_Lumina_Rights_Section_Is_Now_Hyperlinked() {
		test.ContentView.HoverAndClickLuminaSection();
	}

	// 3.Verify that in case of valid values, clicking the same will take the user
	// to Lumina page
	// BS-982
	@Test(priority = 4)
	public void Verify_User_Navigates_To_Lumina_Page() {
		test.ContentView.changeWindow(1);
		test.ContentView.VerifyOnRightPlatformApplication();
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 4.Verify that user is navigated to the same page no matter if he clicks
	// 'More> View Rights details' option or the Hyperlinked values
	// BS-982
	@Test(priority = 5)
	public void Verify_User_Navigates_To_Lumina_Page_Via_More_Link() {
		test.ContentView.changeWindow(0);
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewRightsDetails();
		test.ContentView.changeWindow(1);
		test.ContentView.VerifyAssetIDOnRightPlatform(BrightCoveAssetWithLumiaID);
		test.ContentView.VerifyAssetDB_Key_And_PNF(DBKey, PNF);
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 5."Verify that if no values are present, then clicking the same will result
	// into following message on the screen:Rights Details Not Available. Please
	// contact Rights team for details."
	// BS-982
	@Test(priority = 6)
	public void Verify_Correct_Message_Displayed_for_No_Rights_Metadata() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.EnterTextIntoSearchBox(BrightCoveAssetWithoutLumiaID);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeRepository);
		test.SearchPage.SelectContentTypeInNewAddedField(RepoBrightCove);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenAnContentOnSearchPage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewRightsDetails();
		test.ContentView.VerifyCorrectRightDetailMsgIsDisplayed();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
