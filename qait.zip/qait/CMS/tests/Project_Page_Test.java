package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Project_Page_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, projectTitle;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		projectTitle = getData("ProjectTitle");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutFromApplication() {
		test.HomePage.LogoutFromApplication();
	}

	// 1. Verify that Result Number dropdown, Sort By dropdown, Grid and List view
	// buttons are available at the top and searched results are updated as per the
	// selection made
	@Test(priority = 1)
	public void Verify_Options_Available_At_The_Top_Of_ProjectTab() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyAllTheOptions();
		test.ProjectPage.SelectNumberFromResultDropDown("10");
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.VerifyCorrectNumberOfContentAreDisPlayed("10");
		test.ProjectPage.verifyAlltheOptionsInSortBy();
	}
	

	// 2. Verify that projects are displayed in the table with following columns:1)
	// Author 2) Title etc
	@Test(priority = 2)
	public void Verify_All_The_Columns_Are_Displayed_In_ProjectTab() {
		test.ProjectPage.verifyColumnsAreDisplayed();
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
		test.ProjectPage.VerifyProjectInfoIsDisplayedOnGridView();
	}

	// 3. Verify that in List view- User can navigate to the project on clicking the
	// Preview icon and in Grid view- User can navigate by clicking on the thumbnail
	// or the project name

	@Test(priority = 3)
	public void Verify_User_Can_Navigate_To_Project_On_Clicking_Preview_And_Thumbnail() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.ProjectPage.verifyUserIsOnProjectView();
		test.HomePage.clickProjectTab();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyThumbnailViewIsWorking();

	}

	// 4.Verify that a pagination bar is present at the bottom of project tab
	@Test(priority = 4)
	public void Verify_Pagination_Bar_Is_Present() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyPaginationBarIsVisible();
		test.ProjectPage.VerifyBackAndForthNavigationpaginationBar();
	}

	// 5.Verify that a user is not able to select Single/ multiple projects using
	// checkboxes or by Select All checkbox

	@Test(priority = 5)
	public void User_Is_Not_Able_To_Select_Project_CheckBoxs() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyCheckBoxAreNotSelected();

	}

	// 6.Verify that user can mark the Project as Favorite by clicking the Star icon
	// present to the left of the Project name in List view/ bottom right in Grid
	// view.
	@Test(priority = 6)
	public void Verify_User_Is_Able_To_Mark_Project_As_Favorite() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.clickGridView();
		test.ProjectPage.AddProjectToFavoriteFromProjectTabGridView(projectTitle);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}
	
	//7."For GRID View: Verify that following metadata is displaying:
	//1) Grayed out Checkbox
	//2) Star Icon
	//3) Author
	//4) Title
	//5) Edition
	//6) ISBN"
	@Test(priority=7)
	public void Verify_Metadata_Info_On_Grid_View() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyProjectInfoIsDisplayedOnGridView();
	}
	

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
