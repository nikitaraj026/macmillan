package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.awt.HeadlessException;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_NGA_HotFix_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String FileTitle, PushToAuthoringToolHttpLinks, ContentTypeImageSource;
	String TestImageforNGA, AssetURl, FirstContentID, SecondContentID;
	String DamContent;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		FileTitle = getStringWithDateAndTimes("NGA_Automation_Test");
		PushToAuthoringToolHttpLinks = getData("PushToAuthoringTool.Https link");
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
		TestImageforNGA = "AutoMation NGA_!@#$%ÀÁÂÃÄÅ.jpg";
		AssetURl = getData("AssetURL");
		DamContent = getData("DamContent");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step1: Upload The Test Image
	@Test(priority = 2)
	public void Upload_Test_Image() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadButtonOnUploadPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
	}

	// 1.Verify that Push to NGA authoring operation gets Complete for the assets
	// that has the Special Characters in the file name
	// 2.Verify that Push to NGA authoring operation gets Complete for the assets
	// that has the Unicode Characters in the file name
	// 3.Verify that Push to NGA authoring operation gets Complete for the assets
	// that has the spaces in the file name
	// BS-3020
	@Test(priority = 3)
	public void Verify_Push_To_NGA_Completes_For_Special_Unicode_spaces() {
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyNGAPushOperationCompletes();
	}

	// 4.Verify that CMS encodes the URL so that spaces in the URL are taken care
	// BS-3020
	@Test(priority = 4)
	public void Verify_CMS_Encodes_The_URL() {
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.VerifyAssertURLEncoded(AssetURl);
		test.ContentView.ClickX_OnWindow();
	}

	// 5.Verify that user is able to copy the generated URL via copy icon
	// BS-3020
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Copy_The_Link_From_Icon()
			throws HeadlessException, UnsupportedFlavorException, IOException {
		test.ContentView.CopyAssetUrlFromIconAndVerify();
	}

	// 6.Verify that same link is getting copied which is displaying in the Asset
	// URL window
	// BS-3020
	@Test(priority = 6)
	public void Verify_Same_Link_Copyed_As_In_Asset_URL()
			throws HeadlessException, UnsupportedFlavorException, IOException {
		test.ContentView.VerifySameLinkAsAssetURLIsCopyedInNGATest();
	}

	// 7.Verify that copied URL is able to load successfully in the browser
	// BS-3020
	@Test(priority = 7)
	public void Verify_Copied_URL_Is_Able_To_Load() {
		test.ContentView.VerifyCopyedURLIsAbleToLoad();
	}

	// 8.Verify that same URL is updated in the Content History table as well
	// BS-3020
	@Test(priority = 8)
	public void Verify_URL_Is_Updated_In_Content_History_Table() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableIsUpdatedWithSameNGAAssetUrl();
	}

	// Step:: Delete the Uploaded Image
	@Test(priority = 9)
	public void Delete_The_Uploaded_Image() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.DeleteContentFromCMS();
	}

	// Step: Upload The Test Image
	@Test(priority = 10)
	public void Upload_Sample_Image() {
		FileTitle = getStringWithDateAndTimes("NGA_Automation_Test");
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadButtonOnUploadPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
	}

	// 9.Verify that the Content ID has been added in the generated NGA URL.
	// BS-3021
	@Test(priority = 11)
	public void Verify_ContentID_Added_In_NGA_URL() {
		FirstContentID = test.ContentView.GetContentIDofAsset();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyNGAPushOperationCompletes();
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.VerifyContentIDPresentOnAssetURL(FirstContentID);
		test.ContentView.ClickX_OnWindow();
	}

	// Step: Upload The Test Image
	@Test(priority = 12)
	public void Upload_Second_Sample_Image() {
		FileTitle = getStringWithDateAndTimes("NGA_Automation_Test");
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadButtonOnUploadPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
	}

	// 9.Verify that since Content ID has been added in the URL, each URL is now
	// unique no matter if two or more files have the same filenames and have been
	// pushed to NGA authoring at the same time or at different times.
	// BS-3021
	@Test(priority = 13)
	public void Verify_NGA_URLs_Are_Unique() {
		SecondContentID = test.ContentView.GetContentIDofAsset();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyNGAPushOperationCompletes();
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.VerifyContentIDPresentOnAssetURL(SecondContentID);
		test.ContentView.customAssert.customAssertFalse(SecondContentID.equals(FirstContentID),
				"[Assertion Failed]::The Content ID For Two Different Assert Are Same.");
	}

	// 10."Verify that following is the format of the URL:
	// https://qa-content.macmillan-learning.com/cms-nga/ContentID/Filename"
	// BS-3021
	@Test(priority = 14)
	public void Verify_The_NGA_URL_Format() {
		test.ContentView.VerifyAssetNGAURLFormat(SecondContentID, AssetURl);
		test.ContentView.ClickX_OnWindow();
	}

	// 11.Verify that user is able to load each URL properly in the browser with
	// intended content.
	// BS-3021
	@Test(priority = 15)
	public void Verify_User_Is_Able_To_Load_Each_URL() {
		test.ContentView.VerifyCopyedURLIsAbleToLoad();
		test.ContentView.changeWindow(0);
		test.ContentView.ClickX_OnWindow();
		test.ContentView.DeleteContentFromCMS();
		test.Contentpage.SearchForAnItem(FirstContentID);
		test.Contentpage.ClickOpenAssertOnContentTab();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyCopyedURLIsAbleToLoad();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.DeleteContentFromCMS();
	}

	// 12.Verify that User is able to Push the DAM assets to NGA Authoring tool and
	// the status successfully gets Completed after the scheduler run (3mins max).
	// BS-3041
	@Test(priority = 16)
	public void Verify_User_Is_Able_To_Push_DAM_Asset_TO_NGA() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.opentheSearchContent(DamContent);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringToolHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyNGAPushOperationCompletes();
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.ClickX_OnWindow();
	}

	// 13.Verify that user is able to copy the URL and each URL loads properly in
	// the browser with intended content.
	// BS-3041
	@Test(priority = 17)
	public void Verify_User_Is_Able_To_Load_URL_Successfully() {
		test.ContentView.VerifyCopyedURLIsAbleToLoad();
	}

	// 14.Verify that Username (Email) of the user who has performed the push action
	// should retain in the 'User' column under 'Authoring Platform Push Details'
	// section once the push status changes to 'Complete'.
	// 15.Verify that Username (Email) of the user who has performed the push action
	// should be retained in the entry in content history table (only for NGA) under
	// Created By column
	// BS-3000
	@Test(priority = 18)
	public void Verify_Email_Is_Displayed_In_User_Coloum() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyUserEmailDisplayedOnAuthoringPlatformPushDetails(AdminEmail);
		test.ContentView.VerifyContentHistoryTableCreatedByUpdated(AdminEmail);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}