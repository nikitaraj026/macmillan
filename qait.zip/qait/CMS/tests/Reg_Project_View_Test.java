package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_View_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, NonAdminEmail, NonAdminPassword;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare,
			PublihDestinationCatalog, ISBN2, DamContent,FrostExportFull,ExportOptionEnhancedPub;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, DownloadStartMsg,
			OrganisedDownloadMsgProjectView,TypesOfContentEnhancedEpub,CMSRepository,TypeOfContentCoverDesign;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		DamContent = getData("DamContent");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DownloadStartMsg = getData("DownloadStartMsg");
		OrganisedDownloadMsgProjectView = getData("OrganisedDownloadMsgProjectView");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypeOfContentCoverDesign =getData("TypesOfContent.Covers>Cover Design");
		CMSRepository=getData("Repository.CMS");
		FrostExportFull=getData("FrostExportType.Full");
		ExportOptionEnhancedPub=getData("FrostExportOptions.Enhanced ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// 1.login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 2.Verify that user is able to navigate to project view page
	@Test(priority = 2)
	public void Verify_User_Able_To_Navigate_To_Project_View() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.ProjectPage.logMessage("User is able to navigate to project view page..");
	}

	// 3.Verify that user is able to navigate to project view page from Home page
	@Test(priority = 3)
	public void Verify_User_Able_To_Navigate_To_Project_View_From_Home_Page() {
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN2);
		test.ProjectPage.SelectNumberFromResultDropDown("100");
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN2);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickOnA_Project();
		test.projectView.verifyOnProjectView();
	}

	// 4.Verify that Project view heading is appearing below the three tabs on the
	// left side of the window
	@Test(priority = 4)
	public void Verify_Project_View_Heading_Is_Appearing() {
		test.projectView.verifyOnProjectView();
	}

	// 5.Verify that on clicking on the home link, user is navigated to Dashboard
	@Test(priority = 5)
	public void Verify_On_Clicking_On_Home_Link_Navigated_To_Dashboard() {
		test.projectView.clickhomeLink();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickDashBord();
		test.HomePage.RemoveProjectFromFavorite(ISBN2);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 6.Verify that the user navigates to the project view page on clicking the
	// project link
	@Test(priority = 6)
	public void Verify_On_Clicking_Project_link_Navigates_To_Project_View() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickProjectLink();
		test.ProjectPage.VerifyOnProjectPage();
	}

	// 7.Verify that below the project folder thumbnail, System Metadata is
	// displayed
	@Test(priority = 7)
	public void Verify_System_Metadata_Is_Displayed() {
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.Verify_System_Metadata();
	}

	// 8."Verify that links are available at the top
	@Test(priority = 8)
	public void Verify_That_Top_Links_Are_Available() {
		test.projectView.VerifyTopLinks();
	}

	// 9.Verify that Publish link is available only when the Project status is
	// Enhanced ePub in QA/ Enhanced ePub for Course Building
	@Test(priority = 9)
	public void Verify_Publish_Link_Apperes_When_Status_Enhanced_EPub_In_QA_Or_Course_Building() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyPublishLinkOnlyDisplayforEnhancedEpubAndCourseBuilding();
	}

	// 10.Verify that user can access the Frost QA site from Project view
	@Test(priority = 10)
	public void Verify_User_Can_Access_The_Frost_QA_Site() {
		test.projectView.ClickGoToFrost();
		test.projectView.VerifyUserIsOnFrostApplication();
		test.projectView.changeWindow(1);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 11.Verify that clicking on the Upload Content link opens the pop-up of upload
	// content
	@Test(priority = 11)
	public void Verify_clicking_Upload_Content_PopUp_Of_Upload_Content() {
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
	}

	// 12.Verify that upload content pop up has Browse button and able to browse the
	// file
	@Test(priority = 12)
	public void Verify_Upload_Content_PopUp_Has_Browse_Button() {
		test.projectView.VerifyBrowseButton();
		test.projectView.SelectFileUsingBrowseButton(ISBN + "_FC.jpg");

	}

	// 13.Verify that upload content pop up have Content type drop down and able to
	// select the type of the content
	@Test(priority = 13)
	public void Verify_Content_Type_Drop_Down_Is_Able_To_Select_Type_Of_Content() {
		test.projectView.VerifyContentTypeSelectTypeOfContent();
	}

	// 14.Verify that various fields are available in upload content pop-up
	@Test(priority = 14)
	public void Verify_Various_Fields_In_Upload_Content_PopUp() {
		test.projectView.VerifyVariousFieldsInUploadContentPopUp();
	}

	// 15.Verify that upload content pop-up have Add/Remove Projects and Upload
	// button
	@Test(priority = 15)
	public void Verify_Upload_Content_PopUp_Have_AddRemove_And_Upload_Button() {
		test.projectView.VerifyAddRemoveAndUploadButton();
	}

	// 16.Verify that user is able to add/remove Subject Keyword Taxonomy from the
	// button present right of the field in the upload content pop-up
	// @Test(priority=16) ######### Functionality Removed ########
	public void Verify_User_Is_Able_To_AddRemove_Subject_Keyword_Taxonomy() {
		test.projectView.ClickAddKeywordTaxonomy();
		test.projectView.RemoveSubjectKeywordTaxonomyFunctionalityandVerify();

	}

	// 17.Verify that user is able to to select Relationship type from the
	// Relationship Type dropdown
	// @Test(priority=17) ######### Functionality Removed ########
	public void Verify_User_Able_To_Select_Relationship_Type_From_Relationship_Dropdown() {
		test.projectView.VerifyUserIsAbleToSelectRelationshipType();
	}

	// 18.Verify that user is able to to select Relationship Target from the
	// Relationship Target dropdown
	// @Test(priority=18) ######### Functionality Removed ########
	public void Verify_User_Able_To_Select_Relationship_Target_From_Relationship_Dropdown() {
		test.projectView.VerifyUserIsAbleToSelectRelationshipTarget();

	}

	// 19.Verify that clicking on the Add/Remove Projects button open the add/remove
	// project pop up
	@Test(priority = 19)
	public void Verify_Clicking_AddRemove_Button_Open_AddRemovePopUp() {
		test.projectView.ClickAddRemoveProject();
		test.projectView.VerifyAddtoProjectpopUp();
	}

	// 20.Verify that Add/remove project pop up has Search field and clear link
	// beside search field
	@Test(priority = 20)
	public void Verify_Project_PopUp_Has_Search_Field_And_Clear_Link() {
		test.projectView.VerifySearchFieldAndClearLinkOnAddRemoveProjectPopUp();
	}

	// 21.Verify that Add/remove project pop up has two pane Available and Selected
	// with the Author , Title, Short Title, isbn information
	@Test(priority = 21)
	public void Verify_AddRemove_PopUp_Has_Available_And_Selected_Pane() {
		test.projectView.VerifyAvailableAndSelectedPane();
	}

	// 22.Verify that Add/remove project pop up has Select , unselect, Done and
	// cancel button
	@Test(priority = 22)
	public void Verify_AddRemove_PopUp_Has_Select_Unselect_Done_And_Cancel_Button() {
		test.projectView.VerifySelectUselectDoneCancelButton();
	}

	// 23.Verify that the project ISBN from which the upload content pop-up has been
	// opened is already selected by default
	@Test(priority = 23)
	public void Verify_Project_From_Which_Upload_Content_Is_opened_Is_Already_Selected() {
		test.projectView.VerifyProjectDisplayedOnSelectedPane(ISBN);
	}

	// 24.Verify that user can search for Projects in the Add / Remove Project
	@Test(priority = 24)
	public void Verify_User_Can_Search_Projects_In_AddRemovePopUp() {
		test.projectView.SearchProjectInAddRemovePopUp(ISBN2);
		test.projectView.VerifyProjectDisplayedOnAvailablePane(ISBN2);
	}

	// 25.Verify in the Add/remove projects pop up that user is able to select
	// project from the Available pane on clicking on the Select button
	@Test(priority = 25)
	public void Verify_User_Can_Select_Project_From_Available_pane_Clicking_Select_Button() {
		test.projectView.MoveProjectFromAvailablePaneToSelectedPane(ISBN2);
	}

	// 26.Verify in the Add/remove projects pop up that user is able to deselect
	// project from the Selected pane on clicking on the unelect button
	@Test(priority = 26)
	public void Verify_User_Is_Able_To_Deselect_Project_From_Selected_Pane() {
		test.projectView.MoveProjectFromSelectedPaneToAvailablePane(ISBN2);
		test.projectView.VerifyProjectDisplayedOnAvailablePane(ISBN2);
	}

	// 27.Verify that Add /remove projects pop up closes on clicking the Done button
	@Test(priority = 27)
	public void Verify_Projects_PopUp_Closes_On_Clicking_Done_Button() {
		test.projectView.ClickSaveButtonOnAddToProject();
		test.projectView.VerifyAddToProjectPopUpNotDisplayed();
	}

	// 28.Verify that clicking on the cancel button pop-up close and changes made
	// are not saved
	@Test(priority = 28)
	public void Verify_Clicking_Cancel_Button_PopUp_Close_AddRemovePopUp() {
		test.projectView.ClickAddRemoveProject();
		test.projectView.VerifyAddtoProjectpopUp();
		test.projectView.SearchProjectInAddRemovePopUp(ISBN2);
		test.projectView.MoveProjectFromAvailablePaneToSelectedPane(ISBN2);
		test.projectView.clickCancelButtonOnAddToProject();
		test.projectView.VerifyChangesNotSavedMsgDisplayed();

	}

	// 29.Verify that entering all valid field in the upload content pop up user is
	// able to upload a content
	@Test(priority = 29)
	public void Verify_Upload_Content_PopUp_Enable_User_To_Upload_Content() {
		test.projectView.ClickUploadOnUploadContentPopUpAndVerifyMsg();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem("Delete test");
		test.Contentpage.SelectContentOnContentTab("Delete test",TypeOfContentCoverDesign);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

	}

	// 30.Verify that user is able to upload Flat Epub and validate the metadata
	// ingested at CMS end, also can associate the Flat epub to the project from the
	// same.
	@Test(priority = 30)
	public void Verify_User_Is_Able_To_Upload_Flat_Epub() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickUploadContent();
		test.projectView.UploadFlatEpubFromProjectView(ISBN2);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 31.Verify that user is successfully able to upload Enhanced Epub and validate
	// the metadata ingested at CMS end
	@Test(priority = 31)
	public void Verify_User_Is_Able_To_Upload_Enhanced_Epub() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickUploadContent();
		test.projectView.UploadEnhancedEpubFromProjectView(ISBN2);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 32.Verify that user is successfully able to upload Covers>Cover Design
	// content type and validate the metadata ingested at CMS end
	@Test(priority = 32)
	public void Verify_User_Is_Able_To_Upload_CoversCoverDesign() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickUploadContent();
		test.projectView.UploadCoversCoverDesignFromProjectView(ISBN);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 33.Verify that user is successfully able to upload XHTML file and validate
	// the metadata ingested at CMS end
	@Test(priority = 33)
	public void Verify_User_Is_Able_To_Upload_XHTML() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickUploadContent();
		test.projectView.UploadXHTMLContentFromProjectView();
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 34.Verify that user is successfully able to upload CFI file and validate the
	// metadata ingested at CMS end
	@Test(priority = 34)
	public void Verify_User_Is_Able_To_Upload_CFI() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickUploadContent();
		test.projectView.UploadCFIContentFromProjectView(ISBN2);
		test.ContentView.VerifySystemMetadataAreDisplayed();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// 35."Verify that more drop down has following dropdown list:View Usage
	// DetailsPush to Authoring tool Organized Download"
	@Test(priority = 35)
	public void Verify_More_Drop_Down_Options() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.VerifyTopLinks();
	}

	// 36.Verify that clicking on the view Usage Details options in the more drop
	// down opens the Asset Association pop up
	@Test(priority = 36)
	public void Verify_Clicking_View_Usage_Details_Asset_Association_PopUp_Opens() {
		test.refreshPage();
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyViewUsageDetailPopUpDisplay();
	}

	// 37.Verify that Asset Association pop up has that search field and clear all
	// link at top
	@Test(priority = 37)
	public void Verify_Asset_Association_PopUp_Has_Search_Field_And_Clear_All_Link() {
		test.projectView.verifySearchFieldAndClearAllOnUsageDetailPopUp();
	}

	// 38."Verify that Asset Association pop up has following details in the form of
	// the table:1. Asset Name2. Asset Type3. Last Modified4. Modified By 5. File
	// Size6. Repository"
	@Test(priority = 38)
	public void Verify_Information_On_Usage_Details_PopUp() {
		test.projectView.VerifyInformationOnUsageDetail();
	}

	int Count = 0;

	// 39.Verify that clicking on the Organized Download option in the more drop
	// down that Organized Download pop up is opened
	@Test(priority = 39)
	public void Clicking_Organized_Download_On_More_DropDown_Popup_Opens() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		Count = test.projectView.GetCountOfNumberOfAssetAssociatedToProject();
		test.projectView.clickTopLinkMore();
		test.projectView.clickOrganisedDownload();
		test.projectView.VerifyOrganizedDownloadPopUp();
	}

	// 40.Verify that Organized Download heading is appearing on the Organized
	// Download Pop up
	@Test(priority = 40)
	public void Verify_Organized_Download_Heading() {
		test.projectView.VerifyOrganizedDownloadPopUp();
	}

	// 41."Verify that the Organized Download pop up specify the folder structure in
	// the three categories :Top level folder 1st subfolder 2nd sub-folder"
	@Test(priority = 41)
	public void Verify_Three_Categories_Folder_Structure() {
		test.projectView.OrganisedDownloadInThreeLevelStructure("ISBN", "Repository", "Content Type");
	}

	// 42."Verify that the Organized Download pop up has the folder structure with
	// one of the following option:ISBN Content Type Repository"
	@Test(priority = 42)
	public void Verify_Three_Categories_Folder_Structure_ISBN_Repo_ContentType() {
		test.projectView.OrganisedDownloadInThreeLevelStructure("ISBN", "Repository", "Content Type");
	}

	// 43.Verify that the Organized Download pop up has the Finish and cancel button
	@Test(priority = 43)
	public void Verify_Organised_Download_Has_Finish_And_Cancel_Button() {
		test.projectView.verifyFinishAndCancelButtonAreDisplayed();
	}

	// 44.Verify that clicking on the Finish button in the Organized Download pop
	// up, tpoaster message is displayed
	@Test(priority = 44)
	public void Verify_Toster_Message_Is_Displayed_In_The_Organized_Download() {
		test.projectView.selectAllInOrganizedDownload();
		test.projectView.clickFinishButtonOnOrganizedDownload();
		test.projectView.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsgProjectView, Count);
	}

	// 45.Verify that clicking on the Cancel button on the Organized Download pop up
	// closes the pop up
	@Test(priority = 45)
	public void Verify_On_Clicking_Cancel_Button_The_Organized_Download_PopUp_Closes() {
		test.refreshPage();
		test.projectView.clickTopLinkMore();
		test.projectView.clickOrganisedDownload();
		test.projectView.VerifyOrganizedDownloadPopUp();
		test.projectView.clickCancelButtonOnOrganizedDownload();
		test.projectView.VerifyOrganizedDownloadPopUpClosed();
	}

	// 46.Verify that Project Status drop down with 4 status
	@Test(priority = 46)
	public void Verify_Project_Status_Drop_Down_Has_4_Status() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickWorkFlowStatus();
		test.projectView.GetAllWorkFlowStatus();
	}

	// 47.Verify that changing the project Status to Ready For Enhancements
	// Activates the Push to Authoring Tool link under the More drop down
	@Test(priority = 47)
	public void Verify_Changing_Project_Status_To_Ready_For_Enhancements_Activates_Push_To_Authoring_Tool() {
		test.refreshPage();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.VerifyPushToAuthoringToolIsEnabledOnlyForReadyForEnhancements();
	}

	// 48.Verify that clicking on the Push to Authoring Tool link pop up open with
	// three sub categories
	@Test(priority = 48)
	public void Verify_Clicking_Push_To_Authoring_Tool_Opens_PopUp_With_Three_Sub_Categories() {
		test.refreshPage();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifySubCategoriesInPushToAuthoringTool();
	}

	// 49.Verify that user is to able to select the Authoring platform as Frost from
	// the drop down
	@Test(priority = 49)
	public void Verify_User_Is_Able_To_Select_Authoring_Platform() {
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
	}

	// 50."Verify that user is able to select Assets type from the one of the
	// option: Epubs only Other Assets "
	@Test(priority = 50)
	public void Verify_User_Is_Able_To_Select_Assets_Type_Epubs_Or_Other_Assets() {
		test.projectView.VerifyEpubsAndOtherAssetsOnPushToAuthoringTool();
	}

	// 51.Verify that Push to Authoring Tool pop has view button(to change view grid
	// or list ) in the Step 2 Select Assets section
	@Test(priority = 51)
	public void Verify_View_On_Button_Selected_Assets_Section() {
		test.projectView.VerifyGridView();
		test.projectView.VerifyListView();
	}

	// 52.Verify that Push to Authoring Tool pop has Search field in the Step 2
	// Select Assets section
	@Test(priority = 52)
	public void Verify_Push_To_Authoring_Tool_Has_Search_Field_Step_2() {
		test.projectView.VerifySearchBarOnStep2pushToAuthoringTool();
	}

	// 53.Verify that Push to Authoring Tool pop has Epub thumbnail in the Step 2
	// Select Assets section with details
	@Test(priority = 53)
	public void Verify_Push_To_Authoring_Tool_PopUp_Has_Epub_Thumbnail_In_Step2() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyGridView();
	}

	// 54.Verify that Push to Authoring Tool pop has Search field in the Step 3
	// Select new Project ISBN section
	@Test(priority = 54)
	public void Verify_Push_To_Authoring_Tool_Has_Search_Field_Step_3() {
		test.projectView.VerifySearchBarOnStep3pushToAuthoringTool();
	}

	// 55.Verify that Push to Authoring Tool pop-up has help icon beside the heading
	// Select new Project ISBN
	@Test(priority = 55)
	public void Verify_Push_To_Authoring_Tool_Has_Help_Icon_Which_Display_Info() {
		test.projectView.VerifyInfoIsDisplayedOnClickingHelpIcon();
	}

	// 56.Verify that Searched Isbn in search field are displayed in the table
	// present in the Step 3 Select Project ISBN section
	@Test(priority = 56)
	public void Verify_ISBN_Searched_In_Search_Field_Are_Displayed_In_Step3() {
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ISBN);
		test.projectView.VerifyProjectIsDisplayedOnAuthoringTool(ISBN);
	}

	// 57."Verify that project appear in Step 3 Select new Project ISBN is displayed
	// the table with following details: 1. Author 2. Title 3. Short Title 4. ISBN"
	@Test(priority = 57)
	public void Verify_Following_Info_Of_Project_Is_Displayed() {
		test.projectView.VerifyColoumOfProject();
	}

	// 58.Verify that selecting all valid field in the Push to Authoring Tool pop up
	// user is able to push content to Frost platform
	@Test(priority = 58)
	public void Verify_User_Is_Able_To_Push_Content_To_Frost() {
		test.refreshPage();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(ISBN, ISBN);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(ISBN);
	}

	// 59.Verify that Push to Authoring pop has the push and cancel button
	@Test(priority = 59)
	public void Verify_Push_To_Authoring_PopUp_Has_Push_And_Cancel_Button() {
		test.refreshPage();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.Verify_Cancel_And_Push_OnPushToAuthoringPopUp();
	}

	// 60.Verify that clicking on the cancel button closes the pop up
	@Test(priority = 60)
	public void Verify_Clicking_Cancel_Button_Authoring_Tool_PopUp_Closes() {
		test.projectView.ClickCancelOnAuthoringTool();
		test.projectView.VerifyAuthoringToolClosed();
	}

	// 61.Verify that after filling all the fields in the Push to Authoring Tool pop
	// up and clicking on the push button all content is pushed to Frost
	@Test(priority = 61)
	public void Verify_Pushed_Content_Is_Added_To_Frost() {
		test.refreshPage();
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ISBN, FrostCreatedProjectName);
		test.projectView.DeleteProjectFromFrost(FrostCreatedProjectName);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(ISBN, ISBN);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(ISBN);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.ClickGoToFrost();
		test.ContentView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ISBN, FrostCreatedProjectName);
		test.projectView.DeleteProjectFromFrost(FrostCreatedProjectName);
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 62.Verify that project status change to Enhanced ePub Ingested when user push
	// back content from the Frost
	@Test(priority = 62)
	public void Verify_Project_Status_Change_To_Enhanced_EPub_Ingested_When_Content_Push_Back_From_Frost() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(FrostMainProject, FrostIsbnToEnter);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, getData("FrostProject.ProjectNameToEnter"));
		test.projectView.OpenProjectOnFrost(getData("FrostProject.ProjectNameToEnter"));
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.LogoutFromFrost();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.VerifyCFIAndEnhancedEpubArePushed(FrostIsbnToEnter);
		test.projectView.ClickOpenAssetOnProjectView(FrostIsbnToEnter+".epub",TypesOfContentEnhancedEpub);
		test.projectView.VerifyWorkFlowStatus();
		test.ContentView.DeleteContentFromCMS();
	}

	// Delete Project From Frost
	@Test(priority = 63)
	public void Delete_Project_From_Frost() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.ClickGoToFrost();
		test.ContentView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, getData("FrostProject.ProjectNameToEnter"));
		test.projectView.DeleteProjectFromFrost(getData("FrostProject.ProjectNameToEnter"));
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 63.Verify that after changing the status to the Enhanced ePub in QA /
	// Enhanced ePub for Course Building the Publish button is activated
	@Test(priority = 64)
	public void Verify_Changing_The_Status_To_Enhanced_EPub_In_QA_Or_Enhanced_EPub_For_Course_Building_Activate_Publish_Button() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.VerifyPublishLinkOnlyDisplayforEnhancedEpubAndCourseBuilding();
	}

	// 64.Verify that clicking on the publish link Publish pop up opens
	@Test(priority = 65)
	public void Verify_Clicking_Publish_Link_Opens_Publish_PopUp() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
	}

	// 65.Verify that publish pop up has Publish as heading with ISBN of the project
	@Test(priority = 66)
	public void Verify_Publish_PopUp_heading_Has_ISBN_Of_Project() {
		test.projectView.VerifyTitleOfProjectIsDisplayedOnPublishPopUp(ISBN);
	}

	// 66."Verify that destination drop down has following option in the publish pop
	// up: 1. Core Source 2. Catalog 3. Palgrave"
	@Test(priority = 67)
	public void Verify_Destination_Drop_Down_Has_Core_Source_Catalog_Palgrave() {
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
	}

	// 67."Verify that if the Destination is selected as course source than the
	// other Step 2 Select AssetsStep 3 Publish Assets will appear"
	@Test(priority = 68)
	public void Verify_If_Destination_Is_Selected_As_CourseSource_Two_Section_Is_Displayed() {
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyStep1AndStep2SectionAreDisplayed();
	}

	// 68.Verify that CFI link options are available if CoreSource option is
	// selected as destination Drop down in publish drop down
	@Test(priority = 69)
	public void Verify_That_CFI_Link_Options_Are_Available_If_CoreSource_Selected_As_Destination() {
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyToolTips();
	}

	// 69.Verify that if the Destination is selected as catalog than the no other
	// category(Step 2, Step 3) is displayed
	// @Test(priority=70) ///// Catalog Functionality Removed.....
	public void Verify_Step2_Step3_Category_Not_Displayed_If_Destination_Is_Catalog() {
		test.projectView.selectDestinationOfPublish(PublihDestinationCatalog);
		test.projectView.VerifyStep1AndStep2SectionAreNotDisplayed();
	}

	// 70.Verify that user is able to select the Assets which want to publish
	@Test(priority = 71)
	public void Verify_User_Is_Able_To_Select_Assets_publish() {
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository,TypesOfContentEnhancedEpub,ISBN+".epub",true);
	}

	// 71.Verify that Selected Assets in step 2 is displayed in Step 3 publish
	// Assets
	@Test(priority = 72)
	public void Verify_Selected_Assets_In_Step2_Is_Displayed_In_Step3() {
		test.projectView.VerifySeletedAssertIsDisplayedInStep3(ISBN);
	}

	// 72.Verify that publish Asset categories in the publish pop up has Approve and
	// Approve button
	@Test(priority = 73)
	public void Verify_Publish_popUp_Has_Approve_And_Approve_Button() {
		test.projectView.VerifyPublishAssetsHasApproveAndApproveButton();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}