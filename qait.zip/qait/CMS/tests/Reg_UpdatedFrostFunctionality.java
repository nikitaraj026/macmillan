package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_UpdatedFrostFunctionality extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String ProjectISBN, ProjectTitle, FrostEmail, FrostPassword, ProjectISBN1,TypesOfContentEnhancedEpub,ExportOptionEnhancedPub;
	String FrostLink, ProjectTitle1, FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName,ContentTypeCFI,FrostExportFull;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ProjectISBN = getData("ProjectISBNNo2");
		ProjectTitle = getData("ProjectTitle2");
		ProjectISBN1 = getData("ProjectISBNNo1");
		ProjectTitle1 = getData("ProjectTitle1");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		FrostLink = getData("Link.Frost");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		ContentTypeCFI = getData("TypesOfContent.Project Support Materials>CFI");
		FrostExportFull=getData("FrostExportType.Full");
		ExportOptionEnhancedPub=getData("FrostExportOptions.Enhanced ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that ePub file sent as an additional content to the Project which is
	// already present in Frost retains its File Name and displays the same under
	// Additional Content section (i.e. File Name is displayed instead of base ISBN)
	// when Pushed via Project view window : Retain CSS
	// BS-2106
	@Test(priority = 2)
	public void Verify_Additional_Epub_Send_To_Frost_Displayed_For_RetainCSS_Option() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectRetainCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ProjectISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(ProjectISBN);
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN, ProjectTitle);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.projectView.verifyOnProjectView();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectRetainCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN1 + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN1 + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ProjectISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(ProjectISBN);
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.logMessage("Waiting for " + ProjectTitle + "_EPUB to be created at frost end....");
		test.projectView.hardWait(130); /// waiting for File To be Created at Frost.

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN, ProjectTitle);
		test.projectView.OpenProjectOnFrost(ProjectTitle);
		test.projectView.verifyAdditionalFileInFrost(ProjectTitle);

	}

	// Delete Project From Frost
	@Test(priority = 3)
	public void Delete_Project_From_Frost() {
		test.projectView.changeWindow(1);
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN, ProjectTitle);
		test.projectView.DeleteProjectFromFrost(ProjectTitle);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 2.Verify that ePub file sent as an additional content to the Project which is
	// already present in Frost retains its File Name and displays the same under
	// Additional Content section (i.e. File Name is displayed instead of base ISBN)
	// when Pushed via Project view window : Clear CSS
	// BS-2106
	@Test(priority = 4)
	public void Verify_Additional_Epub_Send_To_Frost_Displayed_For_ClearCSS_Option() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectClearCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ProjectISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(ProjectISBN);
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN, ProjectTitle);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.projectView.verifyOnProjectView();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectClearCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN1 + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN1 + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(ProjectISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(ProjectISBN);
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.logMessage("Waiting for " + ProjectTitle + " to be created at frost end....");
		test.projectView.hardWait(130); // waiting for File To be Created at Frost.

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN, ProjectTitle);
		test.projectView.OpenProjectOnFrost(ProjectTitle);
		test.projectView.verifyAdditionalFileInFrost(ProjectTitle);

	}

	// Delete Project From Frost
	@Test(priority = 5)
	public void Delete_Project_From_Frost1() {
		test.projectView.changeWindow(1);
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN, ProjectTitle);
		test.projectView.DeleteProjectFromFrost(ProjectTitle);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// Logout of the CMS Application
	@Test(priority = 6)
	public void Login_Into_Application() {
		test.HomePage.changeWindow(0);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 3.Verify that ePub file sent as an additional content to the Project which is
	// already present in Frost retains its File Name and displays the same under
	// Additional Content section (i.e. File Name is displayed instead of base ISBN)
	// when Pushed via Content view window Retain CSS
	// BS-2106
	@Test(priority = 7)
	public void Verify_Additional_Epub_Send_To_Frost_Displayed_For_RetainCSS_Option_From_Content_View() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ProjectISBN1 + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ProjectISBN1 + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectCSSOption("retainCss");
		test.ContentView.SearchProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.SelectProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.ClickPushOnAuthoringTool();

		test.ContentView.OpenNewTabOntheCurrentWindow();
		test.ContentView.changeWindow(1);
		test.launchApplication(FrostLink);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN1, ProjectTitle1);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.ContentView.VerifyOnContentViewPage();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ProjectISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ProjectISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectCSSOption("retainCss");
		test.ContentView.SearchProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.SelectProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.ClickPushOnAuthoringTool();

		test.projectView.logMessage("Waiting for " + ProjectTitle1 + " to be created at frost end....");
		test.projectView.hardWait(130); /// waiting for File To be Created at Frost.
		test.ContentView.OpenNewTabOntheCurrentWindow();
		test.ContentView.changeWindow(1);
		test.launchApplication(FrostLink);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN1, ProjectTitle1);
		test.projectView.OpenProjectOnFrost(ProjectTitle1);
		test.projectView.verifyAdditionalFileInFrost(ProjectTitle1);
	}

	// Delete Project From Frost
	@Test(priority = 8)
	public void Delete_Project_From_Frost2() {
		test.projectView.changeWindow(1);
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN1, ProjectTitle1);
		test.projectView.DeleteProjectFromFrost(ProjectTitle1);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 4.Verify that ePub file sent as an additional content to the Project which is
	// already present in Frost retains its File Name and displays the same under
	// Additional Content section (i.e. File Name is displayed instead of base ISBN)
	// when Pushed via Content view window Clear CSS
	// BS-2106
	@Test(priority = 9)
	public void Verify_Additional_Epub_Send_To_Frost_Displayed_For_ClearCSS_Option_From_Content_View() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ProjectISBN1 + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ProjectISBN1 + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectCSSOption("clearCss");
		test.ContentView.SearchProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.SelectProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.ClickPushOnAuthoringTool();

		test.ContentView.OpenNewTabOntheCurrentWindow();
		test.ContentView.changeWindow(1);
		test.launchApplication(FrostLink);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN1, ProjectTitle1);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.ContentView.VerifyOnContentViewPage();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ProjectISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ProjectISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectCSSOption("clearCss");
		test.ContentView.SearchProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.SelectProjectOnAuthoringTool(ProjectISBN1);
		test.ContentView.ClickPushOnAuthoringTool();

		test.projectView.logMessage("Waiting for " + ProjectTitle1 + " to be created at frost end....");
		test.projectView.hardWait(130); /// waiting for File To be Created at Frost.
		test.ContentView.OpenNewTabOntheCurrentWindow();
		test.ContentView.changeWindow(1);
		test.launchApplication(FrostLink);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN1, ProjectTitle1);
		test.projectView.OpenProjectOnFrost(ProjectTitle1);
		test.projectView.verifyAdditionalFileInFrost(ProjectTitle1);
	}

	// Delete Project From Frost
	@Test(priority = 10)
	public void Delete_Project_From_Frost3() {
		test.projectView.changeWindow(1);
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(ProjectISBN1, ProjectTitle1);
		test.projectView.DeleteProjectFromFrost(ProjectTitle1);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 5.Verify that Project(s) are getting created at Frost QA end for the ISBN
	// which is used in Step 3 of Push to Authoring tool window.
	// BS-2801
	@Test(priority = 11)
	public void Verify_User_Is_Able_To_Push_Content_To_Frost() {
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(FrostMainProject, FrostIsbnToEnter);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, getData("FrostProject.ProjectNameToEnter"));
	}

	// 6.Verify that Pushed back files are getting associated to the ISBNs as it
	// should.
	// BS-2801
	@Test(priority = 12)
	public void Verify_Pushed_Back_Files_Are_Getting_Associated_To_ISBN() {
		test.projectView.changeWindow(1);
		test.projectView.OpenProjectOnFrost(getData("FrostProject.ProjectNameToEnter"));
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.changeWindow(0);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.VerifyCFIAndEnhancedEpubArePushed(FrostIsbnToEnter);
		test.projectView.ClickOpenAssetOnProjectView(FrostIsbnToEnter+".epub",TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
		test.ContentView.navigateBack();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(FrostIsbnToEnter+"_CFI.csv",ContentTypeCFI);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}

	// Delete Project From Frost
	@Test(priority = 13)
	public void Delete_Project_From_Frost4() {
		test.projectView.changeWindow(1);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, getData("FrostProject.ProjectNameToEnter"));
		test.projectView.DeleteProjectFromFrost(getData("FrostProject.ProjectNameToEnter"));
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}