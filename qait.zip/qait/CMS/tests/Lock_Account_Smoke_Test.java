package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Lock_Account_Smoke_Test extends Parent_Test{
	CMSTestInitiator test;
	String baseURL;
	String AdminEmail,AdminPassword,NonAdminEmail,NonAdminPassword;
	String homePageLink,PassResetEmail,invalidemail,invalidpassword,logInErrorMsg,passwordResetMessage,LockMessage;
	
	private void initVars() 
	{
		baseURL = getData("baseUrl");
		AdminEmail=getData("Admin.email");
		AdminPassword=getData("Admin.password");
		NonAdminEmail=getData("NonAdmin.email");
		NonAdminPassword=getData("NonAdmin.password");
		homePageLink=getData("Link.HomePageLink");
		invalidemail=getData("Invalidcredentials.email");
		invalidpassword=getData("Invalidcredentials.password");
		logInErrorMsg=getData("LogInError");
		passwordResetMessage=getData("passwordResetMessage");
		LockMessage=getData("LockMessage");
		PassResetEmail=getData("PasswordResetAccount.email");
	}
	
	
	@BeforeSuite
    @Parameters({ "suiteType", "productID", "suiteID" })
    public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID, @Optional("0") String suiteID) {
        beforeSuiteMethod(suiteType, productID, suiteID);
    }

    @BeforeClass
    public void start_test_Session() {
        test = new CMSTestInitiator();
        initVars();
        test.launchApplication(baseURL);
    }

    @BeforeMethod
    public void handleTestMethodName(Method method) {
        test.stepStartMessage(method.getName());
    }
  
    
    public void logoutFromApplication() {
    	test.HomePage.LogoutFromApplication();
    }
    
    //Verify that A/c lock message appears at the top of the login panel if user makes 6 incorrect login attempts
    @Test
    public void Verify_Account_Lock_Message_Appears_After_6_Incorrect_Login_Attempts(){
    test.loginpage.verifyEmailTextBoxDislayed();
	test.loginpage.verifyPasswordTextBoxDisplayed();
	test.loginpage.verifyLogInButtonDisplayed();
	test.loginpage.VerifyAccountGetsLocked(NonAdminEmail,invalidpassword,LockMessage);
    }
    
    
    
    
    @AfterMethod
	public void onFailure(ITestResult result)
	{
		afterMethod(test, result, this.getClass().getName()); 
		logoutFromApplication();
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
