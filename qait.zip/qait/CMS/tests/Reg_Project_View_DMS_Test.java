package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_View_DMS_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, NonAdminEmail, NonAdminPassword,
			PublihDestinationVitalSource;
	String  PublihDestinationPalgrave, PublihDestinationCourseWare,
			PublihDestinationCatalog, PublihDestinationInstructorStore, ISBN2, DamContent;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, DownloadStartMsg,
			ISBNwithoutEnhancedEpub;
	String OrganisedDownloadMsg, LOMacmillanCalculus, LoPrinciplesOfEconomics, LoPrinciplesOfMacroeconomics,
			PrinciplesOfMicroeconomics;
	String TypesOfContentEnhancedEpub, TypesOfContentFlatEpub, TypesOfContentBatchEnhanced, TypesOfContentBatchFlat,
			TypesOfContentCoverDesign;
	String TypeOfContentMarketingAuthorImage, MarketingAuthorImage, DMS_Email, DMS_Password, DMSPublishErrorProjectView;
	String DMSPublishErrorContentView, AuthorId, ISBN3, ISBN4, ISBN5, InstructorStoreNoISBN;
	String selectAllPages;
	String Character80 = "Automation Edited Title (Delete the File) Automation Edited Title (Delete File)";
	String CMSRepository;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ISBN2 = getData("ProjectISBNNo1");
		ISBNwithoutEnhancedEpub = getData("ProjectWithoutEnhanceEpub");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationCatalog = getData("PublishDestination.Catalog");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		DamContent = getData("DamContent");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DownloadStartMsg = getData("DownloadStartMsg");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsgProjectView");
		LOMacmillanCalculus = getData("Framework.macmillan calculus");
		LoPrinciplesOfEconomics = getData("Framework.Principles of Economics");
		LoPrinciplesOfMacroeconomics = getData("Framework.Principles of Macroeconomics");
		PrinciplesOfMicroeconomics = getData("Framework.Principles of Microeconomics");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentBatchEnhanced = getData("TypesOfContent.Flat ePub > Batch");
		TypesOfContentBatchFlat = getData("TypesOfContent.Enhanced ePub > Batch");
		TypesOfContentCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		TypeOfContentMarketingAuthorImage = getData("TypesOfContent.Marketing Content>Author Image");
		MarketingAuthorImage = getData("MarketingAuthorImage");
		DMS_Email = getData("DMSUser.email");
		DMS_Password = getData("DMSUser.password");
		DMSPublishErrorProjectView = getData("DMSPublishErrorProjectView");
		DMSPublishErrorContentView = getData("DMSPublishErrorContentView");
		ISBN3 = getData("ProjectISBNNo2");
		ISBN4 = getData("ProjectISBNNo5");
		ISBN5 = getData("ProjectISBNNo4");
		InstructorStoreNoISBN = getData("InstructorStoreNoISBN");
		AuthorId = getData("Author.id");
		selectAllPages = getData("PageSelection.All Pages");
		CMSRepository = getData("Repository.CMS");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(DMS_Email);
		test.loginpage.enterUserPassword(DMS_Password);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that error message appears when DMS user tries to publish ANY
	// asset to ANY destination from Project view
	// BS-2562
	@Test(priority = 2)
	public void Verify_DMS_User_Not_Able_To_Publish_Any_Asset_From_Project_View() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentEnhancedEpub,
				ISBN + ".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorProjectView);
		test.projectView.ClickCloseButton();
		test.projectView.ClickCloseButton();
	}

	// 2.Verify that error message appears when DMS user tries to publish an
	// asset of ANY content type except Marketing Content>Author Image from
	// Content page view
	// BS-2562
	@Test(priority = 3)
	public void Verify_DMS_User_Is_Not_Able_To_Publish_Any_Non_Marketing_Content_From_Content_View() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorContentView);

		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyPublishWasUnsuccessful_DMS_User(DMSPublishErrorContentView);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
	}

	// 3.Verify that DMS user is successfully able to publish the asset of
	// Marketing Content>Author Image content type from Content page view to any
	// destination
	// BS-2562
	@Test(priority = 4)
	public void Verify_DMS_User_Successfully_Able_To_Publish_Marketing_Content_To_Any_Destination_From_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(MarketingAuthorImage);
		test.Contentpage.opentheSearchContent(MarketingAuthorImage);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 4.Verify that error message is displayed if user hits the Publish button
	// without approving the asset
	// BS-2562
	@Test(priority = 5)
	public void Verify_Error_Message_Displayed_For_Publishing_Unapprove_Asset() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsNotPublished();
	}

	// 5.Verify that default ISBN is already displayed as selected in Step 1 of
	// Publish window
	// BS-2634
	@Test(priority = 6)
	public void Verify_Default_ISBN_Is_Selected_For_IS_In_Publish_Window() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
	}

	// 6.Verify that user is able to add multiple ISBNs when the Instructor
	// Store is selected as the Publish destination
	// BS-2634
	@Test(priority = 7)
	public void Verify_User_Is_Able_To_Add_Multiple_ISBNs_When_Instructor_Store_Is_Selected() {
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN2);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN2);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2);

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN3);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN3);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN3);

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN4);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN4);
		test.projectView.ClickADDButton_IS();
		test.projectView.NavigateToPageNumberInPublishWindow_IS("2");
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN4);

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN5);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN5);
		test.projectView.ClickADDButton_IS();
		test.projectView.NavigateToPageNumberInPublishWindow_IS("2");
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN5);

	}

	// 7.Verify that Delete icon is getting displayed to the right under Action
	// column for all the ISBNs added in Step 1
	// BS-2634
	@Test(priority = 8)
	public void Verify_Delete_Icon_Is_Getting_Displayed_For_ISBNs() {
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyAllDeleteButtonsIn_IS_Publish();
		test.projectView.NavigateToPageNumberInPublishWindow_IS("2");
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyAllDeleteButtonsIn_IS_Publish();
	}

	// 8.Verify that User is able to delete any ISBN by clicking Delete icon to
	// the right of it
	// BS-2634
	@Test(priority = 9)
	public void Verify_User_Able_To_Delete_ISBN_By_Clicking_Delete() {
		test.projectView.NavigateToPageNumberInPublishWindow_IS("1");
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN);

		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN2);
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN2);
	}

	// 9.Verify that user is able to add again the ISBNs deleted (default or
	// additional)
	// BS-2634
	@Test(priority = 10)
	public void Verify_User_Is_Able_To_Add_Deleted_ISBN() {

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.projectView.ClickADDButton_IS();

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN2);
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN2);
		test.projectView.ClickADDButton_IS();

		test.projectView.NavigateToPageNumberInPublishWindow_IS("2");
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2);

	}

	// 10.Verify that if there are no ISBNs selected in Step 1, then Publish
	// button will be grayed out
	// BS-2634
	@Test(priority = 11)
	public void Verify_Publish_Button_Is_Grayed_Out_If_No_ISBNs_Selected_In_Step1() {
		test.projectView.NavigateToPageNumberInPublishWindow_IS("1");
		test.projectView.DeleteAllISBN_IS_PublishWindow();
		test.projectView.DeleteAllISBN_IS_PublishWindow();
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.VerifyPublishButtonOnPublishPopUpDisabled();
	}

	// 11."Verify that following message is getting displayed when no ISBN has
	// been selected in Step 1:
	// There are no ISBNs selected to Publish"
	// BS-2634
	@Test(priority = 12)
	public void Verify_Correct_Message_Displayed_When_No_ISBN_Is_Selected_In_IS_PublishWindow() {
		test.projectView.VerifyErrorMessageOnBottomOfPublishWindow(InstructorStoreNoISBN);
		test.projectView.clickRepositoryOnStep2OfPublishWindow(); /// To remove
																	/// the Repo
																	/// check on
																	/// Publish
																	/// Window.
	}

	// 12.Verify that appropriate success message is getting displayed after
	// clicking Publish button
	// BS-2634
	@Test(priority = 13)
	public void Verify_Appropriate_Success_Message_After_Clicking_Publish_Button() {
		/*
		 * test.projectView.NavigateToPageNumberInPublishWindow_IS("2");
		 * test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN);
		 */
		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN2); // Main ISBN
																	// Removed
																	// in
																	// 'Verify_Publish_Button_Is_Grayed_Out_If_No_ISBNs_Selected_In_Step1'
																	// Adding
																	// second
																	// ISBN
		test.projectView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN2);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingAuthorImage,
				MarketingAuthorImage,true);
		test.projectView.Select_Assert_Displayed_In_Step3(AuthorId);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 13.Verify that Publish history table of the main ISBN will still show an
	// entry for the publish operation, even if the main ISBN has been removed
	// from the list.
	// BS-2634
	@Test(priority = 14)
	public void Verify_Entry_For_Publish_Operation_Displayed_For_Removed_Main_ISBN() {
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationInstructorStore);
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNIs_Not_DisplayedInPublish_Detail_Publish_ProjectPopUp(ISBN);
	}

	// 14."A) Project View Verify that Publish table for Project view is
	// displaying with following column headers:
	// 1) User
	// 2) Destination
	// 3) File Name/s / ISBNs
	// 4) Published Date
	// 5) Publish Status"
	// BS-2478
	@Test(priority = 15)
	public void Verify_Column_Headers_For_Publish_Table_For_ProjectView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN2 + "_FC.jpg");
		test.Contentpage.SelectContentOnContentTab(ISBN2 + "_FC.jpg",TypesOfContentCoverDesign);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN2);
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyHeaderOfPublishTab();
	}

	// 15."A) Project View Verify that when single asset is published to default
	// project ISBN, then File name along with Published Project ISBNs link is
	// displayed"
	// BS-2478
	@Test(priority = 16)
	public void Verify_File_Name_With_Published_Project_ISBNs_Link_When_Single_Asset_Published_To_Default_ISBN() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.ClickPublishDetail();
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_EPUB.epub");
		test.projectView.ClickCloseButton();
		test.projectView.Verify_PublishedProjectISBN_LinkIsDisplayed();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN2);
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.ClickCloseButton();
	}

	// 16."A) Project View Verify that when single asset is published to
	// additional project ISBN (single) and no default ISBN , then File name
	// along with Published Project ISBNs link is displayed""
	// BS-2478
	@Test(priority = 17)
	public void Verify_File_Name_With_Published_Project_ISBNs_When_Asset_Is_Publish_WithOut_Default_ISBN() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2);
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN2); // Removing
																	// Default
																	// ISBN..
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN2);

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN); // Adding ISBN
																	// Other
																	// than
																	// Default
																	// ISBN
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);

		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.ClickPublishDetail();
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_EPUB.epub");
		test.projectView.ClickCloseButton();
		test.projectView.Verify_PublishedProjectISBN_LinkIsDisplayed();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.ClickCloseButton();
	}

	// 17."A) Project View Verify that when multiple assets are published to
	// default project ISBN, then 'Files' link along with Published Project
	// ISBNs link is displayed"
	// BS-2478
	@Test(priority = 18)
	public void Verify_Files_And_Published_Project_ISBNs_Link_When_Multiple_Assets_Are_Published_To_Default_Project_ISBN() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentCoverDesign,
				ISBN2 + "_FC.jpg",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(selectAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.ClickPublishDetail();
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_FC.jpg");
		test.projectView.ClickCloseButton();

		test.projectView.Verify_PublishedProjectISBN_LinkIsDisplayed();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN2);
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.ClickCloseButton();
	}

	// 18."A) Project View Verify that when multiple assets are published to
	// different project ISBN, then 'Files' link along with Published Project
	// ISBNs link is displayed""
	// BS-2478
	@Test(priority = 19)
	public void Verify_Files_And_Published_Project_ISBNs_Link_When_Multiple_Assets_Are_Published_To_different_Project_ISBN() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2); // Verifing
																	// Default
																	// ISBN is
																	// Displayed..
		test.projectView.DeleteISBN_From_IS_PublishWindow(ISBN2); // Removing
																	// Default
																	// ISBN..
		test.projectView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN2);

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN); // Adding ISBN
																	// Other
																	// than
																	// Default
																	// ISBN
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);

		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentCoverDesign,
				ISBN2 + "_FC.jpg",true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(selectAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.ClickPublishDetail();
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_FC.jpg");
		test.projectView.ClickCloseButton();

		test.projectView.Verify_PublishedProjectISBN_LinkIsDisplayed();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(1);
		test.projectView.ClickCloseButton();
	}

	// 19."A) Project View Verify that when multiple assets are published to
	// muliple project ISBNs, then 'Files' link along with Published Project
	// ISBNs link is displayed"
	// BS-2478
	@Test(priority = 20)
	public void Verify_Files_And_Published_Project_ISBNs_Link_When_Multiple_Assets_Are_Published_To_muliple_Project_ISBN() {
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN2); // Verifing
																	// Default
																	// ISBN is
																	// Displayed..

		test.projectView.SearchForISBNIn_IS_Publish_Window(ISBN); // Adding ISBN
																	// Other
																	// than
																	// Default
																	// ISBN
		test.projectView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.projectView.ClickADDButton_IS();
		test.projectView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);

		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN2 + "_EPUB.epub",true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentCoverDesign,
				ISBN2 + "_FC.jpg",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN2);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(selectAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.ClickPublishDetail();
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_EPUB.epub");
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(ISBN2 + "_FC.jpg");
		test.projectView.ClickCloseButton();

		test.projectView.Verify_PublishedProjectISBN_LinkIsDisplayed();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN);
		test.projectView.VerifyISBNDisplayedInPublishProjectPopUp(ISBN2);
		test.projectView.VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(2);
		test.projectView.ClickCloseButton();
	}

	// 20."A) Project View
	// Verify that clicking the Published Project ISBNs link opens the Modal pop
	// up containing details of published ISBNs as follows:
	// 1) ISBN
	// 2) ISBN-10
	// 3) Author
	// 4) Title
	// 5) Edition
	// 6) Copyright Year"
	// BS-2478
	@Test(priority = 21)
	public void Verify_Published_Project_ISBNs_Link__Header() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickPublishDetail();
		test.projectView.ClickPublishedProjectISBN_OnPublishDetail();
		test.projectView.VerifyPublishedProjectISBN_PopUpDisplayed();
		test.projectView.VerifyPublishedProjectISBNHeaders();
	}

	// 21.Project view> Push to Authoring tool window> Epubs only: Verify that
	// tool tips are appearing for long fields in GRID view
	// BS-2000
	@Test(priority = 22)
	public void Verify_Proper_Tool_Tips_Are_Appearing_For_Long_Fields_Epubs_In_GRIDView_AuthoringTool() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyToolTipsOnAuthoringToolGrid();
	}

	// 22.Project view> Push to Authoring tool window> Other Assets: Verify that
	// tool tips are appearing for long fields in Grid view
	// BS-2000
	@Test(priority = 23)
	public void Verify_Proper_Tool_Tips_Are_Appearing_For_Long_Fields_Other_Assets_In_GRIDView_AuthoringTool() {
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.ClickOtherOnPushToAuthoringTool();
		test.projectView.VerifyToolTipsOnAuthoringToolGrid();
	}

	// 23.Project view> Push to Authoring tool window> Epubs only: Verify that
	// tool tips are appearing for long fields in LIST view
	// BS-2000
	@Test(priority = 24)
	public void Verify_Proper_Tool_Tips_Are_Appearing_For_Long_Fields_Epubs_In_LISTView_AuthoringTool() {
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.ClickEpubRadioOnPushToAuthoringTool();
		test.projectView.ClickListViewOnPushToAuthoringTool();
		test.projectView.VerifyToolTipsOnAuthoringToolList();
	}

	// 24.Project view> Push to Authoring tool window> Other Assets: Verify that
	// tool tips are appearing for long fields in LIST view
	// BS-2000
	@Test(priority = 25)
	public void Verify_Proper_Tool_Tips_Are_Appearing_For_Long_Fields_Other_Assets_In_LISTView_AuthoringTool() {
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.ClickOtherOnPushToAuthoringTool();
		test.projectView.VerifyToolTipsOnAuthoringToolList();
		test.projectView.ClickCloseButton();
	}

	// 25.Project view> Publish Window: Verify that tool tips are appearing for
	// long file names in Step 2 and 3
	// BS-2000
	@Test(priority = 26)
	public void Verify_Verify_Proper_Tool_Tips_Are_Appearing_For_Long_Fields_In_PublishWindow() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyToolTipsOnPublishWindow();
		test.projectView.ClickCloseButton();
	}

	// 26.Content view> Push to Authoring tool window: Verify that tool tips are
	// appearing for long fields in GRID view
	// BS-2000
	@Test(priority = 27)
	public void Verify_Tool_Tips_For_Long_Fields_In_GridView_ContentView() {
		test.projectView.ClickOpenAssetOnProjectView(ISBN2+"_EPUB.epub",TypesOfContentFlatEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyToolTipsOnAuthoringToolGrid();
	}

	// 27.Content view> Push to Authoring tool window: Verify that tool tips are
	// appearing for long fields in LIST view
	// BS-2000
	@Test(priority = 28)
	public void Verify_Tool_Tips_For_Long_Fields_In_ListView_ContentView() {
		test.ContentView.VerifyListView();
		test.ContentView.VerifyToolTipsOnAuthoringToolList();
		test.projectView.ClickCloseButton();
	}

	// 28.Content view> Publish window: Verify that tool tips are appearing for
	// long fields in Step 2 and 3.
	// BS-2000
	@Test(priority = 29)
	public void Verify_Verify_Tool_Tips_InContentView_PublishWindow() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyToolTipsOnPublishWindow();
	}

	// 29."Project view> Publish window: a) Verify that the extra white space on
	// the right of the Step 2 is now utilized to display the Asset Title till
	// 80 characters and after that ellipsis is displayed. "
	// BS-2512
	@Test(priority = 30)
	public void Verify_Extra_White_Space_On_Right_Of_Step2_Display_80_Characters() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.UploadCoversCoverDesignFromProjectView(ISBN);
		test.projectView.VerifyMessageDisplayedOnuploadingContent();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(Character80);
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited(Character80);
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.ContentView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyFileIsDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentCoverDesign,
				Character80);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyAssetDisplayedInStep2ForCourseware(CMSRepository, TypesOfContentCoverDesign,
				Character80);

		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(Character80, TypesOfContentCoverDesign);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditContentTitle(Character80 + "Delete File Used for Automated Testing.");
		test.ContentView.ClickUpdateButtonOnEditContentView();
		test.ContentView.VerifyTitleIsEdited(Character80 + "Delete File Used for Automated Testing.");

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN2);
		test.projectView.verifyOnProjectView();
		test.ContentView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.VerifyToolTipIsDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentCoverDesign,
				Character80.substring(0, 50));
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyToolTipDisplayedInStep2ForCourseware(CMSRepository, TypesOfContentCoverDesign,
				Character80.substring(0, 50));
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.navigateBack();
		test.projectView.navigateBack();
		test.projectView.navigateBack();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
