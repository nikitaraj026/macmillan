package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_LogIn_Page_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL;
	String AdminEmail, AdminPassword, NonAdminEmail, NonAdminPassword;
	String homePageLink, invalidemail, invalidpassword, logInErrorMsg, passwordResetMessage, loginPageLink;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		homePageLink = getData("Link.HomePageLink");
		invalidemail = getData("Invalidcredentials.email");
		invalidpassword = getData("Invalidcredentials.password");
		logInErrorMsg = getData("LogInError");
		passwordResetMessage = getData("passwordResetMessage");
		loginPageLink = getData("Link.loginPageLink");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutFromApplication() {

		test.HomePage.clickUserName();
		test.HomePage.clickLogOut();
	}

	// 1.Verify that CMS app Url is launching and loading
	@Test(priority = 1)
	public void Verify_CMS_URL_is_Launching() {
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
	}

	// 2.Verify that user is able to login into CMS application with correct
	// credentials
	@Test(priority = 2)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 3.Verify that user is not able to login into CMS using incorrect password
	@Test(priority = 3)
	public void Verify_User_Is_Not_Able_To_Login_Using_Incorrect_Password() {
		logoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(invalidpassword);
		test.loginpage.clickLogInButton();
		test.loginpage.VerifyErrorMessage(logInErrorMsg);
	}

	// 4.Verify that user is not able to login to CMS using incorrect Username
	@Test(priority = 4)
	public void Verify_User_Not_Able_To_Login_Using_Incorrect_Username() {
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(invalidemail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.loginpage.VerifyErrorMessage(logInErrorMsg);
	}

	// 5.Verify that user is not able to login to CMS using incorrect Username and
	// password both
	@Test(priority = 5)
	public void Verify_User_Not_Able_To_Login_Using_Incorrect_Username_And_Password() {
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(invalidemail);
		test.loginpage.enterUserPassword(invalidpassword);
		test.loginpage.clickLogInButton();
		test.loginpage.VerifyErrorMessage(logInErrorMsg);
	}

	// 6.Verify that 'Macmillan Learning CMS' logo is present at the top Right
	@Test(priority = 6)
	public void Verify_That_Macmillan_Learning_CMS_Logo_Is_Present() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyMacmillanLogoIsPresent();
	}

	// 7.Verify that Login button is not active if either of the Username or
	// Password field is Blank
	@Test(priority = 7)
	public void Verify_Login_Button_Is_Not_Active_Username_Or_Password_Field_Is_Blank() {
		logoutFromApplication();
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.VerifyLoginButtonIsDisable();
		test.refreshPage();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.VerifyLoginButtonIsDisable();
	}

	// 8.Verify that 'Forgot your Password' link is working
	@Test(priority = 8)
	public void Verify_Forgot_Your_Password_Link_Is_Working() {
		test.loginpage.VerifyUserIsOnLoginPage(loginPageLink);
		test.loginpage.clickForgetPassword();
		test.loginpage.VerifyOnPasswordResetFunction();
	}

	// 10.Verify that an info message appears above the login panel on clicking the
	// Reset password button after entering the valid email ID
	@Test(priority = 10)
	public void Verify_Info_Message_Appears_On_Login_Panel_Clicking_Reset_Button() {
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.clickresetButton();
		test.loginpage.VerifyPasswordUpdateMessageDisplayed(passwordResetMessage);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
