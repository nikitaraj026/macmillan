package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Sample_Chapter_Publish extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN;
	String TestImageTitle, TestFileName, TypeOfContentMarketingSampleChapter, PublihDestinationCoreSource;
	String PublihDestinationPalgrave, PublihDestinationCourseWare, PublihDestinationVitalSource,
			PublihDestinationInstructorStore;
	String TestISBN, TestISBN1, TestISBN2, TestISBN3;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		TestISBN = getData("ProjectISBNNo1");
		TestISBN1 = getData("ProjectISBNNo6");
		TestISBN2 = getData("ProjectISBNNo3");
		TestISBN3 = getData("ProjectISBNNo4");
		TestImageTitle = "SampleChapterAutoTest";
		TestFileName = "TestingPDF.pdf";
		TypeOfContentMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step: Upload an Sample Chapter
	@Test(priority = 2)
	public void Upload_An_Sample_Chapter() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestFileName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentMarketingSampleChapter);
		test.HomePage.EnterTextIntoTitleField(TestImageTitle);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// 1.Verify that Publish modal appears after clicking the Publish link available
	// in Content view of Sample Chapters
	@Test(priority = 3)
	public void Verify_Publish_Modal_Appears_Clicking_Publish_Link() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
	}

	// 2."STEP1: Verify that Destination Drop down is available with 4 publish
	// destinations-Palgrave,Instructor Store, CoreSource and VitalSource"
	@Test(priority = 4)
	public void Verify_Verify_All_Publish_Destinations() {
		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
	}

	// 3.STEP1: Verify that Select ISBN box is only displayed when Publish
	// destination is selected as 'Instructor Store'
	@Test(priority = 5)
	public void Verify_Select_ISBN_Box_Displayed_When_Instructor_Store_Selected() {
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.VerifySearchForISBnInputBoxDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifySearchForISBNIn_IS_Publish_Window_Not_Displayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.VerifySearchForISBNIn_IS_Publish_Window_Not_Displayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.VerifySearchForISBNIn_IS_Publish_Window_Not_Displayed();
	}

	// 4.STEP1: Verify that no ISBN is pre-populated
	@Test(priority = 6)
	public void Verify_That_No_ISBN_Is_Pre_populated() {
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.VerifyNoISBNsIsDisplayedOnPublishTable();
	}

	// 5."STEP1: Verify that blank table with following column headers is displayed:
	// Author, Title, Edition, CopyrightYear, ISBN, ISBN-10, Action"
	@Test(priority = 7)
	public void Verify_Column_Headers_In_Step1_Select_Destination() {
		test.ContentView.VerifyTableHeaderForIS_PublishWindow();
	}

	// 6.STEP1: Verify that user is not able to add duplicate ISBNs
	@Test(priority = 8)
	public void Verify_User_Not_Able_To_Add_Duplicate_ISBN() {
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.ContentView.VerifyAddButtonDisabledOnIS_PublishWindow();
		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.ContentView.VerifyAddButtonDisabledOnIS_PublishWindow();
	}

	// 7.STEP1: Verify that user is able to Delete the added ISBN
	@Test(priority = 9)
	public void Verify_User_Is_Able_To_Delele_ISBNs() {
		test.ContentView.DeleteISBN_From_IS_PublishWindow(ISBN);
		test.ContentView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN);
	}

	// 8.STEP1: Verify that user is able to Paste the ISBN in the Select ISBN box
	// and relevant search results are displayed in the autosuggestion list
	@Test(priority = 10)
	public void Verify_User_Able_To_Paste_ISBNs_In_Select_ISBN_Box_Relevant_Search_Results_Displayed() {
		test.ContentView.CopyPaste_ISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
	}

	// 9.STEP1: Verify that user is able to add multiple ISBNs in Step 1 and
	// pagination is there if more than 3 ISBNs are added.
	@Test(priority = 11)
	public void Verify_Multiple_ISBNs_Can_Be_Added_And_pagination_Bar_For_more_Than_3_ISBNs() {
		test.ContentView.Verify_PaginationBar_Not_Displayed_for_InstructorStore_Publish_Window();
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);

		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN);

		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN1);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN1);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN1);

		test.ContentView.Verify_PaginationBar_Not_Displayed_for_InstructorStore_Publish_Window();

		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN3);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN3);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.NavigateToPageNumberInPublishWindow_IS("2");
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN3);
		test.ContentView.Verify_PaginationBar_Displayed_for_InstructorStore_Publish_Window();
	}

	// 10.STEP2: Verify that the asset is displayed as Selected by default under
	// 'Step 2 Selected Assets'
	@Test(priority = 12)
	public void Verify_Asset_Is_Displayed_As_Selected_By_Default_In_Step2_Selected_Assets() {
		test.ContentView.VerifySelectRadioButtonOnPublishPopUp();
	}

	// 11.STEP3: Verify that user is able to Approve/ Unapprove the sample chapter
	// by selecting the checbox and clicking the Approve/ Unapprove button
	@Test(priority = 13)
	public void Verify_User_Able_To_Approve_Unapprove_Sample_Chapter() {
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
	}

	// 12.Verify that if the asset is approved then user is able to initiate the
	// Publish operation by clicking the Publish button
	@Test(priority = 14)
	public void Verify_Approved_Asset_Can_Be_Published() {
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 13.Verify that clicking the 'Cancel' or 'Cross' button closes the Publish
	// modal pop-up
	@Test(priority = 15)
	public void Verify_Cancel_Or_Cross_Button_Closes_Publish_Modal() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.ClickCloseOnpublishPopup();
		test.ContentView.VerifyPublishPopIsClosed();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.ClickCancelOnPublishPop();
		test.ContentView.VerifyPublishPopIsClosed();
	}

	// 14.Verify that error message 'No assets to publish!' is displayed if user
	// clicks on Publish button when the sample chapter is Unapproved
	@Test(priority = 15)
	public void Verify_Error_Message_Displayed_On_Publish_Unapproved() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsNotPublished();
	}

	// 15.Verify that all the ISBNs selected in STEP1 gets disappeared if user
	// modifies the Publish Destination
	@Test(priority = 16)
	public void Verify_ISBN_Selected_Gets_Disappeared_User_Modifies_Publish_Destination() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);

		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN);

		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN1);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN1);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN1);

		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifyISBN_NotDisplayedIn_IS_Publish(ISBN);
		test.ContentView.VerifyISBN_NotDisplayedIn_IS_Publish(TestISBN);
		test.ContentView.VerifyISBN_NotDisplayedIn_IS_Publish(TestISBN1);
	}

	// 16.Verify that Success message containing all the ISBNs is displayed
	// @Test(priority=16) ###### Need to be Updated once Issue is fixed ######
	public void Verify_Success_Message_With_All_ISBNs() {
		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.SearchForISBNIn_IS_Publish_Window(ISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(ISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(ISBN);

		test.ContentView.SearchForISBNIn_IS_Publish_Window(TestISBN);
		test.ContentView.SelectISBNFromSuggestaionBoxInPublishWindow_IS(TestISBN);
		test.ContentView.ClickADDButton_IS();
		test.ContentView.VerifyISBN_DisplayedIn_IS_Publish(TestISBN);

		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

	}
	
	//Delete The The Uploaded Sample Chapter
	@Test(priority=17)
	public void Delete_The_Sample_Chapter() {
		test.ContentView.DeleteContentFromCMS();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
