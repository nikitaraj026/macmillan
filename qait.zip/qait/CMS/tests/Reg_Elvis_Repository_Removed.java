package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Elvis_Repository_Removed extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String LookForAsset, AdvSearchTypeRepository, FacetContentType;
	String FacetLinkImageLinked, TestISBN;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		LookForAsset = getData("LookFor.Assets");
		AdvSearchTypeRepository = getData("SearchTypeAdvanceSearch.Repository");
		FacetContentType = getData("FacetType.Content Type");
		FacetLinkImageLinked = getData("TypesOfContent.Images>Image Linked");
		TestISBN = getData("ProjectISBNNo2");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that 'Elvis' repository has been removed from the available
	// repositories section in Content tab at CMS QA end.
	// BS-2699

	@Test(priority = 2)
	public void Verify_Elvis_Repository_Has_Been_Removed_From_ContentTab() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.VerifyElvisRepositoryRemoved();
	}

	// 2.Verify that 'Elvis' option has been removed from the Repository
	// drop-down available in Advanced Search workflow. // BS-2699

	@Test(priority = 3)
	public void Verify_Elvis_Repository_Has_Been_Removed_From_AdvanceSearch() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeRepository);
		test.SearchPage.VerifyTextNotDisplayedInAddedDropDown(1, "Elvis");
		test.projectView.ClickCloseButton();
	}

	// 3."Verified that flickering of tool tip is not observed i.e. stable tool
	// tip is appearing on hovering over the List/ Grid view button for following
	// workflows: a) Dashboard

	@Test(priority = 4)
	public void sVerify_Flickering_Tool_Tip_Not_Observed_and_works_Properly_DashBoard() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("3");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		for (int trys = 0; trys < 5; trys++) { // need to perform test steps multiple time to reproduce the issue.
			test.HomePage.clickGridView();
			test.HomePage.VerifyGridViewDisplayed();
			test.HomePage.ClickListView();
			test.HomePage.VerifyListViewDisplayed();
			test.HomePage.VerifyGridViewButtonToolTip();
			test.HomePage.VerifyListViewButtonToolTip();
			test.HomePage.clickGridView();
			test.HomePage.ClickListView();
			test.HomePage.ClickListView();
			test.HomePage.ClickListView();
		}

	}

	// 4."Verified that flickering of tool tip is not observed i.e. stable tool
	// tip is appearing on hovering over the List/ Grid view button for following
	// workflows: // b) Project Tab

	@Test(priority = 5)
	public void Verify_Flickering_Tool_Tip_Not_Observed_and_works_Properly_ProjectTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		for (int trys = 0; trys < 5; trys++) { // need to perform test steps multipletime to reproduce the issue.
			test.ProjectPage.clickGridView();
			test.ProjectPage.VerifyProjectsOnGridView();
			test.ProjectPage.clickListView();
			test.ProjectPage.VerifyProjectOnListView();
			test.ProjectPage.clickGridView();
			test.ProjectPage.clickGridView();
			test.ProjectPage.clickGridView();
			test.ProjectPage.clickListView();
			test.ProjectPage.clickListView();
			test.ProjectPage.clickListView();
			test.ProjectPage.VerifyGridViewButtonToolTip();
			test.ProjectPage.VerifyListViewButtonToolTip();
		}
	}

	// 5."Verified that flickering of tool tip is not observed i.e. stable tool
	// tip is appearing on hovering over the List/ Grid view button for following
	// workflows: c) Content Tab
	@Test(priority = 6)
	public void Verify_Flickering_Tool_Tip_Not_Observed_and_works_Properly_ContentTab() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		for (int trys = 0; trys < 5; trys++) { // need to perform test steps multiple time to reproduce the issue.
			test.Contentpage.ClickGridView();
			test.Contentpage.VerifyOnGridView();
			test.Contentpage.clickListView();
			test.Contentpage.VerifyOnListView();
			test.Contentpage.ClickGridView();
			test.Contentpage.ClickGridView();
			test.Contentpage.ClickGridView();
			test.Contentpage.clickListView();
			test.Contentpage.clickListView();
			test.Contentpage.clickListView();
			test.Contentpage.VerifyListViewButtonToolTip();
			test.Contentpage.VerifyGridViewButtonToolTip();
		}

	}

	// a) From Content tab: On clicking each Content type filter available under
	// the Content type Facet, we are getting the accurate results that are
	// matching with the count mentioned to the right of each filter within the
	// '+ See more' pop-up.
	// BS-3443

	@Test(priority = 7)
	public void Verify_Asset_Count_Are_Accoring_To_See_More_Link() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.Contentpage.verifyOnSeeMorePopup(FacetContentType);
		test.Contentpage.verifyCorrectCountOfAssetFromSeeMoreLink(FacetLinkImageLinked);
	}

	// b) From Generic Search> ‘Content’ Search only: On clicking each Content
	// type filter available under the Content type Facet, we are getting the
	// accurate results that are matching with the count mentioned to the right
	// of each filter within the '+ See more' pop-up.
	// BS-3443

	@Test(priority = 8)
	public void Verify_Asset_Count_Are_Accoring_To_See_More_Link_Generic_Search() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem("Test");
		test.Contentpage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.Contentpage.verifyOnSeeMorePopup(FacetContentType);
		test.Contentpage.verifyCorrectCountOfAssetFromSeeMoreLink(FacetLinkImageLinked);
	}

	// c) From Advanced Search> ‘Assets’: On clicking each Content type filter //
	// available under the Content type Facet, we are getting the accurate results
	// that are matching with the count mentioned to the right of each filter
	// within the '+ See more' pop-up.
	// BS-3443
	@Test(priority = 9)
	public void Verify_Asset_Count_Are_Accoring_To_See_More_Link_Advance_Search() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.EnterTextIntoSearchBox("test");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.SearchPage.verifyOnSeeMorePopup(FacetContentType);
		test.SearchPage.verifyCorrectCountOfAssetFromSeeMoreLink(FacetLinkImageLinked);
	}

	// 1) Verify that favorite projects count under the Favorite facet doesn't turns
	// to '0' i.e. displays the current Favorite Projects count if user refreshes
	// the Content tab page.
	// BS-3206
	@Test(priority = 10)
	public void Verify_Facet_Count_Not_Displayed_Zero_On_Refreshing_Content_Tab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("5");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyFavoriteProjectCountIsNotZero();
	}

	// 2) Verify that favorite projects count under the Favorite facet doesn't turns
	// to '0' i.e. displays the current Favorite Projects count if user refreshes
	// the Dashboard tab page.
	// BS-3206
	@Test(priority = 11)
	public void Verify_Facet_Count_Not_Displayed_Zero_On_Refreshing_DashBoard() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.VerifyFavoriteProjectCountIsNotZero();
	}

	// 3) Verify that favorite projects count under the Favorite facet doesn't turns
	// to '0' i.e. displays the current Favorite Projects count if user refreshes
	// the Projects tab page.
	// BS-3206
	@Test(priority = 12)
	public void Verify_Facet_Count_Not_Displayed_Zero_On_Refreshing_ProjectTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.refreshPage();
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.VerifyFavoriteProjectCountIsNotZero();
	}

	// 4) Verify that favorite projects count under the Favorite facet doesn't turns
	// to '0' i.e. displays the current Favorite Projects count if user refreshes
	// the Generic search results page.
	// BS-3206
	@Test(priority = 13)
	public void Verify_Facet_Count_Not_Displayed_Zero_On_Refreshing_GenericSearch() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem("Test");
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.Contentpage.VerifyFavoriteProjectCountIsNotZero();
	}

	// 5) Verify that favorite projects count under the Favorite facet doesn't turns
	// to '0' i.e. displays the current Favorite Projects count if user refreshes
	// the Advance search results page.
	// BS-3206
	@Test(priority = 13)
	public void Verify_Facet_Count_Not_Displayed_Zero_On_Refreshing_AdvanceSearch() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.VerifyFavoriteProjectCountIsNotZero();
	}

	// 6) Verify that favorite projects count under the Favorite facet doesn't turns
	// to '0' i.e. displays the current Favorite Projects count if user navigates
	// within the DashBoard tab, Projects tab, Content tab.
	// BS-3206
	@Test(priority = 13)
	public void Verify_Facet_Count_Not_Displayed_Zero_On_Navigateing() {
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyFavoriteProjectCountIsNotZero();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyFavoriteProjectCountIsNotZero();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyFavoriteProjectCountIsNotZero();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyFavoriteProjectCountIsNotZero();

	}

	// 1. Remove the ‘Clear all’ link from the pop-up.
	// BS-1665
	@Test(priority = 14)
	public void Verify_Clear_All_Link_Removed_From_Add_Remove() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.verifyClearAllLinkNotDisplayedOnAddtoProjectpopUp();
	}

	// 2. Cross icon should appear inside the 'Search Projects' text box on keying
	// the text.
	// BS-1665
	@Test(priority = 15)
	public void Verify_X_Icon_Displayed_On_Add_Remove() {
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.SearchForProjectOnAddRemoveContent(TestISBN);
		test.Contentpage.verifySearchFieldAnd_xIconOnAddtoProjectpopUp();
	}

	// 3. Clicking on the ‘Cross’ icon should clear the keyed text from the Search
	// box.
	// BS-1665
	@Test(priority = 16)
	public void Verify_Cross_Icon_Should_Clear_The_keyed_Text() {
		test.Contentpage.clickXIconOnAddRemoveProject();
		test.Contentpage.VerifyInputBoxClearOnAddRemoveProject();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
