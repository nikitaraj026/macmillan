package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Project_view_Test extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN, NonAdminEmail, NonAdminPassword;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationCourseWare, ProjectISBNNO,
			DamContent;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword,
			PublihDestinationVitalSource;
	String LOMacmillanCalculus, selectAllPages, AdvSearchType, LookForProject, ProjectTypeDistributableEPub;
	String Workflow_PE_Approved, Workflow_Final, PublihDestinationInstructorStore;
	String TypesOfContentFlatEpub, TypesOfContentInstructorResources, TypesOfContentEnhancedEpub;
	String CMSRepository, DAMRepository,ContentTypeCFI,FrostExportFull;
	String TypeOfContentMarketingSampleChapter, MarketingSampleChapter, UploadISBN, DistributableEPubISBN;
	String ExportOptionEnhancedPub;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ProjectISBNNO = getData("ProjectISBNNo1");
		UploadISBN = getData("ProjectISBNNo3");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		DamContent = getData("DamContent");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnter");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		LOMacmillanCalculus = getData("Framework.macmillan calculus");
		selectAllPages = getData("PageSelection.All Pages");
		AdvSearchType = getData("SearchTypeAdvanceSearch.Project Type");
		LookForProject = getData("LookFor.project");
		ProjectTypeDistributableEPub = getData("ProjectType.Distributable ePub");
		Workflow_PE_Approved = getData("WorkFlowStatus.PE Approved");
		Workflow_Final = getData("WorkFlowStatus.Final");
		TypeOfContentMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		MarketingSampleChapter = getData("MarketingSampleChapter");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentInstructorResources = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		CMSRepository = getData("Repository.CMS");
		DAMRepository = getData("Repository.DAM");
		DistributableEPubISBN = getData("DistributableEPubISBN");
		ContentTypeCFI = getData("TypesOfContent.Project Support Materials>CFI");
		FrostExportFull=getData("FrostExportType.Full");
		ExportOptionEnhancedPub=getData("FrostExportOptions.Enhanced ePub");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}


	// 1.Verify following data for a project under System Metadata are displayed
	// System ID Project URI,Date Created,Created,Date Modified,Modified By
	@Test(priority = 1)
	public void Verify_System_Metadata_Are_Displayed() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.Verify_System_Metadata();
	}

	// 2.Verify that corresponding data for a project is displayed under ISBN
	// Details, Project Details and Publish Details tab
	@Test(priority = 2)
	public void Verify_All_The_SubTab_Are_Displayed_In_ProjectView() {

		test.projectView.VerifySubTabAreDispalyed();
	}

	// 3.Verify that user can add/remove his/her email id in the list of email
	// id's as project contact
	@Test(priority = 3)
	public void User_Can_Add_Remove_Email_From_Project_Contact() {

		test.projectView.clickProjectDetails();
		test.ContentView.AddAndRemoveEmailOnAContent(AdminEmail);
	}

	// 4.Verify that Project publish details can be tracked under this tab
	@Test(priority = 4)
	public void Verify_User_Is_Able_To_View_Publish_Details() {
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyHeaderOfPublishTab();
		test.projectView.VerifyPublishDetailsAreDisplayed();
	}

	// 5.Verify that following links are available at the top: 1) Publish
	// (Provided that Project state is Enhanced ePub in QA ETC
	@Test(priority = 5)
	public void Verify_That_Top_Links_Are_Available() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyTopLinks();
	}

	// 6.Verify that a user is navigated to frost authoring tool on a click 'Go
	// To Frost' button
	@Test(priority = 6)
	public void Verify_Go_To_Frost_Button_Is_Working() {
		test.projectView.ClickGoToFrost();
		test.projectView.VerifyUserIsOnFrostApplication();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 7.Verify that user is able to see the Usage details.
	@Test(priority = 7)
	public void Verify_User_Is_Able_To_See_Usage_Details() {
		test.ContentView.changeWindow(0);
		test.projectView.clickTopLinkMore();
		test.projectView.clickUsageDetails();
		test.projectView.VerifyUsageDetailsAreShown();
	}

	// 8.Verify that Push To Authoring Tool is enables when Project state is
	// Ready for Enhancements
	@Test(priority = 8)
	public void Verify_Push_To_Authoring_Tool_Is_Enables_When_State_Ready_For_Enhancements() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyPushToAuthoringToolIsEnabledOnlyForReadyForEnhancements();
	}

	// 9.Verify that ePub labels for Flat and Enhanced ePubs are displaying in
	// Grid view
	@Test(priority = 9)
	public void Verify_Epub_Labels_Are_Displayed_In_Grid_View() {
		test.projectView.VerifyLablesAreDisplayed();
	}

	// 10.Verify that user is able to organize his download with upto three
	// level folder structure as ISBN, Content Type and Repository
	@Test(priority = 10)
	public void Test_User_Is_Able_To_Organize_His_Download_Upto_ThreeL_Level_Folder_Structure() {
		test.projectView.clickTopLinkMore();
		test.projectView.clickOrganisedDownload();
		test.projectView.OrganizedTheDownload("ISBN", "Repository", "Content Type");
	}

	// 11. To complete Verify that user is able to Push the ePub to Frost
	@Test(priority = 11)
	public void Verify_User_Is_Able_To_Push_Epub_To_Frost() {
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(ISBN, ISBN);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(ISBN);
	}

	// 12. To complete Verify that user is able to Push the FC to Frost
	@Test(priority = 12)
	public void Verify_User_Is_Able_To_Push_FC_To_Frost() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectFcOnAuthoringToolAndPush(ISBN);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyFrostPushActionInWorkFlowHistory(ISBN);
	}

	// 13.Verify that all the associated content are displayed here with its
	// thumbnail view
	@Test(priority = 13)
	public void Verify_Associated_Content_Are_Displayed_In_Thumbnail() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyContentsAreDisplayedInThumbnail();
	}

	// 14.Verify that Flat and Enhanced labels are appearing for the ePub
	@Test(priority = 14)
	public void Verify_Epub_Labels_Are_Displayed() {

		test.projectView.VerifyLablesAreDisplayed();
	}

	// 15. Verify that Workflow history is available
	@Test(priority = 15)
	public void Verify_WorkFlow_History_Is_Displayed() {

		test.projectView.VerifyHistoryIsdisplayed();
	}

	// 16.Verify that a user is allowed to add a comment and all the comments
	// are displayed at the bottom of project view page
	@Test(priority = 16)
	public void Verify_User_Is_Able_To_Add_Comment_And_View_It() throws IOException {

		test.projectView.AddCommentAndVerifyIt();
	}

	// 17.Verify that Publish link appears at the top when Project status is
	// Enhanced ePub in QA/ Course Building.
	@Test(priority = 17)
	public void Verify_Publish_Link_Apperes_When_Status_Enhanced_EPub_In_QA_Or_Course_Building() {
		test.projectView.VerifyPublishLinkOnlyDisplayforEnhancedEpubAndCourseBuilding();
	}

	// 18.Step 1: Verify that Instructor store as the Publish destination is
	// selected by default
	@Test(priority = 18)
	public void Verify_Instructor_Store_Is_Selected_As_Default_Publish_Destination() {
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishDestinationOnPublishPopIs(PublihDestinationInstructorStore);
	}

	// 19."Verify that three options are displaying under step 1 when the
	// Destination is selected as CoreSource/VitalSource as:1) Publish CFI and
	// ePub2)
	// Publish CFI only3) Publish ePub only "
	@Test(priority = 19)
	public void Verify_Three_Option_Are_Displayed_When_Destination_selected_as_CoreSource() {

		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyThreeOptionsDisplayedInPublish();
		test.projectView.VerifyToolTips("Publish ePub only", PublihDestinationCoreSource);
		test.projectView.VerifyToolTips("Publish content links and ePub", PublihDestinationCoreSource);
		test.projectView.VerifyToolTips("Publish content links only", PublihDestinationCoreSource);

		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.VerifyToolTips("Publish ePub only", PublihDestinationVitalSource);
		test.projectView.VerifyToolTips("Publish content links and ePub", PublihDestinationVitalSource);
		test.projectView.VerifyToolTips("Publish content links only", PublihDestinationVitalSource);
	}

	// 20.Verify that user is able to Publish the Project to available
	// destination platforms i.e.CoreSource,Palgrave,CourseWare,Instructor Store
	@Test(priority = 20)
	public void Verify_User_Is_able_To_Publish_On_CoreSource_Palgrave_CourseWare() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentFlatEpub, ISBN + "_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub, ISBN + ".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentEnhancedEpub,
				ISBN + ".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.HomePage.ClickDashBord();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.SelectContentOnContentTab(DamContent, TypesOfContentInstructorResources);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.AddSelectedContentToProject(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(DAMRepository, TypesOfContentInstructorResources,
				DamContent,true);
		test.projectView.Select_Assert_Displayed_In_Step3(DamContent);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter,true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
	}

	// 21.Verify that user can Publish only the approved content successfully
	// and success message appears on successful Publish action
	// Verify that error message is displayed if user clicks publish button with no
	// assets Approved.
	@Test(priority = 21)
	public void Verify_Only_Approved_Content_Can_Be_Published_And_Success_Message_Appears() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentEnhancedEpub,
				ISBN + ".epub",true);
		test.projectView.Select_EnhancedEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN + "_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickUnApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasUnsuccessful(ISBN);
	}

	// 22.Verify that user can publish the contents as per the selection made in
	// step 1 and 2
	@Test(priority = 22)
	public void Verify_User_Can_Publish_Content_By_selection_Made_In_Step_1_And_2() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();

		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(CMSRepository, TypesOfContentFlatEpub,
				ISBN + "_EPUB.epub",true);
		test.projectView.Select_FlatEpub_Displayed_In_Step3(ISBN);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseOnpublishPopup();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCoreSource);
	}

	// 23.Verify that a user is successfully able to upload any content to a
	// project/isbn directly from its project view page (the Project ISBN from
	// which the Upload Content pop up is opened is by default selected)
	@Test(priority = 23)
	public void Verify_User_Is_upload_Content_From_project_View_Page() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickUploadContent();
		test.projectView.UploadContentAndAssociateFromProjectView(UploadISBN);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.RemoveContentFromProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	// -----------FROST------------- 24.Verify that project of that ISBN will
	// get created at Frost which is entered by the user in step 3 and while
	// user pushes, these will get associated with both the ISBNs

	@Test(priority = 24)
	// ***** Not Authorized to perform Frost related Functionality on PROD ******
	public void ZZ_Project_of_ISBN__Get_Created_And_associated_In_Frost_Entered_In_Step_3() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.SelectFlatEpubOnAuthoringToolAndPush(FrostMainProject, FrostIsbnToEnter);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, FrostCreatedProjectName);
		test.projectView.OpenProjectOnFrost(FrostCreatedProjectName);
		test.projectView.ExportFilesToCms(ExportOptionEnhancedPub,FrostExportFull);
		test.projectView.ExportFilesFromExportHistory();
		test.projectView.LogoutFromFrost();
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.VerifyCFIAndEnhancedEpubArePushed(FrostIsbnToEnter);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostIsbnToEnter);
		test.projectView.VerifyCFIAndEnhancedEpubArePushed(FrostIsbnToEnter);
	}

	// 25.Verify that Two additional files (Enhanced ePub and CFI file) are
	// received in from Frost and get associated with Project

	@Test(priority = 25, dependsOnMethods = "ZZ_Project_of_ISBN__Get_Created_And_associated_In_Frost_Entered_In_Step_3")
	// ***** Not Authorized to perform Frost related Functionality on PROD ******
	public void Verify_Two_Additional_Files_Recived_From_Frost() {
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.VerifyCFIAndEnhancedEpubArePushed(FrostIsbnToEnter);
	}

	// 26.Verify that State of Project gets changed to 'Enhanced ePub
	// Ingested' automatically after files are pushed back to CMS from Frost and
	// get available in CMS

	@Test(priority = 26, dependsOnMethods = "Verify_Two_Additional_Files_Recived_From_Frost")
	// ***** Not Authorized to perform Frost related Functionality on PROD ******
	public void State_Of_Project_Gets_Changed_To_Enhanced_EPub_Ingested_After_Push_From_Frost() {
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.VerifyWorkFlowStatusIsEnhancedEPubIngested();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostIsbnToEnter);
		test.projectView.ClickOpenAssetOnProjectView(FrostIsbnToEnter+"_CFI.csv", ContentTypeCFI);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostIsbnToEnter);
		test.projectView.ClickOpenAssetOnProjectView(FrostIsbnToEnter+".epub",TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}

	// 27.Delete The Project From The Frost
	@Test(priority = 27, dependsOnMethods = "State_Of_Project_Gets_Changed_To_Enhanced_EPub_Ingested_After_Push_From_Frost")
	// ***** Not Authorized to perform Frost related Functionality on PROD ******
	public void Delete_Project_from_Frost() {
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(FrostMainProject);
		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(FrostIsbnToEnter, FrostCreatedProjectName);
		test.projectView.DeleteProjectFromFrost(FrostCreatedProjectName);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}/// ---------FROST-------------

	// 28.Verify Options are Available on Push To authoring tool:
	// platform,select asset and Java Script Option
	// Verify that ePub labels for Flat and Enhanced ePubs are displaying in Grid
	// view inside the Push to Authoring tool window
	@Test(priority = 28)
	public void Verify_Options_Are_Available_On_Push_To_AuthoringTool() {
		test.projectView.changeWindow(0);
		test.refreshPage();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyLabelsForContentsOnPushToAuthoringTool();
		test.projectView.VerifyAlltheOptionsOfPushToAuthoringTool(ISBN);
		test.projectView.ClickCloseButton();
	}

	// 29.Verify that user is able to filter the associated content on the basis
	// of Content type using the filter available.
	@Test(priority = 29)
	public void Verify_User_Is_Able_To_Filter_The_Associated_Content() {
		test.projectView.VerifyFilterContentIsWorking();

	}

	// 30.Verify that Selected content is displayed to the right of the filter
	@Test(priority = 30)
	public void Selected_Content_Is_Displayed_On_Right_Filter() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifySelectedContentOnRight();
	}

	// 31.Verify that no other user is able to edit or delete other user's
	// comment
	@Test(priority = 31)
	// ***** Only Single Account on PROD Env ******
	public void Verify_Other_User_Is_Not_Able_To_Edit_OR_Delete_Other_User_Comment() {
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(NonAdminEmail);
		test.loginpage.enterUserPassword(NonAdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.VerifyUserIsNotAbleToDeleteMsg(AdminEmail);
		test.projectView.VerifyUserIsnotAbleToEditMsg(AdminEmail);
	}

	// 32.Verify the tool tips for all the above 3 radio buttons
	@Test(priority = 32)
	public void Verify_Tool_Tips_Above_Radio_Button() {
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.VerifyToolTips();
	}

	// 33."Verify that following metadata is displayed under the Content's
	// thumbnail-
	// Title:
	// File Name:
	// Content Type:
	// Last Updated:"
	@Test(priority = 33)
	public void Verify_Appropriate_States_Are_Displaying_For_Associated_Contents() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyAssociatedContentDetailDisplayed();
	}

	// 34.Verify that user can mark/unmark the Project as Favorite
	@Test(priority = 34)
	public void Verify_User_Can_Mark_Unmark_The_Project_As_Favorite() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.AddProjectToFavorite();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 35.Verify that user is able to select all the Assets that are displaying
	// in step 3 (depending upon the selection made in step 2) by clicking the
	// Select All checkbox from any page in Publish window in step 3.
	@Test(priority = 35)
	public void Verify_User_Is_Able_To_Select_All_The_Assets_Displayed_In_Step_3_Of_Publish_Window() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.clickRepositoryOnStep2OfPublishWindow();
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(selectAllPages);
		test.projectView.VerifyAllTheAssetsAreSelectedToPublishInStep3();
	}

	// 36.Verify that in case of Courseware publish, user can tag the assets
	// with Instructor or Student metadata in order to Publish. Also, Clear tag
	// button is available to clear the applied metadata
	@Test(priority = 36)
	public void Verify_User_Can_Tag_The_Assets_With_Instructor_Or_Student_Metadata_In_Courseware_Publish() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(CMSRepository,
				TypesOfContentFlatEpub, ISBN + "_EPUB.epub");
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToStudentResource();
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToInstructorResource();
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.VerifyAssertAreRemovesFromInstructorOrStudentResource();
	}

	// 37.Verify that i or s badges are displayed by default for Supplementary
	// content IR or SR resource and user can not edit the same.
	@Test(priority = 37)
	public void Verify_I_Or_S_Badges_Are_Displayed_By_Default_For_Supplementary_Content() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow(DAMRepository, TypesOfContentInstructorResources,
				DamContent,true);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(DamContent);
		test.projectView.VerifyInstructorOnlyMetadataButtonDisabled();
		test.projectView.VerifyStudentOnlyMetadataButtonDisabled();
		test.projectView.VerifyClearAccessLevelMetadataButtonDisabled();
	}

	// 38.Verify that user is able to add a LOF to the Project
	@Test(priority = 38)
	public void Verify_User_Is_Able_To_Add_LOF_To_The_Project() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOMacmillanCalculus);
	}

	// 39.Verify that LOF added to the project reflects in the Learning
	// objective tab of each associated content to that project
	@Test(priority = 39)
	public void Verify_LOF_Added_To_The_Project_Reflects_In_Each_Associated_Content() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.VerifyFrameWorkIsAddedToTheProject(LOMacmillanCalculus);
		test.projectView.VerifyFrameWorkIsAddedToAssociatedContent(LOMacmillanCalculus);
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
	}

	// 40.Verify that relevant toaster messages are displayed on adding/
	// deleting the LOF
	@Test(priority = 40)
	public void Verify_Relevant_Toaster_Messages_Displayed_On_Adding_Deleting_LOF() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkRemovedMessageDisplayed();

	}

	// 41.Verify that LOF already added to a Project reflects on the Content if
	// that content is added later
	@Test(priority = 41)
	public void Verify_LOF_Added_To_A_Project_Reflects_on_The_Content_Added_Later() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ProjectISBNNO + "_FC.jpg");
		test.Contentpage.opentheSearchContent(ProjectISBNNO + "_FC.jpg");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(ISBN);
		test.refreshPage();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.RemoveContentFromProject(ISBN);
	}

	// 42.Verify that Added LOF in the Project view does not delete from the
	// content view when the same is deleted from the Project view
	@Test(priority = 42)
	public void Verify_LOF_Does_Not_Delete_From_Content_When_Same_Is_Deleted_From_Project() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.RemoveFameworkFromContent(LOMacmillanCalculus);

		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.clickLearningObjectives();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);
		test.projectView.AddLearningObjective(LOMacmillanCalculus);
		test.projectView.VerifyFrameworkAddedMessageDisplayed();
		test.projectView.RemoveFameworkFromProject(LOMacmillanCalculus);

		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN + "_EPUB.epub");
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(LOMacmillanCalculus);
	}

	// 43."Verify that in case of Online course project, following 04 states are
	// available: 1. Ready for Enhancements 2. Enhanced EPub ingested 3. Enhanced
	// ePub in QA 4. Enhanced epub for Course Building
	// and for Distributable epub project, 02 states are available: PE Approved
	// Final"

	@Test(priority = 43)
	public void Verify_All_The_WorkFlow_Status_For_OnlineCourse_And_DistributableEpub_Project() {
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchType);
		test.SearchPage.SelectContentTypeInNewAddedField(ProjectTypeDistributableEPub);
		test.SearchPage.EnterTextIntoSearchBox(DistributableEPubISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.OpenProjectOnAdvanceSearch(DistributableEPubISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickWorkFlowStatus();
		test.projectView.SelectWorkFlowStatus(Workflow_PE_Approved);
		test.projectView.VerifyWorkFlowStatusIs(Workflow_PE_Approved);
		test.projectView.SelectWorkFlowStatus(Workflow_Final);
		test.projectView.VerifyWorkFlowStatusIs(Workflow_Final);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickWorkFlowStatus();
		test.projectView.GetAllWorkFlowStatus();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}