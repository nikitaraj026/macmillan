package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Marking_Project_Favorite extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String ISBN, ISBN1, SearchTypeProject, LookForProject, LookForBoth;

	private void initVars() {
		baseURL = getData("baseUrl");
		loginPageLink = getData("Link.loginPageLink");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		SearchTypeProject = getData("SearchType.Project");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);

	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// "A) Favorite Tab:
	// 1) Verify that toaster message 'Removed from Favorites' appears on marking
	// project as unfavorite"
	// BS-2895
	@Test(priority = 2)
	public void Verify_Toaster_Message_Marking_Project_Unfavorite_FavTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.ProjectPage.SearchForProject(ISBN1);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN1);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN1);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.RemoveProjectFromFavorite(ISBN1);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();

	}

	// 2) Verify that toaster message 'Added to favorites' appears on marking
	// project as favorite
	// BS-2895
	@Test(priority = 3)
	public void Verify_Toaster_Message_Marking_Project_favorite_FavTab() {
		test.HomePage.AddProjectToFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
		test.HomePage.AddProjectToFavorite(ISBN1);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
	}

	// 3) Verify that color of toaster message appears as green on marking
	// project as favorite/unfavorite
	// BS-2895
	@Test(priority = 4)
	public void Verify_Color_Of_Favorite_Toaster_Message_FavTab() {
		test.HomePage.VerifyFavoriteMessageColor();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.RemoveProjectFromFavorite(ISBN1);
		test.HomePage.VerifyFavoriteMessageColor();
	}

	// 4) Verify that toaster message appears for 5 seconds before auto-clearing
	// while marking project as favorite/unfavorite
	// BS-2895
	@Test(priority = 5)
	public void Verify_Favorite_Toaster_Message_Appears_For_5_Seconds() {
		test.HomePage.verifyFavoriteToasterMessageAppears_For_5_Seconds();
	}

	// "B) Recently Visited Tab: // 1) Verify that toaster message 'Added to //
	// favorites' appears on marking project as favorite"
	// BS-2895
	@Test(priority = 6)
	public void Verify_Toaster_Message_Marking_Project_favorite_Recently_Visited() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.removeProjectFromFavorite();

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.removeProjectFromFavorite();

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();

		test.HomePage.AddProjectToFavoriteFromRecentlyVisited(ISBN);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
		test.HomePage.AddProjectToFavoriteFromRecentlyVisited(ISBN1);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
	}

	// 2) Verify that toaster message 'Removed from Favorites' appears on marking
	// project as unfavorite
	// BS-2895
	@Test(priority = 7)
	public void Verify_Toaster_Message_Marking_Project_Unfavorite_Recently_Visited() {
		test.HomePage.RemoveProjectFromFavoriteRecentlyVisited(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.RemoveProjectFromFavoriteRecentlyVisited(ISBN1);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 3) Verify that color of toaster message appears as green on marking
	// project as favorite/unfavorite
	// BS-2895
	@Test(priority = 8)
	public void Verify_Color_Of_Favorite_Toaster_Message_RecentlyVisited() {
		test.HomePage.VerifyFavoriteMessageColor();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.AddProjectToFavoriteFromRecentlyVisited(ISBN1);
		test.HomePage.VerifyFavoriteMessageColor();
	}

	// 4) Verify that toaster message appears for 5 seconds before auto-clearing
	// while marking project as favorite/unfavorite
	// BS-2895

	@Test(priority = 9)
	public void Verify_Favorite_Toaster_Message_Appears_For_5_Recently_Visited() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.AddProjectToFavoriteFromRecentlyVisited(ISBN);
		test.HomePage.verifyFavoriteToasterMessageAppears_For_5_Seconds();
	}

	// "C) Projects Tab 1) Verify that toaster message 'Added to favorites'
	// appears on marking project as favorite"
	// BS-2895
	@Test(priority = 10)
	public void Verify_Toaster_Message_Marking_Project_favorite_ProjectsTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.AddProjectsToFavorite("1");
		test.ProjectPage.verifyMessageDisplayedOnFavoriteAdded();
	}

	// 2) Verify that toaster message 'Removed from Favorites' appears on marking
	// project as unfavorite
	// BS-2895
	@Test(priority = 11)
	public void Verify_Toaster_Message_Marking_Project_Unfavorite_ProjectsTab() {
		test.ProjectPage.RemoveProjectFromFavorite();
	}

	// 3) Verify that color of toaster message appears as green on marking
	// project as favorite/unfavorite
	// BS-2895
	@Test(priority = 12)
	public void Verify_Color_Of_Favorite_Toaster_Message_ProjectsTab() {
		test.ProjectPage.VerifyFavoriteMessageColor();
		test.ProjectPage.waitForLoaderToDisappear();
		test.ProjectPage.AddProjectsToFavorite("1");
		test.ProjectPage.VerifyFavoriteMessageColor();
	}

	// 4) Verify that toaster message appears for 5 seconds before auto-clearing
	// while marking project as favorite/unfavorite
	// BS-2895
	@Test(priority = 13)
	public void Verify_Favorite_Toaster_Message_Appears_For_5_ProjectsTab() {
		test.ProjectPage.verifyFavoriteToasterMessageAppears_For_5_Seconds();
	}

	// "D) Generic Search> 'All Types' & 'Projects'
	// 1) Verify that toaster message 'Added to favorites' appears on marking
	// project as favorite
	// BS-2895
	@Test(priority = 14)
	public void Verify_Toaster_Message_Marking_Project_favorite_Generic_Search_All_Types_Projects() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.AddProjectToFavoriteFromContentTabListView(ISBN);
		test.Contentpage.verifyMessageDisplayedOnFavoriteAdded();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSearchType(SearchTypeProject);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN1);
		test.Contentpage.AddProjectToFavoriteFromContentTabListView(ISBN1);
		test.Contentpage.verifyMessageDisplayedOnFavoriteAdded();

	}

	// 2) Verify that toaster message 'Removed from Favorites' appears on marking
	// project as unfavorite
	// BS-2895
	@Test(priority = 15)
	public void Verify_Toaster_Message_Marking_Project_Unfavorite_Generic_Search_All_Types_Projects() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.removeProjectToFavoriteFromContentTabListView(ISBN);
		test.Contentpage.verifyMessageDisplayedOnFavoriteRemoved();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSearchType(SearchTypeProject);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN1);
		test.Contentpage.removeProjectToFavoriteFromContentTabListView(ISBN1);
		test.Contentpage.verifyMessageDisplayedOnFavoriteRemoved();
	}

	// 3) Verify that color of toaster message appears as green on marking project
	// as favorite/unfavorite
	// BS-2895
	@Test(priority = 16)
	public void Verify_Color_Of_Favorite_Toaster_Message_Generic_Search_All_Types_Projects() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.AddProjectToFavoriteFromContentTabListView(ISBN);
		test.Contentpage.verifyMessageDisplayedOnFavoriteAdded();
		test.Contentpage.VerifyFavoriteMessageColor();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSearchType(SearchTypeProject);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN1);
		test.Contentpage.AddProjectToFavoriteFromContentTabListView(ISBN1);
		test.Contentpage.verifyMessageDisplayedOnFavoriteAdded();
		test.Contentpage.VerifyFavoriteMessageColor();
	}

	// 4) Verify that toaster message appears for 5 seconds before auto-clearing
	// while marking project as favorite/unfavorite
	// BS-2895
	@Test(priority = 17)
	public void Verify_Favorite_Toaster_Message_Appears_For_5_Sec_Generic_Search_All_Types_Projects() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.removeProjectToFavoriteFromContentTabListView(ISBN);
		test.Contentpage.verifyMessageDisplayedOnFavoriteRemoved();
		test.Contentpage.verifyFavoriteToasterMessageAppears_For_5_Seconds();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSearchType(SearchTypeProject);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN1);
		test.Contentpage.removeProjectToFavoriteFromContentTabListView(ISBN1);
		test.Contentpage.verifyMessageDisplayedOnFavoriteRemoved();
		test.Contentpage.verifyFavoriteToasterMessageAppears_For_5_Seconds();
	}

	// "E) Advanced Search> ‘Projects' & 'Assets and Projects’
	// 1) Verify that toaster message 'Added to favorites' appears on marking
	// project as favorite"
	// BS-2895
	@Test(priority = 18)
	public void Verify_Toaster_Message_Marking_Project_favorite_AdvanceSearch() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.enterTextFilterSearchBar(ISBN1);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.AddProjectToFavorite(ISBN1);
		test.SearchPage.verifyMessageDisplayedOnFavoriteAdded();

		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.enterTextFilterSearchBar(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.AddProjectToFavorite(ISBN);
		test.SearchPage.verifyMessageDisplayedOnFavoriteAdded();
	}

	// 2) Verify that toaster message 'Removed from Favorites' appears on marking
	// project as unfavorite
	// BS-2895
	@Test(priority = 19)
	public void Verify_Toaster_Message_Marking_Project_Unfavorite_AdvanceSearch() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.enterTextFilterSearchBar(ISBN1);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.removeProjectFromFavorite(ISBN1);
		test.SearchPage.verifyMessageDisplayedOnFavoriteRemoved();

		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.enterTextFilterSearchBar(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.removeProjectFromFavorite(ISBN);
		test.SearchPage.verifyMessageDisplayedOnFavoriteRemoved();
	}

	// 3) Verify that color of toaster message appears as green on marking project
	// as favorite/unfavorite
	// BS-2895
	@Test(priority = 20)
	public void Verify_Color_Of_Favorite_Toaster_Message_AdvanceSearch() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.enterTextFilterSearchBar(ISBN1);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.AddProjectToFavorite(ISBN1);
		test.SearchPage.VerifyFavoriteMessageColor();
		test.SearchPage.removeProjectFromFavorite(ISBN1);
		test.SearchPage.VerifyFavoriteMessageColor();
	}

	// 4) Verify that toaster message appears for 5 seconds before auto-clearing
	// while marking project as favorite/unfavorite
	// BS-2895
	@Test(priority = 21)
	public void Verify_Favorite_Toaster_Message_Appears_For_5_Sec_AdvanceSearch() {
		test.refreshPage();
		test.SearchPage.waitForLoaderToDisappear();
		test.SearchPage.AddProjectToFavorite(ISBN1);
		test.SearchPage.verifyFavoriteToasterMessageAppears_For_5_Seconds();
	}

	// "F) Project View Page:
	// 1) Verify that toaster message 'Added to favorites' appears on marking
	// project as favorite"
	// BS-2895
	@Test(priority = 22)
	public void Verify_Toaster_Message_Marking_Project_favorite_ProjectView() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();

		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.AddProjectToFavorite();
	}

	// 2) Verify that toaster message 'Removed from Favorites' appears on marking
	// project as unfavorite
	// BS-2895
	@Test(priority = 23)
	public void Verify_Toaster_Message_Marking_Project_Unfavorite_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.removeProjectFromFavorite();
	}

	// 3) Verify that color of toaster message appears as green on marking project
	// as favorite/unfavorite
	// project as unfavorite
	// BS-2895
	@Test(priority = 24)
	public void Verify_Color_Of_Favorite_Toaster_Message_ProjectView() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.AddProjectToFavorite();
		test.projectView.VerifyFavoriteMessageColor();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.removeProjectFromFavorite();
		test.projectView.VerifyFavoriteMessageColor();
	}

	// 4) Verify that toaster message appears for 5 seconds before auto-clearing
	// while marking project as favorite/unfavorite
	// BS-2895
	@Test(priority = 25)
	public void Verify_Favorite_Toaster_Message_Appears_For_5_Sec_ProjectView() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.AddProjectToFavorite();
		test.projectView.verifyFavoriteToasterMessageAppears_For_5_Seconds();
	}

	

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
