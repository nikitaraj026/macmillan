package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import java.lang.reflect.Method;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;


public class Debugging  extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String ISBN, TypesOfContentEnhancedEpub, ISBN1, ProjectTitle;
	String SecondUserEmail;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		ISBN1 = getData("ProjectISBNNo1");
		ProjectTitle = getData("ProjectTitle1");
		SecondUserEmail = getData("PasswordResetAccount.email");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}


	// 1.Verify that a user gets landed on 'Dashboard' tab after a successful login
	// into the application
	@Test(priority = 1)
	public void Verify_That_User_Landed_On_Dashboard_After_login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.DashBordIsDisplayed();
	}
	
	// 1."A) Recently Visited> Projects> List view:
		// 1) Verified that following Column Headers are available in the Recently
		// visited table
		// a) Grayed out checkbox
		// b) Folder icon
		// c) Favorite Star icon
		// d) Author
		// e) Title
		// f) Short Title
		// g) ISBN
		// h) Content Type(Blank for Projects)
		// i) Repository(Blank for Projects)
		// j) Last Modified Date"
		// BS-2197
		@Test(priority = 2)
		public void Verify_Proper_Coloumn_Header_In_Recently_Visisted_Table() {
			test.HomePage.clickProjectTab();
			test.ProjectPage.VerifyOnProjectPage();
			test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
			test.projectView.verifyOnProjectView();
			test.projectView.ClickOpenAssetOnProjectView(ISBN + ".epub", TypesOfContentEnhancedEpub);
			test.ContentView.VerifyOnContentViewPage();
			test.HomePage.ClickDashBord();
			test.HomePage.DashBordIsDisplayed();
			test.HomePage.VerifyRecentlyVisitedTabIsDisplayed();
			test.HomePage.clickRecentlyVisited();
			test.HomePage.Verify_Coloums_On_RecentlyVisited();
			test.HomePage.VerifyCheckBoxGrayedOutOnRecently();
			test.HomePage.VerifyFolderIconForProject(ISBN);
			test.HomePage.VerifyStarIconForProjectRecentlyVisited(ISBN);
			test.HomePage.VerifyContentTypeNotDisplayedForProject(ISBN);
			test.HomePage.verifyRepositoryNotDisplayedForProject(ISBN);
		}

		// 2."A) Recently Visited> Projects> List view:
		// 2) Verified that the Project that is last visited by user gets added in the
		// Recently visited table and the latest one appear on the top."
		// BS-2197
		@Test(priority = 3)
		public void Verify_Visited_Project_is_Displayed_On_Recently_Visited_Table() {
			test.HomePage.clickProjectTab();
			test.ProjectPage.VerifyOnProjectPage();
			test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
			test.projectView.verifyOnProjectView();
			test.HomePage.ClickDashBord();
			test.HomePage.DashBordIsDisplayed();
			test.HomePage.clickRecentlyVisited();
			test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(ISBN);

			test.HomePage.clickProjectTab();
			test.ProjectPage.VerifyOnProjectPage();
			test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
			test.projectView.verifyOnProjectView();
			test.projectView.AddProjectToFavorite();
			test.HomePage.ClickDashBord();
			test.HomePage.DashBordIsDisplayed();
			test.HomePage.clickRecentlyVisited();
			test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(ISBN1);
			
			test.HomePage.ClickContentTab();
			test.Contentpage.VerifyOnContentTab();
			test.Contentpage.SearchForAnItem(ISBN + ".epub");
			test.Contentpage.opentheSearchContent(ISBN + ".epub");
			test.ContentView.VerifyOnContentViewPage();
			test.HomePage.ClickDashBord();
			test.HomePage.DashBordIsDisplayed();
			test.HomePage.clickRecentlyVisited();
			test.HomePage.clickGridView();
			test.HomePage.VerifyContentDisplayedOnRecentlyVisitedGridView(ISBN + ".epub");
		}

		// 3."A) Recently Visited> Projects> List view:
		// 3) Verified that user is able to mark/unmark the Projects as Favorite from
		// Recently visited table and corresponding message notification is displayed
		// for the same (currently user needs to refresh the page to see the changes). "
		// BS-2197
		@Test(priority = 4)
		public void Verify_User_Able_To_Mark_Project_Favorite_Or_Unfavorite() {
			test.HomePage.RemoveProjectFromFavoriteRecentlyVisited(ISBN1);
			test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
			test.HomePage.AddProjectToFavoriteFromRecentlyVisited(ISBN1);
			test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
		}

		// 4."A) Recently Visited> Projects> List view:
		// 5) Verified that tool tip is available for the ellipsis cases."
		// BS-2197
		@Test(priority = 5)
		public void Verify_Tool_Tip_For_Project_List_View() {
			test.HomePage.verifyToolTipDisplayedOnRecentlyVisitedTableListView();
		}

		// 5."A) Recently Visited> Projects> List view:
		// 6) Verified that user can navigate to Projects view page on clicking the
		// Hyperlinked row."
		// BS-2197
		@Test(priority = 6)
		public void Verify_User_Navigate_To_Project_view_Clicking_Row() {
			test.HomePage.OpenProjectDisplayedOnRecentlyVisited(ISBN1);
			test.projectView.verifyOnProjectView();
		}

	// 11."C) Recently Visited> Contents> List view:
		// 1) Verified that following Column Headers are available in the Recently
		// visited table- Pass
		// a) Grayed out checkbox
		// b) File icon
		// c) Favorite Star icon - Blank for Content
		// d) Author - Blank for Content
		// e) Title
		// f) Short Title - Blank for Content
		// g) ISBN - Blank for Content
		// h) Content Type
		// i) Repository
		// j) Last Modified Date"
		// BS-2197
		@Test(priority = 12)
		public void Verify_Proper_Information_On_List_View_Content() {
			test.refreshPage();
			test.HomePage.waitForLoaderToDisappear();
			test.HomePage.ClickDashBord();
			test.HomePage.DashBordIsDisplayed();
			test.HomePage.clickRecentlyVisited();
			test.HomePage.VerifyCheckBoxGrayedOutOnRecently();
			test.HomePage.VerifyFileIconForContent(ISBN + ".epub");
			test.HomePage.VerifyStarIconNotDisplayedForAsset(ISBN + ".epub");
			test.HomePage.VerifyAuthorNameNotDisplayedForContent(ISBN + ".epub");
			test.HomePage.VerifyTitleDisplayedOnRecentlyVisited();
			test.HomePage.VerifyShortTitleNotDisplayedForContent(ISBN + ".epub");
			test.HomePage.VerifyISBNNotDisplayedForContent(ISBN + ".epub");
			test.HomePage.VerifyContentTypeDisplayedForContent(ISBN + ".epub");
			test.HomePage.VerifyLastModifiedDateDisplayedForContent(ISBN + ".epub");
		}
}
