package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.CustomFunctions.getDateString_MM_dd_yyyy;
import static com.qait.automation.utils.FTPUtil.closesFTPConnection;
import static com.qait.automation.utils.FTPUtil.createsFTPConnectionWithOutPortNumber;
import static com.qait.automation.utils.FTPUtil.fetchFileNameFromFTP;
import static com.qait.automation.utils.FTPUtil.uploadSingleFile;
import static com.qait.automation.utils.XmlParser.SaveChangesToXML;
import static com.qait.automation.utils.XmlParser.UpdateXMLAttribute;
import static com.qait.automation.utils.XmlParser.setXmlFile;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_Retain_Metadata_Values extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String TestISBN, CMSDefaultUser, RamdomEmail, ProjectModifiedDate;
	String FTPUrl,FTPHostName,FtpPassword,FolderKlopotek,DestinationXML, SourceXML,NewXmlFileName;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestISBN = getData("ProjectISBNNO");
		CMSDefaultUser = "cms.user@macmillan.com";
		RamdomEmail = getStringWithDateAndTimes("Automation") + "@ABC.com";
		FTPUrl=getData("HotFolderUserDetail.FTPUrl");
		FTPHostName=getData("HotFolderUserDetail.HostName");
		FtpPassword=getData("HotFolderUserDetail.Password");
		FolderKlopotek=getData("FTPFolders.klopotek");
		SourceXML = System.getProperty("user.dir") + getData("HotFolderXMLFiles.ProjectCreationXml");
		DestinationXML = System.getProperty("user.dir") + getData("HotFolderXMLFiles.SaveXmlLocation");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1) Verify that 'Modified By' field under system metadata for Project is
	// displaying as: cms.user@macmillan.com
	// BS-3340
	@Test(priority = 2)
	public void Verify_Modified_By_Option_Is_Displayed_As_Default_User() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		ProjectModifiedDate = test.projectView.GetProjectModifiedDate();
		test.projectView.VerifyUserEmailModifiedBy(CMSDefaultUser);
	}

	// 2) Add an email as a Project Contact and verify that 'Modified By' field
	// under system metadata for Project is still displaying as:
	// cms.user@macmillan.com instead of the user who has added the email.
	// 3) Verify that 'Date Modified' field under system metadata for Project is not
	// getting updated with the change made in #2
	// BS-3340
	@Test(priority = 3)
	public void Verify_Modified_By_Option_Is_Displayed_As_Default_User_Adding_Email() {
		test.projectView.clickProjectDetails();
		test.projectView.AddEmailAddress(RamdomEmail);
		test.projectView.VerifyEmailIsAdded(RamdomEmail);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyUserEmailModifiedBy(CMSDefaultUser);
		test.projectView.VerifyProjectDateModified(ProjectModifiedDate);
	}

	// 4) Remove an email from a Project Contact and verify that 'Modified By' field
	// under system metadata for Project is still displaying as:
	// cms.user@macmillan.com instead of the user who has removed the email.
	// 5) Verify that 'Date Modified' field under system metadata for Project is not
	// getting updated with the change made in #4.
	// BS-3340
	@Test(priority = 4)
	public void Verify_Modified_By_Option_Is_Displayed_As_Default_User_Deletes_Email() {
		test.projectView.clickProjectDetails();
		test.projectView.RemoveEmailFormProjectDetail(RamdomEmail);
		test.projectView.VerifyEmailNotDisplayedOnProjectDetail(RamdomEmail);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.VerifyUserEmailModifiedBy(CMSDefaultUser);
		test.projectView.VerifyProjectDateModified(ProjectModifiedDate);
	}

	// 6) Verify that 'Date Modified' field is getting updated only when feed from
	// Klopotek is received.
	@Test(priority = 5)
	public void Verify_Date_Modified_Only_When_Klopotek_Feed_Received() {
		setXmlFile(SourceXML);
		UpdateXMLAttribute("BS", "ISBN", TestISBN);
		UpdateXMLAttribute("BS", "subtitle", getStringWithDateAndTimes("newSubtitle"));
		NewXmlFileName=getStringWithDateAndTimes("Project XML")+".xml";
		DestinationXML=DestinationXML+NewXmlFileName;
		SaveChangesToXML(DestinationXML);
		createsFTPConnectionWithOutPortNumber(FTPUrl);
		fetchFileNameFromFTP(FTPHostName,FtpPassword,FolderKlopotek);
		uploadSingleFile(DestinationXML, "/"+FolderKlopotek+"/"+NewXmlFileName);
		test.HotFolder.waitForFileToPickedUpByScheduler(FolderKlopotek, NewXmlFileName);
		closesFTPConnection();
		
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.VerifyProjectDateModified(getDateString_MM_dd_yyyy());
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
