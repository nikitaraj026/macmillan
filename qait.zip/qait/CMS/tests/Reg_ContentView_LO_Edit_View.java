package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

public class Reg_ContentView_LO_Edit_View extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String ISBN, ContentTypeImageSource, UploadFileTitle, FrameworkIntroductoryBiology;
	String LearningObjectiveStatement, CoverDesignFile, ContentTypeCoverDesign, CoverDesignTitle;
	String PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationInstructorStore;
	String PublihDestinationVitalSource;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
		UploadFileTitle = "SampleImageForAutomation";
		FrameworkIntroductoryBiology = getData("Framework.Introductory Biology");
		LearningObjectiveStatement = getData("LOS.Introductory Biology");
		CoverDesignFile = getData("TestData.ImageFile");
		ContentTypeCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		CoverDesignTitle = getStringWithDateAndTimes("AutoCoverDesign");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step1:: Upload An Sample Asset For Testing
	@Test(priority = 2)
	public void Upload_Sample_Asset_For_Test() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(ISBN + "_FC.jpg");
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(UploadFileTitle);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
	}

	// 1.Verify that only Content Details tab and Learning Objectives tab are
	// available in Edit mode.
	@Test(priority = 3)
	public void Verify_Content_Details_And_Learning_Objectives_Tab_On_Edit_Window() {
		test.ContentView.ClickEditLink();
		test.ContentView.VerifyLearningObjectiveTabDisplayed();
		test.ContentView.VerifyContentDetailsTabDisplayed();
		test.ContentView.VerifyPublishDetailsTabNotDisplayed();
		test.ContentView.VerifyPublishDetailsTabNotDisplayed();
	}

	// 2.Verify that Learning Objectives functionality is working On Edit Mode
	@Test(priority = 4)
	public void Verify_Learning_Objectives_Functionality_On_Edit() {
		test.ContentView.clickLearningObjectives();
		test.ContentView.LearningObjectiveFrameworkSectionIsDisplayed();
		test.ContentView.AddLearningObjective(FrameworkIntroductoryBiology);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.AddLearningObjectiveStatement(LearningObjectiveStatement);
		test.ContentView.VerifyMessageDispalyedOnAddingLearningObjectiveStatement();
		test.ContentView.VerifyLearningObjectiveStatementAdded(LearningObjectiveStatement);
		test.ContentView.RemoveLOS_Statement(LearningObjectiveStatement);
		test.ContentView.VerifyMessageDispalyedOnRemovingLearningObjectiveStatement();
		test.ContentView.RemoveFameworkFromContentWithoutMessage(FrameworkIntroductoryBiology);
		test.ContentView.VerifyMessageDispalyedOnRemovingFamework();
		test.ContentView.AddLearningObjective(FrameworkIntroductoryBiology);
		test.ContentView.VerifyFrameworkAddedMessageDisplayed();
		test.ContentView.VerifyDoneButtonOnLearningObjectiveTab();
		test.ContentView.ClickDoneButtonOnLearningObjectiveTab();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.clickLearningObjectives();
		test.ContentView.VerifyFrameWorkIsAddedToTheContent(FrameworkIntroductoryBiology);
	}

	// Upload an CoverDesign
	@Test(priority = 5)
	public void Upload_Cover_Design_For_Test() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(CoverDesignFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeCoverDesign);
		test.HomePage.EnterTextIntoTitleField(CoverDesignTitle);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
	}

	// 3.Verify for Cover Design Content type (CMS/DAM) Content view page> Publish
	// Modal, the Publish button at the bottom has been made disabled ONLY when the
	// Publish destination is 'Instructor Store'.
	@Test(priority = 6)
	public void Verify_For_Cover_Design_Publish_Button_Disabled_For_InstructorStore() {
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifyPublishButtonEnabled();

		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.VerifyPublishButtonEnabled();

		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.VerifyPublishButtonEnabled();

		test.ContentView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.ContentView.VerifyPublishButtonDisabled();
		test.ContentView.ClickX_OnWindow();
	}

	// Delete the Uploaded Test Data
	@Test(priority = 7)
	public void Delete_Test_Data_From_Application() {
		test.Contentpage.SearchForAnItem(CoverDesignTitle);
		test.Contentpage.SelectContentOnContentTab(CoverDesignTitle,ContentTypeCoverDesign);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
