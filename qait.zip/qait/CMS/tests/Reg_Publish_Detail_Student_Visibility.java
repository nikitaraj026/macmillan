package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

public class Reg_Publish_Detail_Student_Visibility extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, SampleChapterFile;
	String SampleChapterTitle, ContentTypeSampleChapter, TestISBN, EnhancedEpubFile, TypesOfContentEnhancedEpub;
	String EnhancedEpubTitle, PublihDestinationCoreSource, PublihDestinationPalgrave, PublihDestinationInstructorStore;
	String PublihDestinationVitalSource, PublihDestinationCourseWare, VisibleToStudents, NotVisibleToStudents;
	String TestImage1,TestImage2,TestImage3,TestImage4,ImageFile,ContentTypeImageSource,PageSelectionAllPages;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		SampleChapterFile = getData("TestData.TestPDF2");
		SampleChapterTitle = getStringWithDateAndTimes("AutoSampleChapter");
		ContentTypeSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		TestISBN = getData("ProjectISBNNo2");
		EnhancedEpubFile = getData("TestData.EnhancedEpub");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		EnhancedEpubTitle = getStringWithDateAndTimes("AutomationEpub");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		VisibleToStudents = getData("Visibility.Visible to Students");
		NotVisibleToStudents = getData("Visibility.Not Visible to Students");
		ImageFile=getData("TestData.ImageFile");
		ContentTypeImageSource=getData("TypesOfContent.Images>Image Source");
		PageSelectionAllPages = getData("PageSelection.All Pages");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Setup Sample Chapter and Enhanced Epub on Project
	@Test(priority = 2)
	public void Setup_TestData_On_Project() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(SampleChapterFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeSampleChapter);
		test.HomePage.EnterTextIntoTitleField(SampleChapterTitle);
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.AddTheContentToAProjectOfISBN(TestISBN);

		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(EnhancedEpubFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.EnterTextIntoTitleField(EnhancedEpubTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		
		TestImage1=getStringWithDateAndTimes("AutoImageForTest1");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(ImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(TestImage1);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		
		TestImage2=getStringWithDateAndTimes("AutoImageForTest2");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(ImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(TestImage2);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		
		TestImage3=getStringWithDateAndTimes("AutoImageForTest3");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(ImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(TestImage3);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		
		TestImage4=getStringWithDateAndTimes("AutoImageForTest4");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(ImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(TestImage4);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		
	}

	// 1.Verified that ‘Files’ link is appearing under ‘File Name/ ISBN’ column
	// header of Publish History table under Publish details tab in Project View.
	// BS-3126
	@Test(priority = 3)
	public void Verify_File_Link_In_Publish_Detail_Tab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				EnhancedEpubTitle,true);
		test.projectView.Select_Assert_Displayed_In_Step3(EnhancedEpubFile);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.clickXButtonUploadContent();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationVitalSource);
		test.projectView.VerifyFilesLinkDisplayedInPublishDetail();
	}

	// 2.Verified that clicking the ‘Files’ link opens the pop window with header
	// Published File(s) Data
	// BS-3126
	@Test(priority = 3)
	public void Verify_File_Link_Opens_Window_with_file_Data() {
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(EnhancedEpubTitle);
		test.projectView.VerifyFileNamePublishedInPublishDetail(EnhancedEpubFile);
	}

	// 3."Verified that when Publish action is performed on Palgrave, Instructor
	// Store, CoreSource and VitalSource destination, then the table under
	// 'Published File(s) Details' displays two column headers as:
	// a) Asset Title
	// b) File Name "
	// BS-3126
	@Test(priority = 3)
	public void Verify_Two_Coloum_Header_For_Publish_Destination() {
		test.projectView.VerifyPublishedFileDetailHeaders();
		test.projectView.VerifyVisibilityMetadataHeaderNotDisplayed();
		test.projectView.ClickCloseButton();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				EnhancedEpubTitle,true);
		test.projectView.Select_Assert_Displayed_In_Step3(EnhancedEpubFile);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.clickXButtonUploadContent();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationPalgrave);
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyPublishedFileDetailHeaders();
		test.projectView.VerifyVisibilityMetadataHeaderNotDisplayed();
		test.projectView.ClickCloseButton();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeSampleChapter,
				SampleChapterTitle,true);
		test.projectView.Select_Assert_Displayed_In_Step3(SampleChapterFile);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.clickXButtonUploadContent();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationInstructorStore);
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyPublishedFileDetailHeaders();
		test.projectView.VerifyVisibilityMetadataHeaderNotDisplayed();
		test.projectView.ClickCloseButton();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				EnhancedEpubTitle,true);
		test.projectView.Select_Assert_Displayed_In_Step3(EnhancedEpubFile);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.clickXButtonUploadContent();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationVitalSource);
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyPublishedFileDetailHeaders();
		test.projectView.VerifyVisibilityMetadataHeaderNotDisplayed();
		test.projectView.ClickCloseButton();
	}

	// 4." Verified that when Publish action is performed on Courseware destination,
	// then the table under 'Published File(s) Details' displays three column
	// headers as:
	// a) Asset Title
	// b) File Name
	// c) Visibility Metadata"
	// BS-3126
	@Test(priority = 4)
	public void Verify_Three_Coloum_Header_For_Courseware_Destination() {
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", TypesOfContentEnhancedEpub,
				EnhancedEpubTitle);
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToStudentResource();
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyMessageOnAddingVisibleToStudent();
		test.projectView.ClickManualPublish();
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				EnhancedEpubTitle,true);
		test.projectView.Select_Assert_Displayed_In_Step3(EnhancedEpubFile);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.clickXButtonUploadContent();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCourseWare);
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyPublishedFileDetailHeaders();
		test.projectView.VerifyVisibilityMetadataHeaderIsDisplayed();
	}

	// 5.Verified that correct Asset Title, File name and Visibility Metadata is
	// getting captured in the ‘Published File(s) Details’ table.
	// BS-3126
	@Test(priority = 5)
	public void Verify_Correct_AssetTitle_FileName_Visibility_in_Published_File() {
		test.projectView.VerifyAssetTiltePublishedInPublishDetail(EnhancedEpubTitle);
		test.projectView.VerifyFileNamePublishedInPublishDetail(EnhancedEpubFile);
		test.projectView.VerifyVisibilityOfAssetOnPublishedFileDetailPopup(EnhancedEpubTitle, VisibleToStudents);
	}

	// 6."Depending upon the Visibility state of the Published asset, following is
	// displayed under 'Visibility Metadata' column header:
	// When Student Visibility is True: Visible to Students
	// When Student Visibility is False: Not Visible to Students "
	// BS-3126
	@Test(priority = 6)
	public void Verify_Correct_Visibility_Metadata_Displayed() {
		test.projectView.VerifyVisibilityOfAssetOnPublishedFileDetailPopup(EnhancedEpubTitle, VisibleToStudents);
		test.projectView.ClickCloseButton();

		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", ContentTypeSampleChapter,
				SampleChapterTitle);
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.VerifyAssertAreAddedToStudentResource();
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyMessageOnAddingNotVisibleToStudent();
		test.projectView.ClickManualPublish();
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeSampleChapter,
				SampleChapterTitle,true);
		test.projectView.Select_Assert_Displayed_In_Step3(SampleChapterFile);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.clickXButtonUploadContent();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCourseWare);
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyVisibilityOfAssetOnPublishedFileDetailPopup(SampleChapterTitle, NotVisibleToStudents);
	}

	// 7.Verify that a maximum of 05 asset details are getting captured in the
	// 'Published File(s) Details' table and if the published asset count is more
	// than 05, then pagination comes into picture.
	// BS-3126
	@Test(priority = 7)
	public void Verify_Pagination_For_More_Than_5_Asset() {
		test.projectView.VerifyPaginationBarNotDisplayedOnPublishFilePopup();
		test.projectView.ClickCloseButton();
		
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage1,true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage2,false);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage3,false);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage4,false);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				EnhancedEpubTitle,true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCoreSource);
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyCountOfFileDisplayedOnPublishedFile(5);
		test.projectView.VerifyPaginationBarNotDisplayedOnPublishFilePopup();
		test.projectView.ClickCloseButton();
		
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage1,true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage2,false);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage3,false);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeImageSource,
				TestImage4,false);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentEnhancedEpub,
				EnhancedEpubTitle,true);
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", ContentTypeSampleChapter,
				SampleChapterTitle,true);
		test.projectView.ClickPageSelectionDropDown();
		test.projectView.SelectPagesInStep3PublishWindow(PageSelectionAllPages);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();
		test.projectView.ClickPublishDetail();
		test.projectView.VerifyPublishWasOnCorrectDestination(PublihDestinationCoreSource);
		test.projectView.clickFilesLinkInPublishDetail();
		test.projectView.VerifyPublishFilePopUpDisplayed();
		test.projectView.VerifyPaginationBarIsDisplayedOnPublishFilePopup();
		test.projectView.ClickCloseButton();
	}
	
	//Delete the Uploaded Test Data
	@Test(priority=8)
	public void Delete_Test_Data_From_Application() {
		test.Contentpage.SearchForAnItem(SampleChapterTitle);
		test.Contentpage.SelectContentOnContentTab(SampleChapterTitle,ContentTypeSampleChapter);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.Contentpage.SearchForAnItem(TestImage1);
		test.Contentpage.SelectContentOnContentTab(TestImage1,ContentTypeImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.Contentpage.SearchForAnItem(TestImage2);
		test.Contentpage.SelectContentOnContentTab(TestImage2,ContentTypeImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.Contentpage.SearchForAnItem(TestImage3);
		test.Contentpage.SelectContentOnContentTab(TestImage3,ContentTypeImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.Contentpage.SearchForAnItem(TestImage4);
		test.Contentpage.SelectContentOnContentTab(TestImage4,ContentTypeImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
