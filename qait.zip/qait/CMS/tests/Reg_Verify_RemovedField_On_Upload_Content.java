package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Verify_RemovedField_On_Upload_Content extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DAMLink;
	String ISBN, ContentTypeImageSource;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());

	}

	// LogIn into Application
	@Test(priority = 1)
	public void LogIn_Into_Application() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1."Dashboard> Upload Content::Verified that following fields have been
	// removed from the 'Upload Content' pop-up window:
	// a) Subject Keyword Taxonomy
	// b) Product Data
	// c) Relationship Type
	// d) Relationship Target
	// e) Relationship URI"
	// BS-2997
	@Test(priority = 2)
	public void Verify_Removed_Field_On_Upload_Content_Window_Dashboard() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.Verify_Removed_Field_From_Upload_Content_Window();
	}

	// 2."Dashboard> Upload Content::Verified that following fields are available by
	// default on the 'Upload Content' pop-up window:
	// a) Select File with 'Browse' button
	// b) Content Type
	// c) Title
	// d) Description
	// e) Projects with 'Add/ Remove Projects' button
	// f) Upload button"
	// BS-2997
	@Test(priority = 3)
	public void Verify_Fields_On_Upload_Content_Window_Dashboard() {
		test.HomePage.VerifyBrowseButton();
		test.HomePage.VerifyVariousFieldsInUploadContentPopUp();

	}

	// 3."Project view> Upload Content:: Verified that following fields have been
	// removed from the 'Upload Content' pop-up window:
	// a) Subject Keyword Taxonomy
	// b) Product Data
	// c) Relationship Type
	// d) Relationship Target
	// e) Relationship URI"
	// BS-2997
	@Test(priority = 4)
	public void Verify_Removed_Field_On_Upload_Content_Window_ProjectView() {
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.Verify_Removed_Field_From_Upload_Content_Window();

	}

	// 4."Project view> Upload Content::Verified that following fields are available
	// by default on the 'Upload Content' pop-up window:
	// a) Select File with 'Browse' button
	// b) Content Type
	// c) Title
	// d) Description
	// e) Projects with 'Add/ Remove Projects' button
	// f) Upload button"
	// BS-2997
	@Test(priority = 5)
	public void Verify_Fields_On_Upload_Content_Window_ProjectView() {
		test.projectView.VerifyBrowseButton();
		test.projectView.VerifyVariousFieldsInUploadContentPopUp();
	}

	// 5.Verified that user is successfully able to upload any asset via Upload
	// Content pop-up window.
	// BS-2997
	@Test(priority = 5)
	public void Verify_User_Is_Able_To_Upload_Content() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(ISBN + "_FC.jpg");
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField("AutomationUploadTest");
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
		
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectFileUsingBrowseButton(ISBN + "_FC.jpg");
		test.projectView.SelectContentTypeInUploadContentPopup(ContentTypeImageSource);
		test.projectView.EnterTextIntoTitleField("AutomationUploadTest");
		test.projectView.ClickUploadOnUploadContentPopUpAndVerifyMsg();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
