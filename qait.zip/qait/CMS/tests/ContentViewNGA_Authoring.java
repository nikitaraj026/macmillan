package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.awt.HeadlessException;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class ContentViewNGA_Authoring extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN;
	String PushToAuthoringHttpLinks, TestImageforNGA, ContentTypeImageSource, AssetURl, FileTitle;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		PushToAuthoringHttpLinks = getData("PushToAuthoringTool.Https link");
		TestImageforNGA = "AutoMation NGA_!@#$%ÀÁÂÃÄÅ.jpg";
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
		AssetURl = getData("AssetURL");
		FileTitle = "NGA Automation Test";
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutFromApplication() {

		test.HomePage.LogoutFromApplication();
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Upload Image for NGA Test
	@Test(priority = 2)
	public void Upload_Image_For_NGA_Test() {
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
	}
	
	

	// 1.Verify that Lumina rights section is now hyperlinked i.e. user can navigate
	// to lumina page after clicking on the values
	@Test(priority = 3)
	public void Verify_Lumina_Rights_Section_Is_Now_Hyperlinked() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickLuminaRightDetail();
		test.ContentView.HoverAndClickLuminaSection();
		test.ContentView.VerifyCorrectRightDetailMsgIsDisplayed();
	}

	// 2.Verify that NGA Authoring option is available in Step 1
	@Test(priority = 4)
	public void Verify_NGA_Authoring_Option_In_Step1() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringHttpLinks);
	}

	// 3.Verify that as soon as user has selected this option, Step 3 gets
	// disappeared
	@Test(priority = 5)
	public void Verify_Step3_Disappered_As_NGA_Authoring_Selected() {
		test.ContentView.VerifyStep3LabelOfPushToAuthoringToolNotDisplayed();
	}

	// 4.Verify that user is able to push the asset to NGA authoring platform and
	// success message is displayed for the same.
	@Test(priority = 6)
	public void Verify_User_Is_Able_To_Push_Asset_To_NGA_Authoring_Platform() {
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
	}

	// 5."Verify that 'Authoring Platform Push Details' section is created under
	// Publish details tab with following column headers:
	// Username
	// Destination
	// Pushed Date
	// URL
	// Status along with Refresh button"
	@Test(priority = 7)
	public void Verify_Coloums_for_Authoring_Platform_Push_Details() {
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.VerifyTableHeaderForAuthoringPlatformPushDetails();
		test.ContentView.VerifyPushDetailsRefreshButton();
	}
	
	//6.Verify that asset URL gets generated as soon as user has Pushed the asset to NGA
	@Test(priority=8)
	public void Verify_Asset_URL_Gets_Generated_As_Soon_As_Pushed() {
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.VerifyURL_IsDisplayed();
		test.ContentView.ClickX_OnWindow();
	}

	// 7.Verify that asset URL gets generated when the Push action gets completed
	@Test(priority = 9)
	public void Verify_Asset_URL_Gets_Generates_When_Push_Completes() {
		test.ContentView.VerifyNGAPushOperationCompletes();
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.VerifyURL_IsDisplayed();
	}

	// 8.Verify that asset URL is now encoded for Special Characters/ unicode
	// characters/ Spaces and Content ID has been added in the link to make it
	// unique
	@Test(priority = 10)
	public void Verify_Asset_URL_Encoded_For_Special_Unicode_Characters() {
		test.ContentView.VerifyAssertURLEncoded(AssetURl);
		test.ContentView.ClickX_OnWindow();
	}

	// 9.Verify that user is able to copy the link by clicking the icon present to
	// the left of it
	@Test(priority = 11)
	public void Verify_User_Is_Able_To_Copy_The_Link_From_Icon()
			throws HeadlessException, UnsupportedFlavorException, IOException {
		test.ContentView.CopyAssetUrlFromIconAndVerify();
	}

	// 10."Verify that following entry is updated in the content history table:
	// Push To NGA Authoring Asset URL"
	@Test(priority = 12)
	public void Verify_Content_History_Table_updates_For_NGA_push() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentHistoryTableActionUpdated("Push to https link");
	}

	// Delete the Test Image Uploaded
	@Test(priority = 13)
	public void Delete_Test_Image() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
