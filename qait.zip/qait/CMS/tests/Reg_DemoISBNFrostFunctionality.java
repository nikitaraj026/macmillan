package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_DemoISBNFrostFunctionality extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String ProjectISBN, ProjectTitle, FrostEmail, FrostPassword, ProjectISBN1;
	String FrostLink, ProjectTitle1, DemoISBN, NonStandardMsg;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ProjectISBN = getData("ProjectISBNNo2");
		ProjectTitle = getData("ProjectTitle2");
		ProjectISBN1 = getData("ProjectISBNNo1");
		ProjectTitle1 = getData("ProjectTitle1");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		FrostLink = getData("Link.Frost");
		DemoISBN = getStringWithDateAndTimes("TestISBN");
		NonStandardMsg = getData("NonStandardMsg");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that ePub file sent as an additional content to the Dummy ISBN
	// Project which is already present in Frost retains its File Name and displays
	// the same under Additional Content section (i.e. File Name is displayed
	// instead of base ISBN) when Pushed via Project view window : Retain CSS
	// BS-2106
	@Test(priority = 2)
	public void Verify_Additional_Epub_Send_To_DemoISBN_Frost_Displayed_For_RetainCSS_Option() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectRetainCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.VerifyNonStandardProjectMessage(DemoISBN, NonStandardMsg);
		test.projectView.ClickYESNoForDemoISBN("Yes");
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.projectView.verifyOnProjectView();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectRetainCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN1 + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN1 + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(DemoISBN);
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.logMessage("Waiting for " + DemoISBN + " to be created at frost end....");
		test.projectView.hardWait(130); /// waiting for File To be Created at Frost.

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.OpenProjectOnFrost(DemoISBN);
		test.projectView.verifyAdditionalFileInFrost(DemoISBN);
	}

	// Delete Project From Frost
	@Test(priority = 3)
	public void Delete_Project_From_Frost() {
		test.projectView.changeWindow(1);
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.DeleteProjectFromFrost(DemoISBN);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 2.Verify that ePub file sent as an additional content to the Dummy ISBN
	// Project which is already present in Frost retains its File Name and displays
	// the same under Additional Content section (i.e. File Name is displayed
	// instead of base ISBN) when Pushed via Project view window : Clear CSS
	// BS-2106
	@Test(priority = 4)
	public void Verify_Additional_Epub_Send_To_DemoISBN_Frost_Displayed_For_ClearCSS_Option() {
		DemoISBN = getStringWithDateAndTimes("TestISBN");
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectClearCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.VerifyNonStandardProjectMessage(DemoISBN, NonStandardMsg);
		test.projectView.ClickYESNoForDemoISBN("Yes");
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
		test.projectView.verifyOnProjectView();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SelectClearCssOption();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", ProjectISBN1 + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(ProjectISBN1 + "_EPUB.epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.SelectProjectDisplayedInStep3PushToAuthoringTool(DemoISBN);
		test.projectView.VerifyPushButtonEnabledAuthoringTool();
		test.projectView.ClickPushOnPushToAuthoringTool();

		test.projectView.logMessage("Waiting for " + DemoISBN + " to be created at frost end....");
		test.projectView.hardWait(130); /// waiting for File To be Created at Frost.

		test.projectView.ClickGoToFrost();
		test.projectView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.OpenProjectOnFrost(DemoISBN);
		test.projectView.verifyAdditionalFileInFrost(DemoISBN);
	}

	// Delete Project From Frost
	@Test(priority = 5)
	public void Delete_Project_From_Frost1() {
		test.projectView.changeWindow(1);
		test.projectView.ClickFrostHomeLink();
		test.projectView.VerifyProjectIsCreatedAtFrost(DemoISBN, DemoISBN);
		test.projectView.DeleteProjectFromFrost(DemoISBN);
		test.projectView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// Login into Application
	@Test(priority = 6)
	public void Login_Into_Application() {
		test.projectView.changeWindow(0);
		test.projectView.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.LogoutFromApplication();
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

	}

	// 3.Verify that Warning message is NOT getting displayed if user enters the
	// demoISBN similar to the already available demoISBN and clicks the Search
	// Icon.
	// BS-2901
	@Test(priority = 7)
	public void Verify_Warning_Message_NOT_Getting_Displayed_For_Already_Available_DemoISBN() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ProjectISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SelectPushPlatformOnAuthoringTool("Frost");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool(DemoISBN);
		test.projectView.VerifyNonStandardProjectMessageIsNotDisplayed();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
