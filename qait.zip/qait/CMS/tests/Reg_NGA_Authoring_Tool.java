package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;
import java.awt.HeadlessException;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.CustomFunctions.getDateString_MM_dd_yyyy;
import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_NGA_Authoring_Tool extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String ISBN, ContentTypeImageSource, FileTitle, PushToAuthoringHttpLinks;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
		FileTitle = getStringWithDateAndTimes("NGA_Automation_Test");
		PushToAuthoringHttpLinks = getData("PushToAuthoringTool.Https link");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step1:: Upload Sample Image.
	@Test(priority = 2)
	public void Step1_Upload_Sample_Image() {
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(ISBN + "_FC.jpg");
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
	}

	// 1.Verify that Push to Authoring tool option is available for the Content view
	// BS-2761
	@Test(priority = 3)
	public void Verify_Push_To_Authoring_Tool_Option() {
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
	}

	// 2."Verify that a new platform has been added in Step 1 as:NGA Authoring"
	// BS-2761
	@Test(priority = 4)
	public void Verify_NGA_Authoring_Platform() {
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringHttpLinks);
	}

	// 3.Verify that as soon as NGA Authoring option is selected, Step 3 gets
	// disappear
	// BS-2761
	@Test(priority = 5)
	public void Verify_Step3_Disappered_As_NGA_Authoring_Selected() {
		test.ContentView.VerifyStep3LabelOfPushToAuthoringToolNotDisplayed();
	}

	// 4."Verify that as soon as user selects NGA Authoring in Step 1, the UI on the
	// Push to Authoring tool window is modified to show the following
	// Step 1: Select Authoring platform
	// Step 2: Selected Assets
	// Push and Cancel button"
	// BS-2761
	@Test(priority = 6)
	public void Verify_GUI_Updates_As_User_Selects_NGA_Authoring() {
		test.ContentView.VerifyStep1PushToAuthoringTool();
		test.ContentView.VerifyStep2PushToAuthoringTool();
		test.ContentView.VerifyPushButtonOnAuthoringTool();
		test.ContentView.VerifyCancelButtonOnAuthoringTool();
	}

	// 5.Verify that Push button gets enabled if user selects the NGA Authoring
	// platform in Step 1
	// BS-2761
	@Test(priority = 7)
	public void Verify_Push_Button_Enabled_User_Selects_NGA_Authoring_Platform() {
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.PushButtonEnabledOnPushToAutoringTool();
	}

	// 6.Verify that on clicking the Cancel/Cross button, the action will be aborted
	// and the user will return to the Content View.
	// BS-2761
	@Test(priority = 8)
	public void Verify_Click_Cross_Or_Cancel_Button_Closes_Window() {
		test.ContentView.ClickX_OnWindow();
		test.ContentView.VerifyAuthoringToolClosed();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringHttpLinks);
		test.ContentView.ClickCancelOnAuthoringTool();
		test.ContentView.VerifyAuthoringToolClosed();
	}

	// 7."Verify that on clicking the Push button, the Push to authoring tool window
	// Success Message is Displayed.
	// BS-2761
	@Test(priority = 9)
	public void Verify_Clicking_Push_Button_Success_Message_Is_Displayed() {
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
	}

	// 8.Verify that clicking the OK button or Cross button closes the pop up
	// window.
	// BS-2761
	@Test(priority = 10)
	public void Verify_Clicking_x_Message_Window() {
		test.ContentView.ClickX_OnWindow();
		test.ContentView.VerifyAuthoringToolClosed();
	}

	// Delete the Uploaded Image
	@Test(priority = 11)
	public void Delete_The_Uploaded_Image() {
		test.ContentView.DeleteContentFromCMS();
	}

	// Upload A Image for the the Testing
	@Test(priority = 12)
	public void Step1_Upload_Sample_Image1() {
		FileTitle = getStringWithDateAndTimes("NGA_Automation_Test");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.SelectFileUsingBrowseButton(ISBN + "_FC.jpg");
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
	}

	// 9."Verify that a new table under the Publish details tab in content view is
	// displaying with following column headers:
	// 1) User
	// 2) Destination
	// 3) Pushed Date
	// 4) URL
	// 5) Status"
	// BS-2799
	@Test(priority = 13)
	public void Verify_Coloums_In_Publish_Detail_Tab() {
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyTableHeaderForAuthoringPlatformPushDetails();
	}

	// 10.Verify that only one entry will be displayed at all times, this also
	// covers the scenario where user is trying to push the asset twice, so the
	// previous entry will be overwritten by the new one
	// BS-2799
	@Test(priority = 14)
	public void Verify_Only_One_Entry_Displayed_In_Authoring_Platform_Push_Details() {
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyOnlyOneEntryForNGAPushOperation();

		test.ContentView.clickTopLinkMore(); // scenario for Multiple Entry..
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyOnlyOneEntryForNGAPushOperation();
		test.ContentView.VerifyNGAPushOperationCompletes();

		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool(PushToAuthoringHttpLinks);
		test.ContentView.verifyActivateLinkForHttpsLinkIsDisplayed();
		test.ContentView.clickActivationForHttpsLink();
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.VerifySuccessMessageOnNGAPush();
		test.ContentView.ClickX_OnWindow();
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
		test.ContentView.ClickNGARefreshButton();
		test.ContentView.VerifyOnlyOneEntryForNGAPushOperation();
	}

	// 15.Verify that as soon as the Push process clicks off, In Progress status
	// will be shown to the users
	// BS-2799
	@Test(priority = 15)
	public void Verify_In_Progress_Status_Will_Be_Shown_To_The_Users() {
		test.ContentView.VerifyPushStatusOnPublishDetails("In Progress");
	}

	// 16."Verify that the label name of the new section reads as:Authoring Platform
	// Push Details"
	// BS-2799
	@Test(priority = 16)
	public void Verify_Label_Name_As_Authoring_Platform_Push_Details() {
		test.ContentView.VerifyAuthoringPushPlatformSectionDisplayed();
	}

	// 17.Verify that the hyperlinked text 'Asset URL' is displaying under URL
	// column and when same is clicked, a modal window is opening showing the entire
	// URL with OK button
	// BS-2799
	@Test(priority = 17)
	public void Verify_Assert_URL_Is_Hyperlinked() {
		test.ContentView.clickAssetUrlNGAPublishDetail();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.VerifyURL_IsDisplayed();
		test.ContentView.VerifyOkButtonDisplayed();
		test.ContentView.ClickOkButton();
	}

	// 18.Verify that a copy icon is available to the left of the Hyperlinked text
	// for users to quickly copy the URL
	// BS-2799
	@Test(priority = 18)
	public void Verify_Copy_Icon_Is_Available_And_User_Is_Able_To_Copy_AssertURL()
			throws HeadlessException, UnsupportedFlavorException, IOException {
		
		test.ContentView.CopyAssetUrlFromIconAndVerify();
	}

	// 19.Verify that correct entries are getting updated in the newly added table
	// under each column
	// BS-2799
	@Test(priority = 19)
	public void Verify_Correct_Entries_Are_Getting_Updated() {
		test.ContentView.VerifyPushTableIsUpadted(AdminEmail, getDateString_MM_dd_yyyy().trim());
	}

	// 20."Verify that Push to NGA Authoring entry is updated in the Content History
	// table as:Push To NGA Authoring Asset URL"
	// BS-2799
	@Test(priority = 20)
	public void Verify_History_Table_Is_Upadted() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(FileTitle);
		test.Contentpage.opentheSearchContent(FileTitle);
		test.ContentView.VerifyContentHistoryTableActionUpdated("Push to https link");
	}

	// 21.Verify that Hyperlinked text 'Asset URL' is available right to the marked
	// entry
	// .Verify that clicking the same opens the pop up window containing the URL and
	// OK button
	// BS-2799
	@Test(priority = 21)
	public void Verify_Hyperlinked_Text_Asset_URL_On_History_Table() {
		test.ContentView.VerifyAssetURLOnHistoryTable();
		test.ContentView.ClickAssetUrlOnHistoryTable();
		test.ContentView.VerifyAssertUrlPopUpDisplayed();
		test.ContentView.ClickOkButton();
	}

	// Delete the Uploaded Image
	@Test(priority = 22)
	public void Delete_The_Uploaded_Image1() {
		test.ContentView.DeleteContentFromCMS();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}