package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;

public class Updated_ePub_Functionality extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String TestISBN, PublihDestinationCoreSource, TypesOfContentEnhancedEpub, TypeOfContentEnhancedBatch;
	String BatchEpubISBN, TypesOfContentEpubSupersetNotForDistribution, AdvSearchTypeContentType;
	String TestEpubFile, TestEpubTitle, FacetContentType, FacetLinkImageLinked, FacetProjectType, SeeMoreLink,
			ScructuralValidationComplete;
	String FileIngested;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestISBN = getData("ProjectISBNNO");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypeOfContentEnhancedBatch = getData("TypesOfContent.Enhanced ePub > Batch");
		TypesOfContentEpubSupersetNotForDistribution = getData("TypesOfContent.ePub>Superset - Not for Distribution");
		BatchEpubISBN = getData("BatchEpub");
		AdvSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		TestEpubFile = getData("TestData.TestEpub4");
		TestEpubTitle = getStringWithDateAndTimes("TestSupersetEpub");
		FacetContentType = getData("FacetType.Content Type");
		FacetLinkImageLinked = getData("TypesOfContent.Images>Image Linked");
		FacetProjectType = getData("FacetType.Project Status");
		SeeMoreLink = getData("SeeMoreLink");
		ScructuralValidationComplete = getData("ContentWorkflow.Structural Validation Complete");
		FileIngested = getData("ContentWorkflow.File Ingested");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login into Application
	@Test(priority = 1)
	public void loginIntoApplication() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);

	}

	// Step:Upload ePub_Superset_Not_For_Distribution Epub
	@Test(priority = 2)
	public void Step_Upload_Superset_Not_For_Distribution_Epub() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestEpubFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEpubSupersetNotForDistribution);
		test.HomePage.EnterTextIntoTitleField(TestEpubTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
	}

	// "Verify that user is now not able to publish following content types to
	// CoreSource:
	// Enhanced ePub>Batch
	// Enhanced ePub>Full package
	// i.e. from both views Project and Content"
	@Test(priority = 3)
	public void Verify_User_Not_Able_To_Publish_Enhanced_Batch_And_Full_Package() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.projectView.verifyContentTypeDisabledOnPublishWindow("CMS", TypesOfContentEnhancedEpub);
		test.projectView.verifyContentTypeDisabledOnPublishWindow("CMS", TypeOfContentEnhancedBatch);
		test.projectView.ClickCloseButton();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestISBN + ".epub");
		test.Contentpage.opentheSearchContent(TestISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyPublishButtonDisabled();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.VerifyPublishButtonDisabled();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.ClickX_OnWindow();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(BatchEpubISBN + ".epub");
		test.Contentpage.opentheSearchContent(BatchEpubISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.VerifyPublishButtonDisabled();
		test.ContentView.SelectAssertOnpublishPopUp();
		test.ContentView.VerifyPublishButtonDisabled();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.ClickX_OnWindow();
	}

	// Verify that a new Content type 'ePub>Superset - Not for Distribution' has
	// been added in the Content type list
	@Test(priority = 4)
	public void Verify_ePub_Superset_Not_For_Distribution_Content_Type() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEpubSupersetNotForDistribution);
		test.HomePage.clickXButtonUploadContent();

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentEpubSupersetNotForDistribution);
		test.projectView.clickXButtonUploadContent();

		test.HomePage.clickAdvanceSearch();
		test.HomePage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInNewAddedField(TypesOfContentEpubSupersetNotForDistribution);

	}

	// "Verify that CMS does not explode following Content types:
	// Flat ePub > Batch
	// Enhanced ePub > Batch
	// Superset - Not for Distribution"
	@Test(priority = 5)
	public void Verify_CMS_Does_Not_Explode_For_Batch_And_Superset_Epubs() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(BatchEpubISBN + ".epub");
		test.Contentpage.opentheSearchContent(BatchEpubISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.verifyOperationUnderMoreLinkDisabled("View ePub Files");
		test.ContentView.ClickViewEpubFiles();
		test.ContentView.VerifyExplodedEpubPopUpIsNotDisplayed();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(BatchEpubISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(BatchEpubISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.verifyOperationUnderMoreLinkDisabled("View ePub Files");
		test.ContentView.ClickViewEpubFiles();
		test.ContentView.VerifyExplodedEpubPopUpIsNotDisplayed();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestEpubTitle);
		test.Contentpage.opentheSearchContent(TestEpubTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.verifyOperationUnderMoreLinkDisabled("View ePub Files");
		test.ContentView.ClickViewEpubFiles();
		test.ContentView.VerifyExplodedEpubPopUpIsNotDisplayed();
	}

	// "The Preview ePub feature is disabled from the content view for the following
	// content types
	// Flat ePub > Batch
	// Enhanced ePub > Batch
	// Superset - Not for Distribution"
	@Test(priority = 6)
	public void Verify_Preview_ePub_Feature_Not_Available_For_Batch_And_Superset_Epubs() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(BatchEpubISBN + ".epub");
		test.Contentpage.opentheSearchContent(BatchEpubISBN + ".epub");
		test.ContentView.verifyPreviewEpubButtonDisabled();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(BatchEpubISBN + "_EPUB.epub");
		test.Contentpage.opentheSearchContent(BatchEpubISBN + "_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.verifyPreviewEpubButtonDisabled();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestEpubTitle);
		test.Contentpage.opentheSearchContent(TestEpubTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.verifyPreviewEpubButtonDisabled();
	}

	// Verify that desired error message should appear when user tries to create a
	// Project at Frost with un-intended characters from Project and Content view
	// both
	@Test(priority = 7)
	public void Verify_Error_Message_When_User_Try_To_Push_Reserved_Special_Characters() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", TestISBN + ".epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(TestISBN + ".epub");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool("CON");
		test.projectView.verifyNotSupportedProjectNameDisplayedOnPushToAuthoringTool("CON");
		test.projectView.SearchProjectInStep3SearchFieldOfpushToAuthoringTool("TestProject?");
		test.projectView.verifyReservedCharacterMessageDisplayedOnPushToAuthoringTool("TestProject?");
		test.projectView.ClickCloseButton();
	}

	// Verify that correct results count is getting displayed to the right side and
	// in the left Facet section on clicking a particular Content type filter
	@Test(priority = 8)
	public void Verify_Correct_Results_Count_In_Content_Type_Filter() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem("Test");
		test.Contentpage.clickOnFacetLinks(FacetContentType, getData("SeeMoreLink"));
		test.Contentpage.verifyOnSeeMorePopup(FacetContentType);
		test.Contentpage.verifyCorrectCountOfAssetFromSeeMoreLink(FacetLinkImageLinked);
	}

	// Verify that user is not able to Publish 'ePub>Superset - Not for
	// Distribution' either from Project view or Content view
	@Test(priority = 9)
	public void Verify_User_Not_Able_To_Publish_EPub_Superset_From_Project_And_Content_View() {

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.verifyContentTypeDisabledOnPublishWindow("CMS", TypesOfContentEpubSupersetNotForDistribution);
		test.projectView.ClickCloseButton();

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestEpubTitle);
		test.Contentpage.opentheSearchContent(TestEpubTitle);
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.verifyStructuralValidationIsComplete();
		test.ContentView.verifyPublishLinkNotDisplayed();
	}

	// "Verify that no project in CMS has the follwoing status:
	// 'Structural Validation Complete'
	// 'File Ingested'"
	@Test(priority = 10)
	public void Verify_No_Project_Has_Structural_Validation_Complete_And_File_Ingested() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.clickOnFacetLinks(FacetProjectType, SeeMoreLink);
		test.ProjectPage.verifyOnSeeMorePopup(FacetProjectType);
		test.ProjectPage.VerifyLinkNotDisplayedOnSeeMorePopup(ScructuralValidationComplete);
		test.ProjectPage.VerifyLinkNotDisplayedOnSeeMorePopup(FileIngested);
	}

	// Verify that all newly implemented ePub types are available under the 'EPubs
	// only' section in Push to Authoring tool window
	@Test(priority = 11)
	public void Verify_Newly_Implemented_EPub_Are_Available_Under_EPubs_Only() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", TestISBN + ".epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(TestISBN + ".epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Other", TestISBN + ".epub");
		test.projectView.verifyAssetNotDisplayedInPushToAuthoringTool(TestISBN + ".epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", TestISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(TestISBN + "_EPUB.epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Other", TestISBN + "_EPUB.epub");
		test.projectView.verifyAssetNotDisplayedInPushToAuthoringTool(TestISBN + "_EPUB.epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", BatchEpubISBN + "_EPUB.epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(BatchEpubISBN + "_EPUB.epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Other", BatchEpubISBN + "_EPUB.epub");
		test.projectView.verifyAssetNotDisplayedInPushToAuthoringTool(BatchEpubISBN + "_EPUB.epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", BatchEpubISBN + ".epub");
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(BatchEpubISBN + ".epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Other", BatchEpubISBN + ".epub");
		test.projectView.verifyAssetNotDisplayedInPushToAuthoringTool(BatchEpubISBN + ".epub");
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Epub", TestEpubTitle);
		test.projectView.SelectAssetDisplayedInPushToAuthoringTool(TestEpubTitle);
		test.projectView.ClearSearchResultOnPushToAutoringTool();

		test.projectView.SearchForAssetOnPushToAuthoringTool("Other", TestEpubTitle);
		test.projectView.verifyAssetNotDisplayedInPushToAuthoringTool(TestEpubTitle);
		test.projectView.ClearSearchResultOnPushToAutoringTool();

	}

	// Delete The Uploaded ePub_Superset_Not_For_Distribution Epub
	@Test(priority = 12)
	public void DeleteTheUploadedEpub() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(TestEpubTitle);
		test.Contentpage.SelectContentOnContentTab(TestEpubTitle, TypesOfContentEpubSupersetNotForDistribution);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}

}
