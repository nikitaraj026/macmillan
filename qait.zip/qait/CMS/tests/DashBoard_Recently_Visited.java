package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class DashBoard_Recently_Visited extends Parent_Test {
	CMSTestInitiator test;
	String Env;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String ISBN,ISBN1,ProjectShortTitle;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		ProjectShortTitle=getData("ProjectShortTitle");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());

	}

	// Login Into the Application.
	@Test(priority = 1)
	public void LogIn_Into_Application() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}
	
	//1.Verify that Recently Visited tab is displaying on the Dashboard
	@Test(priority=2)
	public void Verify_Recently_Visited_Tab_DashBoard() {
		test.HomePage.VerifyRecentlyVisitedTabIsDisplayed();
	}
	
	//2.Verify that the Project that is last visited by user gets added in the Recently visited table and the latest one appear on the top
	@Test(priority=3)
	public void Verify_Recently_Visited_Project_is_Displayed() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.AddProjectToFavorite();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(ISBN);
		
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.verifyOnProjectView();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(ISBN1);
	}
	
	//3.Verify that user is able to mark the Project as Favorite or Unfavorite from this tab
	@Test(priority=4)
	public void Verify_User_Able_To_Mark_Project_Favorite_Or_Unfavorite() {
		test.HomePage.RemoveProjectFromFavoriteRecentlyVisited(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.AddProjectToFavoriteFromRecentlyVisited(ISBN);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
		test.HomePage.clickGridView();
		test.HomePage.RemoveProjectToFavoriteFromRecentlyVisitedGridView(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.AddProjectToFavoriteFromRecentlyVisitedGridView(ISBN);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
		test.HomePage.ClickListView();
	}
	
	// 4.Verify that the Content that is last visited by user gets added in the
	// Recently visited table and the latest one appear on the top. 
	@Test(priority=5)
	public void Verify_Recently_Visited_Content_is_Displayed() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(ISBN+".epub");
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(ISBN+".epub");
	}
	
	//5."Verify that Proper Column Headers are available in the Recently visited table
	@Test(priority=6)
	public void Verify_Column_Headers_On_Recently_Visited_Table() {
		test.HomePage.Verify_Coloums_On_RecentlyVisited();
		test.HomePage.VerifyCheckBoxGrayedOutOnRecently();
		test.HomePage.VerifyFolderIconForProject(ISBN);
		test.HomePage.VerifyFileIconForContent(ISBN+".epub");
		test.HomePage.VerifyAuthorNameForProject(ISBN);
		test.HomePage.VerifyAuthorNameNotDisplayedForContent(ISBN+".epub");
		test.HomePage.VerifyTitleDisplayedOnRecentlyVisited();
		test.HomePage.VerifyShortTitleForProject(ISBN,ProjectShortTitle);
		test.HomePage.VerifyShortTitleNotDisplayedForContent(ISBN+".epub");
		test.HomePage.VerifyISBNNotDisplayedForContent(ISBN+".epub");
		test.HomePage.VerifyContentTypeDisplayedForContent(ISBN+".epub");
		test.HomePage.VerifyContentTypeNotDisplayedForProject(ISBN);
		test.HomePage.verifyRepositoryForContentType(ISBN+".epub");
		test.HomePage.verifyRepositoryNotDisplayedForProject(ISBN);
	}
	
	//6.Verify proper information is displayed for Project and content on grid view.
	@Test(priority=6)
	public void Verify_Proper_Information_On_Grid_View() {
		test.HomePage.clickGridView();
		test.HomePage.VerifyGridViewDisplayed();
		test.HomePage.VerifyProjectDetailGridViewRecentlyVisited();
		test.HomePage.VerifyContentDetailGridViewRecentlyVisited();
	}
	
	//7.Verify that view icon available for each row has been replaced by hyperlinking the complete row
	@Test(priority=6)
	public void Verify_View_Icon_Replaced_By_Hyperlink_Row() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.OpenProjectDisplayedOnRecentlyVisited(ISBN);
		test.projectView.verifyOnProjectView();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}