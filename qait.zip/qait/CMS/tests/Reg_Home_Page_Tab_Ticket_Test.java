package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Reg_Home_Page_Tab_Ticket_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DAMLink, LookForAsset, LookForProject,
			LookForBoth;
	String Elvis, ProjectISBNNO, NonAdminEmail, NonAdminPassword, ISBN, Noncmsassert, PassResetEmail,
			CurrentResetPassword;
	String OrganisedDownloadMsg, OrganisedDownloadMsgAdv, DownloadStartMsg, DamContent, DownloadStartMsgAdv;
	String TypesOfContentEnhancedEpub, TypesOfContentFlatEpub, TypesOfContentBatchEnhanced, TypesOfContentBatchFlat,
			AdvSearchTypeAuthor, AdvSearchTypeContentType;
	String AdvSearchTypePublishDestination;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		Elvis = getData("NonCMSAssert.Elvis");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ProjectISBNNO = getData("ProjectISBNNo1");
		Noncmsassert = getData("DamContent");
		PassResetEmail = getData("PasswordResetAccount.email");
		CurrentResetPassword = PropFileHandler.readPropertyFromDataFile("currentPassword");
		LookForAsset = getData("LookFor.Assets");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		OrganisedDownloadMsg = getData("OrganisedDownloadMsg");
		OrganisedDownloadMsgAdv = getData("OrganisedDownloadMsgAdv");
		DownloadStartMsg = getData("DownloadStartMsg");
		DownloadStartMsgAdv = getData("DownloadStartMsgAdv");
		DamContent = getData("DamContent");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		TypesOfContentFlatEpub = getData("TypesOfContent.Flat ePub > Full Package");
		TypesOfContentBatchEnhanced = getData("TypesOfContent.Flat ePub > Batch");
		TypesOfContentBatchFlat = getData("TypesOfContent.Enhanced ePub > Batch");
		AdvSearchTypeAuthor = getData("SearchTypeAdvanceSearch.Author");
		AdvSearchTypeContentType = getData("SearchTypeAdvanceSearch.Content Type");
		AdvSearchTypePublishDestination = getData("SearchTypeAdvanceSearch.Publish Destination");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 5."Verify that ""Your favorite projects will appear here "is displayed when
	// there is no favorite projects marked"
	// BS-2163
	@Test(priority = 6)
	public void Verify_Message_On_Favorite_Tab() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

	}

	// 6."Verify that ""Your favorite projects will appear here"" is displayed when
	// there is no favorite projects marked and user navigates to homepage from any
	// other page"
	// BS-2163
	@Test(priority = 7)
	public void Verify_Message_On_Favorite_Tab_After_User_Navigates_To_Homepage_From_Any_Other_Page() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickDashBord();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

		test.HomePage.clickProjectTab();
		test.HomePage.ClickDashBord();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.HomePage.ClickDashBord();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

	}

	// 7.Verify that user is able to mark project as Favorite from project view page
	// BS-2163
	@Test(priority = 8)
	public void Verify_User_Is_Able_To_Mark_project_As_Favorite_From_ProjectView() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.AddProjectToFavorite();
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 8.Verify that user is able to mark project as Favorite from project tab
	// BS-2163
	@Test(priority = 9)
	public void Verify_User_Is_Able_To_Mark_project_As_Favorite_From_Project_Tab() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 9.Verify that user is able to mark project as Favorite from Generic search
	// result page
	// BS-2163
	@Test(priority = 10)
	public void Verify_User_Is_Able_To_Mark_project_As_Favorite_From_Generic_Search() {
		test.refreshPage();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 10.Verify that user is able to mark project as Favorite from result page
	// BS-2163
	@Test(priority = 11)
	public void Verify_User_Is_Able_To_Mark_project_As_Favorite_From_Advance_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.AddProjectToFavorite(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyProjectIsAddedAsFavorite(ISBN);
	}

	// 11."Verify that Author Tittle Short Title ISBN Publication date Publish
	// Status View fields are shown in table under favorite tab "
	// BS-2163
	@Test(priority = 12)
	public void Verify_Favorite_Table_In_Dashbord_Has_Appropriate_Coloum() {
		test.refreshPage();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyAllTheColoumsOfFavoriteTable();
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 12.Verify that Grid view and List view buttons are at the top right corner
	// BS-2163
	@Test(priority = 13)
	public void Verify_Grid_View_And_List_View_Buttons_On_Favorite_Table() {
		test.HomePage.VerifyGridAndListViewButton();
	}

	// 13.Verify that Favorite projects are displayed in List view by default
	// BS-2163
	@Test(priority = 14)
	public void Verify_Favorite_Projects_Are_Displayed_In_List_View_By_Default() {
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyListViewDisplayed();
	}

	// 14.Verify that Favorite projects are displayed in Grid View on clicking Grid
	// View icon
	// BS-2163
	@Test(priority = 15)
	public void Verify_Favorite_Projects_Are_Displayed_In_Grid_View() {
		test.refreshPage();
		test.HomePage.clickGridView();
		test.HomePage.VerifyGridViewDisplayed();
	}

	// 15.Verify that thumbnails is shown in Grid view for Favorite projects
	// BS-2163
	@Test(priority = 16)
	public void Verify_Thumbnails_Is_Shown_In_Grid_View() {
		test.HomePage.VerifyGridViewDisplayed();
		test.HomePage.VerifyThumbnailinGridView();
	}

	// 16."Verify that Title Star sign Date Created User type are displayed below
	// the thumbnail"
	// BS-2163
	@Test(priority = 17)
	public void Verify_Information_Displayed_Under_Thumbnail() {
		test.HomePage.VerifyFavoriteInformationInGridView();
	}

	// 17.Verify that see all button is at the bottom when favorite projects are
	// more than 5
	// BS-2163
	@Test(priority = 18)
	public void Verify_See_All_Button_At_The_Bottom_Of_Favorite_Projects() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.AddProjectsToFavorite("8");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyFavoriteTableIsDisplayed();
		test.HomePage.VerifyShowAllButtonDisplayed();
	}

	// 18.Verify that see less button is at the bottom when user has clicked the see
	// all button
	// BS-2163
	@Test(priority = 19)
	public void Verify_See_Less_Button_Is_Displayed() {
		test.HomePage.clickShowAllButton();
		test.HomePage.verifyShowLessButtonDisplayed();

	}

	// 19."Verify that favorite tab is present on homepage"
	// BS-2163
	@Test(priority = 20)
	public void Verify_Favorite_Tab_Is_Present_On_Homepage() {
		test.refreshPage();
		test.HomePage.VerifyFavoriteTabIsDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
	}

	// 20."Verify that favorite tab is present when user switch from any other page
	// to homepage "
	// BS-2163
	@Test(priority = 21)
	public void Verify_Favorite_Tab_Present_When_User_Switch_From_Any_Other_Page() {
		test.refreshPage();

		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.clickProjectTab();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.ClickContentTab();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

	}

	// 21."Verify that favorite tab is present when user is on any other page and
	// clicks on MacMillan logo"
	// BS-2163
	@Test(priority = 22)
	public void Verify_Favorite_Tab_After_Clicking_MacmillanLogo() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(ProjectISBNNO);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ProjectISBNNO);
		test.HomePage.ClickDashBord();
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.ClickContentTab();
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.clickProjectTab();
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyFavoriteTabIsDisplayed();
	}

	// 22."Verify that favorite tab is present when user is on any other page and
	// clicks on favorite in facet links"
	// BS-2163
	@Test(priority = 23)
	public void Verify_Favorite_Tab_After_Clicking_Project_Link_On_Facet() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickProjectLinkOnFacet();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.ClickContentTab();
		test.HomePage.clickProjectLinkOnFacet();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.clickProjectTab();
		test.HomePage.clickProjectLinkOnFacet();
		test.HomePage.VerifyFavoriteTabIsDisplayed();

		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
	}

	// 23.Verify that only a single result is displayed when user searches with
	// exact 13 digit ISBN in 'Add Content to Project' pop-up from Generic search
	// page
	// BS-1653
	@Test(priority = 24)
	public void Verify_In_Add_Content_To_Project_Only_A_Single_Result_Is_Displayed_For_Exact_13_Digit_ISBN() {
		test.refreshPage();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.SelectContentOnContentTab(ISBN + ".epub",TypesOfContentEnhancedEpub);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.VerifyAddtoProjectpopUp();
		test.Contentpage.SearchForProjectOnAddRemoveContent(ProjectISBNNO);
		test.Contentpage.VerifyOneProjectDisplayed();
	}

	// 24.Verify that only a single result is displayed when user searches with
	// exact 13 digit ISBN in 'Add Content to Project' pop-up from Advanced search
	// page
	// BS-1653
	@Test(priority = 25)
	public void Verify_In_Add_Content_To_Project_Only_A_Single_Result_Is_Displayed_For_Exact_13_Digit_ISBN_In_Advance_Search() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.VerifyUserIsAbleToMakeAdvanceSearch(ISBN);
		test.SearchPage.SelectAssetOnSearchPage(ISBN + ".epub");
		test.SearchPage.ClickAddToProject();
		test.SearchPage.VerifyAddtoProjectpopUp();
		test.SearchPage.SearchForProjectOnAddRemoveContent(ProjectISBNNO);
		test.SearchPage.VerifyOneProjectDisplayed();
	}

	// 25.Verify that only a single result is displayed when user searches with
	// exact 13 digit ISBN in Add / Remove Project pop-up from Upload content
	// workflow via DASHBOARD
	// BS-1653
	@Test(priority = 26)
	public void Verify_In_Add_Content_To_Project_Only_A_Single_Result_Is_Displayed_For_Exact_13_Digit_ISBN_In_Upload_Content() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(ProjectISBNNO);
		test.HomePage.VerifyOneProjectDisplayed();
	}

	// 26.Verify that the message appear when user performs the Organized download
	// via Generic Search page
	// BS-1582
	@Test(priority = 27)
	public void Verify_Message_On_Organized_Download_Via_Generic_Search_Page() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.Contentpage.SearchForAnItem(ISBN + " epub");
		test.Contentpage.SelectSingleContents();
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "1");
		test.refreshPage();
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsg, "2");
	}

	// 27.Verify that the message appear when user performs the Organized download
	// via Advanced Search page
	// BS-1582
	@Test(priority = 28)
	public void Verify_message_On_Organized_Download_Via_Advanced_Search_Page() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.EnterTextIntoSearchBox(ISBN + " epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectAssetOnSearchPage(ISBN + ".epub");
		test.SearchPage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsgAdv, "1");
		test.refreshPage();
		test.SearchPage.SelectAssetOnSearchPage(ISBN + ".epub");
		test.SearchPage.SelectAssetOnSearchPage(ISBN + "_EPUB.epub");
		test.SearchPage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsgAdv, "2");
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.EnterTextIntoSearchBox(ISBN + " epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectAssetOnSearchPage(ISBN + ".epub");
		test.SearchPage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsgAdv, "1");
		test.refreshPage();
		test.SearchPage.SelectAssetOnSearchPage(ISBN + ".epub");
		test.SearchPage.SelectAssetOnSearchPage(ISBN + "_EPUB.epub");
		test.SearchPage.ClickOrganizedDownload();
		test.Contentpage.OrganizedTheDownload("ISBN", "Repository", "Content Type");
		test.Contentpage.VerifyCorrectMessageOnOrganisedDownload(OrganisedDownloadMsgAdv, "2");
	}

	// 28.Verify that the count of downloaded assets matches with the selected
	// assets to be downloaded for Seach workflow- Generic
	// BS-1582
	@Test(priority = 29)
	public void Verify_Downloaded_Asset_Count_Matches_The_Selected_Assets() throws IOException {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.Contentpage.SearchForAnItem(ISBN);
		test.Contentpage.SelectMultipleContentToDownload("2");
		test.Contentpage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsg, "2");

	}

	// 29.Verify that the count of downloaded assets matches with the selected
	// assets to be downloaded for Seach workflow- Advanced
	// BS-1582
	@Test(priority = 30)
	public void Verify_Downloaded_Asset_Count_Matches_The_Selected_Assets_On_Advance_Search() throws IOException {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.EnterTextIntoSearchBox(ISBN + " epub");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectAssetOnSearchPage(ISBN + ".epub");
		test.SearchPage.SelectAssetOnSearchPage(ISBN + "_EPUB.epub");
		test.SearchPage.clickDownloadContent();
		test.Contentpage.verifyCorrectMessageIsDisplayedOnDownloadOfContent(DownloadStartMsgAdv, "");
	}

	// 30.Verify that Thumbnail is displaying in advance search result page for DAM
	// assets searched via Advance Search
	// BS-2087
	@Test(priority = 31)
	public void Verify_Thumbnail_Are_Displayed_In_Advance_Search_Result_Page_For_DAM_Assets() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.EnterTextIntoSearchBox(" ");
		test.SearchPage.AddNewFieldInAdvancedSearchPopUpAndVerify("Repository");
		test.SearchPage.SelectContentTypeInNewAddedField("DAM");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyThumbnailForDamRepo();
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.VerifyThumbnailForDamRepo();
		test.SearchPage.NavigateToPage("3");
		test.SearchPage.VerifyThumbnailForDamRepo();
	}

	// 31.Verify that Thumbnail is displaying in advance search result page for DAM
	// assets searched via Advance Search when Assets & projects are selected in
	// look for dropdown
	// BS-2087
	@Test(priority = 32)
	public void Verify_Thumbnail_Are_Displayed_In_Advance_Search_Page_For_DAM_Assets_When_Assets_projects_Selected() {
		test.refreshPage();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.EnterTextIntoSearchBox(" ");
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp("Repository");
		test.SearchPage.SelectContentTypeInNewAddedField("DAM");
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyThumbnailForDamRepo();
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.VerifyThumbnailForDamRepo();
		test.SearchPage.NavigateToPage("3");
		test.SearchPage.VerifyThumbnailForDamRepo();
	}

	// 32.Verify that Thumbnail is displaying in Generic Search result page for DAM
	// assest
	// BS-2087
	@Test(priority = 33)
	public void Verify_Thumbnail_Is_Displayed_In_Generic_Search_For_DAM_Assest() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyThumnailImagesAreDisplayed();
	}

	// 33.Verify that Thumbnail is displaying in Content Page For DAM asset
	// BS-2087
	@Test(priority = 34)
	public void Verify_Thumbnai_Displayed_In_Content_Page_For_DAM_Asset() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(DamContent);
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyThumnailImagesAreDisplayed();

	}

	// 34.Verify that Thumbnail is displaying in Content Page For DAM asset when DAM
	// is selected from facet links
	// BS-2087
	@Test(priority = 35)
	public void Verify_Thumbnai_Displayed_In_Content_Page_For_DAM_Asset_From_Facet_Link() {
		test.HomePage.ClickContentTab();
		test.HomePage.ClickOpenRepository("DAM");
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyPreviewOfRepo("DAM");
		test.Contentpage.NavigateToPage("2");
		test.Contentpage.VerifyPreviewOfRepo("DAM");
		test.Contentpage.NavigateToPage("3");
		test.Contentpage.VerifyPreviewOfRepo("DAM");
	}

	// 35.Verify that while adding a new field in Advanced Search, it is only
	// displayed as once in the mid section
	// BS-1681
	@Test(priority = 36)
	public void Verify_Adding_A_New_Field_In_Advanced_Search_Is_Displayed_Once() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.VerifyCountOfNewFieldAdded(1);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInAddedField("2", TypesOfContentEnhancedEpub);
		test.SearchPage.AND_OR_Option_Select("OR");
		test.SearchPage.VerifyCountOfNewFieldAdded(2);
	}

	// 36.Verify that while adding a new field AGAIN in Advanced Search dialog box
	// after a successful Advanced search, it is only displayed as once in the mid
	// section
	// BS-1681
	@Test(priority = 37)
	public void Verify_Adding_A_New_Field_Again__After_Successful_Advanced_Search_Is_Displayed_Once() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.VerifyCountOfNewFieldAdded(1);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.SelectContentTypeInAddedField("2", TypesOfContentEnhancedEpub);
		test.SearchPage.AND_OR_Option_Select("OR");
		test.SearchPage.VerifyCountOfNewFieldAdded(2);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeAuthor);
		test.SearchPage.VerifyCountOfNewFieldAdded(3);
	}

	// 37.Verify that user can remove the added field by clicking the cross icon to
	// the right
	// BS-1681
	@Test(priority = 38)
	public void Verify_User_Can_Remove_Added_Field_By_Clicking_The_Cross_Icon() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.DeleteAddedTypeField("1");
		test.SearchPage.VerifyFieldIsDeleted();
		test.SearchPage.VerifyFieldIsDeleted();
	}

	// 38.Verify that user can add the removed field again to the mid section,
	// however it should appear only once
	// BS-1681
	@Test(priority = 39)
	public void Verify_User_Can_Add_The_Removed_Field_Again_It_Should_Appear_Only_Once() {
		test.SearchPage.AddNewFieldInAdvancedSearchPopUp(AdvSearchTypeContentType);
		test.SearchPage.VerifyCountOfNewFieldAdded(1);
	}

	// 39."Verify that ""Your favorite projects will appear here"" is displayed when
	// there is no favorite projects marked and user clicks on MacMillan logo from
	// any other page"
	// BS-2163
	@Test(priority = 40)
	public void Verify_Favorite_Message_On_Clicking_MacMillan_Logo_From_Any_Other_Page() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

		test.HomePage.ClickContentTab();
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

		test.HomePage.clickProjectTab();
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();

		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.HomePage.ClickMacmillanLogo();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();
	}

	// 40."Verify that ""Your favorite projects will appear here""is displayed when
	// there is no favorite projects marked and user clicks on favorite in facets
	// links from any other page"
	// BS-2163
	@Test(priority = 41)
	public void Verify_Favorite_Message_On_Clicking_FactLink_From_Any_Other_Page() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.HomePage.clickProjectLinkOnFacet();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();
		test.HomePage.clickProjectTab();
		test.HomePage.clickProjectLinkOnFacet();
		test.HomePage.VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed();
	}

	// 41.Verify that PSL is not available as the Publish Destination when Look For
	// is selected as 'Assets'
	// BS-2097
	@Test(priority = 42)
	public void Verify_PSL_Is_Not_Available_In_Publish_Destination_When_Look_For_Is_Assets() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUpAndVerify(AdvSearchTypePublishDestination);

	}

	// 42.Verify that PSL is not available as the Publish Destination when Look For
	// is selected as 'Projects'
	// BS-2097
	@Test(priority = 43)
	public void Verify_Verify_PSL_Is_Not_Available_In_Publish_Destination_When_Look_For_Is_Projects() {
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUpAndVerify(AdvSearchTypePublishDestination);
		test.SearchPage.VerifyPSL_IsNotDisplayed();
	}

	// 43.Verify that PSL is not available as the Publish Destination when Look For
	// is selected as 'Assets & Projects'
	// BS-2098
	@Test(priority = 44)
	public void Verify_Verify_PSL_Is_Not_Available_In_Publish_Destination_When_Look_For_Is_AssetsProjects() {
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.AddNewFieldInAdvancedSearchPopUpAndVerify(AdvSearchTypePublishDestination);
		test.SearchPage.VerifyPSL_IsNotDisplayed();
	}

	// 44.Verify that PSL is not available as the Publish destination when user
	// again navigates to the Publish destination after making an Advanced Search
	// BS-2098
	@Test(priority = 45)
	public void Verify_PSL_Is_Not_Available_In_Publish_Destination_After_Making_An_Advanced_Search() {
		test.SearchPage.ClickSearchButton();
		test.SearchPage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.VerifyPSL_IsNotDisplayed();
	}

	// 45.Verify that check-boxes are now appearing in the first column of the table
	// displaying under Favorites tab in List view/Grid view on Home Page
	// BS-2225
	@Test(priority = 46)
	public void Verify_CheckBoxes_Are_Appearing_Under_Favorites_Tab_In_List_And_Grid_View() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.AddProjectsToFavorite("3");
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyCheckBoxAreApperingForProject();
		test.HomePage.clickGridView();
		test.HomePage.VerifyCheckBoxAreApperingForProject();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyGridAndListViewButton();
		test.HomePage.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
	}

	// 46.Verify that check-boxes are now appearing in the first column of the table
	// in Grid view on Advance search result page
	// BS-2225
	@Test(priority = 47)
	public void Verify_CheckBoxes_Are_Appearing_Under_Favorites_Tab_In_Grid_View_For_Advance_Search() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.VerifyCheckBoxAreApperingForProject();
	}

	// 47.Verify that when a Project is marked as Favorite, correct details are
	// displaying in the favorite table under each column on the Dashboard
	// BS-2199
	@Test(priority = 48)
	public void Verify_Project_Marked_As_Favorite_Displayes_Correct_Information() {
		test.refreshPage();
		test.HomePage.ClickDashBord();
		test.HomePage.clickShowAllButton();
		test.HomePage.RemoveAllProjectFromFavorite();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.ProjectPage.VerifyCorrentInformationOfProjectIsDisplayed(ISBN);
	}

	// 48.Verify that if user changes the Project status of the already marked
	// favorite project, then same should be reflected on the Dashboard Favorite
	// table
	// BS-2199
	@Test(priority = 49)
	public void Verify_If_Project_Status_Is_Changed_It_Should_Reflected_On_The_Dashboard() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ChangeProjectStatusAndVerifyOnTheDashboard(ISBN);
	}

	// 49.Verify that Content Type > Content Subtype has been updated in Dashboard>
	// Upload Content
	// BS-2235
	@Test(priority = 50)
	public void Verify__Content_Subtype_Has_Been_Updated_In_Dashboard_Upload_Content() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentFlatEpub);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentBatchEnhanced);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentBatchFlat);
	}

	// 50."Verify that the Table column header has been renamed to 'CMS Project
	// Status' from 'Project Status' for below workflows: a) Dashboard> Favorites
	// table"
	// BS-2212
	@Test(priority = 51)
	public void Verify_Table_Column_Header_Has_Been_Renamed_To_CMS_Project_Status() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.RemoveProjectFromFavorite(ISBN);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyAllTheColoumsOfFavoriteTable();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
