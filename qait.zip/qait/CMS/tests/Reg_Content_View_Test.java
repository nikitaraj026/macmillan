package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Content_View_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String NonAdminEmail, NonAdminPassword, ISBN, ISBN1, PublihDestinationCoreSource, PublihDestinationPalgrave,
			PublihDestinationVitalSource;
	String FrostMainProject, FrostIsbnToEnter, FrostCreatedProjectName, FrostEmail, FrostPassword, DamContent;
	String TypesOfContentEnhancedEpub, FrostHistoryUpdate,ContentTypeCFI;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ISBN1 = getData("ProjectISBNNo1");
		PublihDestinationCoreSource = getData("PublishDestination.CoreSource");
		PublihDestinationPalgrave = getData("PublishDestination.Palgrave");
		PublihDestinationVitalSource = getData("PublishDestination.VitalSource");
		FrostMainProject = getData("FrostProject.MainProjectISBN");
		FrostIsbnToEnter = getData("FrostProject.ProjectISBNToEnter");
		FrostCreatedProjectName = getData("FrostProject.ProjectNameToEnterRegression");
		FrostEmail = getData("Frost.UserName");
		FrostPassword = getData("Frost.Password");
		DamContent = getData("DamContent");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		FrostHistoryUpdate = getData("CVHistoryFrost");
		ContentTypeCFI = getData("TypesOfContent.Project Support Materials>CFI");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// Login Into The Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1.Verify that user is able to navigate to content view page
	@Test(priority = 2)
	public void Verify_User_Is_Able_To_Navigate_To_Content_View() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyOnContentViewPage();
	}

	// 2.Verify Verify that 'Macmillan Learning CMS' logo is present at the top left
	@Test(priority = 3)
	public void Verify_Macmillan_logo_Is_Present_At_Top() {
		test.HomePage.VerifyMacmillanLogoIsPresent();
	}

	// 3.Verify that in total 3 tabs are presented 'Dashboard', 'Projects',
	// 'Content'
	@Test(priority = 4)
	public void Verify_Total_3_Tabs_Are_Presented() {
		test.HomePage.VerifyContentTabIsDisplayed();
		test.HomePage.VerifyProjectTabIsDisplayed();
		test.HomePage.VerifyContentTabIsDisplayed();
	}

	// 4.Verify that a user profile button is present at the top right of window
	@Test(priority = 5)
	public void Verify_Profile_Button_Present_At_Top() {
		test.HomePage.VerifyProfileButton();
	}

	// 5.Verify that a Search Field and drop down button is present at top middle of
	// the window
	@Test(priority = 6)
	public void Verify_Search_Field_And_Drop_Down_Is_Present() {
		test.HomePage.VerifySearchFieldIsDisplayed();
		test.HomePage.VerifyUserAbleToSelectOptionsInNormalSearch();
	}

	// 6.Verify that a upload content button is present at dashboard tab
	@Test(priority = 7)
	public void Verify_Upload_Content_Button_Is_Present() {
		test.ContentView.VerifyUploadContentButton();
	}

	// 7.Verify that Content view heading is appearing below the three tabs on the
	// left side of the window
	@Test(priority = 8)
	public void Verify_Content_View_Heading_Is_Appearing() {
		test.ContentView.VerifyOnContentViewPage();
	}

	// 8.Verify that on clicking on the home link user is navigate to Dashboard
	@Test(priority = 9)
	public void Verify_On_Clicking_Home_Link_User_Navigate_To_Dashboard() {
		test.ContentView.ClickHomeOnContentView();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 9.Verify that on clicking on the Content link user is navigate to Content
	// page
	@Test(priority = 10)
	public void Verify_On_Clicking_Content_Link_User_Is_Navigate_To_Content_Page() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
	}

	// 10.Verify that content title is appearing below the content view heading
	@Test(priority = 11)
	public void Verify_Content_Title_Is_Appearing_Under_Content_View_Heading() {
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyContentLinkAppearing();
	}

	// 11.Verify that content thumbnail is appearing below the content title
	@Test(priority = 12)
	public void Verify_Content_Thumbnail_Is_Appearing() {
		test.ContentView.VerifyContentThumbnailAppering();
	}

	// 12.Verify that System Metadata heading is appearing below the content
	// thumbnail
	@Test(priority = 13)
	public void Verify_System_MetaData_Is_Appering() {
		test.ContentView.VerifySystemMetadataHeadingAreDisplayed();
	}

	// 13.Verify that System Metadata is displayed for the content
	@Test(priority = 14)
	public void Verify_System_Metadata_Is_Displayed() {
		test.ContentView.VerifySystemMetadataAreDisplayed();
	}

	// 14."Verify that content view page has following link on right side of the
	// window :
	// 1. Publish
	// 2. Download Content
	// 3. Edit
	// 4. Delete
	// 5. More"
	@Test(priority = 15)
	public void Verify_Link_At_The_Top_Are_Available_Publish_Edit_ETC() {
		test.ContentView.VerifyTopLinksAreAvailabe();
	}

	// 15.Verify that clicking on the publish link open the publish pop up on the
	// content page
	@Test(priority = 16)
	public void Verify_Clicking_On_Publish_Link_Opens_Publish_PopUp() {
		test.ContentView.VerifyPublishLinkIsEnabled();
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
	}

	// 16.Verify that publish pop up heading with title of the content at the top
	@Test(priority = 17)
	public void Verify_Publish_PopUp_heading_Has_Title_Of_Content() {
		test.ContentView.VerifyTitleOfContentIsDisplayedOnPublishPopUp(ISBN);
	}

	// 17."Verify that publish pop up has three section for Flat ePub/ Cover design
	// :
	// Step 1 Select Destination
	// Step 2 Selected Assets
	// Step 3 Publish Assets"
	@Test(priority = 18)
	public void Verify_publish_PopUp_Has_Three_Section() {
		test.ContentView.VerifyThreeSectionDisplayedInPublish();
	}

	// 18.Verify that in case of Enhanced ePub, Three CFI link options are also
	// displayed in form of radio button ONLY when destination is selected as
	// CoreSource
	//@Test(priority = 19)   ####### Functionality obsolete #######
	public void Verify_In_Case_Of_Enhanced_EPub_Three_CFI_Link_Options_Are_Displayed() {
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.VerifyThreeOptionsDisplayedInPublish();

		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
		test.ContentView.VerifyThreeOptionsNotDisplayedInPublish();
	}

	// 19."Verify that in case of CFI file push:
	// 1) Step 1 is named as: Step 1 Index the CFI links metadata in Courseware
	// 2) there is no destination platform, instead of this message appears as: **
	// The publish action will overwrite any previous indexes in Courseware"
	@Test(priority = 20)
	public void Verify_For_Publishing_CFI_File_There_Is_No_Destination_Platform() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.ClickOpenAssetOnProjectView(ISBN+"_CFI.csv",ContentTypeCFI);
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyDestinationIsNotDisplayed();
		test.ContentView.VerifyStep1NameForCFIPublish();
	}

	// 20."Verify that Select Destination has drop down with the following
	// option:1)Coresource 2)Palgrave"
	@Test(priority = 21)
	public void Verify_Select_Destination_Has_Coresource_Palgrave_Option() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishLink();
		test.ContentView.selectDestinationOfPublish(PublihDestinationCoreSource);
		test.ContentView.selectDestinationOfPublish(PublihDestinationPalgrave);
	}

	// 21.Verify that Selected Assets Section display the name of the content
	@Test(priority = 22)
	public void Verify_Selected_Assets_Section_Display_Name_Of_Asset() {
		test.ContentView.VerifySelectedAssetsSectionDisplayName(ISBN);
	}

	// 22.Verify that Publish Assets has Approve and Approve button and following
	// information related to content:
	// 1. File Name
	// 2. Type
	// 3. Status
	// 4. Repository
	@Test(priority = 23)
	public void Verify_Publish_Assets_Has_Approve_And_Approve_Button_And_Related_Information() {
		test.ContentView.VerifyPublishAssetsHasApproveAndApproveButton();
		test.ContentView.VerifyPublishAssetsDetailsAreProvided();
	}

	// 23.Verify that user is able to change Status of the content to Approve by
	// selecting content and clicking on the Approve Button
	@Test(priority = 24)
	public void Verify_User_Is_Able_To_Change_Status_Of_Content_To_Approve() {
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
	}

	// 24.Verify that user is able to change Status of the content to Unapprove by
	// selecting content and clicking on the Unapprove Button
	@Test(priority = 25)
	public void Verify_User_Is_Able_To_Change_Status_Of_Content_To_UnApprove() {
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
	}

	// 25.Verify that user is able to publish Content if status is approved
	@Test(priority = 26)
	public void Verify_User_Is_Able_To_Publish_Content_If_Status_Approved() {
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 26.Verify that Publish pop has Publish and cancel button at bottom
	@Test(priority = 27)
	public void Verify_Publish_Pop_Has_Publish_And_Cancel_Button() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishAndCancelButtonOnPublishPopUp();
	}

	// 27.Verify that in case of Enhanced ePub, user can publish by selecting the
	// second radio button
	@Test(priority = 28)
	public void Verify_In_Enhanced_EPub_User_Can_Select_Second_Radio_Button() {
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.SelectPublishRadioButton("Publish content links only");
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();
	}

	// 28.Verify that in case of Enhanced ePub, user can publish the ePub along with
	// CFI link by selecting the First radio button
	@Test(priority = 29)
	public void Verify_In_Enhanced_EPub_User_Can_Select_First_Radio_Button() {
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.SelectPublishRadioButton("Publish content links and ePub");
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.SelectPublishRadioButton("Publish content links and ePub");
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsNotPublished();
	}

	// 29.Verify that in case of Enhanced ePub, user can publish the ePub without
	// selecting any option related to CFI link provided that the state is Approved
	@Test(priority = 30)
	public void Verify_In_Case_Of_Enhanced_Epub_Epub_Can_Be_Published_Without_Selecting_Any_Option_Related_To_CFI() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.selectDestinationOfPublish(PublihDestinationVitalSource);
		test.ContentView.SelectEpubOnPublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsNotPublished();

	}

	// 30.Verify that in case of CFI link file, it can be published irrespective of
	// the Approved/ Unapproved state
	@Test(priority = 31)
	public void Verify_CFI_File_Can_Be_Published_Irrespective_Of_The_State() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_CFI.csv");
		test.Contentpage.opentheSearchContent(ISBN+"_CFI.csv");
		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectCFIOnPublishPopUp();
		test.ContentView.ClickUnApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

		test.ContentView.ClickPublishLink();
		test.ContentView.VerifyPublishPopUpDisplayed();
		test.ContentView.SelectCFIOnPublishPopUp();
		test.ContentView.ClickApproveButtonOnPublishPopUp();
		test.ContentView.clickpublishOnPublishPopUp();
		test.ContentView.VerifyContentIsPublished();

	}

	// 31.Verify that Publish details can be tracked under Publish details tab on
	// Content view page
	@Test(priority = 32)
	public void Verify_Publish_Details_Can_Be_Tracked_Under_Publish_Detail() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.ClickPublishDetail();
		test.ContentView.VerifyPublishDetailsAreDisplayed();
	}

	// 32.Verify that clicking on the Cancel button on the Publish popup closes the
	// popup
	@Test(priority = 33)
	public void Verify_Cancel_Button_Closes_PublishPopUp() {
		test.ContentView.ClickPublishLink();
		test.ContentView.ClickCancelOnPublishPop();
		test.ContentView.VerifyPublishPopIsClosed();
	}

	// 33.Verify that clicking on the Download content download selected content
	@Test(priority = 34)
	public void Verify_Clicking_Download_Content_Download_Starts() {
		test.ContentView.ClickDownloadContent();
		test.Contentpage.VerifyDownloadIsStartedFromContantTab(ISBN + ".epub");
	}

	// 34.Verify that user is able to edit the information in the Content Details
	// tab, Relationship tab, Push details tab on clicking on the Edit button
	@Test(priority = 35)
	public void Verify_User_Is_Able_To_Edit_Information_In_Content_Details_Tab() throws IOException {
		test.ContentView.ClickEditLink();
		test.ContentView.EditAssetDetail();
		test.ContentView.VerifyDetailUpdated();
	}

	// 35.Verify that clicking on the edit button Workflow Status Drop down, publish
	// and more link disappears
	@Test(priority = 36)
	public void Verify_clicking_Edit_Button_Workflow_Status_Publish_More_Link_Disappears() {
		test.ContentView.ClickEditLink();
		test.refreshPage();
		test.ContentView.VerifyClickingWorkflowPublish_MoreLinkDisable();
	}

	// 36.Verify that Clicking on the Delete link Content Is Deleted.
	@Test(priority = 37)
	public void Verify_Clicking_Delete_Content_Is_Deleted() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.HomePage.ClickUploadContent();
		test.Contentpage.UploadContentFromContentPage(ISBN1);
		test.ContentView.DeleteContentFromCMS();
	}

	// 37."Verify that more has following option in drop down list:
	// 1. View Rights Details
	// 2. View Usage Details
	// 3. View Epub Files
	// 4. Push to Authoring Tool"
	@Test(priority = 38)
	public void Verify_Options_In_More_Link() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifyTopLinksAreAvailabe();
	}

	// 38.Verify that Push to Authoring tool is in Deactivated state if Status is
	// not Structural Validation Complete
	@Test(priority = 39)
	public void Verify_Push_To_Authoring_Tool_Deactivated_If_Status_Is_Not_Structural_Validation_Complete() {
		test.ContentView.VerifyPushToAuthoringToolIsEnabledOnlyForStructuralValidation();
	}

	// 39.Verify that clicking on the View Rights Details links from the more drop
	// down, a message is displayed.
	@Test(priority = 40)
	public void Verify_User_Is_Able_To_See_Right_Details() {
		test.refreshPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewRightsDetails();
		test.ContentView.VerifyCorrectRightDetailMsgIsDisplayed();
	}

	// 40.Verify that Clicking on the View Usage Details link from the more drop
	// down list than the Project Association for this Asset pop up open
	@Test(priority = 41)
	public void Verify_User_Is_Able_To_View_Usage_Details_For_Project_Association() {
		test.refreshPage();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewUsageDetails();
		test.ContentView.VerifyViewUsageDetailPopUpDisplay();
	}

	// 41.Verify that Project Association for this Asset pop up has the search field
	// and clear all link
	@Test(priority = 42)
	public void Veriy_Usage_Details_PopUp_Has_Search_Field_And_Clear_Link() {
		test.ContentView.verifySearchFieldAndClearAllLinkOnAddtoProjectpopUp();
	}

	// 42."Verify that Project Association for this Asset pop has following
	// information:
	// 1. ISBN
	// 2. Author
	// 3. Title
	// 4. Edition
	// 5. Copyright year
	// 6. Version type"
	@Test(priority = 43)
	public void Verify_Information_On_Usage_Details_PopUp() {
		test.ContentView.VerifyInformationOnUsageDetail();
	}

	// 43.Verify that clicking on the View Epub Files link in the more dropdown list
	// opens the Exploded Epubs pop up
	@Test(priority = 44)
	public void Verify_Clicking_On_The_View_Epub_Opens_Exploded_Epubs_popUp() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickViewEpubFiles();
		test.ContentView.VerifyExplodedEpubPopUpDisplay();
		test.ContentView.ClickX_OnWindow();
	}

	// 44.Verify that Push to Authoring tool is in activated state if Status is
	// Structural Validation Complete
	@Test(priority = 45)
	public void Verify_Push_To_Authoring_Tool_Activated_If_Status_Is_Structural_Validation_Complete() {
		test.ContentView.VerifyPushToAuthoringToolIsEnabledOnlyForStructuralValidation();
	}

	// 45.Verify that clicking on the Push to authoring tool link opens the pop up
	@Test(priority = 46)
	public void Verify_Clicking_Push_To_Authoring_Tool_PopUp_Opens() {
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
	}

	// 46.Verify that clicking on the Push to Authoring Tool link pop up open with
	// three sub categories
	@Test(priority = 47)
	public void Verify_Push_To_Authoring_Tool_Has_Three_Sub_Categories() {
		test.ContentView.VerifySubCategoriesInPushToAuthoringTool();
	}

	// 47.Verify that user is able to Select Authoring platform from the Step 1 drop
	// down
	@Test(priority = 48)
	public void Verify_User_Is_Able_To_Select_Authoring_Platform() {
		test.ContentView.SelectPushPlatformOnAuthoringTool("Frost");
	}

	// 48.Verify that Push to Authoring Tool pop up has Step 2 Selected Assets
	// section
	@Test(priority = 49)
	public void Verify_Push_To_Authoring_Tool_Has_Selected_Assets_Section() {
		test.ContentView.VerifySelectedAssetsSection();
	}

	// 49.Verify that Step 2 Selected Assets section has view button
	@Test(priority = 50)
	public void Verify_View_On_Button_Selected_Assets_Section() {
		test.ContentView.VerifyViewButtonOnPushToAuthoringTool();
	}

	// 50.Verify that Step 2 Selected Assets section has the thumbnail of the
	// content
	@Test(priority = 51)
	public void Verify_Thumbnail_View_Of_The_Content() {
		test.ContentView.VerifyGridView();
		test.ContentView.VerifyListView();
	}

	// 51."Verify that table is displayed with the following info :Title
	// created by
	// type
	// Data Modified
	// Status
	// in the Step 2 Selected Assets section if its is in list view"
	@Test(priority = 52)
	public void Verify_List_Table_Displays_Info() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyListView();
	}

	// 52.Verify that Push to Authoring Tool pop up has Step 3 Select Project ISBN
	@Test(priority = 53)
	public void Verify_Step_3_Has_Select_Project_ISBN_In_Authoring_Tool() {
		test.ContentView.VerifySelectProjectOnAuthoringTool();
	}

	// 53.Verify that Step 3 Select Project ISBN section has the help icon
	@Test(priority = 54)
	public void Verify_Help_Icon() {
		test.ContentView.VerifyInfoIsDisplayedOnClickingHelpIcon();
	}

	// 54.Verify that Step 3 Select Project ISBN section has the Search field
	@Test(priority = 55)
	public void Verify_Search_Field_On_Authoring_Tool() {
		test.ContentView.VerifySearchFieldOnAuthoringTool();
	}

	// 55.Verify that Searched isbn in search field are displayed in the table
	// present in the Step 3 Select Project ISBN section
	@Test(priority = 56)
	public void Verify_Searched_Isbn_Project_Is_Displayed() {
		test.ContentView.SearchProjectOnAuthoringTool(ISBN);
		test.ContentView.VerifyProjectIsDisplayedOnAuthoringTool(ISBN);
		test.ContentView.ClickX_OnWindow();
	}

	// 56.Verify that user is able to push the content to Frost platform on clicking
	// on the push button
	@Test(priority = 57)
	public void Verify_User_Is_Able_To_Push_The_Content_To_Frost() {
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+"_EPUB.epub");
		test.Contentpage.opentheSearchContent(ISBN+"_EPUB.epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.SelectPushPlatformOnAuthoringTool("Frost");
		test.ContentView.SelectCSSOption("clearCss");
		test.ContentView.SearchProjectOnAuthoringTool(ISBN);
		test.ContentView.VerifyProjectIsDisplayedOnAuthoringTool(ISBN);
		test.ContentView.SelectProjectOnAuthoringTool(ISBN);
		test.ContentView.ClickPushOnAuthoringTool();
		test.ContentView.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.ContentView.VerifyContentHistoryTableActionUpdated(FrostHistoryUpdate + "" + ISBN);
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickGoToFrost();
		test.ContentView.changeWindow(1);
		test.projectView.LoginIntoFrost(FrostEmail, FrostPassword);
		test.projectView.VerifyProjectIsCreatedAtFrost(ISBN, FrostCreatedProjectName);
		test.ContentView.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	// 57.Verify that clicking on the Cancel button on the Push to Authoring Tool
	// popup closes the popup
	@Test(priority = 58)
	public void Verify_Clicking_Cancel_Button_Authoring_Tool_PopUp_Closes() {
		test.ContentView.changeWindow(0);
		test.refreshPage();
		test.ContentView.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.ClickCancelOnAuthoringTool();
		test.ContentView.VerifyAuthoringToolClosed();
	}

	// 58."Verify that content view page has following tabs on right side of the
	// window :Content Details, Relationships, Publish Details, Version Details"
	@Test(priority = 59)
	public void Verify_All_The_SubTab_Are_Displayed_In_ContentView() {
		test.HomePage.ClickContentTab();
		test.HomePage.waitForLoaderToDisappear();
		test.Contentpage.SearchForAnItem(ISBN+".epub");
		test.Contentpage.opentheSearchContent(ISBN+".epub");
		test.ContentView.VerifySubTabAreDispalyed();
	}

	// 59.Verify that Content Details tab has various fields
	@Test(priority = 60)
	public void Verify_Various_Fields_Of_Content_Details_Tab() {
		test.ContentView.VariousFieldOfContentDetails(TypesOfContentEnhancedEpub);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}