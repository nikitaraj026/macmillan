package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Project_Tab_Test extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, ISBN;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		ISBN = getData("ProjectISBNNO");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// 1.LogIn
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 2.Verify that user gets landed on 'Project page' after clicking on the
	// Project tab
	@Test(priority = 2)
	public void Verify_User_landed_On_Project_page() {
		test.HomePage.VerifyProjectTabIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
	}

	// 3.Verify that 'Projects' heading is appearing at top right of the facets
	// section
	@Test(priority = 3)
	public void Verify_Project_appering_On_Top_Right() {
		test.HomePage.VerifyProjectTabIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
	}

	// 4."Verify that user navigates to Dashboard after clicking on the home link
	// present under Projects heading"
	@Test(priority = 4)
	public void Verify_User_Navigates_To_Dashboard_After_Clicking_Home() {
		test.ProjectPage.clickhomeLink();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 5.Verify that on the project page Result number ,Sort by dropdown and list/
	// grid view buttons are present on the right side of the window
	@Test(priority = 5)
	public void VerifyOptionsAvailableAtTheTopOfProjectTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyAllTheOptions();

	}

	// 6.Verify that user can display the search results to 10, 20, 50 and 100
	@Test(priority = 6)
	public void Verify_User_Is_Able_To_Select_Number_From_Result_Drop_Down() {
		test.ProjectPage.SelectNumberFromResultDropDown("10");
		test.ProjectPage.VerifyCorrectNumberOfContentAreDisPlayed("10");

		test.ProjectPage.SelectNumberFromResultDropDown("20");
		test.ProjectPage.VerifyCorrectNumberOfContentAreDisPlayed("20");
	}

	// 7.Verify that user is able sort the project by selecting sorting option from
	// the sort by drop down option
	@Test(priority = 7)
	public void Verify_Content_Is_Sorted_Accordingly_By_SortBy() {
		test.ProjectPage.verifyAlltheOptionsInSortBy();
	}

	// 8.Verify that user can sort the results by Author, Title, ISBN, Modified
	@Test(priority = 8)
	public void Verify_User_Can_Sort_Results_By_Author_Title_ISBN_And_Modified() {
		test.ProjectPage.verifyAlltheOptionsInSortBy();
	}

	// 9.Verify that user is able to see Projects in gridview after clicking on the
	// Gridview button
	@Test(priority = 9)
	public void Verify_User_Is_Able_To_See_Projects_In_Gridview() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyPreviewOfProject();
	}

	// 10.Verify that user is able to see Projects in the list view on clicking on
	// the List view button
	@Test(priority = 10)
	public void Verify_Clicking_List_View_project_Displayed_In_List_View() {
		test.refreshPage();
		test.HomePage.clickProjectTab();
		test.ProjectPage.clickListView();
		test.ProjectPage.VerifyCorrectNumberOfContentAreDisPlayed("20");
	}

	// 11.Verify that all the projects are listed on the page with following
	// details: Author, Title, Short Title, ISBN, Publication Date, Project Status
	// and View
	@Test(priority = 11)
	public void Verify_Projects_Are_Presented_with_Coloum_Defination() {
		test.ProjectPage.verifyColumnsAreDisplayed();
	}

	// 12.Verify that clicking on the view icon present at right of the table with
	// every project respectively user is navigated to project view page for
	// particular project
	@Test(priority = 12)
	public void Verify_On_Clicking_View_Navigates_To_Project_view() {
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.ProjectPage.verifyUserIsOnProjectView();
	}

	// 13.Verify that user is not able to select the project from the table
	@Test(priority = 13)
	public void Verify_User_Is_Not_Able_To_Select_Project_CheckBoxs() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyCheckBoxAreNotSelected();
	}

	// 14.Verify that a pagination bar is present at the bottom of Project page tab
	// which enables an end user to navigate back and forth
	@Test(priority = 14)
	public void VerifyPaginationBarIsPresent() {
		test.ProjectPage.VerifyPaginationBarIsVisible();
	}

	// 15.Verify that in Gridview- User can navigate by clicking on the thumbnail or
	// the project name
	@Test(priority = 15)
	public void Verify_That_Gridview_User_Can_Navigate_By_Clicking_On_Thumbnail() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyThumbnailViewIsWorking();
	}

	// 16.Verify that user is not able to select the project using the checkboxes
	// available to the left
	@Test(priority = 16)
	public void Verify_User_Is_Not_Able_To_Select_Project_CheckBoxs_Available_At_Left() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.clickListView();
		test.ProjectPage.VerifyCheckBoxAreNotSelected();
	}

	// 17.Verify that check-boxes are now appearing in the first column of the table
	// in List view/Grid view on Project Page.
	@Test(priority = 17)
	public void Verify_CheckBoxes_Are_Appearing_In_List_And_Grid_View() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
	}

	// 18.Verify that check-boxes are now appearing in the first column of the table
	// in List view/Grid view on Generic search result page
	@Test(priority = 18)
	public void Verify_CheckBoxes_Are_Appearing_In_List_And_Grid_View_For_Generic_Search() {
		test.HomePage.ClickDashBord();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.clickListView();
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyCheckBoxAreApperingAndDisabledForProject();
	}

	// 19."Verify that the Table column header has been renamed to 'CMS Project
	// Status' from 'Project Status' for below workflows: b) Dashboard> Projects
	// tab> Projects table"
	// BS-2212
	@Test(priority = 19)
	public void Verify_Table_Column_Header_Has_Been_Renamed_To_CMS_Project_Status() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.clickListView();
		test.ProjectPage.verifyColumnsAreDisplayed();
	}

	// 20.Verify that user is able to un-mark the Project from Favorite table by
	// clicking the Star icon. The Filled Star icon is getting changed to the
	// Outlined Star icon. Also, a relevant toaster message is displayed.
	// BS-2224
	@Test(priority = 20)
	public void Verify_That_User_Is_Able_To_Unmark_Project_From_Favorite_Table_Clicking_Star_Icon() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.ProjectPage.RemoveProjectFromFavorite(ISBN);
		test.ProjectPage.VerifyProjectIsMarkedUnfavorite(ISBN);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
