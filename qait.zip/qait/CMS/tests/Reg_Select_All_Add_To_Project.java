package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Select_All_Add_To_Project extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, PageSelectionAllPages;
	String AddtoProjectSelectAllAlert, DeleteAssetSelectAll, ISBN, SearchTypeAllType;
	String SearchTypeProject, SearchTypeContent, TestISBN3, TestISBN2;
	String UploadImageFile, ContentTypeImageSource, FileTitle;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		PageSelectionAllPages = getData("PageSelection.All Pages");
		AddtoProjectSelectAllAlert = getData("SelectAllAssetAddToProject");
		DeleteAssetSelectAll = getData("SelectAllAssetDelete");
		ISBN = getData("ProjectISBNNO");
		TestISBN2 = getData("ProjectISBNNo3");
		TestISBN3 = getData("ProjectISBNNo4");
		SearchTypeAllType = getData("SearchType.All Types");
		SearchTypeProject = getData("SearchType.Project");
		SearchTypeContent = getData("SearchType.content");
		UploadImageFile = getData("TestData.ImageFile");
		ContentTypeImageSource = getData("TypesOfContent.Images>Image Source");
		FileTitle = getStringWithDateAndTimes("AuthorFieldTest");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1."ADD TO PROJECT> For Basic and Advanced Search
	// a) Verified that user is able to add the assets to Single Project after
	// selecting them via Select 'All Pages' option."
	// BS-2935
	@Test(priority = 2)
	public void Verify_User_Is_Able_To_Add_The_Assets_By_All_Pages_Selection() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem("Test");
		test.Contentpage.ClickPageSelectionDropDown();
		test.Contentpage.SelectPageType(PageSelectionAllPages);
		test.Contentpage.ClickAddToProject();
		test.Contentpage.verifyAlertText(AddtoProjectSelectAllAlert);
		test.Contentpage.handleAlert();
		test.Contentpage.VerifyAddtoProjectpopUp();
	}

	// 2."DELETE Validation> For Basic and Advanced Search
	// a) Verified that user is getting a validation message pop up on the browser
	// containing the below text: Deletion for more than 10 assets is not permitted.
	// when user selects more than 10 assets via Select 'All Pages' option and
	// clicks the Delete link."
	// BS-2935
	@Test(priority = 3)
	public void Verify_Validation_Message_For_Deleting_More_Than_10_Asset_SelectAll() {
		test.Contentpage.ClickCloseButton();
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.verifyAlertText(DeleteAssetSelectAll);
		test.Contentpage.handleAlert();
		test.Contentpage.VerifyDeletePopupNotDisplayed();
	}

	// 3. "DELETE Validation> For Basic and Advanced Search
	// b) Verified that user is able to delete 10 or less than 10 assets via Delete
	// link after selecting them via Select 'All Pages' option."
	// BS-2935
	@Test(priority = 4)
	public void Verify_User_Is_Able_To_Delete_10_Or_Less_Than_10() {
		test.Contentpage.SearchForAnItem("\"" + ISBN + " epub\"");
		test.Contentpage.SelectPageType(PageSelectionAllPages);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.verifyAlertText(AddtoProjectSelectAllAlert);
		test.Contentpage.handleAlert();
		test.Contentpage.VerifyDeletePopupDisplayed();
	}

	// 4."DASHBOARD: Verify that following metadata field and values are getting
	// displayed under the Project Thumbnail, in four rows:
	// Author: Author Value
	// Title: Title Value
	// Edition: Edition Value
	// ISBN: ISBN Value
	// BS-2526
	@Test(priority = 5)
	public void Verify_Correct_Metadata_Displayed_For_Project_Thumbnail_DashBoard() {
		test.refreshPage();
		test.Contentpage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchForProject(ISBN);
		test.ProjectPage.AddProjectToFavoriteFromProjectTabListView(ISBN);
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickGridView();
		test.HomePage.VerifyThumbnailinGridView();
		test.HomePage.VerifyFavoriteInformationInGridView();
	}

	// 5."PROJECT TAB: Verify that following metadata field and values are getting
	// displayed under the Project Thumbnail, in four rows:
	// Author: Author Value
	// Title: Title Value
	// Edition: Edition Value
	// ISBN: ISBN Value
	// BS-2526
	@Test(priority = 6)
	public void Verify_Correct_Metadata_Displayed_For_Project_Thumbnail_ProjectTab() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.clickGridView();
		test.ProjectPage.VerifyProjectInfoIsDisplayedOnGridView();
	}

	// 6."CONTENT VIEW PAGE> ASSOCIATED PROJECTS Verify that following metadata
	// field and values are getting displayed under the Project Thumbnail, in four
	// rows:
	// Author: Author Value
	// Title: Title Value
	// Edition: Edition Value
	// ISBN: ISBN Value"
	// BS-2526
	@Test(priority = 7)
	public void Verify_Correct_Metadata_Displayed_For_Project_Thumbnail_ContentView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.clickListView();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.VerifyAssociatedProjectDetail();
	}

	// 7."CONTENT TAB: Verify that following metadata field and values are getting
	// displayed under the Asset Thumbnail, in four rows:
	// Title: Title Value
	// File Name: File Name Value
	// Content Type: Content Type>Content Subtype Value
	// Last Updated: Time/Date Updated
	// BS-2526
	@Test(priority = 8)
	public void Verify_Correct_Metadata_Displayed_For_Content_Thumbnail_ContentTab() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyOnGridView();
		test.Contentpage.VerifyContentInfoOnGridView();
	}

	// 8."PROJECT VIEW> ASSOCIATED CONTENT:Verify that following metadata field and
	// values are getting displayed under the Asset Thumbnail, in four rows:
	// Title: Title Value
	// File Name: File Name Value
	// Content Type: Content Type>Content Subtype Value
	// Last Updated: Time/Date Updated
	// BS-2526
	@Test(priority = 9)
	public void Verify_Correct_Metadata_Displayed_For_Content_Thumbnail_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.clickListView();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.VerifyAssociatedContentDetailDisplayed();
	}

	// 9."PROJECT VIEW> PUSH TO AUTHORING TOOL WINDOW: Verify that following
	// metadata field and values are getting displayed under the Asset Thumbnail, in
	// four rows:
	// Title: Title Value
	// File Name: File Name Value
	// Content Type: Content Type>Content Subtype Value
	// Last Updated: Time/Date Updated
	// BS-2526
	@Test(priority = 10)
	public void Verify_Correct_Metadata_Displayed_For_Content_Thumbnail_ProjectView_Push_To_Authoring_Tool() {
		test.projectView.Click_Ready_For_Enhancements();
		test.projectView.clickTopLinkMore();
		test.projectView.clickPushToAuthoringTool();
		test.projectView.VerifyPushToAuthoringToolPopUp();
		test.projectView.VerifyContentMetadataOnPushToAuthoringTool();
		test.projectView.ClickCloseButton();
	}

	// 10."CONTENT VIEW> PUSH TO AUTHORING TOOL WINDOW: Verify that following
	// metadata field and values are getting displayed under the Asset Thumbnail, in
	// four rows:
	// Title: Title Value
	// File Name: File Name Value
	// Content Type: Content Type>Content Subtype Value
	// Last Updated: Time/Date Updated
	// BS-2526
	@Test(priority = 11)
	public void Verify_Correct_Metadata_Displayed_For_Content_Thumbnail_ContentView_Push_To_Authoring_Tool() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.clickTopLinkMore();
		test.ContentView.ClickPushToAuthoringTool_();
		test.ContentView.VerifyPushToAuthoringToolPopUp();
		test.ContentView.VerifyContentMetadataOnPushToAuthoringTool();
		test.ContentView.ClickX_OnWindow();
	}

	// 11."Generic Search> All Types Verify that following metadata field and values
	// are getting displayed under the Project Thumbnail, in four rows:
	// Author: Author Value
	// Title: Title Value
	// Edition: Edition Value
	// ISBN: ISBN Value"
	// BS-3146
	@Test(priority = 12)
	public void Verify_Metadata_Field_For_Project_Gridview_ContentTab() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SelectSearchType(SearchTypeAllType);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyProjectInfoOnGridView();

	}

	// 12."Generic Search> All Types Verify that following metadata field and values
	// are getting displayed underthe Asset Thumbnail, in four rows:
	// Title: Title Value
	// File Name: File Name
	// Value Content Type: Content Type>Content Subtype Value
	// Last Updated: Time/Date Updated"
	// BS-3146
	@Test(priority = 13)
	public void Verify_Metadata_Field_For_Content_Gridview_ContentTab() {
		test.Contentpage.VerifyContentInfoOnGridView();

	}

	// 13."Generic Search> Projects Verify that following metadata field and values
	// are getting displayed under the Project Thumbnail, in four rows:
	// Author: Author Value
	// Title: Title Value
	// Edition: Edition Value
	// ISBN: ISBN Value"
	// BS-3146
	@Test(priority = 14)
	public void Verify_Metadata_Field_For_Project_Gridview_GenericSearch() {
		test.Contentpage.SelectSearchType(SearchTypeProject);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.ClickGridView();
		test.Contentpage.VerifyProjectInfoOnGridView();

	}

	// 14."Generic Search> Content Verify that following metadata field and values
	// are getting displayed under the Asset Thumbnail, in four rows:
	// Title: Title Value
	// File Name: File Name Value
	// Content Type: Content Type>Content Subtype Value
	// Last Updated: Time/Date Updated
	// BS-3146
	@Test(priority = 15)
	public void Verify_Metadata_Field_For_Content_Gridview_GenericSearch() {
		test.Contentpage.SelectSearchType(SearchTypeContent);
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN);
		test.Contentpage.VerifyContentInfoOnGridView();
	}

	// "1) Project view> Upload Content:
	// a) Verified that the current value of 'Short Title' field is now displaying
	// for the default project under 'Selected' section in the Upload Content> Add/
	// Remove Projects window.
	// BS-2400
	@Test(priority = 16)
	public void Verify_ShortTitle_Field_Not_Empty_In_AddRemove_Project() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.ClickAddRemoveProject();
		test.projectView.VerifyAddtoProjectpopUp();
		test.projectView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// "b) Verified that if user removes the Project from the 'Selected Pane' and
	// adds again, then also the 'Short Title' field value is displaying.
	// BS-2400
	@Test(priority = 17)
	public void Verify_ShortTitle_Field_Not_Empty_After_Adding_Project() {
		test.projectView.MoveProjectFromSelectedPaneToAvailablePane(ISBN);
		test.projectView.SearchProjectInAddRemovePopUp(ISBN);
		test.projectView.MoveProjectFromAvailablePaneToSelectedPane(ISBN);
		test.projectView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// "c) Verified that if user adds multiple other Projects to the 'Selected
	// Pane', then 'Short Title' field value is displaying for each Project.
	// BS-2400
	@Test(priority = 18)
	public void Verify_ShortTitle_Field_Not_Empty_After_Adding_Multiple_Project() {
		test.projectView.SearchProjectInAddRemovePopUp(TestISBN2);
		test.projectView.MoveProjectFromAvailablePaneToSelectedPane(TestISBN2);
		test.projectView.SearchProjectInAddRemovePopUp(TestISBN3);
		test.projectView.MoveProjectFromAvailablePaneToSelectedPane(TestISBN3);
		test.projectView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// d) Verified the same across the pagination.
	// BS-2400
	@Test(priority = 19)
	public void Verify_ShortTitle_Field_Not_Empty_Across_Pagination() {
		test.projectView.SearchProjectInAddRemovePopUp("*");
		test.projectView.ClickSelectAllAddRemoveAvailableSection();
		test.projectView.ClickSelectButtonOnAddRemoveWindow();
		test.projectView.NavigateToPageNumberInAvailablePane("2");
		test.projectView.ClickSelectAllAddRemoveAvailableSection();
		test.projectView.ClickSelectButtonOnAddRemoveWindow();
		test.projectView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
		test.projectView.NavigateToPageNumberInSelectedPane("2");
		test.projectView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// "2) Home> Upload Content:
	// a) Verified that if user adds Single or Multiple Projects to the 'Selected
	// Pane', then 'Short Title' field value is displaying for each Project."
	// BS-2400
	@Test(priority = 20)
	public void Verify_ShortTitle_Field_Not_Empty_DasdBoard() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(ISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(ISBN);
		test.HomePage.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN2);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN2);
		test.HomePage.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// b) Verified the same across the pagination.
	// BS-2400
	@Test(priority = 21)
	public void Verify_ShortTitle_Field_Not_Empty_Across_Pagination_DashBorad() {
		test.HomePage.SearchProjectInAddRemovePopUp("*");
		test.HomePage.ClickSelectAllAddRemoveAvailableSection();
		test.HomePage.ClickSelectButtonAddRemoveProject();
		test.HomePage.NavigateToPageNumberInAvailablePane("1");
		test.HomePage.ClickSelectAllAddRemoveAvailableSection();
		test.HomePage.ClickSelectButtonAddRemoveProject();
		test.HomePage.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
		test.HomePage.NavigateToPageNumberInSelectedPane("2");
		test.HomePage.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// "3) Content Page view> Associated Projects section:
	// a) Verified that 'Short Title' field value is displaying for all the Projects
	// that are available under 'Selected' pane."
	// BS-2400
	@Test(priority = 22)
	public void Verify_ShortTitle_Field_Not_Empty_ContentView() {
		test.refreshPage();
		test.HomePage.waitForLoaderToAppearAndDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItemWithOutSearchType(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickAddRemoveProject();
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.SearchForProjectOnAddRemoveProject(TestISBN3);
		test.ContentView.SelectProjectInAvailablePane(TestISBN3);
		test.ContentView.ClickSelectButtonOnAddRemovePop();
		test.ContentView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();

	}

	// b) Verified that if user adds Single or Multiple Projects to the 'Selected
	// Pane', then also 'Short Title' field value is displaying for each Project.
	// BS-2400
	@Test(priority = 22)
	public void Verify_ShortTitle_Field_Not_Empty_After_Adding_Multiple_Project_ContentView() {
		test.ContentView.VerifypopAddRemovePopUp();
		test.ContentView.SearchForProjectOnAddRemoveProject(TestISBN2);
		test.ContentView.SelectProjectInAvailablePane(TestISBN2);
		test.ContentView.ClickSelectButtonOnAddRemovePop();
		test.ContentView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// c) Verified the same across the pagination.
	// BS-2400
	@Test(priority = 23)
	public void Verify_ShortTitle_Field_Not_Empty_Across_Pagination_ContentView() {
		test.ContentView.SearchForProjectOnAddRemoveProject("*");
		test.ContentView.ClickSelectAllCheckBoxOnAvailablePane();
		test.ContentView.ClickSelectButtonOnAddRemovePop();
		test.ContentView.NavigateToPageNumberInAvailablePane("2");
		test.ContentView.ClickSelectAllCheckBoxOnAvailablePane();
		test.ContentView.ClickSelectButtonOnAddRemovePop();
		test.ContentView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
		test.ContentView.NavigateToPageNumberInAvailablePane("2");
		test.ContentView.verifyShortTitleFieldOnAddRemoveIsNotEmpty();
	}

	// " Verify through Dashboard> Upload Content
	// 1) User is successfully able to navigate to Content view page after clicking
	// the Upload button irrespective of number of Projects added at the time of
	// Upload."
	// BS-3310
	@Test(priority = 24)
	public void Verify_User_Navigates_To_ContentView_After_uploading() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(UploadImageFile);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(ContentTypeImageSource);
		test.HomePage.EnterTextIntoTitleField(FileTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(ISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(ISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(ISBN);
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN2);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN2);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN2);
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN3);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN3);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN3);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}

	// "Project view page> Upload Content workflow.
	// 2)Verify through Dashboard> Upload Content
	// 1) User is successfully able to navigate to Content view page after clicking
	// the Upload button irrespective of number of Projects added at the time of
	// Upload."
	// BS-3310
	@Test(priority = 25)
	public void Verify_User_Navigates_To_ContentView_After_Uploading_ProjectView() {
		FileTitle = getStringWithDateAndTimes("AuthorFieldTest");
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectFileUsingBrowseButton(UploadImageFile);
		test.projectView.SelectContentTypeInUploadContentPopup(ContentTypeImageSource);
		test.projectView.EnterTextIntoTitleField(FileTitle);
		test.projectView.ClickAddRemoveProject();
		test.projectView.VerifyAddtoProjectpopUp();
		test.projectView.SearchProjectInAddRemovePopUp(TestISBN2);
		test.projectView.MoveProjectFromAvailablePaneToSelectedPane(TestISBN2);
		test.projectView.SearchProjectInAddRemovePopUp(TestISBN3);
		test.projectView.MoveProjectFromAvailablePaneToSelectedPane(TestISBN3);
		test.projectView.ClickSaveButtonOnAddToProject();
		test.projectView.ClickUploadOnUploadContentPopUpAndVerifyMsg();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}
	
	//Verify that 'Show All' button on the favorite tab should be available once user has marked more than 5 Projects.
	// BS-3310
	@Test(priority = 25)
	public void Verify_ShowAll_Button_For_More_Than_5_Project() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchForProject("9897");
		test.ProjectPage.AddProjectsToFavorite("8");
		test.HomePage.ClickDashBord();
		test.HomePage.VerifyShowAllButtonDisplayed();
		test.HomePage.clickShowAllButton();
		test.HomePage.VerifyShowAllButtonDisplayAllProject();
		test.HomePage.RemoveAllProjectFromFavorite();
	}
	
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}