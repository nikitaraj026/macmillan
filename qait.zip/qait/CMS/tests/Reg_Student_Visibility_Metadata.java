package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Student_Visibility_Metadata extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink;
	String TestISBN, PublihDestinationCourseWare, TypesOfContentInstructorResources;
	String TestImageforNGA, InstructorFileTitle, TypesOfContentStudentResources, StudentFileTitle;
	String TypeOfContentCoverDesign, TypeOfContentImageSource, OtherAssetTitle, OtherAssetTitleImage;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestISBN = getData("ProjectISBNNo1");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		TypesOfContentInstructorResources = getData("TypesOfContent.Supplementary Content>Instructor Resources");
		TypesOfContentStudentResources = getData("TypesOfContent.Supplementary Content>Student Resources");
		TestImageforNGA = "AutoMation NGA_!@#$%ÀÁÂÃÄÅ.jpg";
		TypeOfContentCoverDesign = getData("TypesOfContent.Covers>Cover Design");
		InstructorFileTitle = getStringWithDateAndTimes("Automation_IR");
		StudentFileTitle = getStringWithDateAndTimes("Automation_SR");
		TypeOfContentImageSource = getData("TypesOfContent.Images>Image Source");
		OtherAssetTitle = getStringWithDateAndTimes("AutomationImage");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Upload an Supplementary Content>Instructor Resources

	@Test(priority = 2)
	public void Upload_Supplementary_Content_Instructor_Resources() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentInstructorResources);
		test.HomePage.EnterTextIntoTitleField(InstructorFileTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

	}

	// 1. "When Publish Destination is selected as Courseware> Manual Publish/
	// Update Content metadata tab: Verify that Instructor Resources are
	// displayed with 'i' badge and eye icon with a slash"
	// BS-3042
	@Test(priority = 3)
	public void Verify_Instructor_Resources_Displayed_I_Badge_Eye_Icon_With_Slash() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.VerifyFileIsDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentInstructorResources,
				InstructorFileTitle);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert_Manual_Publish(InstructorFileTitle);
		test.projectView.VerifyAssetIsNotVisibleToStudentManualPublish(InstructorFileTitle);

		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentInstructorResources, InstructorFileTitle);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(InstructorFileTitle);
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);
		test.projectView.ClickCloseButton();
	}

	// Upload an Supplementary Content>Instructor Resources
	@Test(priority = 4)
	public void Upload_Supplementary_Content_Student_Resources() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentStudentResources);
		test.HomePage.EnterTextIntoTitleField(StudentFileTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

	}

	// 2."When Publish Destination is selected as Courseware> Manual Publish/ Update
	// Content metadata tab:
	// Verify that Student Resources are displayed with 's' badge and eye icon"
	// BS-3042
	@Test(priority = 5)
	public void Verify_Student_Resources_Displayed_S_Badge_Eye_Icon() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.VerifyFileIsDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentStudentResources,
				StudentFileTitle);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert_ManualPublish(StudentFileTitle);
		test.projectView.VerifyAssetIsVisibleToStudentManualPublish(StudentFileTitle);

		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentStudentResources, StudentFileTitle);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(StudentFileTitle);
		test.projectView.VerifyAssetIsVisibleToStudent(StudentFileTitle);
	}

	// 3."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:
	// Verify that if User checks any Instructor or Student Resource asset from the
	// repository, then the Access level metadata buttons remains/get disabled and
	// Visibility section buttons get active."
	// BS-3042
	@Test(priority = 6)
	public void Verify_Access_Level_Metadata_Buttons_Remains_Get_Disabled_And_Visibility_Buttons_Get_Active() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyInstructorOnlyMetadataButtonDisabled();
		test.projectView.VerifyStudentOnlyMetadataButtonDisabled();
		test.projectView.VerifyClearAccessLevelMetadataButtonDisabled();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentStudentResources, StudentFileTitle);
		test.projectView.VerifyVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyNotVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyResetToOriginalSystemStatusButtonButtonEnabled();
		test.projectView.VerifyInstructorOnlyMetadataButtonDisabled();
		test.projectView.VerifyStudentOnlyMetadataButtonDisabled();
		test.projectView.VerifyClearAccessLevelMetadataButtonDisabled();

		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentInstructorResources, InstructorFileTitle);
		test.projectView.VerifyVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyNotVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyResetToOriginalSystemStatusButtonButtonEnabled();
		test.projectView.VerifyInstructorOnlyMetadataButtonDisabled();
		test.projectView.VerifyStudentOnlyMetadataButtonDisabled();
		test.projectView.VerifyClearAccessLevelMetadataButtonDisabled();

		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", TypeOfContentCoverDesign,
				TestISBN + "_FC.jpg");
		test.projectView.VerifyVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyNotVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyResetToOriginalSystemStatusButtonButtonEnabled();
		test.projectView.VerifyInstructorOnlyMetadataButtonDisabled();
		test.projectView.VerifyStudentOnlyMetadataButtonDisabled();
		test.projectView.VerifyClearAccessLevelMetadataButtonDisabled();
		
		test.refreshPage();
		test.projectView.waitForLoaderToAppearAndDisappear();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.ClickContentTypeOnUpdateContentMetadata("CMS",TypesOfContentInstructorResources);
		test.projectView.VerifyVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyNotVisibleToStudentButtonButtonEnabled();
		test.projectView.VerifyResetToOriginalSystemStatusButtonButtonEnabled();
		test.projectView.VerifyInstructorOnlyMetadataButtonDisabled();
		test.projectView.VerifyStudentOnlyMetadataButtonDisabled();
		test.projectView.VerifyClearAccessLevelMetadataButtonDisabled();
		
	}

	// 4."When Publish Destination is selected as Courseware> Manual Publish:
	// Verify that if user selects the assets other than Instructor or Student in
	// Step 2 for Publish, then the 'Publish' button remains disabled and following
	// message is displayed below:
	// Please select only Supplementary Content>Instructor / Student Resources"
	// BS-3042
	@Test(priority = 7)
	public void Verify_Message_When_No_Instructor_Or_Student_Resource_Selected() {
		test.projectView.ClickManualPublish();
		test.projectView.VerifyPublishButtonOnPublishPopUpDisabled();
		test.projectView.VerifySelectOnlyInstructorOrStudentResourcesMessageIsDisplayed();
	}

	// 5. Upload An Asset other than Instructor or Student
	@Test(priority = 8)
	public void Upload_An_Sample_Image() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentImageSource);
		test.HomePage.EnterTextIntoTitleField(OtherAssetTitle);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// 6."When Publish Destination is selected as Courseware> Manual Publish/ Update
	// Content metadata tab: Verify that for Other asset (not IR or SR), there is no
	// eye icon (with or without slash) or any badge is displayed by default"
	// BS-3042
	@Test(priority = 9)
	public void Verify_For_Other_Assert_No_eye_Badge_Icon_Displayed() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.VerifyFileIsDisplayedOnStep2ofPublishWindow("CMS", TypeOfContentImageSource, OtherAssetTitle);
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert_Manual_Publish(OtherAssetTitle);
		test.projectView.Verify_S_Badge_Is_Not_Dispalyed_On_Assert_Manual_Publish(OtherAssetTitle);
		test.projectView.VerifyEyeIconNotDisplayedForAssetManualPublish(OtherAssetTitle);

		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyAssetDisplayedInStep2ForCourseware("CMS", TypeOfContentImageSource, OtherAssetTitle);
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert(OtherAssetTitle);
		test.projectView.Verify_S_Badge_Is_Not_Dispalyed_On_Assert(OtherAssetTitle);
		test.projectView.VerifyEyeIconNotDisplayedForAsset(OtherAssetTitle);

	}

	// 7."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:
	// Verify that if user checks any Other asset (not IR or SR) and applies the
	// Instructor level access metadata> then 'i badge' and 'eye icon with slash' is
	// displayed"
	// BS-3042
	@Test(priority = 10)
	public void Verify_I_badge_And_Eye_Icon_with_slash_For_Other_Asset() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", TypeOfContentImageSource,
				OtherAssetTitle);
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitle);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(OtherAssetTitle);
	}

	// 8."Verify that following message is displayed after adding the Instructor
	// metadata: XX asset/s tagged as Instructor Resource"
	// BS-3042
	@Test(priority = 11)
	public void Verify_Message_Displayed_On_Adding_Instructor_Metadata() {
		test.projectView.VerifyAssertAreAddedToInstructorResource();
	}

	// 9."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:
	// Verify that if user checks any Other asset (not IR or SR) and applies the
	// Student level access metadata> then 's badge' and 'eye icon with slash' is
	// displayed"
	// BS-3042
	@Test(priority = 12)
	public void Verify_S_badge_And_Eye_Icon_with_slash_For_Other_Asset() {
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitle);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(OtherAssetTitle);
	}

	// 10."Verify that following message is displayed after adding the Student
	// metadata: XX asset/s tagged as Student Resource"
	// BS-3042
	@Test(priority = 13)
	public void Verify_Message_Displayed_On_Adding_Student_Metadata() {
		test.projectView.VerifyAssertAreAddedToStudentResource();

	}

	// 11."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:
	// Verify that if user checks any Other asset (not IR or SR) and clicks the
	// 'Clear access level metadata button> then 'i' or 's' badge gets removed and
	// no change is made in the Visibility state"
	// BS-3042
	@Test(priority = 14)
	public void Verify_Clicking_Clear_Access_Level_Badges_are_Removed_No_Change_In_Visibility_() {
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.Verify_S_Badge_Is_Not_Dispalyed_On_Assert(OtherAssetTitle);
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert(OtherAssetTitle);
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitle);

		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.Verify_S_Badge_Is_Not_Dispalyed_On_Assert(OtherAssetTitle);
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert(OtherAssetTitle);
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitle);

	}

	// 12."Verify that following message is displayed after adding Clear access
	// level metadata:
	// XX asset/s cleared from Instructor / student Resource type."
	// BS-3042
	@Test(priority = 15)
	public void Verify_Message_Displayed_On_Clear_Access_Level_Metadata() {
		test.projectView.VerifyAssertAreRemovesFromInstructorOrStudentResource();
	}

	// 13."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:User selects IR asset> Clicks 'Visible to Student'> eye icon is
	// displayed no matter what is the previous visibility state"
	// BS-3042
	@Test(priority = 16)
	public void Verify_Eye_Icon_For_IR_Asset_After_Clicking_Visible_To_Student() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentInstructorResources, InstructorFileTitle);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(InstructorFileTitle);
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);
	}

	// 14."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:selects IR asset> Clicks 'Not Visible to Student'> eye icon with
	// slash is displayed no matter what is the previous visibility state"
	// BS-3042
	@Test(priority = 17)
	public void Verify_Eye_Icon_slash_For_IR_Asset_After_Clicking_Not_Visible_To_Student() {
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(InstructorFileTitle);
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);
	}

	// 15."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:User selects IR asset> Clicks 'Reset to Original System Status'>
	// eye icon with slash is displayed no matter what is the previous state"
	// BS-3042
	@Test(priority = 18)
	public void Verify_Eye_Icon_slash_For_IR_Asset_After_Clicking_Reset_To_Original_System_Status() {
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(InstructorFileTitle);
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);

		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(InstructorFileTitle);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentInstructorResources, InstructorFileTitle);
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(InstructorFileTitle);
	}

	// 16."When Publish Destination is selected as Courseware> Update Content
	// metadata tab: User selects SR asset> Clicks 'Visible to Student'> eye icon is
	// displayed no matter what is the previous state"
	// BS-3042
	@Test(priority = 19)
	public void Verify_Eye_Icon_For_SR_Asset_After_Clicking_Visible_To_Student() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypesOfContentStudentResources, StudentFileTitle);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(StudentFileTitle);
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(StudentFileTitle);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(StudentFileTitle);
	}

	// 17."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:User selects SR asset> Clicks 'Not Visible to Student'> eye icon
	// with slash is displayed to the left no matter what is the previous state"
	// BS-3042
	@Test(priority = 20)
	public void Verify_Eye_Icon_Slash_For_SR_Asset_After_Clicking_Not_Visible_To_Student() {
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(StudentFileTitle);
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(StudentFileTitle);
	}

	// 18."When Publish Destination is selected as Courseware> Manual Publish/
	// Update Content metadata tab: User selects SR asset> Clicks 'Reset to Original
	// System Status'> eye icon is displayed to the left no matter what is the
	// previous
	// state"
	// BS-3042
	@Test(priority = 21)
	public void Verify_Eye_Icon_For_SR_Asset_After_Clicking_Reset_To_Original_System_Status() {
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyAssetIsVisibleToStudent(StudentFileTitle);
		test.projectView.ClickManualPublish();
		test.projectView.VerifyFileIsDisplayedOnStep2ofPublishWindow("CMS", TypesOfContentStudentResources,
				StudentFileTitle);
		test.projectView.VerifyAssetIsVisibleToStudentManualPublish(StudentFileTitle);

		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(StudentFileTitle);
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyAssetIsVisibleToStudent(StudentFileTitle);
		test.projectView.ClickManualPublish();
		test.projectView.VerifyAssetIsVisibleToStudentManualPublish(StudentFileTitle);
	}

	// 19. Upload An Asset other than Instructor or Student
	@Test(priority = 22)
	public void Upload_An_Sample_Image1() {
		OtherAssetTitleImage = getStringWithDateAndTimes("AutomationImage");
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageforNGA);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentImageSource);
		test.HomePage.EnterTextIntoTitleField(OtherAssetTitleImage);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// 19.When Publish Destination is selected as Courseware> Update Content
	// metadata tab: If user has applied the Instructor access level to Other Asset,
	// by default eye icon with slash along with i badge is displayed, and if user
	// clicks on 'Reset to Original System Status' button, then eye icon with slash
	// is retained.
	// BS-3042
	@Test(priority = 23)
	public void Verify_For_Other_Asset_Default_And_Reset_To_Original_System_Status_Scenario_For_Instructor_Access() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",TypeOfContentImageSource,
				OtherAssetTitleImage);
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitleImage);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(OtherAssetTitleImage);
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitleImage);
	}
	
	// 20.When Publish Destination is selected as Courseware> Update Content
	// metadata tab: If user has applied the Student access level to Other Asset, by
	// default eye icon with slash is displayed along with s badge, and if user
	// clicks on 'Reset to Original System Status' button, then eye icon with slash
	// is displayed.
	// BS-3042
	@Test(priority = 24)
	public void Verify_For_Other_Asset_Default_And_Reset_To_Original_System_Status_Scenario_For_Student_Access() {
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitleImage);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(OtherAssetTitleImage);
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitleImage);
	}
	
	//21."When Publish Destination is selected as Courseware> Update Content metadata tab:
	// Verify that if user has applied only the visible/ non visible tag to Other
	// Asset, selects the same and clicks on 'Clear Access Level metadata' button,
	// then visible/ non visible tag is not removed."
	// BS-3042
	@Test(priority = 25)
	public void Verify_Visible_Non_Visible_Tag_Not_Removed_On_Clicking_Clear_Access_Level() {
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.VerifyAssetIsNotVisibleToStudent(OtherAssetTitleImage);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(OtherAssetTitleImage);
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.VerifyAssetIsVisibleToStudent(OtherAssetTitleImage);
	}
	

	// Delete the Uploaded Assets::
	// a)Delete Supplementary Content>Instructor Resources
	// b)Delete Supplementary Content>Student Resources Uploaded in Previous Steps
	// c)Delete Test Image
	// d)Delete Test Image1
	@Test(priority=26)
	public void DeleteTheUploadedAssets() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(InstructorFileTitle);
		test.Contentpage.SelectContentOnContentTab(InstructorFileTitle,TypesOfContentInstructorResources);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.Contentpage.SearchForAnItem(StudentFileTitle);
		test.Contentpage.SelectContentOnContentTab(StudentFileTitle,TypesOfContentStudentResources);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.Contentpage.SearchForAnItem(OtherAssetTitle);
		test.Contentpage.SelectContentOnContentTab(OtherAssetTitle,TypeOfContentImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
		
		test.Contentpage.SearchForAnItem(OtherAssetTitleImage);
		test.Contentpage.SelectContentOnContentTab(OtherAssetTitleImage,TypeOfContentImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}
	
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
