package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

import static com.qait.automation.utils.CustomFunctions.getDateString_MM_dd_yyyy_HH_mm;

public class Reg_Recently_Visited_DashBoard extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink;
	String ISBN, TypesOfContentEnhancedEpub, ISBN1, ProjectTitle;
	String SecondUserEmail;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		ISBN = getData("ProjectISBNNO");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		ISBN1 = getData("ProjectISBNNo1");
		ProjectTitle = getData("ProjectTitle1");
		SecondUserEmail = getData("PasswordResetAccount.email");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// 1."A) Recently Visited> Projects> List view:
	// 1) Verified that following Column Headers are available in the Recently
	// visited table
	// a) Grayed out checkbox
	// b) Folder icon
	// c) Favorite Star icon
	// d) Author
	// e) Title
	// f) Short Title
	// g) ISBN
	// h) Content Type(Blank for Projects)
	// i) Repository(Blank for Projects)
	// j) Last Modified Date"
	// BS-2197
	@Test(priority = 2)
	public void Verify_Proper_Coloumn_Header_In_Recently_Visisted_Table() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.ClickOpenAssetOnProjectView(ISBN + ".epub", TypesOfContentEnhancedEpub);
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.VerifyRecentlyVisitedTabIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.Verify_Coloums_On_RecentlyVisited();
		test.HomePage.VerifyCheckBoxGrayedOutOnRecently();
		test.HomePage.VerifyFolderIconForProject(ISBN);
		test.HomePage.VerifyStarIconForProjectRecentlyVisited(ISBN);
		test.HomePage.VerifyContentTypeNotDisplayedForProject(ISBN);
		test.HomePage.verifyRepositoryNotDisplayedForProject(ISBN);
	}

	// 2."A) Recently Visited> Projects> List view:
	// 2) Verified that the Project that is last visited by user gets added in the
	// Recently visited table and the latest one appear on the top."
	// BS-2197
	@Test(priority = 3)
	public void Verify_Visited_Project_is_Displayed_On_Recently_Visited_Table() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(ISBN);

		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.verifyOnProjectView();
		test.projectView.AddProjectToFavorite();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedListView(ISBN1);
		
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.clickGridView();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisitedGridView(ISBN + ".epub");
	}

	// 3."A) Recently Visited> Projects> List view:
	// 3) Verified that user is able to mark/unmark the Projects as Favorite from
	// Recently visited table and corresponding message notification is displayed
	// for the same (currently user needs to refresh the page to see the changes). "
	// BS-2197
	@Test(priority = 4)
	public void Verify_User_Able_To_Mark_Project_Favorite_Or_Unfavorite() {
		test.HomePage.RemoveProjectFromFavoriteRecentlyVisited(ISBN1);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.AddProjectToFavoriteFromRecentlyVisited(ISBN1);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
	}

	// 4."A) Recently Visited> Projects> List view:
	// 5) Verified that tool tip is available for the ellipsis cases."
	// BS-2197
	@Test(priority = 5)
	public void Verify_Tool_Tip_For_Project_List_View() {
		test.HomePage.verifyToolTipDisplayedOnRecentlyVisitedTableListView();
	}

	// 5."A) Recently Visited> Projects> List view:
	// 6) Verified that user can navigate to Projects view page on clicking the
	// Hyperlinked row."
	// BS-2197
	@Test(priority = 6)
	public void Verify_User_Navigate_To_Project_view_Clicking_Row() {
		test.HomePage.OpenProjectDisplayedOnRecentlyVisited(ISBN1);
		test.projectView.verifyOnProjectView();
	}

	// 6."B) Recently Visited> Projects> Grid view:
	// 1) Verified that following information is displayed in Grid view for Projects
	// in Recently visited tab- Pass
	// a) Project Thumbnail
	// b) Grayed out checkbox
	// c) Favorite Star icon
	// d) Author
	// e) Title
	// f) Edition
	// g) ISBN"
	// BS-2197
	@Test(priority = 7)
	public void Verify_Proper_Information_On_Grid_View_Project() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.clickGridView();
		test.HomePage.VerifyProjectDetailGridViewRecentlyVisited();
	}

	// 7."B) Recently Visited> Projects> Grid view:
	// 2) Verified that the Project that is last visited by user gets added in the
	// Recently visited table and the latest one appear on the top."
	// BS-2197
	@Test(priority = 8)
	public void Verify_Project_Last_Visited_Gets_Added_In_Recently_Visited() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN1);
		test.projectView.verifyOnProjectView();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.clickGridView();
		test.HomePage.VerifyProjectDisplayedOnRecentlyVisitedGridView(ProjectTitle);
	}

	// 8."B) Recently Visited> Projects> Grid view:
	// 3) Verified that user is able to mark/unmark the Projects as Favorite from
	// Recently visited table and corresponding message notification is displayed
	// for the same (currently user needs to refresh the page to see the changes)."
	// BS-2197
	@Test(priority = 9)
	public void Verify_User_Able_To_Mark_Project_Favorite_Or_Unfavorite_GridView() {
		test.HomePage.RemoveProjectToFavoriteFromRecentlyVisitedGridView(ProjectTitle);
		test.HomePage.VerifyMessageDisplayedOnFavoriteRemoved();
		test.HomePage.AddProjectToFavoriteFromRecentlyVisitedGridView(ProjectTitle);
		test.HomePage.VerifyMessageDisplayedOnAddingFavorite();
	}

	// 9."B) Recently Visited> Projects> Grid view:
	// 5) Verified that tool tip is available for the ellipsis cases."
	// BS-2197
	@Test(priority = 10)
	public void Verify_Tool_Tip_On_GridView() {
		test.HomePage.verifyToolTipDisplayedOnRecentlyVisitedTableGridView();
	}

	// 10."B) Recently Visited> Projects> Grid view:
	// 6) Verified that user can navigate to Projects view page on clicking the
	// Project thumbnail."
	// BS-2197
	@Test(priority = 11)
	public void Verify_User_Navigate_Clicking_Thumbnail() {
		test.HomePage.OpenProjectORContentDisplayedOnRecentlyVisitedGridView(ProjectTitle);
		test.projectView.verifyOnProjectView();
	}

	// 11."C) Recently Visited> Contents> List view:
	// 1) Verified that following Column Headers are available in the Recently
	// visited table- Pass
	// a) Grayed out checkbox
	// b) File icon
	// c) Favorite Star icon - Blank for Content
	// d) Author - Blank for Content
	// e) Title
	// f) Short Title - Blank for Content
	// g) ISBN - Blank for Content
	// h) Content Type
	// i) Repository
	// j) Last Modified Date"
	// BS-2197
	@Test(priority = 12)
	public void Verify_Proper_Information_On_List_View_Content() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyCheckBoxGrayedOutOnRecently();
		test.HomePage.VerifyFileIconForContent(ISBN + ".epub");
		test.HomePage.VerifyStarIconNotDisplayedForAsset(ISBN + ".epub");
		test.HomePage.VerifyAuthorNameNotDisplayedForContent(ISBN + ".epub");
		test.HomePage.VerifyTitleDisplayedOnRecentlyVisited();
		test.HomePage.VerifyShortTitleNotDisplayedForContent(ISBN + ".epub");
		test.HomePage.VerifyISBNNotDisplayedForContent(ISBN + ".epub");
		test.HomePage.VerifyContentTypeDisplayedForContent(ISBN + ".epub");
		test.HomePage.VerifyLastModifiedDateDisplayedForContent(ISBN + ".epub");
	}

	// 12."D) Recently Visited> Contents> Grid view:
	// 2) Verified that the Content that is last visited by user gets added in the
	// Recently visited table and the latest one appear on the top. "
	// BS-2197
	@Test(priority = 13)
	public void Verify_Recently_Visited_Content_is_Displayed_GridView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.clickGridView();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisitedGridView(ISBN + ".epub");

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.clickGridView();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisitedGridView(ISBN + ".epub");
	}

	// 13."D) Recently Visited> Contents> List view:
	// 3) Verified that changes made in Content's metadata gets updated in the
	// Recently visited tab simultaneously. "
	// BS-2197
	@Test(priority = 14)
	public void Verify_Changes_Made_In_Content_Reflect_In_Recently_Visited() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ClickEditLink();
		test.ContentView.EditDescription("Automation Edited Description " + getDateString_MM_dd_yyyy_HH_mm());
		test.ContentView.ClickUpdateButtonOnEditContentView();
		String CurrentDate = getDateString_MM_dd_yyyy_HH_mm();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(ISBN + ".epub");
		test.HomePage.VerifyLastModifiedDateDisplayedForContent(ISBN + ".epub", CurrentDate);
	}

	// 14."D) Recently Visited> Contents> Grid view:
	// 5) Verified that user can navigate to Content view page on clicking the
	// Content's thumbnail. "
	// BS-2197
	@Test(priority = 15)
	public void Verify_User_Navigate_To_ContentView_From_Recently_Visited() {
		test.HomePage.clickGridView();
		test.HomePage.OpenProjectORContentDisplayedOnRecentlyVisitedGridView(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
	}

	// 15."E) General Cases:
	// 2) Verified that clicking on the Recently Visited tab on the Dashboard shows
	// a table with a total of 10 entries that includes Projects and Contents that I
	// have visited recently (most recent at the top). This could be a mix of items
	// including both Projects and Contents."
	// BS-2197
	@Test(priority = 16)
	public void Verify_Only_10_Items_Displayed_On_Recently_Visited() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.ClickListView();
		test.HomePage.VerifyOnly10EntriesDisplayedOnRecentlyVisited();
	}

	// 16."E) General Cases:
	// 3) Verified that the data under Recently visited tab is user specific i.e.
	// User1 can not see the recently visited data of User2."
	// BS-2197
	@Test(priority = 17)
	public void Verify_Recently_Visited_Tab_Is_User_Specific() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN1 + ".epub");
		test.Contentpage.opentheSearchContent(ISBN1 + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(ISBN1 + ".epub");
		test.HomePage.LogoutFromApplication();
		test.loginpage.enterEmailAddress(SecondUserEmail);
		test.loginpage.enterUserPassword(PropFileHandler.readPropertyFromDataFile("currentPassword"));
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentNotDisplayedOnRecentlyVisited(ISBN1 + ".epub");
	}

	// 17."C) Recently Visited> Contents> List view:
	// 2) Verified that the Content that is last visited by user gets added in the
	// Recently visited table and the latest one appear on the top. "
	// BS-2197
	@Test(priority = 18)
	public void Verify_Recently_Visited_Content_is_Displayed_ListView() {
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(ISBN + ".epub");

		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(ISBN + ".epub");
		test.Contentpage.opentheSearchContent(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.VerifyContentDisplayedOnRecentlyVisited(ISBN + ".epub");
	}

	// 18."C) Recently Visited> Contents> List view:
	// 5) Verified that user can navigate to Content view page on clicking the view
	// icon. "
	// BS-2197
	@Test(priority = 19)
	public void Verify_User_Navigate_To_ContentView() {
		test.HomePage.OpenContentDisplayedOnRecentlyVisited(ISBN + ".epub");
		test.ContentView.VerifyOnContentViewPage();
	}

	// 19."D) Recently Visited> Contents> Grid view:
	// 1) Verified that following information is displayed in Grid view for Content
	// in Recently visited tab
	// a) Content Thumbnail
	// b) Grayed out checkbox
	// c) Title
	// d) File Name
	// e) Content Type
	// f) Last Updated
	// BS-2197
	@Test(priority = 20)
	public void Verify_Content_Information_GridView() {
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.clickRecentlyVisited();
		test.HomePage.clickGridView();
		test.HomePage.VerifyContentDetailGridViewRecentlyVisited();
	}
	

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
