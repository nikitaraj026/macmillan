package com.qait.CMS.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithDateAndTimes;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;

public class Reg_Student_Visibility_Metadata_Extended extends Parent_Test {

	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, TestImageName;
	String TypeOfContentImageSource, AssetTitleImageCredited, AssetTitleNewImageCredited, TestISBN;
	String PublihDestinationCourseWare, AssetTitleImageSource, AssetTitleNewImageSource;
	String TypeOfContentImageCredited, StudentBagdeToolTip, InstructorBagdeToolTip, VisibleToStudentToolTip;
	String NotVisibleToStudentToolTip, SampleAutomationAsset, TestISBN2, TypeOfContentMarketingSampleChapter,
			MarketingSampleChapter, PublihDestinationInstructorStore;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		TestImageName = "AutoMation NGA_!@#$%ÀÁÂÃÄÅ.jpg";
		TypeOfContentImageSource = getData("TypesOfContent.Images>Image Source");
		TypeOfContentImageCredited = getData("TypesOfContent.Images>Image Credited");
		AssetTitleImageSource = getStringWithDateAndTimes("AutomationImageSource");
		AssetTitleNewImageSource = getStringWithDateAndTimes("AutomationImageSourceNew");
		AssetTitleImageCredited = getStringWithDateAndTimes("AutomationImageCredited");
		AssetTitleNewImageCredited = getStringWithDateAndTimes("AutomationImageCreditedNew");
		TestISBN = getData("ProjectISBNNO");
		TestISBN2 = getData("ProjectISBNNo1");
		PublihDestinationCourseWare = getData("PublishDestination.CourseWare");
		PublihDestinationInstructorStore = getData("PublishDestination.Instructor Store");
		StudentBagdeToolTip = getData("SupplementaryContent.Student");
		InstructorBagdeToolTip = getData("SupplementaryContent.Instructor");
		VisibleToStudentToolTip = getData("EyeIconToolTip.Visible").trim();
		NotVisibleToStudentToolTip = getData("EyeIconToolTip.Not Visible").trim();
		TypeOfContentMarketingSampleChapter = getData("TypesOfContent.Marketing Content>Sample Chapter");
		MarketingSampleChapter = getData("MarketingSampleChapter");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	// login Into Application
	@Test(priority = 1)
	public void Verify_User_Is_Able_To_Login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
	}

	// Step1: Upload An Asset other than Instructor or Student
	@Test(priority = 2)
	public void Upload_An_Sample_Images() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentImageSource);
		test.HomePage.EnterTextIntoTitleField(AssetTitleImageSource);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentImageSource);
		test.HomePage.EnterTextIntoTitleField(AssetTitleNewImageSource);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentImageCredited);
		test.HomePage.EnterTextIntoTitleField(AssetTitleImageCredited);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();

		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentImageCredited);
		test.HomePage.EnterTextIntoTitleField(AssetTitleNewImageCredited);
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// 1."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:Verify that user can do bulk edit by selecting a Parent and
	// hence, changes are applied to all the childs"
	// BS-3042
	@Test(priority = 3, dependsOnMethods = "Upload_An_Sample_Images")
	public void Verify_Bulk_Edit_Selecting_Parent_And_Changes_Applied_To_All_The_Childs() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.ExpandContentTypeOnUpdateContentMetadata("CMS", TypeOfContentImageSource);
		test.projectView.ClickContentTypeOnUpdateContentMetadata("CMS", TypeOfContentImageSource);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleImageSource);
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleNewImageSource);
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(AssetTitleImageSource);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(AssetTitleNewImageSource);
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(AssetTitleImageSource);
		test.projectView.VerifyAssetIsNotVisibleToStudent(AssetTitleNewImageSource);
	}

	// 2."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:Verify that user can do bulk edit by selecting multiple Parents
	// and hence,changes are applied to all the childs"
	// BS-3042
	@Test(priority = 4)
	public void Verify_Bulk_Edit_Selecting_Multiple_Parent_And_Changes_Applied_To_All_The_Childs() {
		test.projectView.ExpandContentTypeOnUpdateContentMetadata("CMS", TypeOfContentImageCredited);
		test.projectView.ClickContentTypeOnUpdateContentMetadata("CMS", TypeOfContentImageCredited);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleNewImageSource);
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleImageSource);
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleNewImageCredited);
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleImageCredited);
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(AssetTitleNewImageCredited);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(AssetTitleImageCredited);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(AssetTitleNewImageSource);
		test.projectView.Verify_I_Badge_Is_Dispalyed_On_Assert(AssetTitleImageSource);
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(AssetTitleNewImageCredited);
		test.projectView.VerifyAssetIsNotVisibleToStudent(AssetTitleImageCredited);
		test.projectView.VerifyAssetIsNotVisibleToStudent(AssetTitleNewImageSource);
		test.projectView.VerifyAssetIsNotVisibleToStudent(AssetTitleImageSource);
	}

	// 4."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:Verify that user can do bulk edit by selecting combination of
	// Parents and childs, and hence, changes are applied to all the selected
	// childs"
	// BS-3042
	@Test(priority = 5)
	public void Verify_Bulk_Edit_Selecting_Combination_Of_Parent_And_Childs() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.ExpandContentTypeOnUpdateContentMetadata("CMS", TypeOfContentImageSource);
		test.projectView.ClickContentTypeOnUpdateContentMetadata("CMS", TypeOfContentImageSource);
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", TypeOfContentImageCredited,
				AssetTitleNewImageCredited);
		test.projectView.ClickClearAccessLevelMetadata();
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert(AssetTitleImageSource);
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert(AssetTitleNewImageSource);
		test.projectView.Verify_I_Badge_Is_Not_Dispalyed_On_Assert(AssetTitleNewImageCredited);
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyEyeIconNotDisplayedForAsset(AssetTitleImageSource);
		test.projectView.VerifyEyeIconNotDisplayedForAsset(AssetTitleNewImageSource);
		test.projectView.VerifyEyeIconNotDisplayedForAsset(AssetTitleNewImageCredited);
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(AssetTitleImageSource);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(AssetTitleNewImageSource);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(AssetTitleNewImageCredited);
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleImageSource);
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleNewImageSource);
		test.projectView.VerifyAssetIsVisibleToStudent(AssetTitleNewImageCredited);
	}

	// 5."When Publish Destination is selected as Courseware> Update Content
	// metadata tab:
	// Verify that following tool tips are available:
	// 'i' badge: Achieve Instructor Resource
	// 's' badge: Achieve Student Resource
	// eye icon: Visible to Students in Achieve
	// cross eye icon: Not Visible to Students in Achieve"
	// BS-3042
	@Test(priority = 5)
	public void Verify_Prpoer_Tool_Tip_For_badges_And_Eye_Icon() {
		test.projectView.VerifyToolTipDisplayedOnBadge(AssetTitleImageSource, StudentBagdeToolTip);
		test.projectView.CheckToolTipDisplayedForEyeIconPublishWindow(AssetTitleImageSource, VisibleToStudentToolTip);
		test.projectView.ClickInstructorOnlyMetadataButton();
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyToolTipDisplayedOnBadge(AssetTitleImageSource, InstructorBagdeToolTip);
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", TypeOfContentImageCredited,
				AssetTitleNewImageCredited);
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.CheckToolTipDisplayedForEyeIconPublishWindow(AssetTitleNewImageCredited,
				NotVisibleToStudentToolTip);
	}

	// 6."Verify that following message is displayed if 'Visible to Student' is
	// clicked after selecting the asset:XX asset/s tagged as Visible to Students in
	// Achieve"
	// BS-3042
	@Test(priority = 6)
	public void Verify_Message_Displayed_On_Adding_Visible_To_Student() {
		test.projectView.ClickVisibleToStudentButton();
		test.projectView.VerifyMessageOnAddingVisibleToStudent();
	}

	// 7."Verify that following message is displayed if 'Not Visiible to Student' is
	// clicked after selecting the asset:XX asset/s tagged as Not Visible to
	// Students in Achieve"
	// BS-3042
	@Test(priority = 7)
	public void Verify_Message_Displayed_On_Adding_Not_Visible_To_Student() {
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyMessageOnAddingNotVisibleToStudent();
	}

	// 8."Verify that following message is displayed if 'Reset to Original System
	// status' is clicked after selecting the asset:XX asset/s set to default
	// visibility"
	// BS-3042
	@Test(priority = 8)
	public void Verify_Message_Displayed_On_Clicking_Reset_To_Original_System_Status() {
		test.projectView.ClickResetToOriginalSystemStatusButton();
		test.projectView.VerifyMessageOnResetToOriginalSystemStatus();
	}

	// 9.Verify that user is able to initiate the Publish operation successfully for
	// the tagged assets
	@Test(priority = 9)
	public void Verify_User_Able_To_Publish_Tagged_Assets() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypeOfContentMarketingSampleChapter, MarketingSampleChapter);
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.ClickManualPublish();
		test.projectView.SelectAssetDisplayedOnStep2ofPublishWindow("CMS", TypeOfContentMarketingSampleChapter,
				MarketingSampleChapter, true);
		test.projectView.Select_Assert_Displayed_In_Step3(MarketingSampleChapter);
		test.projectView.ClickApproveButtonOnPublishPopUp();
		test.projectView.VerifyPublishButtonOnPublishPopUpEnabled();
		test.projectView.clickPublishOnPuplishPopUp();
		test.projectView.VerifyPublishWasSuccessful();
		test.projectView.ClickCloseButton();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationInstructorStore);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS",
				TypeOfContentMarketingSampleChapter, MarketingSampleChapter);
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.ClickNotVisibleToStudentButton();
	}

	// Step::Delete All Uploaded TestData
	@Test(priority = 10)
	public void DeleteTheUploadedAssets() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(AssetTitleImageSource);
		test.Contentpage.SelectContentOnContentTab(AssetTitleImageSource, TypeOfContentImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

		test.Contentpage.SearchForAnItem(AssetTitleNewImageSource);
		test.Contentpage.SelectContentOnContentTab(AssetTitleNewImageSource, TypeOfContentImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

		test.Contentpage.SearchForAnItem(AssetTitleImageCredited);
		test.Contentpage.SelectContentOnContentTab(AssetTitleImageCredited, TypeOfContentImageCredited);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();

		test.Contentpage.SearchForAnItem(AssetTitleNewImageCredited);
		test.Contentpage.SelectContentOnContentTab(AssetTitleNewImageCredited, TypeOfContentImageCredited);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}

	// Upload a Smaple Asset
	@Test(priority = 11)
	public void Upload_And_Associate_Asset_To_Projects() {
		SampleAutomationAsset = getStringWithDateAndTimes("AutomationSampleAsset");
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectFileUsingBrowseButton(TestImageName);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypeOfContentImageSource);
		test.HomePage.EnterTextIntoTitleField(SampleAutomationAsset); //### Change to AssetTitleImageSource on Failuers
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.ClickAddRemoveProject();
		test.HomePage.VerifyAddtoProjectpopUp();
		test.HomePage.SearchProjectInAddRemovePopUp(TestISBN2);
		test.HomePage.VerifyProjectDisplayedOnAvailablePane(TestISBN2);
		test.HomePage.MoveProjectFromAvailablePaneToSelectedPane(TestISBN2);
		test.HomePage.ClickSaveButtonOnAddToProject();
		test.HomePage.clickUploadButton();
		test.ContentView.VerifyContentUploadedMessage();
	}

	// 10.Verify that tags of access level metadata and visibility are saved in
	// Project level only
	@Test(priority = 12)
	public void Verify_Tags_Of_Access_Level_Metadata_Visibility_Are_Saved_In_Project_Level_Only() {
		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", TypeOfContentImageSource,
				SampleAutomationAsset);
		test.projectView.ClickStudentOnlyMetadataButton();
		test.projectView.ClickNotVisibleToStudentButton();
		test.projectView.VerifyAssetIsNotVisibleToStudent(SampleAutomationAsset);
		test.projectView.Verify_S_Badge_Is_Dispalyed_On_Assert(SampleAutomationAsset);
		test.projectView.ClickCloseButton();

		test.refreshPage();
		test.projectView.waitForLoaderToDisappear();
		test.HomePage.clickProjectTab();
		test.ProjectPage.VerifyOnProjectPage();
		test.ProjectPage.SearchAndOpenProjectOfISBN(TestISBN2);
		test.projectView.verifyOnProjectView();
		test.projectView.click_Enhanced_ePub_in_QA();
		test.projectView.clickpublishLink();
		test.projectView.VerifyPublishPopUpDispplayed();
		test.projectView.selectDestinationOfPublish(PublihDestinationCourseWare);
		test.projectView.ClickUpdateContentMetaDataTab();
		test.projectView.VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata("CMS", TypeOfContentImageSource,
				SampleAutomationAsset);
		test.projectView.Verify_S_Badge_Is_Not_Dispalyed_On_Assert(SampleAutomationAsset);
		test.projectView.VerifyEyeIconNotDisplayedForAsset(SampleAutomationAsset);
	}

	// Step::Delete All Uploaded TestData
	@Test(priority = 13)
	public void DeleteTheUploadedAssets1() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickContentTab();
		test.Contentpage.VerifyOnContentTab();
		test.Contentpage.SearchForAnItem(SampleAutomationAsset);
		test.Contentpage.SelectContentOnContentTab(SampleAutomationAsset,TypeOfContentImageSource);
		test.Contentpage.clickDeleteContentOnContentTab();
		test.Contentpage.EnterDeleteToDeleteContent();
		test.Contentpage.ClickConformDelete();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
