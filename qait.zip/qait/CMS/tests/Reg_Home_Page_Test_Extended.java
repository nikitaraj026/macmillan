package com.qait.CMS.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CMSTestInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Reg_Home_Page_Test_Extended extends Parent_Test {
	CMSTestInitiator test;
	String baseURL, AdminEmail, AdminPassword, homePageLink, loginPageLink, DAMLink, LookForAsset, LookForProject,
			LookForBoth;
	String Elvis, ProjectISBNNO, NonAdminEmail, NonAdminPassword, ISBN, Noncmsassert, PassResetEmail,
			CurrentResetPassword;
	String TypesOfContentEnhancedEpub, SelectPageThisPage;

	private void initVars() {
		baseURL = getData("baseUrl");
		AdminEmail = getData("Admin.email");
		AdminPassword = getData("Admin.password");
		homePageLink = getData("Link.HomePageLink");
		loginPageLink = getData("Link.loginPageLink");
		Elvis = getData("NonCMSAssert.Elvis");
		NonAdminEmail = getData("NonAdmin.email");
		NonAdminPassword = getData("NonAdmin.password");
		ISBN = getData("ProjectISBNNO");
		ProjectISBNNO = getData("ProjectISBNNo1");
		Noncmsassert = getData("DamContent");
		PassResetEmail = getData("PasswordResetAccount.email");
		CurrentResetPassword = PropFileHandler.readPropertyFromDataFile("currentPassword");
		LookForAsset = getData("LookFor.Assets");
		LookForProject = getData("LookFor.project");
		LookForBoth = getData("LookFor.both");
		TypesOfContentEnhancedEpub = getData("TypesOfContent.Enhanced ePub > Full Package");
		SelectPageThisPage = getData("PageSelection.This Page");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		test = new CMSTestInitiator();
		initVars();
		test.launchApplication(baseURL);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		test.stepStartMessage(method.getName());
	}

	public void logoutFromApplication() {

		test.HomePage.clickUserName();
		test.HomePage.clickLogOut();
	}

	// Verify that a user gets landed on 'Dashboard' tab after a successful login
	// into the application
	@Test(priority = 1)
	public void Verify_That_User_Landed_On_Dashboard_After_login() {
		test.loginpage.verifyEmailTextBoxDislayed();
		test.loginpage.verifyPasswordTextBoxDisplayed();
		test.loginpage.verifyLogInButtonDisplayed();
		test.loginpage.enterEmailAddress(AdminEmail);
		test.loginpage.enterUserPassword(AdminPassword);
		test.loginpage.clickLogInButton();
		test.HomePage.verifyOnhomePage(homePageLink);
		test.HomePage.DashBordIsDisplayed();
	}

	// 71.Verify that user is not able to select the projects using Select All Radio
	// Button if user do advance search for the project.
	@Test(priority = 2)
	public void Verify_User_Is_Not_Able_To_Select_The_Projects_Using_Select_All_Radio_Button_For_Advance_Search() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForProject);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyProjectsAreNotSelected();
	}

	// 72.Verify that only content are selected when user perform the search
	// operation by option assets and project by clicking on the select all button
	@Test(priority = 3)
	public void Verify_Only_Content_Are_Selected_On_Advance_Search_By_Option_Assets_And_Project() {
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.EnterTextIntoSearchBox(ISBN);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.VerifyProjectsAreNotSelected();
	}

	// 73.Verify that user cannot select Projects displaying after making an
	// Advanced search using the checkbox
	@Test(priority = 4)
	public void Verify_User_Cannot_Select_Project_Displayed_After_AdvanceSearch() {
		test.SearchPage.SelectProjectOnSearchPage(ISBN);
		test.SearchPage.VerifyProjectISNotSelected(ISBN);

	}

	// 74.Verify that User can use the Select All checkbox after making an Advanced
	// search
	@Test(priority = 5)
	public void Verify_User_Can_Use_The_Select_All_checkbox_After_Making_Advanced_Search() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyContentsAreSelected();
	}

	// 75.Verify that selected content is not unselected while navigating to other
	// search result page.
	@Test(priority = 6)
	public void Verify_Selected_Content_Is_Not_Unselected_While_Navigating_To_Other_Result_Page() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.VerifyContentsAreSelected();
	}

	// 76.Verify that on search result page Select all checkbox is unchecked while
	// navigating to other page
	@Test(priority = 7)
	public void Verify_Select_All_Checkbox_Is_Unchecked_While_Navigating_To_Other_Page() {
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.VerifyPageNotSelectedInDropDown(SelectPageThisPage);
	}

	// 78.Verify that Select All checkbox does not checks all the Assets of the
	// Searched query
	@Test(priority = 8)
	public void Verify_Select_All_Checkbox_Does_Not_Checks_All_The_Assets_Of_Searched_Query() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.VerifyContentsAreNotSelected();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.NavigateToPage("3");
		test.SearchPage.VerifyContentsAreNotSelected();
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.VerifyContentsAreSelected();
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.VerifyContentsAreSelected();
	}

	// 79.Verify that rest checked items are not getting unchecked by
	// checking-unchecking the searched assets by taking 'Assets' in 'Look for'
	// field
	// BS-1682
	@Test(priority = 9)
	public void Verify_Checked_Items_Are_Not_Getting_Unchecked_By_Checking_Unchecking_The_Searched_Assets_For_Assets() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.SearchPage.NavigateToPage("1");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingOneItem();
	}

	// 80.Verify that rest checked items are not getting unchecked by
	// checking-unchecking the searched assets by taking 'Assets & Projects' in
	// 'Look for' field
	// BS-1682
	@Test(priority = 10)
	public void Verify_Checked_Items_Are_Not_Getting_Unchecked_By_Checking_Unchecking_The_Searched_Assets_For_Assets_And_Projects() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForBoth);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingOneItem();
	}

	// 81.Verify by checking-unchecking multiple assets and observed that no other
	// asset is getting unchecked
	// BS-1682
	@Test(priority = 11)
	public void Verify_Checked_Items_Are_Not_Getting_Unchecked_By_Checking_Unchecking_Multiple_Assert() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingMultipleItem();
	}

	// 82.Verify the same across multiple pages as well
	// BS-1682
	@Test(priority = 12)
	public void Verify_Checked_Items_Are_Not_Getting_Unchecked_By_Checking_Unchecking_Assert_Across_Multiple_Pages() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.NavigateToPage("2");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingOneItem(); // for Single assert
		test.refreshPage();

		test.HomePage.waitForLoaderToDisappear();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingMultipleItem(); // for multiple assert

		test.SearchPage.NavigateToPage("3");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingOneItem(); // for Single assert
		test.refreshPage();

		test.HomePage.waitForLoaderToDisappear();
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingMultipleItem(); // for multiple assert

	}

	// 83.Verify the same by changing the result number as well
	// BS-1682
	@Test(priority = 13)
	public void Verify_Checked_Items_Are_Not_Getting_Unchecked_By_Checking_Unchecking_And_Changing_The_Result_Number() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.clickAdvanceSearch();
		test.SearchPage.VerifyOnAdvanceSearchPopUp();
		test.SearchPage.ClickResetButton();
		test.SearchPage.SelectLookFor(LookForAsset);
		test.SearchPage.ClickSearchButton();
		test.SearchPage.SelectNumberFromResultDropDown("50");
		test.SearchPage.ClickPageSelectionDropDown();
		test.SearchPage.PageSelection(SelectPageThisPage);
		test.SearchPage.VerifyItemsNotGettingUncheckedByCheckingOneItem();
	}

	// "Dashboard> Upload Content: Verify that by default Select File and Content
	// type are the mandatory fields and if any of them are empty, then the Upload
	// button will remain disabled"
	// BS-2663
	@Test(priority = 14)
	public void Verify_If_either_of_Select_File_And_Content_type_Is_Empty_Upload_Button_Is_Disabled() {
		test.refreshPage();
		test.HomePage.waitForLoaderToDisappear();
		test.HomePage.ClickDashBord();
		test.HomePage.DashBordIsDisplayed();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectImageFileUsingBrowseButton(ISBN);
		test.HomePage.VerifyUploadButtonIsDisabled();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp("Select Content Type");
		test.HomePage.VerifyUploadButtonIsDisabled();
		test.HomePage.clickXButtonUploadContent();
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.VerifyUploadButtonIsDisabled();
		test.HomePage.clickXButtonUploadContent();
	}

	// "Dashboard> Upload Content:Verify that as soon as user fills in both the
	// mandatory fields, the Upload button gets active and user can upload the
	// content successfully."
	// BS-2663
	@Test(priority = 15)
	public void Verify_When_Both_The_Mandatory_Fields_Are_Filled_User_Successfully_Upload() {
		test.HomePage.ClickUploadContent();
		test.HomePage.VerifyUploadContentPopup();
		test.HomePage.SelectImageFileUsingBrowseButton(ISBN);
		test.HomePage.SelectTypeOfContentInUploadContentPopUp(TypesOfContentEnhancedEpub);
		test.HomePage.VerifyUploadButtonIsEnabled();
		test.HomePage.clickUploadButton();
		test.HomePage.waitForLoaderToDisappear();
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.DeleteContentFromCMS();
	}

	// "Project View> Upload Content:Verify that by default Select File and Content
	// type are the mandatory fields and if any of them are empty, then the Upload
	// button will remain disabled"
	// BS-2663
	@Test(priority = 16)
	public void Verify_If_either_of_Select_File_And_Content_type_Is_Empty_Upload_Button_Is_Disabled_ProjectView() {
		test.HomePage.clickProjectTab();
		test.ProjectPage.SearchAndOpenProjectOfISBN(ISBN);
		test.projectView.verifyOnProjectView();
		test.projectView.clickUploadContent();
		test.projectView.VerifyUploadContentPopup();
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentEnhancedEpub);
		test.projectView.VerifyUploadButtonIsDisabled();
		test.projectView.SelectImageFileUsingBrowseButton(ISBN);
		test.projectView.VerifyUploadButtonIsEnabled();
		test.projectView.SelectContentTypeInUploadContentPopup("Select Content Type");
		test.projectView.VerifyUploadButtonIsDisabled();
	}

	// "Project View> Upload Content: Verify that as soon as user fills in both the
	// mandatory fields, the Upload button gets active and user can upload the
	// content successfully."
	// BS-2663
	@Test(priority = 17)
	public void Verify_When_Both_The_Mandatory_Fields_Are_Filled_User_Successfully_Upload_ProjectView() {
		test.projectView.SelectContentTypeInUploadContentPopup(TypesOfContentEnhancedEpub);
		test.projectView.VerifyUploadButtonIsEnabled();
		test.projectView.EnterTextIntoTitleField("AutomationTest");
		test.projectView.ClickUploadOnUploadContentPopUpAndVerifyMsg();
	}

	// Verify that the uploaded content is displayed associated with the project
	// after the upload
	// BS-2663
	@Test(priority = 18)
	public void Verify_Uploaded_Content_Is_Displayed_Associated_With_The_Project() {
		test.ContentView.VerifyOnContentViewPage();
		test.ContentView.ConfirmContentIsAssociateToProject(ISBN);
		test.ContentView.DeleteContentFromCMS();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());
	}

	@AfterClass(alwaysRun = true)
	public void tearDown() {
		test.closeBrowserSession();
	}
}
