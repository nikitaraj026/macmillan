package com.qait.CMS.keywords;

import static com.qait.automation.utils.YamlReader.getData;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import static org.testng.Assert.assertTrue;
import java.awt.HeadlessException;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.UnsupportedFlavorException;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.PropFileHandler;

public class ContentViewAction extends GetPage {

	public ContentViewAction(WebDriver driver) {
		super(driver, "ContentView");
	}

	public void VerifySystemMetadataHeadingAreDisplayed() {

		isElementDisplayed("SystemMetaData", "Content ID:");
		logMessage("Content ID Is displayed");

		isElementDisplayed("SystemMetaData", "Content URI:");
		logMessage("Content URI Is displayed");

		isElementDisplayed("SystemMetaData", "Date Created:");
		logMessage("Date Created Is displayed");

		isElementDisplayed("SystemMetaData", "Created By:");
		logMessage("Created By: Is displayed");

		isElementDisplayed("SystemMetaData", "Date Modified:");
		logMessage("Date Modified: Is displayed");

		isElementDisplayed("SystemMetaData", "Modified By:");
		logMessage("Modified By: Is displayed");

		isElementDisplayed("SystemMetaData", "File Format:");
		logMessage("File Format: Is displayed");

		isElementDisplayed("SystemMetaData", "Filename:");
		logMessage("Filename: Is displayed");

		isElementDisplayed("SystemMetaData", "File Path:");
		logMessage("File Path: Is displayed");

		isElementDisplayed("SystemMetaData", "File Size:");
		logMessage("File Size: Is displayed");

	}

	public void VerifySystemMetadataAreDisplayed() {
		isElementDisplayed("SystemMetaData", "Content ID:");
		logMessage("Content ID::" + element("SystemMetaData", "Content ID:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Content URI:");
		logMessage("Content URI Is displayed");
		logMessage("Content URI::" + element("SystemMetaData", "Content URI:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Date Created:");
		logMessage("Date Created Is displayed");
		logMessage("Date Created::" + element("SystemMetaData", "Date Created:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Created By:");
		logMessage("Created By: Is displayed");
		logMessage("Created By::" + element("SystemMetaData", "Created By:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Date Modified:");
		logMessage("Date Modified: Is displayed");
		logMessage("Date Modified::" + element("SystemMetaData", "Date Modified:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Modified By:");
		logMessage("Modified By: Is displayed");
		logMessage("Modified By::" + element("SystemMetaData", "Modified By:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "File Format:");
		logMessage("File Format: Is displayed");
		logMessage("File Format::" + element("SystemMetaData", "File Format:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Filename:");
		logMessage("Filename: Is displayed");
		logMessage("Filename::" + element("SystemMetaData", "Filename:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "File Path:");
		logMessage("File Path: Is displayed");
		logMessage("File Path::" + element("SystemMetaData", "File Path:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "File Size:");
		logMessage("File Size: Is displayed");
		logMessage("File Size:" + element("SystemMetaData", "File Size:").getAttribute("innerText"));

	}

	public void VerifyUserEmailCreatedBy(String Email) {
		isElementDisplayed("SystemMetaData", "Created By:");
		String EmailDisplayed = element("SystemMetaData", "Created By:").getText().trim();
		logMessage(" Expected Email::" + Email);
		logMessage("Displayed Email::" + EmailDisplayed);
		Assert.assertEquals(Email, EmailDisplayed,
				"[Assertio Failed]::Incorrect User Name Dislpayed::" + EmailDisplayed);
	}

	public void VerifyUserEmailModifiedBy(String Email) {
		isElementDisplayed("SystemMetaData", "Modified By:");
		String EmailDisplayed = element("SystemMetaData", "Modified By:").getText().trim();
		logMessage(" Expected Email::" + Email);
		logMessage("Displayed Email::" + EmailDisplayed);
		Assert.assertEquals(Email, EmailDisplayed,
				"[Assertion Failed]::Incorrect User Name Dislpayed::" + EmailDisplayed);
	}

	public void VerifySubTabAreDispalyed() {
		isElementDisplayed("SubTab", "Content Details");
		isElementDisplayed("SubTab", "Content Details");
		logMessage("Content Details Is displayed");

		isElementDisplayed("SubTab", "Learning Objectives");
		logMessage("Relationships Is displayed");

		isElementDisplayed("SubTab", "Version Details");
		logMessage("Version Details Is displayed");

		isElementDisplayed("SubTab", "Publish Details");
		logMessage("Publish Details Is displayed");
	}

	public void VerifyPublishWasOnCorrectDestination(String publihDestinationCoreSource) {

		wait.hardWait(3);
		ClickPublishDetail();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("publishDetailLabel");
		String platform = element("DestPublish").getAttribute("innerText");
		logMessage("Published Platfrom:" + platform);
		logMessage("expected platform:" + publihDestinationCoreSource);
		if (platform.equalsIgnoreCase(publihDestinationCoreSource)) {
			Assert.assertTrue(true);
			logMessage("[Assertion Passed]: Project Was Publish On Corrent Platform");
		}

		else {
			Assert.assertTrue(false, "[Assertion Failed]: Project Was not Publish On Corrent Platform");
		}
	}

	public void VerifyPublishedProjectPopUpDisplayed() {
		wait.hardWait(1);
		isElementDisplayed("PublishedProjectLabel");
		logMessage("Published Project ISBN(s) Pop Up is Displayed..");
	}

	public void ClickPublishDestinationOnPublishDetail() {
		isElementDisplayed("PublishDestination");
		click(element("PublishDestination"));
		logMessage("Publish Destination Clicked..");
	}

	public void VerifyPublishWasOnCorrectDestinationAndISBN(String publihDestinationCoreSource, String ISBN) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("publishDetailLabel");
		String platform = element("DestPublish").getAttribute("innerText").trim();
		logMessage("Published Platfrom:" + platform);
		logMessage("expected platform:" + publihDestinationCoreSource);
		if (platform.equalsIgnoreCase(publihDestinationCoreSource)) {
			logMessage("[Assertion Passed]: Project Was Publish On Corrent Platform");
		}

		else {
			Assert.assertTrue(false, "[Assertion Failed]: Project Was not Publish On Corrent Platform");
		}

		isElementDisplayed("PublishDestination");
		click(element("PublishDestination"));
		logMessage("Publish Destination Clicked..");
		VerifyPublishedProjectPopUpDisplayed();
		isElementDisplayed("PublishedISBN", ISBN);
		logMessage(ISBN + " is Displayed on Published Project ISBN(s)...");
	}

	public void VerifyISBNDisplayedInPublishProjectPopUpFavourableTime(String ExpectedISBN) {

		try {
			wait.resetImplicitTimeout(1);
			isElementDisplayed("PublishedISBN", ExpectedISBN);
			logMessage(ExpectedISBN + " is Displayed on Published Project ISBN(s)...");
			wait.resetImplicitTimeout(wait.timeout);
		}

		catch (java.lang.AssertionError exc) {
			Assert.assertTrue(false, "[Assertion Failed]:: " + ExpectedISBN + " Is Not Displayed..");
			wait.resetImplicitTimeout(wait.timeout);
		}
	}

	public void VerifyFavoriteProjectCountIsNotZero() {
		isElementDisplayed("FavProjectCount");
		String text = element("FavProjectCount").getText();
		int CountDisplayed = Integer.parseInt(text.substring(text.indexOf('(') + 1, text.lastIndexOf(')')));
		logMessage("Project Count Displayed::" + CountDisplayed);
		if (CountDisplayed <= 0) {
			Assert.assertTrue(false, "[Assertion Failed]::Project count are Reset to Zero");
		}
	}

	public void AddAndRemoveEmailOnAContent(String Email) {
		isElementDisplayed("AddEmail");
		fillText("AddEmail", Email);
		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add button Clicked : Email add to The Content");
		wait.hardWait(3);
		isElementDisplayed("deleteButton", Email);
		clickUsingJS(element("deleteButton", Email));
		logMessage("Email Removed From the Content");

	}

	public void ClickOnVersionDetail() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SubTab", "Version Details");
		clickUsingJS(element("SubTab", "Version Details"));
		logMessage("Version Details is clicked..");

	}

	public void CheckVersionDetailFunctionality() {
		String Status;
		wait.hardWait(2);
		clickUsingJS(element("VersionOperation", "Upload a new version"));
		wait.hardWait(3);
		isElementDisplayed("closeUpload");
		clickUsingJS(element("closeUpload"));
		logMessage("Upload New Version Functionality is working");

		logMessage("Selecting the version of the Content");
		wait.hardWait(2);
		isElementDisplayed("SelectVersion");
		click(element("SelectVersion"));
		logMessage("Version Selected...");
		wait.hardWait(2);
		isElementDisplayed("VersionOperation", "Download");
		clickUsingJS(element("VersionOperation", "Download"));
		logMessage("Download Functionality is working");
		isElementDisplayed("VersionOperation", "Approve");
		clickUsingJS(element("VersionOperation", "Approve"));
		wait.hardWait(2);
		isElementDisplayed("GetApproveStatus");
		Status = element("GetApproveStatus").getAttribute("innerText");
		if (Status.compareTo("Approved") == 0) {
			logMessage("[Assertion Passed]:User is able to Approve the content");
		} else {
			logMessage("[Assertion Failed]:User is  not able to Approve the content");
			Assert.assertFalse(true);
		}

		isElementDisplayed("VersionOperation", "Unapprove");
		clickUsingJS(element("VersionOperation", "Unapprove"));
		wait.hardWait(2);
		isElementDisplayed("GetApproveStatus");
		Status = element("GetApproveStatus").getAttribute("innerText");
		logMessage(Status);
		if (Status.compareTo("Not Approved") == 0) {
			logMessage("[Assertion Passed]:User is able to Unapprove the content");
		} else {
			logMessage("[Assertion Failed]:User is  not able to Unapprove the content");
			Assert.assertFalse(true);
		}
	}

	public void ClickUploadNewVersion() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("VersionOperation", "Upload a new version");
		clickUsingJS(element("VersionOperation", "Upload a new version"));
		logMessage("'Upload a new version' Clicked");
	}

	public void Verify_Upload_Functionality_On_Version_Detail() {
		wait.hardWait(3);
		areElementsDisplayed("VersionOperation", "Upload a new version");
		clickUsingJS(element("VersionOperation", "Upload a new version"));
		logMessage("'Upload a new version' Clicked");
		wait.hardWait(3);
		isElementDisplayed("closeUpload");
		clickUsingJS(element("closeUpload"));
		logMessage("Upload New Version Functionality is working");
	}

	public void VerifyContentUploadedMessage() {
		isElementDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyTopLinksAreAvailabe() {
		String WorkFlowStatus;
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("GetWorkFlowStatus");
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		logMessage(WorkFlowStatus);

		if (WorkFlowStatus.trim().compareTo("Structural Validation Complete") == 0) {
			isElementDisplayed("toplinkForPublish");
			isElementDisplayed("toplinkForPublish");
			wait.hardWait(2);
			logMessage("Publish Is displayed");
		} else {
			if (verifyElementNotDisplayed("toplinkForPublish")) {
				logMessage("'Structural Validation Complete' is not displayed so Publish link will not be displayed ");
			} else {

				logMessage("'Structural Validation Complete' is not displayed But Publish link is displayed ");
				Assert.assertFalse(true);
			}
		}

		isElementDisplayed("toplinks", "Download Content");
		wait.waitForElementToBeClickable(element("toplinks", "Download Content "));
		logMessage("Download Content Is displayed");

		isElementDisplayed("toplinks", "Edit");
		waitForElementToBeClickable(element("toplinks", "Edit"));
		logMessage("Edit Is displayed");

		isElementDisplayed("toplinks", "Delete");
		waitForElementToBeClickable(element("toplinks", "Delete"));
		logMessage("Delete Is displayed");

		clickTopLinkMore();

		isElementDisplayed("FunctionsMore", "View Rights Details");
		waitForElementToBeClickable(element("FunctionsMore", "View Rights Details"));
		logMessage("View Rights details Is displayed");

		isElementDisplayed("FunctionsMore", "View Usage Details");
		waitForElementToBeClickable(element("FunctionsMore", "View Usage Details"));
		logMessage("View Usage details Is displayed");

		isElementDisplayed("FunctionsMore", "View ePub Files");
		waitForElementToBeClickable(element("FunctionsMore", "View ePub Files"));
		logMessage("View ePub Files Is displayed");

		if ((WorkFlowStatus.trim().compareTo("Structural Validation Complete") == 0)) {
			isElementDisplayed("FunctionsMore", "Push to Authoring Tool");
			logMessage("Push to Authoring tool  Is displayed");
		} else {
			if (element("FunctionsMore", "Push to Authoring Tool").isDisplayed()) {
				Assert.assertFalse(true,
						"'Structural Validation Complete' is not displayed but 'Push to Authoring tool'  link is displayed ");
			} else {
				logMessage(
						"'Structural Validation Complete' is not displayed so 'Push to Authoring tool'  link will not be displayed ");
			}
		}
	}

	public void VerifyOnlyWorkFlowLabelIsDisplayed() {

		areElementsDisplayed("GetWorkFlowStatus");
		clickUsingJS(element("GetWorkFlowStatus"));
		logMessage("WorkFlow Status Clicked...");
		Assert.assertTrue(verifyElementNotDisplayed("Revalidate"),
				"[Assertion Failed]::Revalidate link is Displayed..");
		logMessage("'Revalidate link Not Displayed..'");
	}

	public void clickTopLinkMore() {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinkMore");
		clickUsingJS(element("toplinkMore"));
		logMessage("'More Link' is Clicked");

	}

	public void ClickViewRightsDetails() {
		isElementDisplayed("FunctionsMore", "View Rights Details");
		scroll(element("FunctionsMore", "View Rights Details"));
		wait.hardWait(1);
		clickUsingJS(element("FunctionsMore", "View Rights Details"));
		logMessage("'RightsDetails' is Clicked");

	}

	public void verifyOperationUnderMoreLinkDisabled(String Operation) {
		isElementDisplayed("FunctionsMore", Operation);
		Assert.assertTrue(element("FunctionsMore", Operation).getAttribute("class").contains("authoring-disabled"));
		String CursorProperty = element("FunctionsMore", Operation).getCssValue("cursor").trim();
		Assert.assertTrue(CursorProperty.equals("not-allowed"),
				"[Assertion Failed]:: Publish Button is Not Disabled..");
	}
	
	public void verifyPreviewEpubButtonDisabled() {
		isElementDisplayed("PreviewEpub");
		Assert.assertTrue(element("PreviewEpub").getAttribute("class").contains("authoring-disabled"));
		String CursorProperty = element("PreviewEpub").getCssValue("cursor").trim();
		Assert.assertTrue(CursorProperty.equals("not-allowed"),
				"[Assertion Failed]:: Preview Epub Button is Not Disabled..");
	}

	public void VerifyCorrectRightDetailMsgIsDisplayed() {
		String Message = getData("RightDetailMsg");
		areElementsDisplayed("RightMsg");
		String msg = element("RightMsg").getAttribute("innerText");
		Assert.assertTrue(Message.equals(msg), "[Assertion Failed]:: Incorrect Right Detail Message Displayed::" + msg);
		logMessage("[Assertion Passed]:'" + msg + "' Is Displayed");
		isElementDisplayed("closelabel");
		wait.hardWait(1);
		click(element("closelabel"));

	}

	public void VerifyPushToAuthoringToolIsEnabledOnlyForStructuralValidation() {
		String WorkFlowStatus;
		isElementDisplayed("GetWorkFlowStatus");
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		logMessage(WorkFlowStatus);
		clickTopLinkMore();
		if ((WorkFlowStatus.trim().compareTo("Structural Validation Complete") == 0)) {
			isElementDisplayed("AuthoringToolEnabledLink");
			logMessage("[Assertion Passed]:Push to Authoring tool  Is displayed");
		} else {
			try {
				isElementDisplayed("AuthoringToolEnabledLink");
				logMessage(
						"[Assertion Failed]:'Structural Validation Complete' is not displayed but 'Push to Authoring tool'  link is displayed ");
				Assert.assertFalse(true);
			}

			catch (java.lang.AssertionError exc) {
				logMessage(
						"[Assertion Passed]:'Structural Validation Complete' is not displayed so 'Push to Authoring tool'  link will not be displayed ");

			}
		}
	}

	public void VerifyPushToAuthoringToolIsEnabled() {
		clickTopLinkMore();
		try {
			isElementDisplayed("AuthoringToolEnabledLink");
			logMessage("[Assertion Passed]: 'Push to Authoring tool'  link is displayed ");

		}

		catch (Exception e) {
			logMessage("[Assertion Failed]:'Push to Authoring tool'  link  not displayed ");
			Assert.assertFalse(true);
		}
	}

	public void ClickRevalidate() {
		wait.waitForPageToLoadCompletely();
		click(element("GetWorkFlowStatus"));
		logMessage("WorkFlow Satus clicked");
		click(element("Revalidate"));
		logMessage("Revalidate clicked");
		wait.waitForPageToLoadCompletely();
	}

	public void verifyStructuralValidationIsComplete() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("GetWorkFlowStatus");
		String CurrentStatus = element("GetWorkFlowStatus").getText().trim();
		logMessage("Current Status::" + CurrentStatus);
		Assert.assertTrue(CurrentStatus.equals("Structural Validation Complete"));

	}

	public void ClickPushToAuthoringTool() {
		refreshPage();
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		clickTopLinkMore();
		isElementDisplayed("FunctionsMore", "Push to Authoring Tool");
		clickUsingJS(element("FunctionsMore", "Push to Authoring Tool"));
		logMessage("Push to Push to Authoring Tool Clicked");
	}

	public void ClickPushToAuthoringTool_() {
		isElementDisplayed("FunctionsMore", "Push to Authoring Tool");
		isElementDisplayed("FunctionsMore", "Push to Authoring Tool");
		hover(element("FunctionsMore", "Push to Authoring Tool"));
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("FunctionsMore", "Push to Authoring Tool"));
		logMessage("Push to Push to Authoring Tool Clicked");
	}

	public void VerifyContentMetadataOnPushToAuthoringTool() {
		isElementDisplayed("ContentMetadata", "Title:");
		logMessage("Title:" + element("ContentMetadata", "Title:").getText());

		isElementDisplayed("ContentMetadata", "File Name:");
		logMessage("File Name:" + element("ContentMetadata", "File Name:").getText());

		isElementDisplayed("ContentMetadata", "Content Type:");
		logMessage("Content Type:" + element("ContentMetadata", "Content Type:").getText());

		isElementDisplayed("ContentMetadata", "Last Updated:");
		logMessage("Last Updated:" + element("ContentMetadata", "Last Updated:").getText());
	}

	public void SelectPushPlatformOnAuthoringTool(String Platform) {
		areElementsDisplayed("SelectPlatform");
		selectTextFromDropDown("SelectPlatform", Platform);
		logMessage("'" + Platform + "' Selected As Push Platform");
		wait.waitForPageToLoadCompletely();
	}

	public void UploadContentToFrost(String ISBN) {
		areElementsDisplayed("SelectPlatform");
		selectTextFromDropDown("SelectPlatform", "Frost");
		logMessage("'Frost' Selected As Push Platform");
		wait.hardWait(2);

		isElementDisplayed("CssOption", "clearCss");
		clickUsingJS(element("CssOption", "clearCss"));
		logMessage("'Clear CSS and Javascript' Selected ");
		wait.hardWait(1);

		logMessage(ISBN);
		scroll(element("searchBar"));
		isElementDisplayed("searchBar");
		clickUsingJS(element("searchBar"));
		String ISBNc = Keys.chord(ISBN);
		element("searchBar").sendKeys(ISBNc);
		hover(element("SearchSubmit"));
		wait.hardWait(1);
		element("SearchSubmit").click();
		logMessage("Search button clicked");
		logMessage(ISBN);
		wait.hardWait(1);
		isElementDisplayed("SelectProject", ISBN);
		scroll(element("SelectProject", ISBN));
		clickUsingJS(element("SelectProject", ISBN));

		wait.hardWait(1);
		isElementDisplayed("PushFrost");
		scroll(element("PushFrost"));
		hover(element("PushFrost"));
		wait.hardWait(1);
		click(element("PushFrost"));
		logMessage("Push Button Clicked...");
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		Assert.assertTrue(verifyElementNotDisplayed("PushFrost"), "[Assertion Failed]:: Push Button Displayed..");
	}

	public void SearchProjectOnAuthoringTool(String ISBN) {
		isElementDisplayed("searchBar");
		clickUsingJS(element("searchBar"));
		String ISBNc = Keys.chord(ISBN);
		element("searchBar").sendKeys(ISBNc);
		logMessage(ISBN + " Is Filled In Search Bar");
		clickUsingJS(element("SearchSubmit"));
		logMessage("Search button clicked");
	}

	public void VerifyProjectIsDisplayedOnAuthoringTool(String ISBN) {
		wait.hardWait(3);
		isElementDisplayed("SelectProject", ISBN);
		logMessage("Project Of " + ISBN + " is Displayed on Push To AuthoringTool");
	}

	public void SelectProjectOnAuthoringTool(String ISBN) {
		wait.hardWait(3);
		isElementDisplayed("SelectProject", ISBN);
		clickUsingJS(element("SelectProject", ISBN));
		logMessage("Project With ISBN::" + ISBN + " Selected...");
	}

	public void VerifyPushButtonOnAuthoringTool() {
		isElementDisplayed("PushFrost");
		logMessage("Push Button is Displayed..");
	}

	public void PushButtonEnabledOnPushToAutoringTool() {
		isElementDisplayed("PushFrost");
		isElementDisplayed("PushFrost");
		String Attri = element("PushFrost").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Delete Button Is Enabled...");
		} else {
			logMessage("[Assertion Failed]:: Delete Button Is Disabled...");
			Assert.assertTrue(false);
		}
	}

	public void ClickPushOnAuthoringTool() {
		isElementDisplayed("PushFrost");
		scroll(element("PushFrost"));
		wait.waitForPageToLoadCompletely();
		click(element("PushFrost"));
		logMessage("Push button Clicked...");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		wait.hardWait(2);
		Assert.assertTrue(verifyElementNotDisplayed("PushFrost"), "[Assertion Failed]:: Push Button Displayed..");
	}

	public void FilterContent(String Filter) {
		waitForLoaderToDisappear();
		wait.hardWait(2);
		isElementDisplayed("Filter");
		scroll(element("Filter"));
		isElementDisplayed("FilterContent", Filter);
		Select select = new Select(element("AllFilterOptions"));
		click(element("FilterContent", Filter));
		select.selectByVisibleText(Filter);
		logMessage(Filter + " Selected in Filter");
		wait.hardWait(2);
	}

	public void SearchProjectInAddRemovePopUp(String ISBN) {

		isElementDisplayed("SearchProject");
		isElementDisplayed("SearchProject");
		clickUsingJS(element("SearchProject"));
		String ISBNc = Keys.chord(ISBN);
		wait.hardWait(3);
		element("SearchProject").sendKeys(ISBNc);
		isElementDisplayed("SubmitProject");
		clickUsingJS(element("SubmitProject"));
		logMessage("Search button clicked");
		logMessage(ISBN);
		wait.hardWait(4);
	}

	public void VerifyOneProjectDisplayed() {
		areElementsDisplayed("ProjectDisplayed");
		if (elements("ProjectDisplayed").size() == 1) {
			logMessage("[Assertion Passed]:: Only One Project Is Displayed...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: More than One Project Is Displayed...");
		}

	}

	public void SearchForProjectOnAddRemoveProject(String ISBN) {
		isElementDisplayed("SearchProject");
		clickUsingJS(element("SearchProject"));
		String ISBNc = Keys.chord(ISBN);
		wait.hardWait(3);
		fillText("SearchProject", ISBNc);
		isElementDisplayed("SubmitProject");
		clickUsingJS(element("SubmitProject"));
		logMessage("Search button clicked");
		waitForLoaderToDisappear();
	}

	public void verifyShortTitleFieldOnAddRemoveIsNotEmpty() {
		areElementsDisplayed("GetShortTitleValue");
		List<WebElement> ShortTitleField = elements("GetShortTitleValue");
		for (int EachFiled = 0; EachFiled < ShortTitleField.size(); EachFiled++) {
			String Text = ShortTitleField.get(EachFiled).getText().trim();
			if (Text.equals(" ") || Text == null || Text.length() == 0) {
				Assert.assertTrue(false,
						"[Assertion Failed]:: 'Short Title' Field Empty on  Add/Remove Project Window");
			}
		}
	}

	public void VerifyProjectDisplayedInAvailablePane(String ISBN) {
		isElementDisplayed("selectProjectAddRemovePopUp", ISBN);
		logMessage("Project of ISBN::" + ISBN + " is Displayed in Availabe Pane");
	}

	public void SelectProjectInAvailablePane(String ISBN) {
		String InputStatus = element("selectProjectAddRemovePopUp", ISBN).getAttribute("ng-disabled");
		if (InputStatus.equals("false")) {
			areElementsDisplayed("selectProjectAddRemovePopUp", ISBN);
			clickUsingJS(element("selectProjectAddRemovePopUp", ISBN));
			logMessage(ISBN + "::Project Selected");
		} else {
			isElementDisplayed("ConformProject", ISBN);
			clickUsingJS(element("ConformProject", ISBN));
			wait.hardWait(2);
			isElementDisplayed("unselect");
			clickUsingJS(element("unselect"));
			wait.hardWait(2);
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.hardWait(2);
			areElementsDisplayed("selectProjectAddRemovePopUp", ISBN);
			clickUsingJS(element("selectProjectAddRemovePopUp", ISBN));
			logMessage("Project Selected");
		}
	}

	public void ClickSelectButtonOnAddRemovePop() {
		isElementDisplayed("moveSelectedProject");
		isElementDisplayed("moveSelectedProject");
		clickUsingJS(element("moveSelectedProject"));
		logMessage("Select button Clicked...");
	}

	public void AddTheContentToAProjectOfISBN(String ISBN1) {
		isElementDisplayed("SearchProject");
		clickUsingJS(element("SearchProject"));
		String ISBNc = Keys.chord(ISBN1);
		wait.hardWait(2);
		element("SearchProject").sendKeys(ISBNc);
		isElementDisplayed("SubmitProject");
		clickUsingJS(element("SubmitProject"));
		logMessage("Search button clicked");
		logMessage(ISBN1);
		wait.waitForPageToLoadCompletely();
		//String InputStatus = element("selectProjectAddRemovePopUp", ISBN1).getAttribute("ng-disabled");
		//logMessage("InputStatus=" + InputStatus);
		wait.hardWait(2);
		if (BoolenIsElementDisplayed("selectProjectAddRemovePopUp", ISBN1)) {
			isElementDisplayed("selectProjectAddRemovePopUp", ISBN1);
			click(element("selectProjectAddRemovePopUp", ISBN1));
			logMessage("Project Selected");
			wait.hardWait(1);
			isElementDisplayed("moveSelectedProject");
			click(element("moveSelectedProject"));
			wait.hardWait(1);
			areElementsDisplayed("save");
			click(element("save"));
			logMessage("Save button Clicked");
			isElementDisplayed("ContentAddedMsg");
			wait.waitForPageToLoadCompletely();
			String msg = element("ContentAddedMsg").getText().trim();
			Assert.assertTrue(msg.equals("Content successfully updated."),
					"[Assertion Failed]:Correct Message not displayed");
			waitForLoaderToDisappear();
		}

		else {
			logMessage("Content is Already Added to Project::" + ISBN1);
			isElementDisplayed("ConformProject", ISBN1);
			click(element("ConformProject", ISBN1));
			wait.hardWait(1);
			isElementDisplayed("unselect");
			click(element("unselect"));
			logMessage("Unselect Clicked..");
			wait.hardWait(1);
			click(element("save"));
			logMessage("Save button Clicked");
			isElementDisplayed("ContentAddedMsg");
			String msg = element("ContentAddedMsg").getAttribute("innerText");
			Assert.assertTrue(msg.contains("Content successfully updated."),
					"[Assertion Failed]:Correct Message not displayed");
			waitForLoaderToDisappear();
			ClickAddRemoveProject();
			isElementDisplayed("SearchProject");
			clickUsingJS(element("SearchProject"));
			ISBNc = Keys.chord(ISBN1);
			wait.hardWait(2);
			element("SearchProject").sendKeys(ISBNc);
			isElementDisplayed("SubmitProject");
			click(element("SubmitProject"));
			logMessage("Search button clicked");
			waitForLoaderToDisappear();
			isElementDisplayed("selectProjectAddRemovePopUp", ISBN1);
			click(element("selectProjectAddRemovePopUp", ISBN1));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			click(element("moveSelectedProject"));
			logMessage("Select Button Clicked.");
			waitForLoaderToDisappear();
			isElementDisplayed("save");
			click(element("save"));
			logMessage("Save button Clicked");
			isElementDisplayed("ContentAddedMsg");
			msg = element("ContentAddedMsg").getAttribute("innerText");
			Assert.assertTrue(msg.contains("Content successfully updated."),
					"[Assertion Failed]:Correct Message not displayed");
			waitForLoaderToDisappear();
		}
	}

	public void VerifyHistoryIsDisplayed() {
		isElementDisplayed("historyLabel");
		scroll(element("historyLabel"));
		logMessage("History Label Is displayed");
		areElementsDisplayed("historyContent");
		logMessage("[Assertion Passed]: History Log is displyed!!!");
	}

	public void AddCommentAndVerifyIt() throws NumberFormatException, IOException {
		wait.hardWait(4);

		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();
		Random r = new Random();

		String CommentNo = PropFileHandler.readPropertyFromDataFile("CommentNoforContent");
		String Comment = "Test Comment from Automated Script " + CommentNo + alphabet.charAt(r.nextInt(N));

		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		fillText("CommentArea", Comment);
		logMessage("Comment Posted::" + Comment);
		clickUsingJS(element("PostButton"));
		logMessage("Post button clicked");
		CommentNo = Integer.toString(Integer.parseInt(CommentNo) + 1);
		PropFileHandler.writePropertyToDataFile("CommentNoforContent", CommentNo);
		wait.hardWait(1);
		refreshPage();
		waitForLoaderToDisappear();
		isElementDisplayed("VerifyComment", Comment);
		scroll(element("VerifyComment", Comment));
		wait.hardWait(2);
		logMessage("Follwoing comment is displayed::" + Comment);
	}

	public void VerifyPublishLinkIsEnabledOnlyForStructuralValidation() {
		scrollToTop();
		String WorkFlowStatus;
		wait.hardWait(2);
		areElementsDisplayed("ContentViewLabel");
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		logMessage("WorkFlowStatus::" + WorkFlowStatus);
		if ((WorkFlowStatus.trim().compareTo("Structural Validation Complete") == 0)) {
			wait.waitForElementToBeClickable(element("toplinkForPublish"));
			logMessage("[Assertion Passed]:Publish Link Displayed  Is displayed");
		} else {

			if (!verifyElementNotDisplayed("toplinkForPublish")) {
				Assert.assertFalse(true,
						"[Assertion Failed]:'Structural Validation Complete' is not displayed but 'Publish Link' is displayed.");
			}

			else {
				logMessage(
						"[Assertion Passed]:'Structural Validation Complete' is not displayed so 'Publish Link' will not be displayed");
			}
		}
	}

	public void verifyPublishLinkNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("toplinkForPublish"),
				"[Assertion Failed]:: Publish Link is Displayed..");
	}

	public void VerifyPublishLinkIsEnabled() {
		try {
			isElementDisplayed("toplinkForPublish");
			isElementDisplayed("toplinkForPublish");
			logMessage("[Assertion Passed]: 'Publish Link' is displayed ");

		}

		catch (Exception e) {
			logMessage("[Assertion Failed]:'Publish Link' is not displayed ");
			Assert.assertFalse(true);
		}

	}

	public void ClickPublishLink() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinkForPublish");
		wait.waitForElementToBeClickable(element("toplinkForPublish"));
		wait.hardWait(1);
		clickUsingJS(element("toplinkForPublish"));
		logMessage("Publish Link Clicked");
		waitForLoaderToDisappear();

	}

	public void selectDestinationOfPublish(String publihDestination) {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("destination");
		selectTextFromDropDown("destination", publihDestination);
		logMessage(publihDestination + " Selected As Publish Destination");
	}

	public void VerifyPublishDestinationOnPublishPopIs(String PublihDestination) {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("destination");
		Select select = new Select(element("destination"));
		WebElement option = select.getFirstSelectedOption();
		String Destination = option.getText();
		logMessage("Publish Destination Selected::" + Destination);
		Assert.assertTrue(PublihDestination.equals(Destination), "[Assertion Failed]:: Publish Destination Displayed '"
				+ Destination + "' Expected '" + PublihDestination + "'");
		logMessage("[Assertion Passed]:: Publish Destination '" + Destination + "' Displayed");
	}

	public void VerifyDestinationIsNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("destination"), "[Assertion Failed]::Destination is Displayed...");
		logMessage("Destination is not Displayed...");
	}

	public void VerifyThreeOptionsDisplayedInPublish() {

		isElementDisplayed("TypeOfcontentToPublish", "Publish content links and ePub");
		clickUsingJS(element("TypeOfcontentToPublish", "Publish content links and ePub"));
		logMessage("'Publish content links and ePub' is Displayed");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("TypeOfcontentToPublish", "Publish content links only");
		clickUsingJS(element("TypeOfcontentToPublish", "Publish content links only"));
		logMessage("'Publish content links only' is Displayed");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeOfcontentToPublish", "Publish ePub only");
		clickUsingJS(element("TypeOfcontentToPublish", "Publish ePub only"));
		logMessage("'Publish ePub only' is Displayed");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyThreeOptionsNotDisplayedInPublish() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("TypeOfcontentToPublish", "Publish content links and ePub"),
				"[Assertion Failed]::Publish content links and ePub' is Displayed.");
		logMessage("'Publish content links and ePub' is Not Displayed");

		Assert.assertTrue(verifyElementNotDisplayed("TypeOfcontentToPublish", "Publish content links only"),
				"[Assertion Failed]::Publish content links only' is Displayed.");
		logMessage("'Publish content links only' is Not Displayed");

		Assert.assertTrue(verifyElementNotDisplayed("TypeOfcontentToPublish", "Publish ePub only are displayed"),
				"[Assertion Failed]::Publish ePub only are displayed' is Displayed");
		logMessage("'Publish ePub only are displayed' is Not Displayed");
	}

	public void TestProperToolTipsAreGiven() {
		logMessage("Verify Tool Tips Are Given");
		String tips;

		isElementDisplayed("ToolTipsForRadio", "Publish content links and ePub");
		clickUsingJS(element("ToolTipsForRadio", "Publish content links and ePub"));
		tips = element("ToolTipsForRadio", "Publish content links and ePub").getAttribute("uib-popover-html");
		logMessage(tips);
		if (tips.equalsIgnoreCase(
				"'CMS sends CFI content links to Courseware and publishes ePub to CoreSource with this action.'")) {
			logMessage(
					"'CMS sends CFI content links to Courseware and publishes ePub to CoreSource with this action.' IS Displayed");
		} else {
			logMessage("Worong Tool Tip Dispalyed");
		}
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ToolTipsForRadio", "Publish content links only");
		clickUsingJS(element("ToolTipsForRadio", "Publish content links only"));
		tips = element("ToolTipsForRadio", "Publish content links only").getAttribute("uib-popover-html");
		if (tips.equalsIgnoreCase("'CMS sends CFI content links to Courseware with this action.'")) {
			logMessage("'CMS sends CFI content links to Courseware with this action.' IS Displayed");
		} else {
			logMessage("Worong Tool Tip Dispalyed");
		}
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("ToolTipsForRadio", "Publish ePub only");
		clickUsingJS(element("ToolTipsForRadio", "Publish ePub only"));
		tips = element("ToolTipsForRadio", "Publish ePub only").getAttribute("uib-popover-html");
		if (tips.equalsIgnoreCase("'CMS publishes ePub to CoreSource with this action.'")) {
			logMessage("'CMS publishes ePub to CoreSource with this action.' IS Displayed");
		} else {
			logMessage("Worong Tool Tip Dispalyed");
		}
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyPublishRadioButtonSequence(String Option1, String Option2, String Option3) {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("SequenceOfRadioButton");
		String[] SequenceNeeded = new String[3];
		SequenceNeeded[0] = Option1;
		SequenceNeeded[1] = Option2;
		SequenceNeeded[2] = Option3;

		for (int count = 0; count < 3; count++) {
			String ValueDisplayed = elements("SequenceOfRadioButton").get(count).getAttribute("innerText").trim();
			logMessage("Radio Option Expected::" + SequenceNeeded[count]);
			logMessage("Radio Option Displayed::" + ValueDisplayed);
			Assert.assertTrue(ValueDisplayed.equals(SequenceNeeded[count]),
					"[Assertion Failed]::Radio Option Displayed::" + ValueDisplayed);
		}

	}

	public void VerifyEpubCanBePublishIfApproved() {

		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("CheckEpub");
		clickUsingJS(element("CheckEpub"));
		logMessage("Epub Clicked");

		isElementDisplayed("ApproveButton");
		clickUsingJS(element("ApproveButton"));
		logMessage("Approve button clicked");
		wait.waitForPageToLoadCompletely();

		String status = element("status").getAttribute("innerText");
		logMessage("Current Status of Epub::" + status);
		areElementsDisplayed("contentPublish");
		clickUsingJS(element("contentPublish"));
		logMessage("Publish Button Clicked");

		areElementsDisplayed("PublishMSG");
		Assert.assertTrue(
				"Publish action for content was successful.".equals(element("PublishMSG").getAttribute("innerText")),
				"[Assertion Failed]: Content was not able to publish");
		logMessage(
				"[Assertion Passed]: Content was published!!!, Message Displayed:: 'Publish action for content was successful.'");
		refreshPage();
		wait.waitForLoaderToDisappear();

	}

	public void VerifyCFIFileCanBePublishIfApproved() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckEpub");
		clickUsingJS(element("CheckEpub"));
		logMessage("Epub Clicked");

		isElementDisplayed("ApproveButton");
		clickUsingJS(element("ApproveButton"));
		logMessage("Approve button clicked");
		wait.waitForPageToLoadCompletely();

		String status = element("status").getAttribute("innerText");
		logMessage("Current Status of Epub::" + status);
		areElementsDisplayed("contentPublish");
		clickUsingJS(element("contentPublish"));
		logMessage("Publish button clicked");

		areElementsDisplayed("PublishMSG");
		Assert.assertTrue(
				element("PublishMSG").getAttribute("innerText").equals("Publish action for content was successful."),
				"[Assertion Failed]: Content was not able to publish");
		logMessage("CFI Published when approved, MESSAGE DISPLAYED:: 'Publish action for content was successful.'");
		refreshPage();
		wait.waitForLoaderToDisappear();

	}

	public void VerifyEpubCanNotBePublishIfUnapproved() {
		isElementDisplayed("CheckEpub");
		clickUsingJS(element("CheckEpub"));
		logMessage("Epub Clicked");

		isElementDisplayed("UnapproveButton");
		click(element("UnapproveButton"));
		logMessage("Unapprove button clicked");
		wait.waitForPageToLoadCompletely();

		String status = element("status").getAttribute("innerText");
		logMessage("Current Status of Epub::" + status);
		areElementsDisplayed("contentPublish");
		clickUsingJS(element("contentPublish"));
		logMessage("Publish button clicked");

		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("PublishMSG");
		Assert.assertTrue(element("PublishMSG").getAttribute("innerText").equals("No assets to publish!"),
				"[Assertion Failed]: Content was publish");
		logMessage("[Assertion Passed]: Content was not Published!!!!, Message Displayed:: 'No assets to publish!'");
		refreshPage();
		wait.waitForLoaderToDisappear();

	}

	public void VerifyCFIFileCanBePublishIfUnapproved() {
		isElementDisplayed("CheckEpub");
		clickUsingJS(element("CheckEpub"));
		logMessage("Epub Clicked");

		isElementDisplayed("UnapproveButton");
		clickUsingJS(element("UnapproveButton"));
		logMessage("Unapprove button clicked");
		wait.waitForPageToLoadCompletely();

		String status = element("status").getAttribute("innerText");
		logMessage("Current Status of Epub::" + status);
		areElementsDisplayed("contentPublish");
		clickUsingJS(element("contentPublish"));

		areElementsDisplayed("PublishMSG");
		Assert.assertTrue(
				element("PublishMSG").getAttribute("innerText").equals("Publish action for content was successful."),
				"[Assertion Failed]: Content was not able to publish");
		logMessage("CFI Published when Unapprove!!, Message displyed:: 'Publish action for content was successful.'");
		refreshPage();
		wait.waitForLoaderToDisappear();

	}

	public void ClickPublishDetail() {
		waitForLoaderToDisappear();
		isElementDisplayed("SubTab", "Publish Details");
		hover(element("SubTab", "Publish Details"));
		element("SubTab", "Publish Details").click();
		logMessage("Publish Details clicked");
	}

	public void VerifyPublishDetailsAreDisplayed() {

		areElementsDisplayed("publishDetail");
		List<WebElement> publishHistory = elements("publishDetail");
		for (WebElement dates : publishHistory) {
			System.out.println("Content Publish on::" + dates.getText());
		}
	}

	public void selectDamContentAndPublish(String nonCms) {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("checkInstructor", nonCms);
		clickUsingJS(element("checkInstructor", nonCms));
		logMessage(nonCms + " asset selected to publish");
		isElementDisplayed("ApproveButton");
		clickUsingJS(element("ApproveButton"));
		logMessage("Approve button clicked");
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("contentPublish");
		clickUsingJS(element("contentPublish"));
		logMessage("Publish button clicked");
		areElementsDisplayed("PublishMSG");
		Assert.assertTrue(
				element("PublishMSG").getAttribute("innerText").equals("Publish action for content was successful."),
				"[Assertion Failed]: Content was not able to publish");
		logMessage("[Assertion Passed]: Content was able to publish successfully");
	}

	public void ClickAddRemoveProject() {
		wait.waitForLoaderToDisappear();
		isElementDisplayed("AddRemoveButton");
		clickUsingJS(element("AddRemoveButton"));
		logMessage("Add Remove button clicked");
	}

	public void RemoveContentFromProject(String ISBN2) {
		isElementDisplayed("ConformProject", ISBN2);
		clickUsingJS(element("ConformProject", ISBN2));
		logMessage(ISBN2 + " ISBN Project selected");
		wait.waitForLoaderToDisappear();
		isElementDisplayed("unselect");
		clickUsingJS(element("unselect"));
		logMessage("Unselect Button Clicked");
		wait.waitForLoaderToDisappear();
		clickUsingJS(element("save"));
		logMessage("save button clicked");
		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		logMessage("Message Dispalyed::" + msg);
		Assert.assertTrue(msg.equals("Content successfully updated."),
				"[Assertion Failed]:Correct Message not displayed");
		logMessage("Content Removed From::" + ISBN2);
	}

	public void VerifyProjectDisplayedInSelectedPane(String ISBN) {
		isElementDisplayed("ConformProject", ISBN);
		logMessage(ISBN + " Project Displayed In Selected Pane");
	}

	public void SelectProjectInSelectedPane(String ISBN) {
		isElementDisplayed("ConformProject", ISBN);
		clickUsingJS(element("ConformProject", ISBN));
		logMessage(ISBN + " ISBN Project selected");
	}

	public void ClickUnselectButton() {
		isElementDisplayed("unselect");
		clickUsingJS(element("unselect"));
		logMessage("Unselect Button Clicked");
	}

	public void VerifyProjectNotDisplayedInSelectedPane(String ISBN) {
		Assert.assertTrue(verifyElementNotDisplayed("ConformProject", ISBN),
				"[Assertion Failed]::Project of ISBN::" + ISBN + " is Displayed...");
		logMessage("Project of ISBN::" + ISBN + " is not Displayed...");
	}

	public void ClickEditLink() {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinks", "Edit");
		clickUsingJS(element("toplinks", "Edit"));
		logMessage("Edit button clicked");
		waitForLoaderToDisappear();
	}

	public void EditAssetDetail() throws IOException {

		isElementDisplayed("Description");
		String count = PropFileHandler.readPropertyFromDataFile("EditContent");
		element("Description").clear();
		element("Description").sendKeys(("Automation Edited Description" + count));
		logMessage("Description Updated");

		element("ProductData").clear();
		element("ProductData").sendKeys(("Automation Edited TestProductData" + count));
		logMessage("Product Data Updated");

		isElementDisplayed("updateButton");
		scroll(element("updateButton"));
		click(element("updateButton"));
		waitForLoaderToDisappear();

		count = Integer.toString(Integer.parseInt(count) + 1);
		PropFileHandler.writePropertyToDataFile("EditContent", count);

	}

	public void ClickUpdateButtonOnEditContentView() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("updateButton");
		isElementDisplayed("updateButton");
		scroll(element("updateButton"));
		clickUsingJS(element("updateButton"));
		logMessage("Update Button Clicked..");
		waitForLoaderToDisappear();
	}

	public void EditContentTitle() {
		String count = PropFileHandler.readPropertyFromDataFile("EditContent");
		isElementDisplayed("EditTitle");
		element("EditTitle").clear();
		element("EditTitle").sendKeys(("Automation Edited Title" + count));
	}

	public void EditContentTitle(String NewTitle) {
		isElementDisplayed("EditTitle");
		element("EditTitle").click();
		element("EditTitle").clear();
		element("EditTitle").sendKeys(NewTitle);
	}

	public void EditDescription(String NewDec) {
		isElementDisplayed("Description");
		element("Description").click();
		element("Description").clear();
		element("Description").sendKeys(NewDec);
	}

	public void VerifyTitleIsEdited() {
		String count = PropFileHandler.readPropertyFromDataFile("EditContent");
		count = Integer.toString(Integer.parseInt(count) - 1);
		isElementDisplayed("VerifyTitle");
		Assert.assertTrue(element("VerifyTitle").getAttribute("innerText").contains("Automation Edited Title"),
				"[Assertion Failed]: Title was not updated");
		logMessage("Description is updated");

	}

	public void VerifyTitleIsEdited(String Title) {
		refreshPage();
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("VerifyTitle");
		String TitleDisplayed = element("VerifyTitle").getAttribute("innerText");
		logMessage("Title Displayed::" + TitleDisplayed);
		logMessage("Title Expected::" + Title);
		Assert.assertTrue(TitleDisplayed.equals(Title), "[Assertion Failed]: Title was not updated");
		logMessage("Title is updated..");
		wait.waitForLoaderToDisappear();
	}

	public void VerifyDetailUpdated() {
		isElementDisplayed("verifyDes");
		String count = PropFileHandler.readPropertyFromDataFile("EditContent");
		count = Integer.toString(Integer.parseInt(count) - 1);
		Assert.assertTrue(
				element("verifyDes").getAttribute("innerText").contains("Automation Edited Description" + count),
				"[Assertion Failed]: Description was not updated");
		logMessage("Description is updated");

		isElementDisplayed("VerifyProdData");
		count = PropFileHandler.readPropertyFromDataFile("EditContent");
		count = Integer.toString(Integer.parseInt(count) - 1);
		Assert.assertTrue(
				element("VerifyProdData").getAttribute("innerText")
						.contains("Automation Edited TestProductData" + count),
				"[Assertion Failed]: Product Data was not updated");
		logMessage("product data is updated");
		logMessage("[Assertio Passed]:: Asset was updated");
	}

	public void checkWorkFlowStatusIsFileIngested() {
		String WorkFlowStatus;
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("ContentViewLabel");
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		logMessage("WorkFlowStatus::" + WorkFlowStatus);
		Assert.assertTrue(WorkFlowStatus.contains("File Ingested"),
				"[Assertion Failed]: WorkFlow Status is Not 'File Ingested'");
		logMessage("[Assertion Passed]: WorkFlow Status is 'File Ingested'!!!!");

	}

	public void Click_Ready_For_Enhancements() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("GetWorkFlowStatus");
		waitAndClick("GetWorkFlowStatus");
		logMessage("WorkFlow Satus clicked");
		isElementDisplayed("ReadyForEnhancements");
		waitAndClick("ReadyForEnhancements");
		logMessage("Project State change to 'Ready For Enhancements' clicked");
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
	}

	public void CheckWorkFlowStatus() {
		wait.hardWait(2);
		isElementDisplayed("GetWorkFlowStatus");
		if (element("GetWorkFlowStatus").getAttribute("innerText").equalsIgnoreCase("Revalidate")) {
			logMessage(
					"[Assertion Failed]:: WorkFlow Status 'Revalidate' So push to Push to Authoring Tool Can not be clicked");
			Assert.assertTrue(false);
		} else {
			logMessage(
					"[Assertion Passed]:: WorkFlow Status 'Structural Validation in Progress' So push to Push to Authoring Tool Can be clicked");
			Assert.assertTrue(true);
		}

	}

	public void ClickDelete() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinks", "Delete");
		clickUsingJS(element("toplinks", "Delete"));
		logMessage("Delete button Clicked");
	}

	public void DeleteContentFromCMS() {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinks", "Delete");
		clickUsingJS(element("toplinks", "Delete"));
		logMessage("Delete button Clicked");

		isElementDisplayed("DeleteInput");
		isElementDisplayed("DeleteInput");
		fillText("DeleteInput", "Delete");

		isElementDisplayed("confirmDelete");
		click(element("confirmDelete"));
		logMessage("Confirm Delete Clciked");
		logMessage("[Assertion passed]:: Content Deleted!!!!!!");

		// isElementDisplayed("publishMessage");
		isElementDisplayed("publishMessage");
		wait.waitForPageToLoadCompletely();
		String Message = element("publishMessage").getAttribute("innerText").trim();
		if (Message.length() < 1) {
			Assert.assertTrue(false, "[Assertion Failed]::No Message Displayed.");
		}
		Assert.assertTrue(Message.contains("Content successfully deleted."),
				"[Assertion Failed]:: Incorrect Message Displayed::" + Message);
		logMessage("[Assertion Passed]:: Correct Message Displayed::" + Message);
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void ConfirmContentIsAssociateToProject(String ISBN) {
		scroll(element("AssociatedLabel"));
		isElementDisplayed("ConfirmProject", ISBN);
		logMessage("get=" + element("ConfirmProject", ISBN).getAttribute("innerText"));
		logMessage("present=" + ISBN);
		Assert.assertTrue(element("ConfirmProject", ISBN).getAttribute("innerText").contains(ISBN),
				"[Assertion Failed]:: Content Was not associated to::" + ISBN);
		logMessage("[Assertion Passed]:: Content was associated to project::" + ISBN);
	}

	public void VerifyOnContentViewPage() {
		waitForLoaderToDisappear();
		scrollToTop();
		isElementDisplayed("ContentViewLabel");
		logMessage("User is on Content View..");
		wait.waitForPageToLoadCompletely();
	}

	public void ClickContentView() {
		isElementDisplayed("ContentViewLabel");
		click(element("ContentViewLabel"));
		logMessage("Content View Clicked..");

	}

	public void VerifyUploadContentButton() {
		isElementDisplayed("uploadContent");
		logMessage("Upload Content is displayed...");
	}

	public void ClickHomeOnContentView() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("HomeLink");
		clickUsingJS(element("HomeLink"));
		logMessage("Home Link Clicked!!!!!!");
	}

	public void VerifyContentLinkAppearing() {
		isElementDisplayed("ContentLink");
		logMessage("Content link is appering...");

	}

	public void VerifyContentThumbnailAppering() {
		isElementDisplayed("ContentThumbnail");
		logMessage("Thumbnail for the content is appering ");
	}

	public void VerifyPublishPopUpDisplayed() {
		areElementsDisplayed("publishPopUp");
		logMessage("Publish Pop Up Is Displayed...");
	}

	public void VerifyTitleOfContentIsDisplayedOnPublishPopUp(String ISBN) {
		isElementDisplayed("PublishTitle");
		String Title = element("PublishTitle").getAttribute("innerText");
		logMessage("Title shown::" + Title);
		Assert.assertTrue(Title.contains(ISBN + ".epub"),
				"[Assertion Failed]:: Publish Title does not contains The Name Of the File to Publish");

		logMessage("[Assertion Passed]:: Publish Title contains The Name Of the File to Publish");

	}

	public void VerifyThreeSectionDisplayedInPublish() {
		areElementsDisplayed("PublishSections");
		List<WebElement> Steps = elements("PublishSections");
		wait.waitForPageToLoadCompletely();
		for (int i = 0; i < Steps.size(); i++) {
			wait.hardWait(1);
			logMessage("'Step " + (i + 1) + ":" + Steps.get(i).getAttribute("innerText") + "' Is Displayed..");
		}

	}

	public void VerifyStep1NameForCFIPublish() {
		isElementDisplayed("CFIStep1Title");
		logMessage("[Assertion Passsed]::Correct Title Displayed Is:: Index the CFI links metadata in Courseware");

		isElementDisplayed("publishCFIStep1Title");
		logMessage("Message Displayed:: " + element("publishCFIStep1Title").getAttribute("innerText"));

	}

	public void VerifySelectedAssetsSectionDisplayName(String ISBN) {
		isElementDisplayed("AssetName", ISBN + ".epub");
		logMessage("Assert Named is Displayed::" + ISBN + ".epub");
	}

	public void VerifyPublishAssetsHasApproveAndApproveButton() {
		isElementDisplayed("ApproveButton");
		isElementDisplayed("ApproveButton");
		logMessage("Approve Button Is Displayed..");

		isElementDisplayed("UnapproveButton");
		isElementDisplayed("UnapproveButton");
		logMessage("Unapprove Button Is Displayed..");

	}

	public void VerifyPublishAssetsDetailsAreProvided() {
		areElementsDisplayed("publishAssetDetail");
		List<WebElement> details = elements("publishAssetDetail");
		for (int i = 0; i < details.size(); i++) {
			if (" Name Type Status Repository ".contains(details.get(i).getAttribute("innerText"))) {
				logMessage("[Assertion Passsed]:: " + details.get(i).getAttribute("innerText") + " Is Displayed");
			} else {
				logMessage("[Assertion Failed]:: " + details.get(i).getAttribute("innerText") + " Is Not Displayed");
				Assert.assertTrue(false);
			}
		}
	}

	public void SelectEpubOnPublishPopUp() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckEpub");
		clickUsingJS(element("CheckEpub"));
		logMessage("Epub Clicked");
	}

	public void SelectAssertOnpublishPopUp() {
		isElementDisplayed("CheckEpub");
		isElementDisplayed("CheckEpub");
		hover(element("CheckEpub"));
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("CheckEpub"));
		logMessage("Asset is Clicked");
		wait.waitForPageToLoadCompletely();
	}

	public void SelectCFIOnPublishPopUp() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckEpub");
		clickUsingJS(element("CheckEpub"));
		logMessage("Epub Clicked");
	}

	public void ClickApproveButtonOnPublishPopUp() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ApproveButton");
		isElementDisplayed("ApproveButton");
		hover(element("ApproveButton"));
		wait.waitForPageToLoadCompletely();
		click(element("ApproveButton"));
		logMessage("Approve button clicked");
		wait.waitForPageToLoadCompletely();
		String status = element("status").getAttribute("innerText").trim();
		logMessage("Current Status of Asset::" + status);
		Assert.assertTrue(status.equals("Approved"),
				"[Assertion Failed]:: Current Status After Approving Asset is '" + status + "'");
		logMessage("[Assertion Passed]:: Current Status After Approving Asset is '" + status + "'");

	}

	public void ClickUnApproveButtonOnPublishPopUp() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UnapproveButton");
		logMessage("Un Approve Button Clicked....");
		click(element("UnapproveButton"));
		logMessage("Unapprove Button clicked");

		isElementDisplayed("status");
		wait.waitForPageToLoadCompletely();
		String status = element("status").getAttribute("innerText").trim();
		logMessage("Current Status of Asset::" + status);
		Assert.assertTrue(status.equals("Not Approved"),
				"[Assertion Failed]:: Current Status After UnApproving Asset is '" + status + "'");
		logMessage("[Assertion Passed]:: Current Status After UnApproving Asset is '" + status + "'");
	}

	public void clickpublishOnPublishPopUp() {
		wait.waitForPageToLoadCompletely();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("contentPublish");
		clickUsingJS(element("contentPublish"));
		logMessage("Publish Button Clicked");
	}

	public void VerifyPublishButtonDisabled() {
		isElementDisplayed("contentPublish");
		String Attribute = element("contentPublish").getAttribute("disabled").trim();
		Assert.assertTrue(Attribute.equals("true"), "[Assertion Failed]:: Publish Button is Not Disabled..");
		String CursorProperty = element("contentPublish").getCssValue("cursor").trim();
		Assert.assertTrue(CursorProperty.equals("not-allowed"),
				"[Assertion Failed]:: Publish Button is Not Disabled..");

	}

	public void VerifyPublishButtonEnabled() {
		isElementDisplayed("contentPublish");
		Assert.assertTrue(element("contentPublish").getAttribute("disabled") == null,
				"[Assertion Failed]:: Publish Button is Not Disabled..");
		String CursorProperty = element("contentPublish").getCssValue("cursor").trim();
		Assert.assertTrue(CursorProperty.equals("pointer"), "[Assertion Failed]:: Publish Button is Not Disabled..");

	}

	public void VerifyContentIsPublished() {
		areElementsDisplayed("PublishMSG");
		Assert.assertTrue(
				"Publish action for content was successful.".equals(element("PublishMSG").getAttribute("innerText")),
				"[Assertion Failed]: Content was not able to publish, MessageDisplayed::"
						+ element("PublishMSG").getAttribute("innerText"));
		logMessage(
				"[Assertion Passed]: Content was published!!!, Message Displayed:: 'Publish action for content was successful.'");
		ClickCloseOnpublishPopup();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyPublishWasUnsuccessful_DMS_User(String PublishMessage) {
		isElementDisplayed("DMSPublishError");
		String MessageDisplayed = element("DMSPublishError").getAttribute("innerText").trim();
		logMessage("Message Displayed::" + MessageDisplayed);
		logMessage("Message Expected::" + PublishMessage);
		Assert.assertTrue(MessageDisplayed.equals(PublishMessage),
				"[Assertion Failed]:: Incorrect Message Displayed :" + MessageDisplayed);
		logMessage("[Assertion Passed]:: Correct Message Displayed :" + MessageDisplayed);
		ClickCloseOnpublishPopup();
	}

	public void VerifyContentIsNotPublished() {
		areElementsDisplayed("PublishMSG");
		Assert.assertTrue(element("PublishMSG").getAttribute("innerText").equals("No assets to publish!"),
				"[Assertion Failed]: Content was publish");
		logMessage("[Assertion Passed]: Content was not Published!!!!, Message Displayed:: 'No assets to publish!'");
		ClickCloseOnpublishPopup();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyPublishAndCancelButtonOnPublishPopUp() {
		isElementDisplayed("contentPublish");
		logMessage("Publish button Is Dispalyed...");

		isElementDisplayed("CancelButton");
		logMessage("Cancel Button Is Dispalyed...");
	}

	public void ClickCancelOnPublishPop() {
		isElementDisplayed("CancelButton");
		scroll(element("CancelButton"));
		click(element("CancelButton"));
		logMessage("Cancel Button Is Clicked...");
	}

	public void VerifyPublishPopIsClosed() {
		wait.hardWait(2); // need to wait for code to be refreshed on DOM
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("ApproveButton"),
				"[Assertion Failed]::Publish Pop Up Is Displayed...");
		logMessage("Publish Pop Up Is Not Displayed...");

	}

	public void SelectPublishRadioButton(String TypeOfcontent) {
		isElementDisplayed("TypeOfcontentToPublish", TypeOfcontent);
		clickUsingJS(element("TypeOfcontentToPublish", TypeOfcontent));
		logMessage("'" + TypeOfcontent + "'" + " Selected as type od centent To publish");

	}

	public void ClickDownloadContent() {
		isElementDisplayed("toplinks", "Download Content ");
		clickUsingJS(element("toplinks", "Download Content "));
		logMessage("Download content Clicked...");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyClickingWorkflowPublish_MoreLinkDisable() {
		Assert.assertTrue(verifyElementNotDisplayed("toplinkForPublish"),
				"[Assertion Failed]:: Publish Link Is Displayed...");
		logMessage("[Assertion Passed]:: Publish Link Is Not Displayed...");

		Assert.assertTrue(verifyElementNotDisplayed("GetWorkFlowStatus"),
				"[Assertion Failed]:: WorkFlow Status Is  Displayed...");
		logMessage("[Assertion Passed]:: WorkFlow Status Is Not Displayed...");

		Assert.assertTrue(verifyElementNotDisplayed("toplinkMore"), "[Assertion Failed]:: More link Is Displayed...");
		logMessage("[Assertion Passed]:: More link Is Not Displayed...");
	}

	public void ClickViewUsageDetails() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("FunctionsMore", "View Usage Details");
		waitAndClick("FunctionsMore", "View Usage Details");
		logMessage("'View Usage Details' is Clicked");

	}

	public void VerifyViewUsageDetailPopUpDisplay() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UsagePopUp");
		isElementDisplayed("UsagePopUp");
		logMessage("View Usage Detail Pop Up Displayed.....");
	}

	public void VerifyExplodedEpubPopUpDisplay() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExplodedEpubpopUp");
		logMessage("Exploded Epub PopUp Pop Up Displayed.....");

	}
	
	public void VerifyExplodedEpubPopUpIsNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("ExplodedEpubpopUp"),"[Assertion Failed]::xploded Epub PopUp Pop Up Displayed.....");
	}

	public void verifySearchFieldAndClearAllLinkOnAddtoProjectpopUp() {
		isElementDisplayed("SearchProject");
		isElementDisplayed("SearchProject");
		logMessage("Search Field Is Displayed");

		isElementDisplayed("ClearAll");
		isElementDisplayed("ClearAll");
		logMessage("Clear All Field Is Displayed");
	}

	public void VerifyInformationOnUsageDetail() {
		areElementsDisplayed("UsageDetailInfo");
		List<WebElement> info = elements("UsageDetailInfo");
		for (int i = 0; i < info.size(); i++) {
			logMessage(info.get(i).getAttribute("innerText") + " is Displayed...");
		}
	}

	public void ClickViewEpubFiles() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("FunctionsMore", "View ePub Files");
		waitAndClick("FunctionsMore", "View ePub Files");
		logMessage("'View ePub Files' is Clicked");
	}

	public void VerifyPushToAuthoringToolPopUp() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AuthoringToolPopUp");
		isElementDisplayed("AuthoringToolPopUp");
		logMessage("Push To Authoring Tool PopUp Pop Up Displayed.....");

	}

	public void VerifySubCategoriesInPushToAuthoringTool() {
		isElementDisplayed("SubCategories", "Step 1");
		logMessage("Categories:: Step 1 Displayed.....");

		isElementDisplayed("SubCategories", "Step 2");
		logMessage("Categories:: Step 2 Displayed.....");

		isElementDisplayed("SubCategories", "Step 3");
		logMessage("Categories:: Step 3 Displayed.....");

	}

	public void VerifyStep1PushToAuthoringTool() {
		isElementDisplayed("SubCategories", "Step 1: Select Authoring Platform");
		logMessage("Step 1: Select Authoring Platform Displayed.....");
	}

	public void VerifyStep2PushToAuthoringTool() {
		isElementDisplayed("SubCategories", "Step 2: Selected Assets");
		logMessage("Step 2: Selected Assets Displayed.....");
	}

	public void VerifySelectedAssetsSection() {
		isElementDisplayed("SelectAssertSection");
		logMessage("Selected Assert Section Is displayed...");
	}

	public void VerifyViewButtonOnPushToAuthoringTool() {
		isElementDisplayed("ViewButton");
		logMessage("View Button Is displayed....");

		clickUsingJS(element("ViewButton"));
		logMessage("'ViewButton' Clciked List view Selected..");
		Assert.assertTrue(verifyElementNotDisplayed("GridView"));
		logMessage("List View Is Displayed.......");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("ViewButton");
		logMessage("View Button Is Dispayed...");
		clickUsingJS(element("ViewButton"));
		logMessage("'ViewButton' Clciked Grid view Selected..");
		isElementDisplayed("GridView");
		logMessage("Grid View Is Displayed.......");
	}

	public void VerifyGridView() {

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("GridView");
		logMessage("Thumbnail View Is displayed...");
	}

	public void ClickViewIconOnPushToAutoringTool() {
		isElementDisplayed("ViewButton");
		logMessage("View Button Is Dispayed...");
		click(element("ViewButton"));
		logMessage("'ViewButton' Clciked List view Selected..");
	}

	public void VerifyListView() {
		isElementDisplayed("ViewButton");
		logMessage("View Button Is Dispayed...");
		click(element("ViewButton"));
		logMessage("'ViewButton' Clciked List view Selected..");

		Assert.assertTrue(verifyElementNotDisplayed("ListView"));
		List<WebElement> info = elements("ListViewHeader");
		for (int i = 0; i < info.size(); i++) {
			logMessage("'" + info.get(i).getAttribute("innerText") + "' Is Displayed....");
		}
	}

	public void VerifySearchFieldOnAuthoringTool() {
		isElementDisplayed("searchBar");
		logMessage("Search Field is displayed....");
	}

	public void VerifyInfoIsDisplayedOnClickingHelpIcon() {
		isElementDisplayed("HelpIcon");
		logMessage("help Icon Is dispalyed....");
		waitAndClick("HelpIcon");
		logMessage("help icon clciked...");

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("HelpInfos");
		isElementDisplayed("HelpInfos");
		logMessage("Help Information Is Displayed::" + element("HelpInfos").getAttribute("innerText"));
	}

	public void VerifySelectProjectOnAuthoringTool() {

		isElementDisplayed("ProjectISBN");
		logMessage("Select Project ISBN is displayed....");
	}

	public void SelectCSSOption(String CSSOption) { // 1. clearCss 2. retainCss
		isElementDisplayed("CssOption", CSSOption);
		clickUsingJS(element("CssOption", CSSOption));
		logMessage("'" + CSSOption + "' Selected....");
	}

	public void ClickCancelOnAuthoringTool() {
		isElementDisplayed("Cancel");
		clickUsingJS(element("Cancel"));
		logMessage("Cancel button Clicked.....");
	}

	public void VerifyCancelButtonOnAuthoringTool() {
		isElementDisplayed("Cancel");
		logMessage("'Cancel' button is Displayed on Push to Authoring Tool");
	}

	public void VerifyAuthoringToolClosed() {
		wait.hardWait(2); // need to wait for code to refreshed on DOM
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("ProjectISBN"),
				"[Assertion Failed]::Push To Authoring Tool PopUp Pop Up is Displayed");
		logMessage("Push To Authoring Tool PopUp Pop Up is Not Displayed..");
	}

	public void VariousFieldOfContentDetails(String ContentType) {
		isElementDisplayed("ContentDetail", "Content Type");
		logMessage("Content Type:" + element("ContentDetail", "Content Type").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Resource Type");
		logMessage("Content Type:" + element("ContentDetail", "Resource Type").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Title");
		logMessage("Content Type:" + element("ContentDetail", "Title").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Description");
		logMessage("Content Type:" + element("ContentDetail", "Description").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Default Access Level (Achieve):");
		logMessage("Content Type:"
				+ element("ContentDetail", "Default Access Level (Achieve):").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Subject Heading Taxonomy");
		logMessage("Content Type:" + element("ContentDetail", "Subject Heading Taxonomy").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Subject Keyword Taxonomy");
		logMessage("Content Type:" + element("ContentDetail", "Subject Keyword Taxonomy").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Product Data");
		logMessage("Content Type:" + element("ContentDetail", "Product Data").getAttribute("innerText"));

		isElementDisplayed("ContentDetail", "Repository");
		logMessage("Content Type:" + element("ContentDetail", "Repository").getAttribute("innerText"));

		if (ContentType.equals(getData("TypesOfContent.Supplementary Content>Course Management"))) {
			isElementDisplayed("ContentDetail", "Course Management Demo Link:");
			logMessage("Course Management Demo Link:s"
					+ element("ContentDetail", "Course Management Demo Link:").getAttribute("innerText"));
		} else {
			isElementDisplayed("RightDitail");
			logMessage("Rights Details (Lumina): is Displayed..");
		}
	}

	public void clickLuminaRightDetail() {
		isElementDisplayed("RightDitail");
		scroll(element("RightDitail"));
		click(element("RightDitail"));
		logMessage("Lumina Right Details Clicked");
	}

	public void VerifyLuminaRightsDetails(String DB_Key, String PFN) {
		isElementDisplayed("RightDitail");
		scroll(element("RightDitail"));
		click(element("RightDitail"));
		logMessage("Expected DB_Key::" + DB_Key);
		logMessage("Displayed DB_Key::" + element("LuminaRightsDetailsDBKey").getAttribute("innerText").trim());

		logMessage("Expected PFN::" + PFN);
		logMessage("Displayed PFN::" + element("LuminaRightsDetailsPFN").getAttribute("innerText").trim());
		if (element("LuminaRightsDetailsDBKey").getAttribute("innerText").trim().equals(DB_Key)
				&& element("LuminaRightsDetailsPFN").getAttribute("innerText").trim().equals(PFN)) {
			Assert.assertTrue(true, "[Assertion Passed]:: Correct Lumina Asset DB Key::" + DB_Key
					+ " displayed \n  Correct PNF::" + PFN);
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Incorrect Lumina Asset DB Key::" + DB_Key
					+ " displayed \n  Incorrect PNF::" + PFN);
		}

	}

	public void VerifyAddEmailButton() {
		isElementDisplayed("AddButton");
		logMessage("Add Button is Displayed...");

	}

	public void VerifyMessageOnInvalidEmailAddress() {
		isElementDisplayed("AddEmail");
		fillText("AddEmail", "InvalidEmail");

		isElementDisplayed("InvalidMSg");
		wait.waitForPageToLoadCompletely();
		logMessage("Message Displayed::" + element("InvalidMSg").getText().trim());
		Assert.assertTrue(element("InvalidMSg").getText().trim().equals("Invalid email address"),
				"[Assertion Failed]:: Error Message Not Dispalyed");
		logMessage("[Assertion Passed]:: Error Message Displayed '" + element("InvalidMSg").getText().trim() + "'");
	}

	public void AddEmailAddress(String Email) {
		isElementDisplayed("AddEmail");
		fillText("AddEmail", Email);
		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add button Clicked.....");

	}

	public void VerifyEmailIsAdded(String Email) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("deleteButton", Email);
		logMessage(Email + " Is Added in Content Contacts");
	}

	public void VerifyTableHeader() {
		areElementsDisplayed("TableHead");
		logMessage(elements("TableHead").get(0).getAttribute("innerText") + " Is Displayed");
		logMessage(elements("TableHead").get(1).getAttribute("innerText") + " Is Displayed");
	}

	public void RemoveAddedEmail(String Email) {
		isElementDisplayed("deleteButton", Email);
		clickUsingJS(element("deleteButton", Email));
		logMessage("Email Removed From the Content");
	}

	public void VerifyEmailExistErrorMSG() {
		isElementDisplayed("ErrorMSG");
		logMessage("Message Displayed::" + element("ErrorMSG").getText().trim());
		Assert.assertTrue(
				element("ErrorMSG").getText().trim().equals("Email already added, please use a different email"),
				"[Assertion Failed]:: Error Message Not Dispalyed");
		logMessage("[Assertion Passed]:: Error Message Displayed '" + element("ErrorMSG").getText().trim() + "'");
	}

	public void VerifyOnPublishDetailPage() {
		isElementDisplayed("publishDetailLabel");
		logMessage("User IS On Piblish Detail Page...");
	}

	public void VerifyHeaderOfPublishTab() {
		isElementDisplayed("publishHeader", "Username");
		isElementDisplayed("publishHeader", "Destination");
		isElementDisplayed("publishHeader", "Published Date");
		isElementDisplayed("publishHeader", "Published Project ISBN");
		isElementDisplayed("publishHeader", "Publish Status");
	}

	public void WaitforpublishToComplete(String SuccessText, String index) {
		ClickRefreshLink();
		isElementDisplayed("publishInformation", index);
		int No_try = 0;
		while (No_try <= 180) {
			String Status = element("publishInformation", index).getAttribute("innerText").trim();
			if (Status.equalsIgnoreCase(SuccessText)) {
				logMessage("'" + SuccessText + "' Status is Displayed..");
				return;
			}

			else if (Status.equalsIgnoreCase("Failed") || Status.contains("Could not retrieve")) {
				Assert.assertTrue(false, "[Assertion Failed]::'" + Status + "' Status is Displayed..");
				return;
			} else {
				logMessage(Status + " State is Displayed..");
				wait.hardWait(5); // Will Try for 5 sec before re checking Publish Status. will Try to check for
									// 15 min
				ClickRefreshLink();
				No_try++;
			}
			if (No_try >= 180) {
				Assert.assertTrue(false, "[Assertion Failed]::'Complete status is not Displayed'");
				return;
			}
		}

	}

	public void VerifyRefreshLink() {
		isElementDisplayed("Refresh");
		logMessage("Refresh Link Is Available....");
	}

	public void ClickRefreshLink() {
		String title = getPageTitle();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("Refresh");
		clickUsingJS(element("Refresh"));
		logMessage("Refresh Link clicked...");
		waitForPageToLoadCompletely(title);
	}

	public void CheckForColoumsInVersionDetail() {
		areElementsDisplayed("ColoumsInfo");
		List<WebElement> info = elements("ColoumsInfo");
		for (int i = 0; i < info.size(); i++) {
			logMessage(info.get(i).getAttribute("innerText") + " Is dispalyed...");
		}

	}

	public void VerifButtonsOnUploadVersion() {
		isElementDisplayed("SelectFile");
		logMessage("'Select File' Button Is visible");

		isElementDisplayed("finishButton");
		logMessage("'finish' Button Is Visible");

		isElementDisplayed("CancelButtonVer");
		logMessage("'Cancel' Button Is Visible..");

	}

	public void clickSelectFile() {
		isElementDisplayed("SelectFile");
		logMessage("'Select File' Button Is visible");
		clickUsingJS(element("SelectFile"));
		logMessage("Select File Button Clicked...");
	}

	public void UploadNewVersionOfContent(String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("SelectFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN;

		} else {
			filePath = "C:/cms Testdata/" + FileISBN;
		}
		element("SelectFile").sendKeys(filePath);
		logMessage(FileISBN + " selected");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("UploadMSG");
		logMessage("Message Displayed::" + element("UploadMSG").getAttribute("innerText"));

		isElementDisplayed("finishButton");
		logMessage("'finish' Button Is Visible");
		clickUsingJS(element("finishButton"));
		logMessage("'finish' Button Clicked");
		logMessage("New Version Of " + FileISBN + " FC File Has Been Uploded..");
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
	}

	public void SelectIncorrectFileInUploadVersion(String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("SelectFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN + ".epub";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + ".epub";
		}
		element("SelectFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyErrorMessageOnUploadIncorrectFileNameOnVersionDetailTab() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UploadErrorMSG");
		logMessage("Message Displayed::" + element("UploadErrorMSG").getAttribute("innerText"));
		Assert.assertTrue(
				element("UploadErrorMSG").getAttribute("innerText")
						.equals("File name does not match with the previous version!!"),
				"[Asseetion Failed::] Correct Error Message Is Not Displayed..");
		logMessage("[Asseetion Passed::] Correct Error Message Is Displayed..");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyUploadNewVersionPopUpClosed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("SelectFile"),
				"[Assertion Failed]::Upload New Version Pop Up Displayed..");
		logMessage("Upload New Version Pop Up Closed....");

	}

	public void VerifyNewVersionOnVersionDetailsTab() {
		areElementsDisplayed("LatestUplodedVerDate");
		List<WebElement> dates = elements("LatestUplodedVerDate");
		for (int i = 0; i < dates.size(); i++) {
			wait.waitForPageToLoadCompletely();
			logMessage("Date Of Version " + (i + 1) + " is::" + dates.get(i).getAttribute("innerText"));
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-yyyy");
			LocalDateTime now = LocalDateTime.now();
			String Tdate = dtf.format(now);
			System.out.println("Today's Date is::" + Tdate);
			if (dates.get(i).getAttribute("innerText").contains(Tdate)) {
				logMessage("[Assertion Passsed]:: NEW version of the Content is Uploded..");
				return;
			}
		}
		logMessage("[Assertion Failed]:: NEW version of content is not Uploded..");

	}

	public void PrintTheInfoemationOfTheTable() {
		areElementsDisplayed("PrintLatestVersion");
		List<WebElement> info = elements("PrintLatestVersion");
		for (int i = 0; i < info.size(); i++) {
			System.out.print(info.get(i).getAttribute("innerText") + "    ");
		}

	}

	public void VerifyUploadedByVersionTab(String Email) {
		isElementDisplayed("VerUploadedBy", Email);
		logMessage(Email + " Is Displayed in Uploaded by in Version Detail Table");
	}

	public void verifyUserIsAbleToDownload() {
		isElementDisplayed("SelectVersion");
		clickUsingJS(element("SelectVersion"));
		logMessage("Version Selected...");
		clickUsingJS(element("VersionOperation", "Download"));
		logMessage("Download Functionality is working");
	}

	public void CheckApproveButtonFunctionality() {
		isElementDisplayed("VersionOperation", "Approve");
		clickUsingJS(element("VersionOperation", "Approve"));
		wait.waitForPageToLoadCompletely();
		String Status = element("GetApproveStatus").getAttribute("innerText");
		if (Status.compareTo("Approved") == 0) {
			logMessage("[Assertion Passed]:User is able to Approve the content");
		} else {
			logMessage("[Assertion Failed]:User is  not able to Approve the content");
			Assert.assertFalse(true);
		}
	}

	public void CheckUapproveButtonFunctionality() {
		isElementDisplayed("VersionOperation", "Unapprove");
		clickUsingJS(element("VersionOperation", "Unapprove"));
		wait.waitForPageToLoadCompletely();
		String Status = element("GetApproveStatus").getAttribute("innerText");
		logMessage(Status);
		if (Status.compareTo("Not Approved") == 0) {
			logMessage("[Assertion Passed]:User is able to Unapprove the content");
		} else {
			logMessage("[Assertion Failed]:User is  not able to Unapprove the content");
			Assert.assertFalse(true);
		}
	}

	public void VerifyDeletePopUp() {
		isElementDisplayed("DeleteLabel");
		logMessage("Delete Pop Is Displayed....");
	}

	public void VerifyDeletebuttonDisabled() {
		isElementDisplayed("confirmDelete");
		isElementDisplayed("confirmDelete");
		String Attri = element("confirmDelete").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Failed]:: Delete Button Is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]:: Delete Button Is Disabled...");
		}
	}

	public void EnterDeleteInTextBox() {
		isElementDisplayed("DeleteInput");
		logMessage("Delete Input box Is Visible");
		fillText("DeleteInput", "delete");
	}

	public void VerifyDeletebuttonEnabled() {
		isElementDisplayed("confirmDelete");
		isElementDisplayed("confirmDelete");
		String Attri = element("confirmDelete").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Delete Button Is Enabled...");
		} else {
			logMessage("[Assertion Failed]:: Delete Button Is Disabled...");
			Assert.assertTrue(false);
		}
	}

	public void ClickConformDelete() {
		isElementDisplayed("confirmDelete");
		clickUsingJS(element("confirmDelete"));
		logMessage("Confirm Delete Clciked");
		logMessage("[Assertion passed]::Content Deleted!!!!!!");

		isElementDisplayed("ContentAddedMsg");
		logMessage("Message Dispaled::" + element("ContentAddedMsg").getAttribute("innerText"));
	}

	public void ClickConformDeleteOnVersionDetail() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("confirmDelete");
		isElementDisplayed("confirmDelete");
		clickUsingJS(element("confirmDelete"));
		waitForLoaderToAppear();
		logMessage("Confirm Delete Clciked");
		logMessage("[Assertion passed]::Version Deleted!!!!!!");
	}

	public void verifyAssociatedProjectLabel() {
		isElementDisplayed("AssociatedLabel");
		scroll(element("AssociatedLabel"));
		logMessage("Associated Project Label is Displayed...");

	}

	public void VerifyAssociatedProjectDetail() {
		isElementDisplayed("ContentImg");
		scroll(element("ContentImg"));
		logMessage("Thumbnail of the project is displayed...");

		isElementDisplayed("ContentDetails", "Author:");
		logMessage("Author:" + element("ContentDetails", "Author:").getText());

		isElementDisplayed("ContentDetails", "Title:");
		logMessage("Title:" + element("ContentDetails", "Title:").getText());

		isElementDisplayed("ContentDetails", "Edition:");
		logMessage("Edition:" + element("ContentDetails", "Edition:").getText());

		isElementDisplayed("ContentDetails", "ISBN:");
		logMessage("ISBN:" + element("ContentDetails", "ISBN:").getText());

	}

	public void VerifyAddremoveButton() {
		isElementDisplayed("AddRemoveButton");
		logMessage("Add/Remove Button Is displayed..");

	}

	public void VerifypopAddRemovePopUp() {
		areElementsDisplayed("AddtoProjectlabel"); // ########### Dublicate Code
													// present in Source code
													// resulting to Locator
													// conflict
		logMessage("Add/Remove project Pop Up Is displayed...");

	}

	public void VerifyColoumsOnHistoryTable() {
		areElementsDisplayed("HistoryColoum");
		List<WebElement> Col = elements("HistoryColoum");
		wait.waitForPageToLoadCompletely();
		for (int i = 0; i < Col.size(); i++) {
			logMessage(Col.get(i).getAttribute("innerText") + " Is Displayed!!");
		}

	}

	public void verifyPaginationBarIsAppering() {
		try {
			isElementDisplayed("PaginationBar");
			logMessage("PaginationBar Is Appering At thr bottom og the Hisory Table");
		} catch (java.lang.AssertionError exc) {
			logMessage(
					"PaginationBar Is not Appering At thr bottm of the Hisory Table as all the history information is displayed..");
		}

	}

	public void VerifyBackAndForthNavigationpaginationBar() {

		isElementDisplayed("navigate", "2");
		clickUsingJS(element("navigate", "2"));
		logMessage("page number 2 clicked... Able To move Forword from pagination Bar");

		isElementDisplayed("navigate", "1");
		clickUsingJS(element("navigate", "1"));
		logMessage("page number 1 clicked... Able To move Backword from pagination Bar");

	}

	public void VerifyCommentSection() {
		isElementDisplayed("CommentLabel");
		isElementDisplayed("CommentLabel");
		logMessage("Comments is displayed....");
		isElementDisplayed("CommentArea");
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		logMessage("comment Section is Displayed...");
	}

	public void VerifyCommentSectionPaneAndPostButton() {
		isElementDisplayed("CommentArea");
		isElementDisplayed("CommentArea");
		logMessage("comment Section is Displayed...");
		isElementDisplayed("PostButton");
		isElementDisplayed("PostButton");
		logMessage("Post Button is Displayed...");

	}

	public void VerifyPostButtonDisable() {
		isElementDisplayed("CommentArea");
		element("CommentArea").clear();

		isElementDisplayed("PostButton");
		isElementDisplayed("PostButton");
		String Attri = element("PostButton").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Failed]:: Post Button Is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]:: Post Button Is Disabled...");
		}

	}

	public void VerifyPostButtonActive() throws IOException {
		wait.waitForPageToLoadCompletely();
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();
		Random r = new Random();

		String CommentNo = PropFileHandler.readPropertyFromDataFile("CommentNoforContent");
		String Comment = "TestCommentContent " + CommentNo + alphabet.charAt(r.nextInt(N));

		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		fillText("CommentArea", Comment);
		logMessage("Comment Posted::" + Comment);
		CommentNo = Integer.toString(Integer.parseInt(CommentNo) + 1);
		PropFileHandler.writePropertyToDataFile("CommentNoforContent", CommentNo);
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("PostButton");
		String Attri = element("PostButton").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Post Button Is Enabled...");
			clickUsingJS(element("PostButton"));
			logMessage("Post button clicked");
		} else {
			logMessage("[Assertion Failed]:: Post Button Is Disabled...");
			Assert.assertTrue(false);
		}
	}

	public void VerifyUserIsNotAbleToDeleteMsg(String Email) {
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();

		try {
			Assert.assertTrue(verifyElementNotDisplayed("deleteComment", Email));
			logMessage("[Assertion Passed]:: Other User not able to delete comment ");
			Assert.assertTrue(true);
		} catch (java.lang.AssertionError e) {
			logMessage("[Assertion Failed]:: Other User is able to delete comment");
			Assert.assertTrue(false);
		}

	}

	public void VerifyUserIsnotAbleToEditMsg(String EMAIL) {

		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		try {
			Assert.assertTrue(verifyElementNotDisplayed("editComment", EMAIL));
			logMessage("[Assertion Passed]:: Other User not able to edit comment ");
			Assert.assertTrue(true);
		} catch (java.lang.AssertionError e) {
			logMessage("[Assertion Failed]:: Other User is able to edit comment");
			Assert.assertTrue(false);
		}
	}

	public void VerifyUserIsAbleToDeleteComment(String Email) {
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		try {
			isElementDisplayed("deleteComment", Email);
			clickUsingJS(element("deleteComment", Email));
			logMessage("User Is Able to delete Comment");
			Assert.assertTrue(true);
		} catch (java.lang.AssertionError e) {
			logMessage("[Assertion Failed]:: User is not able to delete comment");
			Assert.assertTrue(false);
		}

	}

	public void VerifyUserIsAbleToEditComment(String Email) throws IOException {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		isElementDisplayed("editComment", Email);
		clickUsingJS(element("editComment", Email));
		logMessage("User Is Able to edit Comment");
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();
		Random r = new Random();

		String CommentNo = PropFileHandler.readPropertyFromDataFile("CommentNoforContent");
		String Comment = "Test Comment Edit from Automated Script " + CommentNo + alphabet.charAt(r.nextInt(N));
		logMessage("Edit email Clicked...");

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("TextAreaForComment", Email);
		clickUsingJS(element("TextAreaForComment", Email));
		fillText(element("TextAreaForComment", Email), Comment);
		logMessage("Edited Comment Posted::" + Comment);
		isElementDisplayed("postEditedComment", Email);
		click(element("postEditedComment", Email));
		logMessage(" post Edited Comment Button clicked");
		CommentNo = Integer.toString(Integer.parseInt(CommentNo) + 1);
		PropFileHandler.writePropertyToDataFile("CommentNoforContent", CommentNo);
		wait.waitForPageToLoadCompletely();
		refreshPage();
		waitForLoaderToDisappear();
		scrollToBottom();
		isElementDisplayed("VerifyComment", Comment);
		scroll(element("VerifyComment", Comment));
		wait.waitForPageToLoadCompletely();
		logMessage("Follwoing comment is displayed::" + Comment);
	}

	public void VerifyContentHistoryIsNotUpdated() {
		areElementsDisplayed("HisLatestDate");
		scroll(element("HisLatestDate"));
		String LatestDate = element("HisLatestDate").getAttribute("innerText");
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MM-dd-yyyy hh:mm");
		LocalDateTime now = LocalDateTime.now();
		String Tdate = dtf.format(now);
		System.out.println("Today's Date and Time is::" + Tdate);
		logMessage("Latest Date And Time Of History Table::" + LatestDate);
		Assert.assertFalse(Tdate.equals(LatestDate), "[Assertion Failed]:: Content History Table Is Updated");
		logMessage("[Assertion Passed]:: Content History Table Is  Not Updated");

	}

	public void VerifyFirstRadioButtonAndToolTip() {
		isElementDisplayed("TypeOfcontentToPublish", "Publish ePub only");
		logMessage("'Publish content links and ePub' Input Is Displayed..");

		isElementDisplayed("ToolTipsForRadio", "Publish ePub only");
		logMessage("'Publish content links and ePub' ToolTip Is Displayed..");

	}

	public void clickFirstToolTipAndVerifyOutputOnPlatform(String Platform) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ToolTipsForRadio", "Publish content links and ePub");
		hoverClick(element("ToolTipsForRadio", "Publish content links and ePub"));
		logMessage("'Publish content links and ePub' ToolTip Is Clicked..");

		isElementDisplayed("ToolTipsInfo");
		isElementDisplayed("ToolTipsInfo");
		String MSGDispalyed = element("ToolTipsForRadio", "Publish content links and ePub")
				.getAttribute("uib-popover-html");
		logMessage(MSGDispalyed + " Is Displayed...");

		Assert.assertTrue(MSGDispalyed.equals(
				"'CMS sends CFI content links to Courseware and publishes ePub to " + Platform + " with this action.'"),
				"[Assertion Failed]:: Incorrect Tool Tip Is Displayed");
		logMessage("[Assertion passed]:: Correct Tool Tip Is Displayed");
	}

	public void VerifySecondRadioButtonAndToolTip() {
		isElementDisplayed("TypeOfcontentToPublish", "Publish content links only");
		logMessage("'Publish content links only' Input Is Displayed..");

		isElementDisplayed("ToolTipsForRadio", "Publish content links only");
		logMessage("'Publish content links and ePub' ToolTip Is Displayed..");

	}

	public void clickSecondToolTipAndVerifyOutput() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ToolTipsForRadio", "Publish content links only");
		hoverClick(element("ToolTipsForRadio", "Publish content links only"));
		logMessage("'Publish content links and ePub' ToolTip Is Clicked..");

		isElementDisplayed("ToolTipsInfo");
		String MSGDispalyed = element("ToolTipsForRadio", "Publish content links only")
				.getAttribute("uib-popover-html");
		logMessage(MSGDispalyed + " Is Displayed...");

		Assert.assertTrue(MSGDispalyed.equals("'CMS sends CFI content links to Courseware with this action.'"),
				"[Assertion Failed]:: Incorrect Tool Tip Is Displayed");
		logMessage("[Assertion passed]:: Correct Tool Tip Is Displayed");

	}

	public void VerifyThirdRadioButtonAndToolTip() {
		isElementDisplayed("TypeOfcontentToPublish", "Publish ePub only");
		logMessage("'Publish ePub only' Input Is Displayed..");

		isElementDisplayed("ToolTipsForRadio", "Publish ePub only");
		logMessage("'Publish ePub only' ToolTip Is Displayed..");

	}

	public void clickThirdToolTipAndVerifyOutputOnPlatfrom(String Platform) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ToolTipsForRadio", "Publish ePub only");
		hoverClick(element("ToolTipsForRadio", "Publish ePub only"));
		logMessage("'Publish ePub only' ToolTip Is Clicked..");

		isElementDisplayed("ToolTipsInfo");
		String MSGDispalyed = element("ToolTipsForRadio", "Publish ePub only").getAttribute("uib-popover-html");
		logMessage(MSGDispalyed + " Is Displayed...");

		Assert.assertTrue(MSGDispalyed.equals("'CMS publishes ePub to " + Platform + " with this action.'"),
				"[Assertion Failed]:: Incorrect Tool Tip Is Displayed");
		logMessage("[Assertion passed]:: Correct Tool Tip Is Displayed");
	}

	public void clickVersionDetails() {
		isElementDisplayed("SubTab", "Version Details");
		logMessage("Version Details Is displayed");
		click(element("SubTab", "Version Details"));
		logMessage("Version Detail Tab Clicked...");

	}

	public void VerifyDeleteButtonInVersionDetailTab() {
		isElementDisplayed("VersionOperation", "Delete Version");
		logMessage("Delete Version Button Is Displayed..");
	}

	public void VerifyVersionDetailDeleteButtonDisabled() {
		String Class;
		isElementDisplayed("VersionOperation", "Delete Version");
		Class = element("VersionOperation", "Delete Version").getAttribute("class");
		Assert.assertTrue(Class.contains("disable-btn"),
				"[Asserion Failed]:: Delete Button Enabled In Version Detail Tab");
		logMessage("[Asserion Passed]:: Delete Button Disabled In Version Detail Tab");
	}

	public void SelectMultipleVersionOnDetailVersionTab() {
		areElementsDisplayed("SelectMultiVersion");
		List<WebElement> VersionList = elements("SelectMultiVersion");
		if (VersionList.size() <= 1) {
			logMessage("The Detail Version Tab Has" + VersionList.size()
					+ " Version, So Can Not Select The Multiple Version In Detail Version Tab");
		} else {
			for (int i = 0; i < VersionList.size(); i++) {
				wait.hardWait(1);
				VersionList.get(i).click();
				logMessage("Version " + (i + 1) + " Is Selected...");
			}
		}
	}

	public void SelectSingleVersionOnDetailVersionTab() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectVersion");
		clickUsingJS(element("SelectVersion"));
		logMessage("Version Selected..");
	}

	public void ClickDeleteButtonOnVerTab() {
		isElementDisplayed("VersionOperation", "Delete Version");
		clickUsingJS(element("VersionOperation", "Delete Version"));
		logMessage("Delete Version Button Clicked..s");
	}

	public void VerifyDeleteVersionPopUp() {
		isElementDisplayed("DeleteVerLabel");
		isElementDisplayed("DeleteVerLabel");
		logMessage("Delete Version Pop Up Displayed...");

	}

	public void VerifyHyperLinkDisabledInPushToAuthoringTool() {
		isElementDisplayed("ContentImage");
		logMessage("Content Image is Displayed....");

		isElementDisplayed("ContentImage");
		logMessage("Content Title is Displayed....");

		clickUsingJS(element("ContentImage"));
		logMessage("Content Image Clicked..");
		wait.waitForPageToLoadCompletely();
		VerifyPushToAuthoringToolPopUp();
		logMessage("[Assertion Passed]::Content Image Does Not Navigates to Content View");

		clickUsingJS(element("ContentTitle"));
		logMessage("Content Title Clicked..");
		wait.waitForPageToLoadCompletely();
		VerifyPushToAuthoringToolPopUp();
		logMessage("[Assertion Passed]::Content Title Dows Not Navigates to Content View");

	}

	public void VerifyStep3LabelOfPushToAuthoringTool() {
		isElementDisplayed("Step3Label");
		logMessage("[Assertion Passed]:: Correct Label Displayed!!!  Label Displayed::Step 3: Select Project ISBN");

	}

	public void VerifyStep3LabelOfPushToAuthoringToolNotDisplayed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertFalse(element("Step3Label").isDisplayed(),
				"[Assertion Failed]:: Label Displayed::Step 3: Select Project ISBN is Displayed");
		logMessage("[Assertion Passed]:: Label Displayed::Step 3: Select Project ISBN is Not Displayed");

	}

	public void SelectDamContentAndPublishUnApproved(String nonCms) {
		isElementDisplayed("checkInstructor", nonCms);
		clickUsingJS(element("checkInstructor", nonCms));
		logMessage(nonCms + " asset selected to publish");
		isElementDisplayed("UnapproveButton");
		clickUsingJS(element("UnapproveButton"));
		logMessage("Unapprove button clicked");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("contentPublish");
		clickUsingJS(element("contentPublish"));
		logMessage("Publish button clicked");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("PublishMSG");
		Assert.assertTrue(element("PublishMSG").getAttribute("innerText").equals("No assets to publish!"),
				"[Assertion Failed]: Content was publish");
		logMessage("[Assertion Passed]: Content was not Published!!!!, Message Displayed:: 'No assets to publish!'");
		refreshPage();
		waitForLoaderToDisappear();
	}

	public void clickLearningObjectives() {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("SubTab", "Learning Objectives");
		clickUsingJS(element("SubTab", "Learning Objectives"));
		logMessage("'Learning Objectives' is clicked....");
	}

	public void clickContentDetailTab() {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("SubTab", "Content Details");
		clickUsingJS(element("SubTab", "Content Details"));
		logMessage("'Content Details' is clicked....");
	}

	public void RemoveFameworkFromContent(String Framework) {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		if (BoolenIsElementDisplayed("RemoveFrameWork", Framework)) {
			isElementDisplayed("RemoveFrameWork", Framework);
			click(element("RemoveFrameWork", Framework));
			logMessage(Framework + " Is already Added to the Content..");
			logMessage("Delete Button Is Clicked, to delete the Framework....");
			VerifyMessageDispalyedOnRemovingFamework();
		} else {
			logMessage(Framework + " Is Not Added to the Content So Can Not Be Removed..");
		}

	}

	public void RemoveFameworkFromContentWithoutMessage(String Framework) {
		isElementDisplayed("RemoveFrameWork", Framework);
		wait.waitForPageToLoadCompletely();
		click(element("RemoveFrameWork", Framework));
		logMessage(Framework + " Is already Added to the Content..");
		logMessage("Delete Button Is Clicked, to delete the Framework....");
	}

	public void VerifyFrameWorkIsAddedToTheContent(String Framework) {
		isElementDisplayed("RemoveFrameWork", Framework);
		logMessage(Framework + " Is Added to the Content..");
	}

	public void AddLearningObjective(String Framework) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("LOSearchBar");
		clickUsingJS(element("LOSearchBar"));
		fillText("LOSearchBar", Framework);
		wait.hardWait(1);
		element("LOSearchBar").sendKeys(Keys.BACK_SPACE);
		isElementDisplayed("suggestionBox");
		logMessage("Suggesation Box is Displayed...");
		isElementDisplayed("SelectFrameWork", Framework);
		logMessage(Framework + " is Displayed...");
		wait.hardWait(1);
		clickUsingJS(element("SelectFrameWork", Framework));
		logMessage(Framework + " is Clicked...");
		isElementDisplayed("LOAddButton");
		wait.hardWait(1);
		VerifyLOF_AddButtonEnable();
		clickUsingJS(element("LOAddButton"));
		logMessage("ADD Button Is Clicked...");
	}

	public void VerifyFrameworkAddedMessageDisplayed() {
		isElementDisplayed("LOMessage", "Framework added to the Content");
		logMessage("Correct Message Is Displayed::'Framework added to the Content'");
	}

	public void VerifyFrameworkCanNotBeRemovedMessageIsDisplayed() {
		isElementDisplayed("LOMessage",
				"The Learning Objective Framework cannot be deleted. There are Learning Objective Statements associated to this content.");
		logMessage(
				"Correct Message Is Displayed::'You can not delete a framework if some LO statements are associated.'");
	}

	public void SelectFramework(String Framework) {
		isElementDisplayed("LOSearchBar");
		fillText("LOSearchBar", Framework);
		isElementDisplayed("suggestionBox");
		logMessage("Suggesation Box is Displayed...");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectFrameWork", Framework);
		logMessage(Framework + " is Displayed...");
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("SelectFrameWork", Framework));
		logMessage(Framework + " is Clicked...");
	}

	public void AddButtonOnLearningObjectiveIsDisabled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("LOAddButton");
		String Attri = element("LOAddButton").getAttribute("disabled").trim();
		Assert.assertTrue(Attri.equalsIgnoreCase("true"), "[Assertion Failed]:: User is able to Add Framework again");
		logMessage("[Assertion Passed]:: User is Not able to Add Framework again");
	}

	public void AddLearningObjectiveStatement(String LOS_Statement) {
		isElementDisplayed("LOSsearchBar");
		clickUsingJS(element("LOSsearchBar"));
		wait.hardWait(3);
		fillText("LOSsearchBar", Keys.chord(LOS_Statement));
		wait.waitForPageToLoadCompletely();
		element("LOSsearchBar").sendKeys(Keys.BACK_SPACE);
		wait.hardWait(1);
		element("LOSsearchBar").sendKeys(Keys.BACK_SPACE);
		wait.hardWait(1);
		element("LOSsearchBar").sendKeys(Keys.BACK_SPACE);

		isElementDisplayed("suggestionBox");
		logMessage("Seggesation Box Displayed...");
		isElementDisplayed("SelectLOS", LOS_Statement);
		wait.hardWait(1);
		clickUsingJS(element("SelectLOS", LOS_Statement));
		logMessage("'" + LOS_Statement + "' is selected...");
		wait.hardWait(1);
		isElementDisplayed("LOSAddButton");
		click(element("LOSAddButton"));
		logMessage("Add Button Clicked...");
	}

	public void VerifyLearningObjectiveStatementIsDisplayedInsuggestion(String LOS_Statement) {
		isElementDisplayed("LOSsearchBar");
		fillText("LOSsearchBar", Keys.chord(LOS_Statement));
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("suggestionBox");
		logMessage("Seggesation Box Displayed...");
		isElementDisplayed("SelectLOS", LOS_Statement);
		logMessage("'" + LOS_Statement + "' is Displayed...");
		wait.hardWait(1);
	}

	public void VerifyLearningObjectiveStatementAdded(String Statement) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("RemoveLOS", Statement);
		logMessage(Statement + " is Added...");

	}

	public void RemoveLOS_Statement(String Statement) {
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		if (BoolenIsElementDisplayed("RemoveLOS", Statement)) {
			clickUsingJS(element("RemoveLOS", Statement));
			logMessage("Delete Button For the LOS Statement is displayed....");
			logMessage("Delete Button Clicked...");
			logMessage(Statement + " LOS deleted..");
			wait.resetImplicitTimeout(wait.timeout);
		} else {
			logMessage("Learning object Statement already removed...");
		}

	}

	public void VerifyUserIsNotAbleToAdd_LOS(String LOS_Statement) {
		try {
			Assert.assertTrue(verifyElementNotDisplayed("LOSSection"));
			logMessage("User is not Able To Added LOS Statement");
			Assert.assertTrue(true);
		} catch (java.lang.AssertionError exc) {
			isElementDisplayed("LOSsearchBar");
			fillText("LOSsearchBar", LOS_Statement);
			element("LOSsearchBar", LOS_Statement).sendKeys(Keys.BACK_SPACE);
			wait.waitForPageToLoadCompletely();
			element("LOSsearchBar", LOS_Statement).sendKeys(Keys.BACK_SPACE);
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("suggestionBox");
			logMessage("Seggesation Box Displayed...");
			Assert.assertTrue(verifyElementNotDisplayed("SelectLOS", LOS_Statement));
			logMessage("[Assertion Passed]:: User is not able to Added LOS Statement");
		}
	}

	public void VerifyMessageDispalyedOnAddingLearningObjectiveStatement() {
		isElementDisplayed("LOMessage", "Statement added to the Content");
		logMessage("Correct Message Is Displayed::'Statement added to the Content'");

	}

	public void VerifyMessageDispalyedOnRemovingLearningObjectiveStatement() {
		isElementDisplayed("LOMessage", "Statement removed from the Content");
		logMessage("Correct Message Is Displayed::'Statement removed from the Content'");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyDoneButtonOnLearningObjectiveTab() {
		isElementDisplayed("DoneButton");
		logMessage("'Done' Button is Displayed..");
	}

	public void ClickDoneButtonOnLearningObjectiveTab() {
		isElementDisplayed("DoneButton");
		click(element("DoneButton"));
		logMessage("'Done' Button Clicked..");
	}

	public void VerifyMessageDispalyedOnRemovingFamework() {
		isElementDisplayed("LOMessage", "Framework removed from the Content");
		logMessage("Correct Message Is Displayed::'Framework removed from the Content'");
	}

	public void VerifyISBNColoumRenamed() {
		isElementDisplayed("IsbnRenamed");
		String NewName = element("IsbnRenamed").getAttribute("innerText").trim();
		logMessage("Expected::Published Project ISBN");
		logMessage("Displayed::" + NewName);
		Assert.assertTrue(NewName.equals("Published Project ISBN"),
				"[Assertion Failed]:: In Correct coloum Name::" + NewName);
		logMessage("[Assertion Passed]:: Correct coloum Name::" + NewName);

	}

	public void VerifyISBN_Not_Displayed_On_PublishDetail() {

		String ISBN_Displayed = element("PublishDestinationBlank").getAttribute("innerText").trim();
		logMessage("Expected:: Blank Field Should Be Displayed..");
		if (ISBN_Displayed.equalsIgnoreCase("") || ISBN_Displayed == null) {
			logMessage("[Assertion Passed]: No ISBN is Displayed...");
		}

		else {
			Assert.assertTrue(false, "[Assertion Failed]: Some Text is Displayed::" + ISBN_Displayed);
		}
	}

	public void VerifyLearningObjectiveTabDisplayed() {
		isElementDisplayed("SubTab", "Learning Objectives");
		logMessage("Learning Objective tab is displayed...");
	}

	public void VerifyContentDetailsTabDisplayed() {
		isElementDisplayed("SubTab", "Content Details");
		logMessage("Content Details tab is displayed...");
	}

	public void VerifyVersionDetailTabNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("SubTab", "Version Details"),
				"[Assertion Failed]::'Version Detail Tab is Displayed..'");
	}

	public void VerifyPublishDetailsTabNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("SubTab", "Publish Details"),
				"[Assertion Failed]::'Publish Details Tab is Displayed..'");
	}

	public void VerifySearchBoxDisplayedForLO() {
		isElementDisplayed("LOSearchBar");
		logMessage("Search Box for Learning Objective is Displayed...");
	}

	public void VerifyFrameWorkTableIsDisplayed() {
		isElementDisplayed("LOtable");
		logMessage("Framework table is displayed..");

	}

	public void VerifyFrameworkHeaderIsDisplayed() {
		areElementsDisplayed("LOTableHearder", "Framework Name");
		logMessage("'Framework Name' is Displayed..");

		areElementsDisplayed("LOTableHearder", "Action");
		logMessage("'Action' is Displayed..");
	}

	public void EnterTextIntoLOF_SearchBox(String Text) {
		wait.hardWait(1);
		isElementDisplayed("LOSearchBar");
		clickUsingJS(element("LOSearchBar"));
		wait.hardWait(1);
		fillText("LOSearchBar", Text);
	}

	public void Verify_Count_Of_Framework_Displayed_In_SuggestionBox(String ExpectedCount) {
		areElementsDisplayed("SuggestionFrameWork");
		List<WebElement> ListFramework = elements("SuggestionFrameWork");
		logMessage("Expected  Count of FrameWork on Suggestion Box::" + ExpectedCount);
		logMessage("Displayed Count of FrameWork on Suggestion Box::" + ListFramework.size());
		Assert.assertEquals(ExpectedCount, ListFramework.size(),
				"[Assertion Failed]:: Incorrect Count of Framework Displayed");
	}

	public void ClickCrossIconOnLOF_SearchBox() {
		isElementDisplayed("LOSearchBar");
		String text = element("LOSearchBar").getAttribute("value");
		logMessage("Text Displayed Before Clickcing 'X' icon::" + text);

		isElementDisplayed("Xicon");
		clickUsingJS(element("Xicon"));
		logMessage("'X' icon is Clicked...");
		wait.hardWait(1);
		text = element("LOSearchBar").getAttribute("value");
		logMessage("Text Displayed After Clickcing 'X' icon::" + text);
		if (text.equals("")) {
			logMessage("[Assertion Passed]:: the Text Box is Cleared...");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: The Text Box is not Cleared...");
		}
	}

	public void VerifyLOF_AddButtonDisabled() {
		String Attribute = element("LOAddButton").getAttribute("disabled");
		if (Attribute.equals("true")) {
			logMessage("[Assertion Passed]:: ADD Button Is Disabled..");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: ADD Button Is Enabled..");
		}

	}

	public void ClickAddButtonOnLOF() {
		isElementDisplayed("LOAddButton");
		hoverOverElement(element("LOAddButton"));
		click(element("LOAddButton"));
		logMessage("Clicked ADD button  ");
	}

	public void SelectTheFrameWorkFromSuggestionBox(String Framework) {
		isElementDisplayed("LOSearchBar");
		logMessage("Framewor::" + Framework);
		fillText("LOSearchBar", Framework);
		isElementDisplayed("suggestionBox");
		logMessage("Suggesation Box is Displayed...");
		wait.hardWait(1);
		isElementDisplayed("SelectFrameWork", Framework);
		logMessage(Framework + " is Displayed...");
		wait.hardWait(1);
		clickUsingJS(element("SelectFrameWork", Framework));
		logMessage(Framework + " is Clicked...");
	}

	public void VerifySuggesationBoxDisplayedIn_LOF_Section() {
		isElementDisplayed("suggestionBox");
		logMessage("Suggesation Box is Displayed...");
		wait.hardWait(1);
	}

	public void VerifyLOF_AddButtonEnable() {
		wait.hardWait(1);
		isElementDisplayed("LOAddButton");
		String Attribute = element("LOAddButton").getAttribute("disabled");
		if (Attribute == null) {
			logMessage("[Assertion Passed]:: ADD Button Is Enabled..");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: ADD Button Is Disabled..");
		}

	}

	public void LearningObjectiveFrameworkSectionIsDisplayed() {
		isElementDisplayed("LOFheader");
		logMessage("Learning Objective Framework Section is displayed...");

	}

	public void verifyLOS_SectionIsDisplayed() {
		isElementDisplayed("LOShearder");
		logMessage("Learning Objective Statement Section is displayed...");

	}

	public void RemoveAllLOS_ForContent() {
		wait.waitForPageToLoadCompletely();
		wait.resetImplicitTimeout(1);
		List<WebElement> DeleteButton = elements("RemoveAllStatement");
		wait.resetImplicitTimeout(wait.timeout);
		int size = DeleteButton.size();
		if (size == 0) {
			logMessage("There are No Learning Objective Statement Added...");
		}

		else {
			logMessage(size + " Stalements Are Displayed...");
			for (int i = 0; i < size; i++) {
				wait.hardWait(1);
				isElementDisplayed("DeleteStatementButton");
				// clickUsingJS(element("DeleteFrameWorkButton"));
				click(element("DeleteStatementButton"));
				logMessage("Delete Button Clicked...");
				VerifyMessageDispalyedOnRemovingLearningObjectiveStatement();
				wait.hardWait(1);
			}
		}
	}

	public void RemoveAllFrameWorkFromContent() {
		waitForPageToLoadCompletely(getPageTitle());
		wait.resetImplicitTimeout(1);
		List<WebElement> DeleteButton = elements("RemoveAllFrameWork");
		wait.resetImplicitTimeout(wait.timeout);
		int size = -1;
		size = DeleteButton.size();
		if (size == 0) {
			logMessage("There are No Learning Objective FrameWork Added...");
		} else if (size >= 1) {
			logMessage(size + " Framework are Displayed...");
			for (int i = 0; i < size; i++) {
				wait.waitForPageToLoadCompletely();
				isElementDisplayed("DeleteFrameWorkButton");
				click(element("DeleteFrameWorkButton"));
				logMessage("Delete Button Clicked...");
				VerifyMessageDispalyedOnRemovingFamework();
				wait.waitForPageToLoadCompletely();
				waitForLoaderToDisappear();
			}
		}
	}

	public void VerifyLOS_IsNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("LOSsearchBar"),
				"[Asseertion Failed]::earning Objective Statements is Displayed.");
		logMessage("Learning Objective Statements is Not Displayed...");
	}

	public void LevelsAreNotDisplayedInLOS(String LOS_Statement) {
		isElementDisplayed("LOSsearchBar");
		wait.hardWait(3);
		fillText("LOSsearchBar", Keys.chord(LOS_Statement));
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("suggestionBox");
		logMessage("Seggesation Box Displayed...");
		isElementDisplayed("SelectLOS", LOS_Statement);
		String Statement = element("SelectLOS", LOS_Statement).getAttribute("title");
		String Level = Statement.substring(0, 2).trim();
		if (Level.contains("L1") || Level.contains("L2") || Level.contains("L3")) {
			Assert.assertTrue(false, "[Assertion Failed]::Level are Displayed...");
		} else {
			logMessage("[Assertion Passed]::Level are Not Displayed...");
		}
	}

	public void VerifyLOS_TableHeaders() {
		isElementDisplayed("LOStableHeader", "Name");
		logMessage("'Name' is Displayed..");

		isElementDisplayed("LOStableHeader", "Domain");
		logMessage("'Domain' is Displayed..");

		isElementDisplayed("LOStableHeader", "Level");
		logMessage("'Level' is Displayed..");

		isElementDisplayed("LOStableHeader", "Action");
		logMessage("'Action' is Displayed..");

	}

	public void VerifyLearningObjectiveStatementIsNotDisplayed(String Statement) {
		refreshPage();
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		clickLearningObjectives();
		Assert.assertTrue(verifyElementNotDisplayed("RemoveLOS", Statement));
		logMessage("'" + Statement + "' is not Dispalyed...");
	}

	public void EnterTextInLOS_SearchBox(String Statement) {
		wait.hardWait(1);
		isElementDisplayed("LOSsearchBar");
		clickUsingJS(element("LOSsearchBar"));
		wait.hardWait(1);
		fillText("LOSsearchBar", Keys.chord(Statement));

	}

	public void ClickCrossIconOnLOS_SearchBox() {
		isElementDisplayed("LOSsearchBar");
		String text = element("LOSsearchBar").getAttribute("value");
		logMessage("Text Displayed Before Clickcing 'X' icon::" + text);

		isElementDisplayed("LOSxIcon");
		clickUsingJS(element("LOSxIcon"));
		logMessage("'X' icon is Clicked...");
		wait.hardWait(1);
		text = element("LOSearchBar").getAttribute("value");
		logMessage("Text Displayed After Clickcing 'X' icon::" + text);
		if (text.equals("")) {
			logMessage("[Assertion Passed]:: the Text Box is Cleared...");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: The Text Box is not Cleared...");
		}

	}

	public void VerifyLOS_AddButtonDisabled() {
		String Attribute = element("LOSAddButton").getAttribute("disabled");
		logMessage("Disable" + Attribute);
		if (Attribute.equals("true")) {
			logMessage("[Assertion Passed]:: ADD Button Is Disabled..");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: ADD Button Is Enabled..");
		}
	}

	public void VerifyLOS_AddButtonEnable() {
		wait.hardWait(1);
		String Attribute = element("LOSAddButton").getAttribute("disabled");
		if (Attribute == null) {
			Assert.assertTrue(true, "[Assertion Passed]:: ADD Button Is Enabled..");

		} else {
			logMessage("[Assertion Failed]:: ADD Button Is Disabled..");
			Assert.assertTrue(false);
		}
	}

	public void VerifySuggesationBoxDisplayedIn_LOS_Section() {
		wait.hardWait(1);
		isElementDisplayed("suggestionBox");
		logMessage("Seggesation Box Displayed...");

	}

	public void PressEnterOnLOF_Search() {
		isElementDisplayed("LOSsearchBar");
		isElementDisplayed("LOSsearchBar");
		clickUsingJS(element("LOSsearchBar"));
		element("LOSsearchBar").sendKeys(Keys.ENTER);
		logMessage("'ENTER' Pressed on Learning Objective tab...");
	}

	public void Verify_No_Message_Is_Displayed_On_Pressing_The_Enter() {
		PressEnterOnLOF_Search();
		Assert.assertTrue(verifyElementNotDisplayed("LOMessage", "added to the Project"));
		logMessage("Message on adding LOF Not Displayed..");
		PressEnterOnLOF_Search();
		VerifySuggesationBoxNotDisplayed();
		PressEnterOnLOF_Search();
		Assert.assertTrue(verifyElementNotDisplayed("LOMessage", "Statement removed from the Content"));
		logMessage("Message on Removing LOS Not Displayed..");
		PressEnterOnLOF_Search();
		Assert.assertTrue(verifyElementNotDisplayed("LOMessage", "Framework removed from the Content"));
		logMessage("Message on Removing LOF Not Displayed..");
		Assert.assertTrue(verifyElementNotDisplayed("LOMessage", "Statement added to the Content"));
		logMessage("Message on Adding LOS is not displayed..");
	}

	private void VerifySuggesationBoxNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("suggestionBox"),
				"[Assertion Failed]::suggestion Box is displayed");
		logMessage("suggestion Box is not displayed...");

	}

	public void VerifyWarningMessageDisplayedInLOFSection() {
		isElementDisplayed("WarnningMsg");
		String Text = element("WarnningMsg").getAttribute("innerText").trim();
		logMessage("Warrning Message Displayed::" + Text);
		Assert.assertTrue(Text.contains("No Results Found! for"),
				"[Assertion Failed]:: Warning Message Displayed::" + Text);
		logMessage("[Assertion Passed]:: Warning Message Displayed::" + Text);

	}

	public void VerifyNoDublicateFrameworkIsDisplayed() {
		waitForPageToLoadCompletely(getPageTitle());
		List<WebElement> Framework = elements("ListOfFrameWork");
		String FrameWorkDisplayed[] = new String[Framework.size()];
		for (int frame = 0; frame < Framework.size(); frame++) {
			FrameWorkDisplayed[frame] = Framework.get(frame).getAttribute("innerText").trim();
		}

		HashSet<String> set = new HashSet<String>();
		for (String arrayElement : FrameWorkDisplayed) {
			if (!set.add(arrayElement)) {
				Assert.assertTrue(false, "Duplicate FrameWork Displayed is : " + arrayElement);
			}
		}
		logMessage("No Dublicate FrameWork is Displayed");
	}

	public void VerifyContentSubtypeInContentView(String typesOfContentEnhancedEpub) {
		isElementDisplayed("ContentSubType");
		String ContentTypeDisplayed = element("ContentSubType").getAttribute("innerText").trim();
		Assert.assertTrue(ContentTypeDisplayed.equalsIgnoreCase(typesOfContentEnhancedEpub),
				"[Assertion Failed]:: Incorrect Content Type Displayed:" + ContentTypeDisplayed);
		logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeDisplayed);

	}

	public void VerifyContentTypeInPublishWindow(String typesOfContent) {
		isElementDisplayed("ContentTypeInPublishPopup");
		String ContentTypeDisplayed = element("ContentTypeInPublishPopup").getAttribute("innerText").trim();
		logMessage("Displayed::" + ContentTypeDisplayed);
		logMessage("Expected::" + typesOfContent);
		Assert.assertTrue(ContentTypeDisplayed.equalsIgnoreCase(typesOfContent),
				"[Assertion Failed]:: Incorrect Content Type Displayed:" + ContentTypeDisplayed);
		logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeDisplayed);
	}

	public void VerifyContentSubtypeInPushToAuthoringToolGridView(String ContentType) {
		if (ContentType.length() >= 20) {
			ContentType = ContentType.substring(0, 17);
		}
		isElementDisplayed("ContentTypeInAuthoringtool", ContentType);
		String ContentTypeDisplayed = element("ContentTypeInAuthoringtool", ContentType).getAttribute("innerText")
				.trim();
		logMessage("Expected::" + ContentType);
		logMessage("Displayed::" + element("ContentTypeInAuthoringtool", ContentType).getAttribute("innerText").trim());
		Assert.assertTrue(ContentTypeDisplayed.contains(ContentType),
				"[Assertion Failed]:: Incorrect Content Type Displayed:" + ContentTypeDisplayed);
		logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeDisplayed);

	}

	public void VerifyContentSubtypeInPushToAuthoringToolListView(String ContentType) {
		String ContentTypeDisplayed;
		isElementDisplayed("ContentTypeInAuthoringtoolListView");
		ContentTypeDisplayed = element("ContentTypeInAuthoringtoolListView").getAttribute("uib-tooltip");
		if (ContentTypeDisplayed == null) {
			ContentTypeDisplayed = element("ContentTypeInAuthoringtoolListView").getAttribute("innerText").trim();
		}

		logMessage("Expected::" + ContentType);
		logMessage("Displayed::" + ContentTypeDisplayed);
		Assert.assertTrue(ContentTypeDisplayed.contains(ContentType),
				"[Assertion Failed]:: Incorrect Content Type Displayed:" + ContentTypeDisplayed);
		logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeDisplayed);

	}

	public void ClickCloseIconOnPushToAuthoringTool() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("xButton");
		hover(element("xButton"));
		wait.hardWait(1);
		element("xButton").click();
		logMessage("x icon Clicked...");
	}

	public void ClickX_OnWindow() {
		isElementDisplayed("xButton");
		wait.waitForPageToLoadCompletely();
		hoverOverElement(element("xButton"));
		click(element("xButton"));
		logMessage("x icon Clicked...");
	}

	public void ClickCloseOnpublishPopup() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("xButton");
		hover(element("xButton"));
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		click(element("xButton"));
		logMessage("x icon Clicked...");
	}

	public void VerifyUserNotAbleToEditCommentWithoutClickingEditIcon(String Email) {
		scrollToBottom();
		isElementDisplayed("TextAreaForComment", Email);
		click(element("TextAreaForComment", Email));

		String Attri = element("TextAreaForComment", Email).getAttribute("disabled");
		if (Attri.equals("true")) {
			logMessage("[Assertion Passed]:: Text Area is disabled user can not edit the comment..");
		} else {
			logMessage("[Assertion Failed]:: Text Area is Enabled user can Edit the comment..");
			Assert.assertTrue(false);
		}

		isElementDisplayed("editComment", Email);
		clickUsingJS(element("editComment", Email));
		logMessage("Edit Button is clicked....");

		String Attri1 = element("TextAreaForComment", Email).getAttribute("disabled");
		if (Attri1 == null) {
			logMessage("[Assertion Passed]:: Text Area is Enabled user is able To edit the comment..");
		} else {
			logMessage("[Assertion Failed]:: Text Area is Disabled user can not Edit the comment..");
			Assert.assertTrue(false);
		}

	}

	public void VerifyClickingOutsideChangesAreNotSaved(String Email) {
		isElementDisplayed("editComment", Email);
		clickUsingJS(element("editComment", Email));
		logMessage("Edit Button is clicked....");

		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();
		Random r = new Random();

		String CommentNo = PropFileHandler.readPropertyFromDataFile("CommentNoforContent");
		String Comment = "Test Comment Edit from Automated Script " + CommentNo + alphabet.charAt(r.nextInt(N));

		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		fillText("CommentArea", Comment);

		clickUsingJS(element("CommentLabel")); // Click out side the Comment
												// Box..

		isElementDisplayed("postEditedComment", Email);

		String Attri1 = element("TextAreaForComment", Email).getAttribute("disabled");
		if (Attri1 == null) {
			logMessage("[Assertion Passed]:: Text Area is Enabled user is able To edit the comment..");
		} else {
			logMessage("[Assertion Failed]:: Text Area is Disabled Clicking Out Side the Window Saves the comment..");
			Assert.assertTrue(false);
		}

	}

	public void ClickSelectAllCheckBoxOnSelectedPane() {
		wait.hardWait(1);
		isElementDisplayed("SelectedPaneSelectAll");
		clickUsingJS(element("SelectedPaneSelectAll"));
		logMessage("Select All Clicked...");
	}

	public void ClickSelectAllCheckBoxOnAvailablePane() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AvailablePaneSelectAll");
		clickUsingJS(element("AvailablePaneSelectAll"));
		logMessage("Select All Clicked...");
	}

	public void VerifyNoProjectDisplayedInSelectedPane() {
		Assert.assertTrue(verifyElementNotDisplayed("projectDisplayedOnSelectedPane"),
				"[Assertion Failed]::All Project are not Removed from Selected Pane");
		logMessage("All Project Removed from Selected Pane...");
	}

	public void NavigateToPageNumberInAvailablePane(String PageNumber) {
		isElementDisplayed("NavigateInAvailablePane", PageNumber);
		click(element("NavigateInAvailablePane", PageNumber));
		logMessage("User Navigated to Page::" + PageNumber);
	}

	public void NavigateToPageNumberInSelectedPane(String PageNumber) {
		isElementDisplayed("NavigateInSelectedPane", PageNumber);
		click(element("NavigateInSelectedPane", PageNumber));
		logMessage("User Navigated to Page::" + PageNumber);

	}

	public void VerifyPaginationIsUpdatedAsProjectsRemovedFromSelectedPane() {
		areElementsDisplayed("NumberOfpagesInSelectedPane");
		List<WebElement> pages = elements("NumberOfpagesInSelectedPane");
		int pageNumber = pages.size();

		ClickSelectAllCheckBoxOnSelectedPane();
		ClickUnselectButton();

		List<WebElement> pages2 = elements("NumberOfpagesInSelectedPane");
		logMessage("Number of pages previous::" + pageNumber);
		logMessage("Page Number After Unselect::" + pages2.size());
		if (pageNumber > pages2.size()) {
			logMessage("Pagination Is Updated As Projects Removed From Selected Pane");

		} else {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Pagination Is  not Updated As Projects Removed From Selected Pane");
		}

	}

	public void VerifyColoumOfUsageDetailPopUp() {
		isElementDisplayed("ProjectAssociationColoum", "ISBN");
		logMessage("'ISBN' is Displayed..");

		isElementDisplayed("ProjectAssociationColoum", "Author");
		logMessage("'Author' is Displayed..");

		isElementDisplayed("ProjectAssociationColoum", "Title");
		logMessage("'Title' is Displayed..");

		isElementDisplayed("ProjectAssociationColoum", "Edition");
		logMessage("'Edition' is Displayed..");

		isElementDisplayed("ProjectAssociationColoum", "Copyright Year");
		logMessage("'Copyright Year' is Displayed..");

		isElementDisplayed("ProjectAssociationColoum", "Version Type");
		logMessage("'Version Type' is Displayed..");

		isElementDisplayed("ProjectAssociationColoum", "CMS Project Status");
		logMessage("'CMS Project Status' is Displayed..");

		isElementDisplayed("ProjectAssociationColoum", "Publication Status");
		logMessage("'Publication Status' is Displayed..");
	}

	public void VerifyFileNameIsAuthorKey(String authorId) {
		isElementDisplayed("SystemMetaData", "Filename:");
		String FileName = element("SystemMetaData", "Filename:").getAttribute("innerText");
		logMessage("File Name Displayed::" + FileName);
		logMessage("File Name Expected::" + (authorId + ".jpg"));
		Assert.assertTrue(FileName.equals((authorId + ".jpg")),
				"[Assertion Failed]:: Incorrect File Nmae Is Displayed " + FileName);
		logMessage("[Assertion Passed]:: Correct File Nmae Is Displayed " + FileName);
	}

	public void VerifyAuthorImageInStep2PublishWindow() {
		isElementDisplayed("Step2AuhorImg");
		wait.waitForPageToLoadCompletely();
		wait.hardWait(4);
		String src = element("Step2AuhorImg").getAttribute("src");
		isAttribtueNotPresent(element("Step2AuhorImg"), "src");
		if (src.contains("img/blank")) {
			assertTrue(false, "Author Image not Displayed in Step 2 Publish Window.");
		}
		logMessage("Author image is displayed in Step 2 of Publish window.");

	}

	public void VerifyAuthorNameAndIdInStep2PublishWindow(String AuthorNameAndIDExpected) {
		AuthorNameAndIDExpected = ("Author Name: " + AuthorNameAndIDExpected);
		isElementDisplayed("Step2AuthorDetail");
		String AuthorNameId = element("Step2AuthorDetail").getAttribute("innerText");
		logMessage("Author Detail Displayed::" + AuthorNameId);
		logMessage("Author Detail Expected::" + AuthorNameAndIDExpected);
		Assert.assertTrue(AuthorNameAndIDExpected.equals(AuthorNameId),
				"[Assertion Failed]:: Incorrect Auhor Name And ID:" + AuthorNameId);
		logMessage("[Assertion Passed]:: Correct Auhor Name And ID:" + AuthorNameId);
	}

	public void VerifyAuthorNameAndIdInStep2PublishWindow() {
		isElementDisplayed("Step2AuthorDetail");
		String AuthorNameId = element("Step2AuthorDetail").getAttribute("innerText").trim();
		if (AuthorNameId.length() == 0 || AuthorNameId == null) {
			Assert.assertFalse(false, "Author Name and id nort displayed..");
		}
		logMessage("Author Detail Displayed::" + AuthorNameId);
	}

	public void VerifyPublishStatusofTheContent(String AssetName) {
		logMessage("");
		logMessage("**Checking Asset '" + AssetName + "' For Published Status**");
		logMessage("");
		LocalDateTime ldt = LocalDateTime.now();
		String TodaysDate = DateTimeFormatter.ofPattern("MM-dd-yyyy", Locale.ENGLISH).format(ldt);
		logMessage("Checking Publish Status on Date::" + TodaysDate);
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		wait.hardWait(1);
		wait.resetImplicitTimeout(1);
		List<WebElement> AssetPublished = elements("PublishStatus", TodaysDate);
		wait.resetImplicitTimeout(wait.timeout);
		int Count = AssetPublished.size();
		if (Count <= 0) {
			logMessage("");
			logMessage("***********Asset '" + AssetName + "' is Not Published*********");
			logMessage("");
		} else {
			for (int i = 0; i < Count; i++) {
				String Status = AssetPublished.get(i).getAttribute("innerText");
				logMessage("Status of Publish::" + Status);
				if (Status.equalsIgnoreCase("Complete") || Status.equalsIgnoreCase("Success")) {
					logMessage("Asset is published Successfuly...");
				} else {
					Assert.assertTrue(false, "Asset is not published, Current Status::" + Status + " Displayed.");
				}
			}
		}

	}

	public void NavigateToPageNoInPublishDetail(int PageNo) {
		wait.hardWait(2);
		wait.resetImplicitTimeout(1);
		try {
			isElementDisplayed("NavigateToPage", PageNo + "");
		} catch (java.lang.AssertionError exc) {
			logMessage("PaginationBar Is not Appering At thr bottom of the Publish Detail Table");
			wait.resetImplicitTimeout(wait.getTimeout());
			return;
		}
		isElementDisplayed("NavigateToPage", PageNo + "");
		clickUsingJS(element("NavigateToPage", PageNo + ""));
		logMessage("User Navigated to " + PageNo + " Page");
		wait.hardWait(3);
		wait.resetImplicitTimeout(wait.getTimeout());
	}

	public void VerifyPublishProjectISBN_Header() {
		isElementDisplayed("PublishedProjectISBN_Header", "ISBN");
		isElementDisplayed("PublishedProjectISBN_Header", "ISBN-10");
		isElementDisplayed("PublishedProjectISBN_Header", "Author");
		isElementDisplayed("PublishedProjectISBN_Header", "Title");
		isElementDisplayed("PublishedProjectISBN_Header", "Edition");
		isElementDisplayed("PublishedProjectISBN_Header", "Copyright Year");
	}

	public void VerifyToolTipsOnAuthoringToolGrid() {
		areElementsDisplayed("ToolTipsOnPushAuthoringToolGrid");
		List<WebElement> tooltips = elements("ToolTipsOnPushAuthoringToolGrid");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			wait.hardWait(1);
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}
	}

	public void VerifyToolTipsOnAuthoringToolList() {
		areElementsDisplayed("ToolTipsOnPushAuthoringToolList");
		List<WebElement> tooltips = elements("ToolTipsOnPushAuthoringToolList");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			wait.hardWait(1);
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}
	}

	public void VerifyToolTipsOnPublishWindow() {
		List<WebElement> tooltips = elements("ToolTipsOnPublishWindow");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			wait.hardWait(1);
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}
	}

	public void VerifyPublishDestinationOnPublishPopIsDisabled() {
		isElementDisplayed("destination");
		isElementDisplayed("destination");
		String Attri = element("destination").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Failed]:: Destination DropDown Is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]:: Destination DropDown Disabled...");
		}

	}

	public void VerifyPublishDestinationOnPublishPopIsEnabled() {
		isElementDisplayed("destination");
		isElementDisplayed("destination");
		String Attri = element("destination").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Destination DropDown Is Enabled...");

		} else {
			logMessage("[Assertion Failed]:: Destination DropDown Disabled...");
			Assert.assertTrue(false);
		}

	}

	public void VerifySelectRadioButtonOnPublishPopUp() {
		isElementDisplayed("SelectedRadioButton");
		if (element("SelectedRadioButton").isSelected()) {
			logMessage("[Assertion Passed]:: Radio button is Selected..");
		} else {
			logMessage("[Assertion Failed]:: Radio button is Not Selected..");
		}
	}

	public void VerifyFileNameOnStep2PublishWindow(String FileNameExpected) {
		// isElementDisplayed("FileNameOnPublishWindow",FileNameExpected);
		String FileName = element("FileNameOnPublishWindow").getText().trim();
		logMessage("Expected::" + FileNameExpected);
		logMessage("Displayed::" + FileName);
		if (FileName.equals(FileNameExpected)) {
			logMessage(FileNameExpected = " is displayed..");

		} else {
			Assert.assertTrue(false, FileNameExpected = " is not displayed...");
		}
	}

	public void VerifyOnRightPlatformApplication() {
		wait.hardWait(1);
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("RightPlatformHeader");
		logMessage("User is on Right Platform Application.");

	}

	public void VerifyAssetIDOnRightPlatform(String AssetID) {
		isElementDisplayed("RP_AssetID");
		String AssetID_Displayed = element("RP_AssetID").getAttribute("innerText").trim();
		logMessage("Asset ID Displayed::" + AssetID_Displayed);
		logMessage("Asset ID Expected::" + AssetID);
		Assert.assertTrue(AssetID_Displayed.equals(AssetID),
				"[Assertion Failed]:: Incorrect AssetID::" + AssetID_Displayed);

	}

	public void VerifyAssetDB_Key_And_PNF(String dBKey, String PNF) {
		isElementDisplayed("RP_AssetDB_PNF", dBKey);
		logMessage("Asset DB ID::" + dBKey);
		isElementDisplayed("RP_AssetDB_PNF", PNF);
		logMessage("Asset PFN::" + PNF);
	}

	public void VerifyMessageWhileRightsDetailsAreOpening() {
		areElementsDisplayed("RP_OpeningMessage");
		logMessage("'Rerouting to Lumina to view the Rights Details' message is displayed.");
	}

	public void VerifyAssetURLLinkInPublishDetail() {
		isElementDisplayed("AssetURL");
		logMessage("Asset URL Link is Displayed..");

	}

	public void VerifyPublishStatus(String row, String status) {
		isElementDisplayed("publishInformation", row);
		String StatusDisplayed = element("publishInformation", row).getAttribute("innerText").trim();
		logMessage("Status Displayed::" + StatusDisplayed);
		logMessage("Status Expected::" + status);
		Assert.assertTrue(StatusDisplayed.equals(status),
				"[Assertion Failed]:: Incorrect Status Displayed=" + StatusDisplayed);
	}

	public void VerifyStep3PublishWindowNameOfAsset(String Name) {
		isElementDisplayed("Step3AsseName", Name);
		logMessage(Name + " Asset Displayed in Step 3 Publish Window");

	}

	public void HoverAndClickLuminaSection() {
		isElementDisplayed("LuminaRightsDetailsDBKey");
		hover(element("LuminaRightsDetailsDBKey"));
		click(element("LuminaRightsDetailsDBKey"));
		logMessage("Click Lumina Section");
	}

	public void VerifyAuthoringPushPlatformSectionDisplayed() {
		isElementDisplayed("AuthoringPlatformLabel");
		logMessage("Authoring Platform Push Details is Displayed..");

	}

	public void VerifyPushDetailsRefreshButton() {
		isElementDisplayed("Refreshbutton");
		logMessage("Refresh button Is Displayed..");
	}

	// ################## NGA APPLICATION FUNCTIONALITY Start #################

	public void VerifyTableHeaderForAuthoringPlatformPushDetails() {
		isElementDisplayed("AuthoringPlatformLabel");
		scroll(element("AuthoringPlatformLabel"));

		isElementDisplayed("AuthoringHeaders", "Username");
		logMessage("'User' is Displayed");
		isElementDisplayed("AuthoringHeaders", "Destination");
		logMessage("'Destination' is Displayed");
		isElementDisplayed("AuthoringHeaders", "Pushed Date");
		logMessage("'Pushed Date' is Displayed");
		isElementDisplayed("AuthoringHeaders", "URL");
		logMessage("'URL' is Displayed");
		isElementDisplayed("AuthoringHeaders", "Status");
		logMessage("'Status' is Displayed");
	}

	public void ClickNGARefreshButton() {
		isElementDisplayed("Refreshbutton");
		scroll(element("Refreshbutton"));
		wait.waitForPageToLoadCompletely();
		click(element("Refreshbutton"));
		logMessage("Refresh button Is Clicked..");
		waitForLoaderToDisappear();
	}
	
	public void verifyActivateLinkForHttpsLinkIsDisplayed() {
		isElementDisplayed("HttpsLinkActivateMsg",getData("HttpLinkActivateMsg"));
		logMessage(getData("HttpLinkActivateMsg") +" is Displayed..");
	}
	
	public void clickActivationForHttpsLink() {
		isElementDisplayed("HttpsLinkActivateMsg",getData("HttpLinkActivateMsg"));
		hoverOverElement(element("HttpsLinkActivateMsg",getData("HttpLinkActivateMsg")));
		wait.waitForPageToLoadCompletely();
		click(element("HttpsLinkActivateMsg",getData("HttpLinkActivateMsg")));
		logMessage("Activation Link Clicked..");
	}
	
	public void VerifySuccessMessageOnNGAPush() {
		isElementDisplayed("PushSuccessMsg");
		logMessage("Success Message is Displaye::" + element("PushSuccessMsg").getText());
	}

	public void VerifyNGAPushOperationCompletes() {
		ClickNGARefreshButton();
		isElementDisplayed("PushStatus");
		int No_try = 0;
		while (No_try <= 60) {
			String Status = element("PushStatus").getAttribute("innerText").trim();
			if (Status.equalsIgnoreCase("Complete")) {
				logMessage("'Complete' Status is Displayed..");
				return;
			} else {
				logMessage(Status+" State is Displayed...");
				wait.hardWait(5); // Will wait for 5 sec and refresh
				ClickNGARefreshButton();
				No_try++;
			}
			if (No_try >= 60) {
				Assert.assertTrue(false, "[Assertion Failed]::'Complete status is not Displayed'");
			}
		}
	}

	public void VerifyPushStatusOnPublishDetails(String Status) {
		isElementDisplayed("PushStatus");
		String DisplayedStatus = element("PushStatus").getAttribute("innerText").trim();
		Assert.assertTrue(DisplayedStatus.equalsIgnoreCase(Status),
				"[Assertion Failed]::Status Displayed '" + DisplayedStatus + "'");
		logMessage("Ststus Displayed::" + Status);
	}

	public void clickAssetUrlNGAPublishDetail() {
		isElementDisplayed("AssertUrlLink");
		clickUsingJavaScript("AssertUrlLink");
		logMessage("Assert Url clicked...");
	}

	public void VerifyAssertUrlPopUpDisplayed() {
		isElementDisplayed("AssertUrlLabel");
		logMessage("Assert URL Popup Displayed..");
	}

	public void VerifyURL_IsDisplayed() {
		isElementDisplayed("AssertURL");
		String URL = element("AssertURL").getAttribute("innerText");
		if (URL.length() == 0 || URL == null) {
			Assert.assertTrue(false, "[Assertion Failed]:: Assert URl Not Displayed..");
		} else {
			logMessage("URL Displayed::" + URL);
		}
	}

	public void VerifyOkButtonDisplayed() {
		isElementDisplayed("okButton");
	}

	public void ClickOkButton() {
		isElementDisplayed("okButton");
		wait.waitForPageToLoadCompletely();
		click(element("okButton"));
		logMessage("'OK' Button Clicked...");
	}

	public void VerifyAssertURLEncoded(String assetURl) {
		isElementDisplayed("AssertURL");
		String URL = element("AssertURL").getAttribute("innerText").trim();
		if (URL.length() == 0) {
			Assert.assertTrue(false, "[Assertion Failed]:: Assert URl Not Displayed..");
		}
		logMessage("URL Displayed::" + URL);
		logMessage("URL Expected ::" + assetURl);
		Assert.assertTrue(URL.contains(assetURl), "[Assertion Failed]:: Incorrect Asset URL Displayed");
	}

	public void CopyAssetUrlFromIconAndVerify() throws HeadlessException, UnsupportedFlavorException, IOException {
		isElementDisplayed("CopyIcon");
		scroll(element("CopyIcon"));
		click(element("CopyIcon"));
		logMessage("Copy Icon Cliked...");
		wait.waitForPageToLoadCompletely();
		String data = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
		if (data.length() == 0 || data == null) {
			Assert.assertTrue(false, "[Assertion Failed]:: Link not Copyed..");
		} else {
			logMessage("Link Copyed::" + data);
		}
	}

	public void VerifySameLinkAsAssetURLIsCopyedInNGATest()
			throws HeadlessException, UnsupportedFlavorException, IOException { // Verify User on Publish Detail.
		clickAssetUrlNGAPublishDetail();
		VerifyAssertUrlPopUpDisplayed();
		VerifyURL_IsDisplayed();
		isElementDisplayed("AssertURL");
		String URL = element("AssertURL").getAttribute("innerText").trim();
		refreshPage();
		waitForLoaderToDisappear();
		ClickPublishDetail();
		isElementDisplayed("CopyIcon");
		scroll(element("CopyIcon"));
		click(element("CopyIcon"));
		logMessage("Copy Icon Cliked...");
		String data = (String) Toolkit.getDefaultToolkit().getSystemClipboard().getData(DataFlavor.stringFlavor);
		logMessage("Asset URL Displayed::" + URL);
		logMessage("Asset URL Copyed:::::" + data);
		if (data.trim().equals(URL.trim())) {
			logMessage("[Assertion Passed]:: Assert URL is Copyed Correctly");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Assert URL not Copyed Correctly");
		}
	}

	public void VerifyCopyedURLIsAbleToLoad() {
		clickAssetUrlNGAPublishDetail();
		VerifyAssertUrlPopUpDisplayed();
		VerifyURL_IsDisplayed();
		isElementDisplayed("AssertURL");
		String URL = element("AssertURL").getAttribute("innerText").trim();
		OpenNewTabOntheCurrentWindow();
		changeWindow(1);
		wait.waitForPageToLoadCompletely();
		driver.get(URL);
		if (!BoolenIsElementDisplayed("ErrorNoImg") && BoolenIsElementDisplayed("ImageDisplayed")) {
			Assert.assertTrue(true, "[Assertion Passed]:: Image is Successfuly Loaded");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Image is Not Successfuly Loaded");
		}
		closeWindowAndSwitchBackToOriginalWindow(0);
	}

	public void VerifyCopyedURLIsNotAbleToLoad() {
		clickAssetUrlNGAPublishDetail();
		VerifyAssertUrlPopUpDisplayed();
		VerifyURL_IsDisplayed();
		isElementDisplayed("AssertURL");
		String URL = element("AssertURL").getAttribute("innerText").trim();
		OpenNewTabOntheCurrentWindow();
		changeWindow(1);
		wait.waitForPageToLoadCompletely();
		driver.get(URL);
		if (!BoolenIsElementDisplayed("ErrorNoImg") && BoolenIsElementDisplayed("ImageDisplayed")) {
			Assert.assertTrue(false, "[Assertion Failed]:: Image is Successfuly Loaded");
		} else {
			Assert.assertTrue(true, "[Assertion Passed]:: Image Should not Have been Loaded.");
		}
		closeWindowAndSwitchBackToOriginalWindow(0);
	}

	public void VerifyPushToNGA_EntryNotBoldInHistoryTable() {
		scroll(element("historyLabel"));
		isElementDisplayed("UpdateInfo", "Push to https link");
		String fontweight = element("UpdateInfo", "Push to https link").getCssValue("font-weight");
		logMessage("Fontweight Value::" + fontweight);
		boolean isBold = "bold".equals(fontweight) || "bolder".equals(fontweight)
				|| Integer.parseInt(fontweight) >= 700;
		Assert.assertTrue(isBold == false,
				"[Assertion Failed]:: Push to NGA Authoring Entry is in Bold on Content History Table.");
		logMessage("[Assertion Passed]:: Push to NGA Authoring Entry is NOT in Bold on Content History Table.");
	}

	public void VerifyOnlyOneEntryForNGAPushOperation() {
		areElementsDisplayed("RowsInAuthoringTool");
		int count = elements("RowsInAuthoringTool").size();
		Assert.assertTrue(count == 1, "[Assertion Failed]:: " + count + " Entry Displayed..");
	}

	public void VerifyPushTableIsUpadted(String Name, String date) {
		isElementDisplayed("EntryInTable", Name);
		isElementDisplayed("EntryInTable", date);
	}

	public void VerifyUserEmailDisplayedOnAuthoringPlatformPushDetails(String Email) {
		isElementDisplayed("EntryInTable", Email);
		scroll(element("EntryInTable", Email));
	}

	public void VerifyContentHistoryTableActionUpdated(String Updated) {
		scroll(element("historyLabel"));
		isElementDisplayed("UpdateInfo", Updated);
		logMessage("Content History Table is Upated with:" + Updated);
	}

	public void VerifyContentHistoryTableCreatedByUpdated(String Email) {
		scroll(element("historyLabel"));
		isElementDisplayed("UpdateCreatedBy", Email);
		logMessage("Content History Table is Upated with:" + Email);
	}

	public void VerifyAssetURLOnHistoryTable() {
		isElementDisplayed("NGAAssetUrl");
		scroll(element("NGAAssetUrl"));
		logMessage("'Asset URL' is Displayed on Content History Table.");
	}

	public void ClickAssetUrlOnHistoryTable() {
		isElementDisplayed("NGAAssetUrl");
		hover(element("NGAAssetUrl"));
		wait.waitForPageToLoadCompletely();
		click(element("NGAAssetUrl"));
		logMessage("'Asset URL Clicked..'");
	}

	public void VerifyContentHistoryTableIsUpdatedWithSameNGAAssetUrl() {
		wait.waitForPageToLoadCompletely();
		clickAssetUrlNGAPublishDetail();
		VerifyAssertUrlPopUpDisplayed();
		VerifyURL_IsDisplayed();
		isElementDisplayed("AssertURL");
		String URL = element("AssertURL").getAttribute("innerText").trim();
		ClickX_OnWindow();

		ClickAssetUrlOnHistoryTable();
		VerifyAssertUrlPopUpDisplayed();
		VerifyURL_IsDisplayed();
		isElementDisplayed("AssertURL");
		String ContentHistoryUrl = element("AssertURL").getAttribute("innerText").trim();
		logMessage("URL Displayed on Publish Detail::" + URL);
		logMessage("URL Displayed on Content History:" + ContentHistoryUrl);
		Assert.assertTrue(URL.equals(ContentHistoryUrl),
				"[Assertion Failed]:: The Assert URL Are not Same on Publish Detail and Content History Table");
	}

	public void VerifyContentIDPresentOnAssetURL(String ContentID) {
		if (ContentID == null || ContentID.length() == 0) {
			Assert.assertTrue(false, "[Assertion Failed]:: '" + ContentID + "' Is Not Displayed on NGA Assert URL");
		}
		isElementDisplayed("AssertURL");
		String URL = element("AssertURL").getAttribute("innerText");
		logMessage("URL::" + URL);
		Assert.assertTrue(URL.contains(ContentID),
				"[Assertion Failed]:: '" + ContentID + "' Is Not Displayed on NGA Assert URL");
		logMessage("[Assertion Passed]:: '" + ContentID + "' Is Displayed on NGA Assert URL");
	}

	public void VerifyAssetNGAURLFormat(String ContentId, String FileName) {
		isElementDisplayed("AssertURL");
		String AssetUrl = element("AssertURL").getAttribute("innerText").trim();
		String FormURL = getData("NGAURLFormat") + ContentId + "/" + FileName;
		logMessage("URL Expected:::" + FormURL);
		logMessage("URL Displayed::" + AssetUrl);
		Assert.assertTrue(AssetUrl.equals(FormURL), "[Assertion Failed]:: Expected URL Not Displayed.");
	}

	// #################### NGA APPLICATION FUNCTIONALITY END ####################

	/// *********** START:: Publish To Instructor Store Functionality************//

	public void SearchForISBNIn_IS_Publish_Window(String ISBN) {
		isElementDisplayed("IS_SearchBar");
		fillText("IS_SearchBar", ISBN);
		wait.hardWait(1);
		element("IS_SearchBar").sendKeys(Keys.BACK_SPACE);
	}

	public void CopyPaste_ISBNIn_IS_Publish_Window(String ISBN) {
		isElementDisplayed("IS_SearchBar");
		fillText("IS_SearchBar", ISBN);
		element("IS_SearchBar").sendKeys(Keys.chord(Keys.CONTROL, "a"));
		element("IS_SearchBar").sendKeys(Keys.chord(Keys.CONTROL, "x"));
		element("IS_SearchBar").sendKeys(Keys.chord(Keys.CONTROL, "v"));
		wait.waitForPageToLoadCompletely();
	}

	public void VerifySearchForISBnInputBoxDisplayed() {
		isElementDisplayed("IS_SearchBar");
		logMessage("[Assertion Passed]:: Search For ISBN Input Box is Displayed");
	}

	public void VerifySearchForISBNIn_IS_Publish_Window_Not_Displayed() {
		Assert.assertTrue(verifyElementNotDisplayed("IS_SearchBar"),
				"[Assertion Failed]:: Search For ISBN Input Box is Displayed");
		logMessage("[Assertion Passed]:: Search For ISBN Input Box is Not Displayed");
	}

	public void VerifySuggesationBoxDisplayedInPublishWindowFor_IS() {
		isElementDisplayed("IS_SuggesationBox");
		logMessage("Suggesation Box Displayed....");
	}

	public void SelectISBNFromSuggestaionBoxInPublishWindow_IS(String ISBN) {
		isElementDisplayed("IS_SelectISBN", ISBN);
		hover(element("IS_SelectISBN", ISBN));
		wait.hardWait(1);
		click(element("IS_SelectISBN", ISBN));
		logMessage(ISBN + " Selected from Suggesation Box..");
	}

	public void ClickADDButton_IS() {
		isElementDisplayed("IS_ADDButton");
		wait.waitForElementToBeClickable(element("IS_ADDButton"));
		click(element("IS_ADDButton"));
		logMessage("ADD Button Clicked..");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyAddButtonDisabledOnIS_PublishWindow() {
		isElementDisplayed("IS_ADDButton");
		String AttriDisabled = element("IS_ADDButton").getAttribute("disabled").trim();
		String AttriCursor = element("IS_ADDButton").getCssValue("cursor").trim();
		Assert.assertTrue(AttriDisabled.equals("true") && AttriCursor.equals("not-allowed"),
				"[Assertion Failed]:: Add Button is Enabled");
		logMessage("[Assertion Passed]:: Add Button is Disabled");
	}

	public void VerifyISBN_DisplayedIn_IS_Publish(String ISBN) {
		isElementDisplayed("VerifyISBN_In_IS", ISBN);
		logMessage(ISBN + " ISBN Is Displayed..");
	}

	public void VerifyISBN_NotDisplayedIn_IS_Publish(String ISBN) {
		Assert.assertTrue(verifyElementNotDisplayed("VerifyISBN_In_IS", ISBN),
				"[Assertion Failed]:: " + ISBN + " is Displayed..");
		logMessage(ISBN + " ISBN Is Not Displayed..");
	}

	public void VerifyNoISBNsIsDisplayedOnPublishTable() {
		wait.waitForPageToLoadCompletely();
		List<WebElement> ISBNCount = elements("VerifyCountOfISBN");
		if (ISBNCount.size() == 0) {
			logMessage("[Assertion Passed]:: No ISBNs are Displayed..");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]::" + ISBNCount.size() + " ISBNs are Displayed..");
		}
	}

	public void VerifyTableHeaderForIS_PublishWindow() {
		isElementDisplayed("TableHeaderIS", "Author");
		isElementDisplayed("TableHeaderIS", "Title");
		isElementDisplayed("TableHeaderIS", "Edition");
		isElementDisplayed("TableHeaderIS", "CopyrightYear");
		isElementDisplayed("TableHeaderIS", "ISBN");
		isElementDisplayed("TableHeaderIS", "ISBN-10");
		isElementDisplayed("TableHeaderIS", "Action");

	}

	public void DeleteISBN_From_IS_PublishWindow(String ISBN) {
		isElementDisplayed("DeleteISBN_In_IS", ISBN);
		hover(element("DeleteISBN_In_IS", ISBN));
		wait.hardWait(1);
		waitAndClick("DeleteISBN_In_IS", ISBN);
		logMessage(ISBN + " Deleted From Instructor Store Publish Window..");
		waitForLoaderToDisappear();
	}

	public void NavigateToPageNumberInPublishWindow_IS(String PageNo) {
		wait.hardWait(2);
		wait.resetImplicitTimeout(2);
		try {
			isElementDisplayed("navigateIS_publish", PageNo);
		} catch (java.lang.AssertionError exc) {
			logMessage("PaginationBar Is not Appering At Instructor Store Publish Window");
			wait.resetImplicitTimeout(wait.getTimeout());
			return;
		}

		isElementDisplayed("navigateIS_publish", PageNo);
		click(element("navigateIS_publish", PageNo));
		logMessage("page number " + PageNo + " clicked... Able To move Forword from pagination Bar");
		wait.resetImplicitTimeout(wait.getTimeout());
	}

	public void Verify_PaginationBar_Not_Displayed_for_InstructorStore_Publish_Window() {
		Assert.assertTrue(verifyElementNotDisplayed("navigateIS_publish", "1"),
				"[Assertion Failed]:: PaginationBar Is Appering on Publish Window");
	}

	public void Verify_PaginationBar_Displayed_for_InstructorStore_Publish_Window() {
		isElementDisplayed("navigateIS_publish", "1");
		logMessage("[Assertion Paased]:: PaginationBar Is Appering on Publish Window");
	}

	/// *********** END:: Publish To Instructor Store Functionality************//

	public String GetContentIDofAsset() {
		isElementDisplayed("SystemMetaData", "Content ID");
		return element("SystemMetaData", "Content ID").getText().trim();
	}

}
