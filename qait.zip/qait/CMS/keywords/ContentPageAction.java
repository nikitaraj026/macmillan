package com.qait.CMS.keywords;

import static com.qait.automation.utils.YamlReader.getData;
import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.UnknownHostException;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.YamlReader;

import org.testng.Assert;

public class ContentPageAction extends GetPage {

	public ContentPageAction(WebDriver driver) {
		super(driver, "ContentPage");
	}

	public void VerifyOnContentTab() {
		isElementDisplayed("contentlabel");
		isElementDisplayed("contentlabel");
		logMessage("User is on Content Tab!!!!!");
	}

	public void clickhomeLink() {
		isElementDisplayed("HomeLink");
		clickUsingJS(element("HomeLink"));
		logMessage("Home Link Clicked!!!!!!");
	}

	public void VerifyFilterOprions() {
		isElementDisplayed("resultNo");
		logMessage("Result Number is Displayed");
		isElementDisplayed("SortBy");
		logMessage("SortBy is Displayed");
		isElementDisplayed("SortBy");
		logMessage("SortBy is Displayed");
		isElementDisplayed("GridViewCheck");
		logMessage("GridView is Displayed");
		isElementDisplayed("ListView");
		logMessage("ListView is Displayed");
	}

	public void selectContent(String ContentNo) {
		waitAndClick("SelectContent", ContentNo);
		logMessage("Content Selected");

	}

	public void VerifyModifyOptions() {
		isElementDisplayed("ModifyOptions2", "Organized Download");
		logMessage("'Organized Download' Is Displayed..");

		isElementDisplayed("ModifyOptions2", "Download Content");
		logMessage("'Download Content' Is Displayed..");

		isElementDisplayed("ModifyOptions2", "Add to Project");
		logMessage("'Add to Project' Is Displayed..");

		isElementDisplayed("ModifyOptions2", "Delete");
		logMessage("'Delete' Is Displayed..");

		isElementDisplayed("resultNo");
		logMessage("'resultNo' Is Displayed..");

		isElementDisplayed("SortBy");
		logMessage("'SortBy' Is Displayed..");

	}

	public void verifyColumnsAreDisplayed() {
		isElementDisplayed("Coloums", "Title");
		logMessage("Title is Display");
		isElementDisplayed("Coloums", "File Name");
		logMessage("File Name is Displayed");
		isElementDisplayed("Coloums", "Content Type");
		logMessage("Content Type is Displayed");
		isElementDisplayed("Coloums", "Repository");
		logMessage("Repository is Displayed");
		isElementDisplayed("Coloums", "Last Modified Date");
		logMessage("Last Modified Date is Displayed");
	}
	
	public void verifyTableRowGetsHighlightedOnHover() {
		areElementsDisplayed("OpenAsset");
		hoverOverElement(elements("OpenAsset").get(0));
		String backgroundStatus=elements("OpenAsset").get(0).getCssValue("background-color").trim();
		logMessage("Background Colour Displayed::"+backgroundStatus);
		Assert.assertTrue(backgroundStatus.equals("rgba(173, 216, 230, 1)"), "[Assertion Failed]::Background Colour Expected:rgba(173, 216, 230, 1)");
		
	}
	
	public void verifyViewColoumNotDisplayedOnContentTab() {
		Assert.assertTrue(verifyElementNotDisplayed("Coloums","View"),"[Assertion Failed]:: 'View' Coloum is Displayed on Content Tab..");
	}
	
	public void verifyEyeIconNotDisplayedOnContentTab() {
		Assert.assertTrue(verifyElementNotDisplayed("ViewEyeIcon"),
				"[Assertion Failed]:: Eye Icon is not Displayed on Favorite Table");
	}

	public void VerifyFlatIsDisplayed() {
		areElementsDisplayed("FlatEpub");
		List<WebElement> FlatEpub = elements("FlatEpub");
		String verifyText = FlatEpub.get(0).getAttribute("innerText");
		logMessage(verifyText);
		Assert.assertTrue(verifyText.contains("FLAT"), "[Assertion FAILED]:Flat is not dislayed");

	}

	public void VerifyEnhancedIsDisplayed() {
		areElementsDisplayed("EnhancedEpub");
		List<WebElement> EnhancedEpub = elements("EnhancedEpub");
		String verifyText = EnhancedEpub.get(0).getAttribute("innerText");
		logMessage(verifyText);
		Assert.assertTrue(verifyText.contains("ENHANCED"), "[Assertion FAILED]:ENHANCED is not dislayed");

	}

	public void ClickGridView() {
		waitForLoaderToDisappear();
		waitForLoaderToDisappear();
		isElementDisplayed("GridView");
		hover(element("GridView"));
		wait.waitForPageToLoadCompletely();
		click(element("GridView"));
		logMessage("Grid View Clicked");

	}

	// Select content via check boxs on Content tab.
	public void SelectContentsUsingCheckboxesOrBySelectAllCheckbox() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("contentSelectCheckBox");
		List<WebElement> checkBoxLink = elements("contentSelectCheckBox");
		checkBoxLink.get(0).click();
		logMessage("First Content Selected!!");
		checkBoxLink.get(1).click();
		logMessage("second Content Selected!!");
		wait.waitForPageToLoadCompletely();
		logMessage("first=" + checkBoxLink.get(0).isSelected() + "Sec=" + checkBoxLink.get(1).isSelected());

		if (checkBoxLink.get(0).isSelected() && checkBoxLink.get(1).isSelected()) {
			logMessage("User is able to Select Multiple Contents Using Checkboxes");

		} else {
			logMessage("[Assertion Failed]: user is unable to Select Multiple Contents ");
			Assert.assertFalse(true);
			return;
		}

		refreshPage();
		waitForLoaderToDisappear();
		ClickPageSelectionDropDown();
		SelectPageType(getData("PageSelection.This Page"));
		VerifyContentsAreSelectedOnContantTab();
		logMessage("User is able to select 'Select All Content Checkbox'");
	}
	
	
	//###### Page Selection (Content Selection) on Content Tab Functionality ##### 

	public void ClickPageSelectionDropDown() {
		isElementDisplayed("PageSelectionButton");
		wait.waitForPageToLoadCompletely();
		clickUsingJavaScript("PageSelectionButton");
		logMessage("Page Selection Dropdown Clicked..");
	}

	public void SelectPageType(String pageSelection) {
		isElementDisplayed("PafeSelect", pageSelection);
		wait.waitForPageToLoadCompletely();
		clickUsingJavaScript("PafeSelect", pageSelection);
		logMessage("'" + pageSelection + "' is selected in Page Selection...");
	}

	public void VerifyHandIconOnSelectAllOption(String Option) {
		isElementDisplayed("PafeSelect", Option);
		wait.waitForPageToLoadCompletely();
		hover(element("PafeSelect", Option));
		logMessage("Cursor Property::" + element("PafeSelect", Option).getCssValue("cursor"));
		Assert.assertTrue(element("PafeSelect", Option).getCssValue("cursor").trim().equals("pointer"),
				"[Assertion Failed]::Hand Icon Not Displayed..");
	}

	public void VerifyHandIconNotDisplayedNearPageSelection() {
		isElementDisplayed("PageSelectionArea");
		logMessage("Cursor Property::" + element("PageSelectionArea").getCssValue("cursor"));
		Assert.assertTrue(element("PageSelectionArea").getCssValue("cursor").trim().equals("auto"),
				"[Assertion Failed]::Hand Icon Is Displayed..");
	}

	public void VerifyPageIsSelectedInDropDown(String PageSelection) {
		isElementDisplayed("CheckPageSelection", PageSelection);
		logMessage(PageSelection + " is  Selected...");

	}

	public void VerifyPageNotSelectedInDropDown(String PageSelection) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("CheckPageSelection", PageSelection),
				"[Asserion Failed]::" + PageSelection + " is Selected...");
		logMessage(PageSelection + " is Not Selected...");

	}

	public void VerifyPaginationBarIsVisible() {
		isElementDisplayed("PaginationBar");
		isElementDisplayed("PaginationBar");
		scroll(element("PaginationBar"));
		logMessage("PaginationBar is Visible");

	}

	public void clickDownloadContent() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("DownloadContent");
		clickUsingJS(element("DownloadContent"));
		logMessage("Download content Clicked");

	}

	public void clickDownloadContentONContentView() {
		isElementDisplayed("DownloadContentView");
		clickUsingJS(element("DownloadContentView"));
		logMessage("Download content Clicked");

	}

	public void VerifyMessageNotDisplayedOnDownloadingContent() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("DownloadStart"),
				"[Assertion Failed]::Message on Downloading Content is Displayed");
		logMessage("Message on Downloading Content is not Displayed.....");
	}

	public void verifyCorrectMessageIsDisplayedOnDownloadOfContent(String ExpectedMessage, String count) {
		StringBuilder DownloadMssage = new StringBuilder(ExpectedMessage);
		DownloadMssage.replace(14, 14, count);
		String DownloadMSG = DownloadMssage.toString().replaceAll("  ", " ");
		areElementsDisplayed("DownloadStart");
		String message = element("DownloadStart").getAttribute("innerText").replaceAll("  ", " ");
		logMessage("Message Displayed::" + message);
		logMessage("Expected::" + DownloadMSG);

		Assert.assertTrue(message.equals(DownloadMSG), "[Assertion FAILED]:Correct Message not displayed::" + message);
		logMessage("[Assertion PASSED]:Correct Message displayed::" + message);

	}

	public void SelectSingleContents() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SingleAsset");
		clickUsingJS(element("SingleAsset"));
		logMessage("Single Content Selected!!!!!!");
	}

	public void ClickOrganizedDownload() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("OrganizedDownload");
		wait.waitForElementToBeClickable(element("OrganizedDownload"));
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("OrganizedDownload"));
		waitForLoaderToDisappear();
		logMessage("Organized Download Clicked");
	}
	
	
	// Frame the Organised Download on the Content Tab in Following order::  option 1,option 2,option 3
	public void OrganiseTheDownloadInThreeFolderStructure(String option1, String option2, String option3) {
		isElementDisplayed("OrganisedDownloadDropDown", "Top level folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "Top level folder", option1);
		isElementDisplayed("OrganisedDownloadDropDown", "Top level folder");

		isElementDisplayed("OrganisedDownloadDropDown", "1st sub-folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "1st sub-folder", option2);
		isElementDisplayed("OrganisedDownloadDropDown", "1st sub-folder");

		isElementDisplayed("OrganisedDownloadDropDown", "2nd sub-folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "2nd sub-folder", option3);
		isElementDisplayed("OrganisedDownloadDropDown", "2nd sub-folder");
	}
	
	
	
    // Ensure that the option selected on Organised Window are not repeated again.
	public void VerifyInOrganisedDoenloadSelectionShouldNotRepeat() {
		isElementDisplayed("OrganisedDownloadDropDown", "Top level folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "Top level folder", "ISBN");
		isElementDisplayed("OrganisedDownloadDropDown", "Top level folder");
		logMessage("ISBN is Selected as first option");

		isElementDisplayed("OrganisedDownloadDropDown", "1st sub-folder");
		List<WebElement> DropdownValues = getAllOptionsOfDropdown(
				element("OrganisedDownloadDropDown", "1st sub-folder"));
		for (int i = 0; i < DropdownValues.size(); i++) {
			logMessage("Option " + (i + 1) + ":Displayed in Second DropDown::"
					+ DropdownValues.get(i).getAttribute("innerText"));
			if (DropdownValues.get(i).getAttribute("innerText").equalsIgnoreCase("ISBN")) {
				Assert.assertTrue(false, "ISBN is Selected In First DropDown");
			}
		}
		selectTextFromDropDown("OrganisedDownloadDropDown", "1st sub-folder", "Repository");
		logMessage("Repository is selected In Second DropDown..");
		logMessage(" ");

		isElementDisplayed("OrganisedDownloadDropDown", "2nd sub-folder");
		DropdownValues = getAllOptionsOfDropdown(element("OrganisedDownloadDropDown", "2nd sub-folder"));
		for (int i = 0; i < DropdownValues.size(); i++) {
			logMessage("Option " + (i + 1) + ":Displayed in Third DropDown::"
					+ DropdownValues.get(i).getAttribute("innerText"));
			if (DropdownValues.get(i).getAttribute("innerText").equalsIgnoreCase("Repository")) {
				Assert.assertTrue(false, "Repository is Selected In Second DropDown");
			}
		}
		selectTextFromDropDown("OrganisedDownloadDropDown", "2nd sub-folder", "Content Type");
		logMessage("Content Type Selected in Second DropDown...");
		logMessage(" ");

		isElementDisplayed("OrganisedDownloadDropDown", "Top level folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "Top level folder", "Repository");
		isElementDisplayed("OrganisedDownloadDropDown", "Top level folder");
		logMessage("Repository is Selected as first option");

		isElementDisplayed("OrganisedDownloadDropDown", "1st sub-folder");
		DropdownValues = getAllOptionsOfDropdown(element("OrganisedDownloadDropDown", "1st sub-folder"));
		for (int i = 0; i < DropdownValues.size(); i++) {
			logMessage("Option " + (i + 1) + ":Displayed in Second DropDown::"
					+ DropdownValues.get(i).getAttribute("innerText"));
			if (DropdownValues.get(i).getAttribute("innerText").equalsIgnoreCase("Repository")) {
				Assert.assertTrue(false, "Repository is Selected In First DropDown");
			}
		}
		selectTextFromDropDown("OrganisedDownloadDropDown", "1st sub-folder", "Content Type");
		logMessage("Content Type Selected in Second DropDown");
		logMessage(" ");

		isElementDisplayed("OrganisedDownloadDropDown", "2nd sub-folder");
		DropdownValues = getAllOptionsOfDropdown(element("OrganisedDownloadDropDown", "2nd sub-folder"));
		for (int i = 0; i < DropdownValues.size(); i++) {
			logMessage("Option " + (i + 1) + ":Displayed in Third DropDown::"
					+ DropdownValues.get(i).getAttribute("innerText"));
			if (DropdownValues.get(i).getAttribute("innerText").equalsIgnoreCase("Content Type")) {
				Assert.assertTrue(false, "Content Type is Selected In Second DropDown");
			}
		}
		selectTextFromDropDown("OrganisedDownloadDropDown", "2nd sub-folder", "ISBN");
	}
	
	
	
	public void OrganizedTheDownload(String option1, String option2, String option3) {
		isElementDisplayed("OrganisedDownloadDropDown", "Top level folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "Top level folder", option1);
		logMessage(option1 + " Selected As First Options..");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("OrganisedDownloadDropDown", "1st sub-folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "1st sub-folder", option2);
		logMessage(option2 + " Selected As Second Options..");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("OrganisedDownloadDropDown", "2nd sub-folder");
		selectTextFromDropDown("OrganisedDownloadDropDown", "2nd sub-folder", option3);
		logMessage(option3 + " Selected As Thrid Options..");

		isElementDisplayed("selectAllCheckBox");
		hover(element("selectAllCheckBox"));
		wait.waitForPageToLoadCompletely();
		click(element("selectAllCheckBox"));

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("FinishButton");
		click(element("FinishButton"));
		logMessage("Finish Button Clicked...");
	}
	
	
	// Select type of Search on Content tab
	public void SelectSearchType(String SearchType) {
		isElementDisplayed("SearchTypeButton");
		click(element("SearchTypeButton"));
		logMessage("All Types Button Clicked");
		isElementDisplayed("SearchType", SearchType);
		click(element("SearchType", SearchType));
		logMessage("'" + SearchType + "' Selected In Type Of Search");
	}

	public void SearchForAnItem(String AssetName) {
		scrollToTop();
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("SearchTypeButton");
		clickUsingJS(element("SearchTypeButton"));
		logMessage("All Types Button Clicked");

		isElementDisplayed("SearchType", getData("SearchType.content"));
		clickUsingJS(element("SearchType", getData("SearchType.content")));
		logMessage("'content' Selected In Type Of Search");

		isElementDisplayed("SearchInputBar");
		clickUsingJS(element("SearchInputBar"));
		String selectAll = Keys.chord(AssetName);
		element("SearchInputBar").clear();
		element("SearchInputBar").sendKeys(selectAll);
		logMessage(AssetName + " Entered in search bar");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("SubmitButton");
		hover(element("SubmitButton"));
		wait.waitForPageToLoadCompletely();
		click(element("SubmitButton"));
		logMessage("Submit button clicked");
		waitForLoaderToDisappear();
	}

	public void SearchForAnItemWithOutSearchType(String ISBN) {
		wait.hardWait(1);
		scrollToTop();
		isElementDisplayed("SearchInputBar");
		clickUsingJS(element("SearchInputBar"));
		String selectAll = Keys.chord(ISBN);
		element("SearchInputBar").clear();
		wait.hardWait(1);
		element("SearchInputBar").sendKeys(selectAll);
		logMessage(ISBN + " Entered in search bar");
		wait.hardWait(1);
		clickUsingJS(element("SubmitButton"));
		logMessage("Submit button clicked");
		waitForLoaderToDisappear();
	}

	public void opentheSearchContent(String AssetName) {

		isElementDisplayed("SearchTypeButton");
		clickUsingJS(element("SearchTypeButton"));
		logMessage("All Types Button Clicked");
		isElementDisplayed("SearchType", getData("SearchType.content"));
		clickUsingJS(element("SearchType", getData("SearchType.content")));
		logMessage("'content' Selected In Type Of Search");

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("openAssertWithOutContentType", AssetName);
		scroll(element("openAssertWithOutContentType", AssetName));
		hover(element("openAssertWithOutContentType", AssetName));
		wait.waitForPageToLoadCompletely();
		click(element("openAssertWithOutContentType", AssetName));
		logMessage(AssetName + " Assert Opened");
		waitForLoaderToDisappear();
	}

	public void ClickOnAssetOnContentTab(String AssetName, String ContentType) {
		logMessage(getLocator("openAssert", ContentType, ContentType, AssetName, AssetName) + "");
		wait.waitForPageToLoadCompletely();
		Actions actions = new Actions(driver);
		actions.moveToElement(
				driver.findElement(getLocator("openAssert", ContentType, ContentType, AssetName, AssetName))).perform();
		wait.waitForPageToLoadCompletely();
		driver.findElement(getLocator("openAssert", ContentType, ContentType, AssetName, AssetName)).click();
		logMessage("Asset title::'" + AssetName + "' of content Type::'" + ContentType + "' Clikcked...");
	}
	
	
	

	//##### Method Related to Add/Remove Project Functionality #####
	public void ClickAddToProject() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		scrollToTop();
		isElementDisplayed("AddToProject");
		clickUsingJS(element("AddToProject"));
		logMessage("AddToProject clicked");
	}

	public void AddSelectedContentToProject(String ISBN) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SearchProject");
		clickUsingJS(element("SearchProject"));
		String ISBNc = Keys.chord(ISBN);
		wait.hardWait(1);
		element("SearchProject").sendKeys(ISBNc);
		isElementDisplayed("SubmitProject");
		clickUsingJS(element("SubmitProject"));
		logMessage("Search button clicked");
		logMessage(ISBN);
		waitForLoaderToDisappear();

		areElementsDisplayed("selectProjectToAdd", ISBN);
		clickUsingJS(element("selectProjectToAdd", ISBN));
		logMessage("Project Selected");

		isElementDisplayed("SelectButton");
		clickUsingJS(element("SelectButton"));
		logMessage("Selected Button Clicked");
		waitForLoaderToDisappear();

		isElementDisplayed("saveButton");
		clickUsingJS(element("saveButton"));
		logMessage("Save Button Clicked");

		areElementsDisplayed("publishMessage");
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(
				"Content was successfully associated with project(s)"
						.equals(element("publishMessage").getText().trim()),
				"[Assertion Failed]::Message Displayed:" + element("publishMessage").getText().trim());
		logMessage("Contents are added to project::" + ISBN);
		logMessage("Message Displayed::" + element("publishMessage").getText().trim());
	}

	public void Verify_Success_Message_Is_Displayed_On_Adding_Content_To_Project(String ISBN) {
		wait.hardWait(1);
		areElementsDisplayed("publishMessage");
		Assert.assertTrue("Content was successfully associated with project(s)"
				.equals(element("publishMessage").getAttribute("innerText")));
		logMessage("Contents are added to project::" + ISBN);
	}
	
	
	public void VerifyAddtoProjectpopUp() {
		areElementsDisplayed("AddtoProjectlabel");
		logMessage("Add to project popup displayed");
	}

	public void verifySearchFieldAnd_xIconOnAddtoProjectpopUp() {
		isElementDisplayed("SearchProject");
		logMessage("Search Field Is Displayed");

		isElementDisplayed("xIcon");
		logMessage("'x' Field Is Displayed");

	}
	
	public void clickXIconOnAddRemoveProject() {
		isElementDisplayed("xIcon");
		click(element("xIcon"));
		logMessage("'X' Icon Clicked..");
		
	}
	
	public void verifyClearAllLinkNotDisplayedOnAddtoProjectpopUp() {
		Assert.assertTrue(verifyElementNotDisplayed("ClearAll"), "[Assertion Failed]:: 'Clear All' Link is Displayed..");
		logMessage("[Assertion Failed]:: 'Clear All' Link is Not Displayed..");
	}

	public void VerifyAvailableAndSelectedPane() {
		areElementsDisplayed("AvailablePane");
		logMessage("Seleted pane is displayed");
		List<WebElement> info = elements("AvailablePane");
		for (int i = 0; i < info.size(); i++) {
			logMessage(info.get(i).getAttribute("innerText") + " Is Displayed");
			wait.waitForPageToLoadCompletely();
		}

		areElementsDisplayed("SelectedPane");
		logMessage("Selected pane is displayed");
		List<WebElement> infos = elements("SelectedPane");
		for (int i = 0; i < infos.size(); i++) {
			logMessage(infos.get(i).getAttribute("innerText") + " Is Displayed");
			wait.waitForPageToLoadCompletely();
		}
	}

	public void VerifySelectAndUnselectButton() {
		isElementDisplayed("SelectButton");
		isElementDisplayed("SelectButton");
		logMessage("Select Button Is Displayed");

		isElementDisplayed("UnSelectButton");
		isElementDisplayed("UnSelectButton");
		logMessage("UnSelect Button Is Displayed");

	}

	public void VerifySelectAndUnselectButtonIsDeactivated() {
		isElementDisplayed("SelectButton");
		isElementDisplayed("UnSelectButton");
		String Attr = element("SelectButton").getAttribute("disabled");
		String Attr2 = element("UnSelectButton").getAttribute("disabled");
		logMessage(Attr + " " + Attr2);
		if (Attr.equals("true") && Attr2.equals("true")) {
			logMessage("[Assertion Passed]:: Select And Unselect Button Are Deactivated...");
			Assert.assertTrue(true);
		} else {
			logMessage("[Assertion Failed]:: Select And Unselect Button Are Activated...");
			Assert.assertTrue(false);
		}

	}

	public void SearchForProjectOnAddRemoveContent(String ISBN) {
		isElementDisplayed("SearchProject");
		isElementDisplayed("SearchProject");
		clickUsingJS(element("SearchProject"));
		String ISBNc = Keys.chord(ISBN);
		fillText("SearchProject", ISBNc);
		clickUsingJS(element("SubmitProject"));
		logMessage("Search button clicked");
		logMessage("Project of " + ISBN + " Searched..");
		waitForLoaderToDisappear();
	}
	
	public void VerifyInputBoxClearOnAddRemoveProject() {
		isElementDisplayed("SearchProject");
		Assert.assertTrue(element("SearchProject").getAttribute("value").isEmpty());
	}

	public void Verify_Project_Is_Selected_And_Select_Button_Activated(String ISBN) {
		isElementDisplayed("SearchProject"); // Search and Select project
		isElementDisplayed("SearchProject");
		clickUsingJS(element("SearchProject"));
		String ISBNc = Keys.chord(ISBN);
		fillText("SearchProject", ISBNc);
		clickUsingJS(element("SubmitProject"));
		logMessage("Search button clicked");
		logMessage(ISBN);
		waitForLoaderToDisappear();
		areElementsDisplayed("selectProjectToAdd", ISBN);
		clickUsingJS(element("selectProjectToAdd", ISBN));
		logMessage("Project Selected!!!!!!");
		wait.hardWait(1);

		if (element("SelectButton").getAttribute("disabled") == null) {
			logMessage("[Assertion Passed]:: Select button is Enabled.");

		} else {
			logMessage("[Assertion Failed]:: Select button is disabled.");
			Assert.assertTrue(false);
		}

	}

	public void ClickSelectButton() {
		wait.hardWait(1);
		isElementDisplayed("SelectButton");
		isElementDisplayed("SelectButton");
		clickUsingJS(element("SelectButton"));
		logMessage("Selected Button Clicked");
	}

	public void ClickSelectButtonAndVerifyContentMoved(String ISBN) {

		wait.hardWait(2);
		isElementDisplayed("SelectButton");
		clickUsingJS(element("SelectButton"));
		logMessage("Selected Button Clicked");

		isElementDisplayed("ConformProject", ISBN);
		isElementDisplayed("ConformProject", ISBN);
		logMessage("Project Moved To Selected Pane");
		wait.hardWait(2);
	}

	public void Verify_Unselect_Button_Is_Activated() {
		wait.hardWait(2);

		if (element("UnSelectButton").getAttribute("disabled") == null) {
			logMessage("[Assertion Passed]:: UnSelect Button is Enabled.");
		} else {
			logMessage("[Assertion Passed]:: UnSelect Button is Enabled.");
			Assert.assertTrue(false);

		}
	}

	public void NavigateToPageNumberInAvailablePane(String PageNumber) {
		wait.hardWait(1);
		isElementDisplayed("NavigateInAvailablePane", PageNumber);
		scroll(element("NavigateInAvailablePane", PageNumber));
		click(element("NavigateInAvailablePane", PageNumber));
		logMessage("User Navigated to Page::" + PageNumber);
	}

	public void VerifyPaginationIsUpdatedAsProjectsRemovedFromSelectedPane() {
		wait.hardWait(1);
		areElementsDisplayed("NumberOfpagesInSelectedPane");
		List<WebElement> pages = elements("NumberOfpagesInSelectedPane");
		int pageNumber = pages.size();

		ClickSelectAllCheckBoxOnSelectedPane();
		UnselectTheTheProjectOnSelectedContent();

		List<WebElement> pages2 = elements("NumberOfpagesInSelectedPane");
		logMessage("Number of pages previous::" + pageNumber);
		logMessage("Page Number After Unselect::" + pages2.size());
		if (pageNumber > pages2.size()) {
			logMessage("Pagination Is Updated As Projects Removed From Selected Pane");
		} else {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Pagination Is  not Updated As Projects Removed From Selected Pane");
		}
	}

	public void SelectProjectInAvailablePane(String ISBN) {
		String InputStatus = element("selectProjectToAdd", ISBN).getAttribute("ng-disabled");
		if (InputStatus.equals("false")) {
			areElementsDisplayed("selectProjectToAdd", ISBN);
			clickUsingJS(element("selectProjectToAdd", ISBN));
			logMessage(ISBN + "::Project Selected");
		} else {
			isElementDisplayed("ConformProject", ISBN);
			clickUsingJS(element("ConformProject", ISBN));
			wait.hardWait(3);
			isElementDisplayed("unselect");
			clickUsingJS(element("unselect"));
			wait.hardWait(2);
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.hardWait(3);
			areElementsDisplayed("selectProjectToAdd", ISBN);
			clickUsingJS(element("selectProjectToAdd", ISBN));
			logMessage("Project Selected");
		}
	}

	public void VerifyProjectDisplayedInAvailablePane(String ISBN) {
		isElementDisplayed("selectProjectToAdd", ISBN);
		logMessage("Project of ISBN::" + ISBN + " is Displayed in Availabe Pane");
	}

	public void SelectTheProjectOnSelectedContent(String ISBN) {
		isElementDisplayed("ConformProject", ISBN);
		clickUsingJS(element("ConformProject", ISBN));
		wait.hardWait(1);
	}

	public void VerifyProjectDisplayedInSelectedPane(String ISBN) {
		isElementDisplayed("ConformProject", ISBN);
		logMessage("Project of ISBN::" + ISBN + " IsDisplayed on Selected Pane...");
		wait.hardWait(1);
	}

	public void VerifyProjectNotDisplayedInSelectedPane(String ISBN) {
		Assert.assertTrue(verifyElementNotDisplayed("ConformProject", ISBN),
				"[Assertion Failed]::Project of ISBN::" + ISBN + " Is Displayed on Selected Pane...");
		;
		logMessage("Project of ISBN::" + ISBN + " Is not Displayed on Selected Pane...");
	}

	public void UnselectTheTheProjectOnSelectedContent() {

		isElementDisplayed("unselect");
		clickUsingJS(element("unselect"));
		logMessage("UnSelect Button Clicked...");

	}

	public void VerifySelectedProjectMovedToavailablepane(String ISBN) {
		Assert.assertTrue(verifyElementNotDisplayed("ConformProject", ISBN),
				"[Assertion Failed]::Selected Content are not Moved To Available pane");
		logMessage("Selected Content Moved To Availablepane");

	}

	public void ClickSelectAllCheckBoxOnSelectedPane() {
		wait.hardWait(1);
		isElementDisplayed("SelectedPaneSelectAll");
		clickUsingJS(element("SelectedPaneSelectAll"));
		logMessage("Select All Clicked...");
	}

	public void ClickSelectAllCheckBoxOnAvailablePane() {
		wait.hardWait(2);
		isElementDisplayed("AvailablePaneSelectAll");
		clickUsingJS(element("AvailablePaneSelectAll"));
		logMessage("Select All Clicked...");
	}

	public void VerifyNoProjectDisplayedInSelectedPane() {
		Assert.assertTrue(verifyElementNotDisplayed("projectDisplayedOnSelectedPane"),
				"All Project are not Removed from Selected Pane.");
		logMessage("All Project Removed from Selected Pane...");
	}

	public void VerifySaveAndCancelButtonOnAddToProject() {
		isElementDisplayed("saveButton");
		isElementDisplayed("saveButton");
		logMessage("save Button Is displayed");

		isElementDisplayed("CloseButton");
		isElementDisplayed("CloseButton");
		logMessage("Close Button Is displayed");

	}

	public void VerifySaveButtonIsDisabled() {
		wait.hardWait(2);
		if (element("saveButton").getAttribute("disabled") == null) {
			logMessage("[Assertion Failed]:: save Button is Enabled.");
			Assert.assertTrue(false);
		} else {

			logMessage("[Assertion Passed]:: save Button button is disabled.");

		}
	}

	public void VerifySaveButtonIsActive() {
		isElementDisplayed("saveButton");
		if (element("saveButton").getAttribute("disabled") == null) {
			logMessage("[Assertion Passed]:: save Button is Enabled.");

		} else {
			logMessage("[Assertion Failed]:: save button is disabled.");
			Assert.assertTrue(false);

		}
	}

	public void ClickSaveButtonOnAddToProjectAndVerifySuccessMsgDisplayed(String ISBN) {
		isElementDisplayed("saveButton");
		clickUsingJS(element("saveButton"));
		logMessage("Save Button Clicked");

		areElementsDisplayed("publishMessage");
		logMessage("Message Displyed::" + element("publishMessage").getAttribute("innerText"));
		Assert.assertTrue(
				"Content was successfully associated with project(s)"
						.equals(element("publishMessage").getAttribute("innerText")),
				"[Assertion Failed]: Contents were not added to projects.");
		logMessage("Contents are added to project::" + ISBN);

	}

	public void clickCancelButtonOnAddToProject() {
		wait.hardWait(1);
		areElementsDisplayed("CloseButton");
		clickUsingJS(element("CloseButton"));
		logMessage("Close Button Clicked!!!!!");

	}

	public void VerifySuccessMessageOnDeleteingTheContent() {
		isElementDisplayed("publishMessage");
		Assert.assertTrue(
				"Content was successfully deleted".equals(element("publishMessage").getAttribute("innerText")),
				"[Assertion Failed]:: Incorrect Message Displayed::"
						+ element("publishMessage").getAttribute("innerText"));
		logMessage("[Assertion Passed]:: Correct Message Displayed::"
				+ element("publishMessage").getAttribute("innerText"));
	}


	public void SelectContentOnContentTab(String AssetName, String ContentType) {
		waitForLoaderToDisappear();
		logMessage(getLocator("CheckAssert", ContentType, ContentType, AssetName, AssetName) + "");
		wait.waitForPageToLoadCompletely();
		Actions actions = new Actions(driver);
		actions.moveToElement(
				driver.findElement(getLocator("CheckAssert", ContentType, ContentType, AssetName, AssetName)));
		wait.waitForPageToLoadCompletely();
		driver.findElement(getLocator("CheckAssert", ContentType, ContentType, AssetName, AssetName)).click();
		logMessage("Asset title::'" + AssetName + "' of content Type::'" + ContentType + "' Checked.");
	}
	
	
	
	
	// ##### Function Related to Upload Content from Content tab #### 
	public void ClickUploadContent() {
		isElementDisplayed("UploadContent");
		clickUsingJS(element("UploadContent"));
		logMessage("Upload Button clicked");
	}

	public void UploadContentFromContentPage(String FileISBN) {

		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN + ".epub";
		} else {
			filePath = "C:/cms Testdata/" + FileISBN + ".epub";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:Enhanced ePub > Full Package");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + ".epub");
		logMessage(FileISBN + ".epub Title of the file");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("Upload");
		click(element("Upload"));
		scrollToTop();
		areElementsDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void UploadContentFromContentPageToDelete(String FileISBN) {

		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN + ".epub";
		}

		else {
			filePath = "C:/cms Testdata/" + FileISBN + ".epub";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:Enhanced ePub > Full Package");

		isElementDisplayed("Title");
		element("Title").sendKeys("Delete Test");
		logMessage(FileISBN + ".epub Title of the file");

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("Upload");
		click(element("Upload"));

		areElementsDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		logMessage("Expected MSG::Content successfully created.");
		logMessage("Displayed MSG::" + msg);
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]:: Content is uploded");
		wait.waitForPageToLoadCompletely();
	}

	public void DeleteCheckedContent(String ContentName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckAssert", ContentName);
		clickUsingJS(element("CheckAssert", ContentName));
		logMessage("Asset selected");

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("Delete");
		clickUsingJS(element("Delete"));
		logMessage("Delete button clicked");
		logMessage("Content deleted");

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("DeleteInput");
		fillText("DeleteInput", "Delete");

		isElementDisplayed("confirmDelete");
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("confirmDelete"));
		logMessage("Confirm Delete Clciked");
		logMessage("[Assertion passed]::Content Deleted!!!!!!");
	}

	public void VerifyPreviewOfRepo(String repo) {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("AssetPreview");
		List<WebElement> PreviewLinks = elements("AssetPreview");
		for (int i = 0; i > PreviewLinks.size(); i++) {
			Assert.assertTrue(PreviewLinks.get(i).getAttribute("src").contains("data:image/jpeg"),
					"[Assertion Failed]:: Previews are not available");
		}
		logMessage("[Assertion Passed]:: Previews of assets are displayed for REPO::" + repo);
	}

	public void VerifyCategoriesOfFacets() {
		areElementsDisplayed("facetslabel");
		List<WebElement> Categories = elements("facetslabel");
		for (int i = 0; i > Categories.size(); i++) {
			Assert.assertTrue(
					Categories.get(i).getAttribute("innerText")
							.contains("Repository Keywords Subjects Title Content State"),
					"[Assertion Failed]::" + Categories.get(i).getAttribute("innerText")
							+ " Is not displayed on Facet Categories");
			logMessage("'" + Categories.get(i).getAttribute("innerText") + "'" + " Is Displayed!!!!");
			wait.hardWait(1);
		}

	}

	public void VerifyallTheModifyLinksInContentTab() {
		isElementDisplayed("ModifyOptions2", "Organized Download");
		isElementDisplayed("ModifyOptions2", "Organized Download");
		logMessage("'Organized Download' is displayed");

		isElementDisplayed("ModifyOptions2", "Download Content");
		logMessage("'Download Content' is displayed");

		isElementDisplayed("ModifyOptions2", "Add to Project");
		logMessage("'Add to Project' is displayed");

		isElementDisplayed("ModifyOptions2", "Delete");
		logMessage("'Delete is dispalyed'");

	}

	public void Verify_Links_Are_Deactivated() throws IOException {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ModifyOptions2", "Organized Download");
		logMessage("'Organized Download' Is Displayed..");
		if (element("ModifyOptions2", "Organized Download").getAttribute("class").contains("disable-btn")) {
			logMessage("[Assertion Passed]:: Organized Download button is disabled!!!!!");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Organized Download Button is not disable");
		}

		isElementDisplayed("ModifyOptions2", "Download Content");
		logMessage("'Download Content' Is Displayed..");
		if (element("ModifyOptions2", "Download Content").getAttribute("class").contains("disable-btn")) {
			logMessage("[Assertion Passed]:: Download Content button is disabled!!!!!");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Download Content Button is not disable");
		}

		isElementDisplayed("ModifyOptions2", "Add to Project");
		logMessage("'Add to Project' Is Displayed..");
		if (element("ModifyOptions2", "Add to Project").getAttribute("class").contains("disable-btn")) {
			logMessage("[Assertion Passed]:: Add to Project button is disabled!!!!!");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Add to Project Button is not disable");
		}

		isElementDisplayed("ModifyOptions2", "Delete");
		logMessage("'Delete' Is Displayed..");
		if (element("ModifyOptions2", "Delete").getAttribute("class").contains("disable-btn")) {
			logMessage("[Assertion Passed]:: Delete button is disabled!!!!!");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Delete Button is not disable");
		}

		ClickOrganizedDownload();
		VerifyOrganizedDownloadPopUpClosed();

		clickDownloadContent();
		VerifyDonloadNotStarted();

		ClickAddToProject();
		VerifyAddToProjectPopUpNotDisplayed();

		clickDeleteContentOnContentTab();
		VerifyDeletePopupNotDisplayed();

	}

	private void VerifyDonloadNotStarted() {
		Assert.assertTrue(verifyElementNotDisplayed("Loader"));
		logMessage("Download is Not Started..");
		refreshPage();
		waitForLoaderToDisappear();

	}

	public void Verify_Links_Are_Activated() {

		isElementDisplayed("ModifyOptions2", "Organized Download");
		logMessage("'Organized Download' Is Displayed..");
		if (element("ModifyOptions2", "Organized Download").getAttribute("class").contains("disable-btn")) {
			Assert.assertTrue(false, "[Assertion Failed]:: Organised Download Button is disable!!!!");
			return;
		} else {
			logMessage("[Assertion Passed]:: Organised Download Button is Activated!!!!!");

		}

		isElementDisplayed("ModifyOptions2", "Download Content");
		logMessage("'Download Content' Is Displayed..");
		if (element("ModifyOptions2", "Download Content").getAttribute("class").contains("disable-btn")) {
			Assert.assertTrue(false, "[Assertion Failed]:: Download Content Button is disable!!!!");
			return;
		} else {
			logMessage("[Assertion Passed]:: Download Content Button is Activated!!!!!");
		}

		isElementDisplayed("ModifyOptions2", "Add to Project");
		logMessage("'Add to Project' Is Displayed..");
		if (element("ModifyOptions2", "Add to Project").getAttribute("class").contains("disable-btn")) {
			Assert.assertTrue(false, "[Assertion Failed]:: Add to Project Button is disable!!!!");
			return;
		} else {
			logMessage("[Assertion Passed]:: Add to Project Button is Activated!!!!!");
		}

		isElementDisplayed("ModifyOptions2", "Delete");
		logMessage("'Delete' Is Displayed..");
		if (element("ModifyOptions2", "Delete").getAttribute("class").contains("disable-btn")) {
			Assert.assertTrue(false, "[Assertion Failed]:: Delete Button is disable!!!!");
			return;
		} else {
			logMessage("[Assertion Passed]:: Delete Button is Activated!!!!!");

		}

		ClickOrganizedDownload();
		VerifyOrganizedDownloadPopUp();
		clickCancelButtonOnOrganizedDownload();

		ClickAddToProject();
		VerifyAddtoProjectpopUp();
		clickCancelButtonOnAddToProject();

		clickDeleteContentOnContentTab();
		VerifyDeletePopupDisplayed();
		clickcancelButtonOnDeleteContent();

	}

	private void clickcancelButtonOnDeleteContent() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("xbutton");
		clickUsingJS(element("xbutton"));
		logMessage("Close Button Clicked!!!!!");

	}

	public void VerifyOrganizedDownloadPopUp() {
		isElementDisplayed("FinishButton");
		logMessage("[Assertion Passed]:: Organised Download PopUp Displayed");

	}

	public void verifyFinishAndCancelButtonAreDisplayed() {

		isElementDisplayed("FinishButton");
		logMessage("Finish button Is Dispalyed..");
		isElementDisplayed("CloseButton");
		logMessage("Close Button Is Dispalyed..");
	}

	public void clickFinishButtonOnOrganizedDownload() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("FinishButton");
		clickUsingJS(element("FinishButton"));
		logMessage("Finish button Clicked!!!!!");

	}

	public void clickCancelButtonOnOrganizedDownload() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("CloseButton");
		clickUsingJS(element("CloseButton"));
		logMessage("Close Button Clicked!!!!!");

	}

	public void ClickCloseButton() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("CloseButton");
		clickUsingJS(element("CloseButton"));
		logMessage("Close Button Clicked!!!!!");
	}
	

	public void VerifyOrganizedDownloadPopUpClosed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("selectAllCheckBox"),
				"[Assertion Failed]::Organised Download Pop Up Is Displayed");
		logMessage("Organised Download Pop Up Is Closed...");
	}

	

	public void selectAllInOrganizedDownload() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("selectAllCheckBox");
		waitAndClick("selectAllCheckBox");
	}
	
	

	public void clickDeleteContentOnContentTab() {

		isElementDisplayed("Delete");
		clickUsingJS(element("Delete"));
		logMessage("Delete button clicked");
	}

	public void EnterDeleteToDeleteContent() {
		wait.hardWait(2);
		areElementsDisplayed("DeleteInput");
		fillText("DeleteInput", "Delete");
		wait.waitForPageToLoadCompletely();
	}

	public void ClickConformDelete() {
		isElementDisplayed("confirmDelete");
		clickUsingJS(element("confirmDelete"));
		logMessage("Confirm Delete Clciked");
		logMessage("[Assertion passed]::Content Deleted!!!!!!");

		isElementDisplayed("ContentAddedMsg");
		logMessage("Message Dispaled::" + element("ContentAddedMsg").getAttribute("innerText"));
	}

	public void VerifyResultNumberDropDown() {
		isElementDisplayed("resultNo");
		logMessage("Result Number Is Displayed..");
		waitForLoaderToDisappear();
	}

	public void SelectNumberFromResultDropDown(String count) {
		isElementDisplayed("resultNo");
		selectTextFromDropDown("resultNo", count);
		logMessage(count + " Selected in ResultDropDown");
		waitForLoaderToDisappear();

	}

	public void VerifyCorrectNumberOfContentAreDisPlayed(String Count) {
		wait.hardWait(4);
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("verifyAssert");
		List<WebElement> AssertName = elements("verifyAssert");
		logMessage("Total Assert = " + AssertName.size());
		Assert.assertTrue(AssertName.size() == Integer.parseInt(Count),
				"[Assertion Failed]:: Content Are not According To the Value Selected In Result DropDown");
		logMessage("[Assertion Passed]:: Number of Content are According To the Value Selected In Result DropDown");

	}

	public void VerifySortByDropDownIsDisplayed() {
		isElementDisplayed("SortBy");
		isElementDisplayed("SortBy");
		logMessage("Sort by is Displayed...");

	}

	public void sortBy(String Type) {
		isElementDisplayed("SortBy");
		clickUsingJS(element("SortBy"));
		logMessage("SortBy Clciked");
		selectTextFromDropDown("SortBy", Type);
		logMessage("'" + Type + "' is Selected..");
		waitForLoaderToDisappear();
	}

	public void verifyAlltheOptionsInSortBy() {
		areElementsDisplayed("SortBy");
		clickUsingJS(element("SortBy"));
		logMessage("SortBy Clciked");
		selectTextFromDropDown("SortBy", "Title");
		logMessage("'Title' is Displyed");
		wait.hardWait(2);

		selectTextFromDropDown("SortBy", "Content Type");
		logMessage("'Content Type' is Displyed");
		wait.hardWait(2);

		selectTextFromDropDown("SortBy", "Repository");
		logMessage("'Repository' is Displyed");
		wait.hardWait(2);

		selectTextFromDropDown("SortBy", "Modified");
		logMessage("'Modified' is Displyed");
		wait.hardWait(2);

	}

	public void VerifyContentPageAsGridViewAndListView() {
		isElementDisplayed("GridViewCheck");
		isElementDisplayed("GridViewCheck");
		logMessage("Grid View Is Available");

		isElementDisplayed("ListView");
		isElementDisplayed("ListView");
		logMessage("List View Is Available");

	}

	public void clickListView() {
		wait.hardWait(2);
		isElementDisplayed("ListView");
		isElementDisplayed("ListView");
		// waitForElementToBeClickable(element("ListView"));
		clickUsingJS(element("ListView"));
		logMessage("List View Clicked");
		waitForLoaderToDisappear();
	}

	public void VerifyBackAndForthNavigationpaginationBar() {
		scrollToBottom();
		isElementDisplayed("navigate", "2");
		clickUsingJS(element("navigate", "2"));
		waitForLoaderToDisappear();
		logMessage("page number 2 clicked... Able To move Forword from pagination Bar");

		isElementDisplayed("navigate", "1");
		clickUsingJS(element("navigate", "1"));
		waitForLoaderToDisappear();
		logMessage("page number 1 clicked... Able To move Backword from pagination Bar");

	}

	public void NavigateToPage(String Number) {
		wait.hardWait(1);
		scrollToBottom();
		isElementDisplayed("navigate", Number);
		click(element("navigate", Number));
		logMessage("page number " + Number + " clicked... Able To move from pagination Bar");
		waitForLoaderToDisappear();
	}

	public void VerifyConformDeleteButtonDisabled() {
		wait.hardWait(2);
		if (element("confirmDelete").getAttribute("disabled") == null) {
			logMessage("[Assertion Failed]:: Confirm Delete Button is Enabled.");
			Assert.assertTrue(false);
		} else {

			logMessage("[Assertion Passed]:: Confirm Delete button is disabled.!!!!");

		}

	}

	public void VerifyConformDeleteButtonActivated() {
		isElementDisplayed("confirmDelete");
		if (element("confirmDelete").getAttribute("disabled") == null) {
			logMessage("[Assertion Passed]:: confirm Delete Button is Enabled.");

		} else {
			logMessage("[Assertion Failed]:: confirm Delete button is disabled.");
			Assert.assertTrue(false);

		}
	}

	public void ClickOpenAssertOnContentTab() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("OpenAsset");
		hover(element("OpenAsset"));
		wait.waitForPageToLoadCompletely();
		click(element("OpenAsset"));
		logMessage("View Icon Is Clicked..");
	}

	public void VerifyThumbnailViewIsWorking() {
		List<WebElement> ProjectLink = elements("ThumbnailView");
		waitForElementToBeClickable(ProjectLink.get(0));
		clickUsingJS(ProjectLink.get(0));
		isElementDisplayed("ContentTitle");
		String view = element("ContentTitle").getAttribute("innerText");
		Assert.assertTrue(view.contains("Content View"), "[Assertion FAILED]:User cannot navigate to Content View");
	}
	
	public void verifyUserIsNotNavigatedToContentView() {
		Assert.assertTrue(verifyElementNotDisplayed("ContentTitle"), "[Assertion Failed]:: User is Navigated to Content View");
		logMessage("[Assertion Passed]:: User is Not Navigated to Content View");
	}

	public void ClickGridViewCheck() {

		wait.hardWait(3);
		isElementDisplayed("GridViewCheck");
		isElementDisplayed("GridViewCheck");
		clickUsingJS(element("GridViewCheck"));
		logMessage("Grid View Clicked");

	}

	public void VerifyOnGridView() {
		areElementsDisplayed("ThumbnailView");
		logMessage("User in on Grid View..");
	}

	public void VerifyOnListView() {
		Assert.assertTrue(verifyElementNotDisplayed("ThumbnailView"), "[Assertion Failed]:: List view Not Displayed..");
	}

	public void VerifyGridViewButtonToolTip() {
		isElementDisplayed("GridView");
		hover(element("GridView"));
		isElementDisplayed("ViewToolTip", "Grid View");

	}

	public void VerifyListViewButtonToolTip() {
		isElementDisplayed("ListView");
		hover(element("ListView"));
		isElementDisplayed("ViewToolTip", "List View");

	}

	public void VerifyAddToProjectPopUpNotDisplayed() {
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("saveButton"),
				"[Assertion Failed::Add To Project PopUp is Displayed");
		logMessage("Add To Project PopUp Not Displayed.");
	}

	public void clickOnFacetLinks() {
		isElementDisplayed("link_facet", "Statistics");
		clickUsingJS(element("link_facet", "Statistics"));
		logMessage("Statistics link clicked");
		waitForLoaderToDisappear();

		isElementDisplayed("link_facet", "Not added to Frost");
		clickUsingJS(element("link_facet", "Not added to Frost"));
		logMessage("Not added to Frost link clicked");
		waitForLoaderToDisappear();

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("textVerify");
		isElementDisplayed("textVerify");
		logMessage("[Assertion Passed]:: Facet link  navigate to desired page");
	}

	public void VerifyCorrectMessageOnOrganisedDownload(String organisedDownloadMsg, String count) {
		StringBuilder organisedDownloadMssage = new StringBuilder(organisedDownloadMsg);
		organisedDownloadMssage.replace(14, 16, count + " ");
		logMessage("Expected Message::" + organisedDownloadMssage);
		organisedDownloadMsg = organisedDownloadMssage.toString();
		isElementDisplayed("DownloadStart");
		String Message = element("DownloadStart").getAttribute("innerText");
		Assert.assertTrue(organisedDownloadMsg.equals(Message),
				"[Asserion Failed]:: Correct Message Not Displayed::" + Message);
		logMessage("[Asserion Passed]:: Correct Message Displayed::" + Message);

	}

	public void SelectMultipleContentToDownload(String Count) {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("contentSelectCheckBox");
		wait.hardWait(1);
		List<WebElement> checkBoxLink = elements("contentSelectCheckBox");
		for (int i = 0; i < Integer.parseInt(Count); i++) {
			wait.hardWait(1);
			hover(checkBoxLink.get(i));
			checkBoxLink.get(i).click();
			logMessage(i + 1 + " Content Selected..");
		}
	}

	public void SelectAllTheContentOnPageManually() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("contentSelectCheckBox");
		wait.hardWait(1);
		List<WebElement> checkBoxLink = elements("contentSelectCheckBox");
		for (int i = 0; i < checkBoxLink.size(); i++) {
			wait.hardWait(1);
			hover(checkBoxLink.get(i));
			checkBoxLink.get(i).click();
			logMessage(i + 1 + " Content Selected..");
		}
	}

	public void SelectMultipleContentToDownloadGridView(String Count) {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		areElementsDisplayed("AssetCheckBoxGridView");
		wait.hardWait(1);
		List<WebElement> checkBoxLink = elements("AssetCheckBoxGridView");
		for (int i = 0; i < Integer.parseInt(Count); i++) {
			wait.hardWait(1);
			hover(checkBoxLink.get(i));
			checkBoxLink.get(i).click();
			logMessage(i + 1 + " Content Selected..");
		}
	}

	public void VerifyOneProjectDisplayed() {
		areElementsDisplayed("ProjectDisplayed");
		if (elements("ProjectDisplayed").size() == 1) {
			logMessage("[Assertion Passed]:: Only One Project Is Displayed...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: More than One Project Is Displayed...");
		}

	}

	public void VerifyColourAndCrossIconOnMessageDisplayed() {
		isElementDisplayed("DownloadStart");
		String TextColour;
		String BackgroundColour;
		TextColour = element("DownloadStart").getCssValue("color");
		BackgroundColour = element("DownloadStart").getCssValue("background-color");
		logMessage("Text Colour::" + TextColour + " " + "BackgroundColour::" + BackgroundColour);
		if (TextColour.equals("rgba(60, 118, 61, 1)") && BackgroundColour.equals("rgba(223, 240, 216, 1)")) {
			logMessage("[Assertion Passed]:: Correct Background And Text Colour Are Shown");
		} else {
			logMessage("[Assertion Failed]:: Inorrect Background And Text Colour Are Shown");
			Assert.assertTrue(false);
		}
		isElementDisplayed("CrossIcon");
		logMessage("[Assertion Passed]:: Corss Icon Is Displayed...");
	}

	public void VerifyThumnailImagesAreDisplayed() {
		areElementsDisplayed("DamRepoImages");
		List<WebElement> Images = elements("DamRepoImages");
		for (int i = 0; i < Images.size(); i++) {
			wait.hardWait(1);
			String SRC = Images.get(i).getAttribute("src");
			if (SRC.contains("img/blank") || SRC == null) {
				Assert.assertTrue(false, "[Assertion Failed]:: Thumbnail Image For The DAM Content Are Not Shown...");
			} else {
				logMessage("[Assertion Passed]:: Thumbnail Image For The DAM Content is Displayed..");
			}
		}
	}

	public void clickSelectAllOnContentTab() {
		wait.hardWait(3);
		isElementDisplayed("SelectAllcontentCheckBox");
		hover(element("SelectAllcontentCheckBox"));
		wait.waitForElementToBeClickable(element("SelectAllcontentCheckBox"));
		click(element("SelectAllcontentCheckBox"));
		logMessage("Select All Check Box Clicked..");
		waitForLoaderToDisappear();
	}

	public void clickSelectAllOnContentTabGridView() {
		wait.hardWait(3);
		isElementDisplayed("SelectAllContentGridView");
		hover(element("SelectAllContentGridView"));
		clickUsingJS(element("SelectAllContentGridView"));
		logMessage("Select All Check Box Clicked..");
	}

	public void VerifyDeletePopupDisplayed() {
		isElementDisplayed("confirmDelete");
		isElementDisplayed("confirmDelete");
		logMessage("Delete PopUp is Displayed...");

	}

	public void VerifyDeletePopupNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("DeleteContentPopUp"),
				"[Assertion Failed:]:Delete PopUp is Displayed...");
		logMessage("Delete PopUp is Not Displayed...");
	}

	private File getLatestFilefromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;
	}

	public void createFolderInDirectory(String folderName) {
		logMessage("Working Directory = " + System.getProperty("user.dir") + "\\src\\test\\resources");
		String downloadPath = System.getProperty("user.dir") + "\\src\\test\\resources";
		File dir = new File(downloadPath + "/" + folderName);
		if (dir.exists()) {
			logMessage(folderName + " Folder has already exists in " + downloadPath);
		} else {
			boolean isDirectoryCreated = dir.mkdir();
			if (isDirectoryCreated)
				logMessage("Directory successfully created: " + dir);
			else
				logMessage("Directory was not created successfully: " + dir);
		}
	}

	public void clearFilesFromFolder(String folderName) throws IOException {
		try {
			String downloadPath = System.getProperty("user.dir") + "\\src\\test\\resources";
			File dir = new File(downloadPath + "/" + folderName);
			FileUtils.cleanDirectory(dir);
			logMessage("All files from " + dir + " has been deleted");
		} catch (Exception e) {
			logMessage("File were not deleted..");
		}
	}

	public void VerifyDownloadIsStartedFromContantTab() throws UnknownHostException {
		isElementDisplayed("FileNamewithOutSearch");
		String FileName = element("FileNamewithOutSearch").getAttribute("innerText");
		wait.hardWait(5);
		String DownloadPath = System.getProperty("user.dir") + "\\ScoresImportExport";
		logMessage("Download Path::" + DownloadPath);
		File getLatestFile = getLatestFilefromDir(DownloadPath);
		String LatestFileName = getLatestFile.getName();
		logMessage("Latest File Downloaded::" + LatestFileName);
		logMessage("File Downloaded::" + FileName);
		if (LatestFileName.contains(FileName.substring(0, FileName.indexOf(".")))) {
			logMessage("File Download has been Started::" + FileName);
		} else {
			Assert.assertTrue(false, "INCORRECT FILE NAME IS DISPLAYED::" + FileName);
		}
	}

	public void VerifyDownloadIsStartedFromContantTab(String FileName) {
		wait.hardWait(5);
		String DownloadPath = System.getProperty("user.dir") + "\\ScoresImportExport";
		File getLatestFile = getLatestFilefromDir(DownloadPath);
		String LatestFileName = getLatestFile.getName();
		logMessage("Latest File Downloaded::" + LatestFileName);
		logMessage("File Downloaded::" + FileName);
		if (LatestFileName.contains(FileName.substring(0, FileName.indexOf(".")))) {
			logMessage("File Download has been Started::" + FileName);
		} else {
			Assert.assertTrue(true, "INCORRECT FILE NAME IS DISPLAYED::" + FileName);
		}
	}

	public void VerifySubtypeIsDisplayed() {
		List<WebElement> contents = elements("CheckContentType");
		for (int i = 0; i < contents.size(); i++) {
			String Text = contents.get(i).getAttribute("innerText");
			logMessage("Content displayed::" + Text);
			if (Text.startsWith("Enhanced") || Text.startsWith("Flat")) {
				if (contents.get(i).getAttribute("innerText").contains(">")
						&& !(Text.substring(Text.indexOf('>'), Text.length() - 1)).trim().equals(null)) {
					logMessage("[Assertion Passed]:: Subtype for content is displayed...");
				} else {
					Assert.assertTrue(false, "[Assertion failed]:: Subtype for content is not displayed...");
				}
			}
		}
	}

	public void VerifyContentsAreSelectedOnContantTab() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		wait.hardWait(1);
		areElementsDisplayed("contentSelectCheckBox");
		List<WebElement> content = elements("contentSelectCheckBox");
		wait.hardWait(1);
		for (int i = 0; i < content.size(); i++) {
			if (content.get(i).isSelected()) {
				logMessage("Content " + (i + 1) + " Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content " + (i + 1) + " Is Not Selected...");
			}
		}
	}

	public void VerifyContentsAreSelectedOnContantTabGridView() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		wait.hardWait(1);
		areElementsDisplayed("AssetCheckBoxGridView");
		List<WebElement> content = elements("AssetCheckBoxGridView");
		wait.hardWait(1);
		for (int i = 0; i < content.size(); i++) {
			if (content.get(i).isSelected()) {
				logMessage("Content " + (i + 1) + " Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content " + (i + 1) + " Is Not Selected...");
			}
		}
	}

	public void VerifyContentsAreNotSelectedOnContantTab() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		wait.hardWait(1);
		areElementsDisplayed("AssetCheckBox");
		List<WebElement> content = elements("AssetCheckBox");
		wait.hardWait(1);
		for (int i = 0; i < content.size(); i++) {
			if (content.get(i).isSelected()) {
				Assert.assertTrue(false, "[Assertion Failed]::Content " + (i + 1) + " Is Selected...");

			} else {
				logMessage("Content " + (i + 1) + " Is not Selected.....");
			}
		}
	}

	public void VerifyContentsAreNotSelectedOnContantTabGridView() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		wait.hardWait(1);
		areElementsDisplayed("AssetCheckBoxGridView");
		List<WebElement> content = elements("AssetCheckBoxGridView");
		wait.hardWait(1);
		for (int i = 0; i < content.size(); i++) {
			if (content.get(i).isSelected()) {
				Assert.assertTrue(false, "[Assertion Failed]::Content " + (i + 1) + " Is Selected...");

			} else {
				logMessage("Content " + (i + 1) + " Is not Selected.....");
			}
		}
	}

	public void VerifyContentsAreSelected(int TillIndex) {

		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		wait.hardWait(2);
		areElementsDisplayed("AssetCheckBox");
		List<WebElement> content = elements("AssetCheckBox");
		wait.hardWait(1);
		int i;
		for (i = 0; i < TillIndex; i++) {
			if (content.get(i).isSelected()) {
				logMessage("Content " + (i + 1) + " Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content " + (i + 1) + " Is Not Selected...");
			}
		}
	}

	public void VerifyContentsAreSelectedGridView(int TillIndex) {

		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		wait.hardWait(2);
		areElementsDisplayed("AssetCheckBoxGridView");
		List<WebElement> content = elements("AssetCheckBoxGridView");
		wait.hardWait(1);
		int i;
		for (i = 0; i < TillIndex; i++) {
			if (content.get(i).isSelected()) {
				logMessage("Content " + (i + 1) + " Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content " + (i + 1) + " Is Not Selected...");
			}
		}

		try {
			if (content.get(TillIndex).isSelected()) {
				Assert.assertTrue(false, "[Assertion Failed]::" + (i + 1) + " Is Selected...");
			}
		} catch (Exception IndexOutOfBoundsException) {

		}

	}

	public void VerifySelectAllIsUnchecked() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		isElementDisplayed("SelectAllcontentCheckBox");
		wait.hardWait(3);
		logMessage(element("SelectAllcontentCheckBox").getAttribute("class"));
		if (element("SelectAllcontentCheckBox").getAttribute("class").contains("ng-empty")) {
			logMessage("[Assertion Passed]:: Select All input is Unselected..");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Select All input is Selected..");
		}
	}

	public void VerifySelectAllIsUncheckedGridView() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectAllContentGridView");
		wait.hardWait(3);
		logMessage(element("SelectAllContentGridView").getAttribute("class"));
		if (element("SelectAllContentGridView").getAttribute("class").contains("ng-empty")) {
			logMessage("[Assertion Passed]:: Select All input is Unselected..");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Select All input is Selected..");
		}
	}

	public void VerifySelectAllIsChecked() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		isElementDisplayed("SelectAllcontentCheckBox");
		wait.hardWait(3);
		logMessage(element("SelectAllcontentCheckBox").getAttribute("class"));
		if (element("SelectAllcontentCheckBox").getAttribute("class").contains("ng-not-empty")) {
			logMessage("[Assertion Passed]:: Select All input is Selected..");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Select All input is UnSelected..");
		}
	}

	public void VerifySelectAllIsCheckedGridView() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		isElementDisplayed("SelectAllContentGridView");
		wait.hardWait(3);
		logMessage(element("SelectAllContentGridView").getAttribute("class"));
		if (element("SelectAllContentGridView").getAttribute("class").contains("ng-not-empty")) {
			logMessage("[Assertion Passed]:: Select All input is Unselected..");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Select All input is Selected..");
		}
	}

	public void VerifyCountofSelectedAssetOnContantTab(int count) {
		wait.hardWait(1);
		isElementDisplayed("SelectedAssetCount");
		String text = element("SelectedAssetCount").getAttribute("innerText").trim();
		int countDisplay = Integer.parseInt(text.substring(0, text.indexOf(' ')).trim());
		logMessage("Expected Count::" + count);
		logMessage("Count Displayed::" + countDisplay);
		if (count == countDisplay) {
			logMessage("Corrent Count Displayed::" + count);
		} else {
			Assert.assertTrue(false, "Incorrent Count Displayed::" + countDisplay);
		}
	}

	public void VerifyAllDisplayedInAssertCount(String count) {
		wait.hardWait(1);
		isElementDisplayed("SelectedAssetCount");
		String text = element("SelectedAssetCount").getAttribute("innerText").trim();
		logMessage("Text Displayed::" + text);
		Assert.assertTrue(text.contains(count), "Incorrent Count Displayed::" + text);
	}

	public void VerifyContentType(String ContentType) {
		List<WebElement> contents = elements("CheckContentType");
		areElementsDisplayed("CheckContentType");
		for (int i = 0; i < contents.size(); i++) {
			String Text = contents.get(i).getAttribute("uib-tooltip");
			if (Text == null) {
				Text = contents.get(i).getText().trim();
			}
			logMessage("Content displayed::" + Text);
			if (Text.equals(ContentType)) {
				logMessage("Content Type '" + Text + "' is Displayed..");
				Assert.assertTrue(true);
				return;
			}
		}
		Assert.assertTrue(false, "[Assertion Falied]::Content Type '" + ContentType + "' is  Not Displayed..");

	}

	public void VerifyToolTipForEllipsis() {
		waitForLoaderToDisappear();
		areElementsDisplayed("ToolTip");
		List<WebElement> ellipsis = elements("ToolTip");
		for (int tooltip = 0; tooltip < ellipsis.size(); tooltip++) {
			scroll(ellipsis.get(tooltip));
			hover(ellipsis.get(tooltip));
			isElementDisplayed("VeriyTooltipPopUp");
			Assert.assertTrue(
					element("VeriyTooltipPopUp").getAttribute("innerText")
							.equals(ellipsis.get(tooltip).getAttribute("uib-tooltip")),
					"[Assertion Failed]:: Proper Tool Tip Not Displayed Expected::"
							+ ellipsis.get(tooltip).getAttribute("uib-tooltip") + " Displayed::"
							+ element("VeriyTooltipPopUp").getAttribute("innerText"));
		}
	}

	public void VerifyNoContentToDeleteMsgDisplayed() {
		scrollToTop();
		isElementDisplayed("ContentAddedMsg");
		String Msg = element("ContentAddedMsg").getText().trim();
		logMessage("Message Dispaled::" + Msg);
		logMessage("Message Expected:: No content to delete");
		Assert.assertTrue(Msg.equals("No content to delete"), "Incorrect Message Dispaled::" + Msg);
	}

	public void VerifyElvisRepositoryRemoved() {
		assertTrue(verifyElementNotDisplayed("OpenRepository", "Elvis"),
				"[Assertion Failed]::Elvis Repository is Displayed..");
		logMessage("[Assertion Passed]::Elvis Repository is Not Displayed..");

	}

	public void VerifyContentInfoOnGridView() {
		isElementDisplayed("ContentInfo", "Title:");
		logMessage("Title:" + element("ContentInfo", "Title:").getText().trim());

		isElementDisplayed("ContentInfo", "File Name:");
		logMessage("File Name:" + element("ContentInfo", "File Name:").getText().trim());

		isElementDisplayed("ContentInfo", "Content Type:");
		logMessage("Content Type:" + element("ContentInfo", "Content Type:").getText().trim());

		isElementDisplayed("ContentInfo", "Last Updated:");
		logMessage("Last Updated:" + element("ContentInfo", "Last Updated:").getText().trim());
	}

	public void VerifyProjectInfoOnGridView() {
		isElementDisplayed("ProjectInfo", "Author:");
		logMessage("Title:" + element("ProjectInfo", "Author:").getText().trim());

		isElementDisplayed("ProjectInfo", "Title:");
		logMessage("File Name:" + element("ProjectInfo", "Title:").getText().trim());

		isElementDisplayed("ProjectInfo", "Edition:");
		logMessage("Content Type:" + element("ProjectInfo", "Edition:").getText().trim());

		isElementDisplayed("ProjectInfo", "ISBN:");
		logMessage("Content Type:" + element("ProjectInfo", "ISBN:").getText().trim());

	}

	public void verifyHandIconNotDisplayedOnGrayedOutLink() {

		isElementDisplayed("ModifyOptions2", "Organized Download");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Organized Download").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions2", "Organized Download").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Organized Download");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Organized Download").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions3", "Organized Download").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Organized Download");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Organized Download").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions4", "Organized Download").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions2", "Download Content");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Download Content").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions2", "Download Content").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Download Content");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Download Content").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions3", "Download Content").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Download Content");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Download Content").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions4", "Download Content").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions2", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Add to Project").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions2", "Add to Project").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Add to Project").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions3", "Add to Project").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Add to Project").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions4", "Add to Project").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions2", "Delete");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Delete").getCssValue("cursor"));
		Assert.assertTrue(element("ModifyOptions2", "Delete").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Delete");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Delete").getCssValue("cursor"));
		Assert.assertTrue(element("ModifyOptions3", "Delete").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Delete").getCssValue("cursor"));
		Assert.assertTrue(element("ModifyOptions4", "Delete").getCssValue("cursor").trim().equals("not-allowed"));

	}

	public void VerifyAuthorFiledBlankForAssets() {
		areElementsDisplayed("AssetsOnPage");
		List<WebElement> ListOfAssets = elements("AssetsOnPage");
		for (int Asset = 0; Asset < ListOfAssets.size(); Asset++) {
			if (ListOfAssets.get(Asset).getText().trim().length() >= 1) {
				Assert.assertTrue(false, "Author Field is Not Empty for Asset on Content Tab");
			}
		}

	}

	public void VerifyAuthorFiledIsNotBlankForProject() {
		areElementsDisplayed("ProjectOnPage");
		List<WebElement> ListOfAssets = elements("ProjectOnPage");
		for (int Asset = 0; Asset < ListOfAssets.size(); Asset++) {
			if (ListOfAssets.get(Asset).getText().trim().length() < 1
					|| ListOfAssets.get(Asset).getText().trim().equals(" ")) {
				Assert.assertTrue(false, "Author Field is Empty for Project on Content Tab");
			}

		}
	}

	// ############## Facet Functionality ##############

	public void VerifyFacetTitle(String FacetTitle) {
		isElementDisplayed("FacetTitle", FacetTitle);
		logMessage("Facet Title Displayed::" + FacetTitle);
	}

	public void clickOnFacetLinks(String facetType, String facetLink) {
		isElementDisplayed("OpenFacetLink", facetType, facetLink);
		hoverOverElement(element("OpenFacetLink", facetType, facetLink));
		click(element("OpenFacetLink", facetType, facetLink));
		waitForLoaderToDisappear();

	}

	public void verifyFacetLinkIsDisplayed(String facetType, String facetLink) {
		isElementDisplayed("OpenFacetLink", facetType, facetLink);
	}

	public void verifyFacetLinkNotDisplayed(String facetType, String facetLink) {
		Assert.assertTrue(verifyElementNotDisplayed("OpenFacetLink", facetType, facetLink),
				"[Assertion Failed]:: '" + facetLink + "' is Displayed..");
	}

	public void VerifySearchPageLabel(String Label) {
		isElementDisplayed("SeachLabelOnPage", Label);
		logMessage("User navigated to desired Search page.");
	}

	public void verifyOnSeeMorePopup(String facetType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("VerifySeeMorePopup");
		logMessage("See more Popup displayed for::" + element("VerifySeeMorePopup").getText().trim());
		logMessage("See more Popup Expected for::" + facetType);
		Assert.assertEquals(facetType, element("VerifySeeMorePopup").getText().trim(),
				"[Assertion Failed]:: Incorrect Asset Facet Popup Displayeds");

	}
	
	public void VerifyLinkDisplayedOnSeeMorePopup(String Link) {
		isElementDisplayed("ClickListItemOnSeeMore", Link);
	}
	
	public void VerifyLinkNotDisplayedOnSeeMorePopup(String Link) {
		Assert.assertTrue(verifyElementNotDisplayed("ClickListItemOnSeeMore", Link));
	}

	public void OpenLinkOnSeeMorePopupWindow(String facetType) {
		isElementDisplayed("ClickListItemOnSeeMore", facetType);
		hoverOverElement(element("ClickListItemOnSeeMore", facetType));
		click(element("ClickListItemOnSeeMore", facetType));
		waitForLoaderToDisappear();

	}

	public void verifyCorrectCountOfAssetFromSeeMoreLink(String FacetLink) {
		isElementDisplayed("ClickListItemOnSeeMore", FacetLink);
		String Link = element("ClickListItemOnSeeMore", FacetLink).getText().trim();
		String CountDisplayedNextToLink = Link.substring(Link.indexOf('(') + 1, Link.indexOf(')')); // getting the count
																									// of Asset from
																									// Right of Facet
																									// Link
		logMessage("Expected Count::" + CountDisplayedNextToLink);
		click(element("ClickListItemOnSeeMore", FacetLink));
		waitForLoaderToDisappear();
		isElementDisplayed("VerifyCountOnSearchPage", CountDisplayedNextToLink);
	}

	public void verifyOnlyOneFacetLinkDisplayed(String FacetTitle) {
		isElementDisplayed("FacetLinkOrder", FacetTitle);
		if (elements("FacetLinkOrder", FacetTitle).size() != 1) {
			Assert.assertTrue(false, "[Assertion Failed]::More Than one Facet Link Displayed..");
		}
	}
	
	public void verifyAllContentTypesAreDisplayedOnSeeMorePopup() {
		Map<String, Object> courses = YamlReader.getYamlValues("TypesOfContent");
		for(Map.Entry<String,Object> entry: courses.entrySet()){
			isElementDisplayed("ClickListItemOnSeeMore", entry.getValue().toString()+" (");
			logMessage(entry.getValue().toString()+" is Displayed on See more popup.");
		}
	}

	public void verifyContentTypeDisplayedForAsset(String ContentType) {
		areElementsDisplayed("VerifyContentType");
		for (int content = 0; content < elements("VerifyContentType").size(); content++) {
			Assert.assertEquals(elements("VerifyContentType").get(content).getText().trim(), ContentType,
					"[Assertion Failed]::Content Type Displayed::"
							+ elements("VerifyContentType").get(content).getText());
		}
	}
	
	public void enterTextFilterSearchBar(String Text) {
		isElementDisplayed("FacetSearchBar");
		click(element("FacetSearchBar"));
		sendKeys(element("FacetSearchBar"), Keys.chord(Text));
		element("FacetSearchBar").sendKeys(Keys.BACK_SPACE);
		wait.waitForPageToLoadCompletely();
	}

	public void verifyFacetLinkArrangedInDescendingOrder(String facetType) {
		areElementsDisplayed("FacetLinkOrder", facetType);
		List<WebElement> links = elements("FacetLinkOrder", facetType);
		int previousSize = 0;
		for (int link = 0; link < links.size() - 1/* (To remove +See more Link) */; link++) {
			String LinkText = links.get(link).getText();
			if (link == 0) {
				previousSize = Integer.parseInt(
						links.get(link).getText().substring(LinkText.indexOf('(') + 1, LinkText.lastIndexOf(')')));
			} else {
				int Currentsize = Integer.parseInt(
						links.get(link).getText().substring(LinkText.indexOf('(') + 1, LinkText.lastIndexOf(')')));
				/*
				 * logMessage("previous Size::"+previousSize);
				 * logMessage("Currrent Size::"+Currentsize);
				 */
				if (previousSize < Currentsize) {
					Assert.assertTrue(false, "[Assertion Failed]::Facet Links are not Arranged In Descending Order");
				}
				previousSize = Currentsize;
			}
		}
	}

	public void VerifyFavoriteProjectCount(String Count) {
		isElementDisplayed("FavProjectCount");
		String text = element("FavProjectCount").getText();
		int CountDisplayed = Integer.parseInt(text.substring(text.indexOf('(') + 1, text.lastIndexOf(')')));
		logMessage("Project Count Displayed::" + CountDisplayed);
		logMessage("Project Count Expected ::" + Count);
		Assert.assertEquals(Integer.parseInt(Count), CountDisplayed);
	}

	public void VerifyFavoriteProjectCountIsNotZero() {
		isElementDisplayed("FavProjectCount");
		String text = element("FavProjectCount").getText();
		int CountDisplayed = Integer.parseInt(text.substring(text.indexOf('(') + 1, text.lastIndexOf(')')));
		logMessage("Project Count Displayed::" + CountDisplayed);
		if (CountDisplayed <= 0) {
			Assert.assertTrue(false, "[Assertion Failed]::Project count are Reset to Zero");
		}
	}

	public void clickAreaNextToFileIcon() {
		isElementDisplayed("ColoumFile");
		hoverOverElement(element("ColoumFile"));
		wait.waitForPageToLoadCompletely();
		click(element("ColoumFile"));
		
	}
	
	//################## Favorite Functionality ##############
	
	public void AddProjectToFavoriteFromContentTabListView(String ISBN) {
		waitForLoaderToDisappear();
		isElementDisplayed("FavoriteStatusList", ISBN);
		isElementDisplayed("FavoriteStatusList", ISBN);
		String FavStatus = element("FavoriteStatusList", ISBN).getAttribute("class");
		logMessage(FavStatus);
		if (FavStatus.contains("glyphicon-star-empty")) {
			isElementDisplayed("AddToFavorite", ISBN);
			hoverOverElement(element("AddToFavorite", ISBN));
			wait.waitForPageToLoadCompletely();
			click(element("AddToFavorite", ISBN));
			logMessage("Project With ISBN::" + ISBN + " Is Added To Favorite");
		} else {
			logMessage("Project Is Already Add as Favorite");
		}
	}
	
	public void removeProjectToFavoriteFromContentTabListView(String ISBN) {
		waitForLoaderToDisappear();
		isElementDisplayed("AddToFavorite", ISBN);
		hoverOverElement(element("AddToFavorite", ISBN));
		wait.waitForPageToLoadCompletely();
		click(element("AddToFavorite", ISBN));
	}
	
	public void verifyMessageDisplayedOnFavoriteAdded() {
		isElementDisplayed("FavMarkUnMarkMsg",getData("FavoritesMarkedMsg"));
		logMessage("Message Displayed::"+getData("FavoritesMarkedMsg"));
	}
	
	public void verifyMessageDisplayedOnFavoriteRemoved() {
		isElementDisplayed("FavMarkUnMarkMsg",getData("FavoritesRemovedMsg"));
		logMessage("Message Displayed::"+getData("FavoritesRemovedMsg"));
	}
	
	public void VerifyFavoriteMessageColor() {
		String ColourDisplayed=element("FavMsgColour").getCssValue("color").trim();
		logMessage("Colour Displayed::"+ColourDisplayed);
		Assert.assertTrue(ColourDisplayed.equals("rgba(60, 118, 61, 1)"));
	}
	
	public void verifyFavoriteToasterMessageAppears_For_5_Seconds() {
		isElementDisplayed("FavMsgColour");
		wait.hardWait(5);
		Assert.assertTrue(verifyElementNotDisplayed("FavMsgColour"));
	}
}