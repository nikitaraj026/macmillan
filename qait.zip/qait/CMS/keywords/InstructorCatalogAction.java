package com.qait.CMS.keywords;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class InstructorCatalogAction extends GetPage{
	public InstructorCatalogAction(WebDriver driver) {
		super(driver, "InstructorCatalog");
	}
	
	
	//************ HomePage Action**********//
	
	
	public void SearchforAnProduct(String ISBNorTitle) {
		isElementDisplayed("SearchBox");
		wait.waitForPageToLoadCompletely();
		waitForElementToBeClickable(element("SearchBox"));
		click(element(("SearchBox")));
		fillText("SearchBox", ISBNorTitle);
		element("SearchBox").sendKeys(Keys.ENTER);
		logMessage("User Search for "+ISBNorTitle);
		wait.waitForPageToLoadCompletely();
	}
	
	
	//************** SearchPage Action *******//

	public void verifyUserIsOnSearchPage() {
		isElementDisplayed("SearchPage");
		logMessage("User is on Search Page.");
	}
	
	
	public void ClickBookTitle(String BookTitle) {
		isElementDisplayed("BookTitle",BookTitle);
		wait.waitForPageToLoadCompletely();
		waitForElementToBeClickable(element("BookTitle",BookTitle));
		hover(element("BookTitle",BookTitle));
		click(element("BookTitle",BookTitle));
		logMessage("Clicked on Title "+BookTitle);
		wait.waitForPageToLoadCompletely();
	}
	
	//************* Product Detail Page*********//


	public void VerifyOnProjectDetailPage() {
		isElementDisplayed("ProductDetailPage");
		logMessage("User is on Product Deatil Page.");
		wait.waitForPageToLoadCompletely();
	}


	public void ClickResourcesTab() {
		isElementDisplayed("ProductTabs","Resources");
		click(element("ProductTabs","Resources"));
		logMessage("Resource Tab Clicked..");
		
	}
	
	//******** Resource Tab Page ********//
	
	public void VerifyUserIsOnResourceTab() {
		areElementsDisplayed("ResourceTabPage");
		logMessage("User is on Resource Tab Window..");
	}
	
	public void ExpandResourceType(String ResourceType) {
		isElementDisplayed("ResourceType",ResourceType);
		wait.waitForPageToLoadCompletely();
		hover(element("ResourceType",ResourceType));
		clickUsingJavaScript("ResourceType",ResourceType);
		logMessage(ResourceType+" Clicked Expaned..");
	}
	
	public void ExpandSubResourceType(String ResourceType) {
		isElementDisplayed("SubResourceType",ResourceType);
		wait.waitForPageToLoadCompletely();
		scroll(element("SubResourceType",ResourceType));
		hover(element("SubResourceType",ResourceType));
		clickUsingJavaScript("SubResourceType",ResourceType);
		logMessage(ResourceType+" Clicked Expaned..");
	}
	
	public void VerifyResourceIsDisplayed(String ResourceName) {
		isElementDisplayed("VerifyResource",ResourceName);
		scroll(element("VerifyResource",ResourceName));
		logMessage(ResourceName+" is Displayed..");
		wait.waitForPageToLoadCompletely();
	}
	
	public void ClickLookInside() {
		isElementDisplayed("LookInside");
		scrollToTop();
		hover(element("LookInside"));
		click(element("LookInside"));
		logMessage("Look Inside Cliked..");
	}
	
	public void VerifyResourceOnLookInsideWindow(String ResourceName) {
		isElementDisplayed("VerifyResourceLookInside",ResourceName);
		scroll(element("VerifyResourceLookInside",ResourceName));
		logMessage(ResourceName+" Displayed on Look Inside Window..");
	}
}
