package com.qait.CMS.keywords;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;
import static com.qait.automation.utils.FTPUtil.*;
import static com.qait.automation.utils.XmlParser.*;

public class HotFolderAction extends GetPage {

	public HotFolderAction(WebDriver driver) {
		super(driver, "HotFolder");
	}
	
	public void waitForFileToPickedUpByScheduler(String ftpFolderName, String FileName) {
		Boolean FileStatus=null;
		int Counter=0;
		while(true) {
			Counter++;
			wait.hardWait(10);
			FileStatus=checkFileExistsOnFTP(ftpFolderName, FileName);
			
			if(FileStatus==null) {
				Assert.assertTrue(false, "[Assertion Failed]:: Unable To perform the Operation.");
				return;
			}
			
			else if(FileStatus==false) {
				logMessage("[Assertion Passed]:: File '"+FileName+"' has been picked up by Scheduler.");
				return;
			}
			else if(FileStatus==true) {
				logMessage("File '"+FileName+"' has not been picked up by Scheduler.");
			}
			
			else if(Counter>=90){
				Assert.assertTrue(false, "[Assertion Failed]:: Waited for 15 min, File was not picked up Scheduler");
				return;
			}
			
		}
}
}
