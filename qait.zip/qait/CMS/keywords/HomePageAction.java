package com.qait.CMS.keywords;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.util.List;
import org.testng.Assert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.PropFileHandler;

public class HomePageAction extends GetPage {
	public HomePageAction(WebDriver driver) {
		super(driver, "HomePage");
	}

	public void clickLogOut() {
		isElementDisplayed("logOut");
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("logOut"));
		logMessage("user loged out");
	}

	public void clickUserName() {
		refreshPage();
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		scrollToTop();

		isElementDisplayed("username");
		hover(element("username"));
		wait.hardWait(1);
		wait.waitForElementToBeClickable(element("username"));
		click(element("username"));
		logMessage("user name clicked");
	}

	public String GetCurrentLink() {
		wait.hardWait(2);
		return getCurrentURL();
	}

	public void verifyOnhomePage(String homePageLink) {
		waitForLoaderToDisappear();
		isElementDisplayed("DashbordDispaly");
		wait.hardWait(1);
		String CurrentUrl;
		CurrentUrl = getCurrentURL();
		logMessage(CurrentUrl);
		logMessage(homePageLink);
		Assert.assertTrue(CurrentUrl.contains(homePageLink),
				"[ASSERTION FAILED]:User is not able to navigate to homepage");
		logMessage("[ASSERTION PASSED]::User LOGGED IN,,Is on Home page!!!");

	}

	public void ClickEditAccount() {
		wait.waitForPageToLoadCompletely();
		scrollToTop();
		isElementDisplayed("EditAccount");
		isElementDisplayed("EditAccount");
		wait.waitForElementToBeClickable(element("EditAccount"));
		element("EditAccount").click();
		logMessage("Edit acoount clicked");

	}

	public void ClickDashBord() {
		// waitForElementToBeClickable(element("DashbordTab"));
		waitForLoaderToDisappear();
		scrollToTop();
		isElementDisplayed("DashbordTab");
		clickUsingJS(element("DashbordTab"));
		logMessage("DashBord clicked");
		isElementDisplayed("DashbordDispaly");
	}

	public void clickProjectTab() {
		scrollToTop();
		waitForLoaderToDisappear();
		isElementDisplayed("ProjectTab");
		click(element("ProjectTab"));
		logMessage("ProjectTab clicked");
		waitForLoaderToDisappear();
	}

	public void VerfiyFullNameAndEmailIDIsDisplayed() {
		wait.hardWait(2);
		isElementDisplayed("NameUser");
		String userNameClass = element("NameUser").getAttribute("value");
		logMessage("USER NAME: " + userNameClass);
		String userEmail = element("userEmail").getAttribute("value");
		logMessage("Email:" + userEmail);
	}

	public void ClickResetPassword() {
		isElementDisplayed("resetPassword");
		scroll(element("resetPassword"));
		hover(element("resetPassword"));
		wait.waitForPageToLoadCompletely();
		click(element("resetPassword"));
		logMessage("Reset password clicked");

	}

	public void NavigateToDAM() {
		isElementDisplayed("WorkbenchLink", "DAM (OpenText OTMM)");
		String href = element("WorkbenchLink", "DAM (OpenText OTMM)").getAttribute("href");
		Assert.assertTrue(href.contains("http://"), "[ASSERTION FAILED]: user cant navigate to OpenText OTMM");
		logMessage("User can navigate to DAM Page");
	}

	public void NavigateToRight() {
		isElementDisplayed("WorkbenchLink", "Rights (Lumina)");

		String href = element("WorkbenchLink", "Rights (Lumina)").getAttribute("href");
		Assert.assertTrue(href.contains("https://"), "[ASSERTION FAILED]: user cant navigate to Rights (Lumina)");
		logMessage("User can navigate to Right Page");
	}

	public void NavigateToPDX() {
		isElementDisplayed("WorkbenchLink", "PDX");
		String href = element("WorkbenchLink", "PDX").getAttribute("href");
		Assert.assertTrue(href.contains("http://pdxpx"), "[ASSERTION FAILED]: user cant navigate to PDX");
		logMessage("User can navigate to PDX Page");
	}

	public void NavigateToSiteBuilder() {
		isElementDisplayed("WorkbenchLink", "SiteBuilder");
		String href = element("WorkbenchLink", "SiteBuilder").getAttribute("href");
		Assert.assertTrue(href.contains("http://stage.sitebuilder"),
				"[ASSERTION FAILED]: user cant navigate to sitebuilder");
		logMessage("User can navigate to SiteBuilder Page");
	}
	
	public void verifyUserIsNotNavigatedToProjectView() {
		Assert.assertTrue(verifyElementNotDisplayed("ProjectViewTitle"), "[Assertion Failed]:: User is Navigated on Project View.");
	}

	public void ClickContentTab() {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ContentTab");
		hover(element("ContentTab"));
		wait.hardWait(1);
		clickUsingJS(element("ContentTab"));
		logMessage("Content Tab clicked");
		areElementsDisplayed("contentlabel");
		waitForLoaderToDisappear();
	}

	public void ViewAssetsOfRepository(String RepoName) {
		// refreshPage();
		wait.hardWait(2);
		isElementDisplayed("Repo", RepoName);
		clickUsingJS(element("Repo", RepoName));
		logMessage(RepoName + " Repository Clicked");
		wait.hardWait(2);
		List<WebElement> AssertName = elements("verifyAssert");
		logMessage("Total Assert = " + AssertName.size());
		for (int j = 1; j <= AssertName.size(); j++) {
			String text = element("verifyAssert", Integer.toString(j)).getAttribute("innerText");
			Assert.assertTrue(text.contains(RepoName), "[ASSERTION FAILED]: Non " + RepoName + " Assert displayed");
		}

	}

	public void ClickOpenRepository(String RepoName) {
		waitForLoaderToDisappear();
		isElementDisplayed("Repo", RepoName);
		clickUsingJS(element("Repo", RepoName));
		waitForLoaderToDisappear();
		logMessage(RepoName + " Repository Clicked");
		wait.hardWait(2);

	}

	public void ClickNonCMSAssert(String RepoName) {
		waitAndClick("Repo", RepoName);
		logMessage(RepoName + " link clicked");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();

	}

	public void UplaodTheContent(String contentIndex, String ProjectISBNNO) {
		isElementDisplayed("SelectNonCMSAssert", contentIndex);
		// waitForElementToBeClickable(element("SelectNonCMSAssert",
		// contentIndex));
		wait.hardWait(3);
		executeJavascript("document.querySelector('.table-condensed tbody tr:nth-child(" + contentIndex
				+ ") td:nth-child(1) div input').click()");
		logMessage("Content Selected");

		// waitForElementToBeClickable(element("AddToProject"));
		isElementDisplayed("AddToProject");
		clickUsingJS(element("AddToProject"));
		logMessage("Add to project button clicked");

		isElementDisplayed("SearchInputTag");
		clickUsingJS(element("SearchInputTag"));
		String Isbnc = Keys.chord(ProjectISBNNO);
		element("SearchInputTag").sendKeys(Isbnc);
		logMessage("ISBN Entered into Search bar");
		clickUsingJS(element("submitButton"));
		logMessage("Search button clicked");
		wait.hardWait(3);

		// waitForElementToBeClickable(element("SelectProject",ProjectISBNNO));
		// clickUsingJS(element("SelectProject",ProjectISBNNO));

		String InputStatus = element("SelectProject", ProjectISBNNO).getAttribute("ng-disabled");
		logMessage("InputStatus=" + InputStatus);
		wait.hardWait(2);
		if (InputStatus.equals("false")) {
			isElementDisplayed("SelectProject", ProjectISBNNO);
			clickUsingJS(element("SelectProject", ProjectISBNNO));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.hardWait(2);
			isElementDisplayed("ConformProject", ProjectISBNNO);
			// waitForElementToBeClickable(element("ConformProject",ProjectISBNNO));
			clickUsingJS(element("ConformProject", ProjectISBNNO));
			logMessage("Selected Project checked");
			wait.hardWait(2);
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			isElementDisplayed("ContentAddedMsg");
			String msg = element("ContentAddedMsg").getAttribute("innerText");
			Assert.assertTrue(msg.equals("Content was successfully associated with project(s)"),
					"[Assertion Failed]:Content not associated with project");
			logMessage("[Assertion Passed]: Content was associated with project");
		} else {
			wait.hardWait(2);
			isElementDisplayed("ConformProject", ProjectISBNNO);
			// waitForElementToBeClickable(element("ConformProject",ProjectISBNNO));
			clickUsingJS(element("ConformProject", ProjectISBNNO));
			logMessage("Selected Project checked");
			wait.hardWait(2);
			isElementDisplayed("unselect");
			// waitForElementToBeClickable(element("unselect"));
			clickUsingJS(element("unselect"));
			logMessage("Unselect clicked");
			wait.hardWait(2);
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.hardWait(3);
			isElementDisplayed("SelectProject", ProjectISBNNO);
			clickUsingJS(element("SelectProject", ProjectISBNNO));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.hardWait(2);
			// waitForElementToBeClickable(element("ConformProject",ProjectISBNNO));
			isElementDisplayed("ConformProject", ProjectISBNNO);
			clickUsingJS(element("ConformProject", ProjectISBNNO));
			logMessage("Selected Project checked");
			wait.hardWait(2);
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			isElementDisplayed("ContentAddedMsg");
			String msg = element("ContentAddedMsg").getAttribute("innerText");
			Assert.assertTrue(msg.equals(" Content was successfully associated with project(s)"),
					"[Assertion Failed]:Correct Message not displayed");
			logMessage("[Assertion Passed]: Content was associated with project");
		}

	}

	public void ClickAllProjectLink() {

		// waitForElementToBeClickable(element("SearchAllProject"));
		isElementDisplayed("SearchAllProject");
		clickUsingJS(element("SearchAllProject"));
		logMessage("home page Link clicked");
		wait.hardWait(2);
		String CurrentUrl;
		CurrentUrl = getCurrentURL();
		Assert.assertTrue(CurrentUrl.contains("searchType=project"),
				"[ASSERTION FAILED]:User is not able to navigate to All Project Link");
		logMessage("User is able visit all project link");
	}

	public void clickOnFacetLinks() {
		isElementDisplayed("link_facet", "Macroeconomics");
		clickUsingJS(element("link_facet", "Macroeconomics"));
		logMessage("Macroeconomics link clicked");
		waitForLoaderToDisappear();
		isElementDisplayed("textVerify", "Macroeconomics");

	}

	public void clickAllTypesOfSearch() {
		// waitForElementToBeClickable(element("types"));
		isElementDisplayed("types");
		clickUsingJS(element("types"));
		logMessage("All Types link Clicked");
	}

	public void ResetPassword() throws IOException {
		String CurrentPassword = PropFileHandler.readPropertyFromDataFile("currentPassword");
		String NewPassword = PropFileHandler.readPropertyFromDataFile("newPassword");
		isElementDisplayed("OldPass");
		element("OldPass").sendKeys(CurrentPassword);
		logMessage("Old passsword entered::" + CurrentPassword);

		isElementDisplayed("NewPass");
		element("NewPass").sendKeys(NewPassword);
		logMessage("new passsword entered::" + NewPassword);

		isElementDisplayed("confPass");
		element("confPass").sendKeys(NewPassword);
		logMessage("conform passsword entered::" + NewPassword);

		wait.hardWait(2);
		isElementDisplayed("UpdateButton");
		clickUsingJS(element("UpdateButton"));
		logMessage("Update button clicked");

		wait.hardWait(1);
		PropFileHandler.writePropertyToDataFile("currentPassword", NewPassword);
		PropFileHandler.writePropertyToDataFile("newPassword", CurrentPassword);
		wait.hardWait(1);

		isElementDisplayed("passUpdateLabel");
		isElementDisplayed("updateMsg");
		logMessage("Password Changed Success message is displayed");
		clickXButtonOnRestPassword();
		wait.hardWait(2);
		waitForLoaderToDisappear();

		logMessage("Trying to loggin with updated Password........");
	}

	public void ClickUploadContent() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UploadButton");
		isElementDisplayed("UploadButton");
		clickUsingJS(element("UploadButton"));
		logMessage("Upload Button clicked...");
	}

	public void UploadEnhancedEpubAndAssociateFromHomePage(String AssociateISBN, String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN + ".epub";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + ".epub";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:Enhanced ePub>Full Package");
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + ".epub");
		logMessage(FileISBN + ".epub Title of the file");
		wait.hardWait(2);

		isElementDisplayed("AddRemoveProject");
		clickUsingJS(element("AddRemoveProject"));
		logMessage("AddRemoveProject Button clicked");
		wait.hardWait(2);

		isElementDisplayed("SearchInputTag");
		clickUsingJS(element("SearchInputTag"));
		String Isbnc = Keys.chord(AssociateISBN);
		element("SearchInputTag").sendKeys(Isbnc);
		logMessage("ISBN Entered into Search bar");
		clickUsingJS(element("submitButton"));
		logMessage("Search button clicked");
		wait.hardWait(3);

		String InputStatus = element("SelectProject", AssociateISBN).getAttribute("ng-disabled");
		logMessage("InputStatus=" + InputStatus);
		wait.hardWait(2);
		if (InputStatus.equals("false")) {
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.hardWait(2);
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.hardWait(2);
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			waitForLoaderToDisappear();

		} else {
			isElementDisplayed("ConformProject", AssociateISBN);
			wait.waitForPageToLoadCompletely();
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			isElementDisplayed("unselect");
			wait.waitForPageToLoadCompletely();
			clickUsingJS(element("unselect"));
			logMessage("Unselect clicked");
			wait.waitForPageToLoadCompletely();
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			waitForLoaderToDisappear();
		}

		isElementDisplayed("Upload");
		clickUsingJS(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."),
				"[Assertion Failed]:Incorrect Message Displayed::" + msg);
		logMessage("[Assertion Passed]: Content is uploded");
	}

	public void VerifyUnableToResetOnIncorrectOldPassword() {
		isElementDisplayed("OldPass");
		fillText("OldPass", "IncorrectPassword1");

		isElementDisplayed("NewPass");
		fillText("NewPass", "NewPassword1");

		isElementDisplayed("confPass");
		fillText("confPass", "NewPassword1");

		isElementDisplayed("UpdateButton");
		clickUsingJS(element("UpdateButton"));
		logMessage("Update button clicked");

		isElementDisplayed("IncorrectOldPass");
		String Message = element("IncorrectOldPass").getAttribute("innerText");
		logMessage("Error MEssage::" + Message);
		Assert.assertTrue("Incorrect old password".equals(Message),
				"[Assertion Failed]:: Error Message Is Not Displayed");
		logMessage("[Assertion Passed]:: User Not Able To Reset Password On entering Incorrent old password");
	}

	public void VerifyTopFiveProjectIsDisplayedWithView() {
		areElementsDisplayed("TopFiveProject");
		Assert.assertTrue(elements("TopFiveProject").size() == 5,
				"[Assertion Failed]:: Top Five Project are Not Displayed In The HomePage");
		logMessage("[Assertion Passed]:: Top Five Projects Are Displayed");

		areElementsDisplayed("TopFiveProjectView");
		Assert.assertTrue(elements("TopFiveProjectView").size() == 5,
				"[Assertion Failed]:: View for Top Five Project are Not Displayed In The HomePage");
		logMessage("[Assertion Passed]:: View for Top Five Projects Are Displayed");

	}

	public void VerifyMacmillanLogoIsPresent() {
		isElementDisplayed("Logo");
		logMessage("[Assertion passed]::Macmillan Logo Is Present!!!");

	}

	public void DashBordIsDisplayed() {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("DashbordDispaly");
		logMessage("DashBord Is displayed..");
	}

	public void ClickMacmillanLogo() {
		waitForLoaderToDisappear();
		scrollToTop();
		isElementDisplayed("Logo");
		hover(element("Logo"));
		wait.hardWait(1);
		click(element("Logo"));
		logMessage("Macmillan Logo Clicked");
	}

	public void VerifyContentTabIsDisplayed() {
		wait.hardWait(1);
		isElementDisplayed("ContentTab");
		logMessage("Content tab displayed...");

	}

	public void VerifyProjectTabIsDisplayed() {
		wait.hardWait(1);
		isElementDisplayed("ProjectTab");
		logMessage("Project Tab displayed...");

	}

	public void VerifyProfileButton() {
		isElementDisplayed("username");
		isElementDisplayed("username");
	}

	public void VerifySearchFieldIsDisplayed() {
		isElementDisplayed("SearchInputBar");
		isElementDisplayed("SearchInputBar");

	}

	public void VerifyUserAbleToSelectOptionsInNormalSearch() {
		isElementDisplayed("SearchTypeButton");
		scroll(element("SearchTypeButton"));
		clickUsingJS(element("SearchTypeButton"));
		logMessage("All Types Button Clicked...");
		isElementDisplayed("SearchType", "content");
		isElementDisplayed("SearchType", "content");
		isElementDisplayed("SearchType", "project");
		isElementDisplayed("SearchType", "all");
	}

	public void VerifyEditAccountDisplayed() {
		isElementDisplayed("EditAccount");
		isElementDisplayed("EditAccount");
	}

	public void VerifyLogoutDisplayed() {
		isElementDisplayed("logOut");
		isElementDisplayed("logOut");

	}

	public void VerifyAccountPopUp() {
		isElementDisplayed("VerifyAccountPopUp");
		isElementDisplayed("VerifyAccountPopUp");

	}

	public void verifyGeneralInformation() {
		isElementDisplayed("GeneralInfo");
		isElementDisplayed("GeneralInfo");

	}

	public void verifyResetPassword() {
		isElementDisplayed("resetPassword");
		isElementDisplayed("resetPassword");
	}

	public void VerifyCancelButton() {
		isElementDisplayed("cancelButton");
		isElementDisplayed("cancelButton");

	}

	public void clickCancelButton() {
		isElementDisplayed("cancelButton");
		isElementDisplayed("cancelButton");
		clickUsingJS(element("cancelButton"));
		logMessage("Cancel Button Clicked..");
	}

	public void VerifyAccountPopUpClosed() {
		refreshPage();
		waitForLoaderToDisappear();
		Assert.assertTrue(verifyElementNotDisplayed("VerifyAccountPopUp"),
				"[Assertion Failed]::Account PopUp Is Displayed..");
		logMessage("[Assertion Passed]::Account PopUp Is Not Displayed..");
	}

	public void VerifyGeneralInformationFieldsNotEditable() {
		isElementDisplayed("NameUser");
		String Attri1 = element("NameUser").getAttribute("ng-readonly");
		String Attri2 = element("NameUser").getAttribute("readonly");
		logMessage(Attri1 + " " + Attri2);
		if (Attri1.equals("true") && Attri2.equals("true")) {
			logMessage("[Assertion Passed]::Full Name: Field Is not editable!!!");
		} else {
			logMessage("[Assertion Failed]::Full Name: Field Is editable!!!");
			Assert.assertTrue(false);
		}

		isElementDisplayed("userEmail");
		Attri1 = element("userEmail").getAttribute("ng-readonly");
		Attri2 = element("userEmail").getAttribute("readonly");
		if (Attri1.equals("true") && Attri2.equals("true")) {
			logMessage("[Assertion Passed]:: Email Address:: Field Is not editable!!!");
		} else {
			logMessage("[Assertion Failed]:: Email Address:: Field Is editable!!!");
			Assert.assertTrue(false);
		}
	}

	public void VerifyAllThreeFiledsAreDisplayed() {
		isElementDisplayed("OldPass");
		isElementDisplayed("OldPass");
		isElementDisplayed("NewPass");
		isElementDisplayed("confPass");

	}

	public void VerifyUpdateButton() {
		isElementDisplayed("UpdateButton");
		isElementDisplayed("UpdateButton");

	}

	public void VerifyShowPasswordOnScreen() {
		isElementDisplayed("SeePasswordOnScreen");
		isElementDisplayed("SeePasswordOnScreen");
	}

	/*
	 * public void ViewContentOfFirstProject() { isElementDisplayed("View");
	 * clickUsingJS(element("View")); logMessage("Project opened....."); }
	 */

	public void VerifyNewPasswordFieldDisplaysMessageForLessThan8Character() {
		isElementDisplayed("NewPass");
		fillText("NewPass", "newtest");
		isElementDisplayed("LimitRestrictionMsg");
		logMessage("Message Displyed:: Invalid input, should have at least 8 characters");
	}

	public void VerifyNewPasswordFieldDisplaysMessageForOneUppercase() {
		isElementDisplayed("NewPass");
		fillText("NewPass", "newpassword1");
		isElementDisplayed("UpperCaseRestrictionMsg");
		logMessage("Message Displyed::Should have at least one uppercase");
	}

	public void VerifyNewPasswordFieldDisplaysMessageForOneNumber() {
		isElementDisplayed("NewPass");
		fillText("NewPass", "newPassword");
		isElementDisplayed("NoRestrictionMsg");
		logMessage("Message Displyed::Should have at least one number");

	}

	public void VerifyNewPasswordFieldDisplaysMessageForOneLowerCase() {
		isElementDisplayed("NewPass");
		fillText("NewPass", "NEWPASSWORD1");
		isElementDisplayed("LowerCaseRestrictionMsg");
		logMessage("Message Displyed::Should have at least one lowercase");
	}

	public void VerifyUserGetsErrorMessageIfNewAndConformFieldsAreNotSame() {
		isElementDisplayed("NewPass");
		fillText("NewPass", "Password18");

		isElementDisplayed("confPass");
		fillText("confPass", "Password19");

		isElementDisplayed("PasswordNotMatchMsg");
		logMessage("Message Displayed::Password does not match");
	}

	public void VerifyUpdateButtonDisable() {
		wait.hardWait(2);
		isElementDisplayed("UpdateButton");
		String Attri = element("UpdateButton").getAttribute("disabled");
		if (Attri == null) {
			Assert.assertTrue(false, "[Assertion Failed]:: Update Button Is Enabled...");
		} else {
			logMessage("[Assertion Passed]:: Update Button Is Disabled...");
		}
	}

	public void VerifyUploadButton() {
		isElementDisplayed("Upload");
		isElementDisplayed("Upload");
	}

	public void VerifyUploadButtonIsDisabled() {
		wait.hardWait(2);
		isElementDisplayed("Upload");
		isElementDisplayed("Upload");
		String Attri = element("Upload").getAttribute("disabled");
		if (Attri == null) {
			Assert.assertTrue(false, "[Assertion Failed]:: Update Button Is Enabled...");
		} else {
			logMessage("[Assertion Passed]:: Update Button Is Disabled...");
		}
	}

	public void VerifyUploadButtonIsEnabled() {
		wait.hardWait(2);
		isElementDisplayed("Upload");
		isElementDisplayed("Upload");
		String Attri = element("Upload").getAttribute("disabled");
		if (Attri == null) {
			Assert.assertTrue(true, "[Assertion Passed]:: Update Button Is Enabled...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Update Button Is Disabled...");
		}
	}

	public void EnterValuesInSecondAndThirdPasswordFiled(String value1, String value2) {
		isElementDisplayed("NewPass");
		click(element("NewPass"));
		fillText("NewPass", value1);

		isElementDisplayed("confPass");
		click(element("confPass"));
		fillText("confPass", value2);

	}

	public void clickShowpasswordLink() {
		isElementDisplayed("SeePasswordOnScreen");
		clickUsingJS(element("SeePasswordOnScreen"));
		logMessage("Show Password on screen clciked!!!!");
	}

	public void VerifyUserIsAbleToSeePassword() {
		wait.hardWait(2);
		isElementDisplayed("OldPass");
		isElementDisplayed("NewPass");
		isElementDisplayed("confPass");
		String Attr = element("NewPass").getAttribute("type");
		String Attr1 = element("confPass").getAttribute("type");
		String Attr2 = element("OldPass").getAttribute("type");
		logMessage("Upgated TEXT VALUE:::::::" + Attr);
		if (Attr.equals("text") && Attr1.equals("text") && Attr2.equals("text")) {
			logMessage("Old Password Filed::" + element("OldPass").getAttribute("value"));
			logMessage("New Password Filed::" + element("NewPass").getAttribute("value"));
			logMessage("Conform Password Filed::" + element("confPass").getAttribute("value"));
			logMessage("[Assertion Passed]:: User Is Able To see the Password...");
		}
	}

	public void clickCancelButtonOnRestPassword() {

		wait.hardWait(3);
		isElementDisplayed("CancelButtonOnRestPass");
		scroll(element("CancelButtonOnRestPass"));
		clickUsingJS(element("CancelButtonOnRestPass"));
		logMessage("Cancel button Clicked....");

	}

	public void clickXButtonOnRestPassword() {
		isElementDisplayed("Xbutton");
		wait.waitForPageToLoadCompletely();
		scroll(element("Xbutton"));
		hover(element("Xbutton"));
		click(element("Xbutton"));
		logMessage(" 'x' Button Clicked....");

	}

	public void clickXButtonUploadContent() {
		wait.waitForPageToLoadCompletely();
		scroll(element("Xbutton"));
		hover(element("Xbutton"));
		wait.waitForPageToLoadCompletely();
		click(element("Xbutton"));
		logMessage("'x' Button Clicked....");
	}

	public void verifyResetPasswordPopUpClosed() {
		wait.waitForPageToLoadCompletely();
		wait.hardWait(2);
		Assert.assertTrue(verifyElementNotDisplayed("CancelButtonOnRestPass"),
				"[Assertion Failed]::Reset Password PopUp is Displayed..");
		logMessage("Reset Password PopUp Closed....");

	}

	public void VerifyUploadContentButtonIsPresent() {
		isElementDisplayed("UploadButton");
		logMessage("Upload Content Button is Displayed is displayed...");

	}

	public void VerifyFacetLinksPresentAtLeftSide() {
		areElementsDisplayed("FacetLinks");
		List<WebElement> FacetLink = elements("FacetLinks");
		for (int i = 0; i < FacetLink.size(); i++) {
			logMessage("Links Displayed::" + FacetLink.get(i).getAttribute("innerText"));
			wait.hardWait(1);
		}

	}

	public void clickAdvanceSearch() {
		wait.hardWait(1);
		scrollToTop();
		wait.hardWait(2);
		isElementDisplayed("AdvanceSearchLink");
		clickUsingJS(element("AdvanceSearchLink"));
		logMessage("Advance Search Clicked");
	}

	public void VerifyVeriousFieldOnAdvancedSearchPopUp() {

		isElementDisplayed("lookFor");
		logMessage("'Look For' Drop Down Is Visible...");

		isElementDisplayed("AdvanceSearchField");
		logMessage("Search Filed Displayed On Advance Sraech PopUp Is Visible...");

		isElementDisplayed("FieldPane");
		logMessage("FieldPane Is Visible...");

		isElementDisplayed("AddField");
		logMessage("'AddField' Drop Down Is Visible...");

		isElementDisplayed("submitButtonAS");
		logMessage("'submit Button' Is Visible...");

		isElementDisplayed("reset");
		logMessage("'Reset Button' Is Visible...");

		isElementDisplayed("CancelButtonOnAdvanceSearch");
		logMessage("'Cancel Button' Is Visible...");

	}

	public void VerifyHelpInfoDisplayedOnMouseHover() {
		isElementDisplayed("HelpHover");
		wait.waitForPageToLoadCompletely();
		hover(element("HelpHover"));
		areElementsDisplayed("HelpPage");
		logMessage("Help Information Displayed.....");

	}

	public void Verify14OptionsInAddNewField() {
		areElementsDisplayed("OptionsInAddNewField");
		List<WebElement> Options = elements("OptionsInAddNewField");
		for (int i = 0; i < Options.size(); i++) {
			logMessage((i + 1) + ":'" + Options.get(i).getAttribute("innerText") + "' Is Displayed");
		}

		if (Options.size() == 14) {
			logMessage("[Assertion Passed]:: The Add New Field Has 14 Options");
		} else {
			Assert.assertTrue(false, "[Assertion failed]:: The Add New Field Has " + Options.size() + " Options.");
		}
	}

	public void Verify13OptionsInAddNewField() {
		areElementsDisplayed("OptionsInAddNewField");
		List<WebElement> Options = elements("OptionsInAddNewField");
		for (int i = 0; i < Options.size(); i++) {
			logMessage((i + 1) + ":'" + Options.get(i).getAttribute("innerText") + "' Is Displayed");
		}

		if (Options.size() == 13) {
			logMessage("[Assertion Passed]:: The Add New Field Has 13 Options");
		} else {
			Assert.assertTrue(false, "[Assertion failed]:: The Add New Field Has " + Options.size() + " Options.");
		}
	}

	public void AddNewFieldInAdvancedSearchPopUpAndVerify() {
		isElementDisplayed("AddField");
		selectTextFromDropDown("AddField", "Content Type");
		logMessage("'Content Type' selected in Add field");

		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add button Clicked....");

		areElementsDisplayed("VerifySingleFieldAdded");
		logMessage("New Field has been Added....");

	}

	public void LogoutFromApplication() {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		if (!verifyElementNotDisplayed("username")) {
			clickUserName();
			clickLogOut();
			waitForLoaderToDisappear();
			wait.waitForPageToLoadCompletely();
		} else {
			logMessage("User Is loged out...");
		}
	}

	public void SelectContentTypeInNewAddedField() {
		isElementDisplayed("SelectOptionsFromSingleFieldAdded");
		selectTextFromDropDown("SelectOptionsFromSingleFieldAdded",
				getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("'Enhanced ePub > Full Package' Selected In Content type Field....");

	}

	public void clickAddOnAdvSearch() {
		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add button Clicked....");

	}

	public void VerifyAndOrFiledOnAdvSearch() {
		isElementDisplayed("AddOR");
		selectTextFromDropDown("AddOR", "AND");
		logMessage("AND Selected...");

		selectTextFromDropDown("AddOR", "OR");
		logMessage("OR Selected...");

	}

	public void SearchTextInAdvanceSearch(String Text) {
		isElementDisplayed("SearchContent");
		fillText("SearchContent", Text);

		isElementDisplayed("SearchButton");
		clickUsingJS(element("SearchButton"));
		logMessage("Sraech Button Clicked.......");

	}

	public void clickCancelButtonOnAdvPopUp() {
		isElementDisplayed("CancelAdvPopUp");
		clickUsingJS(element("CancelAdvPopUp"));
		logMessage("Cancel Clicked on Advance Search PopUp.....");

	}

	public void verifyAdvanceSearchPopUpClosed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("reset"), "[Assertion Failed]:: Advance Search popUp Displayed..");
		logMessage("Advance Search popUp is not Displayed..");
	}

	public void VerifyOnAdvanceSearchPopUp() {
		wait.hardWait(1);
		isElementDisplayed("reset");
		logMessage("Advance Search PopUp is Displayed..");
	}

	public void ClickOnA_Project() {
		isElementDisplayed("ViewProject");
		hover(element("ViewProject"));
		wait.waitForPageToLoadCompletely();
		click(element("ViewProject"));
		logMessage("Project opened....");

	}

	public void verifySearchAllProjectDisplayed() {
		isElementDisplayed("SearchAllProject");
		logMessage("Search All Project link Displayed....");

	}

	public void clickSearchAllproject() {
		isElementDisplayed("SearchAllProject");
		clickUsingJS(element("SearchAllProject"));
		logMessage("Search All Project link Clicked....");

	}

	public void VerifySearchAllProjectLinkIsWorking() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("SrarchAllProjectnavigate");
		Assert.assertTrue("project".contains(element("SrarchAllProjectnavigate").getAttribute("innerText")),
				"[Assertion Failed]:: Srarch All Project link  Is Not working");
		logMessage("[Assertion Passed]:: Srarch All Project link  Is  working!!!!");

	}

	public void VerifyResultAreAccordingToSearchedText(String iSBN) {
		isElementDisplayed("VerifyAdvSearch");
		logMessage(element("VerifyAdvSearch").getAttribute("innerText"));
		Assert.assertTrue(element("VerifyAdvSearch").getAttribute("innerText").contains(iSBN),
				"[Assertion Failed]: Search Functionaliy failed");
		logMessage("[Assertion Passed]: Search leads a user to navigate at search results page");

	}

	public void clickUploadButton() {
		isElementDisplayed("Upload");
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("Upload"));
		logMessage("Upload Button Clicked");

	}

	public void VerifyUploadButtonOnUploadPopup() {
		isElementDisplayed("Upload");
		isElementDisplayed("Upload");
		logMessage("Upload Button IS Displayed..");
	}

	public void VerifyUploadContentPopup() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UploadContentLabel");
		isElementDisplayed("UploadContentLabel");
		logMessage("Upload Content Popup Displayed.");

	}

	public void VerifyBrowseButton() {
		isElementDisplayed("BrowseFile");
		logMessage("Browse File Button Is displayed...");

	}

	public void SelectImageFileUsingBrowseButton(String FileISBN) {
		String filePath;
		String selServer = System.getProperty("seleniumServer");
		if (selServer == null)
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN
					+ "_FC.jpg";
		else {
			filePath = "C:/cms Testdata/" + FileISBN + "_FC.jpg";
		}
		System.out.println(filePath);
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.waitForPageToLoadCompletely();
	}

	public void SelectFileUsingBrowseButton(String FileName) {
		String filePath;
		String selServer = System.getProperty("seleniumServer");
		if (selServer == null)
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileName;
		else {
			filePath = "C:/cms Testdata/" + FileName;
		}
		System.out.println(filePath);

		element("BrowseFile").sendKeys(filePath);
		logMessage(FileName + " selected");
		wait.waitForPageToLoadCompletely();
	}

	public void SelectTypeOfContentInUploadContentPopUp(String ContentType) {
		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", ContentType);
		logMessage("Content Type::" + ContentType);
	}

	public void VerifyContentTypeSelectTypeOfContent() {

		isElementDisplayed("TypeSelect");

		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:Enhanced ePub > Full Package");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Project Support Materials>CFI"));
		logMessage("Content Type: CFI");
		wait.waitForPageToLoadCompletely();

		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:Enhanced ePub > Full Package");
		wait.waitForPageToLoadCompletely();

		logMessage("User Is Able To Select Content From Content Type....");

	}

	public void VerifyContentTypeInUploadContentPopup() {
		isElementDisplayed("UploadField", "Content Type");
		isElementDisplayed("UploadField", "Content Type");
		logMessage("Content Type is dispalyed...");
	}

	public void VerifyTitleInUploadContentPopup() {
		isElementDisplayed("UploadFields", "Title");
		isElementDisplayed("UploadFields", "Title");
		logMessage("Title is dispalyed...");
	}

	public void VerifyDescriptionInUploadContentPopUp() {
		isElementDisplayed("DescriptionField");
		logMessage("Description Field is dispalyed...");
	}

	public void VerifyVariousFieldsInUploadContentPopUp() {

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UploadField", "Content Type");
		logMessage("Content Type is dispalyed...");

		isElementDisplayed("UploadField", "Title");
		logMessage("Title is dispalyed...");
		fillText("Title", "Delete test");

		isElementDisplayed("UploadField", "Description");
		logMessage("Description is dispalyed...");

	}

	public void Verify_Removed_Field_From_Upload_Content_Window() {
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Subject Keyword Taxonomy"),
				"[Assertion Failed]::Subject Keyword Taxonomy is dispalyed...");
		logMessage("Subject Keyword Taxonomy is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Product Data"),
				"[Assertion Failed]:Product Data is dispalyed...");
		logMessage("Product Data is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Relationship Type"),
				"[Assertion Failed]:Relationship Type is dispalyed...");
		logMessage("Relationship Type is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Relationship URI"),
				"[Assertion Failed]:Relationship URI is dispalyed...");
		logMessage("Relationship URI is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Relationship Target"),
				"[Assertion Failed]:Relationship Target is dispalyed...");
		logMessage("Relationship Target is NOT dispalyed...");
	}

	public void VerifyAddRemoveAndUploadButton() {

		isElementDisplayed("AddRemoveProject");
		isElementDisplayed("AddRemoveProject");
		logMessage("Add/RemoveProject button is displayed....");

		isElementDisplayed("UploadButton");
		isElementDisplayed("UploadButton");
		logMessage("Upload Button is displayed....");
	}

	public void ClickAddKeywordTaxonomy() {
		isElementDisplayed("AddTaxonomy");
		clickUsingJS(element("AddTaxonomy"));
		logMessage("Add Taxonomy button clicked");
	}

	public void RemoveSubjectKeywordTaxonomyFunctionalityandVerify() {

		isElementDisplayed("AddedTaxonomyFiled");
		logMessage("Subject Keyword Taxonomy Field Added");

		isElementDisplayed("RemoveTaxonomyFiled");
		clickUsingJS(element("RemoveTaxonomyFiled"));

		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("AddedTaxonomyFiled"),
				"[Assertion Failed]::Added Taxonomy Filed Displayed..");
		logMessage("Added Taxonomy Filed Removed..");

	}

	public void VerifyUserIsAbleToSelectRelationshipType() {
		isElementDisplayed("RelationshipType");
		selectTextFromDropDown("RelationshipTarget", "NA");
		logMessage("'NA' Selected As Relationship Type");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipType", "isChild");
		logMessage("'isChild' Selected As Relationship Type");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipType", "isParent");
		logMessage("'isParent' Selected As Relationship Type");
		wait.hardWait(1);

	}

	public void VerifyUserIsAbleToSelectRelationshipTarget() {
		isElementDisplayed("RelationshipTarget");
		selectTextFromDropDown("RelationshipTarget", "NA");
		logMessage("'NA' Selected As Relationship Target");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipTarget", "CMS");
		logMessage("'CMS' Selected As Relationship Target");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipTarget", "Elvis");
		logMessage("'Elvis' Selected As Relationship Target");
		wait.hardWait(1);
	}

	public void ClickAddRemoveProject() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("AddRemoveProject");
		scroll(element("AddRemoveProject"));
		clickUsingJS(element("AddRemoveProject"));
		logMessage("Add Remove button clicked");

	}

	public void VerifyAddtoProjectpopUp() {
		isElementDisplayed("AddtoProjectlabel");
		logMessage("Add to project popup displayed");
	}

	public void VerifySearchFieldAndClearLinkOnAddRemoveProjectPopUp() {
		isElementDisplayed("SearchProjectAddRemove");
		logMessage("Search Filed is Displayed");

		isElementDisplayed("ClickSearchButton");
		logMessage("Search Button is Displayed");

		/*isElementDisplayed("ClearLink");
		logMessage("Clear Link is Displayed");*/

	}

	public void VerifyAvailableAndSelectedPane() {
		areElementsDisplayed("AvailablePane");
		logMessage("Seleted pane is displayed");
		List<WebElement> info = elements("AvailablePane");
		for (int i = 0; i < info.size(); i++) {
			wait.hardWait(1);
			logMessage(info.get(i).getAttribute("innerText") + " Is Displayed");
			wait.hardWait(1);
		}
		areElementsDisplayed("SelectedPane");
		logMessage("Selected pane is displayed");
		List<WebElement> infos = elements("SelectedPane");
		for (int i = 0; i < infos.size(); i++) {
			wait.hardWait(1);
			logMessage(infos.get(i).getAttribute("innerText") + " Is Displayed");
			wait.hardWait(1);
		}
	}

	public void VerifySelectUselectDoneCancelButton() {
		isElementDisplayed("SelectButton");
		logMessage("Select Button Is Displayed");

		isElementDisplayed("UnSelectButton");
		logMessage("UnSelect Button Is Displayed");

		isElementDisplayed("CancelButtonOnADDRemove");
		logMessage("Cancel button Displayed");
	}

	public void ClickSelectButtonAddRemoveProject() {
		isElementDisplayed("SelectButton");
		hoverOverElement(element("SelectButton"));
		click(element("SelectButton"));
		logMessage("Select Button Clicked..");
	}

	public void SearchProjectInAddRemovePopUp(String ISBN) {

		isElementDisplayed("SearchProjectAddRemove");
		clickUsingJS(element("SearchProjectAddRemove"));
		String ISBNc = Keys.chord(ISBN);
		wait.waitForPageToLoadCompletely();
		element("SearchProjectAddRemove").clear();
		element("SearchProjectAddRemove").sendKeys(ISBNc);
		isElementDisplayed("ClickSearchButton");
		clickUsingJS(element("ClickSearchButton"));
		logMessage("Search button clicked");
		logMessage(ISBN);
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
	}

	public void VerifyProjectDisplayedOnAvailablePane(String ISBN) {
		isElementDisplayed("SelectProject", ISBN);
		logMessage("Project Displayed on AvailablePane");
	}

	public void MoveProjectFromAvailablePaneToSelectedPane(String ISBN2) {
		isElementDisplayed("selectProjectAddRemovePopUp", ISBN2);
		clickUsingJS(element("selectProjectAddRemovePopUp", ISBN2));
		logMessage("Project Selected");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("SelectButton");
		clickUsingJS(element("SelectButton"));
		logMessage("Selected Button Clicked");
	}

	public void NavigateToPageNumberInAvailablePane(String PageNumber) {
		isElementDisplayed("NavigateInAvailablePane", PageNumber);
		click(element("NavigateInAvailablePane", PageNumber));
		logMessage("User Navigated to Page::" + PageNumber);

	}

	public void NavigateToPageNumberInSelectedPane(String PageNumber) {
		isElementDisplayed("NavigateInSelectedPane", PageNumber);
		click(element("NavigateInSelectedPane", PageNumber));
		logMessage("User Navigated to Page::" + PageNumber);

	}

	public void MoveProjectFromSelectedPaneToAvailablePane(String ISBN) {

		isElementDisplayed("ConformProject", ISBN);
		wait.waitForPageToLoadCompletely();
		click(element("ConformProject", ISBN)); // New Added
		logMessage("Project Moved To Selected Pane");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("unselect");
		clickUsingJS(element("unselect"));
		logMessage("UnSelect Button Clicked...");
	}

	public void ClickSaveButtonOnAddToProject() {
		isElementDisplayed("saveButton");
		hover(element("saveButton"));
		wait.waitForPageToLoadCompletely();
		click(element("saveButton"));
		logMessage("Save Button Clicked");
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
	}

	public void verifyShortTitleFieldOnAddRemoveIsNotEmpty() {
		areElementsDisplayed("GetShortTitleValue");
		List<WebElement> ShortTitleField = elements("GetShortTitleValue");
		for (int EachFiled = 0; EachFiled < ShortTitleField.size(); EachFiled++) {
			String Text = ShortTitleField.get(EachFiled).getText().trim();
			if (Text.equals(" ") || Text == null || Text.length() == 0) {
				Assert.assertTrue(false,
						"[Assertion Failed]:: 'Short Title' Field Empty on  Add/Remove Project Window");
			}
		}
	}

	public void ClickSelectAllAddRemoveAvailableSection() {
		isElementDisplayed("SelectAllAvailablePane");
		hoverOverElement(element("SelectAllAvailablePane"));
		click(element("SelectAllAvailablePane"));
		logMessage("Select All Check Box Clicked..");
	}

	public void VerifyAddToProjectPopUpNotDisplayed() {
		wait.waitForPageToLoadCompletely();
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("AddtoProjectlabel"),
				"[Assertion Failed]::Add To Project PopUp is Displayed.");
		logMessage("Add To Project PopUp Not Displayed!!!!");

	}

	public void ClickCancelOnAddRemove() {
		isElementDisplayed("CancelButtonOnADDRemove");
		wait.waitForPageToLoadCompletely();
		click(element("CancelButtonOnADDRemove"));
		logMessage("Cancel button Clicked....");
	}

	public void UploadFlatEpubAndAssociateFromHomePage(String AssociateISBN, String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN
					+ "_EPUB.epub";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + "_EPUB.epub";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + "_EPUB.epub selected");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Flat ePub > Full Package"));
		logMessage("Content Type:Flat ePub > Full Package");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + "_EPUB.epub");
		logMessage(FileISBN + "_EPUB.epub Title of the file");
		wait.waitForPageToLoadCompletely();

		areElementsDisplayed("AddRemoveProject");
		scroll(element("AddRemoveProject"));
		wait.hardWait(1);
		clickUsingJS(element("AddRemoveProject"));
		logMessage("AddRemoveProject Button clicked");
		wait.hardWait(1);

		isElementDisplayed("SearchInputTag");
		clickUsingJS(element("SearchInputTag"));
		String Isbnc = Keys.chord(AssociateISBN);
		element("SearchInputTag").sendKeys(Isbnc);
		logMessage("ISBN Entered into Search bar");
		clickUsingJS(element("submitButton"));
		logMessage("Search button clicked");
		wait.waitForPageToLoadCompletely();

		String InputStatus = element("SelectProject", AssociateISBN).getAttribute("ng-disabled");
		logMessage("InputStatus=" + InputStatus);
		wait.waitForPageToLoadCompletely();
		if (InputStatus.equals("false")) {
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage(FileISBN + "_EPUB.epub IS Associated To Project Of ISBN::" + AssociateISBN);

		} else {
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("unselect");
			clickUsingJS(element("unselect"));
			logMessage("Unselect clicked");
			wait.waitForPageToLoadCompletely();
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage(FileISBN + "_EPUB.epub IS Associated To Project Of ISBN::" + AssociateISBN);
		}

		isElementDisplayed("Upload");
		clickUsingJS(element("Upload"));
		logMessage("Upload Button Clicked..");
		areElementsDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");
		wait.waitForPageToLoadCompletely();

	}

	public void UploadCoversCoverDesignAndAssociateFromHomePage(String AssociateISBN, String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		// System.out.println(selServer);
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN
					+ "_FC.jpg";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + "_FC.jpg";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + "_FC.jpg selected");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", "Covers>Cover Design");
		logMessage("Content Type:Covers>Cover Design");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + "_FC.jpg");
		logMessage(FileISBN + "_FC.jpg Title of the file");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("AddRemoveProject");
		clickUsingJS(element("AddRemoveProject"));
		logMessage("AddRemoveProject Button clicked");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("SearchInputTag");
		clickUsingJS(element("SearchInputTag"));
		String Isbnc = Keys.chord(AssociateISBN);
		element("SearchInputTag").sendKeys(Isbnc);
		logMessage("ISBN Entered into Search bar");
		clickUsingJS(element("submitButton"));
		logMessage("Search button clicked");
		wait.waitForPageToLoadCompletely();

		String InputStatus = element("SelectProject", AssociateISBN).getAttribute("ng-disabled");
		logMessage("InputStatus=" + InputStatus);
		wait.waitForPageToLoadCompletely();
		if (InputStatus.equals("false")) {
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage(FileISBN + "_FC.jpg IS Associated To Project Of ISBN::" + AssociateISBN);

		} else {
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("unselect");
			// waitForElementToBeClickable(element("unselect"));
			clickUsingJS(element("unselect"));
			logMessage("Unselect clicked");
			wait.waitForPageToLoadCompletely();
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.waitForPageToLoadCompletely();
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			isElementDisplayed("ConformProject", AssociateISBN);
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage(FileISBN + "_FC.jpg IS Associated To Project Of ISBN::" + AssociateISBN);
		}

		isElementDisplayed("Upload");
		clickUsingJS(element("Upload"));
		areElementsDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void UploadOthersContentAndAssociateFromHomePage(String AssociateISBN) {
		String selServer = System.getProperty("seleniumServer");
		// System.out.println(selServer);
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir")
					+ "\\src\\test\\resources\\testdata\\CMS\\Habits Of effective people.pdf";

		} else {
			filePath = "C:/cms Testdata/Habits Of effective people.pdf";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage("Habits Of effective people.pdf");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", "Other");
		logMessage("Content Type:Other");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("Title");
		element("Title").sendKeys("Habits Of effective people.pdf");
		logMessage("'Habits Of effective people.pdf' Title of the file");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("AddRemoveProject");
		clickUsingJS(element("AddRemoveProject"));
		logMessage("AddRemoveProject Button clicked");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("SearchInputTag");
		clickUsingJS(element("SearchInputTag"));
		String Isbnc = Keys.chord(AssociateISBN);
		element("SearchInputTag").sendKeys(Isbnc);
		logMessage("ISBN Entered into Search bar");
		clickUsingJS(element("submitButton"));
		logMessage("Search button clicked");
		wait.waitForPageToLoadCompletely();

		String InputStatus = element("SelectProject", AssociateISBN).getAttribute("ng-disabled");
		logMessage("InputStatus=" + InputStatus);
		wait.waitForPageToLoadCompletely();
		if (InputStatus.equals("false")) {
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage("'Habits Of effective people.pdf' IS Associated To Project Of ISBN::" + AssociateISBN);

		} else {
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("unselect");
			// waitForElementToBeClickable(element("unselect"));
			clickUsingJS(element("unselect"));
			logMessage("Unselect clicked");
			wait.waitForPageToLoadCompletely();
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.waitForPageToLoadCompletely();
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			isElementDisplayed("ConformProject", AssociateISBN);
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage("'Habits Of effective people.pdf' IS Associated To Project Of ISBN::" + AssociateISBN);
		}

		isElementDisplayed("Upload");
		clickUsingJS(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void UploadXHTMLContentAndAssociateFromHomePage(String AssociateISBN) {
		String selServer = System.getProperty("seleniumServer");
		// System.out.println(selServer);
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\XHTML Example.xhtml";

		} else {
			filePath = "C:/cms Testdata/XHTML Example.xhtml";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage("XHTML Example.xhtml Is Selected..");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.xhtml"));
		logMessage("Content Type:XHTML");
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys("XHTML Example.xhtml");
		logMessage("'XHTML Example.xhtml' Title of the file");
		wait.hardWait(2);

		isElementDisplayed("AddRemoveProject");
		clickUsingJS(element("AddRemoveProject"));
		logMessage("AddRemoveProject Button clicked");
		wait.hardWait(2);

		isElementDisplayed("SearchInputTag");
		clickUsingJS(element("SearchInputTag"));
		String Isbnc = Keys.chord(AssociateISBN);
		element("SearchInputTag").sendKeys(Isbnc);
		logMessage("ISBN Entered into Search bar");
		clickUsingJS(element("submitButton"));
		logMessage("Search button clicked");
		wait.hardWait(3);

		String InputStatus = element("SelectProject", AssociateISBN).getAttribute("ng-disabled");
		logMessage("InputStatus=" + InputStatus);
		wait.hardWait(2);
		if (InputStatus.equals("false")) {
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.hardWait(2);
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.hardWait(2);
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage("'XHTML Example.xhtml' IS Associated To Project Of ISBN::" + AssociateISBN);

		} else {
			wait.hardWait(2);
			isElementDisplayed("ConformProject", AssociateISBN);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.hardWait(2);
			isElementDisplayed("unselect");
			// waitForElementToBeClickable(element("unselect"));
			clickUsingJS(element("unselect"));
			logMessage("Unselect clicked");
			wait.hardWait(2);
			clickUsingJS(element("SubmitProject"));
			logMessage("Search button clicked");
			wait.hardWait(3);
			isElementDisplayed("SelectProject", AssociateISBN);
			clickUsingJS(element("SelectProject", AssociateISBN));
			logMessage("Project Selected");
			isElementDisplayed("moveSelectedProject");
			// waitForElementToBeClickable(element("moveSelectedProject"));
			clickUsingJS(element("moveSelectedProject"));
			logMessage("Selected Project moved");
			wait.hardWait(2);
			// waitForElementToBeClickable(element("ConformProject",AssociateISBN));
			isElementDisplayed("ConformProject", AssociateISBN);
			clickUsingJS(element("ConformProject", AssociateISBN));
			logMessage("Selected Project checked");
			wait.hardWait(2);
			isElementDisplayed("saveButton");
			clickUsingJS(element("saveButton"));
			logMessage("Save button Clicked");
			logMessage("'XHTML Example.xhtml' IS Associated To Project Of ISBN::" + AssociateISBN);
		}

		isElementDisplayed("Upload");
		clickUsingJS(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void VerifyRecentlyVisitedTabNotDisplayed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("RecentlyVisited"),
				"[Assertion Failed]::Recently Visited Tab is  Displayed.");
		logMessage("Recently Visited Tab is not Displayed...");
	}

	public void VerifyRecentlyVisitedTabIsDisplayed() {
		isElementDisplayed("RecentlyVisited");
		logMessage("'Recently Visited' Tab is Displayed...");
	}

	public void clickProjectLinkOnFacet() {
		isElementDisplayed("ProjectLink");
		clickUsingJS(element("ProjectLink"));
		logMessage("Project link on facet clicked..");

	}

	public void VerifyMessageForNoFavoriteProjectsIsDisplayed() {
		refreshPage();
		waitForLoaderToDisappear();
		isElementDisplayed("FavDiaglog");
		String attri = element("FavDiaglog").getAttribute("class");
		logMessage(attri);
		if (attri.equals("ng-hide")) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: 'Your favorite projects will appear here.' is Not displayed on the Dashbord..");
		} else {
			isElementDisplayed("textMsg", "Your favorite");
			isElementDisplayed("textMsg", "projects will appear here.");
			logMessage("Message Displayed 'Your favorite projects will appear here.' is displayed on the Dashbord..");
		}
	}

	public void VerifyMessageForNoFavoriteProjectsIsNotDisplayed() {
		String attri = element("FavDiaglog").getAttribute("class");
		logMessage(attri);
		if (attri.equals("ng-hide")) {
			logMessage("Message:: 'Your favorite projects will appear here.' is Not displayed on the Dashbord..");
		} else {
			logMessage("Message:: 'Your favorite projects will appear here.' is displayed on the Dashbord..");
			Assert.assertTrue(false);
		}
	}

	public void VerifyFavoriteTableIsDisplayed() {
		isElementDisplayed("FavTable");
		logMessage("Table with Favorite Project Is Displayed...");
	}

	public void VerifyFavoriteTableIsNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("FavTable"),
				"[Assertion Failed]::Table with Favorite Project Is Displayed..");
		logMessage("Table with Favorite Project Is Not Displayed...");
	}

	public void VerifyProjectsAreMarkedFavoriteAndMessageIsDisplayed() {
		wait.hardWait(2);
		waitForPageToLoadCompletely(getPageTitle());
		DashBordIsDisplayed();
		isElementDisplayed("ProjectLink");
		String text = element("ProjectLink").getAttribute("innerText");
		int firstIndex = text.indexOf('(');
		int lastIndex = text.indexOf(')');
		int size = Integer.parseInt(text.substring(firstIndex + 1, lastIndex));
		logMessage("Number Of Project Shown::" + size);
		if (size == 0) {
			VerifyMessageForNoFavoriteProjectsIsDisplayed();
			VerifyFavoriteTableIsNotDisplayed();
		}

		else {
			VerifyMessageForNoFavoriteProjectsIsNotDisplayed();
			VerifyFavoriteTableIsDisplayed();
			logMessage(size
					+ " project are selected as favorite So Message 'Your favorite projects will appear here.' is Not Displayed..");
		}

	}

	public void VerifyProjectIsAddedAsFavorite(String ISBN) {
		VerifyFavoriteTableIsDisplayed();
		isElementDisplayed("RemoveFavorite", ISBN);
		logMessage("Project of ISBN::" + ISBN + " Is Added To The Favorite...");
	}

	public void OpenProjectOnFavoriteDashBoard(String ISBN) {
		VerifyFavoriteTableIsDisplayed();
		isElementDisplayed("OpenFavoriteProject", ISBN);
		hoverOverElement(element("OpenFavoriteProject", ISBN));
		wait.waitForPageToLoadCompletely();
		click(element("OpenFavoriteProject", ISBN));
		logMessage("Project of ISBN::" + ISBN + " clicked...");
		waitForLoaderToDisappear();
	}

	public void VerifyProjectIsAddedAsFavoriteInGridView(String ProjectTitle) {
		isElementDisplayed("FavoriteStatusGrid", ProjectTitle);
		isElementDisplayed("FavoriteStatusGrid", ProjectTitle);
		logMessage("Project '" + ProjectTitle + "' Is Added To The Favorite...");
	}

	public void RemoveProjectFromFavoriteInGridView(String ProjectTitle) {
		isElementDisplayed("FavoriteStatusGrid", ProjectTitle);
		hoverOverElement(element("FavoriteStatusGrid", ProjectTitle));
		wait.waitForPageToLoadCompletely();
		click(element("FavoriteStatusGrid", ProjectTitle));
		logMessage(ProjectTitle + "Removed From Favorite..");
	}

	public void AddProjectToFavoriteInGridView(String ProjectTitle) {
		isElementDisplayed("FavoriteStatusGrid", ProjectTitle);
		hoverOverElement(element("FavoriteStatusGrid", ProjectTitle));
		wait.waitForPageToLoadCompletely();
		click(element("FavoriteStatusGrid", ProjectTitle));
		logMessage(ProjectTitle + "Add To Favorite..");
	}

	public void VerifyProjectRemovedFromFavoriteInGridView(String ProjectTitle) {
		Assert.assertTrue(verifyElementNotDisplayed("FavoriteStatusGrid", ProjectTitle),
				"[Assertion Failed]:: Project is Added as Favorite on Grid View");
		logMessage("Project '" + ProjectTitle + "' Is Added To The Favorite...");
	}

	public void VerifyProjectIsRemovedFromFavorite(String ISBN) {
		wait.hardWait(1);
		Assert.assertTrue(verifyElementNotDisplayed("RemoveFavorite", ISBN),
				"[Assertion Failed]::Project of ISBN::" + ISBN + " Is Displayed On Favorite Table...");
		logMessage("Project of ISBN::" + ISBN + " Is Not Displayed On Favorite Table...");

	}

	public void VerifyProjectDetailGridViewFavoriteTab() {
		isElementDisplayed("FavoriteGridInfo", "Author:");
		isElementDisplayed("FavoriteGridInfo", "Title:");
		isElementDisplayed("FavoriteGridInfo", "Edition:");
		isElementDisplayed("FavoriteGridInfo", "ISBN:");
	}

	public void RemoveProjectFromFavorite(String ISBN) {
		wait.hardWait(2);
		isElementDisplayed("RemoveFavorite", ISBN);
		logMessage("Project of ISBN::" + ISBN + " Is Displayed ...");
		click(element("RemoveFavorite", ISBN));
		logMessage("Star Icon Clicked...");
	}
	
	public void AddProjectToFavorite(String ISBN) {
		wait.hardWait(2);
		isElementDisplayed("RemoveFavorite", ISBN);
		logMessage("Project of ISBN::" + ISBN + " Is Displayed ...");
		click(element("RemoveFavorite", ISBN));
		logMessage("Star Icon Clicked...");
	}

	public void VerifyMessageDisplayedOnFavoriteRemoved() {
		isElementDisplayed("RemovedMSG");
		String Message = element("RemovedMSG").getAttribute("innerText");
		Assert.assertTrue(Message.equals("Removed from Favorites"),
				"[Assertion Failed]:: Incorrect Message Displayed::" + Message);
		logMessage("[Assertion Passed]:: Correct Message Displayed::" + Message);
		wait.hardWait(1);
	}

	public void VerifyMessageDisplayedOnAddingFavorite() {
		isElementDisplayed("RemovedMSG");
		String Message = element("RemovedMSG").getAttribute("innerText");
		Assert.assertTrue(Message.equals("Added to Favorites"),
				"[Assertion Failed]:: Incorrect Message Displayed::" + Message);
		logMessage("[Assertion Passed]:: Correct Message Displayed::" + Message);
		wait.hardWait(1);
	}
	
	public void VerifyFavoriteMessageColor() {
		Assert.assertTrue(element("RemovedMSG").getCssValue("color").trim().equals("rgba(60, 118, 61, 1)"));
		logMessage("Colour Displayed::"+element("RemovedMSG").getCssValue("color").trim());
	}
	
	public void verifyFavoriteToasterMessageAppears_For_5_Seconds() {
		isElementDisplayed("RemovedMSG");
		wait.hardWait(5);
		Assert.assertTrue(verifyElementNotDisplayed("RemovedMSG"));
	}
	public void VerifyCountOfFavoriteProject(int Count) {
		isElementDisplayed("ProjectLink");
		String text = element("ProjectLink").getAttribute("innerText");
		int firstIndex = text.indexOf('(');
		int lastIndex = text.indexOf(')');
		int size = Integer.parseInt(text.substring(firstIndex + 1, lastIndex));
		logMessage("Expected Facet Link Count::" + Count);
		logMessage("Facet Link Count Displayed::" + size);
		Assert.assertTrue(size == Count, "[Assertion Failed]:: Incorrect Count Is Displayed...");
	}

	public void VerifyFavoriteProjectCountIsNotZero() {
		isElementDisplayed("ProjectLink");
		String text = element("ProjectLink").getText();
		int CountDisplayed = Integer.parseInt(text.substring(text.indexOf('(') + 1, text.lastIndexOf(')')));
		logMessage("Project Count Displayed::" + CountDisplayed);
		if (CountDisplayed <= 0) {
			Assert.assertTrue(false, "[Assertion Failed]::Project count are Reset to Zero");
		}
	}

	public void RemoveAllProjectFromFavorite() {
		wait.hardWait(3);
		isElementDisplayed("ProjectLink");
		String text = element("ProjectLink").getAttribute("innerText");
		int firstIndex = text.indexOf('(');
		int lastIndex = text.indexOf(')');
		int size = Integer.parseInt(text.substring(firstIndex + 1, lastIndex));
		logMessage("Number Of Project Shown::" + size);
		if (size >= 1) {
			wait.hardWait(2);
			areElementsDisplayed("RemoveAllProjectFavorite");
			List<WebElement> FavProject = elements("RemoveAllProjectFavorite");
			logMessage("favorite project are displayed...");
			for (int i = 0; i < FavProject.size(); i++) {
				wait.hardWait(2);
				wait.waitForPageToLoadCompletely();
				FavProject.get(i).click();
				logMessage((i + 1) + " Project Removed From the Favorite...");
				VerifyMessageDisplayedOnFavoriteRemoved();
			}
		} else {
			logMessage("All project Have Been Removed from Facvorite");
		}
	}

	public void VerifyAllTheColoumsOfFavoriteTable() {
		isElementDisplayed("FavoriteTableColoums", "Author");
		logMessage("'Author' Is Displayed...");

		isElementDisplayed("FavoriteTableColoums", "Title");
		logMessage("'Title' Is Displayed...");

		isElementDisplayed("FavoriteTableColoums", "Short Title");
		logMessage("'Short Title' Is Displayed...");

		isElementDisplayed("FavoriteTableColoums", "ISBN");
		logMessage("'ISBN' Is Displayed...");

		isElementDisplayed("FavoriteTableColoums", "Publication Date");
		logMessage("'Publication Date' Is Displayed...");

		isElementDisplayed("FavoriteTableColoums", "CMS Project Status");
		logMessage("'CMS Project Status' Is Displayed...");

		/*
		 * isElementDisplayed("FavoriteTableColoums", "View");
		 * logMessage("'View' Is Displayed...");
		 */

		areElementsDisplayed("RemoveAllProjectFavorite");// for Star icon
		logMessage("Star Icon is Displayed...");

		areElementsDisplayed("FolderIcons");
		logMessage("'Folder Icon is Displayed..'");

	}

	public void verifyViewColoumNotDisplayedOnFavoriteTable() {
		Assert.assertTrue(verifyElementNotDisplayed("FavoriteTableColoums", "View"),
				"[Assertion Failed]:: View Coloum Displayed on Favorite Table");
		logMessage("[Assertion Passed]:: View Coloum is not Displayed on Favorite Table");
	}
	
	public void verifyEyeIconNotDisplayedOnFavoriteTable() {
		Assert.assertTrue(verifyElementNotDisplayed("FavEyeIcon"),
				"[Assertion Failed]:: Eye Icon is not Displayed on Favorite Table");
	}

	public void VerifyShowAllButtonDisplayed() {
		isElementDisplayed("ShowAll");
		logMessage("'Show all button Displayed...'");

	}

	public void clickShowAllButton() {
		isElementDisplayed("ProjectLink");
		String text = element("ProjectLink").getAttribute("innerText");
		int firstIndex = text.indexOf('(');
		int lastIndex = text.indexOf(')');
		int size = Integer.parseInt(text.substring(firstIndex + 1, lastIndex));
		logMessage("Number Of Project Shown::" + size);
		if (size > 5) {
			scrollToBottom();
			isElementDisplayed("ShowAll");
			click(element("ShowAll"));
			logMessage("'Show All' button Clicked...");
		} else {
			Assert.assertTrue(verifyElementNotDisplayed("ShowAll"),
					"[Assertion Failed]:: 'Show All' Button is Displayed.");
			logMessage("'Show All' Button Not Visible....");
		}
	}

	public void VerifyShowAllButtonDisplayAllProject() {
		areElementsDisplayed("RemoveAllProjectFavorite");
		logMessage("favorite project are displayed...");
		List<WebElement> projects = elements("RemoveAllProjectFavorite");
		if (projects.size() > 5) {
			logMessage("[Assertion Passed]:: Show All button Display All the Project");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Show All button Does not Display All the Project");
		}
	}

	public void VerifyGridAndListViewButton() {
		isElementDisplayed("FGridView");
		logMessage("Grid View button is Displayed...");

		isElementDisplayed("FListView");
		logMessage("List View button is Displayed...");

	}

	public void VerifyListViewDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("GridViewDisplayed"),
				"[Assertion Failed]::Favorite Project in Not in List View");
		logMessage("Favorite Project in List View");

	}

	public void clickGridView() {
		isElementDisplayed("FGridView");
		clickUsingJS(element("FGridView"));
		logMessage("Grid View is Clciked...");
		waitForLoaderToDisappear();
	}

	public void ClickListView() {
		isElementDisplayed("FListView");
		click(element("FListView"));
		logMessage("List View button is clicked...");
	}

	public void VerifyGridViewButtonToolTip() {
		isElementDisplayed("FGridView");
		hover(element("FGridView"));
		isElementDisplayed("ViewToolTip", "Grid View");

	}

	public void VerifyListViewButtonToolTip() {
		isElementDisplayed("FListView");
		hover(element("FListView"));
		isElementDisplayed("ViewToolTip", "List View");

	}

	public void VerifyGridViewDisplayed() {
		areElementsDisplayed("GridViewDisplayed");
		logMessage("Favorite Project in Grid View");

	}

	public void VerifyThumbnailinGridView() {
		areElementsDisplayed("Thumbnail");
		logMessage("Project Are Displayed in Thumbnail View");

	}

	public void VerifyFavoriteInformationInGridView() {
		isElementDisplayed("InfoInGrid", "Author:");
		logMessage("Author::'" + element("InfoInGrid", "Author:").getAttribute("innerText")
				+ "' Displayed in Thumbnail View");

		isElementDisplayed("GridInfoStar");
		logMessage("'Star Icon' is Displayed in Thumbnail View");

		isElementDisplayed("InfoInGrid", "Title:");
		logMessage("Title:'" + element("InfoInGrid", "Title:").getAttribute("innerText")
				+ "' Displayed in Thumbnail View");

		isElementDisplayed("InfoInGrid", "Edition:");
		logMessage("Edition::'" + element("InfoInGrid", "Edition:").getAttribute("innerText")
				+ "' Displayed in Thumbnail View");

		isElementDisplayed("InfoInGrid", "ISBN:");
		logMessage(
				"ISBN:'" + element("InfoInGrid", "ISBN:").getAttribute("innerText") + "' Displayed in Thumbnail View");

	}

	public void verifyShowLessButtonDisplayed() {
		isElementDisplayed("ShowLess");
		logMessage("Show Less Button Is Displayed...");

	}

	public void clickShowLessButton() {
		isElementDisplayed("ShowLess");
		clickUsingJS(element("ShowLess"));
		logMessage("Show Less Button Clicked..");
	}

	public void VerifyFavoriteTabIsDisplayed() {
		isElementDisplayed("FavoriteTab");
		logMessage("Favorite Tab is Displayed...");

	}

	public void VerifyOneProjectDisplayed() {
		areElementsDisplayed("ProjectDisplayed");
		if (elements("ProjectDisplayed").size() == 1) {
			logMessage("[Assertion Passed]:: Only One Project Is Displayed...");
		} else if (elements("ProjectDisplayed").size() == 0) {
			Assert.assertTrue(false, "[Assertion Failed]:: No Project Is Displayed...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: More than one Project Is Displayed...");
		}

	}

	public void VerifyCheckBoxAreApperingForProject() {
		clickShowAllButton();
		areElementsDisplayed("FavCheckBox");
		logMessage("CheckBox are Displayed for the Project.");
	}
	
	public void clickCheckBoxOnFavoriteTable() {
		areElementsDisplayed("FavCheckBox");
		hoverOverElement(elements("FavCheckBox").get(0));
		wait.waitForPageToLoadCompletely();
		click(elements("FavCheckBox").get(0));
		logMessage("Check box Clicked..");
	}
	
	public void verifyCheckBoxAreDisabledOnOnFavoriteTable() {
		areElementsDisplayed("FavCheckBox");
		hoverOverElement(elements("FavCheckBox").get(0));
		isAttribtuePresent(elements("FavCheckBox").get(0), "disabled");
		String CursorStatus=elements("FavCheckBox").get(0).getCssValue("cursor");
		logMessage("Cursor Property::"+CursorStatus);
		Assert.assertTrue(CursorStatus.trim().equals("not-allowed"),
				"[Assertion Failed]::Hand Icon Not Displayed..");
	}
	
	public void verifyTableRowGetsHighlightedOnHover() {
		areElementsDisplayed("FavTableRow");
		hoverOverElement(elements("FavTableRow").get(0));
		String backgroundStatus=elements("FavTableRow").get(0).getCssValue("background-color").trim();
		logMessage("Background Colour Displayed::"+backgroundStatus);
		Assert.assertTrue(backgroundStatus.equals("rgba(173, 216, 230, 1)"), "[Assertion Failed]::Background Colour Expected:rgba(173, 216, 230, 1)");
		
	}

	public void VerifyProjectDisplayedInTopOfTable(String ISBN) {
		isElementDisplayed("ProjectDispayedOnTop", ISBN);
		logMessage("Project od ISBN:" + ISBN + " IS Displayed on Top");

	}

	public void VerifyContentTypeNotDisplayedInUploadContentPopUp(String ContentType) {
		Assert.assertTrue(verifyElementNotDisplayed("ContentType", ContentType),
				"[Assertion Failed]::" + ContentType + " is dispalyed");
		logMessage(ContentType + " is not dispalyed..");

	}

	public void VerifyBrowseButtonIsMandatory() {
		isElementDisplayed("MandatoryField", "Select File");
		logMessage("Browse Button is Mandatory.");
	}

	public void VerifyContentTypeIsIsMandatory() {
		isElementDisplayed("MandatoryField", "Content Type");
		logMessage("Content Type is Mandatory.");

	}

	public void VerifyAuthorNameIsMandatory() {
		isElementDisplayed("MandatoryField", "Author Name");
		logMessage("Author Name is Mandatory.");
	}

	public void VerifyAuthorFieldsBackground() {
		isElementDisplayed("UploadFields", "Author Name");
		String Text = element("UploadFields", "Author Name").getAttribute("placeholder");
		Assert.assertTrue(Text.equals("Search for Author Name"),
				"[Assertion Failed]:: Incorrect Background text is Displayed:" + Text);
		logMessage("Correct Background Text is displayed 'Search for Author Name'");
	}

	public void VerifySearchIconOnAuthorField() {
		isElementDisplayed("AuthorSearch");
		logMessage("Search icon is Displayed..");

	}

	public void VerifyRemoveIconOnAuthorField() {
		isElementDisplayed("AuthorRemove");
		logMessage("Remove Icon is Displayed...");
	}

	public void EnterTextInAuthorField(String Text, boolean backspace) {
		isElementDisplayed("UploadFields", "Author Name");
		element("UploadFields", "Author Name").click();
		fillText(element("UploadFields", "Author Name"), Keys.chord(Text));
		if (backspace) {
			wait.waitForPageToLoadCompletely();
			element("UploadFields", "Author Name").sendKeys(Keys.BACK_SPACE);
		}
	}

	/// To verify the Vertical Scroll Bar on an Upload content Field
	public void VerifyScrollBarOnUploadContentField(String Field) {
		isElementDisplayed("ScrollBarOnField", Field);
		String AttriId = element("ScrollBarOnField", Field).getAttribute("id");
		if (AttriId.isEmpty()) {
			Assert.assertTrue(false, "[Asseetion Failed]:: Vertical Scroll Bar not Displayed on " + Field + " Filed.");
		} else if (AttriId.contains("scrollable-dropdown-menu")) {
			Assert.assertTrue(true, "[Asseetion Passed]:: Vertical Scroll Bar is Displayed on " + Field + " Filed.");
		} else {
			Assert.assertTrue(false, "[Asseetion Failed]:: Vertical Scroll Bar not Displayed on " + Field + " Filed.");
		}
	}

	public void VerifySuggestionForAuthorName_NotDisplayedInUploadContent() {
		wait.hardWait(1);
		Assert.assertTrue(verifyElementNotDisplayed("AuthorSuggestionBox"),
				"[Assertion Failed]::Suggestion box is displayed for Author Name");
		logMessage("Suggestion box is not displayed for Author Name...");
	}

	public void VerifySuggestionforAuthorNameDisplayedInUploadContent() {
		isElementDisplayed("AuthorSuggestionBox");
		logMessage("Suggestion box is displayed for Author Name...");
	}

	public String CombineAuthorNameAndId(String Name, String id) {
		logMessage("Author Name And ID::" + (Name + " - " + id));
		return (Name + " - " + id);
	}

	public void SelectAuthorName(String AuthorName) {
		wait.hardWait(1);
		isElementDisplayed("SelectAuthor", AuthorName);
		hover(element("SelectAuthor", AuthorName));
		wait.waitForPageToLoadCompletely();
		click(element("SelectAuthor", AuthorName));
		logMessage("Author Name And id '" + AuthorName + "' is selected...");

	}

	public void VerifyAuthorNameInTitleField(String NameID) {
		isElementDisplayed("UploadFields", "Title");
		String TextDisplayed = element("UploadFields", "Title").getAttribute("value");
		logMessage("Text Displayed::" + TextDisplayed);
		logMessage("Text Expected::" + NameID);
		Assert.assertTrue(TextDisplayed.equals(NameID),
				"[Assertion Failed]:: Incorrect Text is Displayed in Title Filed::" + TextDisplayed);
		logMessage("[Assertion Passed]:: Correct Text is Displayed in Title Filed::" + NameID);
	}

	public void VerifyTitleIsMandatory() {
		isElementDisplayed("MandatoryField", "Title");
		logMessage("Title Filed is Optional.");

	}

	public void VerifyTitleIsOptional() {
		Assert.assertTrue(verifyElementNotDisplayed("MandatoryField", "Title"),
				"[Assertion Failed]::Title Filed is Not Optional."); // Applyed Not Displayed Due to Author Image.
		logMessage("Title Filed is Optional.");

	}

	public void VerifyDescriptionIsOptional() {
		Assert.assertTrue(verifyElementNotDisplayed("MandatoryField", "Description"),
				"[Assertion Failed]::Description Filed is Not Optional.");
		logMessage("Description Filed is Optional.");

	}

	public void EnterTextIntoTitleField(String Text) {
		isElementDisplayed("UploadFields", "Title");
		fillText(element("UploadFields", "Title"), Text);

		String TextDisplayed = element("UploadFields", "Title").getAttribute("value");
		Assert.assertTrue(TextDisplayed.equals(Text), "[Assertion Failed]:: Title field is not editable.");
		logMessage("Title Filed is Editable.");
	}

	public void EnterTextIntoDescriptionField(String Text) {
		isElementDisplayed("DescriptionField");
		fillText("DescriptionField", Text);

		String TextDisplayed = element("DescriptionField").getAttribute("value");
		Assert.assertTrue(TextDisplayed.equals(Text), "[Assertion Failed]:: Description field is not editable.");
		logMessage("Description Filed is Editable.");
	}

	public void VerifyCountOfContentTypesDisplayedInUploadContentWindow(int Count) {
		Select TypeSelectDropDown = new Select(element("TypeSelect"));
		logMessage("Expected Content Type Count::" + Count);
		logMessage("Displayed Content Type Count::" + TypeSelectDropDown.getOptions().size());
		if (TypeSelectDropDown.getOptions().size() == Count) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "Expected Count of Content Type::" + Count + " Displayed Count of Content Type::"
					+ TypeSelectDropDown.getOptions().size());
		}

	}

	public void VerifyContentUploadedMessage() {
		areElementsDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");
		wait.waitForPageToLoadCompletely();
	}

	// ########### Recently Visited #############//

	public void Verify_Coloums_On_RecentlyVisited() {
		isElementDisplayed("RVTableColoum", "Author");
		isElementDisplayed("RVTableColoum", "Title");
		isElementDisplayed("RVTableColoum", "Short Title");
		isElementDisplayed("RVTableColoum", "ISBN");
		isElementDisplayed("RVTableColoum", "Content Type");
		isElementDisplayed("RVTableColoum", "Repository");
		isElementDisplayed("RVTableColoum", "Last Modified Date ");
		/* isElementDisplayed("RVTableColoum", "View"); */
	}

	public void clickRecentlyVisited() {
		isElementDisplayed("RecentlyVisited");
		click(element("RecentlyVisited"));
		logMessage("Recently Visited clicked");
	}

	public void VerifyProjectDisplayedOnRecentlyVisitedListView(String ISBN) {
		isElementDisplayed("RVProjectDisplayed", ISBN);
		logMessage("'" + ISBN + "' Displayed on Recently Visited");
	}

	public void VerifyProjectNotDisplayedOnRecentlyVisitedListView(String ISBN) {
		Assert.assertTrue(verifyElementNotDisplayed("RVProjectDisplayed", ISBN),
				"[Assertion Failed]:: " + ISBN + "' Displayed on Recently Visited Table");
		logMessage("'" + ISBN + "' Not Displayed on Recently Visited");
	}

	public void VerifyProjectDisplayedOnRecentlyVisitedGridView(String Title) {
		isElementDisplayed("RVProjectOrContentDisplayedGrid", Title);
		logMessage("'" + Title + "' Displayed on Recently Visited");
	}

	public void VerifyContentDisplayedOnRecentlyVisitedGridView(String AssetTitle) {
		isElementDisplayed("RVProjectOrContentDisplayedGrid", AssetTitle);
		logMessage("'" + AssetTitle + "' Displayed on Recently Visited");
	}

	public void OpenProjectDisplayedOnRecentlyVisited(String ISBN) {
		isElementDisplayed("RVProjectDisplayed", ISBN);
		hoverOverElement(element("RVProjectDisplayed", ISBN));
		wait.waitForPageToLoadCompletely();
		click(element("RVProjectDisplayed", ISBN));
		logMessage("Project of '" + ISBN + "' Click on Recently Visited");
		waitForLoaderToDisappear();
	}

	public void OpenProjectORContentDisplayedOnRecentlyVisitedGridView(String Title) {
		isElementDisplayed("RVGridViewThumbnail", Title);
		hoverOverElement(element("RVGridViewThumbnail", Title));
		wait.waitForPageToLoadCompletely();
		click(element("RVGridViewThumbnail", Title));
		logMessage("Project/Content with Name '" + Title + "' Click on Recently Visited");
		waitForLoaderToDisappear();
	}

	public void VerifyStarIconForProjectRecentlyVisited(String ISBN) {
		isElementDisplayed("MarkProjectFav", ISBN);
		logMessage("Star Icon Displayed for Project.");
	}

	public void VerifyContentDisplayedOnRecentlyVisited(String AssetName) {
		isElementDisplayed("RVContentDisplayed", AssetName);
		logMessage("'" + AssetName + "' Displayed on Recently Visited");
	}

	public void VerifyContentNotDisplayedOnRecentlyVisited(String AssetName) {
		Assert.assertTrue(verifyElementNotDisplayed("RVContentDisplayed", AssetName),
				"[Assertion Failed]:: " + AssetName + "' Displayed on Recently Visited Table");
		logMessage("'" + AssetName + "' Not Displayed on Recently Visited");
	}
	
	public void verifyRecentlyVisitedRowIsNotBlank() {
		String text=element("RVContentDisplayed", " ").getText().trim();
		Assert.assertTrue(text.length()>0,"[Assertion Failed]::  Empty Row is Displayed..");
	}

	public void OpenContentDisplayedOnRecentlyVisited(String AssetName) {
		isElementDisplayed("RVContentDisplayed", AssetName);
		hoverOverElement(element("RVContentDisplayed", AssetName));
		wait.waitForPageToLoadCompletely();
		click(element("RVContentDisplayed", AssetName));
		logMessage("'" + AssetName + "' Clicked on Recently Visited");
		waitForLoaderToDisappear();
	}

	public void RemoveProjectFromFavoriteRecentlyVisited(String ISBN) {
		isElementDisplayed("MarkProjectFav", ISBN);
		click(element("MarkProjectFav", ISBN));
		logMessage("'" + ISBN + "' Removed from Favorite..");
	}

	public void RemoveProjectToFavoriteFromRecentlyVisitedGridView(String Title) {
		isElementDisplayed("RVGridViewStarIcon", Title);
		click(element("RVGridViewStarIcon", Title));
		logMessage("'" + Title + "' Add To Favorite..");
	}

	public void AddProjectToFavoriteFromRecentlyVisited(String ISBN) {
		isElementDisplayed("MarkProjectFav", ISBN);
		click(element("MarkProjectFav", ISBN));
		logMessage("'" + ISBN + "' Add To Favorite..");
	}

	public void AddProjectToFavoriteFromRecentlyVisitedGridView(String Title) {
		isElementDisplayed("RVGridViewStarIcon", Title);
		click(element("RVGridViewStarIcon", Title));
		logMessage("'" + Title + "' Add To Favorite..");
	}

	public void VerifyCheckBoxGrayedOutOnRecently() {
		areElementsDisplayed("RVInputBox");
		logMessage("'Checkbox are Grayed out..'");
	}
	
	

	public void VerifyFolderIconForProject(String ISBN) {
		isElementDisplayed("FolderIconForProject", ISBN);
		logMessage("Folder Icon is Displayed for Projedct");
	}

	public void VerifyFileIconForContent(String AssetName) {
		isElementDisplayed("FileIconForContent", AssetName);
		logMessage("File Icon is Displayed for Content");
	}

	public void VerifyAuthorNameForProject(String ISBN) {
		isElementDisplayed("CheckAuthorNameProject", ISBN);
		String AuthorName = element("CheckAuthorNameProject", ISBN).getText().trim();
		if (AuthorName.length() <= 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Author Name Not Displayed for Project on Recently Visted Tab");
		} else {
			logMessage("Author Name Displayed for Project::" + AuthorName);
		}
	}

	public void VerifyAuthorNameNotDisplayedForContent(String AssertName) {
		isElementDisplayed("CheckAuthorNameContent", AssertName);
		String AuthorName = element("CheckAuthorNameContent", AssertName).getText().trim();
		if (AuthorName.length() > 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Author Name is Displayed for Content on Recently Visted Tab::" + AuthorName);
		} else {
			logMessage("Author Name Not Displayed for Content");
		}
	}

	public void VerifyStarIconNotDisplayedForAsset(String AssetName) {
		Assert.assertTrue(verifyElementNotDisplayed("NoStarIconForContent", AssetName),
				"[Assertion Failed]:: Star Icon Displayed for Asset on Recently Visited table");
	}

	public void VerifyTitleDisplayedOnRecentlyVisited() {
		areElementsDisplayed("CheckTitleOnRV");
		List<WebElement> TitleElements = elements("CheckTitleOnRV");
		for (WebElement TitleList : TitleElements) {
			String Title = TitleList.getText().trim();
			if (Title.length() <= 0) {
				Assert.assertTrue(false, "[Assertion Failed]:: Title Not Displayed on Recently Visted Tab");
			}
		}
	}

	public void VerifyShortTitleForProject(String ISBN, String projectShortTitle) {
		String ShortTitleDisplayed;
		isElementDisplayed("ProjectShortTitle", ISBN);
		String ToolTip = element("ProjectShortTitle", ISBN).getAttribute("uib-tooltip");
		if (ToolTip == null || ToolTip.length() < 0) {
			ShortTitleDisplayed = element("ProjectShortTitle", ISBN).getText().trim();
		} else {
			ShortTitleDisplayed = ToolTip;
		}

		logMessage("Short Title Displayed::" + ShortTitleDisplayed);
		logMessage("Short Title Expected::" + projectShortTitle);
		Assert.assertTrue(projectShortTitle.contains(ShortTitleDisplayed),
				"[Assertion Failed]:: InCorrect Short Title Displayed.");

	}

	public void VerifyShortTitleNotDisplayedForContent(String AssertName) {
		isElementDisplayed("CheckContentShortTitle", AssertName);
		if (element("CheckContentShortTitle", AssertName).getText().trim().length() > 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Short Title is Displayed for Content on Recently Visted Tab::"
							+ element("CheckContentShortTitle", AssertName).getText().trim());
		} else {
			logMessage("ShortTitle Not Displayed for Content");
		}
	}

	public void VerifyISBNNotDisplayedForContent(String AssertName) {
		isElementDisplayed("CheckContentISBN", AssertName);
		if (element("CheckContentISBN", AssertName).getText().trim().length() > 0) {
			Assert.assertTrue(false, "[Assertion Failed]:: ISBN is Displayed for Content on Recently Visted Tab::"
					+ element("CheckContentISBN", AssertName).getText().trim());
		} else {
			logMessage("ISBN Not Displayed for Content");
		}
	}

	public void VerifyContentTypeDisplayedForContent(String AssertName) {
		isElementDisplayed("CheckContentType", AssertName);
		String ContentType = element("CheckContentType", AssertName).getText().trim();
		if (ContentType.length() <= 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Content Type Not Displayed for Content on Recently Visted Tab");
		} else {
			logMessage("Content Type Displayed for Content on Recently Visted Tab");
		}
	}

	public void VerifyLastModifiedDateDisplayedForContent(String AssertName, String Date) {
		isElementDisplayed("CheckLastModifiedDate", AssertName);
		String LastModifiedDate = element("CheckLastModifiedDate", AssertName).getText().trim();
		logMessage(" Expected Last Modified Date::" + Date);
		logMessage("Displayed Last Modified Date::" + LastModifiedDate);
		Assert.assertTrue(LastModifiedDate.equals(Date),
				"[Assertion Failed]:: In Correct Last Modified date Displayed");
	}

	public void VerifyLastModifiedDateDisplayedForContent(String AssertName) {
		isElementDisplayed("CheckLastModifiedDate", AssertName);
		String ContentType = element("CheckLastModifiedDate", AssertName).getText().trim();
		if (ContentType.length() <= 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Last Modified date Not Displayed for Content on Recently Visted Tab");
		} else {
			logMessage("Last Modified date Displayed for Content on Recently Visted Tab");
		}
	}

	public void VerifyContentTypeNotDisplayedForProject(String ISBN) {
		isElementDisplayed("ProjectContentType", ISBN);
		String ContentType = element("ProjectContentType", ISBN).getText().trim();
		if (ContentType.length() > 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Content Type Displayed for Project on Recently Visted Tab::" + ContentType);
		} else {
			logMessage("Content Type Not Displayed for Project..");
		}
	}

	public void verifyRepositoryForContentType(String AssertName) {
		isElementDisplayed("ContentRepositoy", AssertName);
		String ContentType = element("ContentRepositoy", AssertName).getText().trim();
		if (ContentType.length() <= 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Repository Not Displayed for Content on Recently Visted Tab");
		} else {
			logMessage("Repository Displayed for Content on Recently Visted Tab");
		}
	}

	public void verifyRepositoryNotDisplayedForProject(String ISBN) {
		isElementDisplayed("ProjectRepository", ISBN);
		String ContentType = element("ProjectRepository", ISBN).getText().trim();
		if (ContentType.length() <= 0) {
			logMessage("Repository Not Displayed for Project on Recently Visted Tab");
		} else {
			Assert.assertTrue(false,
					"[Assertion Failed]:: Repository is Displayed for Project on Recently Visted Tab::" + ContentType);
		}
	}

	public void Verify_GridView_Recently_Visited() {
		areElementsDisplayed("RVGridView");
		logMessage("Grid View Displayed..");
	}

	public void VerifyProjectDetailGridViewRecentlyVisited() {
		isElementDisplayed("RVGridProject", "Author");
		isElementDisplayed("RVGridProject", "Title");
		isElementDisplayed("RVGridProject", "Edition");
		isElementDisplayed("RVGridProject", "ISBN");
	}

	public void VerifyContentDetailGridViewRecentlyVisited() {
		isElementDisplayed("RVGridContent", "Title");
		isElementDisplayed("RVGridContent", "File Name");
		isElementDisplayed("RVGridContent", "Content Type");
		isElementDisplayed("RVGridContent", "Last Updated");
	}

	public void verifyToolTipDisplayedOnRecentlyVisitedTableListView() {
		List<WebElement> tooltips = elements("AuthorFieldToolTip");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}

		tooltips = elements("TitleFieldToolTip");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}

		tooltips = elements("ContentTypeToolTip");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}

	}

	public void verifyToolTipDisplayedOnRecentlyVisitedTableGridView() {
		List<WebElement> tooltips = elements("GridViewToolTip");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}
	}

	public void VerifyOnly10EntriesDisplayedOnRecentlyVisited() {
		areElementsDisplayed("RVListOfItemsDisplayed");
		Assert.assertEquals(elements("RVListOfItemsDisplayed").size(), 10,
				"[Assertion Failed]:: Entries Displayed on Recently Visited Table::"
						+ elements("RVListOfItemsDisplayed").size());

	}

	// Will Verify the Author Filed on Recently Visited tab for Asset are blank
	public void VerifyAuthorFiledBlankForAssets() {
		areElementsDisplayed("AuthorFieldAssets");
		List<WebElement> ListOfAssets = elements("AuthorFieldAssets");
		for (int Asset = 0; Asset < ListOfAssets.size(); Asset++) {
			if (ListOfAssets.get(Asset).getText().trim().length() >= 1) {
				Assert.assertTrue(false, "Author Field is Not Empty for Asset on Content Tab");
			}
		}

	}

	// Will Verify the Author Filed on Recently Visited tab for Project are not
	// Blank
	public void VerifyAuthorFiledIsNotBlankForProject() {
		areElementsDisplayed("AuthorFieldProjects");
		List<WebElement> ListOfAssets = elements("AuthorFieldProjects");
		for (int Asset = 0; Asset < ListOfAssets.size(); Asset++) {
			if (ListOfAssets.get(Asset).getText().trim().length() < 1
					|| ListOfAssets.get(Asset).getText().trim().equals(" ")) {
				Assert.assertTrue(false, "Author Field is Empty for Project on Content Tab");
			}

		}
	}

	// ########### Recently Visited End ##############//
}
