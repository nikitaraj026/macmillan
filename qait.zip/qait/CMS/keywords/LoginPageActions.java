package com.qait.CMS.keywords;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;

public class LoginPageActions extends GetPage {

	public LoginPageActions(WebDriver driver) {
		super(driver, "LoginPage");
	}

	public void verifyEmailTextBoxDislayed() {
		isElementDisplayed("input_email");
		isElementDisplayed("input_email");
		logMessage("Email textbox is displayed");
	}

	public void verifyPasswordTextBoxDisplayed() {
		isElementDisplayed("input_passowrd");
		isElementDisplayed("input_passowrd");
		logMessage("Password text box is displayed");
	}

	public void verifyLogInButtonDisplayed() {
		isElementDisplayed("btn_signIn");
		isElementDisplayed("btn_signIn");
		logMessage("Login button is displayed");
	}

	public void enterEmailAddress(String email) {
		fillText("input_email", email);
		logMessage("Filled " + email + " in email field");
	}

	public void enterUserPassword(String password) {
		wait.hardWait(1);
		fillText("input_passowrd", password);
		logMessage("Filled " + password + " in password field");
	}

	public void clickLogInButton() {
		isElementDisplayed("btn_signIn");
		wait.hardWait(1);
		waitAndClick("btn_signIn");
		logMessage("Click SignIn button");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyErrorMessage(String expectederrormsg) {
		isElementDisplayed("errorMsg");
		String errormsg = element("errorMsg").getAttribute("innerText");
		Assert.assertTrue(errormsg.equals(expectederrormsg),
				"[ASSERTION FAILED]:Message displayed '" + errormsg + "' ");
		logMessage("[ASSERTION Passed]:Error message '" + errormsg + "' Displayed ");

	}

	public void clickForgetPassword() {
		isElementDisplayed("PasswordResetLink");
		clickUsingJS(element("PasswordResetLink"));
		logMessage("password reset link clicked");
	}

	public void VerifyPasswordUpdateMessageDisplayed(String expectedMessage) {
		isElementDisplayed("passwordResetMessage");
		String errormsg = element("passwordResetMessage").getAttribute("innerText").trim();
		Assert.assertTrue(errormsg.equals(expectedMessage), "[ASSERTION FAILED]:Password not updated");
		logMessage("[ASSERTION PASSED]:Password updated!!!! MESSAGE DISPLAYED::'" + errormsg + "'");

	}

	public void VerifyUserIsOnLoginPage(String loginPageLink) {
		String CurrentUrl;
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		CurrentUrl = getCurrentURL();
		logMessage(CurrentUrl);
		logMessage(loginPageLink);
		Assert.assertTrue(CurrentUrl.contains(loginPageLink), "[ASSERTION FAILED]:User is not Login Page");
		logMessage("User is on login Page!!!!!!!!!");

	}

	public void VerifyLoginButtonIsDisable() {
		isElementDisplayed("btn_signIn");
		logMessage("Sign in Button Displayed..");
		if (element("btn_signIn").getAttribute("disabled") == null) {
			logMessage("[Assertion Failed]::Login Button is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]::Login Button is Disabled...");
		}
	}

	public void VerifyOnPasswordResetFunction() {
		isElementDisplayed("restPasswordlabel");
		logMessage("Password rest link is working");

	}

	public void clickresetButton() {
		isElementDisplayed("btn_signIn");
		clickUsingJS(element("btn_signIn"));
		logMessage("Reset Button Clicked...");
	}

	public void VerifyAccountGetsLocked(String IvalidEmail, String InvalidPassword, String LockMessage) {
		verifyEmailTextBoxDislayed();
		verifyPasswordTextBoxDisplayed();
		wait.hardWait(1);
		fillText("input_email", IvalidEmail);
		logMessage("Filled " + IvalidEmail + " in email field");
		wait.hardWait(1);
		fillText("input_passowrd", InvalidPassword);
		logMessage("Filled " + InvalidPassword + " in password field");
		wait.hardWait(1);
		for (int i = 1; i <= 6; i++) {
			logMessage(i + " Attempt To Login...");
			isElementDisplayed("btn_signIn");
			isElementDisplayed("btn_signIn");
			logMessage("Login button is displayed");
			wait.hardWait(3);
			clickUsingJS(element("btn_signIn"));
			logMessage("Click SignIn button");
			wait.hardWait(2);
			isElementDisplayed("errorMsg");
			if (i != 6) {
				String errormsg = element("errorMsg").getAttribute("innerText");
				Assert.assertTrue(errormsg.equals("Username or password is incorrect"),
						"[ASSERTION FAILED]:Message displayed '" + errormsg + "' ");
				logMessage("[ASSERTION Passed]:Error message '" + errormsg + "' Displayed ");
			}
		}

		isElementDisplayed("AccountLockMessage");
		logMessage("Account Locked Message Displayed...");
		String Message = element("AccountLockMessage").getAttribute("innerText").trim().replace("\n", "");
		logMessage("Message Displayed::" + Message);
		Assert.assertTrue(Message.equals(LockMessage), "[Assertion Failed]:: Incorrect Message Not Displayed...");
		logMessage("[Assertion Passed]:: Correct Message Is Displayed..." + Message);

	}

}
