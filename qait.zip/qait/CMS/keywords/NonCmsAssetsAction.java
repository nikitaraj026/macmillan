package com.qait.CMS.keywords;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;

public class NonCmsAssetsAction extends GetPage {

	public NonCmsAssetsAction(WebDriver driver) {
		super(driver, "NonCmsAssets");
	}

	public void VerifyFunctionalityIsDisabled() {

		isElementDisplayed("topLink", "Edit");
		String classes = element("topLink", "Edit").getAttribute("class");
		Assert.assertTrue(classes.contains("disable-btn"),
				"[Assertion Failed]: User is able to 'EDIT' the Non Cms Assets");
		logMessage("[Assertion Passed]: User is unable to 'EDIT' the Non Cms Assets");

		isElementDisplayed("topLink", "Delete");
		classes = element("topLink", "Delete ").getAttribute("class");
		Assert.assertTrue(classes.contains("disable-btn"),
				"[Assertion Failed]: User is able to 'DELETE' the Non Cms Assets");
		logMessage("[Assertion Passed]: User is unable to 'DELETE' the Non Cms Assets");

		isElementDisplayed("SubTab", "Version Details");
		wait.hardWait(2);
		waitAndClick("SubTab", "Version Details");
		logMessage("Version Detail Clicked");

		isElementDisplayed("VersionOperation", "Upload a new version");
		classes = element("VersionOperation", "Upload a new version").getAttribute("disabled");
		logMessage(classes);
		Assert.assertTrue(classes.contains("true"),
				"[Assertion Failed]: User is able to 'Upload a new version' of Non Cms Assets");
		logMessage("[Assertion Passed]: User is unable to 'Upload a new version' the Non Cms Assets");

	}

	public void VerifyUserIsableToApproveOrUnapprove() {
		isElementDisplayed("SelectVersion");
		clickUsingJS(element("SelectVersion"));
		logMessage("version selected");

		isElementDisplayed("contentStatus");
		String Status = element("contentStatus").getAttribute("innerText");
		logMessage("Current status of Version::" + Status);

		if (Status.equalsIgnoreCase("Not Approved")) {
			isElementDisplayed("VersionOperation", "Approve");
			clickUsingJS(element("VersionOperation", "Approve"));
			logMessage("Approved button clicked");
			wait.hardWait(5);
			Status = element("contentStatus").getAttribute("innerText");
			logMessage("Current status of Version::" + Status);
			if (Status.contains("Approved")) {
				logMessage("[Assertion Passed]: User was able to Approve the content version.");
			} else {
				logMessage("[Assertion Failed]: User was unable to Approve the content version.");
			}

			isElementDisplayed("VersionOperation", "Unapprove");
			clickUsingJS(element("VersionOperation", "Unapprove"));
			logMessage("Unapprove button clicked");
			wait.hardWait(5);
			Status = element("contentStatus").getAttribute("innerText");
			logMessage("Current status of Version::" + Status);
			Assert.assertTrue(Status.contains("Not Approved"),
					"[Assertion Failed]: User was unable to Unapprove the content version.");
			logMessage("[Assertion Passed]: User was able to Unapprove the content version.");
		} else {
			isElementDisplayed("VersionOperation", "Unapprove");
			clickUsingJS(element("VersionOperation", "Unapprove"));
			logMessage("Unapprove button clicked");
			wait.hardWait(5);
			Status = element("contentStatus").getAttribute("innerText");
			logMessage("Current status of Version::" + Status);
			if (Status.contains("Not Approved")) {
				logMessage("[Assertion Passed]: User was ABLE to Unapprove the content version.");
			} else {
				logMessage("[Assertion Failed]: User was UNABLE to Unapprove the content version.");
			}

			isElementDisplayed("VersionOperation", "Approve");
			clickUsingJS(element("VersionOperation", "Approve"));
			logMessage("Approved button clicked");
			wait.hardWait(5);
			Status = element("contentStatus").getAttribute("innerText");
			logMessage("Current status of Version::" + Status);
			Assert.assertTrue(Status.contains("Approved"),
					"[Assertion Failed]: User was unable to Approve the content version.");
			logMessage("[Assertion Passed]: User was able to Approve the content version.");
		}
	}

}
