package com.qait.CMS.keywords;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.YamlReader;

public class SearchPageAction extends GetPage {

	public SearchPageAction(WebDriver driver) {
		super(driver, "SearchPage");
	}

	public void clickAdvanceSearch() {
		wait.hardWait(1);
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AdvanceSearchLink");
		clickUsingJS(element("AdvanceSearchLink"));
		logMessage("Advance Search Clicked");

	}

	public void VerifyOnAdvanceSearchPopUp() {
		areElementsDisplayed("reset");
		logMessage("On Advance Search Pop up..");
	}

	public void SelectLookFor(String lookFor) {
		wait.hardWait(1);
		isElementDisplayed("SearchType");
		selectTextFromDropDown("SearchType", lookFor);
		logMessage(lookFor + " Selected From The look For Drop Down");
	}

	public void ClickSelectAllInSearchResult() {
		waitForLoaderToDisappear();
		isElementDisplayed("SelectAll");
		isElementDisplayed("SelectAll");
		hover(element("SelectAll"));
		wait.hardWait(1);
		clickUsingJS(element("SelectAll"));
		logMessage("'Select All Check Box Clciked....'");
		wait.hardWait(2);
	}

	public void ClickPageSelectionDropDown() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("PageSelectionButton");
		wait.waitForElementToBeClickable(element("PageSelectionButton"));
		scroll(element("PageSelectionButton"));
		hover(element("PageSelectionButton"));
		wait.hardWait(1);
		wait.waitForPageToLoadCompletely();
		clickUsingJavaScript("PageSelectionButton");
		logMessage("Page Selection Dropdown Clicked..");
	}

	public void PageSelection(String PageType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("PublishWindowPageSelection", PageType);
		element("PublishWindowPageSelection", PageType).click();
		logMessage("'" + PageType + "' select in page Selection.");
	}
	
	public void VerifyHandIconOnSelectAllOption(String Option) {
		isElementDisplayed("PublishWindowPageSelection", Option);
		wait.hardWait(1);
		hover(element("PublishWindowPageSelection", Option));
		logMessage("Cursor Property::" + element("PublishWindowPageSelection", Option).getCssValue("cursor"));
		Assert.assertTrue(element("PublishWindowPageSelection", Option).getCssValue("cursor").trim().equals("pointer"),
				"[Assertion Failed]::Hand Icon Not Displayed..");
	}

	public void VerifyPageNotSelectedInDropDown(String PageSelection) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("CheckPageSelection", PageSelection),
				"[Asserion Failed]::" + PageSelection + " is Selected...");
		logMessage("'" + PageSelection + "' is Not Selected...");
	}

	public void VerifyPageIsSelectedInDropDown(String PageSelection) {
		isElementDisplayed("CheckPageSelection", PageSelection);
		logMessage(PageSelection + " is  Selected...");
	}

	public void VerifyAdvanceSearchForAsset(String assetName) {

		isElementDisplayed("AddField");
		selectTextFromDropDown("AddField", "Content Type");
		logMessage("Content Type Seleted From Add Field Drop Down");

		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add Button Clicked");

		isElementDisplayed("TypeOfField", "1");
		selectTextFromDropDown("TypeOfField", "1", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Enhanced EPUB Selected...");

		isElementDisplayed("submitButton");
		clickUsingJS(element("submitButton"));
		logMessage("Submit Button Clicked");

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("countOfContents");
		String text = element("countOfContents").getAttribute("innerText");
		String[] parts = text.split(" ");
		int Count1 = Integer.parseInt(parts[4]);
		logMessage("text=" + Count1);

		refreshPage();
		waitForLoaderToDisappear();
		clickDashBord();
		clickAdvanceSearch();
		SelectLookFor("Assets");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeOfField", "1");
		selectTextFromDropDown("TypeOfField", "1", getData("TypesOfContent.Project Support Materials>CFI"));
		logMessage("CFI Selected...");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("submitButton");
		clickUsingJS(element("submitButton"));
		logMessage("Submit Button Clicked");

		waitForLoaderToDisappear();
		isElementDisplayed("countOfContents");
		text = element("countOfContents").getAttribute("innerText");
		parts = text.split(" ");
		int Count2 = Integer.parseInt(parts[4]);
		logMessage("text=" + Count2);

		refreshPage();
		waitForLoaderToDisappear();
		clickDashBord();
		clickAdvanceSearch();
		SelectLookFor("Assets");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("AddField");
		selectTextFromDropDown("AddField", "Content Type");
		logMessage("Content Type Seleted From Add Field Drop Down");
		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add Button Clicked...");

		isElementDisplayed("TypeOfField", "1");
		selectTextFromDropDown("TypeOfField", "1", getData("TypesOfContent.Project Support Materials>CFI"));
		logMessage("CFI Selected...");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeOfField", "2");
		selectTextFromDropDown("TypeOfField", "2", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Enhanced ePub > Full Package Selected...");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("AddOR");
		selectTextFromDropDown("AddOR", "OR");
		logMessage("OR Selected...");

		isElementDisplayed("submitButton");
		clickUsingJS(element("submitButton"));
		logMessage("Submit Button Clicked..");

		waitForLoaderToDisappear();
		isElementDisplayed("countOfContents");
		text = element("countOfContents").getAttribute("innerText");
		parts = text.split(" ");
		int Count3 = Integer.parseInt(parts[4]);
		logMessage("text=" + Count3);

		if (Count3 == Count1 + Count2) {
			logMessage("[Assertion passed]:: Correct result are displayed");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: InCorrect result are displayed");
		}
	}

	private void clickDashBord() {
		scrollToTop();
		wait.hardWait(1);
		isElementDisplayed("DashbordTab");
		clickUsingJS(element("DashbordTab"));
		logMessage("DashBord clicked");
		isElementDisplayed("DashbordDispaly");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyResetButtonIsDispaled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("reset");
		logMessage("Reset Button Is displayed..");
	}
	
	public void ClickX_OnWindow() {
		isElementDisplayed("ClosePopup");
		wait.waitForPageToLoadCompletely();
		hoverOverElement(element("ClosePopup"));
		click(element("ClosePopup"));
		logMessage("x icon Clicked...");
	}
	
	public void ClickResetButton() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("reset");
		clickUsingJS(element("reset"));
		logMessage("Reset Button Is Clicked..");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyResetButton() {
		SelectLookFor("Assets");
		isElementDisplayed("AddField");
		selectTextFromDropDown("AddField", "Content Type");
		logMessage("'Content Type' selected in AddField");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add button clicked");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("TypeOfField", "1");
		logMessage("'Content Type' field add");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("reset");
		clickUsingJS(element("reset"));
		logMessage("Reset button clicked");
		Assert.assertTrue(verifyElementNotDisplayed("TypeOfField", "1"),
				"[Assertion Failed]: Added filed is Displayed!!! ,Reset functionaliy is not working");
		logMessage("[Assertion Passed]: Added filed removed!!! ,Reset functionaliy is working");

	}

	public void VerifyResultAreAccordingToSearchedText(String SearchedText) {
		isElementDisplayed("VerifySearchResult");
		Assert.assertTrue(element("VerifySearchResult").getAttribute("innerText").contains(SearchedText),
				"[Assertion Failed]: Search Functionaliy failed");
		logMessage("[Assertion Passed]: Search leads a user to navigate at search results page");
	}

	public void VerifySuggestionAreProvided(String SearchItem) {

		isElementDisplayed("searchbar");
		scrollToTop();
		clickUsingJS(element("searchbar"));
		String selectAll = Keys.chord(SearchItem);
		element("searchbar").clear();
		element("searchbar").sendKeys(selectAll);
		logMessage(selectAll + " entered in search bar");
		wait.waitForPageToLoadCompletely();
		element("searchbar").sendKeys(Keys.BACK_SPACE);
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("Suggestion");
		logMessage("suggestion SECTION is displayed");
		Assert.assertTrue(element("Suggestion").getAttribute("aria-hidden").contains("false"),
				"[Assertion Failed]: Suggestion are not Provided ");
		logMessage("[Assertion Passed]: Suggestion are Provided!!!!!");
	}

	public void VerifyAllTheContentIsSelected(int TillIndex) {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		areElementsDisplayed("SelectContent");
		List<WebElement> SelectedInput = elements("SelectContent");
		for (int i = 0; i < TillIndex; i++) {
			if (SelectedInput.get(i).getAttribute("checked") == null) {
				logMessage("[Assertion Failed]::" + i + 1 + " Input button Is Not Checked After Clicking Select All");
				Assert.assertFalse(false);
			}
			logMessage(i + 1 + " Input Box Is Selected..");
		}
		logMessage("[Assertion Passed]:: The Input buttons are Checked After Clicking Select All");

	}

	public void AddNewFieldInAdvancedSearchPopUpAndVerify(String FieldType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AddField");
		// click(element("AddField"));
		selectTextFromDropDown("AddField", FieldType);
		logMessage("'" + FieldType + "' selected in Add field");

		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add button Clicked....");

		isElementDisplayed("VerifySingleFieldAdded");
		logMessage("New Field has been Added....");
	}

	public void AddNewFieldInAdvancedSearchPopUp(String FieldType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AddField");
		selectTextFromDropDown("AddField", FieldType);
		logMessage("'" + FieldType + "' selected in Add field");

		areElementsDisplayed("AddButton");
		clickUsingJS(element("AddButton"));
		logMessage("Add button Clicked....");
	}
	
	public void VerifyOptionInAddNewFieldOnAdvancedSearchPopUp(String FieldType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AddField");
		selectTextFromDropDown("AddField", FieldType);
		logMessage("'" + FieldType + "' selected in Add field");
	}

	public void SelectContentTypeInNewAddedField(String Select) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectOptionsFromSingleFieldAdded");
		clickUsingJS(element("SelectOptionsFromSingleFieldAdded"));
		selectTextFromDropDown("SelectOptionsFromSingleFieldAdded", Select);
		logMessage("'" + Select + "' Selected In Content type Field....");

	}

	public void VerifyFieldNotDisplayedInAddNewFiled(String Option) {
		isElementDisplayed("AddField");
		clickUsingJS(element("AddField"));

		Select AddnewfieldDropDown = new Select(element("AddField"));
		List<WebElement> AllSelectOptions = AddnewfieldDropDown.getOptions();
		int iSize = AllSelectOptions.size();

		for (int counter = 0; counter < iSize; counter++) {
			if (AllSelectOptions.get(counter).getText().equals(Option)) {
				Assert.assertFalse(true, "[Assertion Failed]::'" + Option
						+ "' is Displayed on Add new field DropDrop");
			}
		}
		logMessage("'" + Option + "' is Not Displayed on Add new field DropDrop");
	}

	public void VerifyUserIsAbleToMakeAdvanceSearch(String SearchedItem) {
		isElementDisplayed("SearchContent");
		element("SearchContent").clear();
		wait.hardWait(1);
		element("SearchContent").sendKeys(SearchedItem);

		isElementDisplayed("AddField");
		selectTextFromDropDown("AddField", "Content Type");

		isElementDisplayed("AddButton");
		clickUsingJS(element("AddButton"));

		isElementDisplayed("TypeOfField", "1");
		selectTextFromDropDown("TypeOfField", "1", "Enhanced ePub > Full Package");
		logMessage("Enhanced ePub > Full Package selected...");

		isElementDisplayed("submitButton");
		clickUsingJS(element("submitButton"));
	}

	public void EnterTextIntoSearchBox(String Text) {
		isElementDisplayed("SearchContent");
		element("SearchContent").clear();
		wait.hardWait(1);
		element("SearchContent").sendKeys(Text);
		logMessage(Text + " is entered In the Search box");
	}

	public void ClickSearchButton() {
		wait.hardWait(1);
		isElementDisplayed("submitButton");
		clickUsingJS(element("submitButton"));
		logMessage("Search Button Clicked...");
		waitForLoaderToDisappear();
		wait.hardWait(1);
	}

	public void AddProjectToFavorite(String ISBN) {
		isElementDisplayed("AddToFav", ISBN);
		logMessage(ISBN + " Project Displayed...");
		clickUsingJS(element("AddToFav", ISBN));
		logMessage("Star Icon Clicked...");
		logMessage(ISBN + " Project Is added to Favorite...");

	}
	
	public void removeProjectFromFavorite(String ISBN) {
		isElementDisplayed("AddToFav", ISBN);
		logMessage(ISBN + " Project Displayed...");
		clickUsingJS(element("AddToFav", ISBN));
		logMessage("Star Icon Clicked...");
		logMessage(ISBN + " Project Is Removed from Favorite...");

	}
	
	public void verifyMessageDisplayedOnFavoriteAdded() {
		isElementDisplayed("FavMarkUnMarkMsg",getData("FavoritesMarkedMsg"));
		logMessage("Message Displayed::"+getData("FavoritesMarkedMsg"));
	}
	
	public void verifyMessageDisplayedOnFavoriteRemoved() {
		isElementDisplayed("FavMarkUnMarkMsg",getData("FavoritesRemovedMsg"));
		logMessage("Message Displayed::"+getData("FavoritesRemovedMsg"));
	}
	
	public void VerifyFavoriteMessageColor() {
		String ColourDisplayed=element("FavMsgColour").getCssValue("color").trim();
		logMessage("Colour Displayed::"+ColourDisplayed);
		Assert.assertTrue(ColourDisplayed.equals("rgba(60, 118, 61, 1)"));
	}
	
	public void verifyFavoriteToasterMessageAppears_For_5_Seconds() {
		isElementDisplayed("FavMsgColour");
		wait.hardWait(5);
		Assert.assertTrue(verifyElementNotDisplayed("FavMsgColour"));
	}

	public void SelectAssetOnSearchPage(String FileName) {
		wait.hardWait(1);
		isElementDisplayed("SelectAssert", FileName);
		scroll(element("SelectAssert", FileName));
		wait.waitForPageToLoadCompletely();
		logMessage(FileName + " Is Displayed...");
		clickUsingJS(element("SelectAssert", FileName));
		logMessage(FileName + " Asset is Selected...");

	}

	public void ClickAddToProject() {
		isElementDisplayed("AddToProject");
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("AddToProject"));
		logMessage("AddToProject clicked");
	}

	public void VerifyAddtoProjectpopUp() {
		areElementsDisplayed("AddtoProjectlabel");
		logMessage("Add to project popup displayed");
	}

	public void SearchForProjectOnAddRemoveContent(String ISBN) {
		isElementDisplayed("SearchProject");
		isElementDisplayed("SearchProject");
		clickUsingJS(element("SearchProject"));
		String ISBNc = Keys.chord(ISBN);
		wait.waitForPageToLoadCompletely();
		element("SearchProject").sendKeys(ISBNc);
		clickUsingJS(element("SubmitProject"));
		logMessage("Search button clicked");
		logMessage("Project of " + ISBN + " Searched..");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyOneProjectDisplayed() {
		wait.waitForPageToLoadCompletely();
		if (elements("ProjectDisplayed").size() == 1) {
			logMessage("[Assertion Passed]:: Only One Project Is Displayed...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: More than One Project Is Displayed...");
		}

	}

	public void ClickOrganizedDownload() {
		isElementDisplayed("OrganizedDownload");
		// waitForElementToBeClickable(element("OrganizedDownload"));
		clickUsingJS(element("OrganizedDownload"));
		logMessage("Organized Download Clicked");
		waitForLoaderToDisappear();
	}

	public void createFolderInDirectory(String folderName) {
		logMessage("Working Directory = " + System.getProperty("user.dir") + "\\src\\test\\resources");
		String downloadPath = System.getProperty("user.dir") + "\\src\\test\\resources";
		File dir = new File(downloadPath + "/" + folderName);
		if (dir.exists()) {
			logMessage(folderName + " Folder has already exists in " + downloadPath);
		} else {
			boolean isDirectoryCreated = dir.mkdir();
			if (isDirectoryCreated)
				logMessage("Directory successfully created: " + dir);
			else
				logMessage("Directory was not created successfully: " + dir);
		}
	}

	public void clearFilesFromFolder(String folderName) throws IOException {
		String downloadPath = System.getProperty("user.dir") + "\\src\\test\\resources";
		File dir = new File(downloadPath + "/" + folderName);
		FileUtils.cleanDirectory(dir);
		logMessage("All files from " + dir + " has been deleted");
	}

	public void clickDownloadContent() throws IOException {
		// waitForElementToBeClickable(element("DownloadContent"));
		// createFolderInDirectory("CMS_Downloads");
		// clearFilesFromFolder("CMS_Downloads");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("DownloadContent");
		clickUsingJS(element("DownloadContent"));
		logMessage("Download content Clicked");

	}

	public void VerifySelectAllIsDisabled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectAll");
		String Attri = element("SelectAll").getAttribute("disabled");
		if (Attri != null) {
			logMessage("[Assertion Passed]:: Select All button is Disabled.");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Select All button is Enabled.");
		}
	}

	public void VerifyContentsAreSelected() {
		wait.waitForPageToLoadCompletely();
		wait.hardWait(1);
		areElementsDisplayed("ContentInputTag");
		List<WebElement> content = elements("ContentInputTag");
		wait.hardWait(1);
		for (int i = 0; i < content.size(); i++) {
			if (content.get(i).isSelected()) {
				logMessage("Content" + (i + 1) + " Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content Is Not Selected...");
			}
		}
	}

	public void VerifyContentsAreSelected(int TillIndex) {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("ContentInputTag");
		List<WebElement> content = elements("ContentInputTag");
		wait.hardWait(1);
		for (int i = 0; i < TillIndex; i++) {
			if (content.get(i).isSelected()) {
				logMessage((i + 1) + "Content Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content Is Not Selected...");
			}
		}
		if (content.get(TillIndex).isSelected()) {
			Assert.assertTrue(false, "[Assertion Failed]::" + (TillIndex + 1) + "Content Is Selected...");

		}
	}

	public void VerifyContentsAreNotSelected() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		wait.hardWait(1);
		areElementsDisplayed("ContentInputTag");
		List<WebElement> content = elements("ContentInputTag");
		wait.hardWait(1);
		for (int i = 0; i < content.size(); i++) {
			if (content.get(i).isSelected()) {
				Assert.assertTrue(false, "[Assertion Failed]::Content Is Selected...");

			} else {
				logMessage("Is not Selected.....");
			}
		}
	}

	public void VerifyProjectsAreNotSelected() {
		waitForLoaderToDisappear();
		waitForPageToLoadCompletely(getPageTitle());
		wait.hardWait(1);
		List<WebElement> Projects = elements("ProjectInputTag");
		wait.hardWait(1);
		for (int i = 0; i < Projects.size(); i++) {
			String Attri = Projects.get(i).getAttribute("disabled");
			logMessage(Attri);
			if (Attri == null || Projects.get(i).isSelected()) {
				Assert.assertTrue(false, "[Assertion Failed]::Project Is Selected...");

			} else {
				logMessage("Project Is Not Selected...");
			}
		}

	}

	public void VerifyThumbnailForDamRepo() {
		waitForLoaderToDisappear(); ////////////// if Fails Apply 10 sec Hard
									////////////// Wait====> So that Images Can
									////////////// be loaded
		wait.hardWait(5);
		areElementsDisplayed("DamRepoImages");
		List<WebElement> Images = elements("DamRepoImages");
		for (int i = 0; i < Images.size(); i++) {
			String SRC = Images.get(i).getAttribute("src");
			if (SRC.contains("img/blank.jpg") || SRC == null) {
				logMessage("[Assertion Failed]:: Thumbnail Image For The DAM Content Are Not Shown...");
				Assert.assertTrue(false);
			} else {
				logMessage("[Assertion Passed]:: Thumbnail Image For The DAM Content is Shown...");
			}
		}
	}

	public void NavigateToPage(String Number) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("navigate", Number);
		scrollToBottom();
		wait.hardWait(1);
		click(element("navigate", Number));
		logMessage("page number " + Number + " clicked... Able To move from pagination Bar");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		wait.hardWait(1);
	}

	public void SelectContents(int Count) {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("CheckContents");
		List<WebElement> input = elements("CheckContents");
		for (int i = 0; i < Count; i++) {
			wait.hardWait(1);
			wait.waitForPageToLoadCompletely();
			hover(input.get(i));
			input.get(i).click();
			logMessage((i + 1) + " Content Selected...");
		}
	}

	public void SelectAllTheContentsManually() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("CheckContents");
		List<WebElement> input = elements("CheckContents");
		for (int i = 0; i < input.size(); i++) {
			wait.hardWait(1);
			wait.waitForPageToLoadCompletely();
			hover(input.get(i));
			input.get(i).click();
			logMessage((i + 1) + " Content Selected...");
		}
	}

	public void SelectProjectOnSearchPage(String ISBN) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectProject", ISBN);
		clickUsingJS(element("SelectProject", ISBN));
		logMessage("Project Is Clicked...");

	}

	public void VerifyProjectNotDispalyedOnSearchPage(String ISBN) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("SelectProject", ISBN),
				"[Assertion failed]::Project of ISBN::" + ISBN + "Displayed");

	}

	public void VerifyProjectISNotSelected(String ISBN) {
		wait.hardWait(1);
		String Attri = element("SelectProject", ISBN).getAttribute("disabled");
		Assert.assertTrue(Attri.contains("true"), "[Assertion Failed]:: Project Can Be Selected....");
		logMessage("[Assertion Passed]:: Project Can Not Be Selected....");
	}

	public void VerifyCountOfNewFieldAdded(int count) {
		wait.hardWait(2);
		VerifyOnAdvanceSearchPopUp();
		areElementsDisplayed("TypefieldCount");
		List<WebElement> elem = elements("TypefieldCount");
		int size = elem.size();
		if (size == count) {
			logMessage("[Assertion Passed]::" + count + " field has been added...");
		} else {
			logMessage("Number of field displayed::" + size);
			logMessage("Number of field expected::" + count);
			Assert.assertTrue(false);
		}
	}

	public void VerifyPSL_IsNotDisplayed() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("TypeOfField", "1");
		isElementDisplayed("TypeOfField", "1");
		logMessage("Added field is displayed...");
		hover(element("TypeOfField", "1"));
		click(element("TypeOfField", "1"));
		wait.hardWait(1);
		Assert.assertTrue(verifyElementNotDisplayed("PSL"), "[Assertion Failed]::PSL Is  Displayed");
		logMessage("PSL Is not Displayed");
	}

	public void VerifyElementNotDisplayedAddedField(String number, String ContentType) {
		wait.hardWait(1);
		isElementDisplayed("TypeOfField", number);
		isElementDisplayed("TypeOfField", number);
		logMessage("Added field is displayed...");
		wait.hardWait(1);
		Assert.assertTrue(verifyElementNotDisplayed("TypeFiledNotDisplayed", number, ContentType),
				"[Assertion Failed]::" + ContentType + " Is Displayed");
		logMessage(ContentType + " Is not Displayed");

	}

	public void AND_OR_Option_Select(String option) {
		isElementDisplayed("AddOR");
		selectTextFromDropDown("AddOR", option);
		logMessage(option + " Selected...");
	}

	public void SelectContentTypeInAddedField(String index, String ContentType) {
		isElementDisplayed("TypeOfField", index);
		selectTextFromDropDown("TypeOfField", index, ContentType);
		logMessage(ContentType + " selected...");
	}

	// This Method is used to Select the Text from DropDown Added through Add a new
	// field,where index is the position of the DropDown
	public void SelectTextFromInAddedDropDown(int index, String Text) {
		isElementDisplayed("AdvanceSearchQueryDropDown", index + "");
		selectTextFromDropDown("AdvanceSearchQueryDropDown", index + "", Text);
		logMessage(Text + " Selected in DropDown");
	}

	public void VerifyTextNotDisplayedInAddedDropDown(int index, String Text) {
		isElementDisplayed("AdvanceSearchQueryDropDown", index + "");
		Select AddnewfieldDropDown = new Select(element("AdvanceSearchQueryDropDown", index + ""));
		List<WebElement> AllSelectOptions = AddnewfieldDropDown.getOptions();
		int iSize = AllSelectOptions.size();

		for (int counter = 0; counter < iSize; counter++) {
			if (AllSelectOptions.get(counter).getText().trim().equalsIgnoreCase(Text.trim())) {
				Assert.assertFalse(true, "[Assertion Failed]::'" + Text + "' is Displayed on Add new field DropDrop");
			}
		}
		logMessage("'" + Text + "' is Not Displayed on Add new field DropDrop");
	}

	// This Method is used to Enter the Text into Input Bar Added through Add a new
	// field,where index is the position of the Input Bar
	public void EnterTextFromInAddedInputBar(int index, String Text) {
		isElementDisplayed("AdvanceSearchQueryinput", index + "");
		fillText("AdvanceSearchQueryinput", index + "", Text);
		logMessage(Text + " Entered in Input Bar");
	}

	public void VerifySuggestionOnAdvanceSearchPopupAddedInputBar(int index) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AdvanceSearchsuggestionForinput", index + "");
		logMessage("Suggestion Displayed on Advance Search...");
	}
	
	public void VerifySuggestionOnAdvanceSearchPopupAddedInputBarNotDisplayed(int index) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("AdvanceSearchsuggestionForinput", index + ""));
		logMessage("Suggestion Displayed on Advance Search...");
	}

	public void VerifyCountOfAvailableOptionsInAddedField(String index, int ExpectedCount) {
		isElementDisplayed("TypeOfField", index);
		Select TypeSelectDropDown = new Select(element("TypeOfField", index));
		logMessage("Expected Count Of Available Options::" + ExpectedCount);
		logMessage("Displayed Count Of Available Options::" + TypeSelectDropDown.getOptions().size());
		if (TypeSelectDropDown.getOptions().size() == ExpectedCount) {
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "Expected Count Of Available Optionse::" + ExpectedCount
					+ "Displayed Count Of Available Options::" + TypeSelectDropDown.getOptions().size());
		}
	}

	public void DeleteAddedTypeField(String index) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("DeleteTypeField", index);
		clickUsingJS(element("DeleteTypeField", index));
		logMessage("'x' button clicked on Added Type Field...");
	}

	public void VerifyFieldIsDeleted() {
		Assert.assertTrue(verifyElementNotDisplayed("TypeOfField", "1"),
				"[Assertion Failed]: Added filed Displayed!!!");
		logMessage("[Assertion Passed]: Added filed removed!!!");
	}

	public void VerifyCheckBoxAreApperingForProject() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("CheckBox");
		logMessage("CheckBox are Displayed for the Project.");
	}

	private File getLatestFilefromDir(String dirPath) {
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if (files == null || files.length == 0) {
			return null;
		}

		File lastModifiedFile = files[0];
		for (int i = 1; i < files.length; i++) {
			if (lastModifiedFile.lastModified() < files[i].lastModified()) {
				lastModifiedFile = files[i];
			}
		}
		return lastModifiedFile;
	}

	public void VerifyDownloadIsStartedFromAdvanceSearch() {
		isElementDisplayed("GetSingleFileDownloadName");
		String FileName = element("GetSingleFileDownloadName").getAttribute("innerText");

		wait.hardWait(5); // wait for instance of the File to be created at Directory
		String DownloadPath = System.getProperty("user.dir") + "\\ScoresImportExport";
		File getLatestFile = getLatestFilefromDir(DownloadPath);
		String LatestFileName = getLatestFile.getName();
		logMessage("Latest File Downloaded::" + LatestFileName);
		logMessage("File Downloaded::" + FileName);
		if (LatestFileName.contains(FileName.substring(0, FileName.indexOf(".")))) {
			logMessage("File Download has been Started::" + FileName);
		} else {
			System.out.println("INCORRECT FILE NAME IS DISPLAYED::" + FileName);
		}
	}

	public void VerifyDownloadIsStartedFromAdvanceSearch(String FileName) {
		wait.hardWait(5); // wait for instance of the File to be created at Directory
		String DownloadPath = System.getProperty("user.dir") + "\\ScoresImportExport";
		File getLatestFile = getLatestFilefromDir(DownloadPath);
		String LatestFileName = getLatestFile.getName();
		logMessage("Latest File Downloaded::" + LatestFileName);
		logMessage("File Downloaded::" + FileName);
		if (LatestFileName.contains(FileName.substring(0, FileName.indexOf(".")))) {
			logMessage("File Download has been Started::" + FileName);
		} else {
			System.out.println("INCORRECT FILE NAME IS DISPLAYED::" + FileName);
		}
	}

	public void VerifyItemsNotGettingUncheckedByCheckingOneItem() {
		waitForPageToLoadCompletely(getPageTitle());
		VerifyContentsAreSelected();
		wait.waitForPageToLoadCompletely();
		List<WebElement> content = elements("ContentInputTag");
		int size = content.size();
		int UncheckContent = size - 2;
		scrollToBottom();
		wait.hardWait(1);
		content.get(UncheckContent).click();
		logMessage("Unchecking Content Number::" + UncheckContent);
		VerifyContentAreSelectedExcept(UncheckContent);
	}

	public void VerifyContentAreSelectedExcept(int ContentNumber) {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("ContentInputTag");
		List<WebElement> content = elements("ContentInputTag");
		for (int i = 0; i < content.size(); i++) {
			if (ContentNumber == i) {
				if (content.get(i).isSelected()) {
					Assert.assertTrue(false, "Content Number " + ContentNumber + " is Selected...");
				} else {
					logMessage("Content Number " + ContentNumber + " is UnSelected..");
				}
			} else if (content.get(i).isSelected()) {
				logMessage("Content Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content Is Not Selected...");
			}
		}

	}

	public void VerifyItemsNotGettingUncheckedByCheckingMultipleItem() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		VerifyContentsAreSelected();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("ContentInputTag");
		List<WebElement> content = elements("ContentInputTag");
		int size = content.size();
		int UncheckContent1 = size - 2; // Unchecking Content From Last
		int UncheckContent2 = size - 3; // Unchecking Content From Last
		scrollToBottom();
		wait.hardWait(1);
		content.get(UncheckContent1).click();
		logMessage("Unchecking Content Number::" + UncheckContent1);

		wait.hardWait(1);
		content.get(UncheckContent2).click();
		logMessage("Unchecking Content Number::" + UncheckContent2);
		VerifyContentAreSelectedExcept(UncheckContent1, UncheckContent2);

	}

	public void VerifyContentAreSelectedExcept(int ContentNumber1, int ContentNumber2) {
		wait.hardWait(2);
		areElementsDisplayed("ContentInputTag");
		List<WebElement> content = elements("ContentInputTag");
		for (int i = 0; i < content.size(); i++) {
			wait.hardWait(1);
			// String Attri=content.get(i).getAttribute("checked");
			if (ContentNumber1 == i || ContentNumber2 == i) {
				if (content.get(i).isSelected()) {
					Assert.assertTrue(false, "Content Number " + i + " is Selected...");
				} else {
					logMessage("Content Number " + i + " is UnSelected..");
				}
			} else if (content.get(i).isSelected()) {
				logMessage("Content Is Selected...");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]::Content Is Not Selected...");
			}
		}

	}

	public void SelectNumberFromResultDropDown(String count) {
		isElementDisplayed("resultNo");
		selectTextFromDropDown("resultNo", count);
		logMessage(count + " Selected in ResultDropDown");
		waitForLoaderToDisappear();

	}

	public void VerifySubtypeIsDisplayedInAdvanceSearch() {
		areElementsDisplayed("CheckContentType");
		List<WebElement> contents = elements("CheckContentType");
		areElementsDisplayed("CheckContentType");
		for (int i = 0; i < contents.size(); i++) {
			String Text = contents.get(i).getAttribute("innerText");
			logMessage("Content displayed::" + Text);
			if (Text.startsWith("Enhanced") || Text.startsWith("Supplementary") || Text.startsWith("Flat")) {
				if (contents.get(i).getAttribute("innerText").contains(">")
						&& !(Text.substring(Text.indexOf('>'), Text.length() - 1)).trim().equals(null)) {
					logMessage("[Assertion Passed]:: Subtype for content is displayed...");
				} else {
					Assert.assertTrue(false, "[Assertion failed]:: Subtype for content is not displayed...");
				}
			}
		}
	}

	public void VerifyContentType(String ContentType) {
		areElementsDisplayed("CheckContentType");
		List<WebElement> contents = elements("CheckContentType");
		for (int i = 0; i < contents.size(); i++) {
			String Text = contents.get(i).getAttribute("innerText").trim();
			logMessage("Content displayed::" + Text);
			if (Text.equals(ContentType)) {
				logMessage("Content Type '" + Text + "' is Displayed..");
				Assert.assertTrue(true);
				return;
			}
		}
		Assert.assertTrue(false, "[Assertion Falied]::Content Type '" + ContentType + "' is  Not Displayed..");

	}

	public void VerifyCountofSelectedAssetOnAdvanceSearch(int count) {
		wait.hardWait(1);
		isElementDisplayed("SelectedAssetCount");
		String text = element("SelectedAssetCount").getAttribute("innerText").trim();
		int countDisplay = Integer.parseInt(text.substring(0, text.indexOf(' ')).trim());
		logMessage("Expected Count::" + count);
		logMessage("Count Displayed::" + countDisplay);
		if (count == countDisplay) {
			logMessage("Corrent Count Displayed::" + count);
		} else {
			Assert.assertTrue(false, "Incorrent Count Displayed::" + countDisplay);
		}
	}

	public void VerifyAllDisplayedInAssertCount(String count) {
		wait.hardWait(1);
		isElementDisplayed("SelectedAssetCount");
		String text = element("SelectedAssetCount").getAttribute("innerText").trim();
		logMessage("Text Displayed::" + text);
		Assert.assertTrue(text.contains(count), "Incorrent Count Displayed::" + text);
	}

	public void OpenAnContentOnSearchPage() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("OpenAnAsset");
		wait.waitForElementToBeClickable(element("OpenAnAsset"));
		hover(element("OpenAnAsset"));
		wait.hardWait(1);
		clickUsingJS(element("OpenAnAsset"));
		logMessage("Content clicked on Advance Search Result Page..");
		waitForLoaderToDisappear();
	}

	public void OpenAnAssetOnSearchPage(String Name) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ClickOpenAsset", Name);
		wait.waitForElementToBeClickable(element("ClickOpenAsset", Name));
		hover(element("ClickOpenAsset", Name));
		wait.hardWait(1);
		clickUsingJS(element("ClickOpenAsset", Name));
		logMessage(Name + " Asset clicked on Advance Search Result Page..");
		waitForLoaderToDisappear();
	}

	public void OpenProjectOnAdvanceSearch(String ISBN) {
		waitForLoaderToDisappear();
		isElementDisplayed("OpenProject", ISBN);
		hover(element("OpenProject", ISBN));
		wait.waitForPageToLoadCompletely();
		click(element("OpenProject", ISBN));
		waitForLoaderToDisappear();
	}

	public void verifyHandIconNotDisplayedOnGrayedOutLink() {

		isElementDisplayed("ModifyOptions2", "Organized Download");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Organized Download").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions2", "Organized Download").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Organized Download");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Organized Download").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions3", "Organized Download").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Organized Download");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Organized Download").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions4", "Organized Download").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions2", "Download Content");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Download Content").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions2", "Download Content").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Download Content");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Download Content").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions3", "Download Content").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Download Content");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Download Content").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions4", "Download Content").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions2", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Add to Project").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions2", "Add to Project").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Add to Project").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions3", "Add to Project").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Add to Project").getCssValue("cursor"));
		Assert.assertTrue(
				element("ModifyOptions4", "Add to Project").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions2", "Delete");
		logMessage("Cursor Property::" + element("ModifyOptions2", "Delete").getCssValue("cursor"));
		Assert.assertTrue(element("ModifyOptions2", "Delete").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions3", "Delete");
		logMessage("Cursor Property::" + element("ModifyOptions3", "Delete").getCssValue("cursor"));
		Assert.assertTrue(element("ModifyOptions3", "Delete").getCssValue("cursor").trim().equals("not-allowed"));

		isElementDisplayed("ModifyOptions4", "Add to Project");
		logMessage("Cursor Property::" + element("ModifyOptions4", "Delete").getCssValue("cursor"));
		Assert.assertTrue(element("ModifyOptions4", "Delete").getCssValue("cursor").trim().equals("not-allowed"));

	}
	
	
	
	
	// ############## Facet Functionality ##############
	
	
	public void VerifyFacetTitle(String FacetTitle) {
		isElementDisplayed("FacetTitle", FacetTitle);
		logMessage("Facet Title Displayed::" + FacetTitle);
	}
	
	public void clickOnFacetLinks(String facetType, String facetLink) {
		isElementDisplayed("OpenFacetLink", facetType, facetLink);
		hoverOverElement(element("OpenFacetLink", facetType, facetLink));
		click(element("OpenFacetLink", facetType, facetLink));
		waitForLoaderToDisappear();
	}
	
	public void verifyFacetLinkIsDisplayed(String facetType, String facetLink) {
		isElementDisplayed("OpenFacetLink", facetType, facetLink);
	}
	
	public void verifyFacetLinkNotDisplayed(String facetType, String facetLink) {
		Assert.assertTrue(verifyElementNotDisplayed("OpenFacetLink", facetType, facetLink),
				"[Assertion Failed]:: '" + facetLink + "' is Displayed..");
	}
	
	public void verifyOnSeeMorePopup(String facetType) {
		isElementDisplayed("VerifySeeMorePopup");
		logMessage("See more Popup displayed for::" + element("VerifySeeMorePopup").getText().trim());
		logMessage("See more Popup Expected for::" + facetType);
		Assert.assertEquals(facetType, element("VerifySeeMorePopup").getText().trim(),
				"[Assertion Failed]:: Incorrect Asset Facet Popup Displayeds");

	}
	
	public void verifyCorrectCountOfAssetFromSeeMoreLink(String FacetLink) {
		isElementDisplayed("ClickListItemOnSeeMore", FacetLink);
		String Link = element("ClickListItemOnSeeMore", FacetLink).getText().trim();
		String CountDisplayedNextToLink = Link.substring(Link.indexOf('(') + 1, Link.indexOf(')')); // getting the count
																									// of Asset from
																									// Right of Facet
																									// Link
		logMessage("Expected Count::"+CountDisplayedNextToLink);
		click(element("ClickListItemOnSeeMore", FacetLink));
		waitForLoaderToDisappear();
		isElementDisplayed("VerifyCountOnSearchPage",CountDisplayedNextToLink);
	}
	
	public void VerifyFavoriteProjectCountIsNotZero() {
		isElementDisplayed("FavProjectCount");
		String text=element("FavProjectCount").getText();
		int CountDisplayed=Integer.parseInt(text.substring(text.indexOf('(')+1,text.lastIndexOf(')')));
		logMessage("Project Count Displayed::"+CountDisplayed);
		if(CountDisplayed<=0) {
			Assert.assertTrue(false,"[Assertion Failed]::Project count are Reset to Zero");
		}
	}
	
	public void verifyFacetLinkArrangedInDescendingOrder(String facetType) {
		areElementsDisplayed("FacetLinkOrder", facetType);
		List<WebElement> links = elements("FacetLinkOrder", facetType);
		int previousSize = 0;
		for (int link = 0; link < links.size() - 1/* (To remove +See more Link) */; link++) {
			String LinkText = links.get(link).getText();
			if (link == 0) {
				previousSize = Integer.parseInt(
						links.get(link).getText().substring(LinkText.indexOf('(') + 1, LinkText.lastIndexOf(')')));
			} else {
				int Currentsize = Integer.parseInt(
						links.get(link).getText().substring(LinkText.indexOf('(') + 1, LinkText.lastIndexOf(')')));
				/*
				 * logMessage("previous Size::"+previousSize);
				 * logMessage("Currrent Size::"+Currentsize);
				 */
				if (previousSize < Currentsize) {
					Assert.assertTrue(false, "[Assertion Failed]::Facet Links are not Arranged In Descending Order");
				}
				previousSize = Currentsize;
			}
		}
	}
	
	
	public void verifyOnlyOneFacetLinkDisplayed(String FacetTitle) {
		isElementDisplayed("FacetLinkOrder", FacetTitle);
		if (elements("FacetLinkOrder", FacetTitle).size() != 1) {
			Assert.assertTrue(false, "[Assertion Failed]::More Than one Facet Link Displayed..");
		}
	}
	
	public void verifyAllContentTypesAreDisplayedOnSeeMorePopup() {
		Map<String, Object> courses = YamlReader.getYamlValues("TypesOfContent");
		for(Map.Entry<String,Object> entry: courses.entrySet()){
			isElementDisplayed("ClickListItemOnSeeMore", entry.getValue().toString()+" (");
			logMessage(entry.getValue().toString()+" is Displayed on See more popup.");
		}
	}
	
	public void enterTextFilterSearchBar(String Text) {
		isElementDisplayed("FacetSearchBar");
		click(element("FacetSearchBar"));
		sendKeys(element("FacetSearchBar"), Keys.chord(Text));
		element("FacetSearchBar").sendKeys(Keys.BACK_SPACE);
		wait.waitForPageToLoadCompletely();
	}
	
	public void VerifyLinkDisplayedOnSeeMorePopup(String Link) {
		isElementDisplayed("ClickListItemOnSeeMore", Link);
	}
	
	public void VerifyLinkNotDisplayedOnSeeMorePopup(String Link) {
		Assert.assertTrue(verifyElementNotDisplayed("ClickListItemOnSeeMore", Link));
	}
	
	
}
