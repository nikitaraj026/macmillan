package com.qait.CMS.keywords;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;
import static com.qait.automation.utils.YamlReader.getData;
public class ProjectPageAction extends GetPage {

	public ProjectPageAction(WebDriver driver) {
		super(driver, "ProjectPage");
	}

	public void VerifyAllTheOptions() {
		isElementDisplayed("resultNo");
		logMessage("Result Number is Displayed");
		isElementDisplayed("SortBy");
		logMessage("SortBy is Displayed");
		isElementDisplayed("SortBy");
		logMessage("SortBy is Displayed");
		isElementDisplayed("GridView");
		logMessage("GridView is Displayed");
		isElementDisplayed("GridView");
		logMessage("GridView is Displayed");
		isElementDisplayed("ListView");
		logMessage("ListView is Displayed");

	}

	public void VerifyOnProjectPage() {
		waitForLoaderToDisappear();
		isElementDisplayed("ProjectLabel");
		isElementDisplayed("ProjectLabel");
		logMessage("On Project Page!!!!!!!");

	}

	public void verifyColumnsAreDisplayed() {
		isElementDisplayed("Coloum", "Author");
		logMessage("Author is Display");
		isElementDisplayed("Coloum", "Title");
		logMessage("Title is Displayed");
		isElementDisplayed("Coloum", "Short Title");
		logMessage("Short Title is Displayed");
		isElementDisplayed("Coloum", "ISBN");
		logMessage("ISBN is Displayed");
		isElementDisplayed("Coloum", "Publication Date");
		logMessage("Publication date is Displayed");
		isElementDisplayed("Coloum", "CMS Project Status");
		logMessage("CMS Project Status is Displayed");
		/*
		 * isElementDisplayed("Coloum", "View"); logMessage("View is Displayed");
		 */
		areElementsDisplayed("FolderIcons");
		logMessage("Folder Icon is Displayed..");
		areElementsDisplayed("AddMultiple");
		logMessage("'Star Icon is Displayed..'");

	}
	
	public void VerifyViewColoumNotDisplayedOnProjectTabTable() {
		Assert.assertTrue(verifyElementNotDisplayed("Coloum", "View"), "[Assertion Failed]:: 'View' Coloum is Displayed..");
		logMessage("[Assertion Passed]:: 'View' Coloum is Not Displayed..");
	}
	
	public void verifyEyeIconNotDisplayedOnProjectTabTable() {
		Assert.assertTrue(verifyElementNotDisplayed("ViewEyeIcon"),
				"[Assertion Failed]:: Eye Icon is not Displayed on Favorite Table");
	}

	public void verifyColumnsAreDisplayedAfterSearch() {
		isElementDisplayed("Coloum", "Author");
		logMessage("Author is Display");
		isElementDisplayed("Coloum", "Title");
		logMessage("Title is Displayed");
		isElementDisplayed("Coloum", "Short Title");
		logMessage("Short Title is Displayed");
		isElementDisplayed("Coloum", "ISBN");
		logMessage("ISBN is Displayed");
		isElementDisplayed("Coloum", "Content Type");
		logMessage("Content Type is Displayed");
		isElementDisplayed("Coloum", "Repository");
		logMessage("Repository is Displayed");
		isElementDisplayed("Coloum", "Last Modified Date ");
		logMessage("Last Modified Date is Displayed");
		areElementsDisplayed("FolderIcons");
		logMessage("Folder Icon is Displayed..");

	}
	
	public void openAnProjectOnProjectTab() {
		areElementsDisplayed("TableRow");
		hoverOverElement(elements("TableRow").get(1));
		wait.waitForPageToLoadCompletely();
		click(elements("TableRow").get(1));
		logMessage("Table Row Clicked..");
		waitForLoaderToDisappear();
	}

	public void clickListView() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ListView");
		isElementDisplayed("ListView");
		hover(element("ListView"));
		click(element("ListView"));
		logMessage("List View Clicked..");

	}

	public void verifyUserIsOnProjectView() {
		isElementDisplayed("ProjectTitle");
		String view = element("ProjectTitle").getAttribute("innerText");
		Assert.assertTrue(view.contains("Project View"), "[Assertion FAILED]:User cannot navigate to Project view");
		logMessage("[Assertion Passed]:User Can navigate to Project view..");
	}

	public void VerifyProjectsOnGridView() {
		areElementsDisplayed("VerifyGridView");
		logMessage("Projects on Grid View");
	}

	public void VerifyProjectOnListView() {
		Assert.assertTrue(verifyElementNotDisplayed("VerifyGridView"),
				"[Assertion Failed]:: Projects are not in List View.");
	}

	public void VerifyGridViewButtonToolTip() {
		isElementDisplayed("GridView");
		hover(element("GridView"));
		isElementDisplayed("ViewToolTip", "Grid View");

	}

	public void VerifyListViewButtonToolTip() {
		isElementDisplayed("ListView");
		hover(element("ListView"));
		isElementDisplayed("ViewToolTip", "List View");

	}

	public void clickGridView() {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("GridView");
		isElementDisplayed("GridView");
		hover(element("GridView"));
		clickUsingJavaScript("GridView");
		logMessage("GridView Clicked..");
		waitForLoaderToDisappear();
	}

	public void VerifyThumbnailViewIsWorking() {
		List<WebElement> ProjectLink = elements("ThumbnailView");
		waitForElementToBeClickable(ProjectLink.get(0));
		clickUsingJS(ProjectLink.get(0));
		isElementDisplayed("ProjectTitle");
		String view = element("ProjectTitle").getAttribute("innerText");
		Assert.assertTrue(view.equals("Project View"), "[Assertion FAILED]:User cannot navigate to Project view");
	}

	public void VerifyPaginationBarIsVisible() {
		isElementDisplayed("PaginationBar");
		isElementDisplayed("PaginationBar");
		logMessage("PaginationBar is Visible");
	}

	public void VerifyBackAndForthNavigationpaginationBar() {
		scrollToBottom();
		isElementDisplayed("navigate", "2");
		clickUsingJS(element("navigate", "2"));
		waitForLoaderToDisappear();
		logMessage("page number 2 clicked... Able To move Forword from pagination Bar");

		isElementDisplayed("navigate", "1");
		clickUsingJS(element("navigate", "1"));
		waitForLoaderToDisappear();
		logMessage("page number 1 clicked... Able To move Backword from pagination Bar");

	}

	public void NavigateToPage(String Number) {
		wait.hardWait(1);
		scrollToBottom();
		isElementDisplayed("navigate", Number);
		click(element("navigate", Number));
		logMessage("page number " + Number + " clicked... Able To move from pagination Bar");
	}

	public void VerifyCheckBoxAreNotSelected() {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		List<WebElement> checkBoxLink = elements("ProjectSelectCheckBox");
		// logMessage(checkBoxLink.get(0).toString());
		checkBoxLink.get(0).click();
		if (checkBoxLink.get(0).isSelected()) {
			logMessage("[Assertion FAILED]: user is able to select check box");
			Assert.assertFalse(true);

		} else {
			logMessage("user is unable to select check box");
		}

		checkBoxLink.get(1).click();
		if (checkBoxLink.get(1).isSelected()) {
			logMessage("[Assertion FAILED]: user is able to select check box");
			Assert.assertFalse(true);
		}

		else {
			logMessage("User is unable to select check box");
		}
		wait.waitForPageToLoadCompletely();
		click(element("SelectAllProjectCheckBox"));
		verifyCheckBoxUnselected("SelectAllProjectCheckBox");
		logMessage("User is unable to select 'Select All Project Checkbox'");
	}
	
	public void ClickCheckBoxOnProjectTab() {
		areElementsDisplayed("CheckBox");
		hoverOverElement(elements("CheckBox").get(1));
		click(elements("CheckBox").get(1));
		logMessage("Check Box Clicked..");
		waitForLoaderToDisappear();
	}

	public void SearchAndOpenProjectOfISBN(String ISBN) {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SearchTypeButton");
		clickUsingJS(element("SearchTypeButton"));
		logMessage("All Types Button Clicked");
		isElementDisplayed("SearchType", "project");
		clickUsingJS(element("SearchType", "project"));
		logMessage("'project' Selected In Type Of Search");

		isElementDisplayed("SearchBar");
		click(element("SearchBar"));
		element("SearchBar").clear();
		wait.hardWait(1);
		String Isbnc = Keys.chord(ISBN);
		element("SearchBar").sendKeys(Isbnc);
		logMessage("ISBN::" + ISBN + " entered into Search Box...");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SearchButton");
		scroll(element("SearchButton"));
		click(element("SearchButton"));
		logMessage("Search button clicked");
		waitForLoaderToDisappear();

		SelectNumberFromResultDropDown("100");
		waitForLoaderToDisappear();

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectProject", ISBN);
		wait.waitForPageToLoadCompletely();
		click(element("SelectProject", ISBN));
		logMessage("Project With ISBN:: " + ISBN + " Is Opened...");
		waitForLoaderToDisappear();
	}

	public void clickhomeLink() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("HomeLink");
		clickUsingJS(element("HomeLink"));
		logMessage("Home Link Clicked!!!!!!");
	}

	public void SelectNumberFromResultDropDown(String count) {
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("resultNo"));
		isElementDisplayed("resultNo");
		selectTextFromDropDown("resultNo", count);
		logMessage(count + " Selected in ResultDropDown");
	}

	public void VerifyCorrectNumberOfContentAreDisPlayed(String Count) {
		wait.waitForPageToLoadCompletely();
		List<WebElement> AssertName = elements("verifyAssert");
		logMessage("Total Assert = " + AssertName.size());
		Assert.assertTrue(AssertName.size() == Integer.parseInt(Count),
				"[Assertion Failed]:: Content Are not According To the Value Selected In Result DropDown");
		logMessage("[Assertion Passed]:: Number of Content are According To the Value Selected In Result DropDown");
	}

	public void verifyAlltheOptionsInSortBy() {
		isElementDisplayed("SortBy");
		clickUsingJS(element("SortBy"));
		logMessage("SortBy Clciked");
		selectTextFromDropDown("SortBy", "Author");
		logMessage("'Author' is Displyed");
		wait.waitForPageToLoadCompletely();

		selectTextFromDropDown("SortBy", "Title");
		logMessage("'Title' is Displyed");
		wait.waitForPageToLoadCompletely();

		selectTextFromDropDown("SortBy", "ISBN");
		logMessage("'ISBN' is Displyed");
		wait.waitForPageToLoadCompletely();

		selectTextFromDropDown("SortBy", "Modified");
		logMessage("'Modified' is Displyed");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyPreviewOfProject() {
		areElementsDisplayed("AssetPreview");
		List<WebElement> PreviewLinks = elements("AssetPreview");
		for (int i = 0; i > PreviewLinks.size(); i++) {
			Assert.assertTrue(PreviewLinks.get(i).getAttribute("src").contains("data:image/jpeg"),
					"[Assertion Failed]:: Previews are not available");
		}
		logMessage("[Assertion Passed]:: Previews of Project are displayed");
	}

	public void SearchForProject(String ISBN) {
		wait.hardWait(1);
		isElementDisplayed("SearchTypeButton");
		clickUsingJS(element("SearchTypeButton"));
		logMessage("All Types Button Clicked");
		wait.hardWait(1);
		isElementDisplayed("SearchType", "project");
		clickUsingJS(element("SearchType", "project"));
		logMessage("'project' Selected In Type Of Search");

		isElementDisplayed("SearchBar");
		scrollToTop();
		clickUsingJS(element("SearchBar"));
		String Isbnc = Keys.chord(ISBN);
		fillText("SearchBar", Isbnc);
		wait.waitForPageToLoadCompletely();
		logMessage(ISBN + " Enterted into Search Box...");
		waitForLoaderToDisappear();
		isElementDisplayed("SearchButton");
		click(element("SearchButton"));
		logMessage("Search button clicked");
		waitForLoaderToDisappear();
	}

	public void RemoveProjectFromFavorite(String ISBN) {
		waitForLoaderToDisappear();
		isElementDisplayed("FavoriteStatusList", ISBN);
		isElementDisplayed("FavoriteStatusList", ISBN);
		String FavStatus = element("FavoriteStatusList", ISBN).getAttribute("class");
		logMessage(FavStatus);
		if (FavStatus.contains("glyphicon-star-empty")) {
			logMessage("Project Is Already Removed From Favorite");
		} else {
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("AddToFavorite", ISBN);
			isElementDisplayed("AddToFavorite", ISBN);
			click(element("AddToFavorite", ISBN));
			logMessage("Project With ISBN::" + ISBN + " Is Added To Favorite");
		}
	}

	public void AddProjectToFavoriteFromProjectTabListView(String ISBN) {
		waitForLoaderToDisappear();
		isElementDisplayed("FavoriteStatusList", ISBN);
		isElementDisplayed("FavoriteStatusList", ISBN);
		String FavStatus = element("FavoriteStatusList", ISBN).getAttribute("class");
		logMessage(FavStatus);
		if (FavStatus.contains("glyphicon-star-empty")) {
			isElementDisplayed("AddToFavorite", ISBN);
			hoverOverElement(element("AddToFavorite", ISBN));
			wait.waitForPageToLoadCompletely();
			click(element("AddToFavorite", ISBN));
			logMessage("Project With ISBN::" + ISBN + " Is Added To Favorite");
		} else {
			logMessage("Project Is Already Add as Favorite");
		}
	}

	public void VerifyProjectIsMarkedUnfavorite(String ISBN) {
		waitForLoaderToDisappear();
		isElementDisplayed("FavoriteStatusList", ISBN);
		isElementDisplayed("FavoriteStatusList", ISBN);
		String FavStatus = element("FavoriteStatusList", ISBN).getAttribute("class");
		logMessage(FavStatus);
		if (FavStatus.contains("glyphicon-star-empty")) {
			logMessage("Project With ISBN::" + ISBN + " Is Marked Unfavorite and Outlined Star icon is Displayed.. ");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Project is marked As Favorite...");
		}
	}

	public void VerifyFavoriteProjectCountIsNotZero() {
		isElementDisplayed("FavProjectCount");
		String text = element("FavProjectCount").getText();
		int CountDisplayed = Integer.parseInt(text.substring(text.indexOf('(') + 1, text.lastIndexOf(')')));
		logMessage("Project Count Displayed::" + CountDisplayed);
		if (CountDisplayed <= 0) {
			Assert.assertTrue(false, "[Assertion Failed]::Project count are Reset to Zero");
		}
	}

	public void AddProjectsToFavorite(String count) {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("AddMultiple");
		List<WebElement> project = elements("AddMultiple");
		for (int i = 0; i < Integer.parseInt(count); i++) {
			wait.hardWait(1);
			wait.waitForElementToBeClickable(project.get(i));
			click(project.get(i));
			verifyMessageDisplayedOnFavoriteAdded();
			logMessage((i + 1) + " Project Added To Favorite");
		}
	}
	
	public void verifyMessageDisplayedOnFavoriteAdded() {
		isElementDisplayed("FavMarkUnMarkMsg",getData("FavoritesMarkedMsg"));
		logMessage("Message Displayed::"+getData("FavoritesMarkedMsg"));
	}
	
	public void VerifyFavoriteMessageColor() {
		String ColourDisplayed=element("FavMsgColour").getCssValue("color").trim();
		logMessage("Colour Displayed::"+ColourDisplayed);
		Assert.assertTrue(ColourDisplayed.equals("rgba(60, 118, 61, 1)"));
	}
	
	public void verifyFavoriteToasterMessageAppears_For_5_Seconds() {
		isElementDisplayed("FavMsgColour");
		wait.hardWait(5);
		Assert.assertTrue(verifyElementNotDisplayed("FavMsgColour"));
	}
	
	public void RemoveProjectFromFavorite() {
		areElementsDisplayed("RemoveMultiple");
		List<WebElement> project = elements("RemoveMultiple");
		for (int i = 0; i < project.size(); i++) {
			wait.hardWait(1);
			wait.waitForElementToBeClickable(project.get(i));
			click(project.get(i));
			verifyMessageDisplayedOnFavoriteRemoved();
			logMessage((i + 1) + " Project Added To Favorite");
		}
	}
	
	public void verifyTableRowGetsHighlightedOnHover() {
		areElementsDisplayed("TableRow");
		hoverOverElement(elements("TableRow").get(0));
		String backgroundStatus=elements("TableRow").get(0).getCssValue("background-color").trim();
		logMessage("Background Colour Displayed::"+backgroundStatus);
		Assert.assertTrue(backgroundStatus.equals("rgba(173, 216, 230, 1)"), "[Assertion Failed]::Background Colour Expected:rgba(173, 216, 230, 1)");
		
	}
	
	public void verifyMessageDisplayedOnFavoriteRemoved() {
		isElementDisplayed("FavMarkUnMarkMsg",getData("FavoritesRemovedMsg"));
		logMessage("Message Displayed::"+getData("FavoritesRemovedMsg"));
	}

	public void AddProjectToFavoriteFromProjectTabGridView(String ProjectTitle) {
		isElementDisplayed("FavoriteStatusGrid", ProjectTitle);
		String FavStatus = element("FavoriteStatusGrid", ProjectTitle).getAttribute("class");
		if (FavStatus.contains("glyphicon-star-empty")) {
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("AddToFavGrid", ProjectTitle);
			clickUsingJS(element("AddToFavGrid", ProjectTitle));
			logMessage("Project With ISBN::" + ProjectTitle + " Is Added To Favorite");
		} else {
			logMessage("Project Is Already Add as Favorite");
		}
	}

	public void VerifyCheckBoxAreApperingAndDisabledForProject() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("CheckBox");
		logMessage("CheckBox are Displayed for the Project.");
		List<WebElement> ProjectCheckBox = elements("CheckBox");
		for (int CheckBoxs = 0; CheckBoxs < ProjectCheckBox.size(); CheckBoxs++) {
			hoverOverElement(elements("CheckBox").get(CheckBoxs));
			isAttribtuePresent(elements("CheckBox").get(CheckBoxs), "disabled");
			String CursorStatus=elements("CheckBox").get(CheckBoxs).getCssValue("cursor");
			logMessage("Cursor Property::"+CursorStatus);
			Assert.assertTrue(CursorStatus.trim().equals("not-allowed"),
					"[Assertion Failed]::Hand Icon Not Displayed..");
			
		}
	}
	

	public void VerifyCorrentInformationOfProjectIsDisplayed(String ISBN) {
		isElementDisplayed("PAuthor", ISBN);
		String Author = element("PAuthor", ISBN).getAttribute("innerText").trim();
		logMessage("Author::" + Author);

		isElementDisplayed("PTitle", ISBN);
		String Title = element("PTitle", ISBN).getAttribute("innerText").trim();
		logMessage("Title::" + Title);

		isElementDisplayed("PShortTitle", ISBN);
		String ShortTitle = element("PShortTitle", ISBN).getAttribute("innerText").trim();
		logMessage("ShortTitle::" + ShortTitle);

		isElementDisplayed("PISBN", ISBN);
		String PISBN = element("PISBN", ISBN).getAttribute("innerText").trim();
		logMessage("ISBN::" + ISBN);

		HomePageAction homepage = new HomePageAction(driver);
		homepage.ClickDashBord();
		homepage.DashBordIsDisplayed();
		logMessage("Home Page Author::" + element("PAuthor", ISBN).getAttribute("innerText").trim());
		logMessage("Home Page Title::" + element("PTitle", ISBN).getAttribute("innerText").trim());
		logMessage("Home Page ShortTitle::" + element("PShortTitle", ISBN).getAttribute("innerText").trim());
		logMessage("Home Page ISBN::" + element("PISBN", ISBN).getAttribute("innerText").trim());

		if (Author.equalsIgnoreCase(element("PAuthor", ISBN).getAttribute("innerText").trim())) {
			logMessage("Author Name Is Correct");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]::Author Name Is Incorrect ");

		}

		if (Title.equalsIgnoreCase(element("PTitle", ISBN).getAttribute("innerText").trim())) {
			logMessage("Title  Is Correct");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]::Title Is Incorrect ");

		}

		if (element("PShortTitle", ISBN).getAttribute("innerText").trim().contains(ShortTitle.substring(0, 8))) {
			logMessage("ShortTitle  Is Correct");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]::ShortTitle Is Incorrect ");
		}

		if (PISBN.equalsIgnoreCase(element("PISBN", ISBN).getAttribute("innerText").trim())) {
			logMessage("ISBN  Is Correct");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]::ISBN Is Incorrect ");
		}
	}

	public void VerifyprojectNotDisplayed(String ISBN) {

		Assert.assertTrue(verifyElementNotDisplayed("SelectProject", ISBN),
				"[Assertion Failed]::Project of ISBN::" + ISBN + "Displayed.");
	}

	public void VerifyProjectInfoIsDisplayedOnGridView() {
		areElementsDisplayed("AddMultiple");
		areElementsDisplayed("checkBoxDisable");
		areElementsDisplayed("ProjectDetails", "Author");
		areElementsDisplayed("ProjectDetails", "Title");
		areElementsDisplayed("ProjectDetails", "Edition");
		areElementsDisplayed("ProjectDetails", "ISBN");
	}

	// ############## Facet Functionality ##############

	public void clickOnFacetLinks(String facetType, String facetLink) {
		isElementDisplayed("OpenFacetLink", facetType, facetLink);
		hoverOverElement(element("OpenFacetLink", facetType, facetLink));
		click(element("OpenFacetLink", facetType, facetLink));
		waitForLoaderToDisappear();

	}
	
	public void verifyOnSeeMorePopup(String facetType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("VerifySeeMorePopup");
		logMessage("See more Popup displayed for::" + element("VerifySeeMorePopup").getText().trim());
		logMessage("See more Popup Expected for::" + facetType);
		Assert.assertEquals(facetType, element("VerifySeeMorePopup").getText().trim(),
				"[Assertion Failed]:: Incorrect Asset Facet Popup Displayeds");

	}
	
	public void VerifyLinkNotDisplayedOnSeeMorePopup(String Link) {
		Assert.assertTrue(verifyElementNotDisplayed("ClickListItemOnSeeMore", Link));
	}

}
