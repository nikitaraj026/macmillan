package com.qait.CMS.keywords;

import static com.qait.automation.utils.YamlReader.getData;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Key;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.PropFileHandler;

public class ProjectViewAction extends GetPage {
	public ProjectViewAction(WebDriver driver) {
		super(driver, "ProjectView");
	}

	public void ClickAddRemoveProject() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AddRemoveProject");
		scrollToBottom();
		click(element("AddRemoveProject"));
		logMessage("Add Remove button clicked");

	}

	public void Verify_System_Metadata() {
		isElementDisplayed("SystemMetaData", "System ID:");
		logMessage("System ID::" + element("SystemMetaData", "System ID:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Project URI:");
		logMessage("Project URI::" + element("SystemMetaData", "Project URI:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Date Created:");
		logMessage("Date Created::" + element("SystemMetaData", "Date Created:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Created By:");
		logMessage("Created By::" + element("SystemMetaData", "Created By:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Date Modified:");
		logMessage("Date Modified::" + element("SystemMetaData", "Date Modified:").getAttribute("innerText"));

		isElementDisplayed("SystemMetaData", "Modified By:");
		logMessage("Modified By::" + element("SystemMetaData", "Modified By:"));

	}

	public String GetProjectModifiedDate() {
		isElementDisplayed("SystemMetaData", "Date Modified:");
		return element("SystemMetaData", "Date Modified:").getText().trim();
	}

	public void VerifyProjectDateModified(String Date) {
		isElementDisplayed("SystemMetaData", "Date Modified:");
		String DateDisplayed = element("SystemMetaData", "Date Modified:").getText().trim();
		logMessage(" Expected Date::" + Date);
		logMessage("Displayed Date::" + DateDisplayed);
		Assert.assertTrue(DateDisplayed.contains(Date),
				"[Assertio Failed]::Incorrect Modified Date Displayed::" + DateDisplayed);
	}

	public void VerifyUserEmailModifiedBy(String Email) {
		isElementDisplayed("SystemMetaData", "Modified By:");
		String EmailDisplayed = element("SystemMetaData", "Modified By:").getText().trim();
		logMessage(" Expected Email::" + Email);
		logMessage("Displayed Email::" + EmailDisplayed);
		Assert.assertEquals(Email, EmailDisplayed,
				"[Assertio Failed]::Incorrect User Name Dislpayed::" + EmailDisplayed);
	}

	public void VerifyUserEmailCreatedBy(String Email) {
		isElementDisplayed("SystemMetaData", "Created By:");
		String EmailDisplayed = element("SystemMetaData", "Created By:").getText().trim();
		logMessage(" Expected Email::" + Email);
		logMessage("Displayed Email::" + EmailDisplayed);
		Assert.assertEquals(Email, EmailDisplayed,
				"[Assertio Failed]::Incorrect User Name Dislpayed::" + EmailDisplayed);
	}

	public void VerifySubTabAreDispalyed() {

		isElementDisplayed("SubTab", "ISBN Details");
		isElementDisplayed("SubTab", "ISBN Details");
		logMessage("ISBN Details Is displayed");
		click(element("SubTab", "ISBN Details"));

		isElementDisplayed("SubTab", "Project Details");
		logMessage("Project Details Is displayed");
		click(element("SubTab", "Project Details"));

		isElementDisplayed("SubTab", "Publish Details");
		logMessage("Publish Details Is displayed");
		click(element("SubTab", "Publish Details"));
	}

	public void ClickPublishDetail() {
		scrollToTop();
		isElementDisplayed("SubTab", "Publish Details");
		hover(element("SubTab", "Publish Details"));
		wait.waitForPageToLoadCompletely();
		click(element("SubTab", "Publish Details"));
		logMessage("Publish Details clicked");
		waitForLoaderToDisappear();
	}

	public void ClickISBnDetail() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SubTab", "ISBN Details");
		click(element("SubTab", "ISBN Details"));
		logMessage("ISBN Details clicked");
		waitForLoaderToDisappear();
	}

	public void clickProjectDetails() {
		isElementDisplayed("SubTab", "Project Details");
		logMessage("Project Details Is displayed");
		clickUsingJS(element("SubTab", "Project Details"));
		logMessage("Project Details is clicked..");
	}

	public void ClickDelete() {
		isElementDisplayed("toplinks", "Delete");
		hoverOverElement(element("toplinks", "Delete"));
		click(element("toplinks", "Delete"));
		logMessage("Delete Link Clicked..");
	}

	public void VerifyDeletePopupDisplayed() {
		isElementDisplayed("DeleteContentPopUp");
		logMessage("[Assertion Passed]:: Delete PopUp is Displayed...");
	}

	public void EnterDeleteToDeleteContent() {
		wait.hardWait(2);
		areElementsDisplayed("DeleteInput");
		fillText("DeleteInput", "Delete");
		wait.waitForPageToLoadCompletely();
	}

	public void ClickConformDelete() {
		isElementDisplayed("confirmDelete");
		clickUsingJS(element("confirmDelete"));
		logMessage("Confirm Delete Clciked");
		logMessage("[Assertion passed]::Content Deleted!!!!!!");

	}

	public void VerifyProjectDeletedMessageIsDisplayed() {
		isElementDisplayed("ContentAddedMsg");
		String MessageDisplayed = element("ContentAddedMsg").getText().trim();
		logMessage("Message Displayed::" + MessageDisplayed);
		logMessage("Message Expected ::Project successfully deleted.");
		Assert.assertTrue(MessageDisplayed.equals("Project successfully deleted."));
		waitForLoaderToDisappear();
	}

	public void VerifyPublishDetailsAreDisplayed() {
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("publishDetail");
		List<WebElement> publishHistory = elements("publishDetail");
		for (WebElement dates : publishHistory) {
			wait.hardWait(1);
			System.out.println("Project Publish on::" + dates.getAttribute("innerText"));
		}

	}

	public void clickTopLinkMore() {
		scrollToTop();
		wait.hardWait(1);
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinkMore");
		isElementDisplayed("toplinkMore");
		clickUsingJS(element("toplinkMore"));
		logMessage("'More Link' is Clicked");
		wait.hardWait(1);
	}

	public void ClickWorkFlowStatus() {
		wait.hardWait(2);
		isElementDisplayed("WorkFlowStatusButton");
		click(element("WorkFlowStatusButton"));
		logMessage("WorkFlow Satus clicked");
	}

	public void GetAllWorkFlowStatus() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("TypesOfWorkFlow");
		List<WebElement> status = elements("TypesOfWorkFlow");
		for (int statusindex = 0; statusindex < status.size(); statusindex++) {
			logMessage(status.get(statusindex).getAttribute("innerText") + " Is Displayed...");
		}
		if (status.size() != 4) {
			Assert.assertTrue(false, "[Assertion Failed]:: Number of WorkFolw Status Displayed are not 4");
		}
	}

	public void VerifyContentMetadataOnPushToAuthoringTool() {
		isElementDisplayed("ContentMetadata", "Title:");
		logMessage("Title:" + element("ContentMetadata", "Title:").getText());

		isElementDisplayed("ContentMetadata", "File Name:");
		logMessage("File Name:" + element("ContentMetadata", "File Name:").getText());

		isElementDisplayed("ContentMetadata", "Content Type:");
		logMessage("Content Type:" + element("ContentMetadata", "Content Type:").getText());

		isElementDisplayed("ContentMetadata", "Last Updated:");
		logMessage("Last Updated:" + element("ContentMetadata", "Last Updated:").getText());
	}

	public void SelectPushPlatformOnAuthoringTool(String Platform) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectPlatform");
		selectTextFromDropDown("SelectPlatform", Platform);
		logMessage("'" + Platform + "' Selected As Push Platform");
	}

	public void Click_Ready_For_Enhancements() {
		wait.waitForPageToLoadCompletely();
		scrollToTop();
		waitForLoaderToDisappear();
		isElementDisplayed("GetWorkFlowStatus");
		clickUsingJS(element("GetWorkFlowStatus"));
		logMessage("WorkFlow Satus clicked");
		isElementDisplayed("ReadyForEnhancements");
		clickUsingJS(element("ReadyForEnhancements"));
		isElementDisplayed("ContentAddedMsg");
		logMessage("message displayed " + element("ContentAddedMsg").getAttribute("innerText"));
		logMessage("Project State change to 'Ready For Enhancements' clicked");
		waitForLoaderToDisappear();
	}

	public void SelectWorkFlowStatus(String WorkFlowStatus) {
		isElementDisplayed("SelectWorkFlowStatus", WorkFlowStatus);
		clickUsingJS(element("SelectWorkFlowStatus", WorkFlowStatus));
		logMessage("'" + WorkFlowStatus + "' is selected..");
	}

	public void click_Enhanced_ePub_in_QA() {
		wait.hardWait(1);
		isElementDisplayed("GetWorkFlowStatus");
		scrollToTop();
		click(element("GetWorkFlowStatus"));
		logMessage("WorkFlow Satus clicked");
		wait.hardWait(1);
		isElementDisplayed("EnhancedEPubInQA");
		clickUsingJS(element("EnhancedEPubInQA"));
		logMessage("Project State change to 'Enhanced EPub In QA' clicked");
		waitForLoaderToDisappear();
	}

	public void click_CourseBuilding() {
		wait.hardWait(2);
		isElementDisplayed("GetWorkFlowStatus");
		click(element("GetWorkFlowStatus"));
		logMessage("WorkFlow Satus clicked");
		click(element("CourseBuilding"));// to complete
		logMessage("Project State change to 'Course Building' clicked");
	}

	public void VerifyTopLinks() {
		String WorkFlowStatus;
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("GetWorkFlowStatus");
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		logMessage(WorkFlowStatus);

		click_Enhanced_ePub_in_QA();

		if (WorkFlowStatus.trim().compareTo("Enhanced ePub in QA") == 0
				|| WorkFlowStatus.trim().compareTo("Enhanced ePub for Course Building") == 0) {
			isElementDisplayed("toplinkForPublish");

			logMessage("Publish Is displayed");
		} else {
			if (isElementNotDisplayed("toplinkForPublish")) {
				logMessage(WorkFlowStatus + "is not displayed so Publish link will not be displayed ");

			} else {
				logMessage(WorkFlowStatus + " is not displayed But Publish link is displayed ");
				Assert.assertFalse(true);
			}
		}

		isElementDisplayed("toplinks", "Go to Frost");
		logMessage("'Go to Frost' Is displayed");
		isElementDisplayed("uploadContent");
		logMessage("'Upload Content' Is displayed");
		isElementDisplayed("toplinks", "Delete");
		logMessage("'Delete' Is displayed");
		isElementDisplayed("toplinkMore");
		logMessage("'More' Is displayed");
		isElementDisplayed("FavoriteStatus");
		logMessage("'Star Icon' is Displayed..");

		clickTopLinkMore();

		isElementDisplayed("FunctionsMore", "View Usage Details");
		logMessage("'View Usage Details' Is displayed");

		isElementDisplayed("FunctionsMore", "Organized Download");
		logMessage("'Organized Download' Is displayed");
		refreshPage();
		if (WorkFlowStatus.trim().compareTo("Ready For Enhancements") != 0) {
			Click_Ready_For_Enhancements();
			isElementDisplayed("GetWorkFlowStatus");
			WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		}
		clickTopLinkMore();

		if ((WorkFlowStatus.trim().compareTo("Ready For Enhancements") == 0)) {
			isElementDisplayed("FunctionsMore", "Push to Authoring Tool");
			logMessage("Push to Authoring tool  Is displayed");
		} else {
			try {
				isElementDisplayed("FunctionsMore", "Push to Authoring Tool");
				logMessage(WorkFlowStatus + " is not displayed but 'Push to Authoring tool'  link is displayed ");
				Assert.assertFalse(true);
			} catch (Exception e) {
				logMessage(
						WorkFlowStatus + " is not displayed so 'Push to Authoring tool'  link will not be displayed ");
			}
		}
	}

	public void ClickGoToFrost() {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinks", "Go to Frost");
		clickUsingJS(element("toplinks", "Go to Frost"));
		logMessage("'Go to Frost' clicked");
	}

	public void ClickFrostHomeLink() {
		isElementDisplayed("FrostHome");
		wait.waitForPageToLoadCompletely();
		hover(element("FrostHome"));
		click(element("FrostHome"));
		logMessage("Frost Home Button Clicked..");
	}

	public void VerifyUserIsOnFrostApplication() {
		wait.hardWait(1);
		changeWindow(1);
		isElementDisplayed("Frostlogo");
		logMessage("Frost Logo Displayed");
	}

	public void clickUsageDetails() {
		wait.waitForPageToLoadCompletely();
		waitAndClick("FunctionsMore", "View Usage Details");
		logMessage("'View Usage Details' is Clicked");

	}

	public void VerifyUsageDetailsAreShown() {
		areElementsDisplayed("UsageDetailTable");
		List<WebElement> UsageHistory = elements("UsageDetailTable");
		for (WebElement dates : UsageHistory) {
			wait.hardWait(1);
			System.out.println("Project Usage History dates::" + dates.getAttribute("innerText"));
		}

	}

	public void VerifyPushToAuthoringToolIsEnabledOnlyForReadyForEnhancements() {
		String WorkFlowStatus;
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		logMessage(WorkFlowStatus);
		clickTopLinkMore();
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		if ((WorkFlowStatus.trim().compareTo("Ready For Enhancements") == 0)) {
			/*
			 * try { isElementDisplayed("AuthoringToolEnabledLink");
			 * logMessage("[Assertion Passed]:Push to Authoring tool  Is displayed"); }
			 * catch (java.lang.AssertionError exc) { logMessage(
			 * "[Assertion Failed]: Ready For Enhancements is displayed but 'Push to Authoring tool'  link is Not displayed "
			 * ); Assert.assertTrue(false); }
			 */
			isElementDisplayed("AuthoringToolEnabledLink");
			logMessage("Push to Authoring Tool is Enabled..");
		} else {
			Assert.assertTrue(verifyElementNotDisplayed("AuthoringToolEnabledLink"),
					"[Assertion Failed]:: Push to Authoring Tool is Enabled but Workflow status displayed is::"
							+ WorkFlowStatus);
			Click_Ready_For_Enhancements();
			clickTopLinkMore();
		}

	}

	public void VerifyLablesAreDisplayed() {
		FilterContent(getData("TypesOfContent.Enhanced ePub > Full Package"));
		wait.waitForPageToLoadCompletely();

		scroll(element("EnhancedEpub"));
		isElementDisplayed("EnhancedEpub");
		if (element("EnhancedEpub").getAttribute("innerText").equals("ENHANCED")) {
			logMessage("[Assertion Passed]: 'ENHANCED' is Displayed on ENHANCED EPUB Asset");
		} else {
			logMessage("[Assertion Failed]: 'ENHANCED' is  NOT Displayed on ENHANCED EPUB Asset");
			Assert.assertTrue(false);
		}

		refreshPage();
		waitForLoaderToDisappear();
		FilterContent(getData("TypesOfContent.Flat ePub > Full Package"));
		wait.waitForPageToLoadCompletely();

		if (element("FlatEpub").getAttribute("innerText").equals("FLAT")) {
			logMessage("[Assertion Passed]: 'FLAT' is Displayed on FLAT EPUB");
		} else {
			logMessage("[Assertion Failed]: 'FLAT' is  NOT Displayed on FLAT EPUB");
			Assert.assertTrue(false);
		}
	}

	public void clickOrganisedDownload() {
		wait.waitForPageToLoadCompletely();
		click(element("FunctionsMore", "Organized Download"));
		logMessage("'Organized Download' is Clicked");
		waitForLoaderToDisappear();
	}

	public void OrganizedTheDownload(String option1, String option2, String option3) {
		wait.waitForPageToLoadCompletely();
		selectTextFromDropDown("OrganisedDownloadDropDown", "selectedContent", option1);
		logMessage(option1 + " Selected as Top level folder");

		wait.hardWait(1);
		selectTextFromDropDown("OrganisedDownloadDropDown", "selectedContent1", option2);
		logMessage(option2 + " Selected as 1st subfolder");

		wait.hardWait(1);
		selectTextFromDropDown("OrganisedDownloadDropDown", "selectedContent2", option3);
		logMessage(option3 + " Selected as 2nd sub-folder");

		isElementDisplayed("selectAllCheckBox");
		hover(element("selectAllCheckBox"));
		wait.waitForPageToLoadCompletely();
		click(element("selectAllCheckBox"));

		isElementDisplayed("FinishButton");
		hover(element("selectAllCheckBox"));
		wait.waitForPageToLoadCompletely();
		click(element("FinishButton"));
		logMessage("'Finish Button clicked..'");
	}

	public void OrganisedDownloadInThreeLevelStructure(String option1, String option2, String option3) {
		wait.hardWait(2);
		isElementDisplayed("OrganisedDownloadDropDown", "selectedContent");
		selectTextFromDropDown("OrganisedDownloadDropDown", "selectedContent", option1);
		logMessage(option1 + " Selected as Top level folder");

		wait.hardWait(2);
		isElementDisplayed("OrganisedDownloadDropDown", "selectedContent1");
		selectTextFromDropDown("OrganisedDownloadDropDown", "selectedContent1", option2);
		logMessage(option2 + " Selected as 1st subfolder");

		wait.hardWait(2);
		isElementDisplayed("OrganisedDownloadDropDown", "selectedContent2");
		selectTextFromDropDown("OrganisedDownloadDropDown", "selectedContent2", option3);
		logMessage(option3 + " Selected as 2nd sub-folder");
	}

	public int GetCountOfNumberOfAssetAssociatedToProject() {
		isElementDisplayed("AssociatedLabel");
		scroll(element("AssociatedLabel"));
		int NumberOfPages = GetNumberOfPagesInAssociatedContent();
		if (NumberOfPages < 0) {
			NumberOfPages *= -1;
		}
		int count = 0;
		for (int i = 0; i < NumberOfPages - 1; i++) {
			clickNextOnAssociatedContent();
		}
		areElementsDisplayed("OpenFilterContent");
		count = elements("OpenFilterContent").size();
		return (NumberOfPages - 1) * 6 + count; // 6 number of asset per pages.
	}

	public void VerifyCorrectMessageOnOrganisedDownload(String organisedDownloadMsg, int Count) {
		StringBuilder organisedDownloadMssage = new StringBuilder(organisedDownloadMsg);
		organisedDownloadMssage.replace(14, 16, Count + " ");
		logMessage("Expected Message::" + organisedDownloadMssage);
		organisedDownloadMsg = organisedDownloadMssage.toString();
		isElementDisplayed("DownloadStart");
		String Message = element("DownloadStart").getAttribute("innerText");
		logMessage("Message Displayed::" + Message);
		Assert.assertTrue(organisedDownloadMsg.equals(Message),
				"[Asserion Failed]:: Correct Message Not Displayed::" + Message);
		logMessage("[Asserion Passed]:: Correct Message Displayed::" + Message);
	}

	public void verifyFinishAndCancelButtonAreDisplayed() {

		isElementDisplayed("FinishButton");
		logMessage("Finish button Is Dispalyed..");
		isElementDisplayed("CloseButton");
		logMessage("Close Button Is Dispalyed..");
	}

	public void selectAllInOrganizedDownload() {
		wait.hardWait(2);
		isElementDisplayed("selectAllCheckBox");
		waitAndClick("selectAllCheckBox");
		waitAndClick("selectAllCheckBox");
		waitAndClick("selectAllCheckBox");
	}

	public void clickFinishButtonOnOrganizedDownload() {
		wait.hardWait(2);
		isElementDisplayed("FinishButton");
		click(element("FinishButton"));
		logMessage("Finish button Clicked!!!!!");

	}

	public void verifyCorrectMessageIsDisplayedOnDownloadOfContent(String Expected) {
		isElementDisplayed("DownloadStart");
		String message = element("DownloadStart").getAttribute("innerText");
		logMessage("Message Displayed::" + element("DownloadStart").getAttribute("innerText"));
		Assert.assertTrue(message.equals(Expected), "[Assertion FAILED]:Message not displayed");
		logMessage("[Assertion PASSED]:Correct Message displayed");

	}

	public void clickCancelButtonOnOrganizedDownload() {
		isElementDisplayed("CloseButton");
		click(element("CloseButton"));
		logMessage("Close Button Clicked!!!!!");
	}

	public void VerifyOrganizedDownloadPopUpClosed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("FinishButton"),
				"[Assertion Failed]::Organised Download Pop Up Is Displayed..");
		logMessage("Organised Download Pop Up Is Closed...");
	}

	public void clickPushToAuthoringTool() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("FunctionsMore", "Push to Authoring Tool");
		wait.waitForPageToLoadCompletely();
		logMessage("Push to Authoring Tool Link Displayed...");
		click(element("FunctionsMore", "Push to Authoring Tool"));
		logMessage("'Push to Authoring Tool' Is Clicked");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyPushToAuthoringToolPopUp() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AuthoringToolPopUp");
		logMessage("Push To Authoring Tool PopUp Pop Up Displayed.....");

	}

	public void VerifySubCategoriesInPushToAuthoringTool() {

		isElementDisplayed("SubCategories", "Step 1");
		logMessage("Categories:: Step 1 Displayed.....");

		isElementDisplayed("SubCategories", "Step 2");
		logMessage("Categories:: Step 2 Displayed.....");

		isElementDisplayed("SubCategories", "Step 3");
		logMessage("Categories:: Step 3 Displayed.....");

	}

	public void SearchForAssetOnPushToAuthoringTool(String TypeOfAsset, String Name) { // AssetType:: 1)Epub 2)Other
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CssOption", "clearCss");
		click(element("CssOption", "clearCss"));
		logMessage("'Clear CSS and Javascript' Selected ");

		if (TypeOfAsset.equalsIgnoreCase("Epub")) {
			ClickEpubRadioOnPushToAuthoringTool();
		} else if (TypeOfAsset.equalsIgnoreCase("Other")) {
			ClickOtherOnPushToAuthoringTool();
		}
		String Fileinput = Keys.chord(Name);
		isElementDisplayed("Step2SearchBar");
		isElementDisplayed("Step2SearchBar");
		fillText("Step2SearchBar", Fileinput);
		isElementDisplayed("Ste2SearchButton");
		wait.hardWait(1);
		click(element("Ste2SearchButton"));
		waitForLoaderToDisappear();
	}
	
	public void ClearSearchResultOnPushToAutoringTool() {
		isElementDisplayed("ClearSearchResult");
		hoverOverElement(element("ClearSearchResult"));
		wait.waitForPageToLoadCompletely();
		click(element("ClearSearchResult"));
		logMessage("Clear Search Result Button 'x' Clicked..");
	}

	public void VerifyContentSubtypeInPushToAuthoringToolGridView(String ContentType) {
		if (ContentType.length() >= 20) {
			ContentType = ContentType.substring(0, 18);
		}
		isElementDisplayed("ContentTypeInAuthoringtool", ContentType);
		String ContentTypeDisplayed = element("ContentTypeInAuthoringtool", ContentType).getAttribute("innerText")
				.trim();
		logMessage("Expected::" + ContentType);
		logMessage("Displayed::" + element("ContentTypeInAuthoringtool", ContentType).getAttribute("innerText").trim());
		Assert.assertTrue(ContentTypeDisplayed.contains(ContentType),
				"[Assertion Failed]:: Incorrect Content Type Displayed:" + ContentTypeDisplayed);
		logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeDisplayed);

	}

	public void VerifyContentSubtypeInPushToAuthoringToolListView(String ContentType) {
		String ContentTypeDisplayed;
		isElementDisplayed("ContentTypeInAuthoringtoolListView");
		ContentTypeDisplayed = element("ContentTypeInAuthoringtoolListView").getAttribute("uib-tooltip");
		if (ContentTypeDisplayed == null) {
			ContentTypeDisplayed = element("ContentTypeInAuthoringtoolListView").getAttribute("innerText").trim();
		}

		logMessage("Expected::" + ContentType);
		logMessage("Displayed::" + ContentTypeDisplayed);
		Assert.assertTrue(ContentTypeDisplayed.contains(ContentType),
				"[Assertion Failed]:: Incorrect Content Type Displayed:" + ContentTypeDisplayed);
		logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeDisplayed);

	}

	public void SelectAssetDisplayedInPushToAuthoringTool(String FileName) {
		wait.hardWait(2);
		isElementDisplayed("selectEpubOnAuthorisingTool", FileName);
		scroll(element("selectEpubOnAuthorisingTool", FileName));
		click(element("selectEpubOnAuthorisingTool", FileName));
		logMessage(FileName + " is selected To Push");
	}
	
	public void verifyAssetNotDisplayedInPushToAuthoringTool(String FileName) {
		Assert.assertTrue(verifyElementNotDisplayed("selectEpubOnAuthorisingTool", FileName), "[Assertion Failed]:: "+FileName+" Displayed in Push To Authoring Tool");
		logMessage("[Assertion Passed]:: "+FileName+" Is not Displayed on Push To Authoring Tool");
	}

	public void EnterDemoISBNInPushToAuhoringTool(String DemoISBN) {
		isElementDisplayed("searchBar");
		scroll(element("searchBar"));
		click(element("searchBar"));
		String ISBNc = Keys.chord(DemoISBN);
		fillText("searchBar", ISBNc);
		element("searchBar").sendKeys(Key.BACKSPACE);
		fillText("searchBar", ISBNc);
		logMessage(DemoISBN + " Enterted into Search Box..");
		wait.hardWait(1);
		click(element("searchButton"));
		waitForLoaderToDisappear();
		logMessage("Search button clicked");
	}

	public void VerifyYesOrNoButtonForDemoISBN(String Option) { // Make sure First letter is CAPS
		isElementDisplayed("ClickYesNoDemoISBN", Option);
		logMessage(Option + " is Displayed...");
	}

	public void VerifyYesOrNoButtonSelected(String Option) {// Make sure First letter is CAPS
		if (element("ClickYesNoDemoISBN", Option).isSelected()) {
			Assert.assertTrue(true, Option + " Is Selected..");
		} else {
			Assert.assertTrue(false, Option + " Is not Selected..");
		}
	}

	public void ClickYESNoForDemoISBN(String Option) { // Make sure First letter is CAPS
		click(element("ClickYesNoDemoISBN", Option));
		logMessage(Option + " is Selected.");
	}

	public void SelectProjectDisplayedInStep3PushToAuthoringTool(String ISBNorName) {
		isElementDisplayed("SelectProject", ISBNorName);
		click(element("SelectProject", ISBNorName));
		logMessage("Project with " + ISBNorName + " Is Selected");
	}

	public void ClickPushOnPushToAuthoringTool() {
		isElementDisplayed("push");
		scroll(element("push"));
		hover(element("push"));
		wait.waitForPageToLoadCompletely();
		clickUsingJavaScript("push");
		logMessage("Push Clicked");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("push"), "[Assertion Failed]:: Push Button is Displayed..");
	}

	public void VerifyPushButtonDisabledAuthoringTool() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("push");
		String Attri = element("push").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Failed]:: Publish Button Is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]:: Publish Button Is Disabled...");
		}
	}

	public void VerifyPushButtonEnabledAuthoringTool() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("push");
		String Attri = element("push").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Push Button Is Enabled...");
		} else {
			logMessage("[Assertion Failed]:: Push Button Is Disabled...");
			Assert.assertTrue(false);
		}
	}

	public void SelectEnhancedEpubOnAuthoringToolAndPush(String ISBN, String AssociateISBN) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CssOption", "clearCss");
		click(element("CssOption", "clearCss"));
		logMessage("'Clear CSS and Javascript' Selected ");
		String Epub = ISBN + ".epub";

		String EpubFileinput = Keys.chord(Epub);
		isElementDisplayed("Step2SearchBar");
		isElementDisplayed("Step2SearchBar");
		fillText("Step2SearchBar", EpubFileinput);
		isElementDisplayed("Ste2SearchButton");
		wait.hardWait(2);
		click(element("Ste2SearchButton"));
		waitForLoaderToDisappear();

		wait.hardWait(1);
		isElementDisplayed("selectEpubOnAuthorisingTool", ISBN);
		click(element("selectEpubOnAuthorisingTool", ISBN));
		logMessage(Epub + " is selected To Push");

		isElementDisplayed("searchBar");
		scroll(element("searchBar"));
		click(element("searchBar"));
		String ISBNc = Keys.chord(AssociateISBN);
		element("searchBar").sendKeys(ISBNc);
		click(element("searchButton"));
		logMessage("Search button clicked");
		wait.hardWait(2);

		isElementDisplayed("SelectProject", AssociateISBN);
		wait.waitForPageToLoadCompletely();
		click(element("SelectProject", AssociateISBN));
		logMessage("Project with " + AssociateISBN + " Is Selected");
		wait.hardWait(2);

		// isElementDisplayed("push");
		isElementDisplayed("push");
		hover(element("push"));
		wait.waitForPageToLoadCompletely();
		click(element("push"));
		logMessage("Push Clicked");
		wait.hardWait(2);
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("push"), "[Assertion Failed]:: Push Button is Displayed..");
	}

	public void SelectFlatEpubOnAuthoringToolAndPush(String ISBN, String AssociateISBN) {
		isElementDisplayed("CssOption", "clearCss");
		click(element("CssOption", "clearCss"));
		logMessage("'Clear CSS and Javascript' Selected ");

		String Epub = ISBN + "_EPUB.epub";
		String EpubFile = Keys.chord(Epub);
		isElementDisplayed("Step2SearchBar");
		isElementDisplayed("Step2SearchBar");
		fillText("Step2SearchBar", EpubFile);
		isElementDisplayed("Ste2SearchButton");
		wait.waitForPageToLoadCompletely();
		click(element("Ste2SearchButton"));
		waitForLoaderToDisappear();

		isElementDisplayed("selectEpubOnAuthorisingTool", ISBN);
		click(element("selectEpubOnAuthorisingTool", ISBN));
		logMessage(Epub + " is selected To Push");

		isElementDisplayed("searchBar");
		scroll(element("searchBar"));
		click(element("searchBar"));
		String ISBNc = Keys.chord(AssociateISBN);
		element("searchBar").sendKeys(ISBNc);
		logMessage("ISBN ENTERED::" + AssociateISBN);
		click(element("searchButton"));
		logMessage("Search button clicked");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("SelectProject", AssociateISBN);
		click(element("SelectProject", AssociateISBN));
		logMessage("Project with " + AssociateISBN + " Is Selected");
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("push");
		isElementDisplayed("push");
		click(element("push"));
		logMessage("Push Clicked, project uploaded To frost");
		wait.hardWait(2);
		waitForLoaderToDisappear();
		Assert.assertTrue(verifyElementNotDisplayed("push"), "[Assertion Failed]:: push Button Displayed..");
	}

	public void ClickEpubRadioOnPushToAuthoringTool() {
		wait.hardWait(1);
		isElementDisplayed("EpubRadio");
		click(element("EpubRadio"));
		logMessage("Epub Radio Clicked...");
	}

	public void ClickOtherOnPushToAuthoringTool() {
		wait.hardWait(1);
		isElementDisplayed("selectOther");
		click(element("selectOther"));
		logMessage("Other Radio Clicked...");
		wait.waitForPageToLoadCompletely();
	}

	public void SelectFcOnAuthoringToolAndPush(String ISBN) {
		wait.hardWait(2);
		isElementDisplayed("selectOther");
		click(element("selectOther"));
		logMessage("Other Clicked...");

		String FCFile = ISBN + "_FC";
		String FCFileinput = Keys.chord(FCFile);
		isElementDisplayed("Step2SearchBar");
		isElementDisplayed("Step2SearchBar");
		fillText("Step2SearchBar", FCFileinput);
		isElementDisplayed("Ste2SearchButton");
		wait.hardWait(1);
		click(element("Ste2SearchButton"));
		waitForLoaderToDisappear();

		isElementDisplayed("selectEpubOnAuthorisingTool", ISBN);
		wait.hardWait(2);
		click(element("selectEpubOnAuthorisingTool", ISBN));
		logMessage(ISBN + " FC File is selected To Push");
		wait.hardWait(1);

		isElementDisplayed("push");
		scroll(element("push"));
		isElementDisplayed("push");
		hover(element("push"));
		click(element("push"));
		logMessage("Push Clicked");
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		Assert.assertTrue(verifyElementNotDisplayed("push"), "[Assertion Failed]:: Push Button is Displayed..");
	}

	public void VerifyContentsAreDisplayedInThumbnail() {
		wait.hardWait(3);
		areElementsDisplayed("thumbnail");
		List<WebElement> Contents = elements("thumbnail");
		for (WebElement content : Contents) {
			Assert.assertTrue(content.getAttribute("src").length() != 0,
					"[Assertion Failed]:Thumbnail image is not present");
		}
		logMessage("[Assertion Passed]: Thumbnail Images Are Present");

	}

	public void VerifyHistoryIsdisplayed() {
		wait.waitForLoaderToDisappear();
		areElementsDisplayed("WorkflowHistory");
		List<WebElement> UsageHistory = elements("WorkflowHistory");
		for (WebElement dates : UsageHistory) {
			wait.hardWait(1);
			System.out.println("Project workFlow History dates::" + dates.getAttribute("innerText"));
		}
	}

	public void VerifyUserNameWorkFlowHistory(String Text) {
		isElementDisplayed("VerifyInformation", Text);
		logMessage("User Name is Displayed::" + Text);
	}

	public void AddCommentAndVerifyIt() throws IOException {
		scrollToBottom();
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();
		Random r = new Random();
		String CommentNo = PropFileHandler.readPropertyFromDataFile("CommentNoforProject");
		String Comment = "TestCommentProject " + CommentNo + alphabet.charAt(r.nextInt(N));
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		element("CommentArea").sendKeys(Comment);
		isElementDisplayed("PostButton");
		click(element("PostButton"));
		wait.hardWait(4);
		CommentNo = Integer.toString(Integer.parseInt(CommentNo) + 1);
		PropFileHandler.writePropertyToDataFile("CommentNoforProject", CommentNo);
		refreshPage();
		isElementDisplayed("VerifyComment", Comment);
		scroll(element("VerifyComment", Comment));
		isElementDisplayed("VerifyComment", Comment);
		wait.hardWait(2);
		logMessage("Follwoing comment is displayed" + element("VerifyComment", Comment).getAttribute("innerText"));

	}

	public void TestPublicLink() {
		String WorkFlowStatus;
		wait.hardWait(5);
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		logMessage("Current WorkFlow Status::" + WorkFlowStatus);

		if (WorkFlowStatus.trim().compareTo("Enhanced ePub in QA") == 0
				|| WorkFlowStatus.trim().compareTo("Enhanced ePub for Course Building") == 0) {
			isElementDisplayed("toplinkForPublish");
			logMessage("Publish Is displayed");
		} else {

			if (verifyElementNotDisplayed("toplinkForPublish")) {
				logMessage(
						"Enhanced ePub for Course Building OR Enhanced ePub in QA is not displayed so Publish link will not be displayed ");

			} else {
				logMessage(
						"Enhanced ePub for Course Building OR Enhanced ePub in QA is not displayed But Publish link is displayed ");
				Assert.assertFalse(true);
			}
		}
	}

	public void VerifyPublishLinkOnlyDisplayforEnhancedEpubAndCourseBuilding() {
		click_Enhanced_ePub_in_QA();
		TestPublicLink();
		click_CourseBuilding();
		TestPublicLink();
		Click_Ready_For_Enhancements();
		TestPublicLink();
	}

	public void clickpublishLink() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("toplinkForPublish");
		wait.hardWait(2);
		clickUsingJS(element("toplinkForPublish"));
		waitForLoaderToDisappear();
		logMessage("Publish Link Clicked");

	}

	public void VerifyThreeOptionsDisplayedInPublish() {
		logMessage(
				"Verifying Publish content links and ePub,Publish content links only, Publish ePub only are displayed");

		isElementDisplayed("TypeOfcontentToPublish", "Publish content links and ePub");
		scroll(element("TypeOfcontentToPublish", "Publish content links and ePub"));
		click(element("TypeOfcontentToPublish", "Publish content links and ePub"));
		logMessage("'Publish content links and ePub' is Displayed");
		wait.hardWait(2);

		isElementDisplayed("TypeOfcontentToPublish", "Publish content links only");
		click(element("TypeOfcontentToPublish", "Publish content links only"));
		logMessage("'Publish content links only' is Displayed");
		wait.hardWait(2);

		isElementDisplayed("TypeOfcontentToPublish", "Publish ePub only");
		click(element("TypeOfcontentToPublish", "Publish ePub only"));
		logMessage("'Publish ePub only' is Displayed");
		wait.hardWait(2);
	}

	public void VerifyThreeOptionsNotDisplayedInPublish() {
		wait.hardWait(5);
		Assert.assertTrue(verifyElementNotDisplayed("TypeOfcontentToPublish", "Publish content links and ePub"),
				"[Asserion Failed]::Publish content links and ePub' is Displayed");
		logMessage("'Publish content links and ePub' is Not Displayed");
		wait.hardWait(1);

		Assert.assertTrue(verifyElementNotDisplayed("TypeOfcontentToPublish", "Publish content links only"),
				"[Assertion Failed]::Publish content links only' is Displayed");
		logMessage("'Publish content links only' is Not Displayed");
		wait.hardWait(1);

		Assert.assertTrue(verifyElementNotDisplayed("TypeOfcontentToPublish", "Publish ePub only are displayed"),
				"[Assertion Failed]::Publish ePub only are displayed' is Displayed");
		logMessage("'Publish ePub only are displayed' is Not Displayed'");
		wait.hardWait(1);
	}

	public void selectDestinationOfPublish(String publihDestination) {
		isElementDisplayed("destination");
		selectTextFromDropDown("destination", publihDestination);
		logMessage(publihDestination + " Selected As Destination");
		wait.waitForPageToLoadCompletely();
		wait.hardWait(1);

	}

	public void PublishTheEpub(String ISBN) {

		isElementDisplayed("manualPublish");
		click(element("manualPublish"));
		wait.hardWait(3);

		isElementDisplayed("step2repo");
		click(element("step2repo"));
		logMessage("Repository Clicked");
		wait.hardWait(3);

		int index = clickOnRepoOption("CMS");

		wait.hardWait(3);

		int indexOfEpub = GetIndexOfEpub(index);

		isElementDisplayed("checkEpub", String.valueOf(index), String.valueOf(indexOfEpub));
		click(element("checkEpub", String.valueOf(index), String.valueOf(indexOfEpub)));
		logMessage("Epub Checked");
		wait.hardWait(2);

		wait.hardWait(3);
		isElementDisplayed("selectEpubOnPublish", (ISBN + ".epub"));
		scroll(element("selectEpubOnPublish", (ISBN + ".epub")));
		click(element("selectEpubOnPublish", (ISBN + ".epub")));
		logMessage("Epub Selected");
		wait.hardWait(3);

		isElementDisplayed("ApproveButton");
		click(element("ApproveButton"));
		waitForLoaderToDisappear();
		logMessage("Approve Button Clicked");
		waitForLoaderToDisappear();

		wait.hardWait(3);
		isElementDisplayed("publish");
		scroll(element("publish"));
		click(element("publish"));
		logMessage("Publish Was clicked");

	}

	private int GetIndexOfEpub(int index) {

		for (int i = 1; i <= 15; i++) {
			String options = returnTextUsingJavaScript("SearchEpub", String.valueOf(index), "" + i).trim();
			logMessage("Options==" + (options.trim()));
			if (options.contains(getData("TypesOfContent.Enhanced ePub > Full Package"))) {
				wait.hardWait(2);
				logMessage("index of Enhanced Epub::" + i);
				return i;
			}
		}
		System.out.println("FAILED TO FIND EPUB");
		return 0;
	}

	public int clickOnRepoOption(String repoOptions) {
		for (int i = 1; i <= 3; i++) {
			String options = returnTextUsingJavaScript("SelectRepoText", "" + i).trim();
			if (options.contains(repoOptions)) {
				wait.hardWait(6);
				click(element("SelectRepo", String.valueOf(i)));
				return i;
			}
		}
		System.out.println("FAILED TO FIND REPO");
		return -1;
	}

	public int GetRepoNumber(String repoOptions) {
		for (int i = 1; i <= 3; i++) {
			String options = returnTextUsingJavaScript("SelectRepoText", "" + i).trim();
			if (options.contains(repoOptions)) {
				wait.hardWait(6);
				return i;
			}
		}
		System.out.println("FAILED TO FIND REPO");
		return -1;

	}

	public int GetRepoNunberOnCoursewareMetaData(String repoOptions) {
		for (int i = 1; i <= 3; i++) {
			String options = element("SelectRepoTextCWMetadata", "" + i).getAttribute("innerText");
			if (options.contains(repoOptions)) {
				wait.hardWait(6);
				return i;
			}
		}
		System.out.println("FAILED TO FIND REPO");
		return -1;

	}

	public int clickOnRepoOptionCW(String repoOptions) {
		for (int i = 1; i <= 3; i++) {
			String options = returnTextUsingJavaScript("SelectRepoTextCW", "" + i).trim();
			if (options.contains(repoOptions)) {
				wait.hardWait(2);
				click(element("SelectRepoCW", String.valueOf(i)));
				return i;
			}
		}
		System.out.println("FAILED TO FIND REPO");
		return 0;

	}

	public void VerifyPublishWasSuccessful() {
		isElementDisplayed("publishMessage");
		String Message = element("publishMessage").getAttribute("innerText");
		logMessage("Message Displayed::" + Message);
		String ExpectedMessage = getData("PublishProjectView");
		Assert.assertTrue(Message.equals(ExpectedMessage),
				"[Assertion Failed]:Correct Message Not Displayed for the Publish Detail, Message Displayed::"
						+ Message);
		logMessage("[Assertion Passed]:Correct Message Is Displayed for the Publish Detail, Message Displayed::"
				+ Message);
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyCountOfISBNsDisplayedOnPublishMessage(int ExpectedCount) {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("ISBNListOnPublishMessage");
		logMessage("ISBNs Displayed on Publish Message::" + elements("ISBNListOnPublishMessage").size());
		logMessage("ISBNs Expected on  Publish MEssage::" + ExpectedCount);
		Assert.assertTrue((elements("ISBNListOnPublishMessage").size() == ExpectedCount),
				"[Assertion Failed]:: Expected Number of ISBNs on Publish Message ::" + ExpectedCount);
		logMessage("[Assertion Passed]:: " + ExpectedCount + " ISBNs Displayed on the Publish Message.");
	}

	public void VerifyPublishedISBNOnPublishMessage(String... ISBNs) {
		for (String ISBN : ISBNs) {
			isElementDisplayed("ISBNOnPublishMessage", ISBN.trim());
			logMessage(ISBN + " Displayed on Publish Message");
		}
	}

	public void VerifyApprovedEpubCanBePublished(String ISBN) {
		isElementDisplayed("manualPublish");
		click(element("manualPublish"));
		wait.hardWait(5);

		isElementDisplayed("step2repo");
		click(element("step2repo"));
		logMessage("Repository Clicked");
		wait.hardWait(5);
		int index = clickOnRepoOption("CMS");
		wait.hardWait(3);
		int indexOfEpub = GetIndexOfEpub(index);
		isElementDisplayed("checkEpub", String.valueOf(index), String.valueOf(indexOfEpub));
		click(element("checkEpub", String.valueOf(index), String.valueOf(indexOfEpub)));
		logMessage("Epub Checked");
		wait.hardWait(5);

		isElementDisplayed("selectEpubOnPublish", (ISBN + ".epub"));
		scroll(element("selectEpubOnPublish", (ISBN + ".epub")));
		click(element("selectEpubOnPublish", (ISBN + ".epub")));
		logMessage("Epub Selected");
		wait.hardWait(3);

		isElementDisplayed("ApproveButton");
		// waitForElementToBeClickable(element("ApproveButton"));
		click(element("ApproveButton"));
		waitForLoaderToDisappear();
		logMessage("Approve Button Clicked");
		wait.hardWait(5);
		String status = element("ContentStatus", (ISBN + ".epub")).getAttribute("innerText");
		logMessage("Current Status Of Content" + status);

		if (status.trim().equals("Approved")) {
			wait.hardWait(3);
			// waitForElementToBeClickable(element("publish"));
			isElementDisplayed("publish");
			click(element("publish"));
			logMessage("Publish Was clicked");
		} else {
			Assert.assertFalse(true, "[Assertion Failed]: Content is not Approved");
		}

	}

	public void VerifyUnapprovedEpubCanNotBePublished(String ISBN) {
		wait.hardWait(4);
		isElementDisplayed("manualPublish");
		click(element("manualPublish"));
		wait.hardWait(5);

		isElementDisplayed("step2repo");
		click(element("step2repo"));
		logMessage("Repository Clicked");
		wait.hardWait(5);

		int index = clickOnRepoOption("CMS");

		wait.hardWait(5);

		int indexOfEpub = GetIndexOfEpub(index);
		isElementDisplayed("checkEpub", String.valueOf(index), String.valueOf(indexOfEpub));
		click(element("checkEpub", String.valueOf(index), String.valueOf(indexOfEpub)));
		logMessage("Epub Checked");
		wait.hardWait(5);

		isElementDisplayed("selectEpubOnPublish", (ISBN + ".epub"));
		scroll(element("selectEpubOnPublish", (ISBN + ".epub")));
		click(element("selectEpubOnPublish", (ISBN + ".epub")));
		logMessage("Epub Selected");
		wait.hardWait(5);

		// waitForElementToBeClickable(element("UnapproveButton"));
		isElementDisplayed("UnapproveButton");
		click(element("UnapproveButton"));
		waitForLoaderToDisappear();
		logMessage("Unapprove Button Clicked");
		wait.hardWait(5);
		String status = element("ContentStatus", (ISBN + ".epub")).getAttribute("innerText");
		logMessage("Current Status Of Content::" + status);

		wait.hardWait(5);
		// waitForElementToBeClickable(element("publish"));
		isElementDisplayed("publish");
		click(element("publish"));
		logMessage("Publish Was clicked");

	}

	public void VerifyPublishWasUnsuccessful(String iSBN) {
		isElementDisplayed("publishMessage");
		String Message = element("publishMessage").getAttribute("innerText");
		Assert.assertTrue(Message.equals("No assets to publish!"),
				"[Assertion Failed]:Correct Message Not Displayed for the Publish Detail::" + Message);
		logMessage("[Assertion Passed]:Correct Message is Displayed for the Publish Detail::" + Message);
		refreshPage();
		waitForLoaderToDisappear();

	}

	public void VerifyPublishWasUnsuccessful_DMS_User(String PublishMessage) {
		isElementDisplayed("DMSPublishError");
		String MessageDisplayed = element("DMSPublishError").getAttribute("innerText").trim();
		logMessage("Message Displayed::" + MessageDisplayed);
		logMessage("Message Expected::" + PublishMessage);
		Assert.assertTrue(MessageDisplayed.equals(PublishMessage),
				"[Assertion Failed]:: Incorrect Message Displayed :" + MessageDisplayed);
		logMessage("[Assertion Passed]:: Correct Message Displayed :" + MessageDisplayed);
	}

	public void PublishTheInstructorResourceOnCourseWare() {

		wait.hardWait(5);
		isElementDisplayed("step2repo");
		click(element("step2repo"));
		logMessage("Repository Clicked");
		wait.hardWait(5);

		int index = clickOnRepoOptionCW("DAM");

		wait.hardWait(3);

		isElementDisplayed("checkDamContent2", String.valueOf(index));
		click(element("checkDamContent2", String.valueOf(index)));
		logMessage("DAM CONTENT SELECTED Checked");

		isElementDisplayed("selectInstructorResource");
		scroll(element("selectInstructorResource"));
		click(element("selectInstructorResource"));
		logMessage("Instructor Resource Selected");
		wait.hardWait(2);

		// waitForElementToBeClickable(element("ApproveButton"));
		isElementDisplayed("ApproveButton");
		click(element("ApproveButton"));
		waitForLoaderToDisappear();
		logMessage("Approve Button Clicked");

		wait.hardWait(2);
		isElementDisplayed("publish");
		scroll(element("publish"));
		// waitForElementToBeClickable(element("publish"));
		click(element("publish"));
		logMessage("Publish Was clicked");

	}

	public void VerifyPublishWasOnCorrectDestination(String PublishDestination) {

		wait.waitForPageToLoadCompletely();
		ClickPublishDetail();
		isElementDisplayed("label");
		String platform = element("DestPublish").getAttribute("innerText");
		logMessage("Published Platfrom:" + platform);
		logMessage("Expected platform:" + PublishDestination);
		if (platform.trim().equalsIgnoreCase(PublishDestination)) {
			Assert.assertTrue(true);
			logMessage("[Assertion Passed]: Project Was Publish On Corrent Platform");
		}

		else {
			Assert.assertTrue(false, "[Assertion Failed]: Project Was not Publish On Corrent Platform");
		}

	}

	public void ClickOpenAssetOnProjectView(String AssetName, String ContentType) {
		FilterContent(ContentType);
		isElementDisplayed("OpenFCFileISBN", AssetName);
		hover(element("OpenFCFileISBN", AssetName));
		wait.hardWait(1);
		click(element("OpenFCFileISBN", AssetName));
		logMessage(AssetName + " Clicked");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}


	public void clickUploadContent() {
		scrollToTop();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UploadButton");
		click(element("UploadButton"));
		logMessage("UploadButton clicked");

	}

	public void VerifyUploadContentPopup() {
		wait.hardWait(3);
		isElementDisplayed("UploadContentLabel");
		isElementDisplayed("UploadContentLabel");
		logMessage("Upload Content Popup Displayed.");

	}

	public void VerifyContentTypeNotDisplayedInUploadContentPopUp(String ContentType) {
		Assert.assertTrue(verifyElementNotDisplayed("UploadContentType", ContentType),
				"[Assertion Failed]::" + ContentType + " is dispalyed..");
		logMessage(ContentType + " is not dispalyed..");

	}

	public void UploadContentAndAssociateFromProjectView(String FileISBN) {

		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN + ".epub";
		} else {
			filePath = "C:/cms Testdata/" + FileISBN + ".epub";
		}
		System.out.println(filePath);
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:Enhanced ePub > Full Package");
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + ".epub");
		logMessage(FileISBN + ".epub Title of the file");
		wait.hardWait(2);

		isElementDisplayed("Upload");
		click(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void ClickUploadOnUploadContentPopUpAndVerifyMsg() {
		wait.hardWait(1);
		isElementDisplayed("Upload");
		click(element("Upload"));
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");
	}

	public void VerifyMessageDisplayedOnuploadingContent() {
		isElementDisplayed("ContentAddedMsg");
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");
	}

	public void VerifyProjectIsCreatedAtFrost(String ISBN, String ProjectName) {
		logMessage("ISBN To Enter::" + ISBN);
		logMessage("Project Name::" + ProjectName);
		isElementDisplayed("FrostSearchBar");
		fillText("FrostSearchBar", ISBN);
		int flag = 0;
		int count = 0;
		while (count <= 41) {
			count++;
			waitAndClick("FrostSearchBar");
			element("FrostSearchBar").sendKeys(Keys.ENTER);
			logMessage("Search button clicked");
			wait.hardWait(6);
			if (!checkAvailabiltyOfprojectFiles(ProjectName) && flag == 0) {
				logMessage("Project Is not created");
				logMessage("waiting for project to be created.....");
				wait.hardWait(5);
			} else {
				flag = 1;
				wait.hardWait(3);
				isElementDisplayed("DisplayProject", ProjectName);
				String SRC = element("DisplayProject", ProjectName).getAttribute("src");
				logMessage("SRC===============" + SRC);
				flag = 1;
				if (!SRC.contains("img/blank.jpg")) {
					logMessage("Project Name::" + ProjectName + " Has Been Created");
					break;
				}
			}
		}
		wait.resetImplicitTimeout(wait.getTimeout());
		if (count >= 41) {
			Assert.assertTrue(false, "Project is not created At frost END..");
		}
	}

	public boolean checkAvailabiltyOfprojectFiles(String ProjectName) {
		boolean flag = false;
		wait.resetImplicitTimeout(2);
		try {
			wait.hardWait(2);
			return element("DisplayProject", ProjectName).isDisplayed();
		} catch (Exception exc) {
			return flag;
		}
	}

	public void LoginIntoFrost(String frostEmail, String frostPassword) {
		wait.waitForPageToLoadCompletely();
		wait.hardWait(10);
		String CurrentUrl = getCurrentURL().trim();
		logMessage("Current Url::" + CurrentUrl);
		logMessage("Frost Login Url::" + getData("Link.Frost").trim());
		if (CurrentUrl.equals(getData("Link.Frost").trim())) {

			isElementDisplayed("FrostName");
			fillText("FrostName", frostEmail);

			isElementDisplayed("FrostPassword");
			fillText("FrostPassword", frostPassword);

			isElementDisplayed("login");
			click(element("login"));
			logMessage("Login button clicked");
			waitForLoaderToDisappear();

		} else {
			logMessage("User is already logged in...");
			isElementDisplayed("FrostHome");
			waitForLoaderToDisappear();
		}
	}

	public void OpenProjectOnFrost(String frostCreatedProjectName) {

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("DisplayProject", frostCreatedProjectName);
		waitForLoaderToDisappear();
		click(element("DisplayProject", frostCreatedProjectName));
		logMessage("Project opened On frost");
		waitForLoaderToDisappear();
	}

	public void ExportFilesToCms(String ExportOption, String ExportType) {

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExportFiles");
		wait.waitForPageToLoadCompletely();
		// waitForElementToBeClickable(element("ExportFiles"));
		waitAndClick("ExportFiles");
		logMessage("Export Epub files clicked");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("FrsotExportOption");
		selectTextFromDropDown("FrsotExportOption", ExportOption);
		logMessage(ExportOption + " is Select as Export Option:");

		isElementDisplayed("FrostExportType", ExportType);
		hoverOverElement(element("FrostExportType", ExportType));
		wait.waitForPageToLoadCompletely();
		click(element("FrostExportType", ExportType));
		logMessage("'" + ExportType + "' Radio Button Clicked..");

		isElementDisplayed("CFIDomain");
		fillText("CFIDomain", "TEST");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("CFIDomain");
		fillText("CFIBookId", "TEST");

		isElementDisplayed("ExportItButton");
		clickUsingJS(element("ExportItButton"));
		logMessage("Export button clicked");
		wait.waitForPageToLoadCompletely();

		logMessage("Wating for success message to Display");
		isElementDisplayed("ExportSuccessMSG");
		logMessage("Success message Displayed");
		wait.waitForPageToLoadCompletely();

		logMessage("Export Complete File Exported To CMS");

		isElementDisplayed("Okbutton");
		click(element("Okbutton"));
		logMessage("ok button clicked");
		wait.waitForPageToLoadCompletely();

	}

	public void ExportFilesFromExportHistory() {
		int Counter=0;
		while (Counter<=100) {
			isElementDisplayed("ExportHistory");
			click(element("ExportHistory"));
			logMessage("Export History clicked");
			wait.hardWait(6);
			if (checkAvailabiltyOfPushToCMS()) {
				isElementDisplayed("pushToCmsButton");
				click(element("pushToCmsButton"));
				logMessage("Push To CMS clicked");
				wait.hardWait(1);

				isElementDisplayed("YesPushIt");
				waitAndClick("YesPushIt");
				logMessage("Yes Push It Clicked");
				wait.hardWait(1);

				isElementDisplayed("ExportSuccessMSG");
				logMessage("Push Action successfull");
				wait.hardWait(1);

				isElementDisplayed("Okbutton");
				waitAndClick("Okbutton");
				logMessage("ok button clicked");
				logMessage("Project Exported To CMS");
				logMessage("waiting For Files to pe Exported To CMS.............");
				wait.hardWait(200);
				Counter++;
				break;
			} else {
				wait.waitForPageToLoadCompletely();
				isElementDisplayed("Close");
				wait.waitForPageToLoadCompletely();
				click(element("Close"));
				wait.hardWait(8);
				Counter++;
			}
		}
	}

	public boolean checkAvailabiltyOfPushToCMS() {
		boolean flag = false;
		wait.waitForPageToLoadCompletely();
		wait.resetImplicitTimeout(8);
		try {
			wait.waitForPageToLoadCompletely();
			return element("pushToCmsButton").isDisplayed();
		} catch (Exception exc) {
			return flag;
		}
	}

	public void SwitchWindowToCMS() {
		wait.hardWait(8);
		String parentHandle = driver.getWindowHandle();
		System.out.println(parentHandle);
		driver.switchTo().window(parentHandle);
	}

	public void VerifyCFIAndEnhancedEpubArePushed(String ISBN) {
		FilterContent(getData("TypesOfContent.Enhanced ePub > Full Package"));
		wait.hardWait(2);
		String FileName = ISBN + ".epub";
		isElementDisplayed("OpenEnhancedEpubISBN", FileName);
		scroll(element("OpenEnhancedEpubISBN", FileName));
		logMessage("[Assertion Passed]:: " + FileName + " Enhanced Epub Is ADDED FROM FROST To Project" + ISBN);

		FilterContent(getData("TypesOfContent.Project Support Materials>CFI"));
		wait.hardWait(2);
		ISBN = ISBN + "_CFI.csv";
		isElementDisplayed("OpenCFIFIle", ISBN);
		scroll(element("OpenCFIFIle", ISBN));
		logMessage("[Assertion Passed]:: " + ISBN + " CFI File Is ADDED FROM FROST To Project" + ISBN);
	}

	public void VerifyWorkFlowStatus() {
		String WorkFlowStatus;
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("GetWorkFlowStatus");
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		if (WorkFlowStatus.equalsIgnoreCase("Structural Validation in Progress")
				|| WorkFlowStatus.equalsIgnoreCase("File Ingested")) {
			logMessage("[Assertion passsed]:: WorkFolw Status " + WorkFlowStatus + " Is Displayed");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: WorkFolw Status" + WorkFlowStatus + "Is Displayed");
		}
	}

	public void VerifyWorkFlowStatusIsEnhancedEPubIngested() {
		String WorkFlowStatus;
		wait.hardWait(5);
		isElementDisplayed("GetWorkFlowStatus");
		WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText");
		if (WorkFlowStatus.equalsIgnoreCase("Enhanced ePub Ingested")) {
			logMessage("[Assertion passsed]:: WorkFolw Status " + WorkFlowStatus + " Is Displayed");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: WorkFolw Status" + WorkFlowStatus + "Is Displayed");
		}
	}

	public void VerifyWorkFlowStatusIs(String WorkFlow) {
		String WorkFlowStatus;
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("GetWorkFlowStatus");
		WorkFlowStatus = element("GetWorkFlowStatus").getText().trim();
		logMessage("GetWorkFlow Status Displayed:" + WorkFlowStatus);
		logMessage("GetWorkFlow Status Expected:" + WorkFlow);
		if (WorkFlowStatus.equalsIgnoreCase(WorkFlow)) {
			logMessage("[Assertion passsed]:: WorkFolw Status " + WorkFlowStatus + " Is Displayed");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: WorkFolw Status " + WorkFlowStatus + "Is Displayed");
		}
	}

	public void DeleteProjectFromFrost(String ProjectName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("Options", ProjectName);
		wait.hardWait(1);
		click(element("Options", ProjectName));
		logMessage("Option clicked");
		wait.hardWait(1);

		isElementDisplayed("deleteProject", ProjectName);
		wait.hardWait(1);
		click(element("deleteProject", ProjectName));
		logMessage("delete Project clicked");

		isElementDisplayed("yesDeleteIt");
		wait.hardWait(1);
		click(element("yesDeleteIt"));
		logMessage("Yes delete it clicked");

		isElementDisplayed("deleteMsg");
		logMessage("Project Deleted");

		isElementDisplayed("Okbutton");
		wait.hardWait(1);
		click(element("Okbutton"));
		logMessage("OK Button clicked");
	}

	public void LogoutFromFrost() {
		refreshPage();
		wait.hardWait(4);
		isElementDisplayed("frostUserName");
		click(element("frostUserName"));
		logMessage("User name Cliked");

		isElementDisplayed("frostLogout");
		click(element("frostLogout"));
		logMessage("Log out Clicked Cliked");
		wait.hardWait(3);
	}

	public void VerifyAlltheOptionsOfPushToAuthoringTool(String ISBN) {

		wait.waitForPageToLoadCompletely();
		String Epub = ISBN + ".epub";

		isElementDisplayed("Step2SearchBar");
		fillText("Step2SearchBar", Keys.chord(Epub));
		isElementDisplayed("Ste2SearchButton");
		click(element("Ste2SearchButton"));
		waitForLoaderToDisappear();
		isElementDisplayed("selectEpubOnAuthorisingTool", ISBN);
		click(element("selectEpubOnAuthorisingTool", ISBN));
		logMessage(Epub + " is selected To Push");

		isElementDisplayed("pushPlatform");
		logMessage("Select platform to push Is available");

		isElementDisplayed("CssOption", "retainCss");
		click(element("CssOption", "retainCss"));
		logMessage("Retain CSS and Javascript Option Is Availabe");

		isElementDisplayed("CssOption", "clearCss");
		click(element("CssOption", "clearCss"));
		logMessage("Clear CSS and Javascript Option Is Availabe");

	}

	public void SelectClearCssOption() {
		isElementDisplayed("CssOption", "clearCss");
		click(element("CssOption", "clearCss"));
		logMessage("Clear CSS and Javascript Option Is Availabe");
	}

	public void SelectRetainCssOption() {
		isElementDisplayed("CssOption", "retainCss");
		click(element("CssOption", "retainCss"));
		logMessage("Retain CSS and Javascript Option Is Availabe");
	}

	public void VerifyFilterContentIsWorking() {

		FilterContent(getData("TypesOfContent.Enhanced ePub > Full Package"));

		FilterContent(getData("TypesOfContent.Project Support Materials>CFI"));

		FilterContent(getData("TypesOfContent.Covers>Cover Design"));

		FilterContent(getData("TypesOfContent.Flat ePub > Full Package"));
	}

	public void VerifySelectedContentOnRight() {
		FilterContent(getData("TypesOfContent.Enhanced ePub > Full Package"));

		wait.hardWait(2);
		scroll(element("SelectedContent"));
		isElementDisplayed("SelectedContent");
		logMessage("content Seclected::" + element("SelectedContent").getAttribute("innerText"));
		if (element("SelectedContent").getAttribute("innerText").trim()
				.equalsIgnoreCase(getData("TypesOfContent.Enhanced ePub > Full Package"))) {
			logMessage("[ASSERTION PASSED]:: Selected Content is displayed on Right");
			assertTrue(true);
		} else {
			logMessage("[ASSERTION FAILED]:: Selected Content is Not displayed on Right");
			assertTrue(false);
		}
	}

	public void VerifyUserIsnotAbleToEditMsg(String EMAIL) {

		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		try {
			Assert.assertTrue(verifyElementNotDisplayed("NonEditComment", EMAIL));
			logMessage("[Assertion Passed]:: Other User not able to edit comment ");
			Assert.assertTrue(true);
		} catch (java.lang.AssertionError e) {
			logMessage("[Assertion Failed]:: Other User is able to edit comment");
			Assert.assertTrue(false);
		}

	}

	public void VerifyUserIsNotAbleToDeleteMsg(String Email) {
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();

		try {
			Assert.assertTrue(verifyElementNotDisplayed("nondeleteComment", Email));
			logMessage("[Assertion Passed]:: Other User not able to delete comment ");
			Assert.assertTrue(true);
		} catch (java.lang.AssertionError e) {
			logMessage("[Assertion Failed]:: Other User is able to delete comment");
			Assert.assertTrue(false);
		}

	}

	public void clickhomeLink() {
		wait.hardWait(2);
		isElementDisplayed("HomeLink");
		click(element("HomeLink"));
		logMessage("Home Link Clicked!!!!!!");
	}

	public void verifyOnProjectView() {
		waitForLoaderToDisappear();
		scrollToTop();
		isElementDisplayed("ProjectTitle");
		logMessage("User is on Project View....");

	}

	public void clickProjectLink() {
		wait.hardWait(2);
		isElementDisplayed("ProjectLink");
		click(element("ProjectLink"));
		logMessage("Project Link Clicked!!!!!!");

	}

	public void VerifyBrowseButton() {
		isElementDisplayed("BrowseFile");
		isElementDisplayed("BrowseFile");
		logMessage("Browse File Button Is dispaled");

	}

	public void SelectFileUsingBrowseButton(String FileISBN) {
		String filePath;
		String selServer = System.getProperty("seleniumServer");
		if (selServer == null)
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN;
		else {
			filePath = "C:/cms Testdata/" + FileISBN;
		}
		System.out.println(filePath);
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + " selected");
		wait.waitForPageToLoadCompletely();
	}

	public void SelectImageFileUsingBrowseButton(String FileISBN) {
		String filePath;
		String selServer = System.getProperty("seleniumServer");
		if (selServer == null)
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN
					+ "_FC.jpg";
		else {
			filePath = "C:/cms Testdata/" + FileISBN + "_FC.jpg";
		}
		System.out.println(filePath);
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.hardWait(2);
	}

	public void EnterTextIntoTitleField(String Text) {
		isElementDisplayed("Title");
		fillText("Title", Text);
	}

	public void SelectContentTypeInUploadContentPopup(String ContentType) {
		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", ContentType);
		logMessage("Content Type::" + ContentType);
	}

	public void EnterTextInAuthorField(String Text) {
		isElementDisplayed("UploadFields", "Author Name");
		element("UploadFields", "Author Name").click();
		fillText(element("UploadFields", "Author Name"), Keys.chord(Text));
		element("UploadFields", "Author Name").sendKeys(Keys.BACK_SPACE);
		wait.waitForPageToLoadCompletely();
		element("UploadFields", "Author Name").sendKeys(Keys.BACK_SPACE);

	}

	/// To verify the Vertical Scroll Bar on an Upload content Field
	public void VerifyScrollBarOnUploadContentField(String Field) {
		isElementDisplayed("ScrollBarOnField", Field);
		String AttriId = element("ScrollBarOnField", Field).getAttribute("id");
		if (AttriId.isEmpty()) {
			Assert.assertTrue(false, "[Asseetion Failed]:: Vertical Scroll Bar not Displayed on " + Field + " Filed.");
		} else if (AttriId.contains("scrollable-dropdown-menu")) {
			Assert.assertTrue(true, "[Asseetion Passed]:: Vertical Scroll Bar is Displayed on " + Field + " Filed.");
		} else {
			Assert.assertTrue(false, "[Asseetion Failed]:: Vertical Scroll Bar not Displayed on " + Field + " Filed.");
		}
	}

	public void VerifyScrollBarIsWorkingOnUploadContent() {
		isElementDisplayed("Scrolltarget", "15");
		scroll(element("Scrolltarget", "15"));
		logMessage("Scroll To item 15");
		isElementDisplayed("Scrolltarget", "1");
		scroll(element("Scrolltarget", "1"));
		logMessage("Scroll To item 1");
	}

	public void SelectAuthorName(String AuthorName) {
		isElementDisplayed("SelectAuthor", AuthorName);
		hover(element("SelectAuthor", AuthorName));
		wait.waitForPageToLoadCompletely();
		click(element("SelectAuthor", AuthorName));
		logMessage("Author Name And id '" + AuthorName + "' is selected...");
	}

	public void clickXButtonUploadContent() {

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("Xbutton");
		wait.waitForElementToBeClickable(element("Xbutton"));
		hover(element("Xbutton"));
		wait.hardWait(1);
		click(element("Xbutton"));
		logMessage(" 'x' Button Clicked....");

	}

	public void VerifyAuthorNameInTitleField(String NameID) {
		isElementDisplayed("UploadFields", "Title");
		String TextDisplayed = element("UploadFields", "Title").getAttribute("value");
		logMessage("Text Displayed::" + TextDisplayed);
		logMessage("Text Expected::" + NameID);
		Assert.assertTrue(TextDisplayed.equals(NameID),
				"[Assertion Failed]:: Incorrect Text is Displayed in Title Filed::" + TextDisplayed);
		logMessage("[Assertion Passed]:: Correct Text is Displayed in Title Filed::" + NameID);
	}

	public void VerifyContentTypeSelectTypeOfContent() {

		isElementDisplayed("TypeSelect");

		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:Enhanced ePub > Full Package");
		wait.waitForPageToLoadCompletely();

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Project Support Materials>CFI"));
		logMessage("Content Type: Project Support Materials>CFI");
		wait.waitForPageToLoadCompletely();

		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Covers>Cover Design"));
		logMessage("Content Type:Covers>Cover Design");
		wait.waitForPageToLoadCompletely();

		logMessage("User Is Able To Select Content From Content Type....");

	}

	public void VerifyVariousFieldsInUploadContentPopUp() {

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UploadField", "Content Type");
		logMessage("Content Type is dispalyed...");

		isElementDisplayed("UploadFields", "Title");
		logMessage("Title is dispalyed...");
		fillText("Title", "Delete test");

		isElementDisplayed("UploadField", "Description");
		logMessage("Description is Displayed..");
	}

	public void Verify_Removed_Field_From_Upload_Content_Window() {
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Subject Keyword Taxonomy"),
				"[Assertion Failed]::Subject Keyword Taxonomy is dispalyed...");
		logMessage("Subject Keyword Taxonomy is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Product Data"),
				"[Assertion Failed]:Product Data is dispalyed...");
		logMessage("Product Data is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Relationship Type"),
				"[Assertion Failed]:Relationship Type is dispalyed...");
		logMessage("Relationship Type is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Relationship URI"),
				"[Assertion Failed]:Relationship URI is dispalyed...");
		logMessage("Relationship URI is NOT dispalyed...");
		Assert.assertTrue(verifyElementNotDisplayed("UploadField", "Relationship Target"),
				"[Assertion Failed]:Relationship Target is dispalyed...");
		logMessage("Relationship Target is NOT dispalyed...");
	}

	public void VerifyAddRemoveAndUploadButton() {

		isElementDisplayed("AddRemoveProject");
		logMessage("Add/RemoveProject button is displayed....");

		isElementDisplayed("UploadButton");
		logMessage("Upload Button is displayed....");
	}

	public void ClickAddKeywordTaxonomy() {
		isElementDisplayed("AddTaxonomy");
		click(element("AddTaxonomy"));
		logMessage("Add Taxonomy button clicked");
	}

	public void RemoveSubjectKeywordTaxonomyFunctionalityandVerify() {

		isElementDisplayed("AddedTaxonomyFiled");
		logMessage("Subject Keyword Taxonomy Field Added");

		isElementDisplayed("RemoveTaxonomyFiled");
		click(element("RemoveTaxonomyFiled"));

		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("AddedTaxonomyFiled"),
				"[Assertion Failed]::Added Taxonomy Filed Displayed..");
		logMessage("Added Taxonomy Filed Removed..");

	}

	public void VerifyUserIsAbleToSelectRelationshipTarget() {
		isElementDisplayed("RelationshipTarget");
		selectTextFromDropDown("RelationshipTarget", "NA");
		logMessage("'NA' Selected As Relationship Target");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipTarget", "Elvis");
		logMessage("'Elvis' Selected As Relationship Target");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipTarget", "CMS");
		logMessage("'CMS' Selected As Relationship Target");
		wait.hardWait(1);
	}

	public void VerifyUserIsAbleToSelectRelationshipType() {
		isElementDisplayed("RelationshipType");
		selectTextFromDropDown("RelationshipTarget", "NA");
		logMessage("'NA' Selected As Relationship Type");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipType", "isChild");
		logMessage("'isChild' Selected As Relationship Type");
		wait.hardWait(1);

		selectTextFromDropDown("RelationshipType", "isParent");
		logMessage("'isParent' Selected As Relationship Type");
		wait.hardWait(1);

	}

	public void VerifyAddtoProjectpopUp() {
		isElementDisplayed("AddtoProjectlabel");
		logMessage("Add to project popup displayed");
	}

	public void VerifySearchFieldAndClearLinkOnAddRemoveProjectPopUp() {
		isElementDisplayed("SearchProjectAddRemove");
		logMessage("Search Filed is Displayed");

		isElementDisplayed("ClickSearchButton");
		logMessage("Search Button is Displayed");

		isElementDisplayed("ClearLink");
		logMessage("Clear Link is Displayed");

	}

	public void verifyShortTitleFieldOnAddRemoveIsNotEmpty() {
		areElementsDisplayed("GetShortTitleValue");
		List<WebElement> ShortTitleField = elements("GetShortTitleValue");
		for (int EachFiled = 0; EachFiled < ShortTitleField.size(); EachFiled++) {
			String Text = ShortTitleField.get(EachFiled).getText().trim();
			if (Text.equals(" ") || Text == null || Text.length() == 0) {
				Assert.assertTrue(false,
						"[Assertion Failed]:: 'Short Title' Field Empty on  Add/Remove Project Window");
			}
		}
	}

	public void VerifyAvailableAndSelectedPane() {
		areElementsDisplayed("AvailablePane");
		logMessage("Seleted pane is displayed");
		List<WebElement> info = elements("AvailablePane");
		for (int i = 0; i < info.size(); i++) {
			wait.hardWait(1);
			logMessage(info.get(i).getAttribute("innerText") + " Is Displayed");
			wait.hardWait(1);
		}

		areElementsDisplayed("SelectedPane");
		logMessage("Selected pane is displayed");
		List<WebElement> infos = elements("SelectedPane");
		for (int i = 0; i < infos.size(); i++) {
			wait.hardWait(1);
			logMessage(infos.get(i).getAttribute("innerText") + " Is Displayed");
			wait.hardWait(1);
		}
	}

	public void VerifySelectUselectDoneCancelButton() {
		isElementDisplayed("SelectButton");
		isElementDisplayed("SelectButton");
		logMessage("Select Button Is Displayed");

		isElementDisplayed("UnSelectButton");
		isElementDisplayed("UnSelectButton");
		logMessage("UnSelect Button Is Displayed");

		isElementDisplayed("CancelButton");
		isElementDisplayed("CancelButton");
		logMessage("Cancel button Clicked");
	}

	public void VerifySelectedProjectMovedToavailablepane(String ISBN) {

		Assert.assertTrue(verifyElementNotDisplayed("ConformProject", ISBN),
				"[Assertion Failed]::Selected Content is not Moved To Availablepane");
		logMessage("Selected Content Moved To Availablepane");

	}

	public void VerifyProjectDisplayedOnSelectedPane(String ISBN) {

		isElementDisplayed("ConformProject", ISBN);
		logMessage("Project Displayed on SelectedPane::" + ISBN);

	}

	public void SearchProjectInAddRemovePopUp(String ISBN) {

		isElementDisplayed("SearchProjectAddRemove");
		isElementDisplayed("SearchProjectAddRemove");
		click(element("SearchProjectAddRemove"));
		String ISBNc = Keys.chord(ISBN);
		element("SearchProjectAddRemove").clear();
		wait.hardWait(1);
		element("SearchProjectAddRemove").sendKeys(ISBNc);
		logMessage(ISBN + " Entered Into Search Box");
		isElementDisplayed("ClickSearchButton");
		click(element("ClickSearchButton"));
		logMessage("Search button clicked");
		waitForLoaderToDisappear();
	}

	public void VerifyProjectDisplayedOnAvailablePane(String ISBN) {
		isElementDisplayed("selectProjectAddRemovePopUp", ISBN);
		logMessage("Project Displayed on AvailablePane");
		logMessage("Selected Content Moved To Available pane");
	}

	public void MoveProjectFromAvailablePaneToSelectedPane(String ISBN2) {
		isElementDisplayed("selectProjectAddRemovePopUp", ISBN2);
		click(element("selectProjectAddRemovePopUp", ISBN2));
		logMessage("Project Selected");
		wait.hardWait(2);

		isElementDisplayed("SelectButton");
		click(element("SelectButton"));
		logMessage("Selected Button Clicked");
	}

	public void ClickSelectButtonOnAddRemoveWindow() {
		isElementDisplayed("SelectButton");
		hoverOverElement(element("SelectButton"));
		click(element("SelectButton"));
		logMessage("Selected Button Clicked");
	}

	public void NavigateToPageNumberInAvailablePane(String PageNumber) {
		isElementDisplayed("NavigateInAvailablePane", PageNumber);
		click(element("NavigateInAvailablePane", PageNumber));
		logMessage("User Navigated to Page::" + PageNumber);

	}

	public void NavigateToPageNumberInSelectedPane(String PageNumber) {
		isElementDisplayed("NavigateInSelectedPane", PageNumber);
		click(element("NavigateInSelectedPane", PageNumber));
		logMessage("User Navigated to Page::" + PageNumber);

	}

	public void MoveProjectFromSelectedPaneToAvailablePane(String ISBN) {

		isElementDisplayed("ConformProject", ISBN);
		hoverOverElement(element("ConformProject", ISBN));
		wait.waitForPageToLoadCompletely();
		click(element("ConformProject", ISBN));
		logMessage(ISBN + " Project Selected on Selected Pane");
		wait.hardWait(2);

		isElementDisplayed("unselect");
		click(element("unselect"));
		logMessage("UnSelect Button Clicked...");

	}

	public void ClickSaveButtonOnAddToProject() {
		isElementDisplayed("saveButton");
		click(element("saveButton"));
		logMessage("Save Button Clicked");

	}

	public void VerifyAddToProjectPopUpNotDisplayed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("unselect"),
				"[Assertion Failed]::Add To Project PopUp is Displayed");
		logMessage("Add To Project PopUp Not Displayed!!!!");

	}

	public void ClickSelectAllAddRemoveAvailableSection() {
		isElementDisplayed("SelectAllAvailablePane");
		hoverOverElement(element("SelectAllAvailablePane"));
		click(element("SelectAllAvailablePane"));
		logMessage("Select All Check Box Clicked..");
	}

	public void clickCancelButtonOnAddToProject() {
		wait.hardWait(3);
		isElementDisplayed("CancelButton");
		click(element("CancelButton"));
		logMessage("Close Button Clicked!!!!!");

	}

	public void VerifyChangesNotSavedMsgDisplayed() {
		isAlertPresent();
		Alert alert = driver.switchTo().alert();
		String MSG = alert.getText();
		Assert.assertTrue(MSG.equals("Are you sure to leave !!!, there are unsaved records !! "),
				"[Assertion Failed]:: Correct Message Not Displayed::" + MSG);
		logMessage("[Assertion Passed::] Correnct Message Dispalyed::" + MSG);
		wait.hardWait(1);
		alert.accept();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyToolTips() {
		waitForLoaderToDisappear();
		isElementDisplayed("ToolTips", "Publish content links and ePub");
		hover(element("ToolTips", "Publish content links and ePub"));
		wait.hardWait(1);
		click(element("ToolTips", "Publish content links and ePub"));
		logMessage("'Publish content links and ePub' is Displayed");
		isElementDisplayed("ToolTipsInfo");
		wait.hardWait(1);
		String tips = element("ToolTips", "Publish content links and ePub").getAttribute("uib-popover-html");
		logMessage("Tool Tip for 'Publish content links and ePub'::" + tips);

		isElementDisplayed("ToolTips", "Publish content links only");
		hover(element("ToolTips", "Publish content links only"));
		wait.hardWait(1);
		click(element("ToolTips", "Publish content links only"));
		logMessage("'Publish content links only' is Displayed");
		isElementDisplayed("ToolTipsInfo");
		wait.hardWait(1);
		tips = element("ToolTips", "Publish content links only").getAttribute("uib-popover-html");
		logMessage("Tool Tip for 'Publish content links only'::" + tips);

		isElementDisplayed("ToolTips", "Publish ePub only");
		hover(element("ToolTips", "Publish ePub only"));
		wait.hardWait(1);
		click(element("ToolTips", "Publish ePub only"));
		logMessage("'Publish ePub only' is Displayed");
		isElementDisplayed("ToolTipsInfo");
		tips = element("ToolTips", "Publish ePub only").getAttribute("uib-popover-html");
		logMessage("Tool Tip for 'Publish ePub only'::" + tips);
	}

	public void VerifyToolTips(String Option, String platform) {
		String[] tooltip = new String[3];
		tooltip[0] = "'CMS sends CFI content links to Courseware and publishes ePub to " + platform
				+ " with this action.'";
		tooltip[1] = "'CMS sends CFI content links to Courseware with this action.'";
		tooltip[2] = "'CMS publishes ePub to " + platform + " with this action.'";
		isElementDisplayed("ToolTips", Option);
		click(element("ToolTips", Option));
		isElementDisplayed("ToolTipsInfo");
		logMessage("'" + Option + "' is Displayed");
		wait.hardWait(2);
		String Expected;
		if (Option.equals("Publish content links and ePub")) {
			Expected = tooltip[0];
		} else if (Option.equals("Publish content links only")) {
			Expected = tooltip[1];
		} else {
			Expected = tooltip[2];
		}
		String tips = element("ToolTips", Option).getAttribute("uib-popover-html");
		logMessage("Tool Tip Displayed::" + tips);
		if (tips.equalsIgnoreCase(Expected)) {
			logMessage("[Assertion Passed]::'" + tips + "' IS Displayed");
		} else {
			logMessage("[Assertion Failed]::Incorrect '" + tips + "' IS Displayed");
			assertTrue(false);
		}
	}

	public void VerifyPublishRadioButtonSequence(String Option1, String Option2, String Option3) {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("SequenceOfRadioButton");
		String[] SequenceNeeded = new String[3];
		SequenceNeeded[0] = Option1;
		SequenceNeeded[1] = Option2;
		SequenceNeeded[2] = Option3;

		for (int count = 0; count < 3; count++) {
			String ValueDisplayed = elements("SequenceOfRadioButton").get(count).getAttribute("innerText").trim();
			logMessage("Radio Option Expected::" + SequenceNeeded[count]);
			logMessage("Radio Option Displayed::" + ValueDisplayed);
			Assert.assertTrue(ValueDisplayed.equals(SequenceNeeded[count]),
					"[Assertion Failed]::Radio Option Displayed::" + ValueDisplayed);
		}
	}

	public void UploadFlatEpubFromProjectView(String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		// System.out.println(selServer);
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN
					+ "_EPUB.epub";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + "_EPUB.epub";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + "_EPUB.epub selected");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Flat ePub > Full Package"));
		logMessage("Content Type:" + getData("TypesOfContent.Flat ePub > Full Package"));
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + "_EPUB.epub");
		logMessage(FileISBN + "_EPUB.epub Title of the file");
		wait.hardWait(2);

		isElementDisplayed("Upload");
		click(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");
		waitForPageToLoadCompletely(getPageTitle());

	}

	public void UploadEnhancedEpubFromProjectView(String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		// System.out.println(selServer);
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN + ".epub";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + ".epub";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + ".epub selected");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Enhanced ePub > Full Package"));
		logMessage("Content Type:" + getData("TypesOfContent.Enhanced ePub > Full Package"));
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + ".epub");
		logMessage(FileISBN + ".epub Title of the file");
		wait.hardWait(2);

		isElementDisplayed("Upload");
		click(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void UploadCoversCoverDesignFromProjectView(String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN
					+ "_FC.jpg";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + "_FC.jpg";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + "_FC.jpg selected");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", "Covers>Cover Design");
		logMessage("Content Type:Covers>Cover Design");
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + "_FC.jpg");
		logMessage(FileISBN + "_FC.jpg Title of the file");
		wait.hardWait(2);

		isElementDisplayed("Upload");
		click(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void UploadXHTMLContentFromProjectView() {
		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\XHTML Example.xhtml";

		} else {
			filePath = "C:/cms Testdata/XHTML Example.xhtml";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage("XHTML Example.xhtml Is Selected..");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.xhtml"));
		logMessage("Content Type:xhtml");
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys("XHTML Example.xhtml");
		logMessage("'XHTML Example.xhtml' Title of the file");
		wait.hardWait(2);

		isElementDisplayed("Upload");
		click(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void UploadCFIContentFromProjectView(String FileISBN) {
		String selServer = System.getProperty("seleniumServer");
		isElementDisplayed("BrowseFile");
		String filePath = null;
		if (selServer == null) {
			filePath = System.getProperty("user.dir") + "\\src\\test\\resources\\testdata\\CMS\\" + FileISBN
					+ "_CFI.csv";

		} else {
			filePath = "C:/cms Testdata/" + FileISBN + "_CFI.csv";
		}
		element("BrowseFile").sendKeys(filePath);
		logMessage(FileISBN + "_CFI.csv selected");
		wait.hardWait(2);

		isElementDisplayed("TypeSelect");
		selectTextFromDropDown("TypeSelect", getData("TypesOfContent.Project Support Materials>CFI"));
		logMessage("Content Type:CFI");
		wait.hardWait(2);

		isElementDisplayed("Title");
		element("Title").sendKeys(FileISBN + "_CFI.csv");
		logMessage(FileISBN + "_CFI.csv Title of the file");
		wait.hardWait(2);

		isElementDisplayed("Upload");
		click(element("Upload"));
		isElementDisplayed("ContentAddedMsg");
		wait.waitForPageToLoadCompletely();
		String msg = element("ContentAddedMsg").getText().trim();
		Assert.assertTrue(msg.equals("Content successfully created."), "[Assertion Failed]:Content Not Uploded");
		logMessage("[Assertion Passed]: Content is uploded");

	}

	public void VerifyViewUsageDetailPopUpDisplay() {
		wait.hardWait(2);
		isElementDisplayed("UsagePopUp");
		logMessage("View Usage Detail Pop Up Displayed.....");
	}

	public void verifySearchFieldAndClearAllOnUsageDetailPopUp() {
		isElementDisplayed("SearchProjectAddRemove");
		logMessage("Search Field Is Displayed");

		isElementDisplayed("ClearAll");
		logMessage("Clear All Field Is Displayed");
	}

	public void VerifyInformationOnUsageDetail() {
		areElementsDisplayed("UsageDetailInfo");
		List<WebElement> info = elements("UsageDetailInfo");
		for (int i = 0; i < info.size(); i++) {
			wait.hardWait(1);
			logMessage(info.get(i).getAttribute("innerText") + " is Displayed...");
		}
	}

	public void VerifyAssetDisplayedOnAssetAssociationPopUp(String ISBN2) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AssetUsageDetail");
		String AssetName = element("AssetUsageDetail").getAttribute("innerText");
		logMessage("Asset Name Dispalyed::" + AssetName);
		logMessage("Asset name Expected::" + ISBN2);
		Assert.assertTrue((ISBN2.trim()).equalsIgnoreCase((AssetName.trim())),
				"[Assertion Failed]:: Incorrect Assert Name Displayed...");
		logMessage("[Assertion Passed]:: Correct Assert Name Displayed...");

	}

	public void SearchForAssetOnAssetAssociationPopUp(String fileName) {
		isElementDisplayed("UDSearchBar");
		click(element("UDSearchBar"));
		String ISBNc = Keys.chord(fileName);
		element("UDSearchBar").clear();
		element("UDSearchBar").sendKeys(ISBNc);
		logMessage("'" + fileName + "' is Entered In Search Bar..");
		isElementDisplayed("UDSearchButton");
		click(element("UDSearchButton"));
		logMessage("Search Button Clicked...");
	}

	public void VerifyContentTypeInAssociationPopup(String ContentType) {
		isElementDisplayed("ContentTypeInUG");
		String ContentTypeDisplayed = element("ContentTypeInUG").getAttribute("innerText");

		logMessage("Content Type Expected::" + ContentType);
		String TypeDisplayed = ContentTypeDisplayed.substring(0, 21);
		logMessage("Content Type Displayed::" + TypeDisplayed);
		Assert.assertTrue(ContentType.contains(TypeDisplayed),
				"[Assertion Failed]:: Incorrect ContentType is Displayed::" + ContentTypeDisplayed);
		logMessage("[Assertion Passed]:: Correct ContentType is Displayed::" + ContentTypeDisplayed);
	}

	public void VerifyOrganizedDownloadPopUp() {
		isElementDisplayed("OrganisedDownloadPopUp");
		logMessage("[Assertion Passed]:: Organised Download PopUp Displayed");

	}

	public void VerifyEpubsAndOtherAssetsOnPushToAuthoringTool() {
		isElementDisplayed("selectOther");
		isElementDisplayed("selectOther");
		logMessage("'Other Assets' is Displayed...");

		isElementDisplayed("EpubRadio");
		isElementDisplayed("EpubRadio");
		logMessage("'Epubs only' is Displayed...");

	}

	public void VerifyGridView() {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		areElementsDisplayed("GridView");
		logMessage("Thumbnail View Is displayed...");

	}

	public void ClickListViewOnPushToAuthoringTool() {
		isElementDisplayed("ViewButton");
		logMessage("View Button Is Dispayed...");
		click(element("ViewButton"));
		logMessage("'ViewButton' Clicked List view Selected..");
		waitForLoaderToDisappear();
	}

	public void VerifyListView() {
		isElementDisplayed("ViewButton");
		logMessage("View Button Is Dispayed...");
		click(element("ViewButton"));
		logMessage("'ViewButton' Clciked List view Selected..");

		areElementsDisplayed("ListView");
		List<WebElement> info = elements("ListView");

		for (int i = 0; i < info.size(); i++) {
			wait.hardWait(1);
			logMessage("'" + info.get(i).getAttribute("innerText") + "' Is Displayed....");
		}
	}

	public void VerifySearchBarOnStep2pushToAuthoringTool() {
		isElementDisplayed("Step2SearchBar");
		logMessage("Search bar on Step 2 of pushToAuthoringTool is Dispayed....");

	}

	public void VerifySearchBarOnStep3pushToAuthoringTool() {
		isElementDisplayed("SearchBar");
		logMessage("Search bar on Step 3 of pushToAuthoringTool is Dispayed....");

	}

	public void VerifyStep3OfPushToAuthoringToolNotDisplayed() {
		isElementDisplayed("Step3Section");
		Assert.assertTrue(element("Step3Section").getAttribute("class").trim().contains("ng-hide"),
				"[Assertion Failed]:: Step 3: Select Project ISBN and / or Push is Displayed..");
	}

	public void VerifyStep3OfPushToAuthoringToolIsDisplayed() {
		isElementDisplayed("Step3Section");
		Assert.assertFalse(element("Step3Section").getAttribute("class").trim().contains("ng-hide"),
				"[Assertion Failed]:: Step 3: Select Project ISBN and / or Push is Displayed..");
	}

	public void VerifyInfoIsDisplayedOnClickingHelpIcon() {
		isElementDisplayed("HelpIcon");
		logMessage("help Icon Is dispalyed....");
		click(element("HelpIcon"));
		logMessage("help icon clciked...");

		wait.hardWait(1);
		isElementDisplayed("HelpInfos");
		logMessage("Help Information Is Displayed::" + element("HelpInfos").getAttribute("innerText"));

	}

	public void SearchProjectInStep3SearchFieldOfpushToAuthoringTool(String ISBN) {
		isElementDisplayed("searchBar");
		scroll(element("searchBar"));
		click(element("searchBar"));
		element("searchBar").clear();
		String ISBNc = Keys.chord(ISBN);
		element("searchBar").sendKeys(ISBNc);
		logMessage("'" + ISBN + "' is Entered In Search Bar..");
		click(element("searchButton"));
		logMessage("Search button clicked");
		wait.waitForPageToLoadCompletely();

	}
	
	public void enterTextIntoStep3SearchFieldOfpushToAuthoringTool(String ISBN) {
		isElementDisplayed("searchBar");
		scroll(element("searchBar"));
		click(element("searchBar"));
		element("searchBar").clear();
		String ISBNc = Keys.chord(ISBN);
		element("searchBar").sendKeys(ISBNc);
		logMessage("'" + ISBN + "' is Entered In Search Bar..");
	}
	
	public void enterTextIntoStep3SearchFieldOfpushToAuthoringTool(Keys ISBN) {
		isElementDisplayed("searchBar");
		scroll(element("searchBar"));
		click(element("searchBar"));
		element("searchBar").clear();
		String ISBNc = Keys.chord(ISBN);
		element("searchBar").sendKeys(ISBNc);
		logMessage("'" + ISBN + "' is Entered In Search Bar..");
	}
	
	public void clearStep3SearchFieldOfpushToAuthoringTool() {
		isElementDisplayed("searchBar");
		scroll(element("searchBar"));
		click(element("searchBar"));
		element("searchBar").clear();
		logMessage(" is Entered In Search Bar..");
	}
	
	
	
	public void VerifyNonStandardProjectMessage(String NameEntered, String Message) {
		wait.waitForPageToLoadCompletely();
		String MessageExpected = NameEntered + " " + Message;
		isElementDisplayed("DemoISBNMsg");
		String MessageDisplayed = element("DemoISBNMsg").getText().trim().replaceAll("\\r\\n|\\r|\\n", " ");
		logMessage("Expected Message :: " + MessageExpected);
		logMessage("Displayed Message::" + MessageDisplayed);
		Assert.assertTrue(MessageExpected.equals(MessageDisplayed),
				"[Assertion Failed]:: Incorrect Message Displayed=" + MessageDisplayed);
	}

	public void verifyNotSupportedProjectNameDisplayedOnPushToAuthoringTool(String ProjectName) {
		String ExpectedMsg='"'+ProjectName+'"'+" "+ getData("NotSupportedProjectName");
		logMessage("Expected Message::"+ExpectedMsg);
		isElementDisplayed("NotSupportedProjectMsg",ExpectedMsg);
	}
	
	public void verifyReservedCharacterMessageDisplayedOnPushToAuthoringTool(String ProjectName) {
		String ExpectedMsg='"'+ProjectName+'"'+" "+ getData("ReservedCharacter");
		logMessage("Expected Message::"+ExpectedMsg);
		isElementDisplayed("NotSupportedProjectMsg",ExpectedMsg);
	}

	public void VerifyNonStandardProjectMessageIsNotDisplayed() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("DemoISBNMsgNotDisplayed");
		logMessage("[Assertion Passed]::NonStandard ProjectMessage Is Not Displayed");
	}

	public void VerifyProjectColoumHidden() {
		isElementDisplayed("ProjectColoumHidden");
	}

	public void VerifyProjectIsDisplayedOnAuthoringTool(String ISBN) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("SelectProject", ISBN);
		logMessage("Project Of " + ISBN + " is Displayed on Push To AuthoringTool");
	}

	public void VerifyColoumOfProject() {
		wait.waitForPageToLoadCompletely();
		areElementsDisplayed("ProjectColoum");
		List<WebElement> info = elements("ProjectColoum");
		for (int col = 1; col < info.size(); col++) {
			logMessage(info.get(col).getAttribute("innerText") + " Is Displyed...");
		}

	}

	public void VerifySingleProjectDisplayedOnAuhoringTool() {
		areElementsDisplayed("ProjectDisplay");
		if (elements("ProjectDisplay").size() == 1) {
			logMessage("[Assertion Passed]:: Only One Project Is Displayed...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: More than One Project Is Displayed...");
		}

	}

	public void Verify_Cancel_And_Push_OnPushToAuthoringPopUp() {
		isElementDisplayed("Cancel");
		logMessage("Cancel Button Is Displayed..");

		isElementDisplayed("push");
		logMessage("push Button Is Displayed..");

	}

	public void ClickCancelOnAuthoringTool() {
		isElementDisplayed("Cancel");
		click(element("Cancel"));
		logMessage("Cancel button Clicked.....");

	}

	public void VerifyAuthoringToolClosed() {
		wait.waitForPageToLoadCompletely();
		wait.hardWait(1);
		Assert.assertTrue(verifyElementNotDisplayed("HelpIcon"),
				"[Assertion Failed]::Push To Authoring Tool PopUp Pop Up is Displayed");
		logMessage("Push To Authoring Tool PopUp Pop Up is Not Displayed.....");
	}

	public void VerifyPublishPopUpDispplayed() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("publish");
		logMessage("Publish Pop Up Is Displayed...");
	}

	public void VerifyTitleOfProjectIsDisplayedOnPublishPopUp(String ISBN) {
		isElementDisplayed("PublishTitle");
		String Title = element("PublishTitle").getAttribute("innerText");
		logMessage("Title shown::" + Title);
		Assert.assertTrue(Title.contains(ISBN),
				"[Assertion Failed]:: Publish Title does not contains The ISBN Of The Project");

		logMessage("[Assertion Passed]:: Publish Title contains ISBN Of The Project");

	}

	public void VerifyStep1AndStep2SectionAreDisplayed() {
		// isElementDisplayed("PublishSection", "Step 1 Select Assets");
		logMessage("'Step 2  Select Assets' Section Is Displayed....");

		// isElementDisplayed("PublishSection", "Step 3 Publish Assets");
		logMessage("'Step 3  Publish Assets' Section Is Displayed....");
	}

	public void VerifyStep1AndStep2SectionAreNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("PublishSection", "Step 2  Select Assets"),
				"[Assertion Failed]::'Step 2  Select Assets' Section Is Displayed.");
		logMessage("'Step 2  Select Assets' Section Is Not Displayed....");

		Assert.assertTrue(verifyElementNotDisplayed("PublishSection", "Step 3  Publish Assets"),
				"[Assertion Failed]::'Step 3  Publish Assets' Section Is Displayed");
		logMessage("'Step 3  Publish Assets' Section Is Not Displayed....");

	}

	public void VerifyPublishDestinationOnPublishPopIs(String PublihDestination) {
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		isElementDisplayed("destination");
		Select select = new Select(element("destination"));
		WebElement option = select.getFirstSelectedOption();
		String Destination = option.getText().trim();
		logMessage("Publish Destination Selected::" + Destination);
		Assert.assertTrue(PublihDestination.equals(Destination), "[Assertion Failed]:: Publish Destination Displayed '"
				+ Destination + "' Expected '" + PublihDestination + "'");
		logMessage("[Assertion Passed]:: Publish Destination '" + Destination + "' Displayed");
	}

	public void VerifyPublishDestinationOnPublishPopIsDisabled() {
		isElementDisplayed("destination");
		String Attri = element("destination").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Failed]:: Destination DropDown Is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]:: Destination DropDown Disabled...");
		}

	}

	public void VerifyContentTypeDisplayedInStep2PublishWindow(String ContentType) {
		wait.waitForPageToLoadCompletely();
		List<WebElement> text = elements("SearchTitleOnManualPublish");
		int i, flag = 0;
		for (i = 0; i < text.size(); i++) {
			String Content = text.get(i).getAttribute("innerText");
			if (Content == null) {
				Content = text.get(i).getAttribute("innerText");
			}

			if (Content.contains(ContentType)) {
				logMessage(ContentType + " Is Displayed in Step2 of Publish Window...");
				flag = 1;
				break;
			}
		}
		if (flag == 0) {
			Assert.assertTrue(false,
					"[Assertion Failed]::" + ContentType + " Is Not Displayed in Step2 of Publish Window...");

		}
	}

	public void ExpandRepositoryOnManualPublish(String RepositoryName) {
		areElementsDisplayed("SearchRepository");
		List<WebElement> text = elements("SearchRepository");

		int foundFlag = 0, i;
		for (i = 0; i < text.size(); i++) {
			wait.hardWait(1);
			String Content = text.get(i).getAttribute("innerText");
			logMessage("Repository Displayed::" + Content.trim());
			logMessage("Expected::" + RepositoryName.trim());
			if ((Content.trim()).contains((RepositoryName.trim()))) {
				foundFlag = 1;
				break;
			}
		}

		if (foundFlag == 1) {
			isElementDisplayed("ExpandRepository", (i + 1) + "");
			click(element("ExpandRepository", (i + 1) + ""));
			logMessage(RepositoryName.trim() + " Section Expanded....");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]::" + RepositoryName.trim() + " Repository Not Found...");
		}
	}

	public void ExpandContentTypeOnUpdateContentMetadata(String Repo, String ContentType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExpandContentOnCWMetadata", Repo, ContentType);
		scroll(element("ExpandContentOnCWMetadata", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ExpandContentOnCWMetadata", Repo, ContentType));
	}

	public void ClickContentTypeOnUpdateContentMetadata(String Repo, String ContentType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckBoxContentOnCWMetadata", Repo, ContentType);
		scroll(element("CheckBoxContentOnCWMetadata", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("CheckBoxContentOnCWMetadata", Repo, ContentType));
	}

	public void VerifyUserIsAbleToSelectAssertInStep2OnUpdateContentMetadata(String Repo, String ContentType,
			String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExpandContentOnCWMetadata", Repo, ContentType);
		scroll(element("ExpandContentOnCWMetadata", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ExpandContentOnCWMetadata", Repo, ContentType));

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckContentOnCWMetadata", FileName);
		scroll(element("CheckContentOnCWMetadata", FileName));
		hover(element("CheckContentOnCWMetadata", FileName));
		wait.waitForPageToLoadCompletely();
		click(element("CheckContentOnCWMetadata", FileName));
		logMessage(FileName + " Is Selected Displayed...");
	}

	public void VerifyAssetDisplayedInStep2ForCourseware(String Repo, String ContentType, String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExpandContentOnCWMetadata", Repo, ContentType);
		scroll(element("ExpandContentOnCWMetadata", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ExpandContentOnCWMetadata", Repo, ContentType));

		isElementDisplayed("VerifyAssetOnCWMetadata", FileName);
		logMessage("Input Box For " + FileName + " is Displayed...");
	}

	public void VerifyToolTipDisplayedInStep2ForCourseware(String Repo, String ContentType, String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExpandContentOnCWMetadata", Repo, ContentType);
		scroll(element("ExpandContentOnCWMetadata", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ExpandContentOnCWMetadata", Repo, ContentType));

		isElementDisplayed("VerifyAssetOnCWMetadata", FileName);
		hover(element("VerifyAssetOnCWMetadata", FileName));
		wait.hardWait(1);
		isElementDisplayed("ToolTipPopUp",
				(element("VerifyAssetOnCWMetadata", FileName).getAttribute("uib-tooltip").trim()));
		logMessage("Tool tip Is Displayed...");
		logMessage("Input Box For " + FileName + " is Displayed...");
	}

	public void VerifyToolTipIsDisplayedOnStep2ofPublishWindow(String Repo, String ContentType, String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExpandTitleOnManualPublish", Repo, ContentType);
		scroll(element("ExpandTitleOnManualPublish", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ExpandTitleOnManualPublish", Repo, ContentType));
		isElementDisplayed("VerifyFileOnStep2", FileName);
		hover(element("VerifyFileOnStep2", FileName));
		wait.hardWait(1);
		isElementDisplayed("ToolTipPopUp", (element("VerifyFileOnStep2", FileName).getAttribute("uib-tooltip").trim()));
		logMessage("Tool tip Is Displayed...");
	}

	public void VerifyFileIsDisplayedOnStep2ofPublishWindow(String Repo, String ContentType, String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExpandTitleOnManualPublish", Repo, ContentType);
		scroll(element("ExpandTitleOnManualPublish", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ExpandTitleOnManualPublish", Repo, ContentType));

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckContentOnManualPublish", FileName);
		scroll(element("ExpandTitleOnManualPublish", Repo, ContentType));
	}

	public void ExpandContentTypeOnManualPublish(String Repo, String ContentType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ExpandTitleOnManualPublish", Repo, ContentType);
		scroll(element("ExpandTitleOnManualPublish", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ExpandTitleOnManualPublish", Repo, ContentType));
	}

	public void ClickContentTypeOnManualPublish(String Repo, String ContentType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ClickTitleOnManualPublish", Repo, ContentType);
		scroll(element("ClickTitleOnManualPublish", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("ClickTitleOnManualPublish", Repo, ContentType));
	}

	public void verifyContentTypeDisabledOnPublishWindow(String Repo, String ContentType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ClickTitleOnManualPublish", Repo, ContentType);
		isAttribtuePresent(element("ClickTitleOnManualPublish", Repo, ContentType), "disabled");
		String CursorStatus = element("ClickTitleOnManualPublish", Repo, ContentType).getCssValue("cursor");
		logMessage("Cursor Property::" + CursorStatus);
		Assert.assertTrue(CursorStatus.trim().equals("not-allowed"), "[Assertion Failed]::Hand Icon Not Displayed..");
		logMessage("Content Type '" + ContentType + "' is Disabled...");

	}

	public void SelectAssetDisplayedOnStep2ofPublishWindow(String Repo, String ContentType, String FileName,
			Boolean expand) {
		wait.waitForPageToLoadCompletely();
		if (expand) {
			isElementDisplayed("ExpandTitleOnManualPublish", Repo, ContentType);
			scroll(element("ExpandTitleOnManualPublish", Repo, ContentType));
			wait.waitForPageToLoadCompletely();
			click(element("ExpandTitleOnManualPublish", Repo, ContentType));
		}

		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckContentOnManualPublish", FileName);
		scroll(element("ExpandTitleOnManualPublish", Repo, ContentType));
		wait.waitForPageToLoadCompletely();
		click(element("CheckContentOnManualPublish", FileName));
		logMessage(FileName + " Is Selected Displayed...");

	}

	public void VerifySeletedAssertIsDisplayedInStep3(String ISBN) {
		wait.hardWait(1);
		isElementDisplayed("selectEpubOnPublish", (ISBN + ".epub"));
		scroll(element("selectEpubOnPublish", (ISBN + ".epub")));
		logMessage(ISBN + ".epub" + " Is Displayed in Step 3 of Publish");
	}

	public void Select_EnhancedEpub_Displayed_In_Step3(String ISBN) {
		scrollToBottom();
		wait.hardWait(1);
		isElementDisplayed("selectEpubOnPublish", (ISBN + ".epub"));
		logMessage(ISBN + ".epub" + " Is Displayed in Step 3 of Publish");
		click(element("selectEpubOnPublish", (ISBN + ".epub")));
		logMessage("Epub Selected");
		wait.hardWait(1);
	}

	public void Select_FlatEpub_Displayed_In_Step3(String ISBN) {
		wait.hardWait(1);
		isElementDisplayed("selectEpubOnPublish", ISBN + "_EPUB.epub");
		scrollToBottom();
		logMessage(ISBN + "_EPUB.epub" + " Is Displayed in Step 3 of Publish");
		click(element("selectEpubOnPublish", ISBN + "_EPUB.epub"));
		logMessage("Epub Selected");
		wait.hardWait(1);
	}

	public void Select_Assert_Displayed_In_Step3(String FileName) {
		wait.hardWait(2);
		isElementDisplayed("selectEpubOnPublish", FileName);
		scrollToBottom();
		logMessage(FileName + " Is Displayed in Step 3 of Publish");
		hover(element("selectEpubOnPublish", FileName));
		wait.hardWait(1);
		click(element("selectEpubOnPublish", FileName));
		logMessage(FileName + " Selected");
	}

	public void VerifyPublishAssetsHasApproveAndApproveButton() {
		isElementDisplayed("ApproveButton");
		isElementDisplayed("ApproveButton");
		logMessage("Approve Button Is Displayed..");

		isElementDisplayed("UnapproveButton");
		isElementDisplayed("UnapproveButton");
		logMessage("Unapprove Button Is Displayed..");

	}

	public void VerifyPublishAssetsDetailsAreProvided() {
		isElementDisplayed("publishAssetDetail", "Name");
		isElementDisplayed("publishAssetDetail", "Type");
		isElementDisplayed("publishAssetDetail", "Status");
		isElementDisplayed("publishAssetDetail", "Repository");
	}

	public void ClickUnApproveButtonOnPublishPopUp() {
		wait.hardWait(3);
		isElementDisplayed("UnapproveButton");
		click(element("UnapproveButton"));
		waitForLoaderToDisappear();
		logMessage("Unapprove Button Clicked");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyUnapproveButtonOnPublishPopUpDisabled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UnapproveButton");
		String Attri = element("UnapproveButton").getAttribute("disabled");
		if (Attri == null) {
			Assert.assertTrue(false, "[Assertion Failed]:: Unapprove Button Is Enabled...");
		} else {
			logMessage("[Assertion Passed]:: Unapprove Button Is Disabled...");
		}

	}

	public void VerifyUnapproveButtonOnPublishPopUpEnabled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("UnapproveButton");
		String Attri = element("UnapproveButton").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Unapprove Button Is Enabled...");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Unapprove Button Is Disabled...");
		}

	}


	public void ClickApproveButtonOnPublishPopUp() {
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ApproveButton");
		click(element("ApproveButton"));
		waitForLoaderToDisappear();
		logMessage("Approve Button Clicked");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyApproveButtonOnPublishPopUpDisabled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ApproveButton");
		String Attri = element("ApproveButton").getAttribute("disabled");
		if (Attri == null) {
			Assert.assertTrue(false, "[Assertion Failed]:: Approve Button Is Enabled...");
		} else {
			logMessage("[Assertion Passed]:: Approve Button Is Disabled...");
		}

	}

	public void VerifyApproveButtonOnPublishPopUpEnabled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ApproveButton");
		String Attri = element("ApproveButton").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Approve Button Is Enabled...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Approve Button Is Disabled...");
		}

	}

	public void clickPublishOnPuplishPopUp() {
		wait.hardWait(1);
		isElementDisplayed("publish");
		scroll(element("publish"));
		click(element("publish"));
		logMessage("Publish Was clicked");

	}

	public void VerifyPublishAndCancelButtonOnPuplishPopUp() {
		isElementDisplayed("publish");
		scroll(element("publish"));
		logMessage("Publish Button Is Displayed...");

		isElementDisplayed("CancelButt");
		scroll(element("CancelButt"));
		logMessage("Cancel Button Is Displayed...");

	}

	public void clickCancelButtonOnPublishPopUp() {
		isElementDisplayed("CancelButt");
		scroll(element("CancelButt"));
		logMessage("Cancel Button Is Displayed...");
		click(element("CancelButt"));
		logMessage("cancel Button Clicked");
	}

	public void VerifyPublishPopUpClosed() {
		wait.waitForPageToLoadCompletely();
		wait.hardWait(2);
		Assert.assertTrue(verifyElementNotDisplayed("CancelButt"),
				"[Assertion Failed]::Publish Pop Up Is Displayed...");
		logMessage("Publish Pop Up Is Not Displayed...");
	}

	public void SelectRadioButtonOnPublish(String TypeOfcontent) {
		isElementDisplayed("TypeOfcontentToPublish", TypeOfcontent);
		click(element("TypeOfcontentToPublish", TypeOfcontent));
		logMessage("'" + TypeOfcontent + "'" + " Selected as type od centent To publish");

	}

	public void VerifyErrorMessage(String ISBN) {
		isElementDisplayed("publishMessage");
		String Msg = element("publishMessage").getAttribute("innerText");
		String expected = "CFI associated with project: " + ISBN
				+ " belongs to an Enhanced EPUB which is not associated to the project: " + ISBN
				+ ", so CFI snippet will not be sent to Algolia";
		Assert.assertTrue(expected.equals(Msg),
				"[Assertion Failed]::Correct Error Message Not Dispaled Message Dispalyed::'" + Msg + "'");
		logMessage("[Assertion Passesed]:: Error Message Displayed::" + Msg);
	}

	public void VerifyPublishButtonOnPublishPopUpDisabled() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("publish");
		String Attri = element("publish").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Failed]:: Publish Button Is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]:: Publish Button Is Disabled...");
		}

	}

	public void VerifyPublishButtonOnPublishPopUpEnabled() {
		isElementDisplayed("publish");
		String Attri = element("publish").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Publish Button Is Enabled...");
		} else {
			logMessage("[Assertion Failed]:: Publish Button Is Disabled...");
			Assert.assertTrue(false);
		}

	}

	public void SelectFCFile_DisplayedInStep3(String ISBN) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("selectEpubOnPublish", (ISBN + "_FC.jpg"));
		scroll(element("selectEpubOnPublish", (ISBN + "_FC.jpg")));
		logMessage(ISBN + ".epub" + " Is Displayed in Step 3 of Publish");
		click(element("selectEpubOnPublish", (ISBN + "_FC.jpg")));
		logMessage("Epub Selected");
		wait.waitForPageToLoadCompletely();

	}

	public void VerifyISBnDetailTabDisplayInformation() {
		isElementDisplayed("IsbnDetailsfirst", "Title:");
		logMessage(element("IsbnDetailsfirst", "Title:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Subtitle:");
		logMessage("Subtitle:" + element("IsbnDetails", "Subtitle:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Short Title:");
		logMessage("Short Title:" + element("IsbnDetails", "Short Title:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetailsfirst", "ISBN:");
		logMessage(element("IsbnDetailsfirst", "ISBN:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetailsfirst", "Project ISBN 10:");
		logMessage(element("IsbnDetailsfirst", "Project ISBN 10:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Author:");
		logMessage("Author:" + element("IsbnDetails", "Edition:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Edition:");
		logMessage("Author:" + element("IsbnDetails", "Author:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Copyright Year:");
		logMessage("Copyright Year:" + element("IsbnDetails", "Copyright Year:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Actual Pub Date:");
		logMessage("Actual Pub Date:" + element("IsbnDetails", "Actual Pub Date:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Version Type:");
		logMessage("Version Type:" + element("IsbnDetails", "Version Type:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Binding:");
		logMessage("Binding:" + element("IsbnDetails", "Binding:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Medium:");
		logMessage("Medium:" + element("IsbnDetails", "Medium:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Sub Group:");
		logMessage("Sub Group:" + element("IsbnDetails", "Sub Group:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Page Count Estimate:");
		logMessage("Page Count Estimate:" + element("IsbnDetails", "Page Count Estimate:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Page Count Actual:");
		logMessage("Page Count Actual:" + element("IsbnDetails", "Page Count Actual:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Publication Status:");
		logMessage("Publication Status:" + element("IsbnDetails", "Publication Status:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Publisher:");
		logMessage("Publisher:" + element("IsbnDetails", "Publisher:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Planned Pub Date:");
		logMessage("Planned Pub Date:" + element("IsbnDetails", "Planned Pub Date:").getAttribute("innerText"));

		isElementDisplayed("IsbnDetails", "Discipline:");
		logMessage("Discipline:" + element("IsbnDetails", "Discipline:").getAttribute("innerText"));
	}

	public void VerifyProjectContactAndAddButtonDisplayed() {
		isElementDisplayed("AddEmail");
		logMessage("Project Contact Is Displayed...");
		isElementDisplayed("AddButton");
		logMessage("Add Button On Project Contact Is Displayed...");

	}

	public void AddEmailAddress(String Email) {
		isElementDisplayed("AddEmail");
		fillText("AddEmail", Email);
		isElementDisplayed("AddButton");
		click(element("AddButton"));
		logMessage("Add button Clicked.....");

	}

	public void VerifyEmailIsAdded(String Email) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("deleteButton", Email);
		logMessage(Email + " Is Added in Content Contacts");
	}

	public void RemoveEmailFormProjectDetail(String Email) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("deleteButton", Email);
		hoverOverElement(element("deleteButton", Email));
		click(element("deleteButton", Email));
		logMessage("Delete Button Clicked..");
	}

	public void VerifyEmailNotDisplayedOnProjectDetail(String Email) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("deleteButton", Email),
				"[Assertion Failed]:: Email " + Email + " Displayed..");
	}

	public void VerifyMessageOnInvalidEmailAddress() {
		isElementDisplayed("AddEmail");
		fillText("AddEmail", "InvalidEmail");
		isElementDisplayed("AddButton");
		click(element("AddButton"));
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("InvalidMSg");
		logMessage("Message Displayed::" + element("InvalidMSg").getText().trim());
		Assert.assertTrue(element("InvalidMSg").getText().trim().equals("Invalid email address"),
				"[Assertion Failed]:: Error Message Not Dispalyed");
		logMessage("[Assertion Passed]:: Error Message Displayed '" + element("InvalidMSg").getAttribute("innerText")
				+ "'");
	}

	public void VerifyOnPublishDetailPage() {
		isElementDisplayed("label");
		logMessage("User IS On Piblish Detail Page...");

	}

	public void VerifyHeaderOfPublishTab() {
		isElementDisplayed("publishHeader", "Username");
		isElementDisplayed("publishHeader", "Destination");
		isElementDisplayed("publishHeader", "File Name(s) / ISBNs");
		isElementDisplayed("publishHeader", "Published Date");
		isElementDisplayed("publishHeader", "Publish Status");

	}

	public void VerifyRefreshLink() {
		isElementDisplayed("Refresh");
		logMessage("Refresh Link Is Available....");
	}

	public void ClickRefreshLink() {
		String title = getPageTitle();
		wait.hardWait(2);
		isElementDisplayed("Refresh");
		click(element("Refresh"));
		logMessage("Refresh Link clicked...");
		waitForPageToLoadCompletely(title);
	}

	public void verifyAssociatedContentLabel() {
		isElementDisplayed("AssociatedLabel");
		scroll(element("AssociatedLabel"));
		logMessage("Associated Project Label is Displayed...");

	}

	public void VerifyAssociatedContentDetailDisplayed() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("AssociatedLabel");
		scroll(element("AssociatedLabel"));
		areElementsDisplayed("thumbnail");
		List<WebElement> thumbnail = elements("thumbnail");
		System.out.println(thumbnail.size());
		for (int i = 0; i < thumbnail.size(); i++) {
			wait.hardWait(1);
			logMessage("Thumbnail for " + (i + 1) + " Content Is Displayed...");
		}

		isElementDisplayed("ContentDetails", "Title:");
		logMessage("Title:" + element("ContentDetails", "Title:").getAttribute("innerText"));

		isElementDisplayed("ContentDetails", "File Name:");
		logMessage("File Name:" + element("ContentDetails", "File Name:").getAttribute("innerText"));

		isElementDisplayed("ContentDetails", "Content Type:");
		logMessage("Content Type:" + element("ContentDetails", "Content Type:").getAttribute("innerText"));

		isElementDisplayed("ContentDetails", "Last Updated:");
		logMessage("Last Updated:" + element("ContentDetails", "Last Updated:").getAttribute("innerText"));
	}

	public void FilterContent(String Filter) {
		waitForLoaderToDisappear();
		isElementDisplayed("Filter");
		scroll(element("Filter"));
		isElementDisplayed("FilterContent", Filter);
		Select select = new Select(element("AllFilterOptions"));
		click(element("FilterContent", Filter));
		select.selectByVisibleText(Filter);
		logMessage(Filter + " Selected in Filter");
		waitForLoaderToDisappear();
	}

	public void VerifyFrostStatusNotAdded(String ISBN2) {
		isElementDisplayed("FrostStatus", ISBN2 + ".epub");
		String Status = element("FrostStatus", ISBN2 + ".epub").getAttribute("innerText");
		Assert.assertTrue(Status.contains("Not added to Frost"), "[Assertion Failed]:: Status Displayed " + Status);
		logMessage("[Assertion Passed]:: Status Displayed " + Status);
	}

	public void VerifyFrostStatusAdded(String ISBN) {
		isElementDisplayed("FrostStatus", ISBN + "_EPUB.epu...");
		String Status = element("FrostStatus", ISBN + "_EPUB.epu...").getAttribute("innerText");
		Assert.assertTrue(Status.contains("Added to Frost"), "[Assertion Failed]:: Status Displayed " + Status);
		logMessage("[Assertion Passed]:: Status Displayed " + Status);

	}

	public void VerifyFrostStatusAuthoredInFrost(String frostIsbnToEnter) {
		isElementDisplayed("FrostStatus", frostIsbnToEnter + ".epub");
		String Status = element("FrostStatus", frostIsbnToEnter + ".epub").getAttribute("innerText");
		Assert.assertTrue(Status.contains("Authored in Frost"), "[Assertion Failed]:: Status Displayed " + Status);
		logMessage("[Assertion Passed]:: Status Displayed " + Status);

	}

	public void VerifyCommentSection() {
		isElementDisplayed("CommentLabel");
		logMessage("Comments is displayed....");
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		logMessage("comment Section is Displayed...");
	}

	public void VerifyCommentSectionPaneAndPostButton() {
		isElementDisplayed("CommentArea");
		logMessage("comment Section is Displayed...");
		isElementDisplayed("PostButton");
		logMessage("Post Button is Displayed...");

	}

	public void VerifyUserIsAbleToDeleteComment(String Email) {
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		try {
			isElementDisplayed("nondeleteComment", Email);
			click(element("nondeleteComment", Email));
			logMessage("User Is Able to delete Comment");
			Assert.assertTrue(true);
		} catch (java.lang.AssertionError e) {
			logMessage("[Assertion Failed]:: User is not able to delete comment");
			Assert.assertTrue(false);
		}

	}

	public void verifyPaginationBarIsAppering() {
		try {
			areElementsDisplayed("PaginationBar");
			logMessage("PaginationBar Is Appering At the bottom og the Hisory Table");
		} catch (java.lang.AssertionError exc) {
			logMessage(
					"PaginationBar Is not Appering At the bottom of the Hisory Table as all the history information is displayed..");
		}

	}

	public void VerifyBackAndForthNavigationpaginationBar() {
		try {
			areElementsDisplayed("PaginationBar");
		} catch (java.lang.AssertionError exc) {
			logMessage(
					"PaginationBar Is not Appering At thr bottm of the Hisory Table as all the history information is displayed..");
			return;
		}
		isElementDisplayed("navigate", "2");
		click(element("navigate", "2"));
		logMessage("page number 2 clicked... Able To move Forword from pagination Bar");

		isElementDisplayed("navigate", "1");
		click(element("navigate", "1"));
		logMessage("page number 1 clicked... Able To move Backword from pagination Bar");

	}

	public void NavigateToPageNumberInPublishWindow_IS(String PageNo) {
		wait.hardWait(2);
		wait.resetImplicitTimeout(2);
		try {
			isElementDisplayed("navigate", PageNo);
		} catch (java.lang.AssertionError exc) {
			logMessage("PaginationBar Is not Appering At Instructor Store Publish Window");
			wait.resetImplicitTimeout(wait.getTimeout());
			return;
		}

		isElementDisplayed("navigate", PageNo);
		click(element("navigate", PageNo));
		logMessage("page number " + PageNo + " clicked... Able To move Forword from pagination Bar");
		wait.resetImplicitTimeout(wait.getTimeout());
	}

	public void Verify_Clicking_Delete_Opens_PopUp() {
		isElementDisplayed("toplinks", "Delete");
		logMessage("Delete Button Is Displayed...");
		click(element("toplinks", "Delete"));
		logMessage("delete Button Clicked..");
		isElementDisplayed("DeleteLable");
		logMessage("Delete Project PopUp Displayed..");
	}

	public void VerifyDeletebuttonDisabled() {
		isElementDisplayed("confirmDelete");
		String Attri = element("confirmDelete").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Failed]:: Delete Button Is Enabled...");
			Assert.assertTrue(false);
		} else {
			logMessage("[Assertion Passed]:: Delete Button Is Disabled...");
		}

	}

	public void EnterDeleteInTextBox() {
		isElementDisplayed("DeleteInput");
		logMessage("Delete Input box Is Visible");
		fillText("DeleteInput", "delete");
	}

	public void VerifyDeletebuttonEnabled() {
		isElementDisplayed("confirmDelete");
		String Attri = element("confirmDelete").getAttribute("disabled");
		if (Attri == null) {
			logMessage("[Assertion Passed]:: Delete Button Is Enabled...");
		} else {
			logMessage("[Assertion Failed]:: Delete Button Is Disabled...");
			Assert.assertTrue(false);
		}
	}

	public void VerifyPublishDetailsAreDisplayedforEnhancedEPub(String ISBN) {
		areElementsDisplayed("PerticularContentDetail", ISBN + ".epub");
		wait.hardWait(1);
		List<WebElement> Info = elements("PerticularContentDetail", ISBN + ".epub");
		logMessage("Publish Details For The EnhancedEPub");
		for (int detail = 0; detail < Info.size(); detail++) {
			wait.hardWait(1);
			logMessage("Information Displayed::" + Info.get(detail).getAttribute("innerText"));
		}

	}

	public void VerifyEllipsesForFileName(String ISBN) {
		isElementDisplayed("EpubOnPublish", (ISBN + "_EPUB"));
		String FileName = element("EpubOnPublish", (ISBN + "_EPUB")).getAttribute("innerText");
		Assert.assertTrue(FileName.contains("..."), "[Assertion Failed]:: Ellipses are Not Displayed For File Name::"
				+ element("EpubOnPublish", (ISBN + "_EPUB")).getAttribute("innerText"));
		logMessage("[Assertion Passed]:: Ellipses are Displayed For File Name::"
				+ element("EpubOnPublish", (ISBN + "_EPUB")).getAttribute("innerText"));
	}

	public void AddProjectToFavorite() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("FavoriteStatus");
		String FavStatus = element("FavoriteStatus").getAttribute("class");
		if (FavStatus.contains("glyphicon-star-empty")) {
			isElementDisplayed("toplinks", "Favorite");
			click(element("toplinks", "Favorite"));
			logMessage("Favorite link is clicked...");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("FavoriteMSG");
			String Message = element("FavoriteMSG").getAttribute("innerText").trim();
			logMessage("Message Displayed::" + Message);
			Assert.assertTrue(Message.contains("Added to Favorites"),
					"[Assertion Failed]:: Incorrect Message Is Displayed::" + Message);
			logMessage("[Assertion Passed]:: Correct Message Is Displayed::" + Message);
		} else {
			logMessage("Project Is Already Add as Favorite");
		}
	}
	
	public void removeProjectFromFavorite() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("FavoriteStatus");
		String FavStatus = element("FavoriteStatus").getAttribute("class");
		if (FavStatus.contains("glyphicon-star-empty")) {
			logMessage("Project Is Already Marked as Unfavorite");
			
		} else {
			isElementDisplayed("toplinks", "Favorite");
			click(element("toplinks", "Favorite"));
			logMessage("Favorite link is clicked...");
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("FavoriteMSG");
			String Message = element("FavoriteMSG").getAttribute("innerText").trim();
			logMessage("Message Displayed::" + Message);
			Assert.assertTrue(Message.contains("Removed from Favorites"),
					"[Assertion Failed]:: Incorrect Message Is Displayed::" + Message);
			logMessage("[Assertion Passed]:: Correct Message Is Displayed::" + Message);
		}

	}
	
	public void VerifyFavoriteMessageColor() {
		String ColourDisplayed=element("FavoriteMSG").getCssValue("color").trim();
		logMessage("Colour Displayed::"+ColourDisplayed);
		Assert.assertTrue(ColourDisplayed.equals("rgba(60, 118, 61, 1)"));
	}
	
	public void verifyFavoriteToasterMessageAppears_For_5_Seconds() {
		isElementDisplayed("FavoriteMSG");
		wait.hardWait(5);
		Assert.assertTrue(verifyElementNotDisplayed("FavoriteMSG"));
	}

	public void VerifyFavoriteProjectCountIsNotZero() {
		isElementDisplayed("FavProjectCount");
		String text = element("FavProjectCount").getText();
		int CountDisplayed = Integer.parseInt(text.substring(text.indexOf('(') + 1, text.lastIndexOf(')')));
		logMessage("Project Count Displayed::" + CountDisplayed);
		if (CountDisplayed <= 0) {
			Assert.assertTrue(false, "[Assertion Failed]::Project count are Reset to Zero");
		}
	}

	public void VerifyCountOfAssetDisplayedOnAssociationPopUp() {
		wait.hardWait(2);
		areElementsDisplayed("AssetDisplay");
		List<WebElement> count = elements("AssetDisplay");
		logMessage("size==" + count.size());
		if (count.size() == 1) {
			logMessage("[Assertion Passed]:: Only One Instance of the Assert is Present....");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: More than Instance of the Assert is Present....");
		}

	}

	public void VerifyAssetIsNotDisplayedOnAssetAssociationPopUp(String FileName) {
		Assert.assertTrue(verifyElementNotDisplayed("AnAsset", FileName),
				"[Assertion Failed]::" + FileName + " is Displayed..");
		logMessage("[Assertion Passed]::" + FileName + " is not Displayed..");

	}

	public void VerifyHyperLinkDisabledInPushToAuthoringTool() {
		areElementsDisplayed("ContentImg");
		logMessage("Content Image is Displayed....");

		areElementsDisplayed("ContentTitle");
		logMessage("Content Title is Displayed....");

		click(element("ContentImg"));
		logMessage("Content Image Clicked..");
		waitForLoaderToDisappear();
		Assert.assertTrue(verifyElementNotDisplayed("ContentViewLabel"),
				"[Assertion Failed]::Content Image Navigates to Content View");
		logMessage("[Assertion Passed]::Content Image Does Not Navigates to Content View");

		click(element("ContentTitle"));
		logMessage("Content Title Clicked..");
		waitForLoaderToDisappear();
		Assert.assertTrue(verifyElementNotDisplayed("ContentViewLabel"),
				"[Assertion Failed]::Content Image Navigates to Content View");
		logMessage("[Assertion Passed]::Content Title Dows Not Navigates to Content View");

	}

	public void VerifyContentAreDisplayedInPushToAuthoringtool() {
		areElementsDisplayed("ContentShownInPopUp");
		logMessage("Content Are Displayed...");
	}

	public void VerifyStep3LabelOfPushToAuthoringTool() {
		isElementDisplayed("Step3Label");
		String label = element("Step3Label").getAttribute("innerText").trim();
		Assert.assertTrue(label.equalsIgnoreCase("Step 3: Select Project ISBN and / or Push"),
				"[Assertion Failed]:: Incorrect Label Displayed!!! Label Displayed::" + label);
		logMessage("[Assertion Passed]:: Correct Label Displayed!!!  Label Displayed::" + label);

	}

	public void VerifyOneProjectDisplayedOnAddRemoveProject() {
		areElementsDisplayed("ProjectDisplayed");
		if (elements("ProjectDisplayed").size() == 1) {
			logMessage("[Assertion Passed]:: Only One Project Is Displayed...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: More than One Project Is Displayed...");
		}

	}

	public void ClickUpdateContentMetaDataTab() {
		isElementDisplayed("UpdateContentMetaDataTab");
		logMessage("Update Content Metadata Tab Is Displayed...");
		scroll(element("UpdateContentMetaDataTab"));
		wait.waitForPageToLoadCompletely();
		click(element("UpdateContentMetaDataTab"));
		logMessage("Update Content MetaData Tab Clicked...");
	}

	public void ClickManualPublish() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ManualPublishTab");
		logMessage("Manual Publish Tab Is Displayed...");
		click(element("ManualPublishTab"));
		logMessage("Manual Publish Tab Clicked...");

	}

	public void VerifyMetadataButtonsOnCourseware() {
		isElementDisplayed("InstructorOnlyButton");
		logMessage("'Apply Instructor-Only Metadata' Button Is Displayed...");

		isElementDisplayed("StudentOnlyButton");
		logMessage("'Apply Student-Only Metadata' Button Is Displayed...");

		isElementDisplayed("ClearMetaDataButton");
		logMessage("'Apply Access-Level Metadata' Button Is Displayed...");

	}

	public void ClickInstructorOnlyMetadataButton() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("InstructorOnlyButton");
		logMessage("'Apply Instructor-Only Metadata' Button Is Displayed...");
		click(element("InstructorOnlyButton"));
		logMessage("Instructor Only Metadata Button Is Clicked...");
	}

	public void VerifyInstructorOnlyMetadataButtonDisabled() {
		isElementDisplayed("InstructorOnlyButton");
		String CheckAttribute = element("InstructorOnlyButton").getAttribute("disabled");
		if (CheckAttribute != null && CheckAttribute.equals("true")) {
			logMessage("'Instructor Only Metadata' button is Disabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Instructor Only Metadata' button is Enabled..");
		}
	}

	public void VerifyInstructorOnlyMetadataButtonEnabled() {
		isElementDisplayed("InstructorOnlyButton");
		String CheckAttribute = element("InstructorOnlyButton").getAttribute("disabled");
		if (CheckAttribute == null) {
			logMessage("'Instructor Only Metadata' button is Enabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Instructor Only Metadata' button is Disabled..");
		}
	}

	public void VerifyAssertAreAddedToInstructorResource() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ResourceMessage");
		String Message = element("ResourceMessage").getAttribute("innerText");
		assertTrue(Message.contains("asset/s tagged as Instructor Resource"),
				"[Assertion Failed]::Correct Message Not Displayed::" + Message);
		logMessage("[Assertion Passed]::Correct Message Displayed::" + Message);
	}

	public void VerifyAssertAreAddedToStudentResource() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ResourceMessage");
		String Message = element("ResourceMessage").getAttribute("innerText");
		assertTrue(Message.contains("asset/s tagged as Student Resource"),
				"[Assertion Failed]::Correct Message Not Displayed::" + Message);
		logMessage("[Assertion Passed]::Correct Message Displayed::" + Message);
	}

	public void ClickClearAccessLevelMetadata() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ClearMetaDataButton");
		logMessage("'Clear Access Level Metadata' Button Is Displayed...");
		click(element("ClearMetaDataButton"));
		logMessage("Clear Access Level Metadata Button Is Clicked...");
	}

	public void VerifyClearAccessLevelMetadataButtonDisabled() {
		isElementDisplayed("ClearMetaDataButton");
		String CheckAttribute = element("ClearMetaDataButton").getAttribute("disabled");
		if (CheckAttribute != null && CheckAttribute.equals("true")) {
			logMessage("'Clear Access Level Metadata' button is Disabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Clear Access Level Metadata' button is Enabled..");
		}
	}

	public void VerifyClearAccessLevelMetadataButtonEnabled() {
		isElementDisplayed("ClearMetaDataButton");
		String CheckAttribute = element("ClearMetaDataButton").getAttribute("disabled");
		if (CheckAttribute == null) {
			logMessage("'Clear Access Level Metadata' button is Enabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Clear Access Level Metadata' button is Disabled..");
		}
	}

	public void VerifyAssertAreRemovesFromInstructorOrStudentResource() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ResourceMessage");
		String Message = element("ResourceMessage").getAttribute("innerText");
		assertTrue(Message.contains("asset/s cleared from Instructor / student Resource type"),
				"[Assertion Failed]::Correct Message Not Displayed::" + Message);
		logMessage("[Assertion Passed]::Correct Message Displayed::" + Message);

	}

	public void Verify_I_Badge_Is_Dispalyed_On_Assert(String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckBadgeOfAssert", FileName);
		String Badge = element("CheckBadgeOfAssert", FileName).getAttribute("innerText").trim();
		logMessage("Badge Displayed::" + Badge);
		Assert.assertTrue(Badge.equalsIgnoreCase("i"),
				"[Assertion Failed]:: Instructor Badge Not Displayed for " + FileName);
		logMessage("[Assertion Passed]:: Instructor Badge is Displayed for " + FileName);
	}

	public void Verify_I_Badge_Is_Dispalyed_On_Assert_Manual_Publish(String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckBadgeOfAssetManualPublish", FileName);
		String Badge = element("CheckBadgeOfAssetManualPublish", FileName).getAttribute("innerText").trim();
		logMessage("Badge Displayed::" + Badge);
		Assert.assertTrue(Badge.equalsIgnoreCase("i"),
				"[Assertion Failed]:: Instructor Badge Not Displayed for " + FileName);
		logMessage("[Assertion Passed]:: Instructor Badge is Displayed for " + FileName);
	}

	public void Verify_I_Badge_Is_Not_Dispalyed_On_Assert_Manual_Publish(String FileName) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("CheckBadgeOfAssetManualPublish", FileName),
				"[Assertion Failed]:: Instructor Badge Is Displayed for " + FileName);
		logMessage("[Assertion Passed]:: No Badge Displayed for " + FileName);
	}

	public void Verify_I_Badge_Is_Not_Dispalyed_On_Assert(String FileName) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("CheckBadgeOfAssert", FileName),
				"[Assertion Failed]:: Instructor Badge Is Displayed for " + FileName);
		logMessage("[Assertion Passed]:: No Badge Displayed for " + FileName);
	}

	public void ClickStudentOnlyMetadataButton() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("StudentOnlyButton");
		logMessage("'Apply Student-Only Metadata' Button Is Displayed...");
		click(element("StudentOnlyButton"));
		logMessage("Student Only Metadata Button Is Clicked...");
	}

	public void VerifyStudentOnlyMetadataButtonDisabled() {
		isElementDisplayed("StudentOnlyButton");
		String CheckAttribute = element("StudentOnlyButton").getAttribute("disabled");
		if (CheckAttribute != null && CheckAttribute.equals("true")) {
			logMessage("'Student Only Metadata' button is Disabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Student Only Metadata' button is Enabled..");
		}
	}

	public void VerifyStudentOnlyMetadataButtonEnabled() {
		isElementDisplayed("StudentOnlyButton");
		String CheckAttribute = element("StudentOnlyButton").getAttribute("disabled");
		if (CheckAttribute == null) {
			logMessage("'Student Only Metadata' button is Enabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Student Only Metadata' button is Disabled..");
		}
	}

	public void Verify_S_Badge_Is_Dispalyed_On_Assert(String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckBadgeOfAssert", FileName);
		String Badge = element("CheckBadgeOfAssert", FileName).getAttribute("innerText");
		Assert.assertTrue(Badge.equalsIgnoreCase("s"),
				"[Assertion Failed]:: Student Badge Not Displayed for " + FileName);
		logMessage("[Assertion Passed]:: Student Badge is Displayed for " + FileName);

	}

	public void VerifyToolTipDisplayedOnBadge(String FileName, String ToolTip) {
		isElementDisplayed("CheckBadgeOfAssert", FileName);
		hover(element("CheckBadgeOfAssert", FileName));
		isElementDisplayed("ToolTipPopUp", ToolTip);
		logMessage("Tool Tip Displayed::" + ToolTip);
	}

	public void Verify_S_Badge_Is_Dispalyed_On_Assert_ManualPublish(String FileName) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("CheckBadgeOfAssetManualPublish", FileName);
		String Badge = element("CheckBadgeOfAssetManualPublish", FileName).getAttribute("innerText");
		Assert.assertTrue(Badge.equalsIgnoreCase("s"),
				"[Assertion Failed]:: Student Badge Not Displayed for " + FileName);
		logMessage("[Assertion Passed]:: Student Badge is Displayed for " + FileName);

	}

	public void VerifyToolTipDisplayedOnBadgeManualPublish(String FileName, String ToolTip) {
		isElementDisplayed("CheckBadgeOfAssetManualPublish", FileName);
		hover(element("CheckBadgeOfAssetManualPublish", FileName));
		isElementDisplayed("ToolTipPopUp", ToolTip);
		logMessage("Tool Tip Displayed::" + ToolTip);
	}

	public void Verify_S_Badge_Is_Not_Dispalyed_On_Assert_Manual_Publish(String FileName) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("CheckBadgeOfAssetManualPublish", FileName),
				"[Assertion Failed]:: Student Badge Is Displayed for " + FileName);
		logMessage("[Assertion Passed]:: No Badge Displayed for " + FileName);

	}

	public void Verify_S_Badge_Is_Not_Dispalyed_On_Assert(String FileName) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("CheckBadgeOfAssert", FileName),
				"[Assertion Failed]:: Student Badge Is Displayed for " + FileName);
		logMessage("[Assertion Passed]:: No Badge Displayed for " + FileName);

	}

	public void VerifySelectOnlyInstructorOrStudentResourcesMessageIsDisplayed() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ResourceMessageOnManualPublish");
		String Message = element("ResourceMessageOnManualPublish").getAttribute("innerText");
		assertTrue(Message.equals("Please select only Supplementary Content>Instructor / Student Resources"),
				"[Assertion Failed]::Correct Message Not Displayed::" + Message);
		logMessage("[Assertion Passed]::Correct Message Displayed::" + Message);

	}

	public void VerifySelectOnlyInstructorOrStudentResourcesMessageIsNotDisplayed() {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("ResourceMessageOnManualPublish"),
				"[Assertion Failed]::Please select only Supplementary Content>Instructor / Student Resources is Displayed");
		logMessage(
				"Message:: Please select only Supplementary Content>Instructor / Student Resources is not Displayed....");
	}

	public void clickRepositoryOnStep2OfPublishWindow() {
		wait.hardWait(1);
		isElementDisplayed("Step2RepoInput");
		scroll(element("Step2RepoInput"));
		hover(element("Step2RepoInput"));
		wait.waitForPageToLoadCompletely();
		clickUsingJS(element("Step2RepoInput"));
		logMessage("Repository Clicked...");
		wait.hardWait(1);
		scrollToBottom();
	}

	public void VerifyAllTheAssetsAreSelectedToPublishInStep3() {
		scrollToBottom();
		wait.hardWait(1);
		wait.waitForPageToLoadCompletely();
		List<WebElement> pages = elements("NumberOfPages");
		int NoPages = pages.size();
		logMessage("Number of Pages to Traverse::" + NoPages);
		for (int i = 1; i <= NoPages; i++) {
			isElementDisplayed("NavigateOnPublishWindow", i + "");
			click(element("NavigateOnPublishWindow", i + ""));
			logMessage("User Navigated to " + i + " Page");
			wait.waitForPageToLoadCompletely();
			areElementsDisplayed("InputTagsForAssets");
			List<WebElement> Asset = elements("InputTagsForAssets");

			for (int assetCheck = 0; assetCheck < Asset.size(); assetCheck++) {
				wait.hardWait(1);
				String Attribute = Asset.get(assetCheck).getAttribute("class");
				Assert.assertTrue(Attribute.contains("ng-not-empty"), "[Assertion Failed]:: Asset Is Not Checked...");
				logMessage("[Assertion Passed]:: Asset Is Checked...");
			}
		}
	}

	public void VerifyNoTheAssetsAreSelectedToPublishInStep3() {
		scrollToBottom();
		wait.hardWait(1);
		wait.waitForPageToLoadCompletely();
		List<WebElement> pages = elements("NumberOfPages");
		int NoPages = pages.size();
		logMessage("Number of Pages to Traverse::" + NoPages);
		for (int i = 1; i <= NoPages; i++) {
			isElementDisplayed("NavigateOnPublishWindow", i + "");
			click(element("NavigateOnPublishWindow", i + ""));
			logMessage("User Navigated to " + i + " Page");
			wait.waitForPageToLoadCompletely();
			areElementsDisplayed("InputTagsForAssets");
			List<WebElement> Asset = elements("InputTagsForAssets");

			for (int assetCheck = 0; assetCheck < Asset.size(); assetCheck++) {
				String Attribute = Asset.get(assetCheck).getAttribute("class");
				Assert.assertTrue(Attribute.contains("ng-empty"), "[Assertion Failed]:: Asset Is Checked...");
				logMessage("[Assertion Passed]:: Asset Is not Checked...");
			}
		}
	}

	public void ClickPageNumberInStep3OfPublishWindow(int PageNo) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("NavigateOnPublishWindow", PageNo + "");
		click(element("NavigateOnPublishWindow", PageNo + ""));
		logMessage("User Navigated to " + PageNo + " Page");
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyAllTheAssetsAreSelectedForPerticularPageOfPublishWindow() {
		wait.waitForPageToLoadCompletely();
		List<WebElement> Asset = elements("InputTagsForAssets");
		for (int assetCheck = 0; assetCheck < Asset.size(); assetCheck++) {
			String Attribute = Asset.get(assetCheck).getAttribute("class");
			Assert.assertTrue(Attribute.contains("ng-not-empty"), "[Assertion Failed]:: Asset Is Not Checked...");
			logMessage("[Assertion Passed]:: Asset Is Checked...");
		}
	}

	public void SelectMultipleAssertInStep3PublishWindow(int Count) {
		for (int assetCheck = 0; assetCheck < Count; assetCheck++) {
			wait.waitForPageToLoadCompletely();
			isElementDisplayed("SelectAssets", Integer.toString(assetCheck + 1));
			click(element("SelectAssets", Integer.toString(assetCheck + 1)));
			logMessage((assetCheck + 1) + " asset is selected...");

		}
	}

	public void VerifyAllTheAssetsAreNotSelectedForPerticularPageOfPublishWindow() {
		wait.waitForPageToLoadCompletely();
		List<WebElement> Asset = elements("InputTagsForAssets");
		for (int assetCheck = 0; assetCheck < Asset.size(); assetCheck++) {
			String Attribute = Asset.get(assetCheck).getAttribute("class");
			Assert.assertTrue(Attribute.contains("ng-empty"), "[Assertion Failed]:: Asset Is Selected...");
			logMessage("[Assertion Passed]:: Asset Is Not Checked...");
		}
	}

	public void VerifySelectedAssetsAreSelectedForPerticularPageOfPublishWindow(String Count) {

		for (int assetCheck = 0; assetCheck < Integer.parseInt(Count); assetCheck++) {
			wait.hardWait(1);
			isElementDisplayed("SelectAssets", Integer.toString(assetCheck));
			String Attribute = element("SelectAssets", Integer.toString(assetCheck)).getAttribute("class");
			Assert.assertTrue(Attribute.contains("ng-not-empty"), "[Assertion Failed]:: Asset Is Not Checked...");
			logMessage("[Assertion Passed]:: Asset Is Checked...");
		}
	}

	public void VerifyAllTheAssetsAreSelectedInStep3AfterNavigatingToOtherPage() {
		wait.waitForPageToLoadCompletely();
		List<WebElement> pages = elements("NumberOfPages");
		int NoPages = pages.size();
		logMessage("Number of Pages to Traverse::" + NoPages);

		if (NoPages >= 2) {
			ClickPageNumberInStep3OfPublishWindow(1);
			VerifyAllTheAssetsAreSelectedForPerticularPageOfPublishWindow();
			ClickPageNumberInStep3OfPublishWindow(2);
			VerifyAllTheAssetsAreSelectedForPerticularPageOfPublishWindow();
			ClickPageNumberInStep3OfPublishWindow(1);
			VerifyAllTheAssetsAreSelectedForPerticularPageOfPublishWindow();
		} else {
			logMessage("Only single Page is available To Navigate on Step 3 of Publish Window....");
		}
	}

	public void clickLearningObjectives() {
		wait.hardWait(1);
		isElementDisplayed("SubTab", "Learning Objectives");
		clickUsingJS(element("SubTab", "Learning Objectives"));
		logMessage("'Learning Objectives' is clicked....");
	}

	public void AddLearningObjective(String Framework) {
		isElementDisplayed("LOSearchBar");
		fillText("LOSearchBar", Framework);
		isElementDisplayed("suggestionBox");
		logMessage("Suggesation Box is Displayed...");
		wait.hardWait(1);
		isElementDisplayed("SelectFrameWork", Framework);
		logMessage(Framework + " is Displayed...");
		wait.hardWait(1);
		click(element("SelectFrameWork", Framework));
		logMessage(Framework + " is Clicked...");
		isElementDisplayed("LOAddButton");
		waitForLoaderToDisappear();
		click(element("LOAddButton"));
		logMessage("ADD Button Is Clicked...");
	}

	public void VerifyFrameworkAddedMessageDisplayed() {
		isElementDisplayed("LOMessage", "added to the Project");
		logMessage("Correct Message Is Displayed::'Framework added to the Project'");
	}

	public void RemoveFameworkFromProject(String Framework) {
		wait.waitForPageToLoadCompletely();
		if (BoolenIsElementDisplayed("RemoveFrameWork", Framework)) {
			hover(element("RemoveFrameWork", Framework));
			wait.waitForPageToLoadCompletely();
			click(element("RemoveFrameWork", Framework));
			logMessage(Framework + " Is already Added to the Project..");
			logMessage("Delete Button Is Clicked....");
			VerifyFrameworkRemovedMessageDisplayed();
		} else {
			logMessage("");
			logMessage(Framework + " Is Not Added to the Project So Can Not Be Removed..");
		}
	}

	public void RemoveFameworkFromContent(String Framework) {
		wait.hardWait(1);

		if (BoolenIsElementDisplayed("RemoveFrameWork", Framework)) {
			click(element("RemoveFrameWork", Framework));
			logMessage(Framework + " Is already Added to the Content..");
			logMessage("Delete Button Is Clicked....");
		} else {
			logMessage("");
			logMessage(Framework + " Is Not Added to the Content So Can Not Be Removed..");
		}
	}

	public void VerifyFrameWorkIsAddedToTheProject(String Framework) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("RemoveFrameWork", Framework);
		logMessage(Framework + " Is Added to the Project..");
	}

	public void VerifyFrameWorkIsAddedToTheContent(String Framework) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("RemoveFrameWork", Framework);
		logMessage(Framework + " Is Added to the Content..");
	}

	public int GetNumberOfPagesInAssociatedContent() {
		isElementDisplayed("AssociatedLabel");
		scroll(element("AssociatedLabel"));
		if (BoolenIsElementDisplayed("ACNumberOfPages")) {
			String text = element("ACNumberOfPages").getAttribute("innerText").trim();
			logMessage("Number of Pages in Associated Content::" + text.charAt(text.length() - 1));
			return Character.getNumericValue((text.charAt(text.length() - 1)));
		} else {
			return -1;
		}
	}

	public void clickNextOnAssociatedContent() {
		isElementDisplayed("clickNext");
		click(element("clickNext"));
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyFrameWorkIsAddedToAssociatedContent(String Framework) {
		isElementDisplayed("AssociatedLabel");
		scroll(element("AssociatedLabel"));
		int NumberOfPages = GetNumberOfPagesInAssociatedContent();
		int count = 0;
		if (NumberOfPages < 0) {
			NumberOfPages *= -1;
		}
		String contentList[] = new String[NumberOfPages * 6]; // 6 Asset Per Page
		for (int i = 0; i < NumberOfPages - 1; i++) {
			areElementsDisplayed("OpenFilterContent");
			List<WebElement> Contents = elements("OpenFilterContent");
			for (int contentTitle = 0; contentTitle < Contents.size(); contentTitle++) {
				if (isAttribtuePresent(Contents.get(contentTitle), "uib-tooltip")) {
					contentList[count] = Contents.get(contentTitle).getAttribute("uib-tooltip").trim();
				} else {
					contentList[count] = Contents.get(contentTitle).getAttribute("innerText").trim();
				}
				count++;
			}
			clickNextOnAssociatedContent();
		}
		for (int i = 0; i < contentList.length; i++) {
			if (contentList[i] == null) {
				return;
			}
			HomePageAction homepage = new HomePageAction(driver);
			ContentPageAction ContentPage = new ContentPageAction(driver);
			ContentViewAction ContentView = new ContentViewAction(driver);
			homepage.ClickContentTab();
			ContentPage.SearchForAnItem(contentList[i]);
			ContentPage.opentheSearchContent(contentList[i]);
			ContentView.VerifyOnContentViewPage();
			waitForLoaderToDisappear();
			clickLearningObjectives();
			waitForLoaderToDisappear();
			ContentView.RemoveAllLOS_ForContent();
			VerifyFrameWorkIsAddedToTheContent(Framework);// For content In
															// Content View
			ContentView.RemoveAllLOS_ForContent();
			ContentView.RemoveFameworkFromContentWithoutMessage(Framework);// For
																			// content
																			// In
																			// Content
																			// View
			ContentView.VerifyMessageDispalyedOnRemovingFamework();
		}
	}

	public void VerifyFrameworkRemovedMessageDisplayed() {
		isElementDisplayed("LOMessage", "Framework removed from the Project");
		logMessage("Correct Message Is Displayed::'Framework removed from the Project '");

	}

	public void VerifyFrameworkRemovedMessageDisplayedForContent() {
		isElementDisplayed("ContentLoMsg", "Framework removed from the Content");
		logMessage("Correct Message Is Displayed::'Framework removed from the Content'");

	}

	public void verifyFrameworkIsNotAddedToProjectView(String Framework) {
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("RemoveFrameWork", Framework),
				"[Assertion Failed]::Framework '" + Framework + "' Is Added To ProjectView");
		logMessage("Framework '" + Framework + "' Is Not Added To ProjectView");
	}

	public void ChangeProjectStatusAndVerifyOnTheDashboard(String ISBN) {
		verifyOnProjectView();
		isElementDisplayed("GetWorkFlowStatus");
		String WorkFlowStatus = element("GetWorkFlowStatus").getAttribute("innerText").trim();
		String CurrentWorkFlowStatus;
		if (WorkFlowStatus.equalsIgnoreCase("Enhanced ePub in QA")) {
			Click_Ready_For_Enhancements();
			CurrentWorkFlowStatus = "Ready For Enhancements";
		} else {
			click_Enhanced_ePub_in_QA();
			CurrentWorkFlowStatus = "Enhanced ePub in QA";
		}

		wait.waitForPageToLoadCompletely();
		HomePageAction homepage = new HomePageAction(driver);
		homepage.ClickDashBord();
		homepage.DashBordIsDisplayed();

		isElementDisplayed("ProjectStatusOnDashBord", ISBN);
		String WorkFlowStatusOnDashBoard;
		WorkFlowStatusOnDashBoard = element("ProjectStatusOnDashBord", ISBN).getAttribute("innerText").trim();
		logMessage("WorkFlow Status on DashBoard::" + WorkFlowStatusOnDashBoard);
		logMessage("    WorkFlow Status Expected::" + CurrentWorkFlowStatus);
		Assert.assertTrue(WorkFlowStatusOnDashBoard.equalsIgnoreCase(CurrentWorkFlowStatus),
				"[Assertion Failed]:: Incorrect WorkFlowStatus is displayed on DashBoard");
		logMessage("[Assertion Passed]:: Correct WorkFlowStatus is displayed on DashBoard");
	}

	public void VerifyLearningObjectiveTabDisplayed() {
		isElementDisplayed("SubTab", "Learning Objectives");
		logMessage("Learning Objective tab is displayed...");

	}

	public void VerifySearchBoxDisplayedForLO() {
		isElementDisplayed("LOSearchBar");
		logMessage("Search Box for Learning Objective is Displayed...");

	}

	public void VerifyLOS_IsNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("LOSsearchBar"),
				"[Assertion Failed]::Learning Objective Statements is Displayed");
		logMessage("Learning Objective Statements is Not Displayed...");

	}

	public void VerifyFrameWorkTableIsDisplayed() {
		isElementDisplayed("LOtable");
		logMessage("Framework table is displayed..");

	}

	public void VerifyFrameworkHeaderIsDisplayed() {
		areElementsDisplayed("LOTableHearder", "Framework Name");
		logMessage("'Framework Name' is Displayed..");

		areElementsDisplayed("LOTableHearder", "Action");
		logMessage("'Action' is Displayed..");
	}

	public void EnterTextIntoLOF_SearchBox(String Text) {
		isElementDisplayed("LOSearchBar");
		fillText("LOSearchBar", Text);
	}

	public void ClickCrossIconOnLOF_SearchBox() {
		isElementDisplayed("LOSearchBar");
		String text = element("LOSearchBar").getAttribute("value");
		logMessage("Text Displayed Before Clickcing 'X' icon::" + text);

		isElementDisplayed("Xicon");
		click(element("Xicon"));
		logMessage("'X' icon is Clicked...");
		wait.hardWait(1);
		text = element("LOSearchBar").getAttribute("value");
		logMessage("Text Displayed After Clickcing 'X' icon::" + text);
		if (text.equals("")) {
			logMessage("[Assertion Passed]:: the Text Box is Cleared...");

		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: The Text Box is not Cleared...");
		}
	}

	public void VerifyLOF_AddButtonDisabled() {
		String Attribute = element("LOAddButton").getAttribute("disabled");
		logMessage("Disable" + Attribute);
		if (Attribute.equals("true")) {
			logMessage("[Assertion Passed]:: ADD Button Is Disabled..");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: ADD Button Is Enabled..");
		}

	}

	public void ClickAddButtonOnLOF() {
		isElementDisplayed("LOAddButton");
		hoverOverElement(element("LOAddButton"));
		click(element("LOAddButton"));
		logMessage("Add Button Clicked");
	}

	public void VerifyLOF_AddButtonEnable() {
		wait.hardWait(1);
		String Attribute = element("LOAddButton").getAttribute("disabled");
		if (Attribute == null) {
			Assert.assertTrue(true, "[Assertion Passed]:: ADD Button Is Enabled..");

		} else {
			logMessage("[Assertion Failed]:: ADD Button Is Disabled..");
			Assert.assertTrue(false);
		}
	}

	public void VerifySuggesationBoxDisplayedIn_LOF_Section() {
		isElementDisplayed("suggestionBox");
		logMessage("Suggesation Box is Displayed...");
		wait.hardWait(1);
	}

	public void Verify_Count_Of_Framework_Displayed_In_SuggestionBox(String ExpectedCount) {
		areElementsDisplayed("SuggestionFrameWork");
		List<WebElement> ListFramework = elements("SuggestionFrameWork");
		logMessage("Expected  Count of FrameWork on Suggestion Box::" + ExpectedCount);
		logMessage("Displayed Count of FrameWork on Suggestion Box::" + ListFramework.size());
		Assert.assertEquals(ExpectedCount, ListFramework.size(),
				"[Assertion Failed]:: Incorrect Count of Framework Displayed");
	}

	public void SelectTheFrameWorkFromSuggestionBox(String Framework) {
		isElementDisplayed("LOSearchBar");
		fillText("LOSearchBar", Framework);
		isElementDisplayed("suggestionBox");
		logMessage("Suggesation Box is Displayed...");
		wait.hardWait(1);
		isElementDisplayed("SelectFrameWork", Framework);
		logMessage(Framework + " is Displayed...");
		wait.hardWait(1);
		click(element("SelectFrameWork", Framework));
		logMessage(Framework + " is Clicked...");
	}

	public void VerifyAllTheAssetsAreDeselctedToPublishInStep3() {
		scrollToBottom();
		wait.hardWait(1);
		areElementsDisplayed("NumberOfPages");
		List<WebElement> pages = elements("NumberOfPages");
		int NoPages = pages.size();
		logMessage("Number of Pages to Traverse::" + NoPages);
		for (int i = 1; i <= NoPages; i++) {
			isElementDisplayed("NavigateOnPublishWindow", i + "");
			click(element("NavigateOnPublishWindow", i + ""));
			logMessage("User Navigated to " + i + " Page");
			wait.waitForPageToLoadCompletely();
			List<WebElement> Asset = elements("InputTagsForAssets");

			for (int assetCheck = 0; assetCheck < Asset.size(); assetCheck++) {
				String Attribute = Asset.get(assetCheck).getAttribute("class");
				Assert.assertTrue(Attribute.contains("ng-empty"), "[Assertion Failed]:: Asset Is Checked...");
				logMessage("[Assertion Passed]:: Asset Is Not Checked...");
			}
		}
	}

	public void VerifyStatusOfContentsInStep3OfPublishWindow() {
		ClickPageSelectionDropDown();
		SelectPagesInStep3PublishWindow(getData("PageSelection.All Pages"));
		ClickApproveButtonOnPublishPopUp();
		int i = 0;
		ClickPageNumberInStep3OfPublishWindow(1);
		ClickPageSelectionDropDown();
		SelectPagesInStep3PublishWindow(getData("PageSelection.None")); // UnSelect
																		// All
																		// the
																		// assert.
		SelectMultipleAssertInStep3PublishWindow(2);
		ClickUnApproveButtonOnPublishPopUp();

		i = 0;
		int index = 0;
		String NewStatus[] = new String[6];
		while (i < 2) {
			List<WebElement> Asset = elements("InputTagsForAssets");
			for (int assetStatus = 0; assetStatus < Asset.size(); assetStatus++) {
				NewStatus[index] = element("StatusOfContent", Integer.toString(assetStatus + 1))
						.getAttribute("innerText");
				index++;
			}
			ClickPageNumberInStep3OfPublishWindow(2);
			i++;
		}

		ClickPageNumberInStep3OfPublishWindow(1);
		for (int j = 0; j < 2; j++) {
			if (NewStatus[j].trim().equals("Not Approved")) {
				logMessage((j + 1) + " Asset is Not Approved..");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]:: Asset is Approved..");
			}
		}

		for (int j = 2; j < NewStatus.length - 1; j++) {
			if (NewStatus[j].trim().equals("Approved")) {
				logMessage((j + 1) + " Asset is Approved..");
			} else {
				Assert.assertTrue(false, "[Assertion Failed]:: Asset is not Approved..");
			}
		}
	}

	public void RemoveAllFrameWorkFromProject() {
		waitForPageToLoadCompletely(getPageTitle());
		List<WebElement> DeleteButtons = elements("RemoveAllFrameWork");
		int size = DeleteButtons.size();
		if (size == 0) {
			logMessage("There are No Framework Added...");
		}

		else {
			logMessage("Number of FrameWork displayed::" + size);
			for (int i = 0; i < size; i++) {
				wait.hardWait(1);
				isElementDisplayed("DeleteFrameWorkButton");
				click(element("DeleteFrameWorkButton"));
				logMessage("Delete Button Clicked...");
				VerifyFrameworkRemovedMessageDisplayed();
			}
		}
	}

	public void VerifyNoDublicateFrameworkIsDisplayed() {
		waitForPageToLoadCompletely(getPageTitle());
		List<WebElement> Framework = elements("ListOfFrameWork");
		String FrameWorkDisplayed[] = new String[Framework.size()];
		for (int frame = 0; frame < Framework.size(); frame++) {
			FrameWorkDisplayed[frame] = Framework.get(frame).getAttribute("innerText").trim();
		}

		HashSet<String> set = new HashSet<String>();
		for (String arrayElement : FrameWorkDisplayed) {
			if (!set.add(arrayElement)) {
				Assert.assertTrue(false, "Duplicate FrameWork Displayed is : " + arrayElement);
			}
		}
		logMessage("No Dublicate FrameWork is Displayed");
	}

	public void verifyPaginationBarOnPushToAuthoringTool(int AssetCount) {
		if (AssetCount > 4) {
			isElementDisplayed("PaginationBarInPopup");
			logMessage("PaginationBar is Displayed...");
		} else {
			logMessage("PaginationBar is Displayed not Displayed as assets shown are only::" + AssetCount);
		}

	}

	public int GetAssetCountOnProjectViewForFlatAndEnhancedEpub() {
		String firstSelection = getData("TypesOfContent.Enhanced ePub > Full Package");
		String SecongSelection = getData("TypesOfContent.Flat ePub > Full Package");
		click(element("FilterContent", firstSelection));
		Select select = new Select(element("AllFilterOptions"));
		select.selectByVisibleText(firstSelection);
		select.selectByVisibleText(SecongSelection);
		select.deselectByVisibleText(getData("Show_All"));
		wait.hardWait(2);
		List<WebElement> Contents = elements("OpenFilterContent");
		int size = Contents.size();
		return size;
	}

	public void VerifyEpubsOnlyRadioSelectedOnPushToAuthoringTool() {
		if (element("EpubRadio").isSelected()) {
			logMessage("Epubs Only Selected On Push To Authoring Tool");
		} else {
			Assert.assertTrue(false, "Epubs Only is not Selected On Push To Authoring Tool");
		}
	}

	public void VerifyLabelsForContentsOnPushToAuthoringTool() {
		areElementsDisplayed("LabelsOfContent");
		List<WebElement> contents = elements("LabelsOfContent");
		for (int i = 0; i < contents.size(); i++) {
			if (contents.get(i).getAttribute("innerText").trim().equalsIgnoreCase("ENHANCED")
					|| contents.get(i).getAttribute("innerText").trim().equalsIgnoreCase("FLAT")) {
				logMessage("Label Displayed::" + contents.get(i).getAttribute("innerText"));
			} else {
				Assert.assertTrue(false, "Label Displayed::" + contents.get(i).getAttribute("innerText"));
			}
		}
	}

	public void VerifyTimeStampsForPublishedFlatEpubIsSame(String PublishPlatfrom, String ISBN) {
		String ProjectViewTimeStamps = GetPublishDateFromProjectView(PublishPlatfrom).trim();
		ClickOpenAssetOnProjectView(ISBN + "_EPUB.epub", getData("TypesOfContent.Flat ePub > Full Package"));
		String ContentViewTimeStamps = GetPublishDateFromContentView(PublishPlatfrom).trim();
		logMessage("Publish TimeStap on Project view::" + ProjectViewTimeStamps);
		logMessage("Publish TimeStap on Content view::" + ContentViewTimeStamps);
		Assert.assertTrue(ContentViewTimeStamps.equalsIgnoreCase(ProjectViewTimeStamps),
				"[Assertion Failed]:: Difference in TimeStamp for Publish Asset....");

	}

	public void VerifyTimeStampsForPublishedContentIsSame(String PublishPlatfrom, String Content) {
		String ProjectViewTimeStamps = GetPublishDateFromProjectView(PublishPlatfrom).trim();
		refreshPage();
		waitForLoaderToDisappear();
		ClickOpenAssetOnProjectView(Content, getData("TypesOfContent.Supplementary Content>Instructor Resources"));
		String ContentViewTimeStamps = GetPublishDateFromContentView(PublishPlatfrom).trim();
		logMessage("Publish TimeStap on Project view::" + ProjectViewTimeStamps);
		logMessage("Publish TimeStap on Content view::" + ContentViewTimeStamps);
		Assert.assertTrue(ContentViewTimeStamps.equalsIgnoreCase(ProjectViewTimeStamps),
				"[Assertion Failed]:: Difference in TimeStamp for Publish Asset....");

	}

	private String GetPublishDateFromContentView(String publishPlatfrom) {
		wait.hardWait(1);
		ContentViewAction ContentView = new ContentViewAction(driver);
		ContentView.VerifyOnContentViewPage();
		ContentView.ClickPublishDetail();
		isElementDisplayed("label");
		String platform = element("DestPublish").getAttribute("innerText");
		if (platform.trim().equalsIgnoreCase(publishPlatfrom)) {
			isElementDisplayed("GetPublishDtaeContentView");
			return element("GetPublishDtaeContentView").getAttribute("innerText");
		}
		return null;
	}

	private String GetPublishDateFromProjectView(String publishPlatfrom) {
		wait.hardWait(6);
		ClickPublishDetail();
		isElementDisplayed("label");
		verifyOnProjectView();
		String platform = element("DestPublish").getAttribute("innerText").trim();
		if (platform.trim().equalsIgnoreCase(publishPlatfrom)) {
			logMessage("Correct Publish Platform is Displayed::" + publishPlatfrom);
			isElementDisplayed("GetPublishDate");
			return element("GetPublishDate").getAttribute("innerText").trim();
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Publish platform" + publishPlatfrom
					+ " is not Displayed in Publish Detail...");
			return null;
		}
	}

	public void VerifyContentTypeInAssociatedContent(String ContentTypeToVerify) {
		isElementDisplayed("ContentDetails", "Content Type:");
		if (isAttribtuePresent(element("ContentDetails", "Content Type:"), "uib-tooltip"))// if text length is greater
																							// that 21 ubi-tooltip is
																							// used to extract Text
		{

			String Type = element("ContentDetails", "Content Type:").getAttribute("uib-tooltip");
			Assert.assertTrue(Type.equalsIgnoreCase(ContentTypeToVerify),
					"[Assertion Failed]:: Incorrect Content Type Displayed:" + Type);
			logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeToVerify);
		}

		else {
			String Type = element("ContentDetails", "Content Type:").getAttribute("innerText");
			Assert.assertTrue(Type.equalsIgnoreCase(ContentTypeToVerify),
					"[Assertion Failed]:: Incorrect Content Type Displayed:" + Type);
			logMessage("[Assertion Passed]:: Correct Content Type Displayed:" + ContentTypeToVerify);
		}
	}

	public void VerifyContentTypeDisplayedInStep3PublishWindow(String typesOfContent) {
		isElementDisplayed("Step3ContentType");
		String TypeDisplayed = element("Step3ContentType").getAttribute("innerText").trim();
		logMessage("Content Type Expected::" + typesOfContent);
		Assert.assertTrue(typesOfContent.equalsIgnoreCase(TypeDisplayed),
				"[Assertion Failed]:: Incorrect Content Type is Displayed::" + TypeDisplayed);
		logMessage("[Assertion Passed]:: Correct Content Type is Displayed::" + TypeDisplayed);
	}

	public void ClickCloseOnpublishPopup() {
		isElementDisplayed("xButton");
		scroll(element("xButton"));
		hover(element("xButton"));
		wait.waitForPageToLoadCompletely();
		click(element("xButton"));
		logMessage("x icon Clicked...");
		wait.waitForPageToLoadCompletely();
	}

	public void ClickCloseButton() {
		isElementDisplayed("xButton");
		wait.waitForPageToLoadCompletely();
		scroll(element("xButton"));
		hover(element("xButton"));
		wait.waitForPageToLoadCompletely();
		click(element("xButton"));
		logMessage("x icon Clicked...");
	}

	public void VerifyUserNotAbleToEditCommentWithoutClickingEditIcon(String Email) {
		scrollToBottom();
		isElementDisplayed("TextAreaForComment", Email);
		click(element("TextAreaForComment", Email));

		String Attri = element("TextAreaForComment", Email).getAttribute("disabled");
		if (Attri.equals("true")) {
			logMessage("[Assertion Passed]:: Text Area is disabled user can not edit the comment..");
		} else {
			logMessage("[Assertion Failed]:: Text Area is Enabled user can Edit the comment..");
			Assert.assertTrue(false);
		}

		isElementDisplayed("editComment", Email);
		click(element("editComment", Email));
		logMessage("Edit Button is clicked....");

		String Attri1 = element("TextAreaForComment", Email).getAttribute("disabled");
		if (Attri1 == null) {
			logMessage("[Assertion Passed]:: Text Area is Enabled user is able To edit the comment..");
		} else {
			logMessage("[Assertion Failed]:: Text Area is Disabled user can not Edit the comment..");
			Assert.assertTrue(false);
		}
	}

	public void VerifyUserIsAbleToEditComment(String Email) throws IOException {
		isElementDisplayed("CommentArea");
		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		isElementDisplayed("editComment", Email);
		click(element("editComment", Email));
		logMessage("User Is Able to edit Comment");
		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();
		Random r = new Random();

		String CommentNo = PropFileHandler.readPropertyFromDataFile("CommentNoforProject");
		String Comment = "Test Comment Edit from Automated Script " + CommentNo + alphabet.charAt(r.nextInt(N));

		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		fillText(element("TextAreaForComment", Email), Comment);
		logMessage("Edited Comment Posted::" + Comment);
		isElementDisplayed("postEditedComment", Email);
		click(element("postEditedComment", Email));
		logMessage(" post Edited Comment Button clicked");
		CommentNo = Integer.toString(Integer.parseInt(CommentNo) + 1);
		PropFileHandler.writePropertyToDataFile("CommentNoforProject", CommentNo);
		wait.hardWait(1);
		refreshPage();
		waitForLoaderToDisappear();
		scrollToBottom();
		isElementDisplayed("VerifyComment", Comment);
		scroll(element("VerifyComment", Comment));
		wait.hardWait(2);
		logMessage("Follwoing comment is displayed::" + Comment);
	}

	public void VerifyClickingOutsideChangesAreNotSaved(String Email) {
		isElementDisplayed("editComment", Email);
		click(element("editComment", Email));
		logMessage("Edit Button is clicked....");

		String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		int N = alphabet.length();
		Random r = new Random();

		String CommentNo = PropFileHandler.readPropertyFromDataFile("CommentNoforContent");
		String Comment = "Test Comment Edit from Automated Script " + CommentNo + alphabet.charAt(r.nextInt(N));

		scroll(element("CommentArea"));
		click(element("CommentArea"));
		scrollToBottom();
		fillText("CommentArea", Comment);

		click(element("CommentLabel")); // Click out side the Comment
										// Box..

		isElementDisplayed("postEditedComment", Email);

		String Attri1 = element("TextAreaForComment", Email).getAttribute("disabled");
		if (Attri1 == null) {
			logMessage("[Assertion Passed]:: Text Area is Enabled user is able To edit the comment..");
		} else {
			logMessage("[Assertion Failed]:: Text Area is Disabled Clicking Out Side the Window Saves the comment..");
			Assert.assertTrue(false);
		}
	}

	public void VerifyContentDisplayedInAssociatedContent(String ContentName) {
		isElementDisplayed("openContent", ContentName);
		logMessage("'" + ContentName + "' is Displayed on Associated Content...");

	}

	public void VerifyISBN_DisplayedIn_IS_Publish(String ISBN) {
		isElementDisplayed("VerifyISBN_In_IS", ISBN);
		logMessage(ISBN + " ISBN Is Displayed..");
	}

	public void VerifyISBN_NotDisplayedIn_IS_Publish(String ISBN) {
		wait.hardWait(2);
		wait.waitForPageToLoadCompletely();
		Assert.assertTrue(verifyElementNotDisplayed("VerifyISBN_In_IS", ISBN),
				"[Assertion Failed]::ISBN::" + ISBN + " Is Displayed..");
		logMessage("ISBN::" + ISBN + " Is Not Displayed..");

	}

	public void VerifyAllDeleteButtonsIn_IS_Publish() {
		areElementsDisplayed("VerifyAllDeleteButton_IS");
		logMessage("Delete button for All the ISBN Are Displayed..");

	}

	public void SearchForISBNIn_IS_Publish_Window(String ISBN) {
		isElementDisplayed("IS_SearchBar");
		fillText("IS_SearchBar", ISBN);
		wait.hardWait(1);
		element("IS_SearchBar").sendKeys(Keys.BACK_SPACE);
	}

	public void EnterISBNIn_IS_Publish_Window(String ISBN) {
		isElementDisplayed("IS_SearchBar");
		fillText("IS_SearchBar", ISBN);
	}

	public void CopyPaste_ISBNIn_IS_Publish_Window(String ISBN) {
		isElementDisplayed("IS_SearchBar");
		fillText("IS_SearchBar", ISBN);
		element("IS_SearchBar").sendKeys(Keys.chord(Keys.CONTROL, "a"));
		element("IS_SearchBar").sendKeys(Keys.chord(Keys.CONTROL, "x"));
		element("IS_SearchBar").sendKeys(Keys.chord(Keys.CONTROL, "v"));
		wait.waitForPageToLoadCompletely();
	}

	public void VerifySingleResultDisplayedOn_IS_AutoSuggestion() {
		areElementsDisplayed("IS_ListOfISBN");
		logMessage("Number of Result Displayed::" + elements("IS_ListOfISBN").size());
		Assert.assertTrue(elements("IS_ListOfISBN").size() == 1,
				"[Assertion Failed]:: The Single Result on AutoSuggestion Not Displayed");
	}

	public void VerifySuggesationBoxDisplayedInPublishWindowFor_IS() {
		isElementDisplayed("IS_SuggesationBox");
	}

	public void SelectISBNFromSuggestaionBoxInPublishWindow_IS(String ISBN) {
		isElementDisplayed("IS_SelectISBN", ISBN);
		hoverOverElement(element("IS_SelectISBN", ISBN));
		wait.hardWait(1);
		click(element("IS_SelectISBN", ISBN));
		logMessage(ISBN + " Selected from Suggesation Box..");
	}

	// Check List is getting filtered out on Adding Characters
	public void VerifyAutosuggestionListIsFilteredOutOnAdding(String ISBN) {
		for (int loop = 0; loop < ISBN.length(); loop++) {
			char character;
			character = ISBN.charAt(loop);
			isElementDisplayed("IS_SearchBar");
			element("IS_SearchBar").sendKeys(character + "");
			logMessage(character + " Entered into Search Bar.");
			VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
			areElementsDisplayed("IS_ListOfISBN");
			wait.waitForPageToLoadCompletely();
			List<WebElement> ListOfISBN = elements("IS_ListOfISBN");
			for (int ISBNDisplayed = 0; ISBNDisplayed < ListOfISBN.size(); ISBNDisplayed++) {
				logMessage("Filtered ISBN Displayed::" + ListOfISBN.get(ISBNDisplayed).getText().trim());
				Assert.assertTrue(ListOfISBN.get(ISBNDisplayed).getText().trim().contains(ISBN.substring(0, loop)),
						"[Assertion Failed]::" + ISBN.substring(0, loop) + " is Not Present in "
								+ ListOfISBN.get(ISBNDisplayed).getText().trim());
			}
		}
	}

	// Check List is getting filtered out on Deleting Characters
	public void VerifyAutosuggestionListIsFilteredOutOnDeleting(String ISBN) {
		element("IS_SearchBar").clear();
		element("IS_SearchBar").sendKeys(ISBN);

		for (int loop = ISBN.length(); loop > 1; loop--) {
			isElementDisplayed("IS_SearchBar");
			element("IS_SearchBar").sendKeys(Keys.BACK_SPACE);
			VerifySuggesationBoxDisplayedInPublishWindowFor_IS();
			areElementsDisplayed("IS_ListOfISBN");
			wait.waitForPageToLoadCompletely();
			List<WebElement> ListOfISBN = elements("IS_ListOfISBN");
			for (int ISBNDisplayed = 0; ISBNDisplayed < ListOfISBN.size(); ISBNDisplayed++) {
				logMessage("Filtered ISBN Displayed::" + ListOfISBN.get(ISBNDisplayed).getText().trim());
				Assert.assertTrue(ListOfISBN.get(ISBNDisplayed).getText().trim().contains(ISBN.substring(0, loop - 1)),
						"[Assertion Failed]::" + ISBN.substring(0, loop) + " is Not Present in "
								+ ListOfISBN.get(ISBNDisplayed).getText().trim());
			}
		}
	}

	public void ClickADDButton_IS() {
		isElementDisplayed("IS_ADDButton");
		wait.waitForPageToLoadCompletely();
		click(element("IS_ADDButton"));
		logMessage("ADD Button Clicked..");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyInCorrectISBNMessageOn_IS(String ISBN) {
		isElementDisplayed("IS_IncorrectISBN");
		String Expected = "No results found for " + ISBN;
		String Message = element("IS_IncorrectISBN").getText().trim().replaceAll("\\r\\n|\\r|\\n", " ");
		logMessage("Message Expected ::" + Expected);
		logMessage("Message Displayed::" + Message);
		Assert.assertTrue(Message.equals(Expected), "[Assertion Failed]::Incorrect Message Displayed::" + Message);
	}

	public void DeleteISBN_From_IS_PublishWindow(String ISBN) {
		isElementDisplayed("DeleteISBN_In_IS", ISBN);
		hoverOverElement(element("DeleteISBN_In_IS", ISBN));
		wait.hardWait(1);
		waitAndClick("DeleteISBN_In_IS", ISBN);
		logMessage(ISBN + " Deleted From Instructor Store Publish Window..");
		waitForLoaderToDisappear();
	}

	public void DeleteAllISBN_IS_PublishWindow() {
		int count = -1;
		wait.waitForPageToLoadCompletely();
		List<WebElement> deleteButton = elements("VerifyAllDeleteButton_IS");
		count = deleteButton.size();
		if (count > 0) {
			for (int i = 0; i < count; i++) {
				hoverOverElement(deleteButton.get(i));
				wait.hardWait(1);
				deleteButton.get(i).click();
				logMessage("'Delete Button Clicked'");
			}
		} else {
			logMessage("All the ISBN Are Removed.");
		}
	}

	public void VerifyErrorMessageOnBottomOfPublishWindow(String ExpectedMsg) {
		isElementDisplayed("PublishBottomMsg");
		String Message = element("PublishBottomMsg").getAttribute("innerText");
		logMessage("Message Expected::" + ExpectedMsg);
		logMessage("Message Displayed::" + Message);
		Assert.assertTrue(ExpectedMsg.equals(Message), "[Assertion Failed]:: Incorrect Message Displayed::" + Message);
		logMessage("[Assertion Passed]:: Correct Message Displayed::" + Message);

	}

	public void Verify_PublishedProjectISBN_LinkIsDisplayed() {
		isElementDisplayed("PublishedProjectISBN_Link");
		logMessage("'Published Project ISBNs' Link is Displayed...");
	}

	public void ClickPublishedProjectISBN_OnPublishDetail() {
		isElementDisplayed("PublishedProjectISBN_Link");
		hoverOverElement(element("PublishedProjectISBN_Link"));
		wait.waitForPageToLoadCompletely();
		clickUsingJavaScript("PublishedProjectISBN_Link");
		logMessage("'Published Project ISBNs' Clicked..");
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
	}

	public void VerifyPublishedProjectISBN_PopUpDisplayed() {
		wait.hardWait(1);
		isElementDisplayed("PublishedProjectLabel");
		logMessage("Published Project ISBN(s) Pop Up is Displayed..");
	}

	public void VerifyFilesLinkDisplayedInPublishDetail() {
		isElementDisplayed("Files");
		logMessage("'Files' Link Dsplayed in publish Detail.");
	}

	public void clickFilesLinkInPublishDetail() {
		isElementDisplayed("Files");
		hoverOverElement(element("Files"));
		wait.hardWait(1);
		click(element("Files"));
		logMessage("'Files' Link Clicked on publish Detail...");
	}

	public void VerifyPaginationBarNotDisplayedOnPublishFilePopup() {
		Assert.assertTrue(verifyElementNotDisplayed("PublishedFilepagination"),
				"[Assertion Failed]:: Pagination Bar Displayed on Popup");
	}

	public void VerifyPaginationBarIsDisplayedOnPublishFilePopup() {
		areElementsDisplayed("PublishedFilepagination");
		logMessage("PaginationBar is Displayed on Publish File Popup");
	}

	public void VerifyPublishFilePopUpDisplayed() {
		isElementDisplayed("PublishFilePopUp");
		logMessage("Publish File Pop Up is Displayed...");
	}

	public void VerifyAssetTiltePublishedInPublishDetail(String AssetTitle) {
		isElementDisplayed("VerifyAssetTitlePublished", AssetTitle);
		logMessage("'" + AssetTitle + "' Is Published..");
	}

	public void VerifyFileNamePublishedInPublishDetail(String FileName) {
		isElementDisplayed("VerifyFileNamePublished", FileName);
		logMessage("'" + FileName + "' Is Published..");
	}

	public void VerifyVisibilityOfAssetOnPublishedFileDetailPopup(String AssetTitle, String Visibility) {
		isElementDisplayed("CheckVisiblilityOfAsset", AssetTitle, Visibility);
		logMessage("Visibility for Asset '" + AssetTitle + "' is " + Visibility);
	}

	public void VerifyCountOfFileDisplayedOnPublishedFile(int count) {
		areElementsDisplayed("VerifyCountOfFiles");
		logMessage("Count of Files Expected::" + count);
		logMessage("Count of Files Displayed::" + elements("VerifyCountOfFiles").size());
		if (elements("VerifyCountOfFiles").size() != count) {
			Assert.assertTrue(false, "[Assertion Failed]:: Incorrect Count of Files Displayed..");
		}
	}

	public void VerifyISBNDisplayedInPublishProjectPopUp(String ExpectedISBN) {
		areElementsDisplayed("PublishedISBN");
		List<WebElement> ISBNs = elements("PublishedISBN");
		for (int i = 0; i < ISBNs.size(); i++) {
			String ISBN = ISBNs.get(i).getAttribute("innerText").trim();
			if (ISBN.equals(ExpectedISBN)) {
				logMessage("[Assertion Passed]:: " + ExpectedISBN + " Is Displayed..");
				return;
			}
		}
		Assert.assertTrue(false, "[Assertion Failed]:: " + ExpectedISBN + " Is Not Displayed..");
	}

	public void VerifyISBNDisplayedInPublishProjectPopUpFavourableTime(String ExpectedISBN) {
		try {
			wait.resetImplicitTimeout(1);
			areElementsDisplayed("PublishedISBN");
			List<WebElement> ISBNs = elements("PublishedISBN");
			for (int i = 0; i < ISBNs.size(); i++) {
				String ISBN = ISBNs.get(i).getAttribute("innerText").trim();
				if (ISBN.equals(ExpectedISBN)) {
					logMessage("[Assertion Passed]:: " + ExpectedISBN + " Is Displayed..");
					return;
				}
			}
			wait.resetImplicitTimeout(wait.timeout);
			Assert.assertTrue(false, "[Assertion Failed]:: " + ExpectedISBN + " Is Not Displayed..");
		} catch (java.lang.AssertionError exc) {
			Assert.assertTrue(false, "[Assertion Failed]:: " + ExpectedISBN + " Is Not Displayed..");
			wait.resetImplicitTimeout(wait.timeout);
		}
	}

	public void VerifyISBNIs_Not_DisplayedInPublish_Detail_Publish_ProjectPopUp(String ExpectedISBN) {
		areElementsDisplayed("PublishedISBN");
		List<WebElement> ISBNs = elements("PublishedISBN");
		for (int i = 0; i < ISBNs.size(); i++) {
			String ISBN = ISBNs.get(i).getAttribute("innerText").trim();
			if (ISBN.equals(ExpectedISBN)) {
				Assert.assertTrue(false, "[Assertion Failed]:: " + ExpectedISBN + " Is Displayed..");
				return;
			}
		}
		logMessage("[Assertion Passed]:: " + ExpectedISBN + " Is not Displayed..");
	}

	public void VerifyCountOnISBNDisplayedInPublishDetail_Publish_ProjectPopUp(int Count) {
		areElementsDisplayed("PublishedISBN");
		List<WebElement> ISBNs = elements("PublishedISBN");
		logMessage("Number of ISBN Displayed in Published Project ISBN(s)::" + ISBNs.size());
		logMessage("Number of ISBN expected in Published Project ISBN(s)::" + Count);
		if (ISBNs.size() == Count) {
			Assert.assertTrue(true);
		}
	}

	public void VerifyPublishedProjectISBNHeaders() {
		isElementDisplayed("PublishedProjectISBN_Header", "ISBN");
		isElementDisplayed("PublishedProjectISBN_Header", "ISBN-10");
		isElementDisplayed("PublishedProjectISBN_Header", "Author");
		isElementDisplayed("PublishedProjectISBN_Header", "Title");
		isElementDisplayed("PublishedProjectISBN_Header", "Edition");
		isElementDisplayed("PublishedProjectISBN_Header", "Copyright Year");
	}

	public void VerifyPublishedFileDetailHeaders() {
		isElementDisplayed("PublishFileDetailHeader", "Asset Title");
		isElementDisplayed("PublishFileDetailHeader", "File Name");
	}

	public void VerifyVisibilityMetadataHeaderNotDisplayed() {
		Assert.assertTrue(verifyElementNotDisplayed("PublishFileDetailHeader", "Visibility Metadata"),
				"[Assertion Failed]:: Visibility Metadata Header Displayed.");
		logMessage("[Assertion Passed]:: Visibility Metadata Header is Not Displayed.");
	}

	public void VerifyVisibilityMetadataHeaderIsDisplayed() {
		isElementDisplayed("PublishFileDetailHeader", "Visibility Metadata");
		logMessage("[Assertion Passed]:: Visibility Metadata Header is Displayed.");
	}

	public void VerifyToolTipsOnAuthoringToolGrid() {
		List<WebElement> tooltips = elements("ToolTipsGrid");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			wait.hardWait(1);
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}
	}

	public void VerifyToolTipsOnAuthoringToolList() {
		List<WebElement> tooltips = elements("ToolTipsList");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			wait.hardWait(1);
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}
	}

	public void VerifyToolTipsOnPublishWindow() {
		areElementsDisplayed("PublishWindowToolTips");
		List<WebElement> tooltips = elements("PublishWindowToolTips");
		for (int i = 0; i < tooltips.size(); i++) {
			hover(tooltips.get(i));
			wait.hardWait(1);
			isElementDisplayed("ToolTipPopUp", tooltips.get(i).getAttribute("uib-tooltip").trim());
		}
	}

	public void ClickPageSelectionDropDown() {
		isElementDisplayed("PageSelectionButton");
		scroll(element("publish"));
		hover(element("PageSelectionButton"));
		wait.hardWait(1);
		element("PageSelectionButton").click();
		logMessage("Page Selection Dropdown Clicked..");
	}

	public void VerifyPageSelectionDropDownNotDisplayed() {
		isElementDisplayed("PageSelectionSection");
		Assert.assertTrue(element("PageSelectionSection").getAttribute("class").contains("ng-hide"),
				"[Assertion Failed]:: Select All DropDown Is Displayed");
		logMessage("[Assertion Passed]:: Select All DropDown Is NOT Displayed");
	}

	public void SelectPagesInStep3PublishWindow(String PageType) {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("PublishWindowPageSelection", PageType);
		click(element("PublishWindowPageSelection", PageType));
		logMessage("'" + PageType + "' select in page Selection.");
	}

	public void VerifyHandIconOnSelectAllOption(String Option) {
		isElementDisplayed("PublishWindowPageSelection", Option);
		wait.hardWait(1);
		hover(element("PublishWindowPageSelection", Option));
		logMessage("Cursor Property::" + element("PublishWindowPageSelection", Option).getCssValue("cursor"));
		Assert.assertTrue(element("PublishWindowPageSelection", Option).getCssValue("cursor").trim().equals("pointer"),
				"[Assertion Failed]::Hand Icon Not Displayed..");
	}

	public void VerifyUploadButtonIsDisabled() {
		wait.hardWait(2);
		isElementDisplayed("Upload");
		isElementDisplayed("Upload");
		String Attri = element("Upload").getAttribute("disabled");
		if (Attri == null) {
			Assert.assertTrue(false, "[Assertion Failed]:: Update Button Is Enabled...");
		} else {
			logMessage("[Assertion Passed]:: Update Button Is Disabled...");
		}
	}

	public void VerifyUploadButtonIsEnabled() {
		wait.hardWait(2);
		isElementDisplayed("Upload");
		isElementDisplayed("Upload");
		String Attri = element("Upload").getAttribute("disabled");
		if (Attri == null) {
			Assert.assertTrue(true, "[Assertion Passed]:: Update Button Is Enabled...");
		} else {
			Assert.assertTrue(false, "[Assertion Failed]:: Update Button Is Disabled...");
		}
	}

	public void verifyAdditionalFileInFrost(String FileName) {
		isElementDisplayed("AdditionalFile", FileName);
		scroll(element("AdditionalFile", FileName));
		logMessage(FileName + "File Is Present in Frost");

	}

	public void VerifyFrostPushActionInWorkFlowHistory(String demoISBN) {
		String ExpectedStatus = "Workflow update: Push to frost ISBN-" + demoISBN;
		logMessage("Expected Messsage::" + ExpectedStatus);
		areElementsDisplayed("PushFrostStatus", ExpectedStatus);
		/*
		 * String MessageDisplayed =
		 * element("PushFrostStatus").getAttribute("innerText").trim();
		 * logMessage("Expected Status::" + ExpectedStatus);
		 * logMessage("Message Displayed::" + MessageDisplayed);
		 * Assert.assertTrue(ExpectedStatus.trim().equals(MessageDisplayed),
		 * "[Asssertion Failed]:: InCorrect Status Displayed::" + MessageDisplayed);
		 */
	}

	public void VerifyActionInWorkFlowHistory(String Text) {
		isElementDisplayed("VerifyInformation", Text);
		scroll(element("VerifyInformation", Text));
		logMessage("[Asssertion Passed]:: " + Text + " Displayed..");
	}

	public void VerifyFrostPushActionInWorkFlowHistoryIsNotUpdated(String demoISBN) {
		String ExpectedStatus = "Workflow update: Push to frost ISBN-" + demoISBN;
		isElementDisplayed("PushFrostStatusFirst");
		scroll(element("PushFrostStatusFirst"));
		String MessageDisplayed = element("PushFrostStatusFirst").getAttribute("innerText").trim();
		logMessage("Expected Status::" + ExpectedStatus);
		logMessage("Message Displayed::" + MessageDisplayed);
		Assert.assertFalse((ExpectedStatus.trim().equals(MessageDisplayed)),
				"[Asssertion Failed]:: InCorrect Status Displayed::" + MessageDisplayed);
	}

	public void VerifyPublishStatus(String row, String Status) {
		isElementDisplayed("GetPublishInformation", row);
		String StatusDisplayed = element("GetPublishInformation", row).getAttribute("innerText").trim();
		logMessage("Status Displayed::" + StatusDisplayed);
		logMessage("Status Expected::" + Status);
		Assert.assertTrue(StatusDisplayed.equals(Status),
				"[Assertion Failed]:: Incorrect Status Displayed=" + StatusDisplayed);
	}

	public void WaitforpublishToComplete(String SuccessText, String index) {
		ClickRefreshLink();
		isElementDisplayed("GetPublishInformation", index);
		int No_try = 0;
		while (No_try <= 180) {
			String Status = element("GetPublishInformation", index).getAttribute("innerText").trim();
			if (Status.equalsIgnoreCase(SuccessText)) {
				logMessage("'" + SuccessText + "' Status is Displayed..");
				return;
			} else if (Status.equalsIgnoreCase("Failed") || Status.contains("Could not retrieve")) {
				Assert.assertTrue(false, "[Assertion failed]:: " + Status + " Status is Displayed.. ");
			} else {
				logMessage(Status + " State is Displayed..");
				wait.hardWait(5); // Will wait for 5 sec before re-checking Publish Status. will Continue to check
									// for 15 min
				ClickRefreshLink();
				No_try++;
			}
			if (No_try >= 180) {
				Assert.assertTrue(false, "[Assertion Failed]::'Complete status is not Displayed::'" + Status);
			}
		}
	}

	// ################ Student Visibility Functionality ##########//

	public void ClickVisibleToStudentButton() {
		isElementDisplayed("VisibleToStudent");
		hover(element("VisibleToStudent"));
		wait.waitForPageToLoadCompletely();
		click(element("VisibleToStudent"));
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		logMessage("'Visible To Student' button Clicked..");
	}

	public void VerifyMessageOnAddingVisibleToStudent() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ResourceMessage");
		String ExpectedMssage = getData("VisibleToStudent");
		String Message = element("ResourceMessage").getAttribute("innerText");
		assertTrue(Message.contains(ExpectedMssage), "[Assertion Failed]::Correct Message Not Displayed::" + Message);
		logMessage("[Assertion Passed]::Correct Message Displayed::" + Message);
	}

	public void VerifyVisibleToStudentButtonDisabled() {
		isElementDisplayed("VisibleToStudent");
		String CheckAttribute = element("VisibleToStudent").getAttribute("disabled");
		if (CheckAttribute != null && CheckAttribute.equals("true")) {
			logMessage("'Visible To Student' button is Disabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Visible To Student' button is Enabled..");
		}
	}

	public void VerifyVisibleToStudentButtonButtonEnabled() {
		isElementDisplayed("VisibleToStudent");
		String CheckAttribute = element("VisibleToStudent").getAttribute("disabled");
		if (CheckAttribute == null) {
			logMessage("'Visible To Student' button is Enabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Visible To Student' button is Disabled..");
		}
	}

	public void ClickNotVisibleToStudentButton() {
		isElementDisplayed("NotVisibleToStudent");
		hover(element("NotVisibleToStudent"));
		wait.waitForPageToLoadCompletely();
		click(element("NotVisibleToStudent"));
		waitForLoaderToDisappear();
		wait.waitForPageToLoadCompletely();
		logMessage("'Not Visible To Student' button Clicked..");
	}

	public void VerifyMessageOnAddingNotVisibleToStudent() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ResourceMessage");
		String ExpectedMssage = getData("NotVisibleToStudent");
		String Message = element("ResourceMessage").getAttribute("innerText");
		assertTrue(Message.contains(ExpectedMssage), "[Assertion Failed]::Correct Message Not Displayed::" + Message);
		logMessage("[Assertion Passed]::Correct Message Displayed::" + Message);
	}

	public void VerifyNotVisibleToStudentDisabled() {
		isElementDisplayed("NotVisibleToStudent");
		String CheckAttribute = element("NotVisibleToStudent").getAttribute("disabled");
		if (CheckAttribute != null && CheckAttribute.equals("true")) {
			logMessage("'Not Visible To Student' button is Disabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Not Visible To Student' button is Enabled..");
		}
	}

	public void VerifyNotVisibleToStudentButtonButtonEnabled() {
		isElementDisplayed("NotVisibleToStudent");
		String CheckAttribute = element("NotVisibleToStudent").getAttribute("disabled");
		if (CheckAttribute == null) {
			logMessage("'Not Visible To Student' button is Enabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Not Visible To Student' button is Disabled..");
		}
	}

	public void ClickResetToOriginalSystemStatusButton() {
		isElementDisplayed("ResetToOriginal");
		hover(element("ResetToOriginal"));
		wait.waitForPageToLoadCompletely();
		click(element("ResetToOriginal"));
		logMessage("'Reset To Original System Status' button Clicked..");
		waitForLoaderToDisappear();
	}

	public void VerifyMessageOnResetToOriginalSystemStatus() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("ResourceMessage");
		String ExpectedMssage = getData("ResetVisiblity");
		String Message = element("ResourceMessage").getAttribute("innerText");
		assertTrue(Message.contains(ExpectedMssage), "[Assertion Failed]::Correct Message Not Displayed::" + Message);
		logMessage("[Assertion Passed]::Correct Message Displayed::" + Message);
	}

	public void VerifyResetToOriginalSystemStatusDisabled() {
		isElementDisplayed("ResetToOriginal");
		String CheckAttribute = element("ResetToOriginal").getAttribute("disabled");
		if (CheckAttribute != null && CheckAttribute.equals("true")) {
			logMessage("'Reset To Original System Status' button is Disabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Reset To Original System Status' button is Enabled..");
		}
	}

	public void VerifyResetToOriginalSystemStatusButtonButtonEnabled() {
		isElementDisplayed("ResetToOriginal");
		String CheckAttribute = element("ResetToOriginal").getAttribute("disabled");
		if (CheckAttribute == null) {
			logMessage("Reset To Original System Status' button is Enabled..");
			Assert.assertTrue(true);
		} else {
			Assert.assertTrue(false, "'Reset To Original System status' button is Disabled..");
		}
	}

	public void VerifyAssetIsVisibleToStudent(String AssetName) {
		isElementDisplayed("CheckVisiblityOfAsset", AssetName);
		String StudentVisibility = element("CheckVisiblityOfAsset", AssetName).getAttribute("class");
		Assert.assertTrue(StudentVisibility.contains("glyphicon-akp-von"),
				"[Assertion Failed]::Assert is not Visible to Student..");
		logMessage("[Assetion Passed]:: Asset is Visible to Student..");
	}

	public void CheckToolTipDisplayedForEyeIconPublishWindow(String AssetName, String ToolTip) {
		isElementDisplayed("CheckVisiblityOfAsset", AssetName);
		hover(element("CheckVisiblityOfAsset", AssetName));
		isElementDisplayed("ToolTipPopUp", ToolTip);
		logMessage("ToolTip displayed::" + ToolTip);
	}

	public void VerifyAssetIsNotVisibleToStudent(String AssetName) {
		isElementDisplayed("CheckVisiblityOfAsset", AssetName);
		String StudentVisibility = element("CheckVisiblityOfAsset", AssetName).getAttribute("class");
		Assert.assertTrue(StudentVisibility.contains("glyphicon-akp-voff"),
				"[Assertion Failed]::Assert is Visible to Student..");
		logMessage("[Assetion Passed]:: Asset is Not Visible to Student..");
	}

	public void VerifyEyeIconNotDisplayedForAsset(String AssetName) {
		Assert.assertTrue(verifyElementNotDisplayed("CheckVisiblityOfAsset", AssetName),
				"[Assertion Failed]:: Eye Icon Displayed for Asset:" + AssetName);
		logMessage("[Assertion Passed]:: Eye Icon Not Displayed for Asset:" + AssetName);

	}

	public void VerifyAssetIsVisibleToStudentManualPublish(String AssetName) {
		isElementDisplayed("CheckVisiblityOfAssetManualPublish", AssetName);
		String StudentVisibility = element("CheckVisiblityOfAssetManualPublish", AssetName).getAttribute("class");
		Assert.assertTrue(StudentVisibility.contains("glyphicon-akp-von"),
				"[Assertion Failed]::Assert is not Visible to Student..");
		logMessage("[Assetion Passed]:: Asset is Visible to Student..");
	}

	public void CheckToolTipDisplayedForEyeIconPublishWindowManualPublish(String AssetName, String ToolTip) {
		isElementDisplayed("CheckVisiblityOfAssetManualPublish", AssetName);
		hover(element("CheckVisiblityOfAssetManualPublish", AssetName));
		isElementDisplayed("ToolTipPopUp", ToolTip);
		logMessage("ToolTip displayed::" + ToolTip);
	}

	public void VerifyAssetIsNotVisibleToStudentManualPublish(String AssetName) {
		isElementDisplayed("CheckVisiblityOfAssetManualPublish", AssetName);
		String StudentVisibility = element("CheckVisiblityOfAssetManualPublish", AssetName).getAttribute("class");
		Assert.assertTrue(StudentVisibility.contains("glyphicon-akp-voff"),
				"[Assertion Failed]::Assert is Visible to Student..");
		logMessage("[Assetion Passed]:: Asset is Not Visible to Student..");
	}

	public void VerifyEyeIconNotDisplayedForAssetManualPublish(String AssetName) {
		Assert.assertTrue(verifyElementNotDisplayed("CheckVisiblityOfAssetManualPublish", AssetName),
				"[Assertion Failed]:: Eye Icon Displayed for Asset:" + AssetName);
		logMessage("[Assertion Passed]:: Eye Icon Not Displayed for Asset:" + AssetName);

	}

	// ############ Student Visibility Functionality End ##########//
}
