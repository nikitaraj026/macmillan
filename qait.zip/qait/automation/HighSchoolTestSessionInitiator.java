package com.qait.automation;

public class HighSchoolTestSessionInitiator {

}
