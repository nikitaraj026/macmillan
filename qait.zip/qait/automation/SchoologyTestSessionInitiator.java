package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.schoology.keywords.AssignmentPageAction;
import com.qait.schoology.keywords.CoursePageAction;
import com.qait.schoology.keywords.DashboardPageAction;
import com.qait.schoology.keywords.FandEPageActions;
import com.qait.schoology.keywords.LoginPageActions;
import com.qait.schoology.keywords.PXPageAction;
import com.qait.schoology.keywords.ProvisioningPageAction;
import com.qait.schoology.keywords.StudentAccessGrantPageActions;
import com.qait.schoology.keywords.ToolsPageActions;

public class SchoologyTestSessionInitiator extends TestSessionInitiator {
	public CustomFunctions customFunctions;
	public ToolsPageActions toolsPage;
	public LoginPageActions logInpage;
	public DashboardPageAction dashboard;
	public CoursePageAction coursePageAction;
	public ProvisioningPageAction provisioningPage;
	public PXPageAction pxPageAction;
	public AssignmentPageAction assignmentPageAction;
	public FandEPageActions fandEPageActions;
	public StudentAccessGrantPageActions studentAccess;
	private String product_local;

	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		toolsPage = new ToolsPageActions(driver);
		logInpage = new LoginPageActions(driver);
		dashboard = new DashboardPageAction(driver);
		coursePageAction = new CoursePageAction(driver);
		provisioningPage = new ProvisioningPageAction(driver);
		pxPageAction = new PXPageAction(driver);
		assignmentPageAction = new AssignmentPageAction(driver);
		fandEPageActions = new FandEPageActions(driver);
		studentAccess = new StudentAccessGrantPageActions(driver);
	}

	public SchoologyTestSessionInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects(), product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct() {
		product_local = System.getProperty("product");
		product = System.getProperty("product");

		if (product == null) {
			product = ConfigPropertyReader.getProperty("product");
		}

		if (product_local == null) {
			product_local = ConfigPropertyReader.getProperty("product");
		}
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
	}

	public String getCurrentDateWithTime() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy");
		String strDate = formatter.format(date);
		SimpleDateFormat formatter1 = new SimpleDateFormat("HHmmss");
		String time = formatter1.format(date);
		return strDate + "_" + time;
	}
}
