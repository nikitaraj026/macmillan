package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.clever2.keywords.ChooseCoursePageActions;
import com.qait.clever2.keywords.DataBrowserPageActions;
import com.qait.clever2.keywords.HomePageActions;
import com.qait.clever2.keywords.LaunchPadPageActions;
import com.qait.clever2.keywords.LoginPageActions;

public class Clever2TestSessionInitiator extends TestSessionInitiator {

    public CustomFunctions customFunctions;
    public LoginPageActions loginPage;
    public HomePageActions homePage;
    public DataBrowserPageActions dataBrowsePage;
    public ChooseCoursePageActions chooseCoursePage;
    public LaunchPadPageActions LaunchPadPage;
    private String product_local;

    private void _initPage() {
        customFunctions = new CustomFunctions(driver);
        loginPage = new LoginPageActions(driver);
        homePage = new HomePageActions(driver);
        dataBrowsePage = new DataBrowserPageActions(driver);
        chooseCoursePage = new ChooseCoursePageActions(driver);
        LaunchPadPage = new LaunchPadPageActions(driver);
    }

    public Clever2TestSessionInitiator() {
        super();
        setProduct();
        setYamlFilePath(product_local);
        configureBrowser();
        _initPage();
        customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
        CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
    }

    public void setProduct() {
    	product_local="clever2";
        product = "clever2";
        CustomFunctions.setProduct(product_local);
        GetPage.setProduct(product_local);
    }
}
