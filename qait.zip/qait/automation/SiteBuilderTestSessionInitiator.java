/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.testng.Reporter;
import com.qait.SiteBuilder.keywords.AddItemPageActions;
import com.qait.SiteBuilder.keywords.AddSitePageActions;
import com.qait.SiteBuilder.keywords.AddUserPageActions;
import com.qait.SiteBuilder.keywords.ContentUpdatePageActions;
import com.qait.SiteBuilder.keywords.EditItemPageActions;
import com.qait.SiteBuilder.keywords.ExportImportPageActions;
import com.qait.SiteBuilder.keywords.FindPageActions;
import com.qait.SiteBuilder.keywords.GoogleSheetPageAction;
import com.qait.SiteBuilder.keywords.HealthCheckPageAction;
import com.qait.SiteBuilder.keywords.HomePageActions;
import com.qait.SiteBuilder.keywords.LPApplicationPageAction;
import com.qait.SiteBuilder.keywords.LoginpageActions;
import com.qait.SiteBuilder.keywords.LpmsPageActions;
import com.qait.SiteBuilder.keywords.OperationsPageActions;
import com.qait.SiteBuilder.keywords.PublishPageActions;
import com.qait.SiteBuilder.keywords.SandboxLoginPageActions;
import com.qait.SiteBuilder.keywords.SandboxPageActions;
import com.qait.SiteBuilder.keywords.VisualsPageActions;
import com.qait.SiteBuilder.keywords.WorkspaceImportPageActions;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.SeleniumWebDriverEventListener;

/**
 * 
 * @author QAIT
 */

public class SiteBuilderTestSessionInitiator extends TestSessionInitiator{
	private EventFiringWebDriver efwd;
	private SeleniumWebDriverEventListener myListener;
	public CustomFunctions customFunctions;
    public LoginpageActions Loginpage;
	public HomePageActions HomePage;
	public AddSitePageActions AddSitePage;
	public AddUserPageActions AddUserPage;
	public AddItemPageActions AddItemPage;
	public ContentUpdatePageActions ContentUpdatePage;
	public EditItemPageActions EditItemPage;
	public WorkspaceImportPageActions WorkspaceImportPage;
	public ExportImportPageActions ExportImportPage;
	public PublishPageActions PublishPage;
	public FindPageActions FindPage;
	public SandboxPageActions SandboxPage;
	public SandboxLoginPageActions SandboxLoginPage;
	public VisualsPageActions VisualsPage;
	public OperationsPageActions OperationsPage;
	public LpmsPageActions LpmsPage;
	public HealthCheckPageAction HealthCheck;
	public GoogleSheetPageAction GoogleSheet;
	public LPApplicationPageAction LPApplication;
	
	private void _initPage() {
    	customFunctions = new CustomFunctions(driver);
    	Loginpage = new LoginpageActions(driver);
    	HomePage = new HomePageActions(driver);
    	AddSitePage = new AddSitePageActions(driver);
    	AddUserPage = new AddUserPageActions(driver);
    	AddItemPage = new AddItemPageActions(driver);
    	ContentUpdatePage = new ContentUpdatePageActions(driver);
    	EditItemPage = new EditItemPageActions(driver);
    	WorkspaceImportPage = new WorkspaceImportPageActions(driver);
    	ExportImportPage = new ExportImportPageActions(driver);
    	PublishPage = new PublishPageActions(driver);
    	FindPage = new FindPageActions(driver);
    	SandboxPage = new SandboxPageActions(driver);
    	SandboxLoginPage = new SandboxLoginPageActions(driver);
    	VisualsPage = new VisualsPageActions(driver);
    	OperationsPage = new OperationsPageActions(driver);
    	LpmsPage = new LpmsPageActions(driver);
    	HealthCheck=new HealthCheckPageAction(driver);
    	GoogleSheet=new GoogleSheetPageAction(driver);
    	LPApplication=new LPApplicationPageAction(driver);
    }

	public SiteBuilderTestSessionInitiator() {
		 super();
		 setProduct();
		 setYamlFilePath(product);
		 configureBrowser();
		 _initPage();
		 customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,TestSessionInitiator.product);
		 CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
		 
	}
	
	public void setProduct(){
    	product = "SITEBUILDER";
    	CustomFunctions.setProduct(product);
    	GetPage.setProduct(product);
    }
	public void testStartMessage(String testCaseName) {
		Reporter.log(" ", true);
		Reporter.log("\t||||| " + testCaseName.toUpperCase() + " |||||",true);
		Reporter.log("", true);
	}
	
	/*public void _registerEventDriver(){
		efwd = new EventFiringWebDriver(driver);
		myListener = new SeleniumWebDriverEventListener(driver);
		efwd.register(myListener);
		driver = efwd;
	}*/
	
	public void _unregisterDriverFromEventDriver(){
		//efwd.unregister(myListener);
	}

	

}