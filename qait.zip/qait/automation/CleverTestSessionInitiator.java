package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.clever.keywords.ChooseCoursePageActions;
import com.qait.clever.keywords.CleverAppActions;
import com.qait.clever.keywords.CleverHomePageActions;
import com.qait.clever.keywords.CleverLoginPageActions;
import com.qait.clever.keywords.CleverSyncDistrictActions;
import com.qait.clever.keywords.DataBrowserPageActions;
import com.qait.clever.keywords.HomePageActions;
import com.qait.clever.keywords.InsertNewEntriesActions;
import com.qait.clever.keywords.LaunchPadPageActions;
import com.qait.clever.keywords.LoginPageActions;
import com.qait.clever.keywords.PXPageActions;
import com.qait.clever.keywords.excel2csv;
import com.qait.clever.tests.CleverAppStudent;

public class CleverTestSessionInitiator extends TestSessionInitiator {

	public CustomFunctions customFunctions;
	public LoginPageActions loginPage;
	public HomePageActions homePage;
	public DataBrowserPageActions dataBrowsePage;
	public ChooseCoursePageActions chooseCoursePage;
	public CleverLoginPageActions loginPageClever;
	public CleverHomePageActions homePageClever;
	public CleverSyncDistrictActions syncDistrictClever;
	public InsertNewEntriesActions insertEntriesClever;
	public PXPageActions pxpageActions;
	public excel2csv excel2csvClever;
	public CleverAppActions appClever;
	public LaunchPadPageActions LaunchPadPage;
	private String product_local;

	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		loginPage = new LoginPageActions(driver);
		homePage = new HomePageActions(driver);
		dataBrowsePage = new DataBrowserPageActions(driver);
		chooseCoursePage = new ChooseCoursePageActions(driver);
		LaunchPadPage = new LaunchPadPageActions(driver);
		loginPageClever = new CleverLoginPageActions(driver);
		homePageClever = new CleverHomePageActions(driver);
		insertEntriesClever = new InsertNewEntriesActions();
		excel2csvClever = new excel2csv();
		syncDistrictClever = new CleverSyncDistrictActions(driver);
		pxpageActions= new PXPageActions(driver);
		appClever = new CleverAppActions(driver);
	}

	public CleverTestSessionInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects(), product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct() {
		product_local = "clever";
		product = "clever";
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
	}
}
