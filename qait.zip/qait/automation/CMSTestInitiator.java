package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.CMS.keywords.ContentPageAction;
import com.qait.CMS.keywords.ContentViewAction;
import com.qait.CMS.keywords.HomePageAction;
import com.qait.CMS.keywords.HotFolderAction;
import com.qait.CMS.keywords.InstructorCatalogAction;
import com.qait.CMS.keywords.LoginPageActions;
import com.qait.CMS.keywords.NonCmsAssetsAction;
import com.qait.CMS.keywords.ProjectPageAction;
import com.qait.CMS.keywords.ProjectViewAction;
import com.qait.CMS.keywords.SearchPageAction;
import com.qait.SiteBuilder.keywords.GoogleSheetPageAction;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;


public class CMSTestInitiator extends TestSessionInitiator{
	
	public LoginPageActions loginpage;
	public HomePageAction HomePage;
	public CustomFunctions customFunctions;
	public ProjectPageAction ProjectPage;
	public ContentPageAction Contentpage;
	public ProjectViewAction projectView;
	public ContentViewAction ContentView;
	public NonCmsAssetsAction NonCmsAssets;
	public SearchPageAction SearchPage;
	public InstructorCatalogAction InstructorCatalog;
	public HotFolderAction HotFolder;
	public GoogleSheetPageAction  GoogleSheetPage;

	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		loginpage = new LoginPageActions(driver);
		HomePage = new HomePageAction(driver);
		ProjectPage = new ProjectPageAction(driver);
		Contentpage = new ContentPageAction(driver);
		projectView=new ProjectViewAction(driver);
		ContentView=new ContentViewAction(driver);
		NonCmsAssets=new NonCmsAssetsAction(driver);
		SearchPage=new SearchPageAction(driver);
		InstructorCatalog=new InstructorCatalogAction(driver);
		HotFolder=new HotFolderAction(driver); 
		GoogleSheetPage=new GoogleSheetPageAction(driver);
	}
	
	public CMSTestInitiator() {
		super();
		setProduct();
		setYamlFilePath(product);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,TestSessionInitiator.product);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	public void setProduct(){
		product = "CMS";
		CustomFunctions.setProduct(product);
		GetPage.setProduct(product);
	}

	
}