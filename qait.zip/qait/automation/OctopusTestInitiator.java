package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.octopus.keywords.DatabaseActions;
import com.qait.octopus.keywords.OctopusPageActions;

public class OctopusTestInitiator extends TestSessionInitiator{

	public CustomFunctions customFunctions;
	public OctopusPageActions octopusPage;
	public DatabaseActions databaseActions;
	private String product_local;
	
	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		octopusPage = new OctopusPageActions(driver);
		databaseActions = new DatabaseActions();
	}

	public OctopusTestInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct(){
		product_local="octopus";
		product = "octopus";
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
	}
}

