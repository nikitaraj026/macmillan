/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation.getpageobjects;

/**
 *
 * @author QAIT
 */
public enum Tiers {
    DEV, Dev, dev,
    QA, Qa, qa,
    PR, pr, PRISTINE, Pristine, pristine,
    PROD, prod, production, PRODUCTION, Production,  
    lt, LT,
	stg, stage, STG, Stage,
	dnscutover;
}
