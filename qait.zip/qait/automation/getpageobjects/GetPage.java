package com.qait.automation.getpageobjects;

import static com.qait.automation.getpageobjects.ObjectFileReader.getELementFromFile;
import static com.qait.automation.utils.DataReadWrite.getProperty;
import static io.restassured.RestAssured.given;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Color;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.LayoutValidation;

import io.restassured.response.Response;

public class GetPage extends BaseUi {

	protected WebDriver driver, driverToUploadImage;
	String pageName;
	public CustomAssert customAssert;
	static String product;
	LayoutValidation layouttest;

	public GetPage() {
		super();
	}

	public GetPage(WebDriver driver, String pageName) {
		super(driver, pageName);
		this.driver = driver;
		this.pageName = pageName;
		customAssert = new CustomAssert(driver);
		layouttest = new LayoutValidation(driver, pageName);
	}

	public GetPage(WebDriver driver, WebDriver driverToUploadImage, String pageName) {
		super(driver, driverToUploadImage, pageName);
		this.driverToUploadImage = driverToUploadImage;
		this.driver = driver;
		this.pageName = pageName;
		customAssert = new CustomAssert(driver);
		layouttest = new LayoutValidation(driver, pageName);
	}

	public static void setProduct(String productName) {
		product = productName;
	}

	/*****************************************************************************
	 * PRIVATE METHODS
	 *****************************************************************************/

	public void _waitForJqueryToFinish() {
		int count = 60;
		do {
			hardWait(1);
			count++;
		} while (!(Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0") && count <= 60);
	}

	private void _waitForElementToBeVisible(String elementToken, String replacement1, String replacement2) {
		int i = 0;
		int initTimeout = wait.timeout;
		wait.resetImplicitTimeout(1);
		int count;
		while (i <= initTimeout) {
			count = _getCountOfElements(elementToken, replacement1, replacement2);
			if (count != 1) {
				i += 1;
			} else
				break;
		}
		// _waitForJqueryToFinish();
		wait.resetImplicitTimeout(wait.getTimeout());
	}

	private void _waitForElementsToBeVisible(String elementToken, String replacement1, String replacement2) {
		int i = 0;
		int initTimeout = wait.timeout;
		wait.resetImplicitTimeout(2);
		int count;
		while (i <= initTimeout) {
			count = _getCountOfElements(elementToken, replacement1, replacement2);
			if (count == 0) {
				i += 2;
			} else
				break;
		}
		// _waitForJqueryToFinish();
		wait.resetImplicitTimeout(wait.getTimeout());
	}

	private String _getTextFirstElementOfList(String elementToken, String replacement1, String replacement2) {
		_waitForElementsToBeVisible(elementToken, replacement1, replacement2);
		int count = _getCountOfElements(elementToken, replacement1, replacement2);
		if (count > 0) {
			if (replacement1.isEmpty() && replacement2.isEmpty()) {
				return elements(elementToken).get(0).getText().toString().trim();
			} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
				return elements(elementToken, replacement1).get(0).getText().trim();
			} else if (!replacement1.isEmpty() && !replacement2.isEmpty()) {
				return elements(elementToken, replacement1, replacement2).get(0).getText().trim();
			}
		} else {
			_intelligentAssertTrue(elementToken, replacement1, replacement2, count > 0, "elements_displayed");
		}
		return "";
	}

	private void _verifyTextOfElementIsCorrect(String elementToken, String replacement1, String replacement2,
			String expectedText) {
		_isElementDisplayed(elementToken, replacement1, replacement2);
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(2);
		int count = 0;
		String actualText = "This text will never match";
		while (true) {
			try {
				actualText = _getTextFirstElementOfList(elementToken, replacement1, replacement2);
			} catch (Exception e) {
				System.out.println("Exception occured : " + e.getMessage());
			}
			if (actualText.equals(expectedText))
				break;
			hardWait(2);
			count += 2;
			if (count > 25) {
				break;
			}
		}
		customAssert.customAssertTrue(actualText.equalsIgnoreCase(expectedText),
				"[Assertion Failed] : " + "Text of element '" + elementToken + "' is not correct; Expected = '"
						+ expectedText + "'; Actual = '" + actualText + "'");
		logMessage("[Assertion Passed] : Text of element '" + elementToken + "' is '" + expectedText + "'");
		wait.resetImplicitTimeout(timeout);
	}

	private void _verifyTextOfElementIsContains(String elementToken, String replacement1, String replacement2,
			String expectedText) {
		_isElementDisplayed(elementToken, replacement1, replacement2);
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(2);
		int count = 0;
		String actualText = "This text will never match";
		while (true) {
			try {
				actualText = _getTextFirstElementOfList(elementToken, replacement1, replacement2);
			} catch (Exception e) {
				System.out.println("Exception occured : " + e.getMessage());
			}
			if (actualText.equals(expectedText))
				break;
			hardWait(2);
			count += 2;
			if (count > 25) {
				break;
			}
		}
		customAssert.customAssertTrue(actualText.contains(expectedText), "[Assertion Failed] : " + "Text of element '"
				+ elementToken + "' is not correct; Expected = '" + expectedText + "'; Actual = '" + actualText + "'");
		logMessage("[Assertion Passed] : Text of element '" + elementToken + "' is '" + expectedText + "'");
		wait.resetImplicitTimeout(timeout);
	}

	@SuppressWarnings("unused")
	private int _GetTimeForElementIsVisible(String elementToken) {
		int i = 0;
		while (elements(elementToken).size() != 0) {
			hardWait(1);
			i = i + 1;
		}
		return i;
	}

	private void _waitForElementToDisappear(String elementToken, String replacement1, String replacement2) {
		int i = 0;
		int initTimeout = wait.getTimeout();
		wait.resetImplicitTimeout(2);
		int count;
		logMessage("Waiting for element : " + elementToken + replacement1 + replacement2 + " to disappear");
		while (i <= 20) {
			count = _getCountOfElements(elementToken, replacement1, replacement2);
			if (count == 0)
				break;
			i += 2;
		}
		wait.resetImplicitTimeout(initTimeout);
	}

	private int _getCountOfElements(String elementToken, String replacement1, String replacement2) {
		int count = 0;
		if (replacement1.isEmpty() && replacement2.isEmpty()) {
			count = elements(elementToken).size();
		} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
			count = elements(elementToken, replacement1).size();
		} else if (!replacement1.isEmpty() && !replacement2.isEmpty()) {
			count = elements(elementToken, replacement1, replacement2).size();
		} else
			count = 0;
		return count;
	}

	private String[] _getAssertionMessages(String elementToken, String replacement1, String replacement2,
			String verificationType) {
		String[] messages = new String[2];
		String failAssertMessage = "[Assertion Failed] : ";
		String passAssertMessage = "[Assertion Passed] : ";
		if (verificationType.startsWith("element_text")) {
			failAssertMessage += "Text of element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Incorrect";
			passAssertMessage += "Text of element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Correct";
		} else if (verificationType.startsWith("attr_value")) {
			String attrName = verificationType.split(":")[1];
			failAssertMessage += "Attribute '" + attrName + "' value for element '" + elementToken
					+ (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Incorrect";
			passAssertMessage += "Attribute '" + attrName + "' value for element '" + elementToken
					+ (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Correct";
		} else if (verificationType.startsWith("element_displayed")) {
			failAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Not Displayed in DOM";
			passAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Displayed in DOM";
		} else if (verificationType.startsWith("element_not_displayed")) {
			failAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Displayed in DOM";
			passAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Not Displayed in DOM";
		} else if (verificationType.startsWith("elements_displayed")) {
			failAssertMessage += "Elements with locator '" + elementToken
					+ (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' are Not Displayed in DOM";
			passAssertMessage += "Elements with locator '" + elementToken
					+ (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' are Displayed in DOM";
		} else if (verificationType.startsWith("radio_btn_selected")) {
			failAssertMessage += "Radio Button '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is not Selected";
			passAssertMessage += "Radio Button '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ (replacement2.isEmpty() ? "" : ":" + replacement2) + "' is Selected";
		}

		messages[0] = failAssertMessage;
		messages[1] = passAssertMessage;
		return messages;
	}

	private void _intelligentAssertEquals(String elementToken, String replacement1, String replacement2, String actual,
			String expected, String verificationType) {
		String[] messages = _getAssertionMessages(elementToken, replacement1, replacement2, verificationType);
		customAssert.customAssertEquals(actual, expected, messages[0]);
		logMessage(messages[1]);
	}

	private void _intelligentAssertEquals(String elementToken, String replacement1, String replacement2, int actual,
			int expected, String verificationType) {
		String[] messages = _getAssertionMessages(elementToken, replacement1, replacement2, verificationType);
		customAssert.customAssertEquals(actual, expected, messages[0]);
		logMessage(messages[1]);
	}

	private void _intelligentSoftAssertEquals(String elementToken, String replacement1, String replacement2, int actual,
			int expected, String verificationType) {
		String[] messages = _getAssertionMessages(elementToken, replacement1, replacement2, verificationType);
		SoftAssert softAssertion = new SoftAssert();
		softAssertion.assertEquals(actual, expected, messages[0]);
		logMessage(messages[1]);
	}

	private void _intelligentAssertTrue(String elementToken, String replacement1, String replacement2,
			boolean condition, String verificationType) {
		String[] messages = _getAssertionMessages(elementToken, replacement1, replacement2, verificationType);
		customAssert.customAssertTrue(condition, messages[0]);
		logMessage(messages[1]);
	}

	private boolean _isElementDisplayed(String elementToken, String replacement1, String replacement2) {
		int count = 0;
		_waitForElementToBeVisible(elementToken, replacement1, replacement2);
		count = _getCountOfElements(elementToken, replacement1, replacement2);
		_intelligentAssertEquals(elementToken, replacement1, replacement2, count, 1, "element_displayed");
		return (count == 1);
	}

	private boolean _BooleanisElementDisplayed(String elementToken, String replacement1, String replacement2) {
		int count = 0;
		// _waitForElementToBeVisible(elementToken, replacement1, replacement2);
		wait.resetImplicitTimeout(2);
		count = _getCountOfElements(elementToken, replacement1, replacement2);
		_intelligentSoftAssertEquals(elementToken, replacement1, replacement2, count, 1, "element_displayed");
		wait.resetImplicitTimeout(wait.timeout);
		return (count == 1);
	}

	private boolean _areElementsDisplayed(String elementToken, String replacement1, String replacement2) {
		int count = 0;
		_waitForElementsToBeVisible(elementToken, replacement1, replacement2);
		count = _getCountOfElements(elementToken, replacement1, replacement2);
		_intelligentAssertTrue(elementToken, replacement1, replacement2, count > 0, "elements_displayed");
		return (count > 0);
	}

	protected boolean _verifyElementNotDisplayed(String elementToken, String replacement1, String replacement2) {
		int count;
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(10);
		count = _getCountOfElements(elementToken, replacement1, replacement2);
		wait.resetImplicitTimeout(timeout);
		// _intelligentAssertEquals(elementToken, replacement1, replacement2,
		// count, 0,
		// "element_not_displayed");
		return (count == 0);
	}
	private int _getCountOfElements(String elementToken, String replacement) {
		int count = 0;
		if (replacement.isEmpty()) {
			count = elements(elementToken).size();
		} else
			count = 0;
		return count;
	}
	
	private String[] _getAssertionMessages(String elementToken, String replacement1,
			String verificationType) {
		String[] messages = new String[2];
		String failAssertMessage = "[Assertion Failed] : ";
		String passAssertMessage = "[Assertion Passed] : ";
		if (verificationType.startsWith("element_text")) {
			failAssertMessage += "Text of element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+  "' is Incorrect";
			passAssertMessage += "Text of element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ "' is Correct";
		} else if (verificationType.startsWith("attr_value")) {
			String attrName = verificationType.split(":")[1];
			failAssertMessage += "Attribute '" + attrName + "' value for element '" + elementToken
					+ (replacement1.isEmpty() ? "" : ":" + replacement1) + "' is Incorrect";
			passAssertMessage += "Attribute '" + attrName + "' value for element '" + elementToken
					+ (replacement1.isEmpty() ? "" : ":" + replacement1) + "' is Correct";
		} else if (verificationType.startsWith("element_displayed")) {
			failAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1) + "' is Not Displayed in DOM";
			passAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)+ "' is Displayed in DOM";
		} else if (verificationType.startsWith("element_not_displayed")) {
			failAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1) + "' is Displayed in DOM";
			passAssertMessage += "Element '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					 + "' is Not Displayed in DOM";
		} else if (verificationType.startsWith("radio_btn_selected")) {
			failAssertMessage += "Radio Button '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					+ "' is not Selected";
			passAssertMessage += "Radio Button '" + elementToken + (replacement1.isEmpty() ? "" : ":" + replacement1)
					 + "' is Selected";
		}

		messages[0] = failAssertMessage;
		messages[1] = passAssertMessage;
		return messages;
	}

	
	private void _intelligentAssertEquals(String elementToken, String replacement, int actual,
			int expected, String verificationType) {
		String[] messages = _getAssertionMessages(elementToken, replacement, verificationType);
		customAssert.customAssertEquals(actual, expected, messages[0]);
		logMessage(messages[1]);
	}
		
	protected boolean _verifyThatElementNotDisplayed(String elementToken, String replacement) {
		int count;
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(10);
		count = _getCountOfElements(elementToken, replacement);
		wait.resetImplicitTimeout(timeout);
		_intelligentAssertEquals(elementToken, replacement,count, 0, "element_not_displayed");
		return (count == 0);
	}
	

	private void _fillText(String elementToken, String replacement1, String replacement2, String text) {
		// _waitForElementToBeVisible(elementToken, replacement1, replacement2);
		_isElementDisplayed(elementToken, replacement1, replacement2);
		if (replacement2.isEmpty() && replacement1.isEmpty()) {
			if (browser.contains("Chrome")) {
				Actions a = new Actions(driver);
				a.click(element(elementToken)).build().perform();
			} else {
				element(elementToken).click();
			}
			element(elementToken).clear();
			logMessage("Cleared textbox");
			element(elementToken).sendKeys(text);
			logMessage("sent:" + text);
		} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
			element(elementToken, replacement1).click();
			element(elementToken, replacement1).clear();
			element(elementToken, replacement1).sendKeys(text);
		} else if (!replacement2.isEmpty() && !replacement1.isEmpty()) {
			element(elementToken, replacement1, replacement2).click();
			element(elementToken, replacement1, replacement2).clear();
			element(elementToken, replacement1, replacement2).sendKeys(text);
		}
		logMessage("Filled '" + text + "' in Text Field '" + elementToken + "'");
	}

	@SuppressWarnings("unused")
	private void _verifyElementIsDisabled(String elementToken, String replacement1, String replacement2) {
		int count = 0;
		WebElement ele = null;
		if (replacement1.isEmpty() && replacement2.isEmpty()) {
			waitForElementToBeVisible(elementToken);
			count = elements(elementToken).size();
			ele = elements(elementToken).get(0);
		} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
			waitForElementToBeVisible(elementToken, replacement1);
			count = elements(elementToken, replacement1).size();
			ele = elements(elementToken).get(0);
		} else if (!replacement1.isEmpty() && !replacement2.isEmpty()) {
			count = elements(elementToken, replacement1, replacement2).size();
			ele = elements(elementToken).get(0);

		} else
			count = 0;

		customAssert.customAssertEquals(count, 1,
				"[Assertion Failed] : Element '" + elementToken + "' is not displayed");
		logMessage("[Assertion Passed] : element " + elementToken + " is displayed.");

		customAssert.customAssertFalse(ele.isEnabled(),
				"[Assertion Failed] : " + "Element '" + elementToken + "' is not disabled");
		logMessage("[Assertion Passed] : Element '" + elementToken + "' is disabled");

	}

	@SuppressWarnings("unused")
	private void _verifyElementIsEnabled(String elementToken, String replacement1, String replacement2) {
		_waitForElementToBeVisible(elementToken, replacement1, replacement2);
		int count = 0;
		count = _getCountOfElements(elementToken, replacement1, replacement2);
		WebElement ele = null;
		if (replacement1.isEmpty() && replacement2.isEmpty()) {
			ele = elements(elementToken).get(0);
		} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
			ele = elements(elementToken, replacement1).get(0);
		} else if (!replacement1.isEmpty() && !replacement2.isEmpty()) {
			ele = elements(elementToken, replacement1, replacement2).get(0);
		}

		_intelligentAssertEquals(elementToken, replacement1, replacement2, count, 1, "element_displayed");

		customAssert.customAssertTrue(ele.isEnabled(),
				"[Assertion Failed] : " + "Element '" + elementToken + "' is not enabled");
		logMessage("[Assertion Passed] : Element '" + elementToken + "' is enabled");

	}

	private void _verifyBackgroundColorHexCode(String elementToken, String replacement1, String replacement2,
			String expColor) {
		int count = 0;
		WebElement ele = null;
		if (replacement1.isEmpty() && replacement2.isEmpty()) {
			waitForElementToBeVisible(elementToken);
			count = elements(elementToken).size();
			ele = elements(elementToken).get(0);
		} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
			waitForElementToBeVisible(elementToken, replacement1);
			count = elements(elementToken, replacement1).size();
			ele = elements(elementToken).get(0);
		} else if (!replacement1.isEmpty() && !replacement2.isEmpty()) {
			count = elements(elementToken, replacement1, replacement2).size();
			ele = elements(elementToken).get(0);

		} else
			count = 0;

		customAssert.customAssertEquals(count, 1,
				"[Assertion Failed] : Element '" + elementToken + "' is not displayed");
		// logMessage("Assertion Passed: element " + elementToken + " is
		// displayed.");
		String colorvalue = ele.getCssValue("background-color");
		String colorhexcode = Color.fromString(colorvalue).asHex();
		customAssert.customAssertEquals(colorhexcode, expColor, "[Assertion Failed] : Actual Color " + colorhexcode
				+ " does not match with the expected color " + expColor + " for the element " + elementToken);
		logMessage("[Assertion Passed] : Actual Color " + colorhexcode + " matches with the expected color " + expColor
				+ " for the element " + elementToken);
	}

	@SuppressWarnings("unused")
	private void _verifySelectedOptionFromDropdown(String elementToken, String replacement1, String replacement2,
			String expOption) {
		int count = 0;
		int present = 0;
		WebElement ele = null;
		if (replacement1.isEmpty() && replacement2.isEmpty()) {
			waitForElementToBeVisible(elementToken);
			count = elements(elementToken).size();
			ele = elements(elementToken).get(0);
		} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
			waitForElementToBeVisible(elementToken, replacement1);
			count = elements(elementToken, replacement1).size();
			ele = elements(elementToken).get(0);
		} else if (!replacement1.isEmpty() && !replacement2.isEmpty()) {
			count = elements(elementToken, replacement1, replacement2).size();
			ele = elements(elementToken).get(0);

		} else
			count = 0;

		customAssert.customAssertEquals(count, 1,
				"[Assertion Failed] : Element '" + elementToken + "' is not displayed");
		logMessage("[Assertion Passed] : Element " + elementToken + " is displayed.");

		Select selectele = new Select(ele);
		List<WebElement> options = element(elementToken).findElements(By.xpath(""));

		for (WebElement option : options) {
			if (option.getText().equals(expOption)) {
				present = 1;
				break;
			}
		}
		customAssert.customAssertEquals(present, 1,
				"[Assertion Failed] : '" + expOption + "' is not available in the dropdown '" + elementToken + "'");
		logMessage("[Assertion Passed] : '" + expOption + "' option is present in the dropdown '" + elementToken + "'");

		customAssert.customAssertEquals(selectele.getFirstSelectedOption().getText(), expOption,
				"[Assertion Failed] : '" + expOption + "' option is not selected");
		logMessage("[Assertion Passed] : Selected Value matches with the expected value '" + expOption + "'");

	}

	private WebElement _element(String elementToken, String replacement1, String replacement2) {
		if (replacement1.isEmpty() && replacement2.isEmpty()) {
			return driver.findElement(getLocator(elementToken));
		} else if (replacement2.isEmpty() && !replacement1.isEmpty()) {
			return driver.findElement(getLocator(elementToken, replacement1));
		} else if (!replacement1.isEmpty() && !replacement2.isEmpty()) {
			return driver.findElement(getLocator(elementToken, replacement1, replacement2));
		}
		return driver.findElement(getLocator(elementToken));
	}

	private void _switchToFrame(String elementToken, String replacement1, String replacement2) {
		switchToDefaultContent();
		_isElementDisplayed(elementToken, replacement1, replacement2);
		driver.switchTo().frame(_element(elementToken, replacement1, replacement2));
	}

	private void _switchToFrameWithOutSwitchingDefault(String elementToken, String replacement1, String replacement2) {
		_isElementDisplayed(elementToken, replacement1, replacement2);
		driver.switchTo().frame(_element(elementToken, replacement1, replacement2));
	}

	private void _verifyAttributeOfElementIsCorrect(String elementToken, String replacement1, String replacement2,
			String attributeName, String expectedText) {
		_waitForElementToBeVisible(elementToken, replacement1, replacement2);
		String attrValue = _element(elementToken, replacement1, replacement2).getAttribute(attributeName).trim();
		_intelligentAssertEquals(elementToken, replacement1, replacement2, attrValue, expectedText,
				"attr_value:" + attributeName);
	}

	protected boolean isAttribtueNotPresent(WebElement element, String attribute) {

		Boolean result = false;
		try {
			String value = element.getAttribute(attribute);
			if (value == null) {
				result = true;
			}
		} catch (Exception e) {
		}
		return result;
	}

	private void _selectTextFromDropDown(String elementToken, String replacement1, String replacement2,
			String selectString) {
		_waitForElementToBeVisible(elementToken, replacement1, replacement2);
		Select sel = new Select(_element(elementToken, replacement1, replacement2));
		sel.selectByVisibleText(selectString);
	}

	public List<WebElement> getAllOptionsOfDropdown(WebElement element) {
		Select se = new Select(element);
		List<WebElement> valuesInDropdown = se.getOptions();
		return valuesInDropdown;
	}

	public static boolean verify_Values_In_Dropdown(List<WebElement> listOfElements, String[] strValues) {
		boolean bValue = false;
		List<String> list = new ArrayList<String>();
		for (String strValue : strValues) {
			boolean bflag = false;
			for (WebElement element : listOfElements) {
				String elementValue = element.getText();
				if (strValue.equals(elementValue)) {
					bflag = true;
				}
			}
			if (!bflag)
				list.add(strValue);
		}
		if (list.size() > 0) {
			for (String strList : list) {
				System.out.println("Value not present in dropdown: " + strList);
			}
			// Assign false if any of the value not found in dropdown
			bValue = false;
		} else {
			// Assign true if all values found in dropdown
			System.out.println("All value(s) found in dropdown");
			bValue = true;
		}
		return bValue;
	}

	/*****************************************************************************
	 * PROTECTED METHODS
	 *****************************************************************************/

	public void waitForJqueryToFinish() {
		_waitForJqueryToFinish();
	}

	/********** Get Element ***********/
	protected WebElement element(String elementToken) {
		return _element(elementToken, "", "");
	}

	protected WebElement element(String elementToken, String replacement) {
		return _element(elementToken, replacement, "");
	}

	protected WebElement element(String elementToken, String replacement1, String replacement2) {
		return _element(elementToken, replacement1, replacement2);
	}

	protected WebElement element(String elementToken, String replacement1, String replacement2, String replacement3) {
		return driver.findElement(getLocator(elementToken, replacement1, replacement2, replacement3));
	}

	/********** Get List of Elements ***********/
	protected List<WebElement> elements(String elementToken) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		return driver.findElements(getLocators(locator[1].trim(), locator[2].trim()));
	}

	protected List<WebElement> elements(String elementToken, String replacement) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceAll("\\$\\{.+?\\}", replacement);
		// System.out.println("Locator =>" +locator[2]);
		return driver.findElements(getLocators(locator[1].trim(), locator[2].trim()));
	}

	protected List<WebElement> elements(String elementToken, String replacement1, String replacement2) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement1);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement2);
		// logMessage(locator[2]);
		return driver.findElements(getLocators(locator[1].trim(), locator[2].trim()));
	}

	protected List<WebElement> elements(String elementToken, String replacement1, String replacement2,
			String replacement3) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement1);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement2);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement3);
		// logMessage(locator[2]);
		return driver.findElements(getLocators(locator[1].trim(), locator[2].trim()));
	}

	/********** Switch to single Frame ***********/
	protected void switchToFrame(String elementToken) {
		_switchToFrame(elementToken, "", "");
	}

	// Note: Below method is created to avoid switching iframe to default
	// content
	protected void switchToFrameWithOutSwitchingDefault(String elementToken) {
		_switchToFrameWithOutSwitchingDefault(elementToken, "", "");
	}

	protected void switchToFrame(String elementToken, String replacement) {
		_switchToFrame(elementToken, replacement, "");
	}

	protected void switchToFrame(String elementToken, String replacement1, String replacement2) {
		_switchToFrame(elementToken, replacement1, replacement2);
	}

	// TODO: put this in right place, create dedicated class for frame and
	// window
	// handlers
	protected void switchToNestedFrames(String frameNames) {
		switchToDefaultContent();
		String[] frameIdentifiers = frameNames.split(":");
		for (String frameId : frameIdentifiers) {
			wait.waitForFrameToBeAvailableAndSwitchToIt(getLocator(frameId.trim()));
		}
	}

	/********** Wait For Element to be Visible in DOM ***********/
	protected void waitForElementToBeVisible(String elementToken) {
		_waitForElementToBeVisible(elementToken, "", "");
	}

	protected void waitForElementToBeVisible(String elementToken, String replacement) {
		_waitForElementToBeVisible(elementToken, replacement, "");
	}

	protected void waitForElementToBeVisible(String elementToken, String replacement1, String replacement2) {
		_waitForElementToBeVisible(elementToken, replacement1, replacement2);
	}

	/**********
	 * Wait For Element to be Visible in DOM and then Click
	 ***********/
	protected void waitAndClick(String elementToken) {
		hardWait(3);
		isElementDisplayed(elementToken);
		waitForElementToBeClickable(element(elementToken));
		click(element(elementToken));
		logMessage("Clicked on element:" + elementToken);
	}

	protected void waitAndClick(String elementToken, String replacement) {
		isElementDisplayed(elementToken, replacement);
		logMessage("Clicking on element:" + elementToken);
		element(elementToken, replacement).click();
		logMessage("Clicked on element:" + elementToken);
	}

	protected void waitAndClick(String elementToken, String replacement1, String replacement2) {
		isElementDisplayed(elementToken, replacement1, replacement2);
		element(elementToken, replacement1, replacement2).click();
	}

	protected void waitAndClickWithoutUsingExtraMethods(String elementToken) {
		waitForElementToBeVisible(elementToken);
		waitForElementToBeClickable(element(elementToken));
		try {
			element(elementToken).click();
		} catch (Exception e) {
			logMessage("Exception found: " + e.getStackTrace());
			clickMethod(element(elementToken));
		}
		logMessage("Clicked on element:" + elementToken);
	}

	/**********
	 * Wait For Element to be Visible in DOM then Scroll to it and then Click
	 ***********/
	protected void waitScrollAndClick(String locator) {
		waitForElementToBeVisible(locator);
		scrollDown(element(locator));
		element(locator).click();
	}

	protected void waitScrollAndClick(String locator, String replacement) {
		wait.waitForElementToBeVisible(element(locator, replacement));
		hardWait(1);
		scrollDown(element(locator, replacement));
		hardWait(3);
		click(element(locator, replacement));
	}

	protected void waitScrollAndClick(String locator, String replacement, String replacement1) {
		waitForElementToBeVisible(locator, replacement, replacement1);
		hardWait(1);
		scrollDown(element(locator, replacement, replacement1));
		hardWait(3);
		element(locator, replacement).click();
	}

	/**********
	 * Wait For Element to be Visible in DOM then Scroll to it
	 ***********/
	protected void waitAndScrollToElement(String locator) {
		waitForElementToBeVisible(locator);
		scrollDown(element(locator));
	}

	protected void waitAndScrollToElement(String locator, String replacement) {
		waitForElementToBeVisible(locator, replacement);
		scrollDown(element(locator, replacement));
	}

	protected void waitAndScrollToElement(String locator, String replacement, String replacement1) {
		waitForElementToBeVisible(locator, replacement, replacement1);
		scrollDown(element(locator, replacement));
	}

	protected void scrollToElement(String locator, String replacement) {
		// waitForElementToBeVisible(locator);
		scrollDown(element(locator, replacement));
	}

	/**********
	 * Text Field/Area : Waits for Element to be present in DOM then Fills Text in
	 * it
	 ***********/
	protected void fillText(String elementToken, String text) {
		_fillText(elementToken, "", "", text);
	}

	protected void fillText(String elementToken, String replacement, String text) {
		_fillText(elementToken, replacement, "", text);
	}

	protected void fillText(String elementToken, String replacement1, String replacement2, String text) {
		_fillText(elementToken, replacement1, replacement2, text);
	}

	/**********
	 * Waits for Element to be present in DOM then Verifies its Text
	 ***********/
	protected void verifyTextOfElementIsCorrect(String elementToken, String expectedText) {
		_verifyTextOfElementIsCorrect(elementToken, "", "", expectedText);
	}

	protected void verifyTextOfElementIsCorrect(String elementToken, String replacement, String expectedText) {
		_verifyTextOfElementIsCorrect(elementToken, replacement, "", expectedText);
	}

	protected void verifyTextOfElementIsCorrect(String elementToken, String replacement1, String replacement2,
			String expectedText) {
		_verifyTextOfElementIsCorrect(elementToken, replacement1, replacement2, expectedText);
	}

	protected void verifyTextOfElementContains(String elementToken, String replacement1, String replacement2,
			String expectedText) {
		_verifyTextOfElementIsContains(elementToken, replacement1, replacement2, expectedText);
	}

	/**********
	 * Special Case : Waits for Element to be present in DOM then Verifies its Text
	 * including special replacement
	 ***********/
	protected void verifyTextOfElementIsCorrect(String elementToken, String replacement, String expectedText,
			String fromSubstring, String toSubstring) {
		waitForElementToBeVisible(elementToken, replacement);
		int count = 0;
		while (!element(elementToken, replacement).getText().trim().replaceAll(fromSubstring, toSubstring)
				.equals(expectedText)) {
			hardWait(1);
			count++;
			if (count > 15)
				break;
		}
		customAssert.customAssertEquals(
				element(elementToken, replacement).getText().trim().replaceAll(fromSubstring, toSubstring),
				expectedText, "[Assertion Failed] : Text of element '" + elementToken + "' is not correct");
		logMessage("[Assertion Passed] : Text of element '" + elementToken + "' is '" + expectedText + "'");
	}

	/**********
	 * Waits for Element to be present in DOM then Verifies value of specified
	 * Attribute
	 ***********/
	protected void verifyAttributeOfElementIsCorrect(String elementToken, String attributeName, String expectedText) {
		_verifyAttributeOfElementIsCorrect(elementToken, "", "", attributeName, expectedText);
	}

	protected void verifyAttributeOfElementIsCorrect(String elementToken, String replacement, String attributeName,
			String expectedText) {
		_verifyAttributeOfElementIsCorrect(elementToken, replacement, "", attributeName, expectedText);
	}

	protected void verifyAttributeOfElementIsCorrect(String elementToken, String replacement1, String replacement2,
			String attributeName, String expectedText) {
		_verifyAttributeOfElementIsCorrect(elementToken, replacement1, replacement2, attributeName, expectedText);
	}

	protected boolean isAttribtuePresent(WebElement element, String attribute) {
		Boolean result = false;
		try {
			String value = element.getAttribute(attribute);
			if (value != null) {
				result = true;
			}
		} catch (Exception e) {
		}

		return result;
	}

	/********** Waits for Element to disappear from DOM ***********/
	protected void waitForElementToDisappear(String elementToken) {
		_waitForElementToDisappear(elementToken, "", "");
	}

	protected void waitForElementToDisappear(String elementToken, String replacement) {
		_waitForElementToDisappear(elementToken, replacement, "");
	}

	protected void waitForElementToDisappear(String elementToken, String replacement1, String replacement2) {
		_waitForElementToDisappear(elementToken, replacement1, replacement2);
	}

	/**********
	 * Waits for Element List to appear in DOM then returns Text of First Element
	 ***********/
	protected String getTextFirstElementOfList(String elementToken) {
		return _getTextFirstElementOfList(elementToken, "", "");
	}

	protected String getTextFirstElementOfList(String elementToken, String replacement) {
		return _getTextFirstElementOfList(elementToken, replacement, "");
	}

	protected String getTextFirstElementOfList(String elementToken, String replacement1, String replacement2) {
		return _getTextFirstElementOfList(elementToken, replacement1, replacement2);
	}

	/********** Verifies that Radio Button is Selected ***********/
	protected void verifyRadioButtonSelected(String elementToken) {
		isElementDisplayed(elementToken);
		_intelligentAssertTrue(elementToken, "", "", element(elementToken).isSelected(), "radio_btn_selected");
	}

	protected void verifyRadioButtonSelected(String elementToken, String replacement) {
		isElementDisplayed(elementToken, replacement);
		_intelligentAssertTrue(elementToken, replacement, "", element(elementToken, replacement).isSelected(),
				"radio_btn_selected");
	}

	protected void verifyRadioButtonSelected(String elementToken, String replacement1, String replacement2) {
		isElementDisplayed(elementToken, replacement1, replacement2);
		_intelligentAssertTrue(elementToken, replacement1, replacement2,
				element(elementToken, replacement1, replacement2).isSelected(), "radio_btn_selected");
	}

	protected void verifyRadioButtonNotSelected(String elementToken, String replacement) {
		isElementDisplayed(elementToken, replacement);
		_intelligentAssertTrue(elementToken, replacement, "", !element(elementToken, replacement).isSelected(),
				"radio_btn_selected");
	}

	/**********
	 * Waits for Element to be visible then Verifies it is displayed
	 ***********/
	protected boolean isElementDisplayed(String elementToken) {
		return _isElementDisplayed(elementToken, "", "");
	}

	protected boolean BoolenIsElementDisplayed(String elementToken, String replacement1) {
		return _BooleanisElementDisplayed(elementToken, replacement1, "");
	}

	protected boolean BoolenIsElementDisplayed(String elementToken) {
		return _BooleanisElementDisplayed(elementToken, "", "");
	}

	protected boolean isElementDisplayed(String elementToken, String replacement1) {
		return _isElementDisplayed(elementToken, replacement1, "");
	}

	protected boolean isElementDisplayed(String elementToken, String replacement1, String replacement2) {
		return _isElementDisplayed(elementToken, replacement1, replacement2);
	}

	/********** Verifies if atleast one element is found ***********/
	protected boolean areElementsDisplayed(String elementToken) {
		return _areElementsDisplayed(elementToken, "", "");
	}

	protected boolean areElementsDisplayed(String elementToken, String replacement1) {
		return _areElementsDisplayed(elementToken, replacement1, "");
	}

	protected boolean areElementsDisplayed(String elementToken, String replacement1, String replacement2) {
		return _areElementsDisplayed(elementToken, replacement1, replacement2);
	}

	/********** Clicks on Element if visible in DOM ***********/
	protected void clickElementIfVisible(String elementToken) {
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(5);
		int count = elements(elementToken).size();
		if (count == 1)
			element(elementToken).click();
		logMessage("Clicked on element '" + elementToken + "'");
		wait.resetImplicitTimeout(timeout);
	}

	protected void clickElementIfVisible(String elementToken, String replacement) {
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(5);
		int count = elements(elementToken, replacement).size();
		if (count == 1)
			element(elementToken).click();
		logMessage("Clicked on element '" + elementToken + "'");
		wait.resetImplicitTimeout(timeout);
	}

	/********** Verifies that the Element is not present in DOM ***********/
	protected boolean verifyElementNotDisplayed(String elementToken) {
		return _verifyElementNotDisplayed(elementToken, "", "");
	}

	protected boolean verifyElementNotDisplayed(String elementToken, String replacement) {
		return _verifyElementNotDisplayed(elementToken, replacement, "");
	}

	protected boolean verifyElementNotDisplayed(String elementToken, String replacement1, String replacement2) {
		return _verifyElementNotDisplayed(elementToken, replacement1, replacement2);
	}

	protected boolean verifyElementDisplayed(String elementToken) {
		return element(elementToken).isDisplayed();
	}

	/**********
	 * Verifies that Dropdown is visible in DOM then selects provided Text from it
	 ***********/
	protected void selectTextFromDropDown(String elementToken, String selectString) {
		_selectTextFromDropDown(elementToken, "", "", selectString);
	}

	protected void selectTextFromDropDown(String elementToken, String replacement, String selectString) {
		_selectTextFromDropDown(elementToken, replacement, "", selectString);
	}

	protected void selectTextFromDropDown(String elementToken, String replacement1, String replacement2,
			String selectString) {
		_selectTextFromDropDown(elementToken, replacement1, replacement2, selectString);
	}

	protected String waitAndGetSelectedTextFromDropDown(String elementToken) {
		return _getSelectedTextFromDropDown(elementToken, "", "");
	}

	private String _getSelectedTextFromDropDown(String elementToken, String replacement1, String replacement2) {
		_waitForElementToBeVisible(elementToken, replacement1, replacement2);
		Select selEle = new Select(_element(elementToken, replacement1, replacement2));
		return selEle.getFirstSelectedOption().getText();
	}

	/****************
	 * Scroll into view an Element using Javascript
	 *****************/
	/*
	 * Please note the Element Locator Type should be XPath. If the element is
	 * within a Frame make sure you have first switched to the Frame
	 */
	protected void scrollToElementUsingJavaScript(String elementToken) {
		waitForElementToBeVisible(elementToken);
		String xPath = getXPathFromFile(elementToken);
		System.out.println(xPath);
		executeJavascript("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").scrollIntoView(true);");
	}

	protected void scrollToElementUsingJavaScript(String elementToken, String replacement) {
		waitForElementToBeVisible(elementToken, replacement);
		String xPath = getXPathFromFile(elementToken, replacement);
		executeJavascript("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").scrollIntoView(true);");
	}

	protected void scrollToElementUsingJavaScriptForLP(String elementToken, String replacement) {
		waitForElementToBeVisible(elementToken, replacement);
		String xPath = getXPathFromFile(elementToken, replacement);
		executeJavascript("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").scrollIntoView(true);");
		executeJavascript("window.scrollBy(0,-350)");
	}

	protected void scrollToElementUsingJavaScript(String elementToken, String replacement1, String replacement2) {
		waitForElementToBeVisible(elementToken, replacement1, replacement2);
		String xPath = getXPathFromFile(elementToken, replacement1, replacement2);
		System.out.println(xPath);
		executeJavascript("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").scrollIntoView(true);");
	}

	/**************** Click Element using Javascript *****************/
	/*
	 * Please note the Element Locator Type should be XPath. If the element is
	 * within a Frame make sure you have first switched to the Frame
	 */
	protected void clickUsingJavaScript(String elementToken) {
		waitForElementToBeVisible(elementToken);
		String xPath = getXPathFromFile(elementToken);
		System.out.println(xPath);
		System.out.println("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").click();");
		executeJavascript("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").click();");
	}

	// protected void clickusingjs(String myscript) {
	// JavascriptExecutor js = new JavascriptExecutor(driver);
	//
	// }
	protected void clickUsingJavaScript(String elementToken, String replacement) {
		waitForElementToBeVisible(elementToken, replacement);
		String xPath = getXPathFromFile(elementToken, replacement);
		System.out.println("Clicked on <" + xPath + ">");
		System.out.println("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").click();");
		executeJavascript(
				"function getElementByXpath(path){  return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } getElementByXpath(\""
						+ xPath + "\").click();");
	}

	protected void clickUsingJavaScript(String elementToken, String replacement1, String replacement2) {
		waitForElementToBeVisible(elementToken, replacement1, replacement2);
		String xPath = getXPathFromFile(elementToken, replacement1, replacement2);
		System.out.println(xPath);
		executeJavascript("function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
				+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } " + "getElementByXpath(\"" + xPath
				+ "\").click();");
	}

	/**************** Get Text of element using Javascript *****************/
	/*
	 * Please note the Element Locator Type should be XPath. If the element is
	 * within a Frame make sure you have first switched to the Frame
	 */
	protected String getTextOfElementUsingJavaScript(String elementToken) {
		waitForElementToBeVisible(elementToken);
		String xPath = getXPathFromFile(elementToken);
		System.out.println(xPath);
		return executeJavascript(
				"function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
						+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } "
						+ "return getElementByXpath(\"" + xPath + "\").textContent;").toString();
	}

	protected String getTextOfElementUsingJavaScript(String elementToken, String replacement) {
		waitForElementToBeVisible(elementToken, replacement);
		String xPath = getXPathFromFile(elementToken, replacement);
		System.out.println(xPath);
		return executeJavascript(
				"function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
						+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } "
						+ "return getElementByXpath(\"" + xPath + "\").textContent;").toString();
	}

	protected void verifyBackgroundColorHexCode(String elementToken, String replacement1, String replacement2,
			String expColor) {
		_verifyBackgroundColorHexCode(elementToken, replacement1, replacement2, expColor);
	}

	protected String returnTextUsingJavaScript(String elementToken, String replacement, String replacement2) {
		String xPath = getXPathFromFile(elementToken, replacement, replacement2);
		return (String) executeJavascript(
				"function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
						+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } "
						+ " return getElementByXpath(\"" + xPath + "\").textContent;");
	}

	protected String returnTextUsingJavaScript(String elementToken, String replacement) {
		// waitForElementToBeVisible(elementToken, replacement);
		String xPath = getXPathFromFile(elementToken, replacement);
		return (String) executeJavascript(
				"function getElementByXpath(path){   " + "return document.evaluate(path, document, null, "
						+ "XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue; } "
						+ " return getElementByXpath(\"" + xPath + "\").textContent;");
	}

	/********** Get XPath from file ***********/
	public String getXPathFromFile(String elementToken) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		return locator[2].trim();
	}

	public String getXPathFromFile(String elementToken, String replacement) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		System.out.println(locator[2]);
		locator[2] = locator[2].replaceAll("\\$\\{.+?\\}", replacement);
		return locator[2].trim();
	}

	public String getXPathFromFile(String elementToken, String replacement1, String replacement2) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement1);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement2);
		return locator[2].trim();
	}

	protected By getLocator(String elementToken) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		return getLocators(locator[1].trim(), locator[2].trim());
	}

	protected By getLocator(String elementToken, String replacement) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceAll("\\$\\{.+?\\}", replacement);
		return getLocators(locator[1].trim(), locator[2].trim());
	}

	protected By getLocator(String elementToken, String replacement1, String replacement2) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement1);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement2);
		return getLocators(locator[1].trim(), locator[2].trim());
	}

	protected By getLocator(String elementToken, String replacement1, String replacement2, String replacement3) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement1);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement2);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement3);
		return getLocators(locator[1].trim(), locator[2].trim());
	}

	protected By getLocator(String elementToken, String replacement1, String replacement2, String replacement3,
			String replacement4) {
		String[] locator = getELementFromFile(this.pageName, elementToken);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement1);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement2);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement3);
		locator[2] = locator[2].replaceFirst("\\$\\{.+?\\}", replacement4);
		return getLocators(locator[1].trim(), locator[2].trim());
	}

	// TODO rename to distiguish between getlocator and getlocators
	private By getLocators(String locatorType, String locatorValue) {
		switch (Locators.valueOf(locatorType)) {
		case id:
			return By.id(locatorValue);
		case xpath:
			return By.xpath(locatorValue);
		case name:
			return By.name(locatorValue);
		case classname:
			return By.className(locatorValue);
		case css:
			return By.cssSelector(locatorValue);
		case linktext:
			return By.linkText(locatorValue);
		default:
			return By.id(locatorValue);
		}
	}

	protected void sendKeys(WebElement element, String text) {
		JavascriptExecutor executor = (JavascriptExecutor) this.driver;
		executor.executeScript("arguments[0].value='" + text + "';", element);
	}

	List<String> loaderList = Arrays.asList(
			"launchpad:xpath://div[@class='load-message'] | //div[@class='full-loading-overlay' and not(@style='display: none;')]",
			"xbook:xpath://div[@class='full-loading-overlay' or @class='blockUI blockMsg blockElement']",
			"AQE:xpath://div[@class='load-block']", "canvas:xpath://div[@class='load-message']",
			"QBA:classname:loader-spinner",
			"howlifeworks:xpath://div[@class='full-loading-overlay' and not(@style='display: none;')]",
			"blackboard:xpath:(//div[contains(@class,'pleaseWait') and not(contains(@style,'display: none'))]|//div[@class='load-message'])",
			"CMS:xpath://div[@id='loadingIcon' and not(contains(@class, 'ng-hide'))]",
			"Sitebuilder:xpath://div[@id='BFWj-overlay_screen' and not(contains(@style, 'display: none'))]");

	public void waitForLoaderToAppear() {
		int timeout = wait.timeout;
		wait.resetImplicitTimeout(2);

		List<WebElement> elems;
		for (int i = 0; i < loaderList.size(); i++) {

			String[] splitString = loaderList.get(i).trim().split(":", 3);
			if (product.contains(splitString[0])) {
				int j = 0;
				while (j < timeout) {
					elems = driver.findElements(getLocators(splitString[1].trim(), splitString[2].trim()));
					if (elems.size() != 0)
						break;
					j += 2;
				}
			}
		}
		wait.resetImplicitTimeout(timeout);
	}

	public void waitForLoaderToDisappear() {
		switch (product) {
		case "launchpad":
			launchpadWaitForLoader();
			break;
		case "qpv1":
			launchpadWaitForLoader();
			break;
		case "qpv2":
			launchpadWaitForLoader();
			break;
		case "onboarding":
			launchpadWaitForLoader();
			break;
		case "xbook":
			launchpadWaitForLoader();
			break;
		case "howlifeworks":
			launchpadWaitForLoader();
			break;
		case "QBA":
			qbaWaitForLoader();
			break;
		case "CMS":
			CMSWaitForLoader();
			break;
		case "SITEBUILDER":
			SitebuilderWaitForLoader();
			break;
		case "DAM":
			DAMWaitForLoader();
			break;
		default:
			System.out.println("Incorrect product");
			break;
		}
	}

	private void SitebuilderWaitForLoader() {
		logMessage("Waitng For SiteBuilder Loader To disappear..");
		wait.waitForPageToLoadCompletely();
		try {
			wait.resetImplicitTimeout(1);
			wait.waitForElementToBeVisible(driver.findElement(
					By.xpath("//div[@id='BFWj-overlay_screen' and not(contains(@style, 'display: none'))]")));
			wait.waitForElementToDisappear(driver.findElement(
					By.xpath("//div[@id='BFWj-overlay_screen' and not(contains(@style, 'display: none'))]")));
			logMessage("Loader Disappered..");
			wait.waitForPageToLoadCompletely();
			wait.resetImplicitTimeout(wait.timeout);
		} catch (Exception e) {
			wait.resetImplicitTimeout(wait.timeout);
			logMessage("Loader Disappered..");
		}
		wait.waitForPageToLoadCompletely();

	}

	public boolean checkIfElementIsPresent(By eleString) {
		boolean flag = false;
		Integer timeOut = Integer.parseInt(getProperty("Config.properties", "timeout"));
		Integer hiddenFieldTimeOut = Integer.parseInt(getProperty("Config.properties", "hiddenFieldTimeOut"));
		try {
			wait.resetImplicitTimeout(0);
			wait.resetExplicitTimeout(hiddenFieldTimeOut);
			if (driver.findElement(eleString).isDisplayed()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (NoSuchElementException ex) {
			flag = false;
		} finally {
			wait.resetImplicitTimeout(timeOut);
			wait.resetExplicitTimeout(timeOut);
		}
		return flag;
	}

	public void launchpadWaitForLoader() {
		try {
			wait.resetImplicitTimeout(0);
			WebElement loader = driver.findElement(By.xpath("//div[@class='full-loading-overlay']"));
			int counter = 0;
			int killTest = 0;
			do {
				counter++;
				wait.hardWait(1);
				logMessage("Waiting for loader to disappear...");
				if (counter == 100) {
					killTest++;
					if (killTest == 1) {
						logMessage("Application failed to load content after second refresh");
						// String newURL = getCurrentURL().replace("#/start",
						// "");
						if (getCurrentURL().contains("#/start")) {
							String newURL = getCurrentURL().replaceFirst("#/start", "#/launchpad");
							driver.navigate().to(newURL);
							driver.navigate().refresh();
							// hardWait(3);
							// newURL =
							// getCurrentURL().replaceFirst("#/launchpad",
							// "#/start");
							// driver.navigate().to(newURL);
						} else {
							counter = 0;
							driver.navigate().refresh();
							continue;
						}
					}
				}
			} while (!loader.getAttribute("style").equals("display: none;"));
			logMessage("Loader disappeared");
		} catch (AssertionError e) {
			// logMessage("Loader not found");
			launchpadWaitForLoader2();
		} catch (Exception e) {
			logMessage("[LOADER] : Not Visisble");
		} finally {
			wait.resetImplicitTimeout(60);
		}
	}

	public void qbaWaitForLoader() {
		try {
			wait.resetImplicitTimeout(0);
			WebElement spinner = driver.findElement(By.xpath("//div[@id='asyncManagerLoader']/div"));
			do {
				wait.hardWait(1);
				System.out.println("Waiting for Spinner to disappear");

			} while (spinner.findElements(By.xpath(".//*")).size() > 0);

			System.out.println("Spinner disappeared");
		} catch (Exception e) {
			System.out.println("Spinner not found");
		} finally {
			wait.resetImplicitTimeout(60);
		}
	}

	public void CMSWaitForLoader() {
		logMessage("Waitng For CMS Loader To disappear..");
		try {
			wait.resetImplicitTimeout(1);
			wait.waitForElementToBeVisible(
					driver.findElement(By.xpath("//div[@id='loadingIcon' and not(contains(@class, 'ng-hide'))]")));
			wait.resetImplicitTimeout(wait.timeout);
			wait.waitForElementToDisappear(
					driver.findElement(By.xpath("//div[@id='loadingIcon' and not(contains(@class, 'ng-hide'))]")));
			logMessage("Loader Disappered..");
		} catch (Exception e) {
			wait.resetImplicitTimeout(wait.timeout);
			logMessage("Loader Disappered..");
		}
	}

	public void DAMWaitForLoader() {
		logMessage("Waitng For DAM Loader To disappear..");
		try {
			wait.resetImplicitTimeout(1);
			wait.waitForElementToBeVisible(
					driver.findElement(By.xpath("//*[@class='loading' or @class='loader-container']")));
			wait.resetImplicitTimeout(wait.timeout);
			wait.waitForElementToDisappear(
					driver.findElement(By.xpath("//*[@class='loading' or @class='loader-container']")));
			logMessage("Loader Disappered..");
		} catch (Exception e) {
			wait.resetImplicitTimeout(wait.timeout);
			logMessage("Loader Disappered..");
		}
	}

	// public void waitForLoaderToDisappear() {
	// int timeout = wait.timeout;
	// wait.resetImplicitTimeout(1);
	// boolean flag;
	// List<WebElement> elems = null;
	// for (int i = 0; i < loaderList.size(); i++) {
	// String[] splitString = loaderList.get(i).trim().split(":", 3);
	// if (product.contains(splitString[0])) {
	// double j = 0.0;
	// while (j < timeout) {
	// elems = driver.findElements(getLocators(splitString[1].trim(),
	// splitString[2].trim()));
	// if (elems.size() == 0)
	// {
	// logMessage("Loader disappeared");
	// break;
	// }
	// j+= 1;
	// // hardWait(0.1);
	// }
	//
	// if (j > timeout){
	// System.out.println("Size of Loader elements: " + elems.size());
	// logMessage("Loader does NOT disappear!!!");
	// }
	// }
	// }
	// wait.resetImplicitTimeout(timeout);
	// }

	public void waitForLoaderToAppearAndDisappear() {
		waitForLoaderToAppear();
		waitForLoaderToDisappear();
	}

	public void waitForLoaderToAppearAndDisappear(int appearTimeOut, int disappearTimeOut) {
		int configTimeout = wait.getTimeout();
		wait.setTimeout(appearTimeOut);
		waitForLoaderToAppear();
		wait.setTimeout(disappearTimeOut);
		waitForLoaderToDisappear();
		wait.resetImplicitTimeout(configTimeout);
	}

	public void verifyMsgToast(String msgSubstring) {
		String toastMsg = driver.findElement(By.className("toast-message")).getText().trim();
		if (!toastMsg.contains(msgSubstring)) {
			customAssert.customAssertTrue(false,
					"[Assertion Failed] : Toast Message does not contain '" + msgSubstring + "'");
			logMessage("[Assertion Passed] : Toast Message contains '" + msgSubstring + "'");
		} else {
			logMessage("Failed");
		}
	}

	public void clickHomeLogo() {
		element("a_logo").click();
		wait.waitForPageToLoadCompletely();
		waitForMsgToastToDisappear();
		logMessage("Toast message disappeared");
	}

	public void verifyMsgToast_LP(WebElement toastElement, String msgSubstring) {
		wait.waitForElementToBeVisible(toastElement);
		String toastMsg = toastElement.getText().trim();
		customAssert.customAssertEquals(toastMsg, msgSubstring,
				"[Assertion Failed] : Toast Message does not contain '" + msgSubstring + "'");
		logMessage("[Assertion Passed] : Toast Message contains '" + msgSubstring + "'");
	}

	List<String> messageToast = Arrays.asList("classname:toast-message");

	public void waitForMsgToastToAppearAndDisappear() {
		waitForMsgToastToAppear();
		waitForMsgToastToDisappear();
	}

	public void waitForMsgToastToAppear() {
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(5);

		List<WebElement> elems;
		for (int i = 0; i < messageToast.size(); i++) {
			String[] splitString = messageToast.get(i).trim().split(":", 2);
			int j = 0;
			while (j < timeout) {
				elems = driver.findElements(getLocators(splitString[0].trim(), splitString[1].trim()));
				if (elems.size() != 0)
					break;
				j += 5;
			}
		}
		wait.resetImplicitTimeout(timeout);
	}

	public void waitForMsgToastToAppear(String msgSubstring) {
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(1);
		List<WebElement> elems;
		// waitForLoaderToDisappear();
		for (int i = 0; i < messageToast.size(); i++) {
			String[] splitString = messageToast.get(i).trim().split(":", 2);
			int j = 0;
			while (j < timeout) {
				elems = driver.findElements(getLocators(splitString[0].trim(), splitString[1].trim()));
				if (elems.size() != 0) {
					boolean messageFound = false;
					for (int x = 0; x < elems.size(); x++) {
						String message = elems.get(x).getText().trim();
						messageFound = message.contains(msgSubstring);
						if (messageFound)
							break;
					}
					customAssert.customAssertTrue(messageFound,
							"[Assertion Failed] : " + "Toast Message does not contain '" + msgSubstring + "'");
					logMessage("[Assertion Passed] : Toast Message contains '" + msgSubstring + "'");
					break;
				}
				j += 1;
			}
		}
		wait.resetImplicitTimeout(timeout);
	}

	public void verifyToastMessageAppearsOrNot(String msgSubstring) {
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(1);
		List<WebElement> elems;
		boolean messageFound = false;
		waitForLoaderToDisappear();
		for (int i = 0; i < messageToast.size(); i++) {
			String[] splitString = messageToast.get(i).trim().split(":", 2);
			int j = 0;

			while (j < timeout) {
				elems = driver.findElements(getLocators(splitString[0].trim(), splitString[1].trim()));
				if (elems.size() != 0) {
					for (int x = 0; x < elems.size(); x++) {
						String message = elems.get(x).getText().trim();
						messageFound = message.contains(msgSubstring);
						if (messageFound)
							break;
					}
					customAssert.customAssertTrue(messageFound,
							"[Assertion Failed] : " + "Toast Message does not contain '" + msgSubstring + "'");
					logMessage("[Assertion Passed] : Toast Message contains '" + msgSubstring + "'");
					break;
				}
				hardWait(1);
				j += 1;
			}
			customAssert.customAssertTrue(messageFound, "[Assertion Failed] : No Toast Message appeared");
		}
		wait.resetImplicitTimeout(timeout);
	}

	public void waitForMsgToastToDisappear() {
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(1);
		List<WebElement> elems;
		for (int i = 0; i < messageToast.size(); i++) {
			String[] splitString = messageToast.get(i).trim().split(":", 2);
			int j = 0;
			while (j < timeout) {
				elems = driver.findElements(getLocators(splitString[0].trim(), splitString[1].trim()));
				if (elems.size() == 0)
					break;
				hardWait(1);
				j += 1;
			}
		}
		wait.resetImplicitTimeout(timeout);
	}

	public void waitForElementToBeClickable(WebElement elem) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.elementToBeClickable(elem));
	}

	public boolean isClickable(WebElement webe) {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 5);
			wait.until(ExpectedConditions.elementToBeClickable(webe));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void testPageLayout(List<String> tagsToBeTested) {
		layouttest.checklayout(tagsToBeTested);
	}

	public void testPageLayout(String... tagToBeTested) {
		testPageLayout(Arrays.asList(tagToBeTested));
	}

	public void testPageLayout() {
		testPageLayout(Arrays.asList(getProperty("./Config.properties", "browser")));
	}

	
	public int getElementCount(String elementToken) {
		int count = 0;
		_waitForElementToBeVisible(elementToken, "", "");
		count = _getCountOfElements(elementToken, "", "");
		return count;
	}

	public int getElementCount(String elementToken, String replacement1) {
		int count = 0;
		_waitForElementToBeVisible(elementToken, replacement1, "");
		count = _getCountOfElements(elementToken, replacement1, "");
		return count;
	}

	public int getElementCount(String elementToken, String replacement1, String replacement2) {
		int count = 0;
		_waitForElementToBeVisible(elementToken, replacement1, replacement2);
		count = _getCountOfElements(elementToken, replacement1, replacement2);
		return count;
	}

	public void selectCheckbox(String elementToken) {
		_isElementDisplayed(elementToken, "", "");
		if (!element(elementToken).isSelected()) {
			element(elementToken).click();
		}
	}

	public void selectCheckbox(String elementToken, String replacement1) {
		_isElementDisplayed(elementToken, replacement1, "");
		if (!element(elementToken, replacement1).isSelected()) {
			element(elementToken, replacement1).click();
		}
	}

	public void selectCheckbox(String elementToken, String replacement1, String replacement2) {
		_isElementDisplayed(elementToken, replacement1, replacement2);
		if (!element(elementToken, replacement1, replacement2).isSelected()) {
			element(elementToken, replacement1, replacement2).click();
		}
	}

	public void unselectCheckbox(String elementToken) {
		_isElementDisplayed(elementToken, "", "");
		if (element(elementToken).isSelected()) {
			element(elementToken).click();
		}
	}

	public void unselectCheckbox(String elementToken, String replacement1) {
		_isElementDisplayed(elementToken, replacement1, "");
		if (element(elementToken, replacement1).isSelected()) {
			element(elementToken, replacement1).click();
		}
	}

	public void unselectCheckbox(String elementToken, String replacement1, String replacement2) {
		_isElementDisplayed(elementToken, replacement1, replacement2);
		if (element(elementToken, replacement1, replacement2).isSelected()) {
			element(elementToken, replacement1, replacement2).click();
		}
	}

	protected void verifyCheckBoxSelected(String elementToken) {
		isElementDisplayed(elementToken);
		customAssert.customAssertTrue(element(elementToken).isSelected(),
				"[Assertion Failed] : Element with locator '" + elementToken + "' is not checked");
		logMessage("[Assertion Passed] : Element with locator '" + elementToken + "' is checked");
	}

	protected void verifyCheckBoxSelected(String elementToken, String replacement) {
		isElementDisplayed(elementToken, replacement);
		customAssert.customAssertTrue(element(elementToken, replacement).isSelected(),
				"[Assertion Failed] : Element with locator '" + elementToken + "' is not checked");
	}

	protected void verifyCheckBoxUnselected(String elementToken) {
		isElementDisplayed(elementToken);
		customAssert.customAssertFalse(element(elementToken).isSelected(),
				"[Assertion Failed] : Element with locator '" + elementToken + "' is checked");
	}

	protected void verifyCheckBoxUnselected(String elementToken, String replacement) {
		isElementDisplayed(elementToken, replacement);
		customAssert.customAssertFalse(element(elementToken, replacement).isSelected(),
				"[Assertion Failed] : Element with locator '" + elementToken + "' is checked");
	}

	public int getHttpResponseCode(String url) {
		Response response = given().get(url).then().extract().response();
		return response.getStatusCode();
	}

	public void verifyHttpResponseCode(String url, int expectedResponseCode) {
		int actualResponseCode = getHttpResponseCode(url);
		customAssert.customAssertEquals(actualResponseCode, expectedResponseCode,
				"[Assertion Failed] : Response status code is not correct");
		logMessage("[Assertion Passed] : Response status code is '" + expectedResponseCode + "'");
	}

	public void navigateToURL(String url) {
		driver.get(url);
	}

	protected void clickusingmyjs(String myscript) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript(myscript);
	}

	@Override
	public void clickUsingJS(WebElement element) {
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		try {
			executor.executeScript("arguments[0].click();", element);
		} catch (StaleElementReferenceException sre) {
			System.out.println("Stale Exeception handled.");
			wait.hardWait(1);
			executor.executeScript("arguments[0].click();", element);

		} // end of catch
	}

	protected boolean isElementNotDisplayed(String elementName) {
		boolean result = false;
		try {
			driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
			assertTrue(!element(elementName).isDisplayed(),
					"Assertion Failed: element '" + elementName + "' is displayed.");
			result = false;
			logMessage("Assertion Passed: element " + elementName + " is not displayed.");
			driver.manage().timeouts().implicitlyWait(55, TimeUnit.SECONDS);
		} catch (AssertionError ae) {
			driver.manage().timeouts().implicitlyWait(55, TimeUnit.SECONDS);
			logMessage("Assertion Passed: element " + elementName + " is not displayed.");
			result = true;
		} // end of catch
		catch (TimeoutException ae) {
			assertTrue(true);
			logMessage("Assertion Passed: element " + elementName + " is not displayed.");
			result = true;
			driver.manage().timeouts().implicitlyWait(55, TimeUnit.SECONDS);

		} // end of catch
		return result;
	}

	protected boolean isElementNotDisplayed(String elementName, String replacement) {
		boolean result = false;
		try {
			driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
			assertTrue(!element(elementName, replacement).isDisplayed(),
					"Assertion Failed: element '" + elementName + "' is displayed.");
			result = false;
			logMessage("Assertion Passed: element " + elementName + " is not displayed.");
			driver.manage().timeouts().implicitlyWait(55, TimeUnit.SECONDS);
		} catch (AssertionError ae) {
			driver.manage().timeouts().implicitlyWait(55, TimeUnit.SECONDS);
			logMessage("Assertion Passed: element " + elementName + " is not displayed.");
			result = true;
		} // end of catch
		catch (TimeoutException ae) {
			assertTrue(true);
			logMessage("Assertion Passed: element " + elementName + " is not displayed.");
			result = true;
			driver.manage().timeouts().implicitlyWait(55, TimeUnit.SECONDS);

		} // end of catch
		return result;
	}

	public void goBackToPreviousPage() {
		executeJavascript("window.history.go(-1)");
		logMessage("switched to previous page");
	}

	// added by kamini naithani
	public void matchElementValuesWithYamlDataOptions(List<WebElement> elementList1, Map<String, Object> data) {
		int size = elementList1.size();
		int objSize = data.size();
		System.out.println("Element List size : " + size + " Object size : " + objSize);
		int temp = 0;
		int i = 0;

		if (size == objSize) {
			for (Object val : data.values()) {
				String str = elementList1.get(i).getText();
				String str2 = val.toString();
				logMessage("List data : " + str + "\n value present in the file : " + str2);

				i++;
				if (!(str.equals(str2))) {
					temp = 1;
					break;
				}
			}
		} else {
			temp = 1;
		}
		if (temp == 1) {
			logMessage("Fail: data is not present");
		}
		logMessage("Pass: data is present");
	}

	public void goToLandingPage() {
		driver.close();
		changeWindow(0);
	}

	public void launchpadWaitForLoader2() {
		try {
			wait.resetImplicitTimeout(0);
			WebElement loader = driver.findElement(By.xpath("//div[contains(@class,'loadoverlay active')]"));
			int counter = 0;
			int killTest = 0;
			do {
				counter++;
				wait.hardWait(1);
				logMessage("Waiting for loader to disappear");
				if (counter == 100) {
					killTest++;
					if (killTest == 2) {
						logMessage("Application failed to load content after second refresh");
					} else {
						counter = 0;
						driver.navigate().refresh();
						continue;
					}
				}
			} while (loader.getAttribute("class").contains("active"));
			logMessage("loader disappeared");
		} catch (AssertionError e) {
			// logMessage("loader not found");
		} catch (Exception e) {
			logMessage("[LOADER] : Not Visisble");
		} finally {
			wait.resetImplicitTimeout(60);
		}
	}

	protected boolean isElementDisplayedNoError(String elementToken, String replacement1, String replacement2) {
		return _isElementDisplayedNoError(elementToken, replacement1, replacement2);
	}

	protected boolean isElementDisplayedNoError(String elementToken, String replacement1) {
		return _isElementDisplayedNoError(elementToken, replacement1, "");
	}

	protected boolean isElementDisplayedNoError(String elementToken) {
		return _isElementDisplayedNoError(elementToken, "", "");
	}

	private boolean _isElementDisplayedNoError(String elementToken, String replacement1, String replacement2) {
		int count = 0;
		// _waitForElementToBeVisible(elementToken, replacement1, replacement2);
		count = _getCountOfElements(elementToken, replacement1, replacement2);
		// _intelligentAssertEquals(elementToken, replacement1, replacement2,
		// count, 1, "element_displayed");
		return (count == 1);
	}

	public String changeIntToString(int number) {
		String numInString = Integer.toString(number);
		return numInString;
	}

	public void goToBackPage() {
		driver.navigate().back();
	}

	protected boolean checkIfElementIsThere(String eleString) {
		boolean flag = false;
		wait.resetImplicitTimeout(2);
		// wait.resetExplicitTimeout(10);
		try {
			if (driver.findElement(getLocator(eleString)).isDisplayed()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (NoSuchElementException ex) {
			flag = false;
		}
		return flag;
	}

	protected boolean checkIfElementIsThere(String eleString, String replacement1) {
		boolean flag = false;
		wait.resetImplicitTimeout(2);
		// wait.resetExplicitTimeout(10);
		try {
			if (driver.findElement(getLocator(eleString, replacement1)).isDisplayed()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (NoSuchElementException ex) {
			flag = false;
		}
		return flag;
	}

	public void windowhandler(String elementkey) {
		String parentWindowHandler = driver.getWindowHandle(); // Store your
																// parent window
		String subWindowHandler = null;
		Set<String> handles = driver.getWindowHandles(); // get all window
															// handles
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()) {
			subWindowHandler = iterator.next();
		}
		driver.switchTo().window(subWindowHandler); // switch to popup window

		// Now you are in the popup window, perform necessary actions here

		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		element(elementkey).click();

		driver.switchTo().window(parentWindowHandler); // switch back to parent
														// window
	}

	/*
	 * By Akash Karki:: Opens new Tab on Same window, Tested for Browser 'Chrome'
	 */
	public void OpenNewTabOntheCurrentWindow() {

		String a = "window.open('about:blank','_blank');";
		((JavascriptExecutor) driver).executeScript(a);
	}

	public String GetCurrentTierOnLocalOrRemote() {
		String Env = System.getProperty("seleniumServer");
		if (Env == null) {
			return ConfigPropertyReader.getProperty("tier");
		} else {
			return System.getProperty("env");
		}
	}

	public boolean isElementNotThere(String elementToken) {
		boolean present;
		try {
			isElementDisplayed(elementToken);
			present = false;
		} catch (NoSuchElementException e) {
			present = true;
		}
		return present;
	}
}