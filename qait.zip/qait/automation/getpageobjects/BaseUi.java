/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation.getpageobjects;

import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.SeleniumWait;
import com.qait.automation.utils.YamlReader;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.ISelect;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import static com.qait.automation.TestSessionInitiator.getEnv;
import static com.qait.automation.getpageobjects.ObjectFileReader.getPageTitleFromFile;
import static com.qait.automation.utils.DataReadWrite.getProperty;
import static org.testng.Assert.assertEquals;
import static org.testng.Reporter.log;

public class BaseUi {

	WebDriver driver, driverToUploadImage;
	protected SeleniumWait wait;
	private String pageName;
	private CustomAssert customAssert;
	private static final String CHAR_LIST = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final int RANDOM_STRING_LENGTH = 5;
	protected String browser;

	protected BaseUi() {

	}

	protected BaseUi(WebDriver driver, String pageName) {
		PageFactory.initElements(driver, this);
		this.driver = driver;
		this.pageName = pageName;
		browser = (String) executeJavascript("return navigator.userAgent;");
		int timeout;
		if (System.getProperty("timeout") != null)
			timeout = Integer.parseInt(System.getProperty("timeout"));
		else
			timeout = Integer.parseInt(getProperty("Config.properties", "timeout"));
		this.wait = new SeleniumWait(driver, timeout);
		customAssert = new CustomAssert(driver);
		browser = (String) executeJavascript("return navigator.userAgent;");
	}

	protected BaseUi(WebDriver driver, WebDriver driverToUploadImage, String pageName) {
		PageFactory.initElements(driver, this);
		this.driverToUploadImage = driverToUploadImage;
		this.driver = driver;
		this.pageName = pageName;
		int timeout;
		if (System.getProperty("timeout") != null)
			timeout = Integer.parseInt(System.getProperty("timeout"));
		else
			timeout = Integer.parseInt(getProperty("Config.properties", "timeout"));
		this.wait = new SeleniumWait(driver, timeout);
		customAssert = new CustomAssert(driver);
	}

	protected String getPageTitle() {
		return driver.getTitle().trim();
	}

	public void logMessage(String string) {
		Reporter.setEscapeHtml(false);
		Reporter.log(string, true);
	}

	public String getCurrentURL() {
		return driver.getCurrentUrl();
	}

	protected void verifyPageTitleExact() {
		String pageTitle = getPageTitleFromFile(pageName);
		verifyPageTitleExact(pageTitle);
	}

	public void verifyPageTitleExactD2l() {
		String pagetitle = getPageTitleFromFile(pageName);
		assertEquals(getPageTitle(), pagetitle, "Verifying Page title to validate right " + pageName + " - ");
		log("Assertion Passed: PageTitle for " + pageName + " is exactly: '" + pagetitle + "'.");
	}

	protected void verifyPageTitleExact(String expectedPagetitle) {
		wait.waitForPageTitleToContain(expectedPagetitle);
		customAssert.customAssertEquals(getPageTitle(), expectedPagetitle,
				"Test Failed due to page title check on " + pageName);
		logMessage("Assertion Passed: PageTitle for " + pageName + " is exactly: '" + expectedPagetitle + "'");
	}

	/**
	 * Verification of the page title with the title text provided in the page
	 * object repository
	 */
	// protected void verifyPageTitleContains() {
	// String expectedPagetitle = getPageTitleFromFile(pageName).trim();
	// verifyPageTitleContains(expectedPagetitle);
	// }

	/**
	 * this method will get page title of current window and match it partially with
	 * the param provided
	 *
	 * @param expectedPagetitle
	 *            partial page title text
	 */
	protected void verifyPageTitleContains(String expectedPagetitle) {
		String actualPageTitle = getPageTitle().toLowerCase().trim();
		customAssert.customAssertTrue(actualPageTitle.contains(expectedPagetitle.toLowerCase().trim()),
				"Verifying Actual Page Title: '" + actualPageTitle + "' contains expected Page Title : '"
						+ expectedPagetitle + "'.");
		logMessage("Assertion Passed: PageTitle for " + actualPageTitle + " contains: '" + expectedPagetitle + "'.");
	}

	protected void verifyPageTitleContains() {
		String expectedPagetitle = getPageTitleFromFile(pageName).trim();
		verifyPageTitleContains(expectedPagetitle);
	}

	protected WebElement getElementByIndex(List<WebElement> elementlist, int index) {
		return elementlist.get(index);
	}

	protected WebElement getElementByExactText(List<WebElement> elementlist, String elementtext) {
		WebElement element = null;
		for (WebElement elem : elementlist) {
			if (elem.getText().equalsIgnoreCase(elementtext.trim())) {
				element = elem;
			}
		}
		// FIXME: handle if no element with the text is found in list
		if (element == null) {
		}
		return element;
	}

	protected WebElement getElementByContainsText(List<WebElement> elementlist, String elementtext) {
		WebElement element = null;
		for (WebElement elem : elementlist) {
			if (elem.getText().contains(elementtext.trim())) {
				element = elem;
			}
		}
		// FIXME: handle if no element with the text is found in list
		if (element == null) {
		}
		return element;
	}

	protected void switchToFrame(WebElement element) {
		wait.waitForElementToBeVisible(element);
		driver.switchTo().frame(element);
	}

	protected void switchToFrame2(WebElement element) {
		wait.waitForElementToBeVisible(element);
		driver.switchTo().frame(element.getAttribute("class"));
	}

	public void switchToDefaultContent() {
		try {
			driver.switchTo().defaultContent();
			hardWait(1);
		} catch (Exception e) {
             
		}
	}

	protected Object executeJavascript(String script) {
		return ((JavascriptExecutor) driver).executeScript(script);
	}

	protected Object executeJavascriptWithRep(String script, Object... args) {
		return ((JavascriptExecutor) driver).executeScript(script, args);

	}

	protected String executeJavascriptAndReturnValue(String script) {
		return (String) ((JavascriptExecutor) driver).executeScript("return " + script);
	}

	protected Boolean executeJavascriptAndReturnBooleanValue(String script) {
		return ((Boolean) ((JavascriptExecutor) driver).executeScript("return " + script)).booleanValue();
	}

	protected void hover(WebElement element) {
		Actions hoverOver = new Actions(driver);
		hoverOver.moveToElement(element).build().perform();
		logMessage("Hovered on element:" + element);
	}

	public String handleAlert() {
		isAlertPresent();
		wait.hardWait(1);
		String alertBoxText = null;
		try {
			Alert alertBox = driver.switchTo().alert();
			alertBoxText = alertBox.getText();
			alertBox.accept();
			logMessage("Alert handled...");
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logMessage("No Alert window appeared...");
			logMessage(e.getMessage());
		}
		wait.hardWait(1);
		return alertBoxText;
	}

	public void verifyAlertText(String alertTxt) {
		isAlertPresent();
		System.out.println("getAlertText():" + getAlertText());
		customAssert.customAssertTrue(getAlertText().contains(alertTxt), "Alert text is not correct");
		logMessage("'" + alertTxt + "' message displayed in alert");
	}

	public boolean isAlertPresent() {
		try {
			Alert a = new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());

			if (a != null) {
				System.out.println("Alert is present");

				return true;
			} else {
				throw new Throwable();
			}
		} catch (Throwable e) {
			System.err.println("Alert isn't present!!");
			return false;
		}

	}

	protected String getAlertText() {
		Alert alert = driver.switchTo().alert();
		String alertText = alert.getText();
		return alertText;
	}

	public WebElement expandRootElement(WebElement element) {
		WebElement ele = (WebElement) ((JavascriptExecutor) driver).executeScript("return arguments[0].shadowRoot",
				element);
		return ele;
	}

	protected void handleTwoConfirmationBoxes() {
		try {
			Alert alertBox1 = driver.switchTo().alert();
			logMessage(alertBox1.getText());
			alertBox1.accept();
			hardWait(2);
			Alert alertBox2 = driver.switchTo().alert();
			logMessage(alertBox2.getText());
			alertBox2.accept();
			hardWait(10);
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logMessage("No Alert window appeared...");
			System.out.println(e);
		}
	}

	public String handleAlert(String option) {
		isAlertPresent();
		switchToAlert();

		String alertBoxText = null;
		try {
			Alert alertBox = driver.switchTo().alert();
			alertBoxText = alertBox.getText();

			if (option.equalsIgnoreCase("Yes") || option.equalsIgnoreCase("OK")) {
				alertBox.accept();
				logMessage("Alert handled...");
			} else {
				alertBox.dismiss();
				logMessage("Alert dismissed...");
			}
			logMessage("Alert Box text: " + alertBoxText);
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logMessage("No Alert window appeared...");
		}
		return alertBoxText;
	}

	public String Conform_Alerts(String option) {
		switchToAlert();

		String alertBoxText = null;
		try {
			Alert alertBox = driver.switchTo().alert();
			alertBoxText = alertBox.getText();

			if (option.equalsIgnoreCase("Yes") || option.equalsIgnoreCase("OK")) {
				alertBox.accept();
				logMessage("Alert handled...");
			} else {
				alertBox.dismiss();
				logMessage("Alert dismissed...");
			}
			logMessage("Alert Box text: " + alertBoxText);
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logMessage("No Alert window appeared...");
		}
		return alertBoxText;
	}

	protected String declineAlert() {
		String alertBoxText = null;
		try {
			Alert alertBox = driver.switchTo().alert();
			alertBoxText = alertBox.getText();
			alertBox.dismiss();
			logMessage("Alert handled...");
			driver.switchTo().defaultContent();
		} catch (Exception e) {
			logMessage("No Alert window appeared...");
		}
		return alertBoxText;
	}

	protected Alert switchToAlert() {
		WebDriverWait wait = new WebDriverWait(driver, 8);
		return wait.until(ExpectedConditions.alertIsPresent());
	}

	public void waitForPageToLoadCompletely(String pageTitle) {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.titleContains(pageTitle));
	}

	Set<String> windows;
	String wins[];

	public void changeWindow(int i) {
		hardWait(1);
		windows = driver.getWindowHandles();
		if (i > 0) {
			for (int j = 0; j < 9; j++) {
				System.out.println("Windows: " + windows.size());
				hardWait(1);
				if (windows.size() >= 2) {
					try {
						Thread.sleep(5000);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
					break;
				}
				windows = driver.getWindowHandles();
				System.out.println("Windows After: " + windows.size());
			}
		}
		wins = windows.toArray(new String[windows.size()]);
		driver.switchTo().window(wins[i]);
		hardWait(1);
		System.out.println("Title: " + driver.switchTo().window(wins[i]).getTitle());
	}

	// added by kamini naithani
	public void closeWindowAndSwitchBackToOriginalWindow(int i) {
		closeWindow();
		changeWindow(i);
	}

	public String switchWindow() {
		String currentWindow = driver.getWindowHandle();
		Set<String> windows = driver.getWindowHandles();
		System.out.println("Windows:" + driver.getWindowHandles().size());
		for (String winHandle : windows) {
			driver.switchTo().window(winHandle);
			System.out.println("Window Switched." + driver.getTitle() + " handle window :" + driver.getWindowHandle());
		}
		return currentWindow;
	}

	public void moveToDefaultWindow(String defaultWIndow) {
		driver.close();
		driver.switchTo().window(defaultWIndow);
	}
	//////////////////////////////////

	// FIXME Remove hard Wait option
	public void hardWait(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	protected void hardWait(double seconds) {
		try {
			Thread.sleep((long) (seconds * 1000));
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

	public void closeWindow() {
		hardWait(1);
		driver.close();
	}

	protected void selectProvidedTextFromDropDown(WebElement el, String text) {
		wait.waitForElementToBeVisible(el);
		Select sel = new Select(el);
		sel.selectByVisibleText(text);
	}
	//

	protected void selectProvidedTextFromDropDownList(String id, String text) {

		Select sel = new Select(driver.findElement(By.id(id)));
		sel.selectByVisibleText(text);
	}

	protected void selectByValueFromDropDown(WebElement el, String value) {
		wait.waitForElementToBeVisible(el);
		Select sel = new Select(el);
		sel.selectByValue(value);
	}

	protected String verifySelectedTextInDropdown(WebElement el) {
		wait.waitForElementToBeVisible(el);
		Select sel = new Select(el);
		String value = sel.getFirstSelectedOption().getText();
		return value;
	}

	protected void scrollToTop() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,-10000)");
	}

	protected void scrollToBottom() {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,10000)");
	}

	protected void scrollBy(String num) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0," + num + ")");
	}

	protected void scrollDown(WebElement element) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0, -100000)");
		hardWait(5);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		hardWait(1);
		jse.executeScript("window.scrollBy(0,-350)");
		hardWait(5);
	}

	protected void scrollDownWithGivenDimension(int dimValue) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0," + dimValue + ")");
		hardWait(5);
	}

	protected void scroll(WebElement element) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}

	protected void hoverClick(WebElement element) {
		Actions hoverClick = new Actions(driver);
		hoverClick.moveToElement(element).click().build().perform();
		logMessage("Clicked on Element..");
	}

	protected void fillText(WebElement element, String text) {
		hardWait(3);
		element.click();
		element.clear();
		element.sendKeys(text);
		logMessage("Filled '" + text + "' in Text Field");
	}

	protected void selectText(WebElement element) {
		Actions action = new Actions(driver);
		action.clickAndHold(element).build().perform();
		action.release().perform();
		action.clickAndHold(element).build().perform();
		action.moveToElement(element, 0, 0).build().perform();
		action.release().build().perform();
	}

	protected boolean areHtmlTagsDisplayed(WebElement el) {
		String text = el.getText();
		String pattern = "<\\w+?>\\w+?<\\/\\w+?>|<[\\w]+?\\/>";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(text);
		if (m.find())
			return true;
		return false;
	}

	protected void isStringMatching(String actual, String expected) {
		Assert.assertEquals(actual, expected);
		logMessage("ACTUAL STRING : " + actual);
		logMessage("EXPECTED STRING : " + expected);
		logMessage("String compare Assertion passed.");
	}

	public void refreshPage() {
		driver.navigate().refresh();
		logMessage("Page refreshed by Webdriver");
		wait.waitForPageToLoadCompletely();
	}

	public void navigateBack() {
		wait.waitForPageToLoadCompletely();
		hardWait(1);
		driver.navigate().back();
		logMessage("Page has navigated back in the browser's history");
	}

	public void navigateForward() {
		driver.navigate().forward();
		logMessage("Page has navigated forward in the browser's history");
	}

	public void reloadPage() {
		driver.findElement(By.xpath("//body")).sendKeys(Keys.F5);
		wait.waitForPageToLoadCompletely();
	}

	public void reloadPageUsingJs() {
		executeJavascript("location.reload()");
		logMessage("Page reloaded using Js");
	}

	public void clearCookies() {
		driver.manage().deleteAllCookies();
	}

	public void getCookiesViaKey(String key) {
		driver.manage().getCookieNamed(key);
	}

	public void clickUsingJS(WebElement element) {
		wait.waitForElementToBeVisible(element);
		JavascriptExecutor executor = (JavascriptExecutor) driver;
		try {
			executor.executeScript("arguments[0].click();", element);

		} catch (StaleElementReferenceException sre) {
			System.out.println("Stale Exeception handled.");
			wait.hardWait(1);
			executor.executeScript("arguments[0].click();", element);

		} // end of catch
	}

	public void click(WebElement element) {
		wait.waitForPageToLoadCompletely();
		try {
			wait.waitForElementToBeVisible(element);
			if (browser.contains("Chrome"))
				new Actions(driver).click(element).build().perform();
			else
				element.click();
		} catch (StaleElementReferenceException ex1) {
			wait.waitForElementToBeVisible(element);
			scrollDown(element);
			element.click();
			logMessage("Clicked Element " + element + " after catching Stale Element Exception");
		} catch (UnhandledAlertException u) {
			handleAlert();
			element.click();
		} catch (ElementClickInterceptedException e) {
			clickUsingJS(element);
		}
	}
	public void clickMethod(WebElement element) {
		try {
			wait.waitForElementToBeVisible(element);
			wait.waitForElementToBeClickable(element);
			scroll(element);
			element.click();
			logMessage("Clicked Element " + element + " after verifying element is visible and clickable");					
		} catch (StaleElementReferenceException ex1) {
			wait.waitForElementToBeVisible(element);
			scroll(element);
			new Actions(driver).click(element).build().perform();
			logMessage("Clicked Element " + element + " after catching Stale Element Exception");
		} catch (Exception e) {
			clickUsingJS(element);
			logMessage("Clicked Element " + element + " after catching Exception");			
		}
	}
	
	public void enterText(WebElement element, String text) {
		try {
			wait.waitForElementToBeVisible(element);
			scrollDown(element);
			element.clear();
			element.sendKeys(text);
			logMessage("Entered Text '" + text + "' in Element " + element);
		} catch (StaleElementReferenceException ex1) {
			scrollDown(element);
			element.clear();
			element.sendKeys(text);
			logMessage("Entered Text '" + text + "' in Element " + element + " after catching Stale Element Exception");
		} catch (UnhandledAlertException u) {
			handleAlert();
			scrollDown(element);
			element.clear();
			element.sendKeys(text);
		}
	}

	public void hoverOverElement(WebElement ele) {
		Actions hoverOver = new Actions(driver);
		hoverOver.moveToElement(ele).build().perform();
	}

	protected void scrollDownPX(WebElement element) {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scroll(0, -100000)");
		hardWait(1);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		hardWait(1);
		jse.executeScript("window.scrollBy(0,-350)");
	}

	protected void doubleClick(WebElement element) {
		Actions act = new Actions(driver);
		act.doubleClick(element).perform();
	}

	protected boolean enterData(WebElement element, String text) {
		try {
			wait.waitForElementToBeVisible(element);
			element.click();
			element.clear();
			element.sendKeys(text);
			logMessage("Entered Text :" + text);
			return true;
		} catch (StaleElementReferenceException e) {
			wait.waitForElementToBeVisible(element);
			element.click();
			element.clear();
			element.sendKeys(text);
			logMessage("Data Entered after handling Stale Element");
			return true;
		} catch (Exception ex) {
			logMessage("In Catch Block: " + ex.getMessage());
			return false;
		}
	}

	public String getUniqueName(String name) {
		int i = YamlReader.generateRandomNumber(1, 25000);
		return name + String.valueOf(i);
	}

	protected String[] getLastNameFirstNameOfUser(String userName) {
		String[] user = userName.split(" ");
		return user;
	}

	/**
	 * This method generates random string
	 * 
	 * @return
	 */
	public String generateRandomString() {

		StringBuffer randStr = new StringBuffer();
		for (int i = 0; i < RANDOM_STRING_LENGTH; i++) {
			int number = getRandomNumber();
			char ch = CHAR_LIST.charAt(number);
			randStr.append(ch);
		}
		return randStr.toString();
	}

	/**
	 * This method generates random numbers
	 * 
	 * @return int
	 */
	public int getRandomNumber() {
		int randomInt = 0;
		Random randomGenerator = new Random();
		randomInt = randomGenerator.nextInt(CHAR_LIST.length());
		if (randomInt - 1 == -1) {
			return randomInt;
		} else {
			return randomInt - 1;
		}
	}

	public void dragAndDropElement(WebElement fromElem, WebElement toElem) {
		Actions builder = new Actions(driver);
		Action dragAndDrop = builder.clickAndHold(fromElem).moveToElement(toElem).click().release(toElem).build();
		dragAndDrop.perform();
	}

	public void dragAndDropToParticularPosition(WebElement source, int x, int y) {
		Actions builder = new Actions(driver);
		Action dragAndDrop = builder.dragAndDropBy(source, x, y).build();
		dragAndDrop.perform();
	}

	public void DragAndDropUsingAction(WebElement fromElem, WebElement toElem) {
		/*
		 * Actions builder = new Actions(driver); builder.keyDown(Keys.CONTROL)
		 * .click(fromElem) .click(toElem) .keyUp(Keys.CONTROL);
		 * 
		 * // Then get the action: Action selectMultiple = builder.build();
		 * 
		 * // And execute it: selectMultiple.perform();
		 */
		Actions builder = new Actions(driver);

		Action dragAndDrop = builder.clickAndHold(fromElem)

				.moveToElement(toElem)

				.release(toElem)

				.build();

		dragAndDrop.perform();
	}

	/**
	 * This method will select by provided index number
	 * 
	 * @param el
	 * @param index
	 */
	protected void selectByIndex(WebElement el, int index) {
		wait.waitForElementToBeVisible(el);
		Select sel = new Select(el);
		sel.selectByIndex(index);
	}

	protected String getdefaultDropDown(WebElement el) {
		wait.waitForElementToBeVisible(el);
		Select sel = new Select(el);
		return sel.getFirstSelectedOption().getText();

	}

	public void selectChoice(WebElement el) {
		wait.waitForElementToBeClickable(el);
		el.click();

	}

	public String getDefaultRadioReturnId(WebElement el) {
		wait.waitForElementToBeVisible(el);
		if (el.isSelected()) {
			System.out.println(el.getAttribute("id"));
			return el.getAttribute("id");
		} else {
			System.out.println("error");
			return null;
		}

	}

	public String getDefaultRadioReturnValue(WebElement el) {
		wait.waitForElementToBeVisible(el);
		if (el.isSelected()) {
			System.out.println(el.getAttribute("value"));
			return el.getAttribute("value");
		} else {
			System.out.println("error");
			return null;
		}

	}

	public String getDefaultRadioReturnClass(WebElement el) {
		wait.waitForElementToBeVisible(el);
		if (el.isSelected()) {
			System.out.println(el.getAttribute("class"));
			return el.getAttribute("class");
		} else {
			System.out.println("error");
			return null;
		}

	}

	public void _alertAccept() {
		driver.switchTo().alert().accept();
	}

	
	protected void scrollIntoViewUsingJavaScript(WebElement e) {
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", e);
	}
	
	protected void clickUsingJavaScript(WebElement e) {
		wait.waitForPageToLoadCompletely();
		wait.waitForElementToBeClickable(e);
		((JavascriptExecutor) driver).executeScript("arguments[0].click()", e);
	}
	
	protected void clickElementByScrollIntoView(WebElement e) {
		wait.waitForElementToBeVisible(e);
		scrollIntoViewUsingJavaScript(e);
		wait.waitForElementToBeClickable(e);
		try {
			e.click();
		} catch (StaleElementReferenceException ex1) {
			wait.waitForElementToBeVisible(e);
			scrollIntoViewUsingJavaScript(e);
			e.click();
			logMessage("Clicked Element " + e + " after catching Stale Element Exception");
		} catch (Exception ex2) {
			scrollIntoViewUsingJavaScript(e);
			e.isDisplayed();
			clickUsingJavaScript(e);
			logMessage("Element " + e + " could not be clicked using java script! " + ex2.getMessage());
		}
		wait.waitForPageToLoadCompletely();
	}

	
}