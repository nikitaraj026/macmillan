package com.qait.automation.getpageobjects;

public enum Browsers {
	firefox,FIREFOX,ff,FF,Firefox,
	chrome,CHROME,Chrome,
	IE,ie,InternetExplorer,internetexplorer,
	Safari,SAFARI,safari
}
