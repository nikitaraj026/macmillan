package com.qait.automation.getpageobjects;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.testng.Assert;

import com.qait.automation.TestSessionInitiator;

import static com.qait.automation.utils.DataReadWrite.getProperty;

/**
 * This class reads the PageObjectRepository text files. Uses buffer reader.
 *
 * @author QAIT
 *
 */
public class ObjectFileReader {

	static String tier, product;
	static String filepath = "src/test/resources/PageObjectRepository/";

	public static String[] getELementFromFile(String pageName,
			String elementName) {
		setTier();
		setProduct();
		BufferedReader br = null;
		String matchingLine = "";
		try {
			String filePathString = filepath + product + File.separator + tier
					+ File.separator + pageName + ".txt";
			File f = new File(filePathString);
			if (!f.exists()) {
//				 System.out.println("WARNING : '" + tier + "/" + pageName + ".txt' file not found");
			} else {
				br = new BufferedReader(new FileReader(filePathString));
				String line = br.readLine();
				while (line != null) {
					if (line.split(":", 3)[0].equalsIgnoreCase(elementName)) {
						matchingLine = line;
						break;
					}
					line = br.readLine();
				}
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		if (matchingLine.equals("")) {
			// System.out.println("Locator '" + elementName + "' not found in '"
			// + tier + "/" + pageName + ".txt'");
			// System.out.println("Searching for locator in 'common/" + pageName
			// + ".txt");
			try {
				String filePathString = filepath + product + File.separator
						+ "COMMON" + File.separator + pageName + ".txt";
				File f = new File(filePathString);
				if (!f.exists()) {
					// System.out.println("WARNING : 'common/" + pageName +
					// ".txt' file not found");
				} else {
					br = new BufferedReader(new FileReader(filePathString));
					String line = br.readLine();
					while (line != null) {
						if (line.split(":", 3)[0].equalsIgnoreCase(elementName)) {
							matchingLine = line;
							break;
						}
						line = br.readLine();
					}
				}
				Assert.assertTrue(!matchingLine.equals(""), "Locator Name '"
						+ elementName + "' is not present in '" + pageName
						+ ".txt' file.");
			} catch (IOException ioe) {
				ioe.printStackTrace();
			} finally {
				if (br != null) {
					try {
						br.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		return matchingLine.split(":", 3);
		// TODO: Handle Arrayoutofbounds and Filenotfound exceptions gracefully.
	}

	public static String getPageTitleFromFile(String pageName) {
		setTier();
		setProduct();
		BufferedReader br = null;
		String returnElement = "";
		try {
			br = new BufferedReader(new FileReader(filepath + product
					+ File.separator + "COMMON" + File.separator + pageName
					+ ".txt"));
			String line = br.readLine();

			while (line != null) {
				if (line.split(":", 3)[0].equalsIgnoreCase("pagetitle")
						|| line.split(":", 3)[0].equalsIgnoreCase("title")) {
					returnElement = line;
					break;
				}
				line = br.readLine();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return returnElement.split(":", 3)[1].trim();
	}

	private static void setTier() {
		if (System.getProperty("env") != null)
			tier = System.getProperty("env").toUpperCase();
		else {
			switch (Tiers.valueOf(getProperty("Config.properties", "tier"))) {
			case production:
			case PROD:
			case PRODUCTION:
			case Production:
			case prod:
				tier = "PROD";
				break;
			case pristine:
			case PR:
			case PRISTINE:
			case Pristine:
			case pr:
				tier = "PR";
				break;
			case qa:
			case QA:
			case Qa:
				tier = "QA";
				break;
			case Dev:
			case DEV:
			case dev:
				tier = "DEV";
				break;
			case lt:
			case LT:
				tier = "LT";
				break;
			case dnscutover:
				tier = "dnscutover";
				break;
			default:
				break;
			}
		}
	}

	private static void setProduct() {
		product = TestSessionInitiator.product.toUpperCase();
	}
}
