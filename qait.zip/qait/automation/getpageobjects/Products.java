package com.qait.automation.getpageobjects;

public enum Products {
	Launchpad,LAUNCHPAD,launchpad,lp,LP,
	XBOOK,Xbook,xbook,xb,XB,CMS,Sitebuilder,DAM;
}
