package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.StudentStore.keywords.*;
import com.qait.StudentStoreBackend.keywords.Backend_HomePage;
import com.qait.StudentStoreBackend.keywords.Backend_OrderPage;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;


public class StudentStoreTestInitiator extends TestSessionInitiator{

	public CustomFunctions customFunctions;
	public LoginPageActions loginPage;
	public SearchResultActions searchResultPage;
	public HomePageActions homepage;
	public CartPageActions cartPage;
	public ProductDetailsPageActions productDetailPage;
	public CheckOutPageActions checkOutpage;
	public DigitalProductPageActions digitalProductPage;
	public CatalogHomePageActions catalogHomePage;
	public RegistrationPageActions registrationPage;
	public SeamlessProductPageActions seamlessPage;
	public YopmailPageActions yopMailPage;
	private String product_local;
	
	
	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		loginPage = new LoginPageActions(driver);
		searchResultPage = new SearchResultActions(driver);
		homepage = new HomePageActions(driver);
		cartPage = new CartPageActions(driver);
		productDetailPage = new ProductDetailsPageActions(driver);
		checkOutpage = new CheckOutPageActions(driver);
		digitalProductPage = new DigitalProductPageActions(driver);
		catalogHomePage = new CatalogHomePageActions(driver);
		seamlessPage = new SeamlessProductPageActions(driver);
		registrationPage = new RegistrationPageActions(driver);
		yopMailPage = new YopmailPageActions(driver);
	}

	public StudentStoreTestInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct(){
		product_local="StudentStore";
		product = "StudentStore";
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
	}
}

