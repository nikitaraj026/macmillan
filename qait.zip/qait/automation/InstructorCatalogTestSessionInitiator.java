package com.qait.automation;

import static com.qait.automation.utils.PropFileHandler.setPropertyFilePath;
import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.InstructorCatalog.keywords.CheckoutPageAction;
import com.qait.InstructorCatalog.keywords.FindMyRepoAction;
import com.qait.InstructorCatalog.keywords.GmailPageActions;
import com.qait.InstructorCatalog.keywords.HomePageAction;
import com.qait.InstructorCatalog.keywords.LoginPageActions;
import com.qait.InstructorCatalog.keywords.MyAccountPageAction;
import com.qait.InstructorCatalog.keywords.ProductDescPageActions;
import com.qait.InstructorCatalog.keywords.RegistrationPageAction;
import com.qait.InstructorCatalog.keywords.SearchResultActions;
import com.qait.InstructorCatalog.keywords.ShoppingCartAction;
import com.qait.InstructorCatalog.keywords.YopmailPageActions;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;

public class InstructorCatalogTestSessionInitiator extends TestSessionInitiator {

	public GmailPageActions gmailPage;
	public HomePageAction homePage;
	public LoginPageActions loginPage;
	public CheckoutPageAction checkoutPage;
	public ShoppingCartAction shoppingCartPage;
	public ProductDescPageActions productDescPage;
	public RegistrationPageAction registrationPage;
	public SearchResultActions searchResult;
	public YopmailPageActions yopmailPage;
    public CustomFunctions customFunctions;
    private String product_local;
	public MyAccountPageAction myAccountPage;
	public FindMyRepoAction findmyrepo;

	private void _initPage() {
		gmailPage=new GmailPageActions(driver);
		checkoutPage = new CheckoutPageAction(driver);
		shoppingCartPage = new ShoppingCartAction(driver); 
		yopmailPage=new YopmailPageActions(driver);
		homePage=new HomePageAction(driver);
		loginPage=new LoginPageActions(driver);
		productDescPage=new ProductDescPageActions(driver);
		registrationPage=new RegistrationPageAction(driver);
		searchResult=new SearchResultActions(driver);
		myAccountPage= new MyAccountPageAction(driver);
		customFunctions=new CustomFunctions(driver);
		findmyrepo=new FindMyRepoAction(driver);
	}


    /**
     * Page object Initiation done
     */
	public InstructorCatalogTestSessionInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		setPropertyFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"),
				getDebugObjects(), TestSessionInitiator.product);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	public void setProduct(){
		product_local="InstructorCatalog";
    	product = "InstructorCatalog";
    	CustomFunctions.setProduct(product_local);
    	GetPage.setProduct(product_local);
    }
	
	
    
    
}
