package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.LayoutValidation;
import com.qait.onboarding.functional.keywords.EnrollPageActions;
import com.qait.onboarding.functional.keywords.EulaPageActions;
import com.qait.onboarding.functional.keywords.FindTitleActions;
import com.qait.onboarding.functional.keywords.FooterActions;
import com.qait.onboarding.functional.keywords.ForgotPasswordActions;
import com.qait.onboarding.functional.keywords.PurchasePageActions;
import com.qait.onboarding.functional.keywords.RegisterPageActions;
import com.qait.onboarding.layout.keywords.EulaLayout;
import com.qait.onboarding.layout.keywords.FindCourseLayout;
import com.qait.onboarding.layout.keywords.FindTitleLayout;
import com.qait.onboarding.layout.keywords.PurchaseAccessLayout;
//import com.qait.xbook.keywords.TOCPageActions;
import com.qait.onboarding.functional.keywords.TocPageAction;
import com.qait.onboarding.functional.keywords.LoginPageActions;
import com.qait.onboarding.functional.keywords.ManageProfileActions;
import com.qait.onboarding.functional.keywords.DashboardPageActions;
import com.qait.onboarding.functional.keywords.DoYouHaveAccountWithUsPageActions;
import com.qait.onboarding.functional.keywords.ExistingAccountFoundPageActions;
import com.qait.onboarding.functional.keywords.FreeTrialBegunPageActions;
import com.qait.onboarding.functional.keywords.HeaderActions;
import com.qait.onboarding.functional.keywords.InstructorAccessGrantedPageActions;
import com.qait.onboarding.functional.keywords.InstructorRegistrationPageActions;
import com.qait.onboarding.functional.keywords.RequestInstructorAccessPageActions;
import com.qait.onboarding.functional.keywords.PaywallPageActions;


public class OnboardingTestInitiator extends TestSessionInitiator{

	public CustomFunctions customFunctions;
	public FindTitleActions FindTitle;
	public FindTitleLayout findTitleLayout;
	public FindCourseLayout findCourseLayout;
	public LoginPageActions loginPage;
	public EulaPageActions eulaPage;
	public RegisterPageActions registerPage;
	public PurchasePageActions purchasePage;
	public EnrollPageActions enrollPage;
	public RequestInstructorAccessPageActions requestInstructorAccessPage;
	public InstructorRegistrationPageActions instructorRegistrationPage;
	public InstructorAccessGrantedPageActions instructorAccessGrantedPage;
	public DashboardPageActions dashboardPage;
	public HeaderActions header;
	public DoYouHaveAccountWithUsPageActions doYouHaveAccountWithUsPage;
	public FreeTrialBegunPageActions freeTrialBegunPage;
	public EulaLayout eulaLayout;
	public PurchaseAccessLayout purchaseAccessLayout;
	public ExistingAccountFoundPageActions existingAccountFoundPage;
	public ForgotPasswordActions forgotPasswordPage;
	public ManageProfileActions manageprofile;
	public FooterActions footer;
	private String product_local;
	public TocPageAction TocPageAction;
	public PaywallPageActions PaywallPageActions;
	
	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		FindTitle = new FindTitleActions(driver);
		findTitleLayout = new FindTitleLayout(driver);
		findCourseLayout = new FindCourseLayout(driver);
		loginPage = new LoginPageActions(driver);
		eulaPage = new EulaPageActions(driver);
		registerPage = new RegisterPageActions(driver);
		purchasePage = new PurchasePageActions(driver);
		enrollPage = new EnrollPageActions(driver);
		requestInstructorAccessPage = new RequestInstructorAccessPageActions(driver);
		instructorRegistrationPage = new InstructorRegistrationPageActions(driver);
		instructorAccessGrantedPage = new InstructorAccessGrantedPageActions(driver);
		dashboardPage = new DashboardPageActions(driver);
		header = new HeaderActions(driver);
		doYouHaveAccountWithUsPage = new DoYouHaveAccountWithUsPageActions(driver);
		freeTrialBegunPage = new FreeTrialBegunPageActions(driver);
		eulaLayout = new EulaLayout(driver);
		purchaseAccessLayout = new PurchaseAccessLayout(driver);
		existingAccountFoundPage = new ExistingAccountFoundPageActions(driver);
		forgotPasswordPage = new ForgotPasswordActions(driver);
		manageprofile = new ManageProfileActions(driver);
		footer = new FooterActions(driver);
		TocPageAction=new TocPageAction(driver);
		PaywallPageActions = new PaywallPageActions(driver);
	}

	public OnboardingTestInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct(){
		product_local="onboarding";
		product = "onboarding";
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
		LayoutValidation.setProduct(product_local);
	}
}

