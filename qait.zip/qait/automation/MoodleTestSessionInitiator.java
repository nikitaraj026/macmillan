package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.blackboard.keywords.CourseHomePageActionsLaunchpad;
import com.qait.moodle.keywords.FandEPageActionsLaunchpad;
import com.qait.moodle.keywords.StudentAccessGrantPageActions;
import com.qait.moodle.keywords.TokenRegistrationPageActions;
import com.qait.moodle.keywords.OnboardingPageActions;
import com.qait.moodle.keywords.CoursePageAction;
import com.qait.moodle.keywords.DashBoardPageAction;

import com.qait.moodle.keywords.LoginPageAction;
import com.qait.moodle.keywords.MacmillanHigherEducationInstructorProfileActions;
import com.qait.moodle.keywords.PXPageActions;
import com.qait.moodle.keywords.ToolsPageAction;



public class MoodleTestSessionInitiator extends TestSessionInitiator{

	public CustomFunctions customFunctions;
	public LoginPageAction loginPage;
	public DashBoardPageAction dashboardPage;
	public CoursePageAction coursePage;
	public PXPageActions pxPage;
	public ToolsPageAction toolsPage;
	public OnboardingPageActions onboardingPage;
	public StudentAccessGrantPageActions studentAccessGrantPage;
	public FandEPageActionsLaunchpad fandEPageLaunchpad;
	public MacmillanHigherEducationInstructorProfileActions MacmillanHigherEducationInstructorProfile;
	public TokenRegistrationPageActions TokenRegistration;
	private String product_local;

	private void _initPage() {
		loginPage = new LoginPageAction(driver);
		dashboardPage = new DashBoardPageAction(driver);
		coursePage = new CoursePageAction(driver);
		pxPage = new PXPageActions(driver);
		toolsPage = new ToolsPageAction(driver);
		onboardingPage = new OnboardingPageActions(driver);
		studentAccessGrantPage = new StudentAccessGrantPageActions(driver);
		fandEPageLaunchpad = new FandEPageActionsLaunchpad(driver);
		MacmillanHigherEducationInstructorProfile = new MacmillanHigherEducationInstructorProfileActions(driver);
		TokenRegistration = new TokenRegistrationPageActions(driver);
	
	}

	public MoodleTestSessionInitiator(){
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		//customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,getProduct());
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	 public void setProduct(){
		 	product_local="moodle";
	    	product = "moodle";
	    	CustomFunctions.setProduct(product_local);
	    	GetPage.setProduct(product_local);
	    	GetPage.setProduct(product_local);
	    }
}
