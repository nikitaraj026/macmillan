package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.launchpad.keywords.CourseHomePageActions;
import com.qait.launchpad.keywords.FandEPageActions;
import com.qait.moodle2.keywords.*;

public class Moodle2TestSessionInitiator extends TestSessionInitiator {

	public CustomFunctions customFunctions;
	public HomePageActions homePage;
	public LoginPageActions loginPage;
	public DashboardPageActions dashboardPage;
	public SiteAdministrationPageActions SiteAdministrationPage;
	public CoursePageActions coursePage;
	public ToolsPageActions toolsPage;
	public TokenRegistrationPageActions tokenRegistration;
	public PXPageActions pxPage;
	public OnboardingPageActions onboardingPage;
	public StudentAccessGrantPageActions studentAccessGrantPage;
	public FandEPageActions fandEPageLaunchpad;
	public GradeBookPageActions gradeBookPage;
	private String product_local;
    public CourseHomePageActions courseHomePage;
    public FandEPageActions fne;
    public SaplingStudentActions saplingStudentPage;
    
	private void _initPage() {
		fne=new FandEPageActions(driver);
		courseHomePage=new CourseHomePageActions(driver);
		customFunctions = new CustomFunctions(driver);
		loginPage = new LoginPageActions(driver);
		homePage = new HomePageActions(driver);
		dashboardPage = new DashboardPageActions(driver);
		SiteAdministrationPage = new SiteAdministrationPageActions(driver);
		coursePage = new CoursePageActions(driver);
		toolsPage = new ToolsPageActions(driver);
		tokenRegistration = new TokenRegistrationPageActions(driver);
		pxPage = new PXPageActions(driver);
		onboardingPage = new OnboardingPageActions(driver);
		studentAccessGrantPage = new StudentAccessGrantPageActions(driver);
		fandEPageLaunchpad = new FandEPageActions(driver);
		gradeBookPage = new GradeBookPageActions(driver);
	saplingStudentPage = new SaplingStudentActions(driver);
	}

	public Moodle2TestSessionInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"),
				getDebugObjects(), product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct() {
		product_local = "moodle2";
		product = "moodle2";
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
		GetPage.setProduct(product_local);
	}
}
