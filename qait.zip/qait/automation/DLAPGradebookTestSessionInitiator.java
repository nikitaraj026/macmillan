package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.LayoutValidation;
import com.qait.dlap.keywords.DropStudent;
import com.qait.dlap.keywords.ScoreDisplayOptions;
import com.qait.dlap.keywords.ShowCategoryTotals;
import com.qait.dlap.keywords.ShowInactiveEnrollments;
import com.qait.dlap.keywords.VisibleColumns;
import com.qait.dlap.keywords.VisibleFooters;

public class DLAPGradebookTestSessionInitiator extends TestSessionInitiator{
	
	public DropStudent dropStudent;
	public ScoreDisplayOptions scoredisplayoptions;
	public ShowCategoryTotals showcategorytotals;
	public ShowInactiveEnrollments showinactiveenrollments;
	public VisibleColumns visiblecolumns;
	public VisibleFooters visiblefooters;
	public CustomFunctions customFunctions;
	private String product_local;
	
	 private void _initPage() {
		 	dropStudent = new DropStudent(driver);
		 	scoredisplayoptions = new ScoreDisplayOptions(driver);
		 	showcategorytotals = new ShowCategoryTotals(driver);
		 	showinactiveenrollments = new ShowInactiveEnrollments(driver);
		 	visiblecolumns = new VisibleColumns(driver);
		 	visiblefooters = new VisibleFooters(driver);
		 	customFunctions = new CustomFunctions(driver);
	    }
	 
	 public DLAPGradebookTestSessionInitiator() {
		 super();
		 setProduct();
		 setYamlFilePath(product_local);
		 configureBrowser();
		 _initPage();
		 customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		 CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	 }
	 
	 public void setProduct(){
	    	product = "dlap";
	    	product_local="dlap";
	    	CustomFunctions.setProduct(product_local);
	    	GetPage.setProduct(product_local);
	    	LayoutValidation.setProduct(product_local);
	 }
}

