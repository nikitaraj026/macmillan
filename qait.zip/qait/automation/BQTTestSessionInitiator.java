package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import org.openqa.selenium.JavascriptExecutor;

import com.qait.BQT.keywords.CourseHomePageActions;
import com.qait.BQT.keywords.DashboardPageActions;
import com.qait.BQT.keywords.EnrollPageActions;
import com.qait.BQT.keywords.FandEPageActions;
import com.qait.BQT.keywords.HeaderPageActions;
import com.qait.BQT.keywords.LoginPageActions;
import com.qait.BQT.keywords.WelcomePageActions;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;

public class BQTTestSessionInitiator extends TestSessionInitiator{

		public CustomFunctions customFunctions;
		public LoginPageActions loginPage;
		public DashboardPageActions dashboardPage;
		public WelcomePageActions welcomePage;
		public CourseHomePageActions courseHomePage;
		public FandEPageActions fandePage;
		public HeaderPageActions headerPage;
		public EnrollPageActions enrollPage;
		private String product_local;

	    private void _initPage() {
			customFunctions = new CustomFunctions(driver);
			loginPage = new LoginPageActions(driver);
			dashboardPage = new DashboardPageActions(driver);
			courseHomePage = new CourseHomePageActions(driver);
			welcomePage = new WelcomePageActions(driver);
			fandePage = new FandEPageActions(driver);
			headerPage = new HeaderPageActions(driver);
			enrollPage = new EnrollPageActions(driver);
	    }

	    public BQTTestSessionInitiator() {
	       super();
	       setProduct();
	       setYamlFilePath(product_local);
	       configureBrowser();
	       _initPage();
	       customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,TestSessionInitiator.product);
	       CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	    }
	    
	    public void setProduct(){
	    	product_local="BQT";
	    	product = "BQT";
	    	CustomFunctions.setProduct(product_local);
	    	GetPage.setProduct(product_local);
	    }

		public void openURLInNewTab(String Url) {
			JavascriptExecutor js = (JavascriptExecutor)driver;
			js.executeScript("window.open('"+Url+"','_blank');");
		}	
}
