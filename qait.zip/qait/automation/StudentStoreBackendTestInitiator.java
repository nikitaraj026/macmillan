package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.StudentStore.keywords.HomePageActions;
import com.qait.StudentStoreBackend.keywords.Backend_BrainTree_login;
import com.qait.StudentStoreBackend.keywords.Backend_HomePage;
import com.qait.StudentStoreBackend.keywords.Backend_OrderPage;
import com.qait.StudentStoreBackend.keywords.Backend_Payment;
import com.qait.StudentStoreBackend.keywords.Backend_Pricing;
import com.qait.StudentStoreBackend.keywords.BrainTree_search;
import com.qait.StudentStoreBackend.keywords.OrderCreationAction;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;

public class StudentStoreBackendTestInitiator extends TestSessionInitiator {

	public Backend_HomePage backend_homepage;
	public Backend_OrderPage backend_order;
	public Backend_Pricing backend_pricing;
	public Backend_Payment backend_payment;
	private String product_local;
	public CustomFunctions customFunctions;
	public Backend_BrainTree_login brainTreeLogin;
	public BrainTree_search braintreeSearch;
	public OrderCreationAction orderCreation;
	
	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		backend_homepage = new Backend_HomePage(driver);
		backend_order = new Backend_OrderPage(driver);
		brainTreeLogin= new Backend_BrainTree_login(driver);
		braintreeSearch= new BrainTree_search(driver);
		backend_pricing= new Backend_Pricing(driver);
		backend_payment= new Backend_Payment(driver);
		orderCreation = new OrderCreationAction(driver);
		
	}
	
	public StudentStoreBackendTestInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct(){
		product_local="StudentStoreBackend";
		product = "StudentStoreBackend";
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
	}

}
