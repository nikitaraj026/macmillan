package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.LayoutValidation;


public class LPTestInitiator extends TestSessionInitiator {
    //LP
    public CustomFunctions customFunctions;
    public com.qait.launchpad.keywords.LoginPageActions loginPageLP;
    public com.qait.launchpad.keywords.DashboardPageActions dashboardPageLP;
    public com.qait.launchpad.keywords.WelcomePageActions welcomePageLP;
    public com.qait.launchpad.keywords.CourseHomePageActions courseHomePageLP;
    public com.qait.launchpad.keywords.FandEPageActions fnePageLP;
    public com.qait.launchpad.keywords.FandEPageQPV2Actions fnePageqpv2LP;
    public com.qait.launchpad.keywords.ResourceOverlayActions resourceOverlayLP;
    public com.qait.launchpad.keywords.InstructorConsolePageActions instructorConsolePageLP;
    public com.qait.launchpad.keywords.CalenderPageActions calendarPageLP;
    public com.qait.launchpad.keywords.UpdateProfileActions updateProfilePageLP;
    public com.qait.launchpad.keywords.ActivateCourseModalActions activatecoursemodalLP;
    public com.qait.launchpad.keywords.FindYourCoursePageActions findYourCoursePageLP;
    public com.qait.launchpad.keywords.EnrollPageActions enrollPageLP;
    public com.qait.launchpad.keywords.FooterActions footerLP;
    public com.qait.launchpad.keywords.HeaderActions headerLP;
    public com.qait.launchpad.keywords.MenuActions menuLP;
    public com.qait.launchpad.keywords.StudentGradebookPageActions studentGradebookPageLP;
    public com.qait.launchpad.keywords.MarsPageActions marsPageLP;
    public com.qait.launchpad.keywords.LearningCurveActions learningcurveLP;
    public com.qait.launchpad.keywords.LearningCurveTitleActions learningcurvetitleLP;
    public com.qait.launchpad.keywords.AssignmentSettingsActions assignmentSettingsActionsLP;
    public com.qait.launchpad.keywords.ReefActions reefLP;
    public com.qait.canvas.keywords.PXPageActions pxPageLP;

    private String product_local;

    public com.qait.launchpad.keywords.EshaTestActions eshaPageLP;
    public com.qait.launchpad.keywords.VitalSourcesActions vitalSourcesLP;
    public com.qait.launchpad.keywords.GoreactActions goreactLP;
    public com.qait.launchpad.keywords.XbookHomePageActions xbookHomePageLP;
    public com.qait.launchpad.keywords.XbookTopMenuActions xbookTopMenuLP;
    public com.qait.launchpad.keywords.XbookResourcesPageActions xbookResourcesPageLP;
    public com.qait.launchpad.keywords.XbookTOCPageActions xbookTocpageLP;
    public com.qait.launchpad.keywords.XbookAssignmentPageActions xbookAssignmentPageLP;
    public com.qait.launchpad.keywords.XbookJoinCoursePageActions xbookJoinCoursePageLP;
    public com.qait.launchpad.keywords.XbookFandEPageActions xbookFandEPageLP;
    public com.qait.launchpad.keywords.XbookSearchPageActions xbookSearchPageLP;
    public com.qait.launchpad.keywords.XbookGradebookPageActions xbookGradebookPageLP;
    public com.qait.launchpad.keywords.VideoToolPageActions videoToolPageLP;

    //qpv1
    public com.qait.QPv1.keywords.LoginPageActions loginPageQPv1;
    public com.qait.QPv1.keywords.DashboardPageActions dashboardPageQPv1;
    public com.qait.QPv1.keywords.WelcomePageActions welcomePageQPv1;
    public com.qait.QPv1.keywords.WelcomePageActions welcomePage1QPv1;
    public com.qait.QPv1.keywords.CourseHomePageActions courseHomePageQPv1;
    public com.qait.QPv1.keywords.FandEPageActions fnePageQPv1;
    public com.qait.QPv1.keywords.AssignmentSettingsActions assignmentSettingsActionsQPv1;
    public com.qait.QPv1.keywords.QuestionEditorPageAction questionEditorPageQPv1;
    public com.qait.QPv1.keywords.InstructorConsolePageActions instructorConsolePageQPv1;
    public com.qait.QPv1.keywords.CalenderPageActions calendarPageQPv1;
    public com.qait.QPv1.keywords.UpdateProfileActions updateProfilePageQPv1;
    public com.qait.QPv1.keywords.ActivateCourseModalActions activatecoursemodalQPv1;
    public com.qait.QPv1.keywords.FindYourCoursePageActions findYourCoursePageQPv1;
    public com.qait.QPv1.keywords.HeaderActions headerQPv1;
    public com.qait.QPv1.keywords.EnrollPageActions enrollPageQPv1;
    public com.qait.QPv1.keywords.MenuActions menuQPv1;
    public com.qait.QPv1.keywords.StudentGradebookPageActions studentGradebookPageQPv1;

    //qpv2 -
    public com.qait.QPv2.keywords.LoginPageActions loginPageQPv2;
    public com.qait.QPv2.keywords.DashboardPageActions dashboardPageQPv2;
    public com.qait.QPv2.keywords.WelcomePageActions welcomePageQPv2;
    public com.qait.QPv2.keywords.CourseHomePageActions courseHomePageQPv2;
    public com.qait.QPv2.keywords.FandEPageActions fnePageQPv2;
    public com.qait.QPv2.keywords.QuizPlayerActions quizPlayerQPv2;
    public com.qait.QPv2.keywords.InstructorConsolePageActions instructorConsolePageQPv2;
    public com.qait.QPv2.keywords.CalenderPageActions calendarPageQPv2;
    public com.qait.QPv2.keywords.ActivateCourseModalActions activatecoursemodalQPv2;
    public com.qait.QPv2.keywords.FindYourCoursePageActions findYourCoursePageQPv2;
    public com.qait.QPv2.keywords.HomePageActions_QBA homePage_qbaQPv2;
    public com.qait.QPv2.keywords.LoginPageActions_QBA loginPage_qbaQPv2;
    public com.qait.QPv2.keywords.MetadataconfigActions_QBA metadataConfig_qbaQPv2;
    public com.qait.QPv2.keywords.PxLaunchpad_QBA pxLaunchpad_qbaQPv2;
    public com.qait.QPv2.keywords.QuestionPageActions_QBA questionPage_qbaQPv2;
    public com.qait.QPv2.keywords.ShareQuestionAction_QBA shareQuestion_qbaQPv2;
    public com.qait.QPv2.keywords.TitlePageAction_QBA titlePage_qbaQPv2;
    public com.qait.QPv2.keywords.UserManagementActions_QBA userManagement_qbaQPv2;
    public com.qait.QPv2.keywords.MenuActions menuQPv2;
    public com.qait.QPv2.keywords.ResourceOverlayActions resourceOverlayQPv2;
    public com.qait.QPv2.keywords.EnrollPageQPv2Actions enrollPageQPv2;
    public com.qait.QPv2.keywords.AssignmentSettingsActions assignmentSettingsActionsQPv2;
    public com.qait.QPv2.keywords.StudentGradebookPageActions studentGradebookPageQPv2;
    

    private void _initPage() {
        customFunctions = new CustomFunctions(driver);
        //lp
        loginPageLP = new com.qait.launchpad.keywords.LoginPageActions(driver);
        dashboardPageLP = new com.qait.launchpad.keywords.DashboardPageActions(driver);
        welcomePageLP = new com.qait.launchpad.keywords.WelcomePageActions(driver);
        courseHomePageLP = new com.qait.launchpad.keywords.CourseHomePageActions(driver);
        fnePageLP = new com.qait.launchpad.keywords.FandEPageActions(driver);
        fnePageqpv2LP = new com.qait.launchpad.keywords.FandEPageQPV2Actions(driver);
        resourceOverlayLP = new com.qait.launchpad.keywords.ResourceOverlayActions(driver);
        instructorConsolePageLP = new com.qait.launchpad.keywords.InstructorConsolePageActions(driver);
        calendarPageLP = new com.qait.launchpad.keywords.CalenderPageActions(driver);
        updateProfilePageLP = new com.qait.launchpad.keywords.UpdateProfileActions(driver);
        activatecoursemodalLP = new com.qait.launchpad.keywords.ActivateCourseModalActions(driver);
        findYourCoursePageLP = new com.qait.launchpad.keywords.FindYourCoursePageActions(driver);
        enrollPageLP = new com.qait.launchpad.keywords.EnrollPageActions(driver);
        footerLP = new com.qait.launchpad.keywords.FooterActions(driver);
        headerLP = new com.qait.launchpad.keywords.HeaderActions(driver);
        menuLP = new com.qait.launchpad.keywords.MenuActions(driver);
        studentGradebookPageLP = new com.qait.launchpad.keywords.StudentGradebookPageActions(driver);
        marsPageLP = new com.qait.launchpad.keywords.MarsPageActions(driver);
        learningcurveLP = new com.qait.launchpad.keywords.LearningCurveActions(driver);
        learningcurvetitleLP = new com.qait.launchpad.keywords.LearningCurveTitleActions(driver);
        assignmentSettingsActionsLP = new com.qait.launchpad.keywords.AssignmentSettingsActions(driver);
        reefLP = new com.qait.launchpad.keywords.ReefActions(driver);
        eshaPageLP = new com.qait.launchpad.keywords.EshaTestActions(driver);
        vitalSourcesLP = new com.qait.launchpad.keywords.VitalSourcesActions(driver);
        goreactLP = new com.qait.launchpad.keywords.GoreactActions(driver);
        xbookHomePageLP = new com.qait.launchpad.keywords.XbookHomePageActions(driver);
        xbookTopMenuLP = new com.qait.launchpad.keywords.XbookTopMenuActions(driver);
        xbookResourcesPageLP = new com.qait.launchpad.keywords.XbookResourcesPageActions(driver);
        xbookTocpageLP = new com.qait.launchpad.keywords.XbookTOCPageActions(driver);
        xbookAssignmentPageLP = new com.qait.launchpad.keywords.XbookAssignmentPageActions(driver,originalDriver);
        xbookJoinCoursePageLP = new com.qait.launchpad.keywords.XbookJoinCoursePageActions(driver);
        xbookFandEPageLP = new com.qait.launchpad.keywords.XbookFandEPageActions(driver, originalDriver);
        xbookSearchPageLP = new com.qait.launchpad.keywords.XbookSearchPageActions(driver);
        xbookGradebookPageLP = new com.qait.launchpad.keywords.XbookGradebookPageActions(driver);
        videoToolPageLP = new com.qait.launchpad.keywords.VideoToolPageActions(driver);
        
        //qpv1
        loginPageQPv1 = new com.qait.QPv1.keywords.LoginPageActions(driver);
        dashboardPageQPv1 = new com.qait.QPv1.keywords.DashboardPageActions(driver);
        welcomePageQPv1 = new com.qait.QPv1.keywords.WelcomePageActions(driver);
        welcomePage1QPv1 = new com.qait.QPv1.keywords.WelcomePageActions(driver);
        courseHomePageQPv1 = new com.qait.QPv1.keywords.CourseHomePageActions(driver);
        fnePageQPv1 = new com.qait.QPv1.keywords.FandEPageActions(driver);
        questionEditorPageQPv1 = new com.qait.QPv1.keywords.QuestionEditorPageAction(driver);
        instructorConsolePageQPv1 = new com.qait.QPv1.keywords.InstructorConsolePageActions(driver);
        calendarPageQPv1 = new com.qait.QPv1.keywords.CalenderPageActions(driver);
        updateProfilePageQPv1 = new com.qait.QPv1.keywords.UpdateProfileActions(driver);
        activatecoursemodalQPv1 = new com.qait.QPv1.keywords.ActivateCourseModalActions(driver);
        findYourCoursePageQPv1 = new com.qait.QPv1.keywords.FindYourCoursePageActions(driver);
        headerQPv1 = new com.qait.QPv1.keywords.HeaderActions(driver);
        enrollPageQPv1 = new com.qait.QPv1.keywords.EnrollPageActions(driver);
        menuQPv1 = new com.qait.QPv1.keywords.MenuActions(driver);
        studentGradebookPageQPv1 = new com.qait.QPv1.keywords.StudentGradebookPageActions(driver);
        assignmentSettingsActionsQPv1 = new com.qait.QPv1.keywords.AssignmentSettingsActions(driver);

        //qpv2
        loginPageQPv2 = new com.qait.QPv2.keywords.LoginPageActions(driver);
        dashboardPageQPv2 = new com.qait.QPv2.keywords.DashboardPageActions(driver);
        welcomePageQPv2 = new com.qait.QPv2.keywords.WelcomePageActions(driver);
        courseHomePageQPv2 = new com.qait.QPv2.keywords.CourseHomePageActions(driver);
        fnePageQPv2 = new com.qait.QPv2.keywords.FandEPageActions(driver);
        instructorConsolePageQPv2 = new com.qait.QPv2.keywords.InstructorConsolePageActions(driver);
        calendarPageQPv2 = new com.qait.QPv2.keywords.CalenderPageActions(driver);
        activatecoursemodalQPv2 = new com.qait.QPv2.keywords.ActivateCourseModalActions(driver);
        findYourCoursePageQPv2 = new com.qait.QPv2.keywords.FindYourCoursePageActions(driver);
        homePage_qbaQPv2 = new com.qait.QPv2.keywords.HomePageActions_QBA(driver);
        loginPage_qbaQPv2 = new com.qait.QPv2.keywords.LoginPageActions_QBA(driver);
        metadataConfig_qbaQPv2 = new com.qait.QPv2.keywords.MetadataconfigActions_QBA(driver);
        pxLaunchpad_qbaQPv2 = new com.qait.QPv2.keywords.PxLaunchpad_QBA(driver);
        questionPage_qbaQPv2 = new com.qait.QPv2.keywords.QuestionPageActions_QBA(driver);
        shareQuestion_qbaQPv2 = new com.qait.QPv2.keywords.ShareQuestionAction_QBA(driver);
        titlePage_qbaQPv2 = new com.qait.QPv2.keywords.TitlePageAction_QBA(driver);
        userManagement_qbaQPv2 = new com.qait.QPv2.keywords.UserManagementActions_QBA(driver);
        resourceOverlayQPv2 = new com.qait.QPv2.keywords.ResourceOverlayActions(driver);
        menuQPv2 = new com.qait.QPv2.keywords.MenuActions(driver);
        enrollPageQPv2 = new com.qait.QPv2.keywords.EnrollPageQPv2Actions(driver);
        quizPlayerQPv2 = new com.qait.QPv2.keywords.QuizPlayerActions(driver);
        assignmentSettingsActionsQPv2 = new com.qait.QPv2.keywords.AssignmentSettingsActions(driver);
        studentGradebookPageQPv2 = new com.qait.QPv2.keywords.StudentGradebookPageActions(driver);
    }

    public LPTestInitiator() {
        super();
        setProduct();
        setYamlFilePath(product_local);

        configureBrowser();
        _initPage();
        customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
        CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
    }

    public void setProduct(){
       product_local=System.getProperty("product");
       product = System.getProperty("product");

       if(product==null) {
           product = ConfigPropertyReader.getProperty("product");
       }

       if(product_local==null) {
            product_local = ConfigPropertyReader.getProperty("product");
        }
        CustomFunctions.setProduct(product_local);
        GetPage.setProduct(product_local);
        
        
    }
}
