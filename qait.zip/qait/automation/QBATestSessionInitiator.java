/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation;

import java.util.Map;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.QBA.keywords.CourseHomePageActions_QPv2;
import com.qait.QBA.keywords.DashboardPageActions_QPv2;
import com.qait.QBA.keywords.FandEPageActions_QPv2;
import com.qait.QBA.keywords.HomePageActions;
import com.qait.QBA.keywords.ImportPageActions;
import com.qait.QBA.keywords.LoginPageActions;
import com.qait.QBA.keywords.LoginPageActions_QPv2;
import com.qait.QBA.keywords.MetadataconfigActions;
import com.qait.QBA.keywords.PxLaunchpad;
import com.qait.QBA.keywords.QuestionPageActions;
import com.qait.QBA.keywords.ShareQuestionAction;
import com.qait.QBA.keywords.TitlePageAction;
import com.qait.QBA.keywords.UserManagementActions;
import com.qait.QBA.keywords.WelcomePageActions_QPv2;
import com.qait.QBA.keywords.InstructorConsolePageActions;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.QBA.keywords.MenuActions;

public class QBATestSessionInitiator extends TestSessionInitiator{

	Map<String, Object> chromeOptions = null;
	public LoginPageActions loginPage;
	public CustomFunctions customFunctions;
	public HomePageActions homePage;
	public QuestionPageActions questionpage;
	public TitlePageAction titlepage;
	public ShareQuestionAction sharequestion;
	public MetadataconfigActions metadataconfig;
	public UserManagementActions userManage;
	public ImportPageActions importPage;
	public LoginPageActions_QPv2 loginPage_QPv2;
	public PxLaunchpad PXlaunchPad;
	public CourseHomePageActions_QPv2 courseHomePage_QPv2;
	public DashboardPageActions_QPv2 dashboardPage_QPv2;
	public FandEPageActions_QPv2 fnePage_QPv2;
	public WelcomePageActions_QPv2 welcomePage_QPv2;
	public MenuActions menu;
	public InstructorConsolePageActions instructorConsolePage;
	private String product_local;

	private void _initPage() {
		loginPage = new LoginPageActions(driver);
		customFunctions = new CustomFunctions(driver);
		homePage = new HomePageActions(driver);
		questionpage = new QuestionPageActions(driver);
		titlepage = new TitlePageAction(driver);
		sharequestion = new ShareQuestionAction(driver);
		metadataconfig = new MetadataconfigActions(driver);
		userManage = new UserManagementActions(driver);
		importPage = new ImportPageActions(driver);
		PXlaunchPad = new PxLaunchpad(driver);
		loginPage_QPv2 = new LoginPageActions_QPv2(driver);
		courseHomePage_QPv2 = new CourseHomePageActions_QPv2(driver);
		dashboardPage_QPv2 = new DashboardPageActions_QPv2(driver);
		fnePage_QPv2 = new FandEPageActions_QPv2(driver);
		welcomePage_QPv2 = new WelcomePageActions_QPv2(driver);
		menu= new MenuActions(driver);
		instructorConsolePage = new InstructorConsolePageActions(driver);
	}

	public QBATestSessionInitiator() {
		super();
		 setProduct();
		 setYamlFilePath(product_local);
		 configureBrowser();
		 _initPage();
		 customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		 CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	public void setProduct(){
		product_local="QBA";
    	product = "QBA";
    	CustomFunctions.setProduct(product_local);
    	GetPage.setProduct(product_local);
    }
}