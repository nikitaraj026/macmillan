package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.blackboard.keywords.CourseHomePageActionsLaunchpad;
import com.qait.blackboard.keywords.CoursePageAction;
import com.qait.blackboard.keywords.DashBoardPageAction;
import com.qait.blackboard.keywords.DashboardPageActionsLaunchpad;
import com.qait.blackboard.keywords.FandEPageActionsLaunchpad;
import com.qait.blackboard.keywords.FindYourCoursePageActionsLaunchpad;
import com.qait.blackboard.keywords.InstructorConsolePageActionsLaunchpad;
import com.qait.blackboard.keywords.LoginPageAction;
import com.qait.blackboard.keywords.LoginPageActionsLaunchpad;
import com.qait.blackboard.keywords.MenuActionsLaunchpad;
import com.qait.blackboard.keywords.StudentAccessGrantPageActions;
import com.qait.blackboard.keywords.SupportPageActionsCatalog;
import com.qait.blackboard.keywords.ToolsPageAction;
import com.qait.blackboard.keywords.TopMenuActions;
import com.qait.blackboard.keywords.WelcomePageActionsLaunchpad;
import com.qait.canvas.keywords.ContentTocPageActions;
import com.qait.blackboard.keywords.AchieveAdminActions;
import com.qait.blackboard.keywords.AchieveInstructorActions;
import com.qait.blackboard.keywords.AchieveStudentActions;
import com.qait.blackboard.keywords.SaplingStudentActions;
import com.qait.blackboard.keywords.OnboardingPageActions;

public class BlackBoardTestSessionInitiator extends TestSessionInitiator{
	public LoginPageAction loginPage;
	public DashBoardPageAction dashboardPage;
	public CoursePageAction coursePage;
	public ToolsPageAction toolsPage;
	public CustomFunctions customFunctions;
	public ContentTocPageActions contentTocPage;
	public LoginPageActionsLaunchpad loginPageLaunchpad;
	public TopMenuActions topMenu;
	public DashboardPageActionsLaunchpad dashBoardPageLaunchpad;
	public WelcomePageActionsLaunchpad welcomePageLaunchpad;
	public CourseHomePageActionsLaunchpad courseHomePageLaunchpad;
	public FindYourCoursePageActionsLaunchpad findYourCoursePageLaunchpad;
	public FandEPageActionsLaunchpad fandEPageLaunchpad;
	public InstructorConsolePageActionsLaunchpad instructorConsolePageLaunchpad;
	public MenuActionsLaunchpad menuLaunchpad;
	public StudentAccessGrantPageActions studentAccessGrantPage;
	public AchieveStudentActions achieveStudentPage;
	public AchieveInstructorActions achieveInstructorPage;
	public SaplingStudentActions saplingStudentPage;
	public AchieveAdminActions achieveAdminPage;
	public OnboardingPageActions onboardingPage;
	
	public SupportPageActionsCatalog supportPageActionsCatalog;
	private String product_local;

	private void _initPage(){
		loginPage = new LoginPageAction(driver);
		dashboardPage = new DashBoardPageAction(driver);
		coursePage = new CoursePageAction(driver);
		toolsPage = new ToolsPageAction(driver);
		studentAccessGrantPage = new StudentAccessGrantPageActions(driver);
		customFunctions = new CustomFunctions(driver);
		
		loginPageLaunchpad = new LoginPageActionsLaunchpad(driver);
		topMenu = new TopMenuActions(driver);
		dashBoardPageLaunchpad = new DashboardPageActionsLaunchpad(driver);
		welcomePageLaunchpad = new WelcomePageActionsLaunchpad(driver);
		courseHomePageLaunchpad = new CourseHomePageActionsLaunchpad(driver);
		menuLaunchpad = new MenuActionsLaunchpad(driver);
		findYourCoursePageLaunchpad = new FindYourCoursePageActionsLaunchpad(driver);
		fandEPageLaunchpad = new FandEPageActionsLaunchpad(driver);
		instructorConsolePageLaunchpad = new InstructorConsolePageActionsLaunchpad(driver);
		
		onboardingPage = new OnboardingPageActions(driver);
		achieveStudentPage= new AchieveStudentActions(driver);
		achieveInstructorPage = new AchieveInstructorActions(driver);
		supportPageActionsCatalog = new SupportPageActionsCatalog(driver);
	    saplingStudentPage= new SaplingStudentActions(driver);
	    achieveAdminPage = new AchieveAdminActions(driver);
	    contentTocPage =new ContentTocPageActions(driver);
	}

	public BlackBoardTestSessionInitiator(){
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}


	public void setProduct(){
		product_local=System.getProperty("product");
		product = System.getProperty("product");

		if(product==null) {
		product = ConfigPropertyReader.getProperty("product");
		}

		if(product_local==null) {
		product_local = ConfigPropertyReader.getProperty("product");
		}
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
		}
	public static String getCurrentDateWithTime() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy");
		String strDate = formatter.format(date);
		SimpleDateFormat formatter1 = new SimpleDateFormat("HHmmss");
		String time = formatter1.format(date);
		return strDate + "_" + time;
	}
}
