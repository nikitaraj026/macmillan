/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;

import org.json.JSONObject;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;
import com.qait.automation.getpageobjects.Browsers;

public class WebDriverFactory {

	private static String browser, seleniumServer, product;
	private static String chromeDriverPath = "src/test/resources/Driver/chromedriver";
	private static String firefoxDriverPath = "src/test/resources/Driver/geckodriver";
	private static String iEDriverPath = "src/test/resources/drivers/IEDriverServer";
	private static DesiredCapabilities capabilities = new DesiredCapabilities();
	private static String firefoxProfilePath = "C:/selenium/FirefoxProfile";
	private String seleniumhubaddress;

	public WebDriver getDriver(Map<String, String> seleniumconfig) {
		browser = System.getProperty("browser");
		product = System.getProperty("product");
		seleniumServer = System.getProperty("seleniumServer");
		if (browser == null)
			browser = seleniumconfig.get("browser").toString();
		if (seleniumServer == null)
			seleniumServer = seleniumconfig.get("seleniumserver").toString();
		if (seleniumServer.equalsIgnoreCase("remote")) {
			return setRemoteDriver(seleniumconfig);
		} else {
			switch (Browsers.valueOf(browser)) {
			case firefox:
			case FIREFOX:
				if (System.getProperty("os.name").toUpperCase().equals("LINUX")) {
					return getFirefoxDriver(firefoxDriverPath);
				} else
					return getFirefoxDriver(firefoxDriverPath + ".exe");
			case chrome:
			case CHROME:
			case Chrome:
				if (System.getProperty("os.name").toUpperCase().equals("LINUX")) {
					return getChromeDriver(chromeDriverPath);
				} else {
					return getChromeDriver(chromeDriverPath + ".exe");
				}
			case ie:
			case IE:
			case InternetExplorer:
			case internetexplorer:
				return getInternetExplorerDriver(iEDriverPath + ".exe");
			case Safari:
			case SAFARI:
			case safari:
				return getSafariDriver();
			default:
				return new FirefoxDriver();
			}
		}
	}

	private WebDriver setRemoteDriver(Map<String, String> selConfig) {
		DesiredCapabilities cap = null;
		browser = System.getProperty("browser");
		if (browser == null)
			browser = selConfig.get("browser").toString();
		if (browser.equalsIgnoreCase("firefox")) {
			cap = DesiredCapabilities.firefox();
		} else if (browser.equalsIgnoreCase("chrome")) {
			cap = DesiredCapabilities.chrome();
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--start-maximized");

			Map<String, Object> prefs = new HashMap<String, Object>();
			prefs.put("credentials_enable_service", false);
			prefs.put("profile.password_manager_enabled", false);
			prefs.put("download.prompt_for_download", false);
			String downloadFilepath = "C:" + File.separator + "IMSCFILES";
			System.out.println(downloadFilepath);
			prefs.put("download.default_directory", downloadFilepath);
			options.setExperimentalOption("prefs", prefs);
			cap.setCapability(ChromeOptions.CAPABILITY, options);

			LoggingPreferences logPrefs = new LoggingPreferences();
			logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
			cap.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);

		} else if (browser.equalsIgnoreCase("Safari")) {
			cap = DesiredCapabilities.safari();
		} else if ((browser.equalsIgnoreCase("ie")) || (browser.equalsIgnoreCase("internetexplorer"))
				|| (browser.equalsIgnoreCase("internet explorer"))) {
			cap = DesiredCapabilities.internetExplorer();
		}
		seleniumhubaddress = System.getProperty("hub");
		if (seleniumhubaddress == null) {
			if (selConfig.get("seleniumserverhost1") == null) {
				seleniumhubaddress = selConfig.get("seleniumserverhost2");
			} else
				seleniumhubaddress = selConfig.get("seleniumserverhost1");
		} else {
			if (System.getProperty("hub").equals("hub1"))
				seleniumhubaddress = selConfig.get("seleniumserverhost1");
			else if (System.getProperty("hub").equals("hub2"))
				seleniumhubaddress = selConfig.get("seleniumserverhost2");
		}
		URL selserverhost = null;
		try {
			System.out.println("seleniumhubaddress: " + seleniumhubaddress);
			selserverhost = new URL(seleniumhubaddress);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		cap.setJavascriptEnabled(true);

//		getCurrentSystemInfo(selserverhost, cap);

		RemoteWebDriver rm = new RemoteWebDriver(selserverhost, cap);
		return rm;

	}

	private static WebDriver getChromeDriver(String driverpath) {
		System.setProperty("webdriver.chrome.driver", driverpath);
		File dirFile = new File("C:" + File.separator + "IMSCFILES");
		dirFile.mkdir();
//		System.out.println("dir path :" + dirFile.getAbsolutePath());
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("same-site-by-default-cookies", true);
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", dirFile.getAbsolutePath());
		chromePrefs.put("profile.default_content_setting_values.plugins", 1);
		chromePrefs.put("profile.content_settings.plugin_whitelist.adobe-flash-player", 1);
		chromePrefs.put("profile.content_settings.exceptions.plugins.*,*.per_resource.adobe-flash-player", 1);
		ChromeOptions options = new ChromeOptions();
		HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();

		chromePrefs.put("credentials_enable_service", false);
		chromePrefs.put("profile.password_manager_enabled", false);

		options.addArguments("--start-maximized");
		options.setExperimentalOption("prefs", chromePrefs);
		options.addArguments("--test-type");
		options.addArguments("--disable-extensions");

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setJavascriptEnabled(true);
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptionsMap);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		capabilities.setCapability("acceptInsecureCerts", true);
		LoggingPreferences logPrefs = new LoggingPreferences();
		logPrefs.enable(LogType.PERFORMANCE, Level.ALL);
		capabilities.setCapability(CapabilityType.LOGGING_PREFS, logPrefs);

		options.addArguments("--start-maximized");

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		prefs.put("excludeSwitches", Collections.singletonList("enable-automation"));
		prefs.put("download.default_directory", dirFile.getAbsolutePath());

		options.setExperimentalOption("prefs", prefs);
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		capabilities.setJavascriptEnabled(true);

		return new ChromeDriver(capabilities);
	}

	private static WebDriver getInternetExplorerDriver(String driverpath) {
		System.setProperty("webdriver.ie.driver", driverpath);
		capabilities.setCapability("ignoreZoomSetting", true);
		capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		// capabilities.setJavascriptEnabled(true);
		// capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS,
		// true);
		return new InternetExplorerDriver();
	}

	private static WebDriver getSafariDriver() {
		return new SafariDriver();
	}

	/**
	 * For Techtool We have to set the firefox profile and need AutoAuth xpi
	 * AutoAuth is a firefox add on
	 *
	 * @return
	 */

//    private static WebDriver getFirefoxDriver() {
//        FirefoxProfile profile;
//        if (TestSessionInitiator.product.equalsIgnoreCase("techtool")) {
//            String autoAuthPath = "src/test/resources/Techtool-testdata/autoauth-2.1-fx+fn.xpi";
//
//            // Path of Firefox Profile having 'AutoAuth' extension to it
//            File firefoxProfile = new File(firefoxProfilePath);
//            profile = new FirefoxProfile(firefoxProfile);
//
//            // Path of AutoAuth file i.e., in the project
//            File extension = new File(autoAuthPath);
//            try {
//                profile.addExtension(extension);
//            } catch (IOException e) {
//            }
//        } else {
//            profile = new FirefoxProfile();
//        }
//        profile.setPreference("browser.cache.disk.enable", false);
//        profile.setPreference("dom.max_chrome_script_run_time", 20);
//        profile.setPreference("dom.max_script_run_time", 0);
//        return new FirefoxDriver(profile);
//    }

	private static WebDriver getFirefoxDriver(String driverpath) {
		System.setProperty("webdriver.gecko.driver", driverpath);
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities = DesiredCapabilities.firefox();
		capabilities.setBrowserName("firefox");
		// capabilities.setVersion("set your version");
		capabilities.setPlatform(Platform.WINDOWS);
		capabilities.setCapability("marionette", false);
		return new FirefoxDriver();
	}

	private void getCurrentSystemInfo(URL selserverhost, DesiredCapabilities cap) {
		RestAssured rspec = new RestAssured();
		String gridURL = seleniumhubaddress.split("//wd")[0];
		Response rs = rspec.given().get(
				gridURL + "/grid/api/testsession?session=" + new RemoteWebDriver(selserverhost, cap).getSessionId())
				.then().extract().response();
		JSONObject js = new JSONObject(rs.asString());
		System.out.println("Node: " + js.get("proxyId").toString());
	}

	public WebDriver getDriverInDubugMode() {
		// Change chrome driver path accordingly
		System.setProperty("webdriver.chrome.driver", chromeDriverPath + "" + ".exe");
		ChromeOptions options = new ChromeOptions();

		options.addArguments("test-type");
		options.addArguments("disable-popup-blocking");

		// DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		capabilities.setCapability("applicationCacheEnabled", false);

		options.setExperimentalOption("debuggerAddress", "127.0.0.1:9222");
		return new ChromeDriver(options);
	}
}