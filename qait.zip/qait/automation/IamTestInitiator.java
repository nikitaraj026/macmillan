package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.iam.keywords.ForgotPasswordActions;
import com.qait.iam.keywords.LoginPageActions;
import com.qait.iam.keywords.NewStudentRegistrationActions;


public class IamTestInitiator extends TestSessionInitiator{

	public CustomFunctions customFunctions;
	public LoginPageActions loginPage;
	public ForgotPasswordActions forgotPasswordPage;
	public NewStudentRegistrationActions newStudentRegistrationPage;
	private String product_local;
	
	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		loginPage = new LoginPageActions(driver);
		forgotPasswordPage = new ForgotPasswordActions(driver);
		newStudentRegistrationPage = new NewStudentRegistrationActions(driver);;
	}

	public IamTestInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct(){
		product_local="iam";
		product = "iam";
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
	}
}

