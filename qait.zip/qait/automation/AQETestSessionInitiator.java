/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import com.qait.AQE.keywords.AqeStudentPreviewPageActions;
import com.qait.AQE.keywords.CourseHomePageActions;
import com.qait.AQE.keywords.CreateCourseModalActions;
import com.qait.AQE.keywords.DashboardPageActions;
import com.qait.AQE.keywords.EnrollCoursePageAction;
import com.qait.AQE.keywords.FnEPageActions;
import com.qait.AQE.keywords.IndexPageActions;
import com.qait.AQE.keywords.LoginPageActions;
import com.qait.AQE.keywords.QuestionEditorPageAction;
import com.qait.AQE.keywords.WelcomePageActions;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;


import com.qait.automation.utils.CustomFunctions;

/**
 * 
 * @author prashantshukla
 */

public class AQETestSessionInitiator extends TestSessionInitiator{

	public LoginPageActions loginPage;
	public IndexPageActions indexPage;
	public DashboardPageActions dashboard;
	public CreateCourseModalActions createcoursemodal;
	public WelcomePageActions welcomepage;
	public CourseHomePageActions coursehomepage;
	public FnEPageActions fnepage;
	public QuestionEditorPageAction questioneditor;
	public AqeStudentPreviewPageActions studentpreviewpage;
	public EnrollCoursePageAction enrollcoursepage;
	public CustomFunctions customFunctions;
	private String product_local;

	private void _initPage() {
		loginPage = new LoginPageActions(driver);
		indexPage = new IndexPageActions(driver);
		dashboard = new DashboardPageActions(driver);
		createcoursemodal = new CreateCourseModalActions(driver);
		welcomepage = new WelcomePageActions(driver);
		coursehomepage = new CourseHomePageActions(driver);
		fnepage = new FnEPageActions(driver);
		questioneditor = new QuestionEditorPageAction(driver);
		studentpreviewpage = new AqeStudentPreviewPageActions(driver);
		enrollcoursepage = new EnrollCoursePageAction(driver);
		customFunctions = new CustomFunctions(driver);
	}

	public AQETestSessionInitiator() {
		 super();
		 setProduct();
		 setYamlFilePath(product_local);
		 configureBrowser();
		 _initPage();
		 customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		 CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	public void setProduct(){
		product_local="AQE";
    	product = "AQE";
    	CustomFunctions.setProduct(product_local);
    	GetPage.setProduct(product_local);
    }

}