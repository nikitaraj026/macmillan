package com.qait.automation.report;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.ISuiteResult;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.collections.Lists;
import org.testng.internal.Utils;
import org.testng.log4testng.Logger;
import org.testng.xml.XmlSuite;

/**
 * Reporter that generates a single-page HTML report of the suite test results.
 * <p>
 * Based on TestNG built-in implementation:
 * org.testng.reporters.EmailableReporter2
 * </p>
 */
public class CustomReport_Old implements IReporter {

	private static final Logger LOG = Logger.getLogger(CustomReport_Old.class);
	private static String timeZone = "GMT-4:00";
	private static SimpleDateFormat sdfdate = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat sdftime = new SimpleDateFormat("HH:mm:ss a");
	private static String outFilename = "Test_Automation_Report.html";
	private static NumberFormat integerFormat = NumberFormat
			.getIntegerInstance();
	protected PrintWriter writer;
	protected List<SuiteResult> suiteResults = Lists.newArrayList();
	private StringBuilder buffer = new StringBuilder();
	private String htmlContent = "";

	@Override
	public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites,
			String outputDirectory) {
		try {
			writer = createWriter(outputDirectory);
		} catch (IOException e) {
			LOG.error("Unable to create output file", e);
			return;
		}
		for (ISuite suite : suites) {
			suiteResults.add(new SuiteResult(suite));
		}

		writeDocumentStart();
		writeHead();
		writeBody();
		writeDocumentEnd();
		writer.print(htmlContent);
		writer.close();
	}

	protected PrintWriter createWriter(String outdir) throws IOException {
		new File(outdir).mkdirs();
		return new PrintWriter(new BufferedWriter(new FileWriter(new File(
				outdir, outFilename))));
	}

	protected void writeDocumentStart() {
		htmlContent += "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">";
		htmlContent += "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
	}

	protected void writeHead() {
		htmlContent += "<head>";
		htmlContent += "<title>Test Automation Report</title>";
		writeStylesheet();
		htmlContent += "</head>";
	}

	protected void writeStylesheet() {
		htmlContent += "<style type=\"text/css\">";
		htmlContent += ".divClass {padding-top: 8px; padding-bottom: 15px; border-radius: 15px; padding:10px;} .div1 { width: 200px} .table_data tr:nth-child(even) td{background-color: #58F723;} .table_data tr:nth-child(odd) td{background-color: #58F723;} h1, h3, table { font-family: 'Arial', Helvetica, sans-serif; } h1,h3 {padding-left: 5px;} .pass {background-color: #58F723; color: #000000;} .skip {background-color: #F3F781; color: #000000;} .fail {background-color: #F54848; color: #000000;} .total {background-color: #7A99F6; color: #000000;} .table_head {background-color: #7A99F6; color: #000000;} .table_data tr td.fail { background-color: #F54848; color: #000000; } table { border: 2px solid black; border-spacing: 3px; width: inherit; } table td { text-align: center; } .suitename {background-color: #EEEFEF; color: #000000;} table tr td:first-child { text-align: left; font-weight: bold; padding-left: 5px; padding-right: 5px; } .table_data tr:first-child th{padding-left: 5px; padding-right: 5px;}";
		htmlContent += "</style>";
	}

	protected void writeBody() {
		htmlContent += "<body>";
		writeReportTitle("Test Automation Report");
		writeSuiteSummary();
		htmlContent += "</body>";
	}

	protected void writeReportTitle(String title) {
		// htmlContent += "<h1>" + title + " - " + getDateAsString() + "</h1>" ;
		// htmlContent += "<hr width='100%' />";
	}

	protected void writeDocumentEnd() {
		htmlContent += "</html>";
	}

	protected void writeSuiteSummary() {
		int totalPassedTests = 0;
		int totalSkippedTests = 0;
		int totalFailedTests = 0;
		@SuppressWarnings("unused")
		long totalDuration = 0;

		String secondTable = "";

		secondTable += "<h3>Test Script Result Summary</h3>";
		secondTable += "<div class='divClass'>";
		secondTable += "<table class='table_data'>";
		secondTable += "<tr class='table_head'><th>Tests</th><th>Passed</th><th>Skipped</th><th>Failed</th></tr>";

		int testIndex = 0;
		for (SuiteResult suiteResult : suiteResults) {
			secondTable += "<tr class='table_head'><th colspan='4', class='suitename'>";
			secondTable += Utils.escapeHtml(suiteResult.getSuiteName());
			secondTable += "</th></tr>";

			for (TestResult testResult : suiteResult.getTestResults()) {
				int passedTests = testResult.getPassedTestCount();
				int skippedTests = testResult.getSkippedTestCount();
				int failedTests = testResult.getFailedTestCount();
				long duration = testResult.getDuration();

				secondTable += "<tr>";
				buffer.setLength(0);
				if (failedTests > 0)
					secondTable += "<td class='fail'>";
				else
					secondTable += "<td>";
				secondTable += Utils.escapeHtml(testResult.getTestName())
						.toString();
				secondTable += "</td>";

				if (failedTests > 0)
					secondTable += "<td class='fail'>";
				else
					secondTable += "<td>";
				secondTable += integerFormat.format(passedTests) + "</td>";
				if (failedTests > 0)
					secondTable += "<td class='fail'>";
				else
					secondTable += "<td>";
				secondTable += integerFormat.format(skippedTests) + "</td>";
				if (failedTests > 0)
					secondTable += "<td class='fail'>";
				else
					secondTable += "<td>";
				secondTable += integerFormat.format(failedTests) + "</td>";
				secondTable += "</tr>";

				totalPassedTests += passedTests;
				totalSkippedTests += skippedTests;
				totalFailedTests += failedTests;
				totalDuration += duration;

				testIndex++;
			}
		}

		// Print totals if there was more than one test
		if (testIndex >= 1) {
			secondTable += "<tr class='table_head'><th>Total</th>";
			secondTable += "<th>" + integerFormat.format(totalPassedTests)
					+ "</th>";
			secondTable += "<th>" + integerFormat.format(totalSkippedTests)
					+ "</th>";
			secondTable += "<th>";
			secondTable += integerFormat.format(totalFailedTests) + "</th>";
			secondTable += "</tr>";
		}

		secondTable += "</table></div>";
		secondTable += "<hr width='100%; />";

		String firstTable = "";
		firstTable += "<h3>Overall Report Summary</h3><div class='divClass div1'><table>";
		firstTable += "<tr class='pass'><td>Passed</td><th>"
				+ integerFormat.format(totalPassedTests) + "</th></tr>";
		firstTable += "<tr class='skip'><td>Skipped</td><th>"
				+ integerFormat.format(totalSkippedTests) + "</th></tr>";
		firstTable += "<tr class='fail'><td>Failed</td><th>"
				+ integerFormat.format(totalFailedTests) + "</th></tr>";
		firstTable += "<tr class='total'><td>Total</td><th>"
				+ integerFormat.format(totalPassedTests + totalSkippedTests
						+ totalFailedTests) + "</th></tr>";

		firstTable += "</table></div><hr width='100%' /> ";
		htmlContent += firstTable + secondTable;
	}

	/**
	 * Groups {@link TestResult}s by suite.
	 */
	protected static class SuiteResult {
		private final String suiteName;
		private final List<TestResult> testResults = Lists.newArrayList();

		public SuiteResult(ISuite suite) {
			suiteName = suite.getName();
			for (ISuiteResult suiteResult : suite.getResults().values()) {
				testResults.add(new TestResult(suiteResult.getTestContext()));
			}
		}

		public String getSuiteName() {
			return suiteName;
		}

		/**
		 * @return the test results (possibly empty)
		 */
		public List<TestResult> getTestResults() {
			return testResults;
		}
	}

	/**
	 * Groups {@link ClassResult}s by test, type (configuration or test), and
	 * status.
	 */
	protected static class TestResult {
		/**
		 * Orders test results by class name and then by method name (in
		 * lexicographic order).
		 */
		protected static final Comparator<ITestResult> RESULT_COMPARATOR = new Comparator<ITestResult>() {
			@Override
			public int compare(ITestResult o1, ITestResult o2) {
				int result = o1.getTestClass().getName()
						.compareTo(o2.getTestClass().getName());
				if (result == 0) {
					result = o1.getMethod().getMethodName()
							.compareTo(o2.getMethod().getMethodName());
				}
				return result;
			}
		};

		private final String testName;
		private final List<ClassResult> failedConfigurationResults;
		private final List<ClassResult> failedTestResults;
		private final List<ClassResult> skippedConfigurationResults;
		private final List<ClassResult> skippedTestResults;
		private final List<ClassResult> passedTestResults;
		private final int failedTestCount;
		private final int skippedTestCount;
		private final int passedTestCount;
		private final long duration;
		private final String includedGroups;
		private final String excludedGroups;

		public TestResult(ITestContext context) {
			testName = context.getName();

			Set<ITestResult> failedConfigurations = context
					.getFailedConfigurations().getAllResults();
			Set<ITestResult> failedTests = context.getFailedTests()
					.getAllResults();
			Set<ITestResult> skippedConfigurations = context
					.getSkippedConfigurations().getAllResults();
			Set<ITestResult> skippedTests = context.getSkippedTests()
					.getAllResults();
			Set<ITestResult> passedTests = context.getPassedTests()
					.getAllResults();

			failedConfigurationResults = groupResults(failedConfigurations);
			failedTestResults = groupResults(failedTests);
			skippedConfigurationResults = groupResults(skippedConfigurations);
			skippedTestResults = groupResults(skippedTests);
			passedTestResults = groupResults(passedTests);

			failedTestCount = failedTests.size();
			skippedTestCount = skippedTests.size();
			passedTestCount = passedTests.size();

			duration = context.getEndDate().getTime()
					- context.getStartDate().getTime();

			includedGroups = formatGroups(context.getIncludedGroups());
			excludedGroups = formatGroups(context.getExcludedGroups());
		}

		/**
		 * Groups test results by method and then by class.
		 */
		protected List<ClassResult> groupResults(Set<ITestResult> results) {
			List<ClassResult> classResults = Lists.newArrayList();
			if (!results.isEmpty()) {
				List<MethodResult> resultsPerClass = Lists.newArrayList();
				List<ITestResult> resultsPerMethod = Lists.newArrayList();

				List<ITestResult> resultsList = Lists.newArrayList(results);
				Collections.sort(resultsList, RESULT_COMPARATOR);
				Iterator<ITestResult> resultsIterator = resultsList.iterator();
				assert resultsIterator.hasNext();

				ITestResult result = resultsIterator.next();
				resultsPerMethod.add(result);

				String previousClassName = result.getTestClass().getName();
				String previousMethodName = result.getMethod().getMethodName();
				while (resultsIterator.hasNext()) {
					result = resultsIterator.next();

					String className = result.getTestClass().getName();
					if (!previousClassName.equals(className)) {
						// Different class implies different method
						assert !resultsPerMethod.isEmpty();
						resultsPerClass.add(new MethodResult(resultsPerMethod));
						resultsPerMethod = Lists.newArrayList();

						assert !resultsPerClass.isEmpty();
						classResults.add(new ClassResult(previousClassName,
								resultsPerClass));
						resultsPerClass = Lists.newArrayList();

						previousClassName = className;
						previousMethodName = result.getMethod().getMethodName();
					} else {
						String methodName = result.getMethod().getMethodName();
						if (!previousMethodName.equals(methodName)) {
							assert !resultsPerMethod.isEmpty();
							resultsPerClass.add(new MethodResult(
									resultsPerMethod));
							resultsPerMethod = Lists.newArrayList();

							previousMethodName = methodName;
						}
					}
					resultsPerMethod.add(result);
				}
				assert !resultsPerMethod.isEmpty();
				resultsPerClass.add(new MethodResult(resultsPerMethod));
				assert !resultsPerClass.isEmpty();
				classResults.add(new ClassResult(previousClassName,
						resultsPerClass));
			}
			return classResults;
		}

		public String getTestName() {
			return testName;
		}

		/**
		 * @return the results for failed configurations (possibly empty)
		 */
		public List<ClassResult> getFailedConfigurationResults() {
			return failedConfigurationResults;
		}

		/**
		 * @return the results for failed tests (possibly empty)
		 */
		public List<ClassResult> getFailedTestResults() {
			return failedTestResults;
		}

		/**
		 * @return the results for skipped configurations (possibly empty)
		 */
		public List<ClassResult> getSkippedConfigurationResults() {
			return skippedConfigurationResults;
		}

		/**
		 * @return the results for skipped tests (possibly empty)
		 */
		public List<ClassResult> getSkippedTestResults() {
			return skippedTestResults;
		}

		/**
		 * @return the results for passed tests (possibly empty)
		 */
		public List<ClassResult> getPassedTestResults() {
			return passedTestResults;
		}

		public int getFailedTestCount() {
			return failedTestCount;
		}

		public int getSkippedTestCount() {
			return skippedTestCount;
		}

		public int getPassedTestCount() {
			return passedTestCount;
		}

		public long getDuration() {
			return duration;
		}

		public String getIncludedGroups() {
			return includedGroups;
		}

		public String getExcludedGroups() {
			return excludedGroups;
		}

		/**
		 * Formats an array of groups for display.
		 */
		protected String formatGroups(String[] groups) {
			if (groups.length == 0) {
				return "";
			}

			StringBuilder builder = new StringBuilder();
			builder.append(groups[0]);
			for (int i = 1; i < groups.length; i++) {
				builder.append(", ").append(groups[i]);
			}
			return builder.toString();
		}
	}

	/**
	 * Groups {@link MethodResult}s by class.
	 */
	protected static class ClassResult {
		private final String className;
		private final List<MethodResult> methodResults;

		/**
		 * @param className
		 *            the class name
		 * @param methodResults
		 *            the non-null, non-empty {@link MethodResult} list
		 */
		public ClassResult(String className, List<MethodResult> methodResults) {
			this.className = className;
			this.methodResults = methodResults;
		}

		public String getClassName() {
			return className;
		}

		/**
		 * @return the non-null, non-empty {@link MethodResult} list
		 */
		public List<MethodResult> getMethodResults() {
			return methodResults;
		}
	}

	/**
	 * Groups test results by method.
	 */
	protected static class MethodResult {
		private final List<ITestResult> results;

		/**
		 * @param results
		 *            the non-null, non-empty result list
		 */
		public MethodResult(List<ITestResult> results) {
			this.results = results;
		}

		/**
		 * @return the non-null, non-empty result list
		 */
		public List<ITestResult> getResults() {
			return results;
		}
	}

	/*
	 * Methods to improve time display on report
	 */
	protected String getDateAsString() {
		Date date = new Date();
		sdfdate.setTimeZone(TimeZone.getTimeZone(timeZone));
		return sdfdate.format(date);
	}

	protected String parseUnixTimeToTimeOfDay(long unixSeconds) {
		Date date = new Date(unixSeconds);
		sdftime.setTimeZone(TimeZone.getTimeZone(timeZone));
		return sdftime.format(date);
	}

	protected double millisecondsToSeconds(long ms) {
		return new BigDecimal((ms / 1000.00) / 60.00).setScale(2,
				RoundingMode.HALF_UP).doubleValue();
	}

}
