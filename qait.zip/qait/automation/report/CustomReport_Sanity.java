package com.qait.automation.report;

import com.qait.automation.TestSessionInitiator;
import com.qait.automation.utils.CustomFunctions;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import java.io.*;

public class CustomReport_Sanity {

	private static final Logger LOG = Logger.getLogger(CustomReport_Automation_New.class);
	    private static String product[]={"launchpad","qpv1","qpv2","QBA","onboarding"};
	    private static String suiteName[]={"SanityTest","Prod_SanityTest","Qpv2_Sanity_Test","Prod Sanity","On-Boarding Pre Test Suite"};
	    private static String env, browser;
	    private static String outFilename = "Sanity_Automation_Report.html";
	    private static String ftpUrl, ftpUserID, ftpPass;
	    private static String Exec_details[][]=new String[5][8];
	    private static String prev_Exec_details[][]=new String[5][8];
	    private static String htmlContent = "";
	    protected static PrintWriter writer;
	    
	    public static void initVars()
	    {
	    	 ftpUrl = TestSessionInitiator.getFTPUrl();
	         ftpUserID = TestSessionInitiator.getFTPUserID();
	         ftpPass = TestSessionInitiator.getFTPPassword();
	         env=System.getProperty("env");
	         browser = System.getProperty("browser");
	    }
	    
	    private static String[] getCurrentExecDetails(String product, String suiteName) {
			String dirPath = "/selenium/test/automation/executions/";
			String fileName = product + "_" + env + "_" + suiteName +".csv";
			String[] currFileData = null;
			
			boolean isFilePresent = CustomFunctions.checkFTPFileExists(dirPath, fileName);
			System.out.println("IsFilePresent? " +isFilePresent);
			if (isFilePresent) {
				String ftpFilePath = "ftp://" + ftpUserID + ":" + ftpPass + "@" + ftpUrl + dirPath + fileName;
				String fileData = CustomFunctions.getLinesFromFTPFile(ftpFilePath).trim();
				currFileData = fileData.split(",");
			}
			return currFileData;
		}
	    
	    private static String[] getPreviousExecDetails(String product) {
			String dirPath = "C:\\Program Files (x86)\\Jenkins\\jobs\\Consolidated_Sanity_Test\\workspace";
			String fileName = "Prev_Exec_Details_"+product+"_"+env+".csv";
			String[] prevFileData = null;
			FileReader fr;
			BufferedReader br;
			String fileData="";
			try {

				//br = new BufferedReader(new FileReader(FILENAME));
				fr = new FileReader(fileName);
				br = new BufferedReader(fr);

				String sCurrentLine;

				while ((sCurrentLine = br.readLine()) != null) {
					fileData+=sCurrentLine.trim()+"\n";
				}
				br.close();

			} catch (IOException e) {

				e.printStackTrace();

			}
			
				prevFileData = fileData.split(",");
			
			return prevFileData;
		}
	   
	    @Test
	    public static void main() throws IOException
	    {
	    	initVars();
	    	for(int i=0;i<5;i++)
	    	{
	    		Exec_details[i]=getCurrentExecDetails(product[i],suiteName[i]);
	    		prev_Exec_details[i]=getPreviousExecDetails(product[i]);
	    	}
	    	for(int i=0;i<5;i++)
	    		{for(int j=0;j<8;j++)
	    			{ Exec_details[i][j]=Exec_details[i][j].trim();
	    			prev_Exec_details[i][j]=prev_Exec_details[i][j].trim();
	    			System.out.print(Exec_details[i][j]+"\t\t");}
	    		System.out.println();}
	    	
	    	try {
	            writer = createWriter("./test-output/");
	        } catch ( IOException e ) {
	            LOG.error( "Unable to create output file", e );
	            return;
	        }
	    	
	    	writeDocumentStart();
	    	writeHead();
	    	writeBody();
	    	writeDocumentEnd();
	    	 writer.print(htmlContent);
	         writer.close();
	    	
	    }
	    
	    protected static PrintWriter createWriter(String outdir) throws IOException {
	        new File(outdir).mkdirs();
	        return new PrintWriter( new BufferedWriter( new FileWriter( new File( outdir, "Sanity_Automation_Report_"+env+".html" ) ) ) );
	    }
	    
	    protected static void writeDocumentStart() {
	        htmlContent += "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">";
	        htmlContent += "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
	    }

	    protected static void writeHead() {
	    	htmlContent += "<head>";
	    	htmlContent += "<title>" + "Consolidated Sanity Test Report</title>";
	        writeStylesheet();
	        htmlContent += "</head>";
	    }
	    
		protected static void writeStylesheet() {
	        htmlContent += "<style type=\"text/css\">";
	        htmlContent += ".graphDiv { position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto; } .graphDiv .bar { display: block; position: relative; color: #333; height: 1em; line-height: 1em; } table td{ border: 0px; } table th{ border: 0px; } .graphDiv .skip { background: #ffff99; border: 1px solid #cccc00; } .graphDiv .fail { background: #ff9999; border: 1px solid #cc0000; } .graphDiv .pass { background: #99ff99; border: 1px solid #00cc00; } .graphDiv .total { background: #9999ff; border: 1px solid #0000cc; } table td{ border: 0px; } table th{ border: 0px; }  .exec_field { background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle; } .bug_table { background: #ffffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle; } .exec_value { background: #a8ffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle; } .relative_right { position:absolute; right: 5px; } .relative_left { position:absolute; left: 5px; } .float_left { float: left; text-align: left; } .float_right { float: right; text-align: right; } strong { font-size: 13.5; } strong, table, p {font-family: 'Century Gothic', CenturyGothic, Geneva, AppleGothic, sans-serif;} .graph .bar span { position: absolute; left: 1em; } .note{ font-size: 10; } .heading{ font-size: 20; } .sectionHeading{ font-size: 16; }  a{ color: #2A5DB0; text-decoration: none; } img { display: block; padding:0px; margin: 0px; -moz-box-sizing: border-box; box-sizing: border-box; height: 480px; width: 480px; no-repeat} ";
	        htmlContent += "</style>";
	    }

	    protected static void writeBody() throws IOException {
	        htmlContent += "<body>";
	        htmlContent += writeSuiteSummary();
	        htmlContent += "</body>";
	    }

	    protected static void writeDocumentEnd() {
	        htmlContent += "</html>";
	    }
	    
	    protected static String writeSuiteSummary() throws IOException {
	    	String str = "";
	  for(int i=0;i<5;i++)
	  {
//	    	createPieChart(Exec_details,i,product[i],env);
			str += "<table><tr><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'>Project</td>";
			str += "<td style='background: #a8ffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><div><strong class='bar float_left'>" + product[i] + "</strong></div></td></tr>";
			
			str += "<tr><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'>Environment</td>";
			if(env.equals("lt"))
			str += "<td style='background: #a8ffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><div><strong class='bar float_left'>Loadtest</strong></div></td></tr>";
			else
				str += "<td style='background: #a8ffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><div><strong class='bar float_left'>Production</strong></div></td></tr>";
			
//			str += "<td class='buildInfoTD'>Show Build Info<span><table class='buildInfo'><tr><th>Build Name</th><th>Version</th></tr>";
//			str += getBuildInfoHTMLTableData(buildVersions);
//			str += "</tr></table></span></td></tr>";
			
			str += "<tr><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'>Browser</td>";
			str += "<td style='background: #a8ffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><div><strong class='bar float_left'>" + browser + "</strong></div></td></tr>";
			str += "<tr><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'>Test Suite</td>";
			str += "<td style='background: #a8ffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><div><strong class='bar float_left'>" + suiteName[i] + "</strong></div></td></tr>";
			
//			str += "<tr><td class='exec_field'>Total</td>";
//			str += "<td class='exec_value'><div><strong class='bar float_left'>" + Exec_details[i][3] + "</strong></div></td></tr>";
//			
//			str += "<tr><td class='exec_field'>Passed</td>";
//			str += "<td class='exec_value'><div><strong class='bar float_left'>" + Exec_details[i][0] + "</strong></div></td></tr>";
//			
//			str += "<tr><td class='exec_field'>Failed</td>";
//			str += "<td class='exec_value'><div><strong class='bar float_left'>" + Exec_details[i][1] + "</strong></div></td></tr>";
//			
//			str += "<tr><td class='exec_field'>Skipped</td>";
//			str += "<td class='exec_value'><div><strong class='bar float_left'>" + Exec_details[i][2] + "</strong></div></td></tr>";
//			
//			str += "<tr><td class='exec_field'>Known Failures</td>";
//			str += "<td class='exec_value'><div><strong class='bar float_left'>" + Exec_details[i][4] + "</strong></div></td></tr>";
			
			str += "<tr><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'>Date</td>";
			str += "<td style='background: #a8ffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><div><strong class='bar float_left'>" + Exec_details[i][5] +","+ Exec_details[i][6]+","+Exec_details[i][7] + "</strong></div></td></tr>";
			
			str += "</table>";
			str += "</br><hr width='100%' /></br>";
			
			str+= createExecutionsComparisonChart(product[i],env,i)+"</br>";
			
	//		str +="<table><tr><td><img src='cid:./test-output/Sanity_Pie_Charts_"+product[i]+"_"+env+".jpeg' width='480' height='480' alt='no piechart available'></td></tr></table></br><hr width='100%' />";
	  }
	  
	  	str+="<div><h2 style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><strong>Known Issues Summary</strong></h3></div>";
	  	str+= "<table><tr><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><strong>Bug ID</strong></td>";
	  	str+= "<td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><strong>Summary</strong></td>";
	  	str+= "<td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><strong>Priority</strong></td></tr>";
	  	str+= "<tr><td style='background: #ffffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle' ><strong><a href=\"https://macmillanlearning.atlassian.net/browse/LP-406\">LP-406</a></strong></td>";
	  	str+= "<td style='background: #ffffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><strong>[Production Bug][Footers]Incorrect copyrights year '© 2015 Macmillan, all rights reserved.' is appearing instead of '© 2017 Macmillan, all rights reserved (Refer Observation)</strong></td>";
	  	str+= "<td style='background: #ffffff; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle'><strong>Minor</strong></td></tr></table></br>";
	  return str;
}
	    
	    public static String createExecutionsComparisonChart(String product, String env,int i)
	    {
	    	String details="";
	    	int curr_total=Integer.parseInt(Exec_details[i][3]);
	    	int curr_pass=Integer.parseInt(Exec_details[i][0]);
	    	int curr_fail=Integer.parseInt(Exec_details[i][2]);
	    	int curr_skip=Integer.parseInt(Exec_details[i][1]);
	    	int prev_total=Integer.parseInt(prev_Exec_details[i][3]);
	    	int prev_pass=Integer.parseInt(prev_Exec_details[i][0]);
	    	int prev_fail=Integer.parseInt(prev_Exec_details[i][2]);
	    	int prev_skip=Integer.parseInt(prev_Exec_details[i][1]);
	    	 int currTotalPercent = (int)Math.round(curr_total * 100.0/curr_total);
	         int currPassPercent = (int)Math.round(curr_pass * 100.0/curr_total);
	         int currSkipPercent = (int)Math.round(curr_skip * 100.0/curr_total);
	         int currFailPercent = (int)Math.round(curr_fail * 100.0/curr_total);
	     
	         int prevTotalPercent = (int)Math.round(prev_total * 100.0/prev_total);
	         int prevPassPercent = (int)Math.round(prev_pass * 100.0/prev_total);
	         int prevSkipPercent = (int)Math.round(prev_skip * 100.0/prev_total);
	         int prevFailPercent = (int)Math.round(prev_fail * 100.0/prev_total);
	         
	         details += "<table>";
	         details += "<tr><td align='center'><b>&#8656; Current Execution</b></td><td></td>"
	         		+ "<td align='center'><b>Previous Execution &#8658;</b></td></tr>";
	         
	         details += writeHorizontalGraph_Total("total", "Total", Integer.toString(currTotalPercent), 
		        		Integer.toString(curr_total), Integer.toString(prevTotalPercent), prev_Exec_details[i][3]);
		        details += writeHorizontalGraph_Pass("pass", "Passed", Integer.toString(currPassPercent), 
		        		Integer.toString(curr_pass), Integer.toString(prevPassPercent), prev_Exec_details[i][0]);
		        details += writeHorizontalGraph_Skip("skip", "Skipped", Integer.toString(currSkipPercent), 
		        		Integer.toString(curr_skip), Integer.toString(prevSkipPercent), prev_Exec_details[i][1]);
		        details += writeHorizontalGraph_Fail("fail", "Total Failed", Integer.toString(currFailPercent), 
		        		Integer.toString(curr_fail), Integer.toString(prevFailPercent), prev_Exec_details[i][2]);
		        if(product.equals("onboarding"))
		        	details += writeCompareData("Known Failures", "1", "1");
		        else
		        details += writeCompareData("Known Failures", Exec_details[i][4], prev_Exec_details[i][4]);
		        details += "<tr height='5px'></tr>";
		        details += writeCompareData("Date",Exec_details[i][6].trim() + ", " + Exec_details[i][7].trim(), prev_Exec_details[i][6].trim() + ", " + prev_Exec_details[i][7].trim());
		        details += writeCompareData("Time", Exec_details[i][5].trim(), prev_Exec_details[i][5].trim());
		        
		        details += "</table>";
		        details += "<hr width='100%' />";
		        
		        return details;
	    }
	    
	    /**
	     * Draw a comparison chart between current and previous execution
	     */
	    private static String writeHorizontalGraph_Total(String className, String field, String currPercent, String currValue, 
				String prevPercent, String prevValue) {
			String str = "";
			str += "<tr><td><div style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
			str += "<strong style='background: #9999ff; border: 1px solid #0000cc; width: " + currPercent + "%; float: right; text-align: right; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
			str += "<strong style='float: right; text-align: right; position:absolute; right: 5px;'>" + currValue + "</strong>";
	        str += "</div></td><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle;'>" + field + "</td><td><div class='graphDiv'style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
	        str += "<strong style='background: #9999ff; border: 1px solid #0000cc; width: " + prevPercent + "%; float: left; text-align: left; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
	        str += "<strong style='float: left; text-align: left; position:absolute; left: 5px;'>" + prevValue + "</strong>";
	        str += "</div></td></tr>";
			return str;
		}	
	    /**
	     * Draw a comparison chart between current and previous execution
	     */
	    private static String writeHorizontalGraph_Pass(String className, String field, String currPercent, String currValue, 
				String prevPercent, String prevValue) {
			String str = "";
			str += "<tr><td><div style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
			str += "<strong style='background: #99ff99; border: 1px solid #00cc00; width: " + currPercent + "%; float: right; text-align: right; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
			str += "<strong style='float: right; text-align: right; position:absolute; right: 5px;'>" + currValue + "</strong>";
	        str += "</div></td><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle;'>" + field + "</td><td><div style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
	        str += "<strong style='background: #99ff99; border: 1px solid #00cc00; width: " + prevPercent + "%; float: left; text-align: left; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
	        str += "<strong style='float: left; text-align: left; position:absolute; left: 5px;'>" + prevValue + "</strong>";
	        str += "</div></td></tr>";
			return str;
		}	
	    /**
	     * Draw a comparison chart between current and previous execution
	     */
	    private static String writeHorizontalGraph_Skip(String className, String field, String currPercent, String currValue, 
				String prevPercent, String prevValue) {
			String str = "";
			str += "<tr><td><div style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
			str += "<strong style='background: #ffff99; border: 1px solid #cccc00; width: " + currPercent + "%; float: right; text-align: right; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
			str += "<strong style='float: right; text-align: right; position:absolute; right: 5px;'>" + currValue + "</strong>";
	        str += "</div></td><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle;'>" + field + "</td><td><div style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
	        str += "<strong style='background: #ffff99; border: 1px solid #cccc00; width: " + prevPercent + "%; float: left; text-align: left; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
	        str += "<strong style='float: left; text-align: left; position:absolute; left: 5px;'>" + prevValue + "</strong>";
	        str += "</div></td></tr>";
			return str;
		}	
	    /**
	     * Draw a comparison chart between current and previous execution
	     */
	    private static String writeHorizontalGraph_Fail(String className, String field, String currPercent, String currValue, 
				String prevPercent, String prevValue) {
			String str = "";
			str += "<tr><td><div style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
			str += "<strong style='background: #ff9999; border: 1px solid #cc0000; width: " + currPercent + "%; float: right; text-align: right; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
			str += "<strong style='float: right; text-align: right; position:absolute; right: 5px;'>" + currValue + "</strong>";
	        str += "</div></td><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle;'>" + field + "</td><td><div style='position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto;'>";
	        str += "<strong style='background: #ff9999; border: 1px solid #cc0000; width: " + prevPercent + "%; float: left; text-align: left; display: block; position: relative; color: #333; height: 1em; line-height: 1em;'></strong>";
	        str += "<strong style='float: left; text-align: left; position:absolute; left: 5px;'>" + prevValue + "</strong>";
	        str += "</div></td></tr>";
			return str;
		}	
	    
	    private static String writeCompareData(String field, String currData, String prevData) {
			String str = "";
			str += "<tr><td><div>";
			str += "<strong style='display: block; position: relative; color: #333; height: 1em; line-height: 1em; float: right; text-align: right;'>" + currData + "</strong>";
			str += "</div></td><td style='background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle;'>" + field + "</td><td><div>";
			str += "<strong style='display: block; position: relative; color: #333; height: 1em; line-height: 1em; float: left; text-align: left;'>" + prevData + "</strong>";
			str += "</div></td></tr>";
			return str;
		}
	    
	    
	    
	    /**
	     * Method to create pie chart for each execution 
	     */
//	    public static void createPieChart(String[][] exec_details, int i, String product, String env) throws IOException
//	    {
//	    	 DefaultPieDataset dataset = new DefaultPieDataset( );
//	         dataset.setValue("Passed-"+exec_details[i][0], Integer.parseInt(exec_details[i][0]) );
//	         dataset.setValue("Failed-"+exec_details[i][2], Integer.parseInt(exec_details[i][2]) );
//	         dataset.setValue("Skipped-"+exec_details[i][1], Integer.parseInt(exec_details[i][1]) );
//
//	         JFreeChart chart = ChartFactory.createPieChart(
//	            product+"_"+env+"sanity_results, Total Cases="+exec_details[i][3],   // chart title
//	            dataset,          // data
//	            true,             // include legend
//	            true,
//	            false);
//
//	         int width = 640;   /* Width of the image */
//	         int height = 480;  /* Height of the image */
//	         File pieChart = new File( "./test-output/Sanity_Pie_Charts_"+product+"_"+env+".jpeg");
//	         ChartUtilities.saveChartAsJPEG( pieChart , chart , width , height );
//	    }
	    
}
