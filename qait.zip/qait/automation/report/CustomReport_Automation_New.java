package com.qait.automation.report;

import com.qait.automation.TestSessionInitiator;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.DataReadWrite;
import com.qait.automation.utils.YamlReader;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.util.SystemOutLogger;
import org.testng.*;
import org.testng.collections.Lists;
import org.testng.log4testng.Logger;
import org.testng.xml.XmlSuite;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/**
 * Custom Reporter for all the products
 */
public class  CustomReport_Automation_New implements IReporter {

    private static final Logger LOG = Logger.getLogger(CustomReport_Automation_New.class);
    private static String product, env, browser, testXML = System.getProperty("testXml"), browserVersion;
    private static String outFilename = "Test_Automation_Report.html";
    private boolean useFTP;
    private static String ftpUrl, ftpUserID, ftpPass;
    @SuppressWarnings("unused")
	private static NumberFormat integerFormat = NumberFormat.getIntegerInstance();
    protected PrintWriter slackWriter, sendHTMLReportToSlack = null;
    protected PrintWriter writer, writer_sanity = null;
    protected List<SuiteResult> suiteResults = Lists.newArrayList();
    @SuppressWarnings("unused")
	private StringBuilder buffer = new StringBuilder();
    private String htmlContent = "";
//    String currBuild = System.getProperty("buildName");
//    String currBuildVersion = System.getProperty("buildVersion");

    @Override
    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites,
                               String outputDirectory) {
        System.out.println("Generating Custom Report...");
        useFTP = TestSessionInitiator.isFtpUseAllowed();
        ftpUrl = TestSessionInitiator.getFTPUrl();
        ftpUserID = TestSessionInitiator.getFTPUserID();
        ftpPass = TestSessionInitiator.getFTPPassword();
//        System.out.println("=================================");
//        System.out.println("useFTP : " + useFTP);
//        System.out.println("ftpUrl : " + ftpUrl);
//        System.out.println("ftpUserID : " + ftpUserID);
//        System.out.println("ftpPass : " + ftpPass);
//        System.out.println("=================================");

    	product = TestSessionInitiator.product;
        env = YamlReader.getTier();
        browser = System.getProperty("browser");
        if (System.getProperty("testXml") == null) {browser = new TestSessionInitiator().getBrowser();
        testXML = DataReadWrite.getProperty("./Config.properties","testXML");}
        
    	try {
            writer = createWriter(outputDirectory);
			slackWriter = createWriter(outputDirectory);

//			if(new TestSessionInitiator().getSeleniumServer().equalsIgnoreCase("remote"))
//			sendHTMLReportToSlack = sendHTMLReportToSlack();
//            if(testXML.equals("TestNG_PX_Prod_Sanity.xml")||testXML.equals("TestNG_QPv1_Prod_Sanity.xml")
//            		||testXML.equals("TestNG_QBA_Prod_Sanity.xml")||testXML.equals("TestNG_QPv2_Prod_Sanity.xml")
//            		||testXML.equals("TestNG_Onboarding_Prod_Sanity.xml"))
//            	writer_sanity=createWriterSanity();

        } catch ( IOException e ) {
            LOG.error( "Unable to create output file", e );
            return;
        }
        for ( ISuite suite : suites ) {
            suiteResults.add( new SuiteResult( suite ) );
        }

        writeDocumentStart();
        writeHead();
        try {
			writeBody();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        writeDocumentEnd();
        writer.print(htmlContent);
        writer.close();
  //      if(!writer_sanity.equals(null))
//        	if(testXML.equals("TestNG_PX_Prod_Sanity.xml")||testXML.equals("TestNG_QPv1_Prod_Sanity.xml")
//            		||testXML.equals("TestNG_QBA_Prod_Sanity.xml")||testXML.equals("TestNG_QPv2_Prod_Sanity.xml")
//            		||testXML.equals("TestNG_Onboarding_Prod_Sanity.xml"))
//        {
//        	writer_sanity.print(htmlContent);
//        	writer_sanity.close();
//        }
        	if(new TestSessionInitiator().getSeleniumServer().equalsIgnoreCase("remote"))
        	{
		sendHTMLReportToSlack.print(htmlContent);
		sendHTMLReportToSlack.close();
        	}
    }

 
	protected PrintWriter createWriter(String outdir) throws IOException {   
        new File(outdir).mkdirs();
        return new PrintWriter( new BufferedWriter( new FileWriter( new File( outdir, outFilename ) ) ) );
    }
    
    protected PrintWriter createWriterSanity() throws IOException {
   	 {
        String outDir2="C:\\Program Files (x86)\\Jenkins\\jobs\\Consolidated_Sanity_Test\\workspace";
      return  new PrintWriter( new BufferedWriter( new FileWriter( new File( outDir2, product+"_"+env+"_TestAutomationReport.html" ) ) ) );}
      }

	protected PrintWriter sendHTMLReportToSlack()	throws IOException	{
		{
    	String outDir3 = "C:\\Program Files (x86)\\Jenkins\\jobs\\TestAutomationResults_SlackEmail\\workspace";
		return  new PrintWriter( new BufferedWriter( new FileWriter( new File( outDir3, product+"_"+env+"_TestAutomationReport.html" ) ) ) );}
	}

    protected void writeDocumentStart() {
        htmlContent += "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.1//EN\" \"http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd\">";
        htmlContent += "<html xmlns=\"http://www.w3.org/1999/xhtml\">";
    }

    protected void writeHead() {
    	htmlContent += "<head>";
    	htmlContent += "<title>" + getDisplayProduct() + " Test Automation Report</title>";
        writeStylesheet();
        htmlContent += "</head>";
    }

    private String getDisplayProduct() {
		String dispProd = product;
		if (product.equals("aqe")) dispProd = "AQE";
		else if (product.equals("bqt")) dispProd = "BQT";
		else if (product.equals("canvas")) dispProd = "Canvas";
		else if (product.equals("d2l")) dispProd = "D2L";
		else if (product.equals("homework")) dispProd = "Homework";
		else if (product.equals("howlifeworks")) dispProd = "How Life Works";
		else if (product.equals("launchpad")) dispProd = "Launchpad";
		else if (product.equals("learningcurve")) dispProd = "LearningCurve";
		else if (product.equals("onboarding")) dispProd = "Onboarding : Phase II";
		else if (product.equals("qba")) dispProd = "QBA";
		else if (product.equals("techtool")) dispProd = "TechTool";
		else if (product.equals("xbook")) dispProd = "XBook";
		else if (product.equals("moodle")) dispProd = "Moodle";
		else if (product.equals("highschool")) dispProd = "Highschool";
		else if (product.equals("iam")) dispProd = "IAM";
		else if (product.equals("Student Store")) dispProd = "Student Store";
		else if (product.equals("clever")) dispProd = "Clever";
		else if (product.equals("clever2")) dispProd = "Clever";
		return dispProd;
	}
    
    private String getDisplayEnv() {
		String dispEnv = env;
		if (env.equals("mice")) dispEnv = "Mice";
		else if (env.equals("dev")) dispEnv = "Dev";
		else if (env.equals("qa")) dispEnv = "QA";
		else if (env.equals("pr")) dispEnv = "Pristine";
		else if (env.equals("prod")) dispEnv = "Production";
		else if (env.equals("lt")) dispEnv = "Load Test";
		return dispEnv;
	}
    
    private String getDisplayBrowser() {
		String dispBrowser = browser;
		if (browser.equals("firefox")) dispBrowser = "Firefox 65.0.1";
		else if (browser.equals("chrome")) dispBrowser = "Chrome 71.0";
		return dispBrowser;
	}

	protected void writeStylesheet() {
        htmlContent += "<style type=\"text/css\">";
        htmlContent += ".graphDiv { position: relative; width: 200px; border: 0px; padding: 2px; overflow:auto; } .graphDiv .bar { display: block; position: relative; color: #333; height: 1em; line-height: 1em; } table td{ border: 0px; } table th{ border: 0px; } .graphDiv .skip { background: #ffff99; border: 1px solid #cccc00; } .graphDiv .fail { background: #ff9999; border: 1px solid #cc0000; } .graphDiv .pass { background: #99ff99; border: 1px solid #00cc00; } .graphDiv .total { background: #9999ff; border: 1px solid #0000cc; } .exec_field { background: #d9d9d9; border: 1px solid #666666; text-align: center; padding-left: 10px; padding-right: 10px; padding-top: 2px; padding-bottom: 2px; font-size: 14; height: 1.3em; line-height: 1.3em; vertical-align: middle; } .relative_right { position:absolute; right: 5px; } .relative_left { position:absolute; left: 5px; } .float_left { float: left; text-align: left; } .float_right { float: right; text-align: right; } strong { font-size: 13.5; } strong, table, p {font-family: 'Century Gothic', CenturyGothic, Geneva, AppleGothic, sans-serif;} .graph .bar span { position: absolute; left: 1em; } .note{ font-size: 10; } .heading{ font-size: 20; } .sectionHeading{ font-size: 16; } .scriptTable{ border-collapse: collapse; font-size: 13; border-spacing: 0px; } .scriptTable td{ border: 1px solid #666666; padding-left: 6px; padding-right: 6px; padding-top: 2px; padding-bottom: 2px; } .scriptTable th{ border: 1px solid #666666; padding-left: 6px; padding-right: 6px; padding-top: 2px; padding-bottom: 2px; } a{ color: #2A5DB0; text-decoration: none; } .buildInfoTD{ font-size: 14; color: #2A5DB0; } td.buildInfoTD span table { border-collapse: collapse; font-size: 12; border-spacing: 0px; margin-left: 6px; background: #ffffff; } td.buildInfoTD span table td{ border: 1px solid #666666; padding-left: 6px; padding-right: 6px; padding-top: 2px; padding-bottom: 2px; } td.buildInfoTD span table th{ border: 1px solid #666666; padding-left: 6px; padding-right: 6px; padding-top: 2px; padding-bottom: 2px; } td.buildInfoTD:hover {text-decoration:none;} td.buildInfoTD span { z-index:10;display:none; padding:0px 0px; margin-top:-0px; margin-left:0px; } .screenshot { height: 12px; } .noDetails{ font-size: 14;} td.buildInfoTD:hover > span{position:absolute;display:inline;} td.buildInfoTD > span table{border: 1px;} .scriptTable table.noborder_error td.buildInfoTD{border: 0px;} .scriptTable table.noborder_error td span table{border: 1px; width: 300px;} p.errorMessage {word-wrap: break-word; width:300px;} img { display: block; color:transparent; padding:0px; margin: 0px; -moz-box-sizing: border-box; box-sizing: border-box; height: 20px; width: 24px; background: url(http://testcafe.devexpress.com/Content/images/doc/UsingTestCafe/ControlPanel/Results/view-screenshot-button.png) no-repeat}";
        htmlContent += "</style>";
    }

    protected void writeBody() throws IOException {
        htmlContent += "<body>";
        writeSuiteSummary();
        htmlContent += "</body>";
    }

    protected void writeDocumentEnd() {
        htmlContent += "</html>";
    }

    @SuppressWarnings({ "rawtypes", "unused" })
	protected void writeSuiteSummary() throws IOException {
    	System.out.println("Fetching Data...");
    	// Set failed execution details file path. This is S: drive for remote machines and User's Desktop when executed locally
		String dirPath = "C:";
		File f = new File(dirPath);
		if (!f.exists()) dirPath = System.getProperty("user.home") + File.separator + "Desktop";
		
    	HashMap<String, String> hm = getFailedTestDetails(dirPath + File.separator + product + ".csv");
    	System.out.println("Failed test details:"+ hm.keySet());
    	System.out.println("Failed test details:"+ hm.values());
    	HashMap<String, String> knownFailures = getKnownFailureDetails();
    	
    	List<String> affectingBuilds = getAffectingBuildList();
    	HashMap<String, String> buildVersions = getBuildVersions(affectingBuilds);
    	System.out.println("Test");
    	for (String name: buildVersions.keySet()){

            String key =name.toString();
            String value = buildVersions.get(name).toString();  
            System.out.println(key + " " + value);  
    	}
    	System.out.println("Test End");
    	/*
    	 * scripRemarks would contain final Failing Scripts data to be used in creating Custom Report
    	 * failingScriptName > [New or Known Failure Info, '|' separated Screenshot URL's, '|||' separated failureReasons]
    	 */
    	HashMap<String, String[]> scriptRemarks = new HashMap<String, String[]>();
    	
    	String[] prevExecData = getPrevExecDetails();
    	
    	/*
    	 * Creates a mapping of Test Name with Test Script Name
    	 */
    	HashMap<String, String> testScripts = new HashMap<String, String>();
    	String testngXMLFilePath = "src" + File.separator + "test" + File.separator + 
    			"resources" + File.separator + "testngxmls" + File.separator + product;
    	List<String> testngFiles = getTestngFiles(testngXMLFilePath + File.separator + testXML);
		if (testngFiles.size() > 0) {
			for (String testngFile : testngFiles) {
				testScripts.putAll(getTestVsScript(testngXMLFilePath + File.separator + testngFile));
			}
		}else {
			testScripts = getTestVsScript(testngXMLFilePath + File.separator + testXML);
		}
    	
		int totalKnownFailureCount = 0, totalNewFailureCount = 0;
		Iterator it;
		it = hm.entrySet().iterator();
	    while (it.hasNext()) {
			Map.Entry pair = (Map.Entry)it.next();
	        String failScriptName = pair.getKey().toString();
	        String failScriptData = pair.getValue().toString();
	        String[] screenshotUrls = getScreenshotUrls(failScriptData);
	        String[] failedTestSteps = getFailedTestSteps(failScriptData);
	        String[] failureMessages = getFailureMessages(failScriptData);
	        int knownFailureCount = 0;
	        String knownFailuresMessage = "";
	        String[] finalData = new String[3];
	        
	        if (knownFailures.keySet().contains(failScriptName)){
	        	for (int i = 0; i < failedTestSteps.length; i++) {
	        		String failedStep = failedTestSteps[i].trim();
	        		String knownFailureSteps = knownFailures.get(failScriptName);
	        		if (knownFailureSteps.contains(failedStep)) {
	        			totalKnownFailureCount += 1;
	        			knownFailureCount += 1;
	        			String reason = getKnownFailureReason(knownFailureSteps, failedStep);
	        			String regexString = "[A-Z]*[-]\\d*";
	        			Pattern r = Pattern.compile(regexString);
	        	        Matcher m = r.matcher(reason);        	        
	        	        if (m.find()) {
	        	        	if(m.group().contains("AWSCM-") || m.group().contains("LP-") || m.group().contains("DEN-")){
	        	        		knownFailuresMessage += "<a href='https://macmillanlearning.atlassian.net/browse/" + m.group() 
        	        			+ "'>" + m.group() + "</a>&nbsp;";
	        	        	}else {
	        	        		knownFailuresMessage += "<a href='https://macmillanhighered.atlassian.net/browse/" + m.group() 
	        	        			+ "'>" + m.group() + "</a>&nbsp;";
	        	        	}
	        	        } else {
	        	        	knownFailuresMessage += reason;
	        	        }	        			
	        		}
				}
	        	if (knownFailureCount > 0)
	        		finalData[0] = knownFailuresMessage;
	        	else
	        		finalData[0] = "";
	        	scriptRemarks.put(failScriptName, finalData);
	        }else {
	        	finalData[0] = "";
	        }
	        finalData[1] = StringUtils.join(screenshotUrls, "|");	
	        finalData[2] = StringUtils.join(failureMessages, "|||");
	        scriptRemarks.put(failScriptName, finalData);
	    }
    	
	    it = scriptRemarks.entrySet().iterator();
	    while (it.hasNext()) {
			Map.Entry pair = (Map.Entry)it.next();
	        String failScriptName = pair.getKey().toString();
	        String[] data123 = (String[]) pair.getValue();
	    }
	    
        int totalPassedTests = 0;
        int totalSkippedTests = 0;
        int totalFailedTests = 0;
        int totalPassedScripts = 0;
        int totalFailedScripts = 0;
        int totalSkippedScripts = 0;
        int totalScripts = 0;
        
        
        htmlContent += writeReportHeadingSection();
        htmlContent += writeExecutionDetailsSection(buildVersions, suiteResults.get(0).suiteName);
        
        String scriptTable = "";
        scriptTable += "<p><b class='sectionHeading'>Summary of Failed Scripts</b></br>";
        scriptTable += "<p height='10px'></p>";
        scriptTable += "<table class='scriptTable'>";
        scriptTable += "<tr><th>Script Name</th><th>Passed</th><th>Skipped</th><th>Failed</th><th>Reason (If Known)</th><th>Screenshots</th></tr>";
            
        for ( SuiteResult suiteResult : suiteResults ) {
            for ( TestResult testResult : suiteResult.getTestResults() ) {
                int passedTests = testResult.getPassedTestCount();
                int skippedTests = testResult.getSkippedTestCount();
                int failedTests = testResult.getFailedTestCount();                
                String testScriptName = testScripts.get(testResult.getTestName().toString());
                String[] failData = scriptRemarks.get(testScriptName);

                if (failedTests > 0 || skippedTests > 0) {
                	scriptTable += "<tr>";
                	scriptTable += "<td>" + testResult.getTestName() + "</td>";
                	scriptTable += "<td>" + Integer.toString(passedTests) + "</td>";
                	scriptTable += "<td>" + Integer.toString(skippedTests) + "</td>";
                	scriptTable += "<td>" + Integer.toString(failedTests) + "</td>";
                	if (scriptRemarks.keySet().contains(testScriptName)) {
                		if (failData[0].length() > 0) scriptTable += "<td>" + failData[0] + "</td>";
                		else scriptTable += "<td></td>";
                		String[] finalScreenshots = failData[1].split("[|]");
                		String[] failureMessages = failData[2].split("[|][|][|]");
                		scriptTable += "<td><table class='noborder_error'><tr>";
                		for (int i = 0; i < finalScreenshots.length; i++) {
                			scriptTable += "<td class='buildInfoTD'>";
                    		scriptTable += "<a href='" + finalScreenshots[i] + "'>" + "<img alt='" + Integer.toString(i+1) + "'>" + "</a>";
                    		scriptTable += "<span><table class='buildInfo'><tr><td><b>" + failureMessages[2*i] + ":</b><br />" + failureMessages[(2*i)+1] + "</td></tr></table></span>";
                    		scriptTable += "</td>";
                		}
                		scriptTable += "</tr></table></td>";
                	}else {
                		scriptTable += "<td></td><td></td>";
                	}
                	scriptTable += "</tr>";
                }

                totalPassedTests += passedTests;
                totalSkippedTests += skippedTests;
                totalFailedTests += failedTests;
            }
        }
        
        scriptTable += "</table>";
        scriptTable += "<p height='10px'></p><hr width='100%' />";
        
        String execFileData = Integer.toString(totalPassedTests) + ", " + 
        		Integer.toString(totalSkippedTests) + ", " +
        		Integer.toString(totalFailedTests) + ", " + 
        		Integer.toString(totalPassedTests + totalSkippedTests + totalFailedTests) + ", " + 
        		Integer.toString(totalKnownFailureCount) + ", " + 
        		CustomFunctions.getDateTimeStringForReport();
        if (useFTP){
        	System.out.println("Writing data to FTP file : " + "/selenium/test/automation/executions/" + product + "_" + env + "_" + suiteResults.get(0).suiteName + ".csv");
        	CustomFunctions.writeToFTPFile(ftpUrl, ftpUserID, ftpPass, "/selenium/test/automation/executions/" + product + "_" + env + "_" + suiteResults.get(0).suiteName + ".csv", execFileData);
        }
        // Current Vs. Previous Details with Graph
        
        String details = "";
        details += "<table>";
		details += "<tr><td><h5>Jenkins Job Url</h5></td><td><h5><a href='${BUILD_URL}'>${BUILD_URL}</a></h5></td></td></tr>";
        details += "<tr><td align='center'><b>&#8656; Current Execution</b></td><td></td>"
        		+ "<td align='center'><b>Previous Execution &#8658;</b></td></tr>";
        int maxValue = 0;
        int totalTests = totalPassedTests + totalSkippedTests + totalFailedTests;
        if (prevExecData != null) {
        	if (Integer.parseInt(prevExecData[3].trim()) <= totalTests) maxValue = totalTests; 
        	else maxValue = Integer.parseInt(prevExecData[3].trim());
        } else{
        	maxValue = totalTests;
        }
        
        int currTotalPercent = (int)Math.round(totalTests * 100.0/maxValue);
        int currPassPercent = (int)Math.round(totalPassedTests * 100.0/maxValue);
        int currSkipPercent = (int)Math.round(totalSkippedTests * 100.0/maxValue);
        int currFailPercent = (int)Math.round(totalFailedTests * 100.0/maxValue);
        int prevTotalPercent = 0;
        int prevPassPercent = 0;
        int prevSkipPercent = 0;
        int prevFailPercent = 0;
        if (prevExecData != null) {
        	prevTotalPercent = (int)Math.round(Integer.parseInt(prevExecData[3].trim()) * 100.0/maxValue);
            prevPassPercent = (int)Math.round(Integer.parseInt(prevExecData[0].trim()) * 100.0/maxValue);
            prevSkipPercent = (int)Math.round(Integer.parseInt(prevExecData[1].trim()) * 100.0/maxValue);
            prevFailPercent = (int)Math.round(Integer.parseInt(prevExecData[2].trim()) * 100.0/maxValue);
        }
        
        String currDate = CustomFunctions.getDateTimeStringForReport();
        String[] splitDate = currDate.split(",", 2);
        if (prevExecData != null){
	        details += writeHorizontalGraph("total", "Total", Integer.toString(currTotalPercent), 
	        		Integer.toString(totalTests), Integer.toString(prevTotalPercent), prevExecData[3].trim());
	        details += writeHorizontalGraph("pass", "Passed", Integer.toString(currPassPercent), 
	        		Integer.toString(totalPassedTests), Integer.toString(prevPassPercent), prevExecData[0].trim());
	        details += writeHorizontalGraph("skip", "Skipped", Integer.toString(currSkipPercent), 
	        		Integer.toString(totalSkippedTests), Integer.toString(prevSkipPercent), prevExecData[1].trim());
	        details += writeHorizontalGraph("fail", "Failed", Integer.toString(currFailPercent), 
	        		Integer.toString(totalFailedTests), Integer.toString(prevFailPercent), prevExecData[2].trim());
	        details += writeCompareData("Known Failures", Integer.toString(totalKnownFailureCount), prevExecData[4].trim());
	        details += "<tr height='5px'></tr>";
	        details += writeCompareData("Date", splitDate[1].trim(), prevExecData[6].trim() + ", " + prevExecData[7].trim());
	        details += writeCompareData("Time", splitDate[0].trim(), prevExecData[5].trim());
        } else {
        	details += writeHorizontalGraphCurrent("total", "Total", Integer.toString(currTotalPercent), 
	        		Integer.toString(totalTests), "No Details Available");
        	details += writeHorizontalGraphCurrent("pass", "Passed", Integer.toString(currPassPercent), 
	        		Integer.toString(totalPassedTests), "");
	        details += writeHorizontalGraphCurrent("skip", "Skipped", Integer.toString(currSkipPercent), 
	        		Integer.toString(totalSkippedTests), "");
	        details += writeHorizontalGraphCurrent("fail", "Failed", Integer.toString(currFailPercent), 
	        		Integer.toString(totalFailedTests), "");
	        details += writeCompareDataCurrent("Known Failures", Integer.toString(totalKnownFailureCount));
	        details += "<tr height='5px'></tr>";
	        details += writeCompareDataCurrent("Date", splitDate[1].trim());
	        details += writeCompareDataCurrent("Time", splitDate[0].trim());
        }
        
        details += "</table>";
        details += "<hr width='100%' />";
        details += drawPieChart(currPassPercent, currSkipPercent, currFailPercent, "Current");
		if (prevExecData != null)
		details += drawPieChart(prevPassPercent, prevSkipPercent, prevFailPercent, "Previous");
        htmlContent += details;
        if (!(totalFailedTests == 0 && totalSkippedTests == 0)) htmlContent += scriptTable;
    }

	private String writeCompareDataCurrent(String field, String currData) {
		String str = "";
		str += "<tr><td><div>";
		str += "<strong class='bar float_right'>" + currData + "</strong>";
		str += "</div></td><td class='exec_field'>" + field + "</td><td></td></tr>";
		return str;
	}

	private String drawPieChart(int PassPercent, int SkipPercent, int FailPercent, String execution)	{
    	String temp = "<div>\n" +
				"    <script type=\"text/javascript\" src=\"https://www.gstatic.com/charts/loader.js\"></script>\n" +
				"\t<script type=\"text/javascript\">\n" +
				"      google.charts.load('current', {'packages':['corechart']});\n" +
				"      google.charts.setOnLoadCallback(drawChart"+execution+");\n" +
				"      function drawChart"+execution+"() {\n" +
				"        var data = google.visualization.arrayToDataTable([\n" +
				"          ['Task', 'Execution Report'],\n" +
				"          ['Passed',     "+PassPercent+"],\n" +
				"          ['Skipped',      "+SkipPercent+"],\n" +
				"          ['Failed',  "+FailPercent+"]\n" +
				"        ]);\n" +
				"        var options = {title: '"+execution+" Execution'};\n" +
				"        var chart = new google.visualization.PieChart(document.getElementById('piechart"+execution+"'));\n" +
				"        chart.draw(data, options);\n" +
				"      }\n" +
				"    </script>\n" +
				"  </div>\n" +
				"    <div id=\"piechart"+execution+"\" style=\"width: 900px; height: 500px;\"></div>";
    	return temp;
	}

	private String writeHorizontalGraphCurrent(String className, String field,
			String currPercent, String currValue, String message) {
		String str = "";
		str += "<tr><td><div class='graphDiv'>";
		str += "<strong class='bar " + className + " float_right' style='width: " + currPercent + "%;'></strong>";
		str += "<strong class='float_right relative_right'>" + currValue + "</strong>";
        str += "</div></td><td class='exec_field'>" + field + "</td>";
        str += "<td class='noDetails'>" + message + "</td></tr>";
		return str;
	}

	private String writeCompareData(String field, String currData, String prevData) {
		String str = "";
		str += "<tr><td><div>";
		str += "<strong class='bar float_right'>" + currData + "</strong>";
		str += "</div></td><td class='exec_field'>" + field + "</td><td><div>";
		str += "<strong class='bar float_left'>" + prevData + "</strong>";
		str += "</div></td></tr>";
		return str;
	}

	private String writeHorizontalGraph(String className, String field, String currPercent, String currValue, 
			String prevPercent, String prevValue) {
		String str = "";
		str += "<tr><td><div class='graphDiv'>";
		str += "<strong class='bar " + className + " float_right' style='width: " + currPercent + "%;'></strong>";
		str += "<strong class='float_right relative_right'>" + currValue + "</strong>";
        str += "</div></td><td class='exec_field'>" + field + "</td><td><div class='graphDiv'>";
        str += "<strong class='bar " + className + " float_left' style='width: " + prevPercent + "%;'></strong>";
        str += "<strong class='float_left relative_left'>" + prevValue + "</strong>";
        str += "</div></td></tr>";
		return str;
	}

	private String writeExecutionDetailsSection(HashMap<String, String> buildVersions, String suiteName) {
		String str = "";
		str += "<table><tr><td class='exec_field'>Project</td>";
		str += "<td><div><strong class='bar float_left'>" + getDisplayProduct() + "</strong></div></td>";
		str += "<td rowspan='4' width='20px'><hr width='1' size='70'></td></tr>";
		
		str += "<tr><td class='exec_field'>Environment</td>";
		str += "<td><div><strong class='bar float_left'>" + getDisplayEnv() + "</strong></div></td>";
		
		str += "<td class='buildInfoTD'>Show Build Info<span><table class='buildInfo'><tr><th>Build Name</th><th>Version</th></tr>";
		str += getBuildInfoHTMLTableData(buildVersions);
		str += "</tr></table></span></td></tr>";
		
		str += "<tr><td class='exec_field'>Browser</td>";
		str += "<td><div><strong class='bar float_left'>" + getDisplayBrowser() + "</strong></div></td></tr>";
		str += "<tr><td class='exec_field'>Test Suite</td>";
		str += "<td><div><strong class='bar float_left'>" + suiteName + "</strong></div></td></tr>";
		
		str += "</table><hr width='100%' />";
		return str;
	}

	private String writeReportHeadingSection() {
		String str = "";
		str += "<p><b class='heading'>Test Automation Report</b></br>";
		str += "<i class='note'>Note : This is Report of an automatically triggered Job</i></p>";
		str += "<hr width='100%' />";
		return str;
	}

	private String[] getPrevExecDetails() throws IOException {
		String dirPath = "/selenium/test/automation/executions/";
		String fileName = product + "_" + env + "_" + suiteResults.get(0).suiteName +".csv";
		System.out.println("FileName : "+fileName);
		String[] prevFileData = null;
		String fileData="";
		String outdir = "";
		boolean isFilePresent = CustomFunctions.checkFTPFileExists(dirPath, fileName);

		if (isFilePresent) {
			String ftpFilePath = "ftp://" + ftpUserID + ":" + ftpPass + "@" + ftpUrl + dirPath + fileName;
			fileData = CustomFunctions.getLinesFromFTPFile(ftpFilePath).trim();
			prevFileData = fileData.split(",");
		}
//		 if(testXML.equals("TestNG_PX_Prod_Sanity.xml")||testXML.equals("TestNG_QPv1_Prod_Sanity.xml")
//         		||testXML.equals("TestNG_QBA_Prod_Sanity.xml")||testXML.equals("TestNG_QPv2_Prod_Sanity.xml")
//         		||testXML.equals("TestNG_Onboarding_Prod_Sanity.xml"))
//		 {
//			 if (product.equalsIgnoreCase("Launchpad"))
//			 {
//			 	outdir="S:\\jobs\\Sanity_PX_" + env + "\\workspace";
//			 	}
//			 	else
//			 		{
//			 			outdir="S:\\jobs\\Sanity_"+product+"_" + env + "\\workspace";
//			 		}
//		PrintWriter out= new PrintWriter( new BufferedWriter( new FileWriter( new File( outdir, "Prev_Exec_Details_"+product+"_"+env+".csv" ) ) ) );
//		out.print(fileData);
//		out.close();
//		 }
		return prevFileData;
	}

	@SuppressWarnings("rawtypes")
	private String getBuildInfoHTMLTableData(HashMap<String, String> buildVersions) {
		String tableData = "";
		Iterator it;
		it = buildVersions.entrySet().iterator();
	    while (it.hasNext()) {
	    	Map.Entry pair = (Map.Entry)it.next();
	        String buildName = pair.getKey().toString();
	        String buildVersion = pair.getValue().toString();
	        tableData += "<tr><td>" + buildName + "</td><td>" + buildVersion + "</td></tr>";
	    }
	    return tableData;
	}

	private HashMap<String, String> getBuildVersions(
			List<String> affectingBuilds) {
		String ftpFilePath = "ftp://" + ftpUserID + ":" + ftpPass + "@" + ftpUrl + "/selenium/test/execution/BuildInfo.csv";
		String buildInfoData = CustomFunctions.getLinesFromFTPFile(ftpFilePath);
		
		String ftpFileEnv = env;
		if (product.equals("dlapapi") && env.equalsIgnoreCase("aws")) {
			ftpFileEnv = "nonPRD-AWS";
		}
		if (env.equalsIgnoreCase("qa")) {
			ftpFileEnv = "QA1-nonPRD-AWS";
		} else if(env.equalsIgnoreCase("dev")) {
			ftpFileEnv = "DEV1-nonPRD-AWS";
		} else if (env.equalsIgnoreCase("lt")){
			ftpFileEnv = "LOADTEST";
		}
		
		HashMap<String, String> buildVersions = new HashMap<String, String>();
		String[] splitData = buildInfoData.split("\\r?\\n");
		for (String buildName : affectingBuilds) {
			for (int i = 0; i < splitData.length; i++) {
				String line = splitData[i];
				if (line.contains(buildName) && line.contains(ftpFileEnv)){
					buildVersions.put(buildName, line.split(",")[3].trim());
					break;
				}
			}
		}
		return buildVersions;
	}

	private List<String> getAffectingBuildList() {
		String ftpFilePath = "ftp://" + ftpUserID + ":" + ftpPass + "@" + ftpUrl + "/selenium/test/execution/BuildAutoProject.csv";
		String buildAutoProjData = CustomFunctions.getLinesFromFTPFile(ftpFilePath);

		List<String> affectingBuilds = new ArrayList<String>();
		String[] splitData = buildAutoProjData.split("\\r?\\n");
		for (int i = 0; i < splitData.length; i++) {
			if (splitData[i].contains(product)) {
				affectingBuilds.add(splitData[i].split(",")[0].trim());
			}
		}
		return affectingBuilds;
	}

	@SuppressWarnings("unused")
	private String getHoverFailureReasons(String failData) {
		String[] splitStr = failData.split("[|][|][|]");
		String spanStr= "<span><table class='table_border execDetails'><tr class='failureTableHead'><th>Failed Step Name</th><th>Failure Message</th></tr>";
		
		for (int i = 0; i < splitStr.length; i++) {
			if (i%2 == 0){
				spanStr += "<tr>";
			}
			if (i%2 == 0)spanStr += "<td>" + splitStr[i].trim() + "</td>";
			else spanStr += "<td><small>" + splitStr[i].trim() + "</small></td>";
			if (i%2 == 1) {
				spanStr += "</tr>";
			}
		}
		spanStr += "</table></span>";
		return spanStr;
	}

	private String[] getScreenshotUrls(String data) {
		String[] splitStr = data.split(";");
		int failCount = 0;
		if (splitStr.length%3 == 0) failCount = splitStr.length/3;
		
		String[] screenshotUrls;
		if (failCount != 0) {
			screenshotUrls = new String[failCount];
			for (int i = 0; i < splitStr.length; i++) {
				if ((i-1)%3 == 0) {
					screenshotUrls[(i-1)/3] = splitStr[i];
				}
			}
		} else return null;
		return screenshotUrls;
	}

	private String getKnownFailureReason(String knownFailureSteps,
			String failedStep) {
		String[] splitStr = knownFailureSteps.split(";");
		int len = splitStr.length;
		for (int i = 0; i < len; i++) {
			if (splitStr[i].trim().equalsIgnoreCase(failedStep.trim())){
				return splitStr[i+1];
			}
		}
		return "";
	}
	

	private String[] getFailedTestSteps(String data) {
		String[] splitStr = data.split(";");
		int failCount = 0;
		if (splitStr.length%3 == 0) failCount = splitStr.length/3;
		
		String[] failedTestSteps;
		if (failCount != 0) {
			failedTestSteps = new String[failCount];
			for (int i = 0; i < splitStr.length; i++) {
				if (i%3 == 0) {
					failedTestSteps[i/3] = splitStr[i];
				}
			}
		} else return null;
		return failedTestSteps;
	}
	
	private String[] getFailureMessages(String data) {
		String[] splitStr = data.split(";");
		int failCount = 0;
		if (splitStr.length%3 == 0) failCount = splitStr.length/3;
		
		String[] failureMessages;
		if (failCount != 0) {
			failureMessages = new String[failCount];
			for (int i = 0; i < splitStr.length; i++) {
				if ((i-2)%3 == 0) {
					failureMessages[(i-2)/3] = splitStr[i];
				}
			}
		} else return null;
		return failureMessages;
	}
	

//	private static String getImageUrl(String compStr1, String compStr2) {
//		String[] strSplit = compStr1.split(";");
//		int len = strSplit.length;
//		if (len == 2 || compStr2.equals("")) return strSplit[1];
//		for (int i = 0; i < len; i++) {
//			if (strSplit[i].trim().equalsIgnoreCase(compStr2.trim())){
//				if (len > i+1) return strSplit[i+1];
//			}
//		}
//		return "";
//	}
    
	/**
	 * Returns data of Failed Tests in HashMap<String, String>.
	 * @param filePath filePath from which data would be fetched
	 * @return HashMap<String, String> >> scriptName = testStep1;screenshot1;failureMessage1;testStep2;Screenshot2;failureMessage2;...
	 */
	private static HashMap<String, String> getFailedTestDetails(String filePath) {
		FileReader fr;
		HashMap<String, String> hm = new HashMap<String, String>();
		try {
			fr = new FileReader(filePath);
			BufferedReader br = new BufferedReader(fr);
			String s;
			while((s = br.readLine()) != null) {
				String[] splitStr = s.split(",");
				String scriptName = splitStr[0];
				String testStep = splitStr[1];
				String screenshot = splitStr[2];
				String failureMessage = splitStr[3];
				if (!hm.keySet().contains(scriptName)) {
					hm.put(scriptName, testStep + ";" + screenshot + ";" + failureMessage);
				} else {
					hm.put(scriptName, hm.get(scriptName) + ";" + testStep + ";" + screenshot + ";" + failureMessage);
				}
			}
			fr.close(); 
//			File f = new File(fileName);
//			f.delete();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
		return hm;
	}

//	private static String format(String grpStr) {
//		if (grpStr.startsWith("Step"))
//				grpStr = grpStr.substring(grpStr.indexOf("_") + 1);
//		return grpStr;
//	}
	
	/**
	 * Returns known failures data from File present at FTP location
	 * @return HashMap<String, String> >> scriptName > testStep1;failureReason1;testStep2;failureReason2;...
	 */

//	private static HashMap<String, String> getKnownFailureDetails() {
//		String localFilePath = "src" + File.separator +
//    			"test" + File.separator + "resources" + File.separator + "testdata" +
//    			File.separator + product.toUpperCase() + File.separator + product + "_" + env + ".csv";
//		String ftpFilePath = "ftp://" + ftpUserID + ":" + ftpPass + "@" + ftpUrl + "/selenium/test/automation/"
//				+ "knownfailure/" + product + "/" + product + "_" + env + ".csv";
//		String knownFailureData = CustomFunctions.getLinesFromFTPFile(ftpFilePath);
//		if (knownFailureData.trim().isEmpty())
//			knownFailureData = CustomFunctions.readFile(localFilePath);
//
//		HashMap<String, String> hm = new HashMap<String, String>();
//		String[] splitData = knownFailureData.split("\\r?\\n");
//		for (int i = 0; i < splitData.length; i++) {
//			String line = splitData[i].trim();
//			if (line.startsWith("#") || line.equals("")) continue;
//			if (line.contains(",")){
//				String[] lineSplit = line.split(",");
//				String scriptName = lineSplit[0];
//				String testStep = lineSplit[1];
//				String reason = lineSplit[2];
//				if (!hm.keySet().contains(scriptName)) {
//					hm.put(scriptName, testStep + ";" + reason);
//				} else {
//					hm.put(scriptName, hm.get(scriptName) + ";" + testStep + ";" + reason);
//				}
//			}
//		}
//		return hm;
//	}

	private static HashMap<String, String> getKnownFailureDetails() {
//		String localFilePath = "src" + File.separator +
//    			"test" + File.separator + "resources" + File.separator + "testdata" +
//    			File.separator + product.toUpperCase() + File.separator + product + "_" + tier + ".csv";
		String localFilePath = "src" + File.separator +
				"test" + File.separator + "resources" + File.separator + "testdata" +
				File.separator + product + "/"+  product +  "_" + env + ".csv";
		String ftpFilePath = "ftp://" + ftpUserID + ":" + ftpPass + "@" + ftpUrl + "/selenium/test/automation/"
				+ "knownfailure/" + product + "/" + product + "_" + env + ".csv";
		String knownFailureData = CustomFunctions.getLinesFromFTPFile(ftpFilePath);
		if (knownFailureData.trim().isEmpty())
			knownFailureData = CustomFunctions.readFile(localFilePath);

		HashMap<String, String> hm = new HashMap<String, String>();
		String[] splitData = knownFailureData.split("\\r?\\n");
		for (int i = 0; i < splitData.length; i++) {
			String line = splitData[i].trim();
			if (line.startsWith("#") || line.equals("")) continue;
			if (line.contains(",")){
				String[] lineSplit = line.split(",");
				String scriptName = lineSplit[0];
				String testStep = lineSplit[1];
				String reason = lineSplit[2];
				if (!hm.keySet().contains(scriptName)) {
					hm.put(scriptName, testStep + ";" + reason);
				} else {
					hm.put(scriptName, hm.get(scriptName) + ";" + testStep + ";" + reason);
				}
			}
		}
		return hm;
	}


	/**
     * Groups {@link TestResult}s by suite.
     */
    protected static class SuiteResult {
        private final String suiteName;
        private final List<TestResult> testResults = Lists.newArrayList();

        public SuiteResult(ISuite suite) {
            suiteName = suite.getName();
            for (ISuiteResult suiteResult : suite.getResults().values()) {
                testResults.add(new TestResult(suiteResult.getTestContext()));
            }
        }

        public String getSuiteName() {
            return suiteName;
        }

        /**
         * @return the test results (possibly empty)
         */
        public List<TestResult> getTestResults() {
            return testResults;
        }
    }

    /**
     * Groups {@link ClassResult}s by test, type (configuration or test), and
     * status.
     */
    protected static class TestResult {
        /**
         * Orders test results by class name and then by method name (in
         * lexicographic order).
         */
        protected static final Comparator<ITestResult> RESULT_COMPARATOR = new Comparator<ITestResult>() {
            @Override
            public int compare(ITestResult o1, ITestResult o2) {
                int result = o1.getTestClass().getName()
                        .compareTo(o2.getTestClass().getName());
                if (result == 0) {
                    result = o1.getMethod().getMethodName()
                            .compareTo(o2.getMethod().getMethodName());
                }
                return result;
            }
        };

        private final String testName;
        private final List<ClassResult> failedConfigurationResults;
        private final List<ClassResult> failedTestResults;
        private final List<ClassResult> skippedConfigurationResults;
        private final List<ClassResult> skippedTestResults;
        private final List<ClassResult> passedTestResults;
        private final int failedTestCount;
        private final int skippedTestCount;
        private final int passedTestCount;
        private final long duration;
        private final String includedGroups;
        private final String excludedGroups;

        public TestResult(ITestContext context) {
            testName = context.getName();

            Set<ITestResult> failedConfigurations = context
                    .getFailedConfigurations().getAllResults();
            Set<ITestResult> failedTests = context.getFailedTests()
                    .getAllResults();
            Set<ITestResult> skippedConfigurations = context
                    .getSkippedConfigurations().getAllResults();
            Set<ITestResult> skippedTests = context.getSkippedTests()
                    .getAllResults();
            Set<ITestResult> passedTests = context.getPassedTests()
                    .getAllResults();

            failedConfigurationResults = groupResults(failedConfigurations);
            failedTestResults = groupResults(failedTests);
            skippedConfigurationResults = groupResults(skippedConfigurations);
            skippedTestResults = groupResults(skippedTests);
            passedTestResults = groupResults(passedTests);

            failedTestCount = failedTests.size();
            skippedTestCount = skippedTests.size();
            passedTestCount = passedTests.size();

            duration = context.getEndDate().getTime() - context.getStartDate().getTime();

            includedGroups = formatGroups(context.getIncludedGroups());
            excludedGroups = formatGroups(context.getExcludedGroups());
        }

        /**
         * Groups test results by method and then by class.
         */
        protected List<ClassResult> groupResults(Set<ITestResult> results) {
            List<ClassResult> classResults = Lists.newArrayList();
            if (!results.isEmpty()) {
                List<MethodResult> resultsPerClass = Lists.newArrayList();
                List<ITestResult> resultsPerMethod = Lists.newArrayList();

                List<ITestResult> resultsList = Lists.newArrayList(results);
                Collections.sort(resultsList, RESULT_COMPARATOR);
                Iterator<ITestResult> resultsIterator = resultsList.iterator();
                assert resultsIterator.hasNext();

                ITestResult result = resultsIterator.next();
                resultsPerMethod.add(result);

                String previousClassName = result.getTestClass().getName();
                String previousMethodName = result.getMethod().getMethodName();
                while (resultsIterator.hasNext()) {
                    result = resultsIterator.next();

                    String className = result.getTestClass().getName();
                    if (!previousClassName.equals(className)) {
                        // Different class implies different method
                        assert !resultsPerMethod.isEmpty();
                        resultsPerClass.add(new MethodResult(resultsPerMethod));
                        resultsPerMethod = Lists.newArrayList();

                        assert !resultsPerClass.isEmpty();
                        classResults.add(new ClassResult(previousClassName,
                                resultsPerClass));
                        resultsPerClass = Lists.newArrayList();

                        previousClassName = className;
                        previousMethodName = result.getMethod().getMethodName();
                    } else {
                        String methodName = result.getMethod().getMethodName();
                        if (!previousMethodName.equals(methodName)) {
                            assert !resultsPerMethod.isEmpty();
                            resultsPerClass.add(new MethodResult(resultsPerMethod));
                            resultsPerMethod = Lists.newArrayList();

                            previousMethodName = methodName;
                        }
                    }
                    resultsPerMethod.add(result);
                }
                assert !resultsPerMethod.isEmpty();
                resultsPerClass.add(new MethodResult(resultsPerMethod));
                assert !resultsPerClass.isEmpty();
                classResults.add(new ClassResult(previousClassName,
                        resultsPerClass));
            }
            return classResults;
        }

        public String getTestName() {
            return testName;
        }

        /**
         * @return the results for failed configurations (possibly empty)
         */
        public List<ClassResult> getFailedConfigurationResults() {
            return failedConfigurationResults;
        }

        /**
         * @return the results for failed tests (possibly empty)
         */
        public List<ClassResult> getFailedTestResults() {
            return failedTestResults;
        }

        /**
         * @return the results for skipped configurations (possibly empty)
         */
        public List<ClassResult> getSkippedConfigurationResults() {
            return skippedConfigurationResults;
        }

        /**
         * @return the results for skipped tests (possibly empty)
         */
        public List<ClassResult> getSkippedTestResults() {
            return skippedTestResults;
        }

        /**
         * @return the results for passed tests (possibly empty)
         */
        public List<ClassResult> getPassedTestResults() {
            return passedTestResults;
        }

        public int getFailedTestCount() {
            return failedTestCount;
        }

        public int getSkippedTestCount() {
            return skippedTestCount;
        }

        public int getPassedTestCount() {
            return passedTestCount;
        }

        public long getDuration() {
            return duration;
        }

        public String getIncludedGroups() {
            return includedGroups;
        }

        public String getExcludedGroups() {
            return excludedGroups;
        }

        /**
         * Formats an array of groups for display.
         */
        protected String formatGroups(String[] groups) {
            if (groups.length == 0) {
                return "";
            }

            StringBuilder builder = new StringBuilder();
            builder.append(groups[0]);
            for (int i = 1; i < groups.length; i++) {
                builder.append(", ").append(groups[i]);
            }
            return builder.toString();
        }
    }

    /**
     * Groups {@link MethodResult}s by class.
     */
    protected static class ClassResult {
        private final String className;
        private final List<MethodResult> methodResults;

        /**
         * @param className     the class name
         * @param methodResults the non-null, non-empty {@link MethodResult} list
         */
        public ClassResult(String className, List<MethodResult> methodResults) {
            this.className = className;
            this.methodResults = methodResults;
        }

        public String getClassName() {
            return className;
        }

        /**
         * @return the non-null, non-empty {@link MethodResult} list
         */
        public List<MethodResult> getMethodResults() {
            return methodResults;
        }
    }

    /**
     * Groups test results by method.
     */
    protected static class MethodResult {
        private final List<ITestResult> results;

        /**
         * @param results the non-null, non-empty result list
         */
        public MethodResult(List<ITestResult> results) {
            this.results = results;
        }

        /**
         * @return the non-null, non-empty result list
         */
        public List<ITestResult> getResults() {
            return results;
        }
    }

    protected double millisecondsToSeconds( long ms ) {
        return new BigDecimal((ms/1000.00)/60.00).setScale( 2, RoundingMode.HALF_UP ).doubleValue();
    }
    
    /**
     * Processes the XML File and returns the List of Test Suite File Names associated with it
     * @param xmlPath path of testNG xml file to be processed 
     * @return List<String> of Test Suite File Names
     */
    private static List<String> getTestngFiles(String xmlPath) {
		List<String> testngFiles;
		testngFiles = new ArrayList<String>();
		
		try {
			File fXmlFile = new File(xmlPath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("suite-files");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element testElem = (Element) nNode;
					
					NodeList suiteFileList = testElem.getElementsByTagName("suite-file");
					Node suiteFileNode = suiteFileList.item(0);
					Element suiteFileElem = (Element) suiteFileNode;
					String path = suiteFileElem.getAttribute("path");
					path = path.substring(path.indexOf("/")+1);
					testngFiles.add(path);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return testngFiles;
	}
    
    /**
     * Returns a HashMap with TestName associated to its Test Class
     * @param xmlPath Path of the TestNG XML file
     * @return HashMap testName > Test Class Name
     */
    @SuppressWarnings("unused")
	private static HashMap<String, String> getTestVsScript(String xmlPath) {
		HashMap<String, String> testScripts = new HashMap<String, String>();
		try {
			File fXmlFile = new File(xmlPath);
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
			Document doc = dBuilder.parse(fXmlFile);
			doc.getDocumentElement().normalize();
			NodeList nList = doc.getElementsByTagName("test");

			for (int temp = 0; temp < nList.getLength(); temp++) {
				Node nNode = nList.item(temp);
				if (nNode.getNodeType() == Node.ELEMENT_NODE) {
					Element testElem = (Element) nNode;
					String testName = testElem.getAttribute("name");
					NodeList classesList = testElem.getElementsByTagName("classes");
					Node classesNode = classesList.item(0);
					Element classesElem = (Element) classesNode;
					NodeList classList = testElem.getElementsByTagName("class");
					for (int j = 0; j < classList.getLength(); j++){
						Node classNode = classList.item(0);
						Element classElem = (Element) classNode;
						String testClass = classElem.getAttribute("name");
						testClass = testClass.substring(testClass.lastIndexOf(".")+1);
						testScripts.put(testName, testClass);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testScripts;
	}

}

