package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.DAM.keywords.*;
import com.qait.SiteBuilder.keywords.GoogleSheetPageAction;


public class DAMTestInitiator extends TestSessionInitiator{
	
	public LoginPageActions loginpage;
	public CustomFunctions customFunctions;
	public HomePageActions homepage;
	public AssetsPageActions assetspage;
	public FoldersPageActions folderspage;
	public JobsPageActions jobspage;
	public ActivitiesPageActions activitiespage;
	public LightboxPageActions lightboxpage;
	public CheckedOutPageActions checkedoutpage;
	public WorkspacePageActions workspacepage;
	public UtilityPageActions utility;
	private String product_local;
	public LinkAssetPageActions linkassetpage;
	public AttachContentPageActions attachcontentpage;
	public LuminaPageActions luminaPage;
	public CMSDAMIntegrationPageActions cmsdamintegrationPage;
	public HotFolderPageActions hotfolderpage;
	public DAM3684ThumbNailPageActions dam3684thumbnailPage;
	public SearchAndFilterPageActions searchPage;
	public PreferencesPageActions preferencesPage;
	public GoogleSheetPageAction GoogleSheet;
	
	private void _initPage() {
		customFunctions = new CustomFunctions(driver);
		loginpage = new LoginPageActions(driver);
		homepage  = new HomePageActions(driver);
		assetspage = new AssetsPageActions(driver);
		folderspage = new FoldersPageActions(driver);
		jobspage = new JobsPageActions(driver);
		activitiespage = new ActivitiesPageActions(driver);
		lightboxpage = new LightboxPageActions(driver);
		checkedoutpage = new CheckedOutPageActions(driver);
		workspacepage = new WorkspacePageActions(driver);
		utility   = new UtilityPageActions(driver);
		linkassetpage = new LinkAssetPageActions(driver);
	    attachcontentpage = new AttachContentPageActions(driver);
	    luminaPage = new LuminaPageActions(driver);
	    cmsdamintegrationPage = new CMSDAMIntegrationPageActions(driver);
	    hotfolderpage = new HotFolderPageActions(driver);
	    dam3684thumbnailPage = new DAM3684ThumbNailPageActions(driver);
	    searchPage = new SearchAndFilterPageActions(driver);
	    preferencesPage = new PreferencesPageActions(driver);
	    GoogleSheet= new GoogleSheetPageAction(driver);
	}
		
	public DAMTestInitiator() {
	        super();
	        setProduct();
	        setYamlFilePath(product_local);

	        configureBrowser();
	        _initPage();
	        customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
	        CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	    }

	    public void setProduct(){
	       product_local=System.getProperty("product");
	       product = System.getProperty("product");

	       if(product==null) {
	           product = ConfigPropertyReader.getProperty("product");
	       }

	       if(product_local==null) {
	            product_local = ConfigPropertyReader.getProperty("product");
	        }
	        CustomFunctions.setProduct(product_local);
	        GetPage.setProduct(product_local);
	        
	        
	    }

	
}