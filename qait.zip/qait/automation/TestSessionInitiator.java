/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation;

import com.qait.automation.utils.SeleniumWebDriverEventListener;

import groovy.util.logging.Log;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.qait.automation.TestSessionInitiator.getEnv;
import static com.qait.automation.utils.DataReadWrite.getProperty;
import static com.qait.automation.utils.YamlReader.getYamlValue;

public class TestSessionInitiator {

	protected WebDriver driver, originalDriver;
	private WebDriverFactory wdfactory;
	Map<String, Object> chromeOptions = null;
	public static String product;

	public TestSessionInitiator() {
		wdfactory = new WebDriverFactory();
	}

	public boolean getDebugMode() {
		String value = _getSessionConfig().get("chromeDubugMode");
		if (value == null || Boolean.parseBoolean(value) == false)
			return false;
		else
			return true;
	}

	protected void configureBrowser() {
		if (getDebugMode()) {
			driver = wdfactory.getDriverInDubugMode();
		} else {
			driver = wdfactory.getDriver(_getSessionConfig());
		}

		if (getBrowser().equals("chrome"))
			try {
				driver.manage().window().maximize();
			} catch (WebDriverException e) {
				System.out.println("Already in maximized state");
			}
		if (getBrowser().equals("firefox"))
			driver.manage().window().maximize();
		int timeout;
		if (System.getProperty("timeout") != null)
			timeout = Integer.parseInt(System.getProperty("timeout"));
		else
			timeout = Integer.parseInt(_getSessionConfig().get("timeout"));
		driver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
		originalDriver = driver;
		EventFiringWebDriver efwd = new EventFiringWebDriver(driver);

//		SeleniumWebDriverEventListener myListener = new SeleniumWebDriverEventListener(driver);
//		efwd.register(myListener);
//		driver = efwd;
	}

//	public String getBrowserVersion()	{
//		Capabilities caps = ((RemoteWebDriver) driver).getCapabilities();
//		Capabilities capabilities = null;
//		capabilities.getVersion();
//		String 	browserVerison = caps.getVersion();
//		return  browserVerison;
//	}

	private static Map<String, String> _getSessionConfig() {
		String[] configKeys = { "product", "tier", "browser", "seleniumserver", "seleniumserverhost1",
				"seleniumserverhost2", "timeout", "debugObjects", "takeScreenshot", "uploadImage", "testrail", "useFTP",
				"ftpUrl", "ftpUserID", "ftpPass", "chromeDubugMode" };
		Map<String, String> config = new HashMap<String, String>();
		for (String string : configKeys) {
			config.put(string, getProperty("./Config.properties", string));
		}
		return config;
	}

	public static boolean isFtpUseAllowed() {
		String useFTP = System.getProperty("useFTP");
		if (useFTP == null)
			useFTP = _getSessionConfig().get("useFTP");
		if (useFTP.equals("yes") || useFTP.equals("true"))
			return true;
		else
			return false;
	}

	public static String getFTPUrl() {
		String ftpUrl = System.getProperty("ftpUrl");
		if (ftpUrl == null)
			ftpUrl = _getSessionConfig().get("ftpUrl");
		return ftpUrl;
	}

	public static String getFTPUserID() {
		String ftpUserID = System.getProperty("ftpUserID");
		if (ftpUserID == null)
			ftpUserID = _getSessionConfig().get("ftpUserID");
		return ftpUserID;
	}

	public static String getFTPPassword() {
		String ftpPass = System.getProperty("ftpPass");
		if (ftpPass == null)
			ftpPass = _getSessionConfig().get("ftpPass");
		return ftpPass;
	}

	public static String getEnv() {
		String tier = System.getProperty("env");
		if (tier == null)
			tier = _getSessionConfig().get("tier");
		return tier;
	}

	public static boolean getTestRailUpdationFlag() {
		String testrailFlag = System.getProperty("testrail");
		if (testrailFlag == null)
			testrailFlag = _getSessionConfig().get("testrail");
		if (testrailFlag.equalsIgnoreCase("yes") || testrailFlag.equalsIgnoreCase("true"))
			return true;
		else
			return false;
	}

	public static boolean VerifyTestCasesRunable() {
		System.out.println("Enveronment::" + getEnv());
		if (getEnv().equalsIgnoreCase("QA")) {
			return false;
		} else {
			return true;
		}
	}

	public String getDebugObjects() {
		return _getSessionConfig().get("debugObjects");
	}

	public String getBrowser() {
		String browser = System.getProperty("browser");
		if (browser == null)
			browser = _getSessionConfig().get("browser");
		return browser;
	}

	public String getUploadScreenshotToFtp() {
		return _getSessionConfig().get("uploadImage");
	}

	public String getTakeScreenshot() {
		return _getSessionConfig().get("takeScreenshot");
	}

	public static String getProduct() {
		if (product == null && System.getProperty("product") != null)
			product = System.getProperty("product");
		return product;
	}

	public void launchApplicationforSchoology() {
		launchApplication(getYamlValue("app_url"));
	}

	public void launchApplication() {
//		System.out.println("Application Url is" + getYamlValue("app_url"));
		launchApplication(getYamlValue("app_url"));
	}

	public void launchAchieveApplication() {
//		System.out.println("Application Url is"+getYamlValue("achieve_url"));
		launchApplication(getYamlValue("achieve_url"));
	}

	public void launchLMSRequestForm() {
		launchApplication(getYamlValue("form_url"));
	}

	public void launchApplicationForSapling() {
//		System.out.println("Application Url is" + getYamlValue("sap_app_url"));
		launchApplication(getYamlValue("sap_app_url"));
	}

	public void launchApplication(String applicationpath) {
		Reporter.log("Application url is :- " + applicationpath, true);
		Reporter.log("Test browser is :- " + getBrowser(), true);
		driver.manage().deleteAllCookies();
		
     	driver.manage().window().maximize();
		      
		driver.get(applicationpath);
	}

	public void getCurrentHostAddress() {
		InetAddress IP = null;
		try {
			IP = InetAddress.getLocalHost();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.out.println("IP := " + IP.getHostAddress());
	}

	public void getWaxOffURLInNewTab(String waxOffUrl, String appUrl) {
		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs.get(0)); // switches to new tab
		driver.get(waxOffUrl);

		driver.switchTo().window(tabs.get(0)); // switch back to main screen
		driver.get(appUrl);
	}

	public void getURL(String url) {
		driver.manage().deleteAllCookies();
		driver.get(url);
	}

	public void setWindowSize(int width, int height) {
		driver.manage().window().setSize(new Dimension(width, height));
	}

	public void closeBrowserSession() {

		driver.quit();

	}

	/**
	 * if localflag >0 browser will close if localflag = 0 browser will remain open
	 * if code is running on remote it will always close irrescpective of localflag
	 * parameter
	 *
	 * @param localflag = 0 or positive number
	 * 
	 */
	public void closeBrowserSession(int localflag) {
		if (getSeleniumServer().equals("remote"))
			driver.quit();
		else if (localflag > 0)
			driver.close();
	}

	public void closebrowserSession() {
		driver.quit();
	}

	public String getPageTitle() {
		return driver.getTitle();
	}

	public void stepStartMessage(String testStepName) {
		Reporter.log(" ", true);
		Reporter.log("***** STARTING TEST STEP:- " + testStepName.toUpperCase() + " *****", true);
		Reporter.log(" ", true);
	}

	public void refreshPage() {
		driver.navigate().refresh();
	}

	public void closeWindow() {
		driver.close();
	}

	public String getSeleniumServer() {
		String selServer = System.getProperty("seleniumserver");
		if (selServer == null)
			selServer = _getSessionConfig().get("seleniumserver");
		return selServer;
	}

}