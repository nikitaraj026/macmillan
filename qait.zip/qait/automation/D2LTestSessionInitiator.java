package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;
import static org.testng.Assert.assertTrue;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.blackboard.keywords.CourseHomePageActionsLaunchpad;
import com.qait.d2l.keywords.OnboardingPageActions;
import com.qait.d2l.keywords.PXPageActions;
import com.qait.d2l.keywords.LoginPageAction;
import com.qait.d2l.keywords.HomePageAction;
import com.qait.d2l.keywords.InstructorCourseAssociationAction;
import com.qait.d2l.keywords.InstructorHomePageAction;
import com.qait.d2l.keywords.InstructorToolsWidgetAction;
import com.qait.d2l.keywords.LaunchpadPageActions;
import com.qait.d2l.keywords.ManageCoursesPageAction;
import com.qait.d2l.keywords.UsersPageActon;
import com.qait.d2l.tests.InstructorSmokeContentDeployment;
import com.qait.d2l.keywords.CourseDeploymentPageAction;
import com.qait.d2l.keywords.CoursePageAction;
import com.qait.d2l.keywords.FandEPageActionsLaunchpad;
import com.qait.d2l.keywords.RemotePluginsPageAction;
import com.qait.d2l.keywords.StudentAccessGrantPageActions;
import com.qait.d2l.keywords.StudentHomePageAction;
import com.qait.d2l.keywords.MacmillanHigherEducationInstructorProfileActions;

public class D2LTestSessionInitiator extends TestSessionInitiator{

	public CustomFunctions customFunctions;
	public LoginPageAction loginPage;
	public HomePageAction homePage;
	public ManageCoursesPageAction manageCoursesPageAction;
	public UsersPageActon usersPageActon;
	public CoursePageAction coursePageAction;
	public RemotePluginsPageAction remotePluginsPageAction;
	public InstructorHomePageAction instructorHomePageAction;
	public InstructorCourseAssociationAction instructorCourseAssociationAction;
	public InstructorToolsWidgetAction instructorToolsWidgetAction;
	public LaunchpadPageActions launchpadPageactions;
	public InstructorSmokeContentDeployment instructorSmokeContentDeployment;
	public CourseDeploymentPageAction courseDeploymentPageAction;
	public OnboardingPageActions onboardingPageActions;
	public StudentAccessGrantPageActions studentAccessGrantPageActions;
	public PXPageActions pxPageActions;
	public FandEPageActionsLaunchpad fandEpageActionsLaunchpad;
	public StudentHomePageAction studentHomePageAction;
	public MacmillanHigherEducationInstructorProfileActions macmillanHigherEducationInstructorProfile;
	private String product_local;
	
	
	private void _initPage() {
		loginPage = new LoginPageAction(driver);
		homePage = new HomePageAction(driver);
		manageCoursesPageAction = new ManageCoursesPageAction(driver);
		customFunctions = new CustomFunctions(driver);
		usersPageActon = new UsersPageActon(driver);
		coursePageAction = new CoursePageAction(driver);
		remotePluginsPageAction = new RemotePluginsPageAction(driver);
		instructorHomePageAction = new InstructorHomePageAction(driver);
		instructorCourseAssociationAction = new InstructorCourseAssociationAction(driver);
		instructorToolsWidgetAction = new InstructorToolsWidgetAction(driver);
		launchpadPageactions = new LaunchpadPageActions(driver);
		instructorSmokeContentDeployment = new InstructorSmokeContentDeployment();
		courseDeploymentPageAction = new CourseDeploymentPageAction(driver);
		onboardingPageActions = new OnboardingPageActions(driver);
		studentAccessGrantPageActions = new StudentAccessGrantPageActions(driver);
		pxPageActions = new PXPageActions(driver);
		fandEpageActionsLaunchpad = new FandEPageActionsLaunchpad(driver);
		studentHomePageAction = new StudentHomePageAction(driver);
		macmillanHigherEducationInstructorProfile= new MacmillanHigherEducationInstructorProfileActions(driver);
	}

	public D2LTestSessionInitiator(){
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	 public void setProduct(){
		 product_local="d2l";
	    	product = "d2l";
	    	CustomFunctions.setProduct(product_local);
	    	GetPage.setProduct(product_local);
	    }
	
}