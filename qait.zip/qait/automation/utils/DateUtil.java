package com.qait.automation.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class DateUtil {

	static Calendar cal;
	static SimpleDateFormat s;
	String[] arr;

	public static String getCurrentDateTime() {
		String ranNum = "";
		DateFormat formatter = new SimpleDateFormat("MMM");
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		DateFormat dformatter = new SimpleDateFormat("DD");
		SimpleDateFormat dateParse = new SimpleDateFormat("DD");
		Calendar cal = Calendar.getInstance();
		String month = Integer.toString(cal.get(Calendar.MONTH));
		String date = Integer.toString(cal.get(Calendar.DATE));
		try {
			ranNum = "_" + dformatter.format(dateParse.parse(date))
			+ formatter.format(monthParse.parse(month)) + "_"
			+ Integer.toString(cal.get(Calendar.HOUR_OF_DAY))
			+ Integer.toString(cal.get(Calendar.MINUTE));
		} catch (Exception e) {
		}
		return ranNum;
	}

	public static String getCurrentDate() {
		DateFormat formatter = new SimpleDateFormat("MM");
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		DateFormat dformatter = new SimpleDateFormat("DD");
		SimpleDateFormat dateParse = new SimpleDateFormat("DD");
		Calendar cal = Calendar.getInstance();
		String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
		String date = Integer.toString(cal.get(Calendar.DATE));
		try {
			month = formatter.format(monthParse.parse(month));
			date = dformatter.format(dateParse.parse(date));
		} catch (ParseException e) {
		}
		String year = Integer.toString(cal.get(Calendar.YEAR));
		String calDate = month + "/" + date + "/" + year;
		return calDate;
	}

	/**
	 * Method returns tomorrows date according to US time Zone
	 */
	public static String getTommorrowsDate() {
		Date date = new Date();
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		df.setTimeZone(TimeZone.getTimeZone("EST"));
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(df.parse(df.format(date)));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c.add(Calendar.DATE, 1);
		date = c.getTime();
		return df.format(date);
	}

	public static String getTommorrowsDateFne() {
		DateFormat formatter = new SimpleDateFormat("MMM");
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		DateFormat dformatter = new SimpleDateFormat("DD");
		SimpleDateFormat dateParse = new SimpleDateFormat("DD");
		Calendar cal = Calendar.getInstance();
		String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
		String date = Integer.toString(cal.get(Calendar.DATE) + 1);
		try {
			month = formatter.format(monthParse.parse(month));
			date = dformatter.format(dateParse.parse(date));
		} catch (ParseException e) {
		}
		String calDate = month + " " + date;
		return calDate;
	}

	public static String getDayAfterTommorrowsDate() {
		DateFormat formatter = new SimpleDateFormat("MM");
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		DateFormat dformatter = new SimpleDateFormat("DD");
		SimpleDateFormat dateParse = new SimpleDateFormat("DD");
		Calendar cal = Calendar.getInstance();
		String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
		String date = Integer.toString(cal.get(Calendar.DATE) + 2);
		try {
			month = formatter.format(monthParse.parse(month));
			date = dformatter.format(dateParse.parse(date));
		} catch (ParseException e) {
		}
		String year = Integer.toString(cal.get(Calendar.YEAR));
		String calDate = month + "/" + date + "/" + year;
		return calDate;
	}

	public static String getDayAfterTommorrowsDateFne() {
		DateFormat formatter = new SimpleDateFormat("MMM");
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		DateFormat dformatter = new SimpleDateFormat("DD");
		SimpleDateFormat dateParse = new SimpleDateFormat("DD");
		Calendar cal = Calendar.getInstance();
		String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
		String date = Integer.toString(cal.get(Calendar.DATE) + 2);
		try {
			month = formatter.format(monthParse.parse(month));
			date = dformatter.format(dateParse.parse(date));
		} catch (ParseException e) {
		}
		String calDate = month + " " + date;
		return calDate;
	}

	public static String getDayToDayAfterTommorrowsDate() {
		DateFormat formatter = new SimpleDateFormat("MM");
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		DateFormat dformatter = new SimpleDateFormat("DD");
		SimpleDateFormat dateParse = new SimpleDateFormat("DD");
		Calendar cal = Calendar.getInstance();
		String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
		String date = Integer.toString(cal.get(Calendar.DATE) + 3);
		try {
			month = formatter.format(monthParse.parse(month));
			date = dformatter.format(dateParse.parse(date));
		} catch (ParseException e) {
		}
		String year = Integer.toString(cal.get(Calendar.YEAR));
		String calDate = month + "/" + date + "/" + year;
		return calDate;
	}

	public static String getDayToDayAfterTommorrowsDateFne() {
		DateFormat formatter = new SimpleDateFormat("MMM");
		SimpleDateFormat monthParse = new SimpleDateFormat("MM");
		DateFormat dformatter = new SimpleDateFormat("DD");
		SimpleDateFormat dateParse = new SimpleDateFormat("DD");
		Calendar cal = Calendar.getInstance();
		String month = Integer.toString(cal.get(Calendar.MONTH) + 1);
		String date = Integer.toString(cal.get(Calendar.DATE) + 3);
		try {
			month = formatter.format(monthParse.parse(month));
			date = dformatter.format(dateParse.parse(date));
		} catch (ParseException e) {
		}
		String calDate = month + " " + date;
		return calDate;
	}

	public static String getCurrentdateInStringWithGivenFormate(String formate) {
		String date = new SimpleDateFormat(formate).format(new Date());
		return date;
	}

	public static String getNextDateFromGivenDateFoGivenDateModule(
			String dateFormat, String dateModule, String curDate, int frequency) {
		final SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		Date date = null;
		try {
			date = format.parse(curDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cal = Calendar.getInstance();
		cal.setTime(date);
		if (dateModule.equalsIgnoreCase("day")) {
			cal.add(Calendar.DAY_OF_YEAR, frequency);

		} else if (dateModule.equalsIgnoreCase("month")) {
			cal.add(Calendar.MONTH, frequency);

		} else {
			cal.add(Calendar.YEAR, frequency);
		}
		return format.format(cal.getTime());
	}

	public static String getPreviousDateFromGivenDateFoGivenDateModule(
			String dateFormat, String dateModule, String curDate, int frequency) {
		final SimpleDateFormat format = new SimpleDateFormat(dateFormat);
		Date date = null;
		try {
			date = format.parse(curDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cal = Calendar.getInstance();
		cal.setTime(date);
		if (dateModule.equalsIgnoreCase("day")) {
			cal.add(Calendar.DAY_OF_YEAR, -frequency);

		} else if (dateModule.equalsIgnoreCase("month")) {
			cal.add(Calendar.MONTH, -frequency);

		} else {
			cal.add(Calendar.YEAR, -frequency);
		}
		return format.format(cal.getTime());
	}

	public static String getDate(String date) {
		if (date.equalsIgnoreCase("TomorrowDate"))
			return getTommorrowsDate();
		if (date.equalsIgnoreCase("DayAfterTomorrowDate"))
			return getDayAfterTommorrowsDate();
		if (date.equalsIgnoreCase("DayToDayAfterTomorrowDate"))
			return getDayToDayAfterTommorrowsDate();
		return fixedDate();
	}

	public static String getDateForFne(String date) {
		if (date.equalsIgnoreCase("TomorrowDate"))
			return getTommorrowsDateFne();
		if (date.equalsIgnoreCase("DayAfterTomorrowDate"))
			return getDayAfterTommorrowsDateFne();
		if (date.equalsIgnoreCase("DayToDayAfterTomorrowDate"))
			return getDayToDayAfterTommorrowsDateFne();
		return fixedDate();
	}

	public static String getTimeAsPerTimeZone(String time, String timeZOne) {
		time = time.split("Minutes")[1];
		DateFormat formatter = new SimpleDateFormat("hh:mm a");
		TimeZone tz = TimeZone.getTimeZone("EST5EDT");
		Calendar cal = new GregorianCalendar(tz);
		cal.add(Calendar.MINUTE, Integer.parseInt(time));
		formatter.setTimeZone(tz);
		return formatter.format(cal.getTime());
	}

	//	public static String getTommorrowsDate(){
	//		Calendar cal = Calendar.getInstance();
	//		String month = Integer.toString(cal.get(Calendar.MONTH)+1);
	//		String date = Integer.toString(cal.get(Calendar.DATE)+1);
	//		String year = Integer.toString(cal.get(Calendar.YEAR));
	//		if (month.length()==1){
	//			month = "0".concat(month);
	//		}
	//		String calDate = month+"/"+date+"/"+year;
	//		return calDate;
	//
	//	}

	public static String fixedDate() {
		return "12/31/2019";
	}

	public static String getCurrentTime() {
		Date date = new Date();
		String strDateFormat = "HH:mm a";
		SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
		return (sdf.format(date));
	}

	public static String getCurrentTimeInFormat(String dateFormat) {
		Date date = new Date();
		String strDateFormat = dateFormat;
		SimpleDateFormat sdf = new SimpleDateFormat(strDateFormat);
		return (sdf.format(date));
	}

	public static String getESTDateTime() {
		Date date = new Date();
		DateFormat formatter = new SimpleDateFormat("dd MM yyyy HH:mm:ss a z");
		// Set the formatter to use a different time zone
		formatter.setTimeZone(TimeZone.getTimeZone("GMT-4:00"));
		// Prints the date in the EST time zone
		return formatter.format(date);
	}

	public static Date addDays(Date date, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); // minus number would decrement the days
		return cal.getTime();
	}

	public static long timeDuration(String time1, String time2, String timeFormat) throws ParseException {
		SimpleDateFormat format = new SimpleDateFormat(timeFormat);
		Date date1 = format.parse(time1);
		Date date2 = format.parse(time2);
		long difference = date1.getTime() - date2.getTime();
		return difference;
	}

	public String getDesiredDateInNumbers(int count) 
	{
		_Add_OR_Subtract_Date(count);
		String date = _get_Day_Date_Month_Year("date");
		if (date.startsWith("0"))
		{
			date = date.replaceFirst("0", "");
		}
		String month = _get_Day_Date_Month_Year("month");
		String year = _get_Day_Date_Month_Year("year");
		int month_no = cal.get(Calendar.MONTH);
		month_no = month_no + 1;
		String month_text = Integer.toString(month_no);
		System.out.println("month_no" + month_no);
		String calDate = month_text + "/" + date + "/" + year;
		String calYear=year;
		System.out.println(calDate);
		System.out.println(calYear);
		return calYear;
	}

	private void _Add_OR_Subtract_Date(int noOfDays) {
		cal = Calendar.getInstance();
		System.out.println("Today : " + cal.getTime());
		cal.add(Calendar.DATE, noOfDays);
		System.out.println("Days after: " + cal.getTime());
	}

	private String _get_Day_Date_Month_Year(String value) {

		String str = cal.getTime().toString();
		String[] result = str.split(" ");

		if (value.equalsIgnoreCase("day")) {
			return result[0];
		} else if (value.equalsIgnoreCase("date")) {
			return result[2];
		} else if (value.equalsIgnoreCase("month")) {
			return result[1];
		} else if (value.equalsIgnoreCase("year")) {
			return result[5];
		} else {
			return "Invalid Value";
		}
	}

	public int getNextMonth(){
		String month = Integer.toString(cal.get(Calendar.MONTH));
		int month_no = Integer.parseInt(month);
		month_no = month_no + 1;
		if (month_no == 13)
			month_no = 1;
		return month_no;
		
	}

	public int getCurrentYear(){
		String year = Integer.toString(cal.get(Calendar.YEAR));
		int year_no = Integer.parseInt(year);
		return year_no;
	}

}
