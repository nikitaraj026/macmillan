package com.qait.automation.utils;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;





import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.Sheets;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.Sheet;
import com.google.api.services.sheets.v4.model.SheetProperties;
import com.google.api.services.sheets.v4.model.Spreadsheet;
import com.google.api.services.sheets.v4.model.ValueRange;

public class SheetsAPI {

	Sheets service = null;
	private String spreadSheetId;
	private static final String APPLICATION_NAME = "Google Sheets API Java Quickstart";
	// Directory to store user credentials for this application. //*
	private static final java.io.File DATA_STORE_DIR = new java.io.File(System.getProperty("user.home"),
			".credentials/sheets.googleapis.com-java-quickstart.json");
	// Global instance of the {@link FileDataStoreFactory}. //*
	private static FileDataStoreFactory DATA_STORE_FACTORY;
	// Global instance of the JSON factory. //*
	private static final JsonFactory JSON_FACTORY = JacksonFactory.getDefaultInstance();
	// Global instance of the HTTP transport. //*
	private static HttpTransport HTTP_TRANSPORT;
	// //*
	// * Global instance of the scopes required by this quickstart.
	// *
	// * If modifying these scopes, delete your previously saved credentials at
	// * ~/.credentials/sheets.googleapis.com-java-quickstart.json
	// //
	private static final List<String> SCOPES = Arrays.asList(SheetsScopes.SPREADSHEETS);

	static {
		try {
			HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
			DATA_STORE_FACTORY = new FileDataStoreFactory(DATA_STORE_DIR);
		} catch (Throwable t) {
			t.printStackTrace();
			System.exit(1);
		}
	}

	public SheetsAPI(String spreadSheetID) {
		this.spreadSheetId = spreadSheetID;
		//this.spreadSheetId = "1HXduIyv9HBsVWW40QJT98tHF7vJXQsjy5ZfPI34Jg9w";
		service = getSheetsService();
	}	

	// **
	// Build and return an authorized Sheets API client service.
	// *
	// * @return an authorized Sheets API client service
	// * @throws IOException
	// //
	public Sheets getSheetsService(){
		Credential credential=null;
		credential = authorize();
		return new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential).setApplicationName(APPLICATION_NAME)
				.build();
	}

	// //*
	// * Creates an authorized Credential object.
	// *
	// * @return an authorized Credential object.
	// * @throws IOException
	// //
	public static Credential authorize() {
		// Load client secrets.
		Credential credential= null;
		try{
			InputStream in = SheetsAPI.class.getResourceAsStream("/SheetsAPI/client_secret.json");
			GoogleClientSecrets clientSecrets = GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

			// Build flow and trigger user authorization request.
			GoogleAuthorizationCodeFlow flow = new GoogleAuthorizationCodeFlow.Builder(HTTP_TRANSPORT, JSON_FACTORY,
					clientSecrets, SCOPES).setDataStoreFactory(DATA_STORE_FACTORY).setAccessType("offline").build();
			credential = new AuthorizationCodeInstalledApp(flow, new LocalServerReceiver()).authorize("user");
			System.out.println("Credentials saved to " + DATA_STORE_DIR.getAbsolutePath());
		}
		catch(IOException e)
		{

		}
		return credential;
	}	

	public ArrayList<Sheet> getListOfSheets()
	{
		Spreadsheet spreadSheet = null;
		try {
			spreadSheet = service.spreadsheets().get(spreadSheetId).execute();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return (ArrayList<Sheet>) spreadSheet.getSheets();
	}

	public static void main(String[] args) {
		SheetsAPI tes = new SheetsAPI("<Enter sheet id here>");
		tes.getSheetsService();
		int sheetIndex = tes.getSheetIndex("Test Sheet");
		//System.out.println(sheets.get(0).toString());
		System.out.println("Sheet Index : " + sheetIndex);
		//tes.readSheetData(sheetIndex);
		String data = tes.findData(sheetIndex, "TCID", "tc2", "Test Step Name");
		System.out.println("Data is : " + data);
	}

	public String findData(int sheetIndex, String col1, String data1, String col2) {
		ArrayList<Sheet> sheets = this.getListOfSheets();
		Sheet sheet = sheets.get(sheetIndex);

		List<List<Object>> values = null;
		try{			
			String range = "'" + sheet.getProperties().getTitle() + "'" + "!A1:J500";
			ValueRange response = null;
			try {
				response = service.spreadsheets().values().get(spreadSheetId, range).setMajorDimension("ROWS").execute();
			} catch (IOException e) {
				e.printStackTrace();
			}
			values = response.getValues();
			if (values == null || values.size() == 0) {
				System.out.println("No data found.");
			} else {
				int col1Index = 0;
				int col2Index = 0;
				//System.out.println("Size : " + values.size());
				for (int i = 0; i < values.size(); i++) {
					for (int j = 0; j < values.get(i).size(); j++) {
						//System.out.println("Values : " + values.get(i).get(j).toString());
						//System.out.println("===============");
						//System.out.println(values.get(i).get(j).toString().trim());
						//System.out.println(col1);
						if (values.get(i).get(j).toString().trim().equals(col1)) col1Index = j;
						if (values.get(i).get(j).toString().trim().equals(col2)) col2Index = j;
						if (values.get(i).get(col1Index).toString().equals(data1)) 
							return values.get(i).get(col2Index).toString();

					}
				}
			}
		}
		catch (NullPointerException e)
		{
			e.printStackTrace();
		}
		return "";
	}

	public int getSheetIndex(String sheetName) {
		ArrayList<Sheet> sheets = this.getListOfSheets();
		for (Sheet sheet : sheets) {
			SheetProperties prop = sheet.getProperties();
			if (prop.get("title").toString().equals(sheetName)){
				return Integer.parseInt(prop.get("index").toString());
			}
		}
		return -1;
	}

	/**
	 * Fetches task with is ready to be added to the test suite
	 */

	public List<List<Object>> readSheetData(int sheetIndex)
	{
		ArrayList<Sheet> sheets = this.getListOfSheets();
		Sheet sheet = sheets.get(sheetIndex);

		List<List<Object>> values = null;
		try{
			//System.out.println(sheet);
			System.out.println("in readTasksFromSheet");

			String range = "'" + sheet.getProperties().getTitle() + "'" + "!A1:J500";
			ValueRange response = null;
			try {
				response = service.spreadsheets().values().get(spreadSheetId, range).setMajorDimension("ROWS").execute();
			} catch (IOException e) {
				e.printStackTrace();
			}
			values = response.getValues();
			if (values == null || values.size() == 0) {
				System.out.println("No data found.");
			} else {
				//   System.out.println("TaskId");
				for (List row : values) {
					for (Object obj : row)
						System.out.println((String)obj);
				}
			}
		}
		catch (NullPointerException e)
		{
			e.printStackTrace();
		}
		return values;

	}


}
