package com.qait.automation.utils;

import java.awt.List;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.json.JSONObject;
import org.json.XML;
import org.testng.Assert;
import org.w3c.dom.NodeList;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.response.Response;

public class RestAPIHandler {
	static Response response;
	static org.w3c.dom.Document document;
	static DocumentBuilder docBuilder;
 	static ArrayList<String> list;

    /**
     * construtor of this class
     */
    public RestAPIHandler() {
    }

  
    public static Response getXmlResponseFromAPI(String baseUrl,String isbnValue,String keyValue){
    	System.out.println("baseUrl is==> " + baseUrl);
    	System.out.println("isbnValue is==> " + isbnValue);
    	System.out.println("keyValue is==> " + keyValue);

    	Response response = RestAssured.given().baseUri(baseUrl).pathParam("key",keyValue).pathParam("isbn", isbnValue).when().get("/{key}/{isbn}").then().contentType("text/plain;charset=ISO-8859-1").extract().response();
		 System.out.println("xml response is ===>" + response.asString());
    	 return response;

    }
   
    public static JSONObject getJsonResponseFromAPI(String baseUrl,String endpoint,String keyValue){
    	Response response = RestAssured.given().baseUri(baseUrl).header("x-api-key",keyValue).when().get(endpoint).then().contentType("text/plain;charset=ISO-8859-1").extract().response();
    	JSONObject responseJson = XML.toJSONObject(response.asString());
		return responseJson;
    }
   
    public static String ParseXMLandFetchTagValue(String responseXml,String tagName) {
    	InputStream is = new ByteArrayInputStream(responseXml.getBytes());
    	String errorMessage = null;
    	try{
			 docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
			 document = docBuilder.parse(is);
			 String rootNode =  document.getDocumentElement().getNodeName();
		     NodeList bookslist = document.getElementsByTagName(rootNode);
		     if(!tagName.equalsIgnoreCase(null) || !tagName.equalsIgnoreCase(" ")) {
		    	 errorMessage = ((org.w3c.dom.Element) bookslist.item(0)).getElementsByTagName(tagName).
			                        item(0).getChildNodes().item(0).getNodeValue();
			     System.out.println("Response errorMessage is====>" + errorMessage);
		     }
			 
		 }catch(Exception e){
			 e.printStackTrace();
		 }
		return errorMessage;
	}
  
    public static ArrayList<String> parseXmlandFetchXMLTagNames(String responseXml)  {
    	InputStream is = new ByteArrayInputStream(responseXml.getBytes());
    	String errorMessage = null;
    	list=new ArrayList<String>();
	    try {
			docBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
     	      document = docBuilder.parse(is);
		} catch (Exception e) {
			e.printStackTrace();
		}
    	NodeList nl = document.getElementsByTagName("*");
        for (int i = 0; i < nl.getLength(); i++)
        {
          list.add(nl.item(i).getNodeName());
        }
        System.out.println( "list values====> " + list);
    	return list;
	}
    
    public static void verifyXMLTagsValue(String activityToVerify) {
    	boolean correctStringMatched = false;
		for(int i=0;i<list.size();i++) {
			if(list.get(i).toString().contains(activityToVerify)) {
				correctStringMatched = true;
			}
		}
		Assert.assertTrue(correctStringMatched);
		System.out.println("[Assertion Passed:] Correct name "+activityToVerify +" available for downloaded tag under XML");
	
	}
    
}
