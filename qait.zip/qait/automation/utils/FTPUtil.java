package com.qait.automation.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.commons.net.telnet.WindowSizeOptionHandler;
import org.apache.log4j.Logger;
import org.openqa.selenium.support.ui.Wait;

import groovy.util.logging.Log;

import org.apache.commons.net.ftp.FTPFile;

public class FTPUtil {
	static FTPClient ftpClient = new FTPClient();
	static FTPFile[] files, files1;
	static String remotePath = null;
	static Logger logger = LoggerImplemetation.logConfig("FTPConnection.class");

	/**
	 * construtor of this class
	 */
	public FTPUtil() {

	}

	private static void showServerReply(FTPClient ftpClient) {
		String[] replies = ftpClient.getReplyStrings();
		if (replies != null && replies.length > 0) {
			for (String aReply : replies) {
				logger.info("SERVER: " + aReply);
			}
		}
	}

	public static void createsFTPConnection(String serverIP, int port) {
		try {
			ftpClient.connect(serverIP, port);
			showServerReply(ftpClient);
			int replyCode = ftpClient.getReplyCode();
			if (!FTPReply.isPositiveCompletion(replyCode)) {
				logger.info("Operation failed. Server reply code: " + replyCode);
				return;
			}

		} catch (IOException ex) {
			logger.info("Oops! Something wrong happened");
			ex.printStackTrace();
		} catch (Exception ex) {
			logger.info("Parent Exception");
			ex.printStackTrace();
		}
	}

	public static void createsFTPConnectionWithOutPortNumber(String serverIP) {
		try {
			ftpClient.connect(serverIP);
			showServerReply(ftpClient);
			int replyCode = ftpClient.getReplyCode();
			if (!FTPReply.isPositiveCompletion(replyCode)) {
				logger.info("Operation failed. Server reply code: " + replyCode);
				return;
			}

		} catch (IOException ex) {
			logger.info("Oops! Something wrong happened");
			ex.printStackTrace();
		} catch (Exception ex) {
			logger.info("Parent Exception");
			ex.printStackTrace();
		}
	}

	public static void disconnectFTPConnection(String serverIP, int port) {
		try {
			showServerReply(ftpClient);
			int replyCode = ftpClient.getReplyCode();
			if (!FTPReply.isPositiveCompletion(replyCode)) {
				logger.info("Operation failed. Server reply code: " + replyCode);
				ftpClient.disconnect();

				return;
			}

		} catch (IOException ex) {
			logger.info("Oops! Something wrong happened");
			ex.printStackTrace();
		} catch (Exception ex) {
			logger.info("Parent Exception");
			ex.printStackTrace();
		}
	}

	public static void fetchFileNameFromFTP(String ftpFolderName) {
		// boolean success;
		try {
			// ftpClient.enterLocalPassiveMode();
			files = ftpClient.listFiles("/" + ftpFolderName);
			logger.info("new files" + files.toString().length());
			for (FTPFile file : files) {
				remotePath = "/" + ftpFolderName + "/" + file.getName();
				logger.info(" remote path is ==== " + remotePath);
			}

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Boolean checkFileExistsOnFTP(String ftpFolderName, String FileName) {
		try {
		FTPFile[] remoteFiles = ftpClient.listFiles("/"+ftpFolderName+"/"+FileName);
		for (int i = 0; i < remoteFiles.length; i++) {
			if (remoteFiles[i].getName().equals(FileName)) {
				System.out.println("File "+remoteFiles[i].getName()+" Exists on FTP Server..");
				return true;
			}	
		}
		return false;
		}
		catch(IOException Ioe) {
			Ioe.printStackTrace();
			return null;
		}
	}
		

	public static void fetchFileNameFromFTP(String userName, String password, String ftpFolderName) {
		boolean success;
		try {
			success = ftpClient.login(userName, password);
			showServerReply(ftpClient);
			if (!success) {
				logger.info("Could not login to the server");
				return;
			} else {
				logger.info("LOGGED IN SERVER");
				ftpClient.enterLocalPassiveMode();
			}
			ftpClient.enterLocalPassiveMode();
			/*
			 * files = ftpClient.listFiles("/"); for (FTPFile file : files) { String
			 * remoteFilePath = "/" + file.getName(); }
			 */

			files = ftpClient.listFiles("/" + ftpFolderName);
			for (FTPFile file : files) {
				remotePath = "/" + ftpFolderName + "/" + file.getName();
			}
			showServerReply(ftpClient);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static boolean uploadSingleFile(String localFilePath, String remoteFilePath) {
		File localFile = new File(localFilePath);
		InputStream inputStream = null;
		boolean uploadFlag = false;
		System.out.println("Local File path:: " + localFilePath);
		System.out.println("Remort File Path::" + remoteFilePath);
		try {
			inputStream = new FileInputStream(localFile);
			showServerReply(ftpClient);
			ftpClient.setFileType(FTP.BINARY_FILE_TYPE);
			uploadFlag = ftpClient.storeFile(remoteFilePath, inputStream);
			System.out.println("upload flag ==>" + uploadFlag);
			return uploadFlag;
		} catch (FileNotFoundException e) {
			logger.info("filenot  found ");
			e.printStackTrace();
		} /*
			 * catch (IOException e) { logger.info("io excep"); e.printStackTrace(); }
			 */ catch (Exception e) {
			logger.info("exce ");
			e.printStackTrace();
		} finally {
			try {
				inputStream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return uploadFlag;
	}

	public static void uploadDirectory(String remoteDirPath, String localParentDir, String remoteParentDir)
			throws IOException {
		// logger.info("LISTING directory: " + localParentDir);
		File localDir = new File(localParentDir);
		File[] subFiles = localDir.listFiles();
		if (subFiles != null && subFiles.length > 0) {
			for (File item : subFiles) {
				String remoteFilePath = remoteDirPath + "/" + remoteParentDir + "/" + item.getName();
				if (remoteParentDir.equals("")) {
					remoteFilePath = remoteDirPath + "/" + item.getName();
				}
				if (item.isFile()) {
					// upload the file
					String localFilePath = item.getAbsolutePath();
					boolean uploaded = uploadSingleFile(localFilePath, remoteFilePath);
					if (uploaded) {
						System.out.println("UPLOADED a file to: " + remoteFilePath);
					} else {
						System.out.println("COULD NOT upload the file: " + localFilePath);
					}
				} else {
					// create directory on the server
					boolean created = ftpClient.makeDirectory(remoteFilePath);
					if (created) {
						System.out.println("CREATED the directory: " + remoteFilePath);
					} else {
						System.out.println("COULD NOT create the directory: " + remoteFilePath);
					}

					// upload the sub directory
					String parent = remoteParentDir + "/" + item.getName();
					if (remoteParentDir.equals("")) {
						parent = item.getName();
					}

					localParentDir = item.getAbsolutePath();
					uploadDirectory(remoteDirPath, localParentDir, parent);
				}
			}
		}
	}

	public static void closesFTPConnection() {
		try {
			ftpClient.logout();
			ftpClient.disconnect();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public static List<String> fetchLocalFTPFiles(String localParentDir) {
		File localDir = new File(localParentDir);
		File[] files = localDir.listFiles();
		List<String> list = new ArrayList<String>();
		for (File file : files) {
			list.add(file.getName());
		}
		return list;
	}

	public static void createDirectoryOnLOcalSystem(String filePath) {
		File file = new File(filePath);
		boolean exists = file.exists();
		if (!exists) {
			new File(filePath).mkdir();
			logger.info("New file directory is created");
		}
	}

	public static void createFileOnLocalSystem(String filePath) {
		File file = new File(filePath);
		boolean fvar = false;
		try {
			fvar = file.createNewFile();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (fvar) {
			System.out.println("File has been created successfully");
		} else {
			System.out.println("File already present at the specified location");
		}

	}

}
