package com.qait.automation.utils;

import java.util.*;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.testng.annotations.Test;


public class TestRail {

	static String testrailUrl = "https://mnv.testrail.com/";
	static String username = "utkarsh.akhouri.contractor@macmillan.com";
	static String pass = "One2ka$4";
	static String testRunID;
	
	public static void main(String[] args) {
		String runID;
		runID = createTestRun("Sanity", "17", "1735", true);
		System.out.println(runID);
		postResultForTestCase("1107864", true, "AWSCM-200", "Win-8, Firefox");
		postResultForTestCase("1107865", false, "AWSCM-200", "Win-8, Firefox");
	}
	public static String createTestRun(String suiteType, String projectID, String suiteID, boolean includeAll) {
		APIClient client = new APIClient(testrailUrl);
		client.setUser(username);
		client.setPassword(pass);
		String name = suiteType + " " + CustomFunctions.getTestRunDateTimeString();
		Map PostData = new HashMap();
		PostData.put("suite_id", suiteID);
		PostData.put("name", name);
		PostData.put("description", "This is a TestRun generated through automation for '" + suiteType + "' suite");
		PostData.put("include_all", includeAll);
		String targetStr = "";
		try {
			System.out.println();
			JSONObject r = (JSONObject) client.sendPost("add_run/" + projectID + "/", PostData);
			JSONArray c = (JSONArray) client.sendGet("get_runs/"+projectID+"&suite_id="+suiteID+"&is_completed=0");
			targetStr = c.get(0).toString();
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (APIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String pattern = "[\"]id[\"]:(\\d+)";
		Pattern p = Pattern.compile(pattern);
		Matcher m = p.matcher(targetStr);
		if (m.find( )) {
			testRunID = m.group(1);
		}else {
			testRunID = "Could Not Find";
		}		
		return testRunID;
		
	}

	public static void postResultForTestCase(String caseID, boolean result, String defects, String version){
		APIClient client = new APIClient(testrailUrl);
		client.setUser(username);
		client.setPassword(pass);
		Map data = new HashMap();
		int statusid = getStatusId(result);
		String comment = testComment(statusid);
		data.put("status_id", statusid);
		data.put("comment", comment);
		data.put("defects", defects);
		data.put("version", version);
		try {
			JSONObject r = (JSONObject) client.sendPost("add_result_for_case/" + testRunID + "/" + caseID, data);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (APIException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


//	private static int getStatusId(String result) {
//		if(result.equalsIgnoreCase("pass")) return 1;
//		else if(result.equalsIgnoreCase("fail")) return 5;
//		else return 3;
//	}

	public static String testComment(int Status_ID) {
		String TestComment;
		if (Status_ID == 1) {
			TestComment = "PASSED: Test Case Passed Successfully!";
			return TestComment;
		} else if (Status_ID == 5) {
			TestComment = "FAILED: Test Case Failed!";
			return TestComment;
		} else if (Status_ID == 3) {
			TestComment = "UNTESTED: This Test Case was skipped because a depending Test Case Failed!";
			return TestComment;
		} else {
			TestComment = "BLOCKED: Test Case is Blocked!";
			return TestComment;
		}
	}

	public static int getStatusId(boolean checkResult) {
		int Status_ID;
		if (checkResult == true) {
			Status_ID = 1;
			return Status_ID;
		} else {
			Status_ID = 5;
			return Status_ID;
		}
	}

	/*public static void testPlanCreation(){
	APIClient client = new APIClient(testrailUrl);
	client.setUser(username);
	client.setPassword(pass);
	 // TestPlanCreator testPlanCreator = new TestPlanCreator();
	  client.setName("TESTPLANNAME");
	  List<Object> entries = new ArrayList<Object>();
	  
	   entries.setSuiteId(17);
	   entries.setIncludeAll(true);
	  entries.add(entry);
	  testPlanCreator.setEntries(entries);
}*/
}