package com.qait.automation.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.testng.Reporter;

public class Database
{
	static String currentExecDBPath = "src/test/resources/testdata/COMMON/execution.sq3";
	static Connection connection;	
	
	public static void createExecutionSummaryTable(String dbPath, String table) throws SQLException, ClassNotFoundException{
		Class.forName("org.sqlite.JDBC");
		Connection connection = null;
		connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
		Statement statement = connection.createStatement();
		statement.setQueryTimeout( 30);  
		
		statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + table + " (" +
				"exid int(11) NOT NULL PRIMARY KEY, " +      
				"project varchar(100) NOT NULL default '', " +
				"dispProject varchar(100) default '', " +
				"env varchar(50) default '', " +
				"dispEnv varchar(50) default '', " +
				"browser varchar(50) default '', " +
				"dispBrowser varchar(50) default '', " +
				"suiteType varchar(50) default '', " +
				"date varchar(50) default '', " +
				"time varchar(50) default '', " +
				"knownFailures int(3) , " + 
				"pass int(5) , " + 
				"fail int(5) , " +
				"skip int(5) , " +
				"total int(6))");
		if(connection != null)
			connection.close();	
	}
	
	public static void createScriptExecSummaryTable(String dbPath, String table) throws SQLException, ClassNotFoundException{
		Class.forName("org.sqlite.JDBC");
		Connection connection = null;
		connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
		Statement statement = connection.createStatement();
		statement.setQueryTimeout( 30);  
		
		statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + table + " (" +
				"exid int(11) NOT NULL , " +      
				"scriptName varchar(300) default '', " +
				"pass int(3) , " + 
				"fail int(2) , " +
				"skip int(3) , " +
				"total int(4))");
		if(connection != null)
			connection.close();	
	}
	
	public static void createFailureDetailsTable(String dbPath, String table) throws SQLException, ClassNotFoundException{
		Class.forName("org.sqlite.JDBC");
		Connection connection = null;
		connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
		Statement statement = connection.createStatement();
		statement.setQueryTimeout( 30);  
		
		statement.executeUpdate("CREATE TABLE IF NOT EXISTS " + table + " (" +
				"exid int(11) NOT NULL , " +      
				"scriptName varchar(300) default '', " +
				"testStep varchar(300) default '', " +
				"reason varchar(200) default '', " +
				"isKnown int(1), " +
				"screenshot varchar(300) default '')");
		if(connection != null)
			connection.close();	
	}
	
	public static void insertDataExecutionSummaryTable(String dbPath, String table, String data) throws SQLException, ClassNotFoundException{
		Class.forName("org.sqlite.JDBC");
		Connection connection = null;
		connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
		Statement statement = connection.createStatement();
		statement.setQueryTimeout( 30);  
		
		ResultSet rs = statement.executeQuery("select max(exid) as exid from " + table);
		String oldExID = "";
		while(rs.next())
		{
			oldExID = rs.getString("exid");
		}
		
		String sql = "insert into " + table + " (exid,";
		String[] dataSplit = data.split(";");
		for (int i = 0; i < dataSplit.length; i++) {
			sql += dataSplit[i].split("=")[0];
			if (i != (dataSplit.length - 1)) sql += ",";
		}
		sql += ") values (" + (Integer.parseInt(oldExID) + 1) + ",";
		for (int i = 0; i < dataSplit.length; i++) {
			sql += dataSplit[i].split("=")[1];
			if (i != (dataSplit.length - 1)) sql += ",";
		}
		sql += ")";
		System.out.println(sql);
		statement.executeUpdate(sql);
		
		if(connection != null)
			connection.close();
			
	}
	
	public static void insertDataCurrentExecutionTable(String testScript, String testStep, String screenshot, String failureMessage){
		failureMessage = failureMessage.replaceAll("[']", "\"");
		try {
			Class.forName("org.sqlite.JDBC");
			Connection connection = null;
			connection = DriverManager.getConnection("jdbc:sqlite:" + currentExecDBPath);
			Statement statement = connection.createStatement();
			statement.setQueryTimeout( 30);  

			String sql = "insert into execution values ('" + testScript + "', '" + testStep + "', '" + screenshot + "', '" + failureMessage + "')";
			statement.executeUpdate(sql);
			System.out.println("Done: insertDataCurrentExecutionTable");
			
			if(connection != null)
				connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void updateBuildInfoVersion(String buildName, String env, String version){
		try {
			Class.forName("org.sqlite.JDBC");
			Connection connection = null;
			String dbPath = "src/test/resources/testdata/COMMON/scheduler.sq3";
			connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
			Statement statement = connection.createStatement();
			statement.setQueryTimeout( 30);  

			String sql = "update BuildInfo set version='" + version + "' where buildName='" + buildName + "' and env='" + env + "'";
			statement.executeUpdate(sql);
			
			if(connection != null)
				connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void deleteDataCurrentExecutionTable(){
		try {
			Class.forName("org.sqlite.JDBC");
			Connection connection = null;
			connection = DriverManager.getConnection("jdbc:sqlite:" + currentExecDBPath);
			Statement statement = connection.createStatement();
			statement.setQueryTimeout( 30);

			String sql = "DELETE FROM execution";
			statement.executeUpdate(sql);

			if(connection != null)
				connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static ResultSet getSelectQueryResult(String dbPath, String query) throws SQLException, ClassNotFoundException{
		System.out.println("Executing Query...");
		System.out.println(query);
		Class.forName("org.sqlite.JDBC");
		connection = DriverManager.getConnection("jdbc:sqlite:" + dbPath);
		Statement statement = connection.createStatement();
		statement.setQueryTimeout(30);
		ResultSet rs = statement.executeQuery(query);
//		if(connection != null)
//			statement.close();
//			connection.close();
		return rs;
	}
	
//	public static void main(String[] args) throws ClassNotFoundException
//	{
//
//		try {
//			List<String> data = getMappedTestCaseIDs("src/test/resources/testdata/ONBOARDING/onboarding.sq3", "EulaPageTest", "Step02_Verify_Launchpad_Login_Page");
////			List<String> data = getMappedTestCaseIDs("src/test/resources/testdata/IAM/iam.sq3", "ForgotPasswordTest", "Step03_Click_Forgot_Password_Link");
//			System.out.println("5");
////			System.out.println(data.get(0));
//			for(int i=0 ; i < data.size(); i++)
//			{
//				System.out.println("printing value");
//				System.out.println(data.get(i));
//			}
//			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	}
	
//	public static List<String> getMappedTestCaseIDs(String dbPath, String tableName, String testStep) {
//	tableName = tableName.substring(tableName.lastIndexOf(".") + 1);
//	  ResultSet rs;
//	  List<String> lt = new ArrayList<String>();
//	  try {
//	   rs = getSelectQueryResult(dbPath, "select tcid from " + tableName + " where teststep='" + testStep + "'");
//	   while(rs.next())
//	   {
//	    lt.add(rs.getString("tcid"));
//	   }
//	   
//	   if(connection != null)
//	    connection.close();
//	  } catch (ClassNotFoundException e) {
//	   // TODO Auto-generated catch block
//	   e.printStackTrace();
//	  } catch (SQLException e) {
//	   // TODO Auto-generated catch block
//	   e.printStackTrace();
//	  }
//	  return lt;
//	 }

	public static List<String> getMappedTestCaseIDs(String dbPath, String tableName, String testStep) {
		tableName = tableName.substring(tableName.lastIndexOf(".") + 1);
		ResultSet rs;
		List<String> lt = new ArrayList<String>();
		try {
			rs = getSelectQueryResult(dbPath, "select tcid from " + tableName + " where teststep='" + testStep + "'");
			while(rs.next())
			{
				lt.add(rs.getString("tcid"));
			}
			if (lt.size() == 0){
				if(testStep.startsWith("Step")){
					testStep = testStep.substring(testStep.indexOf("_") + 1);
					rs = getSelectQueryResult(dbPath, "select tcid from " + tableName + " where teststep LIKE 'Step%" + testStep + "'");
					while(rs.next())
					{
						lt.add(rs.getString("tcid"));
					}
				}
				System.out.println("Test run");
			}
			
			if(connection != null)
				connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			System.out.println("No need to Map this method name with db browser and testrail");
		}
		return lt;
	}


	public static String getKnownIssue(String dbPath, String tableName, String testStep, String tcid) {
		tableName = tableName.substring(tableName.lastIndexOf(".") + 1);
		ResultSet rs;
		String defect = "";
		try {
			rs = getSelectQueryResult(dbPath, "select issue from " + tableName + " where teststep='" + testStep + "' and tcid='" + tcid + "' limit 1");
			System.out.println(rs);
			if(rs.next()){
				defect = rs.getString("issue");
			}
			if(connection != null)
				connection.close();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return defect;
	}
	
	
	
	
}