/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import static com.qait.automation.utils.DataReadWrite.getProperty;

import org.testng.Reporter;

@SuppressWarnings("unchecked")
public class YamlReader {

	public static String yamlFilePath;
	static String tier = System.getProperty("env");
	static String tier1 = null;
	static String product;

	public static void setProduct(String productName) {
		product = productName;
	}

	@SuppressWarnings("resource")
	public static String setYamlFilePath(String product) {
		if (tier == null)
			tier = getProperty("Config.properties", "tier").trim();
		System.out.println("Product is: " + product);
		if (tier1 != null) {
			tier = tier1;
		}
		if (tier.equalsIgnoreCase("dev")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "DEV_TestData.yml";
		} else if (tier.equalsIgnoreCase("qa")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "QA_TestData.yml";
		} else if (tier.equalsIgnoreCase("pr") || tier.equalsIgnoreCase("pristine")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "PR_TestData.yml";
		} else if (tier.equalsIgnoreCase("lt")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "LT_TestData.yml";
		} else if (tier.equalsIgnoreCase("prod") || tier.equalsIgnoreCase("production")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "PROD_TestData.yml";
		} else if (tier.equalsIgnoreCase("mice") || tier.equalsIgnoreCase("Mice")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "MICE_TestData.yml";
		} else if (tier.equalsIgnoreCase("iqa") || tier.equalsIgnoreCase("IQA")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "IQA_TestData.yml";
		} else if (tier.equalsIgnoreCase("stg") || tier.equalsIgnoreCase("stage")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "STG_TestData.yml";

		} else if (tier.equalsIgnoreCase("dnscutover") || tier.equalsIgnoreCase("dnscutover")) {
			yamlFilePath = "src" + File.separator + "test" + File.separator + "resources" + File.separator + "testdata"
					+ File.separator + product.toUpperCase() + File.separator + "dnscutover_TestData.yml";
		}
		System.out.println("Yaml file path :: " + yamlFilePath);
		try {
			new FileReader(yamlFilePath);
		} catch (FileNotFoundException e) {
			Reporter.log("Wrong Tier!!!", true);
			System.exit(0);
		}
		return yamlFilePath;
	}

	public static void setTier(String env) {
		tier1 = env;
	}

	public static String getTier() {
		return tier;
	}

	public static String getYamlValue(String token) {
		return getValue(token);
	}

	public static String getData(String token) {
		return getYamlValue(token);
	}

	public static Map<String, Object> getYamlValues(String token) {
		Reader doc;
		try {
			doc = new FileReader(yamlFilePath);
		} catch (FileNotFoundException ex) {
			System.out.println("File not valid or missing!!!");
			ex.printStackTrace();
			return null;
		}
		Yaml yaml = new Yaml();
		// TODO: check the type casting of object into the Map and create
		// instance in one place
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);
		return parseMap(object, token + ".");
	}

	private static String getValue(String token) {
		Reader doc = null;
		try {
			doc = new FileReader(yamlFilePath);
		} catch (FileNotFoundException e) {
			Reporter.log("Wrong tier", true);
			return null;
		}
		Yaml yaml = new Yaml();
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);

		return getMapValue(object, token);

	}

	public static String getMapValue(Map<String, Object> object, String token) {
		// TODO: check for proper yaml token string based on presence of '.'
		String[] st = token.split("\\.");
		return parseMap(object, token).get(st[st.length - 1]).toString();
	}

	private static Map<String, Object> parseMap(Map<String, Object> object, String token) {
		if (token.contains(".")) {
			String[] st = token.split("\\.");
			object = parseMap((Map<String, Object>) object.get(st[0]), token.replace(st[0] + ".", ""));
		}
		return object;
	}

	public static int generateRandomNumber(int MinRange, int MaxRange) {
		int randomNumber = MinRange + (int) (Math.random() * ((MaxRange - MinRange) + 1));
		return randomNumber;
	}
}
