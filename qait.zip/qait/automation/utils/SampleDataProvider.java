package com.qait.automation.utils;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.testng.annotations.DataProvider;


public class SampleDataProvider {
	
	@DataProvider
	public static Iterator<Object[]> Authentication() {
		String csvFilePath = System.getProperty("user.dir") + "/src/test/resources/testdata/StudentStoreBackend/ISBN.csv";
		List<Object[]> dataToBeReturned = new ArrayList<Object[]>();
		List<String> testData = DataReadWrite.readDataFromCSVFile(csvFilePath);
		for (String userData : testData) {
	        dataToBeReturned.add(new Object[] {userData});
	    }
		return dataToBeReturned.iterator();
	}
	
	
}
