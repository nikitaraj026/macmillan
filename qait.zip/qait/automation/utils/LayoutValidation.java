package com.qait.automation.utils;

import static com.qait.automation.utils.DataReadWrite.getProperty;

import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import net.mindengine.galen.api.Galen;
import net.mindengine.galen.reports.GalenTestInfo;
import net.mindengine.galen.reports.HtmlReportBuilder;
import net.mindengine.galen.reports.model.LayoutReport;
import net.mindengine.galen.validation.ValidationResult;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import com.qait.automation.getpageobjects.Tiers;

public class LayoutValidation {

    WebDriver driver;
    String PageName;
    static String tier;
    static String productName;
    private CustomAssert customAssert;
    private final String filepath = "src/test/resources/SpecFileRepository";
   
    static LinkedList<GalenTestInfo> tests = new LinkedList<GalenTestInfo>();
    
    public LayoutValidation(WebDriver driver, String pageName) {
        this.driver = driver;
        this.PageName = pageName;
        setTier();
        customAssert = new CustomAssert(driver);
    }
    
	public static void setProduct(String product) {
		productName = product;
	}

    @SuppressWarnings("static-access")
	public void checklayout(List<String> tagsToBeTested) {
        try {
            // Executing layout check and obtaining the layout report
            LayoutReport layoutReport = Galen.checkLayout(this.driver,
                    this.filepath + File.separator + productName.toUpperCase() + File.separator + 
                    this.tier.toUpperCase() + File.separator + this.PageName + ".spec",
                    tagsToBeTested, null, null, null);

            
            
            // Creating a list of tests

            // Creating an object that will contain the information about the
            // test
            GalenTestInfo test = GalenTestInfo.fromString(this.PageName + " : " + StringUtils.join(tagsToBeTested, ","));

            // Adding layout report to the test report
            test.getReport().layout(layoutReport,
                    this.PageName + " : " + StringUtils.join(tagsToBeTested, ","));
            tests.add(test);

            // Exporting all test reports to html
            new HtmlReportBuilder().build(tests, "target/galen-reports");
            String allErrors = "";
           if (layoutReport.errors() > 0) {
				Reporter.log("There are Layout Errors on the page:- "
						+ this.PageName + "!!! The Errors are for ", true);
				List<ValidationResult> valErrList = layoutReport.getValidationErrorResults();
				for (ValidationResult validationError : valErrList) {
					List<String> errMessages = validationError.getError().getMessages();
					for (String err : errMessages) {
						Reporter.log(err, true);
						allErrors += err + "\n";
					}
				}
				customAssert.customAssertTrue(false, "There are Layout Errors on the page:- "
						+ this.PageName + "!!! The Errors are for following:\n" + allErrors);
			}else{
				Reporter.log("There are no layout errors for Tags.", true);
			}
            

        } catch (IOException ex) {
            Reporter.log(ex.getLocalizedMessage(), true);
        }
    }
    
    private static void setTier() {
    	if(System.getProperty("env")!=null)
    		tier = System.getProperty("env").toUpperCase();
    	else{
	        switch (Tiers.valueOf(getProperty("Config.properties", "tier"))) {
	            case production:
	            case PROD:
	            case PRODUCTION:
	            case Production:
	            case prod:
	                tier = "PROD";
	                break;
	            case pristine:
	            case PR:
	            case PRISTINE:
	            case Pristine:
	            case pr:
	                tier = "PR";
	                break;
	            case qa:
	            case QA:
	            case Qa:
	                tier = "QA";
	                break;
	            case Dev:
	            case DEV:
	            case dev:
	                tier = "DEV";
	                break;
	            case lt:
	            case LT:            	
	                tier = "LT";
	                break;    
	            case dnscutover:            	
	                tier = "dnscutover";
	                break;
			default:
				break;
	        }
    	}
    }

}
