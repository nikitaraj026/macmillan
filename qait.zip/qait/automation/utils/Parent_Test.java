package com.qait.automation.utils;

import static com.qait.automation.TestSessionInitiator.getEnv;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.testng.IHookCallBack;
import org.testng.IHookable;
import org.testng.ITestContext;
import org.testng.ITestResult;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.BQTTestSessionInitiator;
import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.CMSTestInitiator;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.DAMTestInitiator;
import com.qait.automation.DlapTestSessionInitiator;
import com.qait.automation.HighSchoolTestSessionInitiator;
import com.qait.automation.IamTestInitiator;
import com.qait.automation.InstructorCatalogTestSessionInitiator;
import com.qait.automation.LPTestInitiator;
import com.qait.automation.Moodle2TestSessionInitiator;
import com.qait.automation.Moodle36TestSessionInitiator;
import com.qait.automation.MoodleTestSessionInitiator;
import com.qait.automation.OnboardingTestInitiator;
import com.qait.automation.QBATestSessionInitiator;
import com.qait.automation.SchoologyTestSessionInitiator;
import com.qait.automation.SiteBuilderTestSessionInitiator;
import com.qait.automation.StudentStoreTestInitiator;
import com.qait.automation.TechtoolTestSessionInitiator;
import com.qait.automation.TestSessionInitiator;
import com.qait.automation.XBookTestSessionInitiator;

import io.qameta.allure.Attachment;

/**
 * Steps Automated:
 * 
 */
public class Parent_Test implements IHookable {

	static boolean isTestRunCreated = false;
	static boolean testRailFlag = false;
	static String product, module;

	@Override
	public void run(IHookCallBack callBack, ITestResult testResult) {
		callBack.runTestMethod(testResult);
		if (testResult.getThrowable() != null) {
			try {
				takeScreenShot(testResult.getMethod().getMethodName());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Attachment(value = "Screenshot - {0}", type = "image/png")
	private byte[] takeScreenShot(String methodName) throws IOException {
		return CustomFunctions.takeScreenshotForAllure();
	}

	public static void beforeSuiteMethod() {
		System.out.println("[Start] : BeforeSuteMethod");
		String dirPath = "C:";
		File f = new File(dirPath);
		if (!f.exists())
			dirPath = System.getProperty("user.home") + File.separator + "Desktop";
		product = System.getProperty("product");
		if (product == null)
			product = ConfigPropertyReader.getProperty("product");
		String filePath = dirPath + File.separator + "execution.csv";
		if (product != null)
			filePath = dirPath + File.separator + product + ".csv";
		f = new File(filePath);
		if (f.exists())
			f.delete();
		CustomFunctions.deleteFTPFile("/selenium/test/automation/screenshotLinks/" + product + ".csv");
		System.out.println("[End] : BeforeSuteMethod");
	}

	public static void beforeSuiteMethod(ITestContext itc) {
		System.out.println("[Start] : BeforeSuteMethod");
		String dirPath = "C:";
		File f = new File(dirPath);
		if (!f.exists())
			dirPath = System.getProperty("user.home") + File.separator + "Desktop";
		product = System.getProperty("product");
		if (product == null)
			product = ConfigPropertyReader.getProperty("product");
		String filePath = dirPath + File.separator + "execution.csv";
		if (product != null)
			filePath = dirPath + File.separator + product + ".csv";
		f = new File(filePath);
		if (!itc.getSuite().getName().equals("BugRegressionTestNG")) {
			if (f.exists())
				f.delete();
			CustomFunctions.deleteFTPFile("/selenium/test/automation/screenshotLinks/" + product + ".csv");
			System.out.println("FTPFile Path : " + "/selenium/test/automation/screenshotLinks/" + product + ".csv");
		}
		Database.deleteDataCurrentExecutionTable();
		System.out.println("[End] : BeforeSuteMethod");
	}

	public static void beforeSuiteMethod(String suiteType, String productID, String suiteID) {
		System.out.println("[Start] : BeforeSuteMethod");
		String dirPath = "C:";
		File f = new File(dirPath);
		if (!f.exists())
			dirPath = System.getProperty("user.home") + File.separator + "Desktop";
		product = System.getProperty("product");
		if (product == null)
			product = ConfigPropertyReader.getProperty("product");
		String filePath = dirPath + File.separator + "execution.csv";
		if (product != null)
			filePath = dirPath + File.separator + product + ".csv";
		
		System.out.println("dirPath---------------"+ dirPath);
		System.out.println("filePath---------------"+ filePath);
		
		f = new File(filePath);
		if (f.exists())
			f.delete();
		CustomFunctions.deleteFTPFile("/selenium/test/automation/screenshotLinks/" + product + ".csv");
		System.out.println("FTPFile Path : " + "/selenium/test/automation/screenshotLinks/" + product + ".csv");
		testRailFlag = TestSessionInitiator.getTestRailUpdationFlag();
		if (testRailFlag) {
			if (!isTestRunCreated) {
				isTestRunCreated = true;
				createTestRailTestRun(getEnv().toUpperCase() + "_" + suiteType, productID, suiteID);
			}
		}
		Database.deleteDataCurrentExecutionTable();
		System.out.println("[End] : BeforeSuteMethod");
	}

	private static void createTestRailTestRun(String suiteType, String productID, String suiteID) {
		String testRunID = "";
		testRunID = TestRail.createTestRun(suiteType, productID, suiteID, true);
		System.out.println("Created TestRun ID : " + testRunID);
	}

	private static void manageTestRailTestRunUpdation(ITestResult result, String testName) {
		// TODO : Find defects and configuration/title info
		product = TestSessionInitiator.product;
		String subProduct = "";
		module = System.getProperty("module");

		if (module == null) {
			module = ConfigPropertyReader.getProperty("module");
		}
		if (!module.equals("NA")) {
			subProduct = product + "_" + module;
		} else {
			subProduct = product;
		}
		if (testRailFlag && (result.getStatus() == ITestResult.FAILURE || result.getStatus() == ITestResult.SUCCESS)) {
			String dbPath = "src/test/resources/testdata/" + product.toUpperCase() + "/" + subProduct + ".sq3";
			System.out.println(dbPath);
			String testStep = result.getName().toString().trim();

			List<String> testcids = Database.getMappedTestCaseIDs(dbPath, testName, testStep);
			List<String> tcids = new ArrayList<String>();
			for (String caseID : testcids) {
				if (caseID.startsWith("C")) {
					tcids.add(caseID.substring(1));
				} else {
					tcids.add(caseID);
				}
			}

			boolean resultStatus = false;
			if (result.getStatus() == ITestResult.SUCCESS)
				resultStatus = true;
			String defects = "";
			if (!tcids.isEmpty()) {
				for (String tcid : tcids) {
					if (!resultStatus) {
						defects = Database.getKnownIssue(dbPath, testName, testStep, tcid);
					}
					TestRail.postResultForTestCase(tcid, resultStatus, defects, "");
				}
			}
		}
	}

	public static void afterMethod(AQETestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");

			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(SiteBuilderTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", "Result",
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(CMSTestInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", "Result",
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(BlackBoardTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");

			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(BQTTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(CanvasTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(D2LTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(LPTestInitiator test, ITestResult result, String testName) {
		System.out.println("[Start] : AfterMethod");
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
			System.out
					.println("[TestName] : " + testName + "\n[Result] : " + result + "\n[Screenshot] : " + screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
		System.out.println("[End] : AfterMethod");
	}

	public static void afterMethod(QBATestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(TechtoolTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(XBookTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(DlapTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
//			String screenshot = test.customFunctions.takeScreenshot("Screenshots",
//					testName, TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
//					TestSessionInitiator.getFTPPassword(), test.getUploadScreenshotToFtp().equalsIgnoreCase("yes")?"true":"false");
//			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(InstructorCatalogTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(MoodleTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(Moodle2TestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(Moodle36TestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

//	public static void afterMethod(HighSchoolTestSessionInitiator test, ITestResult result, String testName) {
//		if (result.getStatus() == ITestResult.FAILURE) {
//			String screenshot = test.customFunctions.takeScreenshot("Screenshots", "Result",
//					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
//					TestSessionInitiator.getFTPPassword(),
//					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
//			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
//		}
//		manageTestRailTestRunUpdation(result, testName);
//	}

	public static void afterMethod(OnboardingTestInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", "Result",
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(IamTestInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");

			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(StudentStoreTestInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", "Result",
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}

	public static void afterMethod(DAMTestInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", "Result",
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}
	public static void afterMethod(SchoologyTestSessionInitiator test, ITestResult result, String testName) {
		if (result.getStatus() == ITestResult.FAILURE) {
			String screenshot = test.customFunctions.takeScreenshot("Screenshots", testName,
					TestSessionInitiator.getFTPUrl(), TestSessionInitiator.getFTPUserID(),
					TestSessionInitiator.getFTPPassword(),
					test.getUploadScreenshotToFtp().equalsIgnoreCase("yes") ? "true" : "false");
			CustomFunctions.updateFailScriptFile(testName, result, screenshot);
		}
		manageTestRailTestRunUpdation(result, testName);
	}
}
