package com.qait.automation.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;
import java.util.*;
import javax.mail.*;
import javax.mail.internet.*;
import org.testng.Assert;
import org.testng.Reporter;

import com.qait.automation.report.Authenticator;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class ReadEmail {

	int count;
	long mail_time;

	static String res="";
	
	static String host = "smtp.gmail.com";
	static String from = "demosftester@gmail.com";
	static String To;

	static String password = "qait@123";
	static int port = 25;
	static String reply;
	static String _repliedText;

	public static void SendEmail(String to, String cc, String subject) {
		// Recipient's email ID needs to be mentioned.
		String ToList[] = to.split(",");
		System.out.println("ToList is::" + ToList.length);

		String CCList[] = cc.split(",");
		System.out.println("CCList is::" + CCList[0]);

		Properties props = new Properties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.socketFactory.port", "465");
		props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.port", "465");

		Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("demosftester@gmail.com", "qait@123");
			}
		});

		try {
			// Create a default MimeMessage object.
			MimeMessage message = new MimeMessage(session);

			// Set From: header field of the header.
			message.setFrom(new InternetAddress("demosftester@gmail.com"));

			// Set To: header field of the header.
			for (String t : ToList) {
				System.out.println("To is" + t);
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(t));
			}
			if (CCList[0].equals("")) {

			} else {
				for (String cc1 : CCList) {
					System.out.println("CC is" + cc1);
					message.addRecipient(Message.RecipientType.CC, new InternetAddress(cc1));
				}

			}

			// Set Subject: header field
			message.setSubject(subject);

			// Now set the actual message
			message.setText("For Testing!!");

			// Send message
			Transport.send(message);
			System.out.println("Sent message successfully....");
			Assert.assertTrue(true);
		} catch (MessagingException mex) {
			mex.printStackTrace();
			Assert.assertTrue(false);
		}
	}

	public static void deleteAllMailsFromSpecificMails(String folder) {
		Message[] messages;
		Folder emailFolder;
		Store store;
		Session session;
		System.out.println("before try****");
		Properties properties = new Properties();

		Message[] m;
		Message mm;
		Properties props = new Properties();
		String content;
		props.setProperty("mail.store.protocol", "imaps");

		try {
			session = Session.getInstance(props, null);
			store = session.getStore();
			store.connect("imap.gmail.com", "demosftester@gmail.com", "qait@123");
			Folder[] folderList = store.getFolder("[Gmail]").list();
			for (int i = 0; i < folderList.length; i++) {
				System.out.println(folderList[i].getFullName());
			}
			Folder inbox = store.getFolder(folder);
			inbox.open(Folder.READ_WRITE);
			m = inbox.getMessages();

			System.out.println("msg" + m.length);
			for (int i = 0; i < m.length; i++) {

				mm = m[i];
				mm.setFlag(Flags.Flag.DELETED, true);
			}

		//	driver.quit();
		} catch (MessagingException me) {
		}
	}

	

	
	public static String writePart(Part p) throws Exception {
	       System.out.println("----------------------------");
	       System.out.println("CONTENT-TYPE: " + p.getContentType());

	       //check if the content is plain text
	       if (p.isMimeType("text/plain")) {
	          System.out.println("This is plain text");
	          System.out.println("---------------------------");
	          System.out.println((String) p.getContent());
	          res= (String) p.getContent();
	       } 
	       //check if the content has attachment
	       else if (p.isMimeType("multipart/*")) {
	          System.out.println("This is a Multipart");
	          System.out.println("---------------------------");
	          Multipart mp = (Multipart) p.getContent();
	          int count = mp.getCount();
	          for (int i = 0; i < count; i++)
	             writePart(mp.getBodyPart(i));
	       } 
	       return res;
	    }
	
	public static String verifyEmailFiltersToSpecificFolder(String folder, String type) {
	  Message[] messages;
	  Folder emailFolder;
	  Store store;
	  Session session;
	  System.out.println("before try****");
	  Properties properties = new Properties();

	  Message[] m;
	  Message mm;
	  Properties props = new Properties();
	  // String content = "";
	  props.setProperty("mail.store.protocol", "imaps");

	  try {

	   session = Session.getInstance(props, null);
	   store = session.getStore();
	   store.connect("imap.gmail.com", "demosftester@gmail.com", "qait@123");
	   Folder[] folderList = store.getFolder("[Gmail]").list();
	   for (int i = 0; i < folderList.length; i++) {
	    System.out.println(folderList[i].getFullName());
	   }
	   Thread.sleep(5000);
	   Folder inbox = store.getFolder(folder);
	   inbox.open(Folder.READ_WRITE);
	   m = inbox.getMessages();

	   System.out.println("msg" + m.length);
	   for (int i = 0; i < m.length; i++) {

	    mm = m[i];

	    if (type.equals("Subject")) {
	     // Assert.assertTrue(mm.getSubject().contains(bodyContent),
	     // "Assertion Failed:: Mail do not contain as type of
	     // Content " + mm.getSubject());
	     Reporter.log("Assertion Passed:: Mail contain " + mm.getSubject());
	     res = mm.getSubject();

	     deleteMail(mm);
	     return res;
	    } else if (type.equals("Content")) {
	     Object content = mm.getContent();
	     System.out.println("content "+content.toString());
	     if (content instanceof String) {
	      System.out.println("content inside if:"+content);
	      deleteMail(mm);
	      return (String) content;

	     }

	     if (mm.isMimeType("text/plain")) {
	      System.out.println("text/plain::"+mm.getContent().toString());
	      res = mm.getContent().toString();
	     } else if (mm.isMimeType("multipart/*")) {
	      res=writePart(mm);
	    
	     }
	     
	    }
	    deleteMail(mm);
	    return res;
	  }

	  } catch (Exception e) {
	   System.out.println("Exeception is"+e);
	  }
	  return res;
	 }
	
	

	
	public static int read() {
		Properties props = new Properties();
		props.setProperty("mail.store.protocol", "imaps");
		Session session;
		Store store;
		int messageCount=0;
		try {
			session = Session.getInstance(props, null);
			store = session.getStore();
			// props.load(new FileInputStream(new File("C:\\smtp.properties")));
			// Session session = Session.getDefaultInstance(props, null);
			// Store store = session.getStore("imaps");
			store.connect("imap.gmail.com", "demosftester@gmail.com", "qait@123");

			Folder inbox = store.getFolder("SalesForceMails");
			inbox.open(Folder.READ_ONLY);
			 messageCount = inbox.getMessageCount();

			System.out.println("Total Messages:- " + messageCount);

			Message[] messages = inbox.getMessages();
			System.out.println("------------------------------");

			for (int i = 0; i < messageCount; i++) {
				System.out.println("Mail Subject:- " + messages[i].getSubject());
				System.out.println("Mail Subject:- " + messages[i].getContent().toString());
			}
              
			inbox.close(true);
			store.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return messageCount;
		
	}

	public static String getTextContentOfMail(String content) {
		String text = null;
		if (content != null) {
			Document doc = Jsoup.parse(content);
			doc.outputSettings().charset("UTF-8");
			doc.body().wrap("<pre></pre>");
			text = doc.text();
			text = text.replaceAll("\u00A0", " ");
			System.out.println("Final Text" + text + "\n");

		}
		return text;
	}

	public static void deleteMail(Message mm) {
		try {
			mm.setFlag(Flags.Flag.DELETED, true);
			//driver.quit();
		} catch (MessagingException me) {

		}
	}

	public static void ReplyEmailOnSameSubject(String repliedText) {

		Message[] messages;
		Folder emailFolder;
		Store store;
		Session session;
		System.out.println("before try****");
		Properties properties = new Properties();

		Message[] m;
		Message mm;

		Properties props = new Properties();		
		props.setProperty("mail.store.protocol", "imaps");

		try {
			session = Session.getInstance(props);
			store = session.getStore();
			store.connect("imap.gmail.com", "demosftester@gmail.com", "qait@123");
			Folder[] folderList = store.getFolder("[Gmail]").list();
			for (int i = 0; i < folderList.length; i++) {
				System.out.println(folderList[i].getFullName());
			}
			Folder inbox = store.getFolder("SalesForceMails");
			inbox.open(Folder.READ_ONLY);
			messages = inbox.getMessages();
			System.out.println("Total Message - " + messages.length);
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			for (int i = 0; i < messages.length; i++) {
				Message emailMessage = messages[i];
				System.out.println();
				System.out.println("Email " + (i + 1) + " -");
				System.out.println("Subject - " + emailMessage.getSubject());
				System.out.println("From - " + emailMessage.getFrom()[0]);
			}
			System.out.print("Enter email number to " + "which you want to reply: ");
			String emailNo = "1";
			Message emailMessage = inbox.getMessage(Integer.parseInt(emailNo));
			Message mimeMessage = new MimeMessage(session);
			mimeMessage = (MimeMessage) emailMessage.reply(false);
			mimeMessage.setFrom(new InternetAddress("demosftester@gmail.com"));
			mimeMessage.setText(repliedText);
			_repliedText = repliedText;
			reply = "RE: " + mimeMessage.getSubject();
			mimeMessage.setSubject("RE: " + mimeMessage.getSubject());
			To	=	 emailMessage.getFrom()[0].toString();
//			mimeMessage.addRecipient(Message.RecipientType.TO, emailMessage.getFrom()[0]);
			// Transport.send(mimeMessage);
			sendResultsMail();
			System.out.println("Email message " + "replied successfully.");
			inbox.close(false);
			store.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("Error in replying email.");

		}

	}

	

	private static Session getSession() {
		Authenticator authenticator = new Authenticator(from, password);
		Properties properties = new Properties();
		properties.setProperty("mail.transport.protocol", "smtps");
		properties.put("mail.smtps.auth", "true");
		properties.setProperty("mail.smtp.submitter", authenticator.getPasswordAuthentication().getUserName());
		properties.setProperty("mail.smtp.auth", "true");
		properties.setProperty("mail.smtp.host", host);
		properties.setProperty("mail.smtp.port", String.valueOf(port));
		return Session.getInstance(properties, authenticator);
	}

	public static void sendResultsMail() throws MessagingException, IOException {

		if (true) { // send email is true *************************
			Message message = new MimeMessage(getSession());
			message.addFrom(new InternetAddress[] { (new InternetAddress(from)) });
			System.out.println("Hello1");
			setMailRecipient(message);
			message.setContent(setAttachment());
			message.setSubject(reply);
			Session session = getSession();
			Transport transport = session.getTransport("smtps");
			transport.connect(host, from, password);
			transport.sendMessage(message, message.getAllRecipients());
			transport.close();
		}
		System.out.println("Reports emailed");

	}

	private static Multipart setAttachment() {
		// Create the message part
		MimeBodyPart messageBodyPart = new MimeBodyPart();

		try {
			messageBodyPart.setContent(_repliedText, "text/html");
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		MimeMultipart multipart = new MimeMultipart();
		try {
			multipart.addBodyPart(messageBodyPart);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Part two is attachment
		messageBodyPart = new MimeBodyPart();

		return multipart;

	}

	private static void setMailRecipient(Message message) throws AddressException, MessagingException, IOException {

		message.addRecipient(Message.RecipientType.TO, new InternetAddress(To));
	}

	public static void forwardEmails()
	{

	Message[] messages;
	Folder emailFolder;
	Store store;
	Session session;
	System.out.println("before try****");
	Properties properties = new Properties();

	Message[] m;
	Message mm;

	Properties props = new Properties();		
	props.setProperty("mail.store.protocol", "imaps");
	 try {
		 session = Session.getInstance(props);
			store = session.getStore();
			store.connect("imap.gmail.com", "demosftester@gmail.com", "qait@123");
         

         // Create a Folder object and open the folder
         Folder folder = store.getFolder("inbox");
         folder.open(Folder.READ_ONLY);
         BufferedReader reader = new BufferedReader(new InputStreamReader(
            System.in));
        messages = folder.getMessages();
         if (messages.length != 0) {

         for (int i = 0, n = messages.length; i < n; i++) {
            Message message = messages[i];
            // Get all the information from the message
            String from = InternetAddress.toString(message.getFrom());
            if (from != null) {
               System.out.println("From: " + from);
            }
            String replyTo = InternetAddress.toString(message
               .getReplyTo());
            if (replyTo != null) {
               System.out.println("Reply-to: " + replyTo);
            }
            String to = InternetAddress.toString(message
               .getRecipients(Message.RecipientType.TO));
            if (to != null) {
               System.out.println("To: " + to);
            }

            String subject = message.getSubject();
            if (subject != null) {
               System.out.println("Subject: " + subject);
            }
            Date sent = message.getSentDate();
            if (sent != null) {
               System.out.println("Sent: " + sent);
            }
            System.out.print("Do you want to reply [y/n] : ");
            String ans = reader.readLine();
            if ("Y".equals(ans) || "y".equals(ans)) {
               Message forward = new MimeMessage(session);
               // Fill in header
               forward.setRecipients(Message.RecipientType.TO,
               InternetAddress.parse(from));
               forward.setSubject("Fwd: " + message.getSubject());
               forward.setFrom(new InternetAddress(to));

               // Create the message part
               MimeBodyPart messageBodyPart = new MimeBodyPart();
               // Create a multipart message
               Multipart multipart = new MimeMultipart();
               // set content
               messageBodyPart.setContent(message, "message/rfc822");
               // Add part to multi part
               multipart.addBodyPart(messageBodyPart);
               // Associate multi-part with message
               forward.setContent(multipart);
               forward.saveChanges();

               // Send the message by authenticating the SMTP server
               // Create a Transport instance and call the sendMessage
               Transport t = session.getTransport("smtp");
               try {
                  //connect to the smpt server using transport instance
		  //change the user and password accordingly
                  t.connect("abc", "*****");
                  t.sendMessage(forward, forward.getAllRecipients());
               } finally {
                  t.close();
               }

               System.out.println("message forwarded successfully....");

            // close the store and folder objects
            folder.close(false);
            store.close();
            }// end if

         } 
         }
	 }catch (Exception e) {
             e.printStackTrace();
         }
	}


}
