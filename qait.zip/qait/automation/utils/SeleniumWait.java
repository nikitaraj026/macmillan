package com.qait.automation.utils;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

public class SeleniumWait{
    
    WebDriver driver;
    WebDriverWait wait;
    public int timeout;
    public int configTimeOut;
   
    
    public SeleniumWait(WebDriver driver, int timeout) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, timeout);
        this.timeout = timeout;
        this.configTimeOut = timeout;
      
    }

    /**
     * Returns webElement found by the locator if element is visible
     *
     * @param locator
     * @return
     */
    public WebElement getWhenVisible(By locator) {
        WebElement element;
        element = wait.until(ExpectedConditions
                .visibilityOfElementLocated(locator));
        return element;
    }
    
    public WebElement getWhenClickable(By locator) {
        WebElement element;
        element = wait.until(ExpectedConditions.elementToBeClickable(locator));
        return element;
    }
    
    public boolean waitForPageTitleToBeExact(String expectedPagetitle) {
        return wait.until(ExpectedConditions.titleIs(expectedPagetitle));
    }
    
    public boolean waitForPageTitleToContain(String expectedPagetitle) {
        return wait.until(ExpectedConditions.titleContains(expectedPagetitle));
    }
    
    public WebElement waitForElementToBeVisible(WebElement element) {	
    	try{
    		return wait.until(ExpectedConditions.visibilityOf(element));
    	}
    	catch(StaleElementReferenceException e){
    		return wait.until(ExpectedConditions.visibilityOf(element));
    	}
    }
    
    public void waitForFrameToBeAvailableAndSwitchToIt(By locator) {
        wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(locator));
    }
    
   /* public void waitUntillElementIsStale(WebElement element){
    	wait.until(ExpectedConditions.stalenessOf(element));
    }*/
    
    public List<WebElement> waitForElementsToBeVisible(List<WebElement> elements) {
        return wait.until(ExpectedConditions.visibilityOfAllElements(elements));
    }
    
    public boolean waitForElementToBeInVisible(By locator) {
        return wait.until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }
    
    public WebElement waitForElementToBeClickable(WebElement element) {
        return wait.until(ExpectedConditions.elementToBeClickable(element));
    }
    
    public void clickWhenReady(By locator) {
        WebElement element = wait.until(ExpectedConditions
                .elementToBeClickable(locator));
        element.click();
    }

    public void verifyMsgToast(String msgSubstring) {
    	String toastMsg = driver.findElement(By.className("toast-message")).getText().trim();
    	if (!toastMsg.contains(msgSubstring)) {
    		org.testng.Assert.assertTrue(false, "Assertion Failed : Toast Message does not contain '" + msgSubstring + "'");
    	}
    }
    
    public void waitForMsgToastToAppear(String msgSubstring) {
        int i = 0;
        resetImplicitTimeout(1);
        while(true) {
        	try {
        		if (driver.findElement(By.className("toast-message")).isDisplayed()) {
        			resetImplicitTimeout(timeout);  
        			verifyMsgToast(msgSubstring);
        			return;
        		}
        	}catch (Exception e) {
        		hardWait(1);
        		i++;
        		if (i > timeout) {
        			break;
        		}
        		continue;
        	}
        } 
        resetImplicitTimeout(timeout);
    }
    
    public void waitForMsgToastToDisappear() {
        int i = 0;
        resetImplicitTimeout(1);
        try {
            while (driver.findElement(By.className("toast-message")).isDisplayed() && i <= timeout) {
                hardWait(1);                
                i++;
            }
        } catch (Exception e) {
        }
        resetImplicitTimeout(timeout);        
    }
    
    public void waitForElementToDisappear(WebElement element) {
        int i = 0;
        resetImplicitTimeout(2);
        try {
            while (element.isDisplayed() && i <= timeout) {
                hardWait(1);                
                i++;
            }
        } catch (Exception e) {
        }
        resetImplicitTimeout(timeout);        
    }
    /**
     * returns global timeout mention in config file so that after executing task 
     * user can reset it to previous value
     * **/
    public int resetImplicitTimeout(int newTimeOut) {
    	try {
            driver.manage().timeouts().implicitlyWait(newTimeOut, TimeUnit.SECONDS);
        } catch (Exception e) {	
        	
        }
    	return timeout;
    }

	public void resetExplicitTimeout(int newTimeOut) {
		try {
			this.wait = new WebDriverWait(driver, newTimeOut);
		} catch (Exception e) {
		}
	}

    public void setTimeout(int newTimeout) {
    	timeout = newTimeout;
    }
    
    // TODO Implement Wait for page load for page synchronizations
    public void waitForPageToLoadCompletely() {	
    	// wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*")));	
    	hardWait(2);		
    	wait.until(new ExpectedCondition<Boolean>(){
    			public Boolean apply(WebDriver wdriver) {
    				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");	
    		}	
    	});		Reporter.log("Page loaded completely");	}
    
    public void hardWait(int seconds) {
        try {
            Thread.sleep(seconds * 1000);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
    public void hardWaitWithMS(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }
    }
    
    @FindBy(id = "loadingBlock")
    WebElement loader;
    
    public void waitForLoaderToDisappear() {
        int i = 0;
        hardWait(2);
        resetImplicitTimeout(5);
        try {
            while (loader.isDisplayed() && i <= timeout) {
                hardWait(1);                
                i++;
            }
        } catch (Exception e) {	
        }
        resetImplicitTimeout(timeout);        
    }
    
    @FindBy(className = "load-block-container")
    WebElement loaderMessage;
    
    public void waitForLoadingMessageToDisappear() {
        int i = 0;
        hardWait(2);
        resetImplicitTimeout(5);
        try {
            while (loaderMessage.isDisplayed() && i <= timeout) {
                hardWait(1);                
                i++;
            }
        } catch (Exception e) {	
        }
        resetImplicitTimeout(timeout);        
    }
    
    @FindBy(xpath = "//div[@class='full-loading-overlay']")
    WebElement progressBar;
    
    public void waitForProgressBarToAppearAndDisappear() {
        waitForProgressBarToAppear();
        waitForProgressBarToDisappear();
    }
    
    public void waitForProgressBarToAppear() {
        int i = 0;
        resetImplicitTimeout(1);
        while(true) {
        	try {
        		if (progressBar.isDisplayed()) {
        			resetImplicitTimeout(timeout);  
        			return;
        		}
        	}catch (Exception e) {
        		hardWait(1);
        		i++;
        		if (i > timeout) {
        			break;
        		}
        		continue;
        	}
        } 
        resetImplicitTimeout(timeout);
    }
    
    public void waitForProgressBarToDisappear() {
        int i = 0;
        resetImplicitTimeout(1);
        try {
            while (progressBar.isDisplayed() && i <= timeout) {
                hardWait(1);                
                i++;
            }
        } catch (Exception e) {
        }
        resetImplicitTimeout(timeout);  
    }
    
    public int getTimeout() {
    	return configTimeOut;
    }
    
    @FindBy(xpath = "//*[@class='full-lp-logo']")
    WebElement fullLoader;
    
    public void waitForFullLoaderToDisappear() {
        int i = 0;
        resetImplicitTimeout(5);
        try {
            while (fullLoader.isDisplayed() && i <= timeout) {
                hardWait(1);                
                i++;
            }
        } catch (Exception e) {	
        }
        resetImplicitTimeout(timeout);        
    }
    
    public void waitForLoaderToAppearAndDisappear() {
    	resetImplicitTimeout(1);
        try {
        	hardWait(1);
            driver.findElements(By.xpath("//div[@class='blockUI blockMsg blockElement']")).get(0).isDisplayed();
        } catch (Exception e) {
        	resetImplicitTimeout(timeout);
            return;
        }
        
        int k = 200, j=0;
        int size = 10;
        
        try{
        for (j = 1; j < k; j++) {
            size = driver.findElements(By.xpath("//div[@class='blockUI blockMsg blockElement']")).size();
            if (size == 0) {
                break;
            } else {
                hardWait(1);
                continue;
            }
        }}
        catch(Exception e) {
        }
        Assert.assertTrue(j<200,"Loader does not disappear in 200 secs");
        Reporter.log("Loader disappeared in "+j+" secs", true);
        resetImplicitTimeout(timeout);
        waitForFullLoaderToDisappear();
        waitForLoaderToDisappear();
    }
    
    public boolean isAlertPresent(){
		try{
			wait.until(ExpectedConditions.alertIsPresent());
            return true;
        }
        catch(Exception e){
            return false;
        }
		
    }
    
   
}
