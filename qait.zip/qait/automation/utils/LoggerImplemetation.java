package com.qait.automation.utils;

import java.io.File;
import org.apache.log4j.Logger;

import org.apache.log4j.PropertyConfigurator;

public class LoggerImplemetation {

	public static org.apache.log4j.Logger logConfig(String classname) {
		Logger logger = Logger.getLogger(classname);
		String log4jConfigFile = System.getProperty("user.dir")
				+ File.separator + "src//test//resources//Logger//log4j.properties";
		PropertyConfigurator.configure(log4jConfigFile);
		return logger;
	}
}
