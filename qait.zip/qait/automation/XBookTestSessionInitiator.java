package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import java.util.Map;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.YamlReader;
import com.qait.xbook.keywords.AssignmentPageActions;
import com.qait.xbook.keywords.DashboardPageActions;
import com.qait.xbook.keywords.FandEPageActions;
import com.qait.xbook.keywords.GradebookPageActions;
import com.qait.xbook.keywords.HeaderPageActions;
import com.qait.xbook.keywords.HomePageActions;
import com.qait.xbook.keywords.JoinCoursePageActions;
import com.qait.xbook.keywords.LearningCurvePageActions;
import com.qait.xbook.keywords.LoginPageActions;
import com.qait.xbook.keywords.ResourcesPageActions;
import com.qait.xbook.keywords.SearchPageActions;
import com.qait.xbook.keywords.TOCPageActions;
import com.qait.xbook.keywords.TopMenuActions;

public class XBookTestSessionInitiator extends TestSessionInitiator{

	 
	    Map<String, Object> chromeOptions = null;
		public CustomFunctions customFunctions;
		public LoginPageActions loginPage;
		public DashboardPageActions dashboardPage;
		public HomePageActions homePage;
		public AssignmentPageActions assignmentPage;
		public TopMenuActions topMenu;
		public GradebookPageActions gradebookPage;
		public HeaderPageActions headerPage;
		public JoinCoursePageActions joinCoursePage;
		public SearchPageActions searchPage;
		public FandEPageActions fandePage;
		public LearningCurvePageActions learningCurvePage;
		public ResourcesPageActions resourcesPage;
		public TOCPageActions tocpage;
		private String product_local;

	    private void _initPage() {
			customFunctions = new CustomFunctions(driver);
			loginPage = new LoginPageActions(driver);
			dashboardPage = new DashboardPageActions(driver);
			homePage = new HomePageActions(driver);
			assignmentPage = new AssignmentPageActions(driver, originalDriver);
			topMenu = new TopMenuActions(driver);
			gradebookPage = new GradebookPageActions(driver);
			tocpage= new TOCPageActions(driver);
			headerPage = new HeaderPageActions(driver);
			joinCoursePage = new JoinCoursePageActions(driver);
			searchPage = new SearchPageActions(driver);
			fandePage= new FandEPageActions(driver, originalDriver);
			learningCurvePage = new LearningCurvePageActions(driver);
			resourcesPage = new ResourcesPageActions(driver);
	    }

	    public XBookTestSessionInitiator() {
	       super();
	       setProduct();
	       setYamlFilePath(product_local);
	       configureBrowser();
	       _initPage();
	       customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
	       CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	    }
	    
	    public void setProduct(){
	    	product_local="xbook";
	    	product = "xbook";
	    	CustomFunctions.setProduct(product_local);
	    	GetPage.setProduct(product_local);
	    }

}
