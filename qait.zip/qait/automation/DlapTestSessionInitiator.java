package com.qait.automation;

import static com.qait.automation.utils.DataReadWrite.getProperty;
import static com.qait.automation.utils.YamlReader.setYamlFilePath;



import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.dlapapi.keywords.DLAPAPI_Authentication;
import com.qait.dlapapi.keywords.DLAPAPI_Response;

public class DlapTestSessionInitiator extends TestSessionInitiator {
	
	public DLAPAPI_Authentication apiLogin ;
	public DLAPAPI_Response  apiResponse;
	public CustomFunctions customFunctions;
	public String loginurl, sandboxurl;
	private String product_local;
	
	private void _initPage() {
		apiLogin = new DLAPAPI_Authentication(driver);
		apiResponse = new DLAPAPI_Response(driver);
		customFunctions = new CustomFunctions(driver);
	}
	
	public DlapTestSessionInitiator() {
		 super();
		 setProduct();
		 setYamlFilePath(product_local);
		 configureBrowser();
		 _initPage();
		 customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects() ,product_local);
		 CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	public void setProduct(){
		product_local="dlapapi";
   	product = "dlapapi";
   	CustomFunctions.setProduct(product_local);
  	GetPage.setProduct(product_local);
   }

	public String[] setDLAPServer()
	{
		if(System.getProperty("domainName")!=null)
			 {
			loginurl = "http://"+System.getProperty("domainName")+"/login.aspx";
			 sandboxurl="http://"+System.getProperty("domainName")+"/callmethod.aspx";
			 }
		else {
			loginurl = "http://"+getProperty("./Config.properties", "domainName").trim()+"/login.aspx";
			 sandboxurl="http://"+getProperty("./Config.properties", "domainName").trim()+"/callmethod.aspx";
		}
		return new String[]{loginurl,sandboxurl};
	}
}
