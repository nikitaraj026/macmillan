/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import org.testng.Reporter;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.techtool.keywords.Admin_ManageRolesPermissionActions;
import com.qait.techtool.keywords.CourseHomePageActions;
import com.qait.techtool.keywords.DashboardPageActions;
import com.qait.techtool.keywords.HeaderActions;
import com.qait.techtool.keywords.ActivateCourseModalActions;
import com.qait.techtool.keywords.AdminPageAction;
import com.qait.techtool.keywords.Admin_CreateNewUserActions;
import com.qait.techtool.keywords.HeaderPageActions;
import com.qait.techtool.keywords.HomePageActions;
import com.qait.techtool.keywords.PXCourseLookUp_SuperUserActions;
import com.qait.techtool.keywords.PX_AutomatedPXNotificationAction;
import com.qait.techtool.keywords.PX_EnrollStudentInCourseAction;
import com.qait.techtool.keywords.PX_ExtendPXCourseRoasterRAExpirationDateActions;
import com.qait.techtool.keywords.PX_FindAccessCodeActions;
import com.qait.techtool.keywords.PX_Find_Existing_User_Actions;
import com.qait.techtool.keywords.PX_LaunchPadActions;
import com.qait.techtool.keywords.PX_LearningCurveActions;
import com.qait.techtool.keywords.PX_ManageUserAccessActions;
import com.qait.techtool.keywords.ManageRolesPermissionActions;
import com.qait.techtool.keywords.PX_XbookActions;
import com.qait.techtool.keywords.PX_n_RA_PageActions;
import com.qait.techtool.keywords.UserDetailsAction;
import com.qait.techtool.keywords.LoginPageActions;
import com.qait.techtool.keywords.LoginPageActions_px;
import com.qait.techtool.keywords.Manage_Custom_LaunchPad_And_PriceActions;
import com.qait.techtool.keywords.FileReadAndWrite;
import com.qait.techtool.keywords.LoginPageAction_obg;
import com.qait.techtool.keywords.EulaPageActions;
import com.qait.techtool.keywords.RegisterPageActions;
import com.qait.techtool.keywords.EnrollPageActions;
import com.qait.techtool.keywords.PurchasePageActions;
import com.qait.techtool.keywords.FindTitleActions;

public class TechtoolTestSessionInitiator extends TestSessionInitiator{
    
    /**
     * Initiating the page objects
     */
    public CustomFunctions customFunctions;
    public LoginPageActions loginPage ;
    public HomePageActions homepage;
    public PX_n_RA_PageActions px_n_ra_page;
    public HeaderPageActions headerpage;
    public PX_Find_Existing_User_Actions PX_Find_Existing_User_Page;
    public PX_ExtendPXCourseRoasterRAExpirationDateActions ExtentCourseRoaster;
    public PXCourseLookUp_SuperUserActions PXCourseLookUp;
    public AdminPageAction AdminPage;
    public Admin_ManageRolesPermissionActions ManageRolesPermission;
    public PX_EnrollStudentInCourseAction PX_EnrollStudentInCourse;
    public UserDetailsAction UserDetails;
    public PX_AutomatedPXNotificationAction PX_AutomatedPXNotification;
    public PX_ManageUserAccessActions PX_ManageUserAccess;
    public Admin_CreateNewUserActions Admin_CreateNewUserPage;
    public PX_FindAccessCodeActions PX_FindAccessCodePage;
    public PX_XbookActions PX_XbookPage;
    public PX_LaunchPadActions PX_LaunchPadPage;
    public PX_LearningCurveActions PX_LearningCurve;
    private String product_local;
    public Manage_Custom_LaunchPad_And_PriceActions customPricePage;
    public ActivateCourseModalActions activatecoursemodalLP;
    public DashboardPageActions dashboardPageLP;
    public HeaderActions headerLP; 
    public LoginPageActions_px loginPageLP;
    public CourseHomePageActions courseHomePageLP;
    public ManageRolesPermissionActions ManageRolesPermissionActions;
    public FileReadAndWrite FileReadAndWrite;
    public LoginPageAction_obg LoginPageAction_obg;
    public EulaPageActions eulaPage;
    public RegisterPageActions registerPage;
    public PurchasePageActions purchasePage;
    public FindTitleActions FindTitle;
    public EnrollPageActions enrollPage;

    private void _initPage() {
        loginPage = new LoginPageActions(driver);
        homepage = new HomePageActions(driver);
        px_n_ra_page = new PX_n_RA_PageActions(driver);
        headerpage = new HeaderPageActions(driver);
        PX_Find_Existing_User_Page = new PX_Find_Existing_User_Actions(driver);
        ExtentCourseRoaster = new PX_ExtendPXCourseRoasterRAExpirationDateActions(driver);
        PXCourseLookUp = new PXCourseLookUp_SuperUserActions(driver);
        AdminPage = new AdminPageAction(driver);
        ManageRolesPermission = new Admin_ManageRolesPermissionActions(driver);
        PX_EnrollStudentInCourse = new PX_EnrollStudentInCourseAction(driver);
        UserDetails = new UserDetailsAction(driver);
        PX_ManageUserAccess = new PX_ManageUserAccessActions(driver);
        PX_AutomatedPXNotification = new PX_AutomatedPXNotificationAction(driver);
        Admin_CreateNewUserPage = new Admin_CreateNewUserActions(driver);
        customFunctions = new CustomFunctions(driver);
        PX_FindAccessCodePage = new PX_FindAccessCodeActions(driver);
        PX_XbookPage = new PX_XbookActions(driver);
        PX_LaunchPadPage = new PX_LaunchPadActions(driver);
        PX_LearningCurve = new PX_LearningCurveActions(driver);
        customPricePage = new Manage_Custom_LaunchPad_And_PriceActions(driver);
        activatecoursemodalLP = new ActivateCourseModalActions(driver);
        dashboardPageLP = new DashboardPageActions(driver);
        headerLP= new HeaderActions (driver);
        loginPageLP = new LoginPageActions_px (driver);
        courseHomePageLP = new CourseHomePageActions (driver);
        ManageRolesPermissionActions = new ManageRolesPermissionActions(driver);
        FileReadAndWrite = new FileReadAndWrite();
        LoginPageAction_obg = new LoginPageAction_obg(driver);
        eulaPage = new EulaPageActions(driver);
        registerPage = new RegisterPageActions(driver);
        purchasePage = new PurchasePageActions(driver);
        FindTitle = new FindTitleActions(driver);
        enrollPage=new EnrollPageActions(driver);
    }
    
    /**
     * Page object Initiation done
     */
	public TechtoolTestSessionInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"),
				getDebugObjects(), product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	public void setProduct(){
		product_local="techtool";
    	product = "techtool";
    	CustomFunctions.setProduct(product_local);
    	GetPage.setProduct(product_local);
    }
	
	public void launchApplication(String applicationpath, String username,
			String Password) {
		if (getEnv().equalsIgnoreCase("DEV") || getEnv().equalsIgnoreCase("QA")) {
			launchApplicationWithNtlmAuth(applicationpath, username, Password);
		} else  {
			launchApplication(applicationpath);
		}
	}
    
    /**
     * 
     * @param appPath
     * @param username
     * @param Password
     */
	public void launchApplicationWithNtlmAuth(String appPath, String username,
			String Password) {
		Reporter.log("The test browser is :- " + getBrowser(), true);
		Reporter.log("Using the Username :- " + username + " and Password :- "
				+ Password, true);
		String launchPath = null;
		if (appPath.startsWith("http://") && (getBrowser().equalsIgnoreCase("firefox")
				|| getBrowser().equalsIgnoreCase("chrome"))) {
			launchPath = appPath.replace("http://","http://" + username + ":" + Password + "@")
					.replaceFirst("@", "%40").replace("\\", "%5C");
			appPath = launchPath;
		}

		Reporter.log("The application url is :- " + appPath, true);
		driver.get(appPath);
		
		// For IE browser i.e., to handle HTTP Basic Authorization in windows
		// Window.exe is a auto it script that is not added in the code you have to add in script manually
		if (getBrowser().equalsIgnoreCase("ie") && !getEnv().equalsIgnoreCase("prod")){
			 String autoITPath;
				if(System.getProperty("os.arch").equalsIgnoreCase("x86")){
					autoITPath = "src/test/resources/Techtool-testdata/window32.exe";
				}else autoITPath  = "src/test/resources/Techtool-testdata/window64.exe";
			Runtime runtime = Runtime.getRuntime();
			try {
			    runtime.exec("cmd /c start "+autoITPath);
			    Thread.sleep(4000);
			  } catch (Exception e) {
			     Reporter.log("Unable to handle authentication window");
			     e.printStackTrace();
			    }
		}
	}


}
