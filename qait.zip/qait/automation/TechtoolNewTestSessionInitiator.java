/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import org.testng.Reporter;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.techtoolnew.keywords.HeaderActions;
import com.qait.techtoolnew.keywords.HomePageActions;
import com.qait.techtoolnew.keywords.LoginPageActions;
import com.qait.techtoolnew.keywords.PX_And_RA_PageActions;


public class TechtoolNewTestSessionInitiator extends TestSessionInitiator{
    
    /**
     * Initiating the page objects
     */
    public CustomFunctions customFunctions;
    public LoginPageActions loginPage; 
    public HeaderActions header;
    public HomePageActions homePage;
    public PX_And_RA_PageActions pxraPage;
    private String product_local;
    
    private void _initPage() {
        loginPage = new LoginPageActions(driver);
        header = new HeaderActions(driver);
        homePage = new HomePageActions(driver);
        pxraPage = new PX_And_RA_PageActions(driver);
        
        customFunctions = new CustomFunctions(driver);
    }
    
    /**
     * Page object Initiation done
     */
	public TechtoolNewTestSessionInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"),
				getDebugObjects(), product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}
	
	public void setProduct(){
		product_local="techtoolnew";
    	product = "techtoolnew";
    	CustomFunctions.setProduct(product_local);
    	GetPage.setProduct(product_local);
    }
	
	public void launchApplication(String applicationpath, String username,
			String Password) {
		if (getEnv().equalsIgnoreCase("DEV") || getEnv().equalsIgnoreCase("QA")) {
			launchApplicationWithNtlmAuth(applicationpath, username, Password);
		} else  {
			launchApplication(applicationpath);
		}
	}
    
    /**
     * 
     * @param appPath
     * @param username
     * @param Password
     */
	public void launchApplicationWithNtlmAuth(String appPath, String username,
			String Password) {
		Reporter.log("The test browser is :- " + getBrowser(), true);
		Reporter.log("Using the Username :- " + username + " and Password :- "
				+ Password, true);
		String launchPath = null;
		if (appPath.startsWith("http://") && (getBrowser().equalsIgnoreCase("firefox")
				|| getBrowser().equalsIgnoreCase("chrome"))) {
			launchPath = appPath.replace("http://","http://" + username + ":" + Password + "@")
					.replaceFirst("@", "%40").replace("\\", "%5C");
			appPath = launchPath;
		}

		Reporter.log("The application url is :- " + appPath, true);
		driver.get(appPath);
		
		// For IE browser i.e., to handle HTTP Basic Authorization in windows
		// Window.exe is a auto it script that is not added in the code you have to add in script manually
		if (getBrowser().equalsIgnoreCase("ie") && !getEnv().equalsIgnoreCase("prod")){
			 String autoITPath;
				if(System.getProperty("os.arch").equalsIgnoreCase("x86")){
					autoITPath = "src/test/resources/Techtool-testdata/window32.exe";
				}else autoITPath  = "src/test/resources/Techtool-testdata/window64.exe";
			Runtime runtime = Runtime.getRuntime();
			try {
			    runtime.exec("cmd /c start "+autoITPath);
			    Thread.sleep(4000);
			  } catch (Exception e) {
			     Reporter.log("Unable to handle authentication window");
			     e.printStackTrace();
			    }
		}
	}
}
