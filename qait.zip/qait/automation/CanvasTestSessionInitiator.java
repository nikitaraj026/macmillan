package com.qait.automation;

import static com.qait.automation.utils.YamlReader.setYamlFilePath;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.CustomAssert;
import com.qait.automation.utils.CustomFunctions;
import com.qait.blackboard.keywords.CourseHomePageActionsLaunchpad;
import com.qait.blackboard.keywords.DashboardPageActionsLaunchpad;
import com.qait.canvas.keywords.AccountPageAction;
import com.qait.canvas.keywords.AchieveAdminActions;
import com.qait.canvas.keywords.AchieveInstructorActions;
import com.qait.canvas.keywords.AchieveStudentActions;
import com.qait.canvas.keywords.AchieveStudentActions;
import com.qait.canvas.keywords.AddMacmillanToolsAction;
import com.qait.canvas.keywords.AssignmentPageActions;
import com.qait.canvas.keywords.ContentRefreshAction;
import com.qait.canvas.keywords.ContentTocPageActions;
import com.qait.canvas.keywords.LeftMenuActions;
import com.qait.canvas.keywords.CoursePageAction;
import com.qait.canvas.keywords.DashBoardPageAction;
import com.qait.canvas.keywords.DiscussPageAction;
import com.qait.canvas.keywords.EnrollUsersAndCreateLoginAction;
import com.qait.canvas.keywords.FandEPageActions;
import com.qait.canvas.keywords.GradeRefreshAction;
import com.qait.canvas.keywords.LoginPageAction;
import com.qait.canvas.keywords.LoginPageActionsLaunchpad;
import com.qait.canvas.keywords.Macmillan2PageAction;
import com.qait.canvas.keywords.MarsEulaRegistrationPageActions;
import com.qait.canvas.keywords.MiddleWareLoginPageActions;
import com.qait.canvas.keywords.MiddlewarePageActions;
import com.qait.canvas.keywords.ModulePageAction;
import com.qait.canvas.keywords.OnboardingPageActions;
import com.qait.canvas.keywords.PXPageActions;
import com.qait.canvas.keywords.ProvisioningPageActions;
import com.qait.canvas.keywords.RequestFormActions;
import com.qait.canvas.keywords.SaplingAdminAction;
import com.qait.canvas.keywords.SaplingStudentActions;
import com.qait.canvas.keywords.StudentAccessGrantPageActions;
import com.qait.canvas.keywords.ToolsPageAction;
import com.qait.canvas.keywords.UserSettingsActions;
import com.qait.canvas.keywords.ProfilePageActions;

public class CanvasTestSessionInitiator extends TestSessionInitiator {

	public CustomFunctions customFunctions;
	public LoginPageAction loginPage;
	public LeftMenuActions leftMenu;
	public Macmillan2PageAction macmillan2Page;
	public DashBoardPageAction dashboardPage;
	public CoursePageAction coursePage;
	public ModulePageAction modulePage;
	public ProvisioningPageActions provisionPage;
	public ContentTocPageActions contentTocPage;
	public DiscussPageAction discussionPage;
	public PXPageActions pxPage;
	public FandEPageActions fnePage;
	public LoginPageActionsLaunchpad loginPageLaunchpad;
	public DashboardPageActionsLaunchpad dashBoardPageLaunchpad;
	public OnboardingPageActions onboardingPage;
	public AchieveStudentActions achieveStudentPage;
	public SaplingStudentActions saplingStudentPage;
	public AchieveInstructorActions achieveInstructorPage;
	public AchieveAdminActions achieveAdminPage;
	public MarsEulaRegistrationPageActions raPage;
	public ToolsPageAction toolsPage;
	public ContentRefreshAction contentRefresh;
	public GradeRefreshAction gradeRefresh;
	public StudentAccessGrantPageActions studentAccessGrantPage;
	public MiddlewarePageActions MiddlewarePage;
	public ProfilePageActions profilePage;
	public MiddleWareLoginPageActions MiddlewareLoginPage;
	public AssignmentPageActions assignmentPage;
	public AccountPageAction accountPage;
	public UserSettingsActions userSettings;
	public EnrollUsersAndCreateLoginAction enrollUsers;
	public AddMacmillanToolsAction addMacTools;
	public RequestFormActions requestpage;
	public SaplingAdminAction sapAdmin;
	private String product_local;

	private void _initPage() {
		loginPage = new LoginPageAction(driver);
		dashboardPage = new DashBoardPageAction(driver);
		leftMenu = new LeftMenuActions(driver);
		macmillan2Page = new Macmillan2PageAction(driver);
		coursePage = new CoursePageAction(driver);
		modulePage = new ModulePageAction(driver);
		provisionPage = new ProvisioningPageActions(driver);
		contentTocPage = new ContentTocPageActions(driver);
		discussionPage = new DiscussPageAction(driver);
		pxPage = new PXPageActions(driver);
		fnePage = new FandEPageActions(driver);
		loginPageLaunchpad = new LoginPageActionsLaunchpad(driver);
		dashBoardPageLaunchpad = new DashboardPageActionsLaunchpad(driver);
		onboardingPage = new OnboardingPageActions(driver);
		raPage = new MarsEulaRegistrationPageActions(driver);
		toolsPage = new ToolsPageAction(driver);
		customFunctions = new CustomFunctions(driver);
		contentRefresh = new ContentRefreshAction(driver);
		gradeRefresh = new GradeRefreshAction(driver);
		studentAccessGrantPage = new StudentAccessGrantPageActions(driver);
		MiddlewarePage = new MiddlewarePageActions(driver);
		profilePage = new ProfilePageActions(driver);
		MiddlewareLoginPage = new MiddleWareLoginPageActions(driver);
		assignmentPage = new AssignmentPageActions(driver, originalDriver);
		accountPage = new AccountPageAction(driver);
		userSettings = new UserSettingsActions(driver);
		enrollUsers = new EnrollUsersAndCreateLoginAction(driver);
		addMacTools = new AddMacmillanToolsAction(driver);
		sapAdmin = new SaplingAdminAction(driver);
		achieveStudentPage = new AchieveStudentActions(driver);
		achieveInstructorPage = new AchieveInstructorActions(driver);
		saplingStudentPage = new SaplingStudentActions(driver);
		achieveAdminPage = new AchieveAdminActions(driver);
		requestpage = new RequestFormActions(driver);
	}

	public CanvasTestSessionInitiator() {
		super();
		setProduct();
		setYamlFilePath(product_local);
		configureBrowser();
		_initPage();
		customFunctions.debugPageObjects(System.getProperty("user.dir"), getDebugObjects(), product_local);
		CustomAssert.setUploadScreenshotFlag(getUploadScreenshotToFtp());
	}

	public void setProduct() {
		product_local = System.getProperty("product");
		product = System.getProperty("product");

		if (product == null) {
			product = ConfigPropertyReader.getProperty("product");
		}

		if (product_local == null) {
			product_local = ConfigPropertyReader.getProperty("product");
		}
		CustomFunctions.setProduct(product_local);
		GetPage.setProduct(product_local);
	}

	public String getCurrentDateWithTime() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("dd_MM_yyyy");
		String strDate = formatter.format(date);
		SimpleDateFormat formatter1 = new SimpleDateFormat("HHmmss");
		String time = formatter1.format(date);
		return strDate + "_" + time;
	}
}
