package com.qait.blackboard.keywords;

import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.gdata.data.dublincore.Date;
import com.qait.automation.getpageobjects.GetPage;

public class AchieveInstructorActions extends GetPage {

	public AchieveInstructorActions(WebDriver driver) {
		super(driver, "AchieveInstructorAction");
	}

	public void create_AssesmentForAchieve() {

		waitForElementToBeVisible("link_menuItem", "COURSE PLANNER");
		isElementDisplayed("link_menuItem", "COURSE PLANNER");
		waitAndClick("link_menuItem", "COURSE PLANNER");
		List<WebElement> listforcb = elements("inpt_checkboxes");
		hardWait(5);
		System.out.println("Size of list is--------------->" + listforcb.size());
		if (listforcb.size() > 0) {
			for (int i = 0; i < listforcb.size(); i++) {
				listforcb.get(i).click();
				hardWait(3);
			}
			waitForElementToBeVisible("btn_Remove");
			isElementDisplayed("btn_Remove");
			waitAndClick("btn_Remove");
			hardWait(4);
			isElementDisplayed("btn_yesRemove");
			waitAndClick("btn_yesRemove");
			hardWait(6);
		}
		waitForElementToBeVisible("btn_showLibrary");
		isElementDisplayed("btn_showLibrary");
		waitAndClick("btn_showLibrary");
		List<WebElement> list = elements("inpt_checkboxes");
		hardWait(5);
		for (int i = 0; i < list.size(); i++) {
			list.get(i).click();
			hardWait(3);
		}
		waitAndScrollToElement("btn_AddSelectedItem");
		isElementDisplayed("btn_AddSelectedItem");
		waitAndClick("btn_AddSelectedItem");
		waitForElementToBeVisible("txt_coursePlanner");
		isElementDisplayed("txt_coursePlanner");
		waitAndClick("txt_coursePlanner");
		waitForElementToBeVisible("btn_AddNewUnit");
		isElementDisplayed("btn_AddNewUnit");
		waitAndClick("btn_AddNewUnit");
		hardWait(5);
		waitForElementToBeVisible("btn_hideLibrary");
		isElementDisplayed("btn_hideLibrary");
		waitAndClick("btn_hideLibrary");
		hardWait(5);
		List<WebElement> listSettings = elements("btn_actionMenu");
		hardWait(5);
		for (int j = 0; j < listSettings.size(); j++) {
			executeJavascript("document.getElementsByClassName('_2ns5').item(0).click()");
			hardWait(3);
			waitForElementToBeVisible("inpt_Points");
			isElementDisplayed("inpt_Points");
			fillText("inpt_Points", "30");
			selecting_CourseEndDate();
			hardWait(6);
			clickSaveBtn();
			hardWait(12);
		}
		changeWindow(0);
	}

	public void clickMyCourseTab() {
		waitForElementToBeVisible("link_menuItem", "My Course");
		isElementDisplayed("link_menuItem", "My Course");
		waitAndClick("link_menuItem", "My Course");
	}

	public void removeAllPreviousAssignments() {
		List<WebElement> listfortabs = elements("btn_MyCourseTab", "COURSE PLAN");
		if (listfortabs.size() > 0) {
			listfortabs.get(0).click();
			hardWait(2);
		}
		List<WebElement> listforcb = elements("inpt_checkboxes");
		hardWait(5);
		System.out.println("Size of list is--------------->" + listforcb.size());
		if (listforcb.size() > 0) {
			for (int i = 0; i < listforcb.size(); i++) {
				listforcb.get(i).click();
				hardWait(3);
			}
			waitForElementToBeVisible("btn_Remove");
			isElementDisplayed("btn_Remove");
			waitAndClick("btn_Remove");
			hardWait(4);
			isElementDisplayed("btn_yesRemove");
			waitAndClick("btn_yesRemove");
			hardWait(6);
		}
	}

	public void addAssignmentToCoursePlan() {
		waitForElementToBeVisible("link_menuItem", "Browse");
		isElementDisplayed("link_menuItem", "Browse");
		waitAndClick("link_menuItem", "Browse");
		List<WebElement> list = elements("inpt_checkboxes");
		hardWait(5);
		for (int i = 0; i < list.size(); i++) {
			if (list.get(i).isSelected()) {
				continue;
			} else {
				list.get(i).click();
				hardWait(3);
			}
		}

		waitForElementToBeVisible("btn_AddToCourse");
		isElementDisplayed("btn_AddToCourse");
		waitAndClick("btn_AddToCourse");
		waitForElementToBeVisible("btn_ShowInCoursePlan");
		isElementDisplayed("btn_ShowInCoursePlan");
		waitAndClick("btn_ShowInCoursePlan");
	}

	public void assignAssigments() {
		waitForElementToBeVisible("btn_MyCourseTab", "COURSE PLAN");
		isElementDisplayed("btn_MyCourseTab", "COURSE PLAN");
		waitAndClick("btn_MyCourseTab", "COURSE PLAN");
		hardWait(5);
		List<WebElement> listSettings = elements("btn_actionMenu");
		hardWait(5);
		for (int j = 0; j < listSettings.size(); j++) {
			executeJavascript("document.getElementsByClassName('_2ns5').item(0).click()");
			hardWait(3);
			waitForElementToBeVisible("inpt_Points");
			isElementDisplayed("inpt_Points");
			fillText("inpt_Points", "30");
			selecting_CourseEndDate();
			hardWait(6);
			clickSaveBtn();
			hardWait(12);
		}
	}

	public void createAssessmentFromNewCourseAchieve() {
		clickMyCourseTab();
		removeAllPreviousAssignments();
		addAssignmentToCoursePlan();
		clickMyCourseTab();
		assignAssigments();
		changeWindow(0);

	}

	public void clickSaveBtn() {
		waitForElementToBeVisible("btn_Save");
		waitAndClick("btn_Save");
		logMessage("Clicked on Save Button");
	}

	public void verify_User_Is_On_AchieveSide() {
		hardWait(5);
		waitForElementToBeVisible("img_AchieveLogo");
		isElementDisplayed("img_AchieveLogo");
	}

	public void selecting_CourseEndDate() {
		isElementDisplayed("due_CalenderDate");
		waitAndClick("due_CalenderDate");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("var first = {" + "  second: function myFunc7(){"
				+ "document.getElementsByClassName('_2eGJ wbLx').item(0).click();"
				+ "document.getElementsByClassName('_2XMC ').item(9).click();" + "}};" + "   first.second();");

	}

	public void verifyGradebookForAchieve() {
		waitForElementToBeVisible("link_menuItem", "GRADEBOOK");
		isElementDisplayed("link_menuItem", "GRADEBOOK");
		waitAndClick("link_menuItem", "GRADEBOOK");
		waitForElementToBeVisible("inpt_searchTab");
		isElementDisplayed("inpt_searchTab");
		waitForElementToBeVisible("link_assignmentName");
		isElementDisplayed("link_assignmentName");
		waitForElementToBeVisible("btn_percentage");
		isElementDisplayed("btn_percentage");
		waitForElementToBeVisible("btn_pts");
		isElementDisplayed("btn_pts");
		waitForElementToBeVisible("btn_syncExport");
		isElementDisplayed("btn_syncExport");
		waitForElementToBeVisible("btn_settings");
		isElementDisplayed("btn_settings");

	}

	public void updateGradeValueOfAssignment(String points) {
		waitForElementToBeVisible("link_menuItem", "COURSE PLANNER");
		isElementDisplayed("link_menuItem", "COURSE PLANNER");
		waitAndClick("link_menuItem", "COURSE PLANNER");
		hardWait(5);
		List<WebElement> listSettings = elements("btn_actionMenu");
		hardWait(5);
		for (int j = 0; j < listSettings.size(); j++) {
			executeJavascript("document.getElementsByClassName('_2ns5').item(0).click()");
			hardWait(3);
			waitForElementToBeVisible("inpt_Points");
			isElementDisplayed("inpt_Points");
			fillText("inpt_Points", points);
			selecting_CourseEndDate();
			hardWait(6);
			executeJavascript("document.getElementsByClassName('_1tkc undefined').item(0).click()");
			hardWait(12);
		}
	}
}