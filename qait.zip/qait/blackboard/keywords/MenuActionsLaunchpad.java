package com.qait.blackboard.keywords;

import org.openqa.selenium.WebDriver;
import com.qait.automation.getpageobjects.GetPage;

public class MenuActionsLaunchpad extends GetPage {

	FandEPageActionsLaunchpad fandePage;
	public MenuActionsLaunchpad(WebDriver driver) {
		super(driver, "MenuLaunchpad");
		fandePage = new FandEPageActionsLaunchpad(driver);
	}
	
	
	/************************* LEFT SIDE NAVIGATION MENU **********************/
	
	/***************************
	 * 1. LEFT SIDE NAVIGATION MENU : BASIC OPERATIONS
	 * a. Verifications
	 ***************************/
	
	/**
	 * Verifies that Menu resize Button is displayed
	 */
	public void verifyMenuResizeButtonDisplayed() {
		isElementDisplayed("btn_menuResize");
	}
	
	/**
	 * Verifies that Ebook Menu Button is displayed
	 */
	public void verifyEbookMenuButtonDisplayed() {
		isElementDisplayed("btn_ebook");
	}
	
	/**
	 * Verifies that Gradebook Menu Button is displayed
	 */
	public void verifyGradebookMenuButtonDisplayed() {
		isElementDisplayed("btn_gradebook");
	}
	
	/**
	 * Verifies that Calendar Menu Button is displayed
	 */
	public void verifyCalendarMenuButtonDisplayed() {
		isElementDisplayed("btn_calendar");
	}
	
	/**
	 * Verifies that Resources Menu Button is displayed
	 */
	public void verifyResourcesMenuButtonDisplayed() {
		isElementDisplayed("btn_resources");
	}
	
	/**
	 * Verifies that Welcome Center Menu Button is displayed
	 */
	public void verifyWelcomeCenterMenuButtonDisplayed() {
		isElementDisplayed("btn_welcomeCenter");
	}
	
	/**
	 * Verifies that Welcome Center Menu Button is not displayed
	 */
	public void verifyWelcomeCenterMenuButtonNotDisplayed() {
		verifyElementNotDisplayed("btn_welcomeCenter", "");
	}
	
	/**
	 * Verifies that Instructor Console Menu Button is displayed
	 */
	public void verifyInstructorConsoleMenuButtonDisplayed() {
		isElementDisplayed("btn_instructorConsole");
	}
	
	/**
	 * Verifies that Instructor Console Menu Button is not displayed
	 */
	public void verifyInstructorConsoleMenuButtonNotDisplayed() {
		verifyElementNotDisplayed("btn_instructorConsole", "");
	}
	
	/**
	 * Verifies that Preview as Student Menu Button is displayed
	 */
	public void verifyPreviewAsStudentMenuButtonDisplayed() {
		isElementDisplayed("btn_previewAsStudent");
	}
	
	/**
	 * Verifies that Preview as Student Menu Button is not displayed
	 */
	public void verifyPreviewAsStudentMenuButtonNotDisplayed() {
		verifyElementNotDisplayed("btn_previewAsStudent", "");
	}
	
	/***************************
	 * 1. LEFT SIDE NAVIGATION MENU : BASIC OPERATIONS
	 * b. Click
	 ***************************/
	
	/**
	 * Click Menu Resize Button
	 */
	public void clickMenuResizeButton() {
		waitScrollAndClick("btn_menuResize");
		logMessage("Clicked Menu Resize Button");
	}
	
	/**
	 * Click Home Menu Button
	 */
	public void clickHomeMenuButton() {
		waitScrollAndClick("btn_home");
		logMessage("Clicked Home Menu Button");
	}
	
	/**
	 * Click Ebook Menu Button
	 */
	public void clickEbookMenuButton() {
		waitScrollAndClick("btn_ebook");
		logMessage("Clicked Ebook Menu Button");
	}
	
	/**
	 * Click Gradebook Menu Button
	 */
	public void clickGradebookMenuButton() {
		waitScrollAndClick("btn_gradebook");
		logMessage("Clicked Gradebook Menu Button");
	}
	
	/**
	 * Click Calendar Menu Button
	 */
	public void clickCalendarMenuButton() {
		waitScrollAndClick("btn_calendar");
		logMessage("Clicked Calendar Menu Button");
	}
	
	/**
	 * Click Resources Menu Button
	 */
	public void clickResourcesMenuButton() {
		waitScrollAndClick("btn_resources");
		//element("btn_resources").click();
		logMessage("Clicked Resources Menu Button");
	}
	
	/**
	 * Click Welcome Center Menu Button
	 */
	public void clickWelcomeCenterMenuButton() {
		waitScrollAndClick("btn_welcomeCenter");
		logMessage("Clicked 'Welcome Center' Menu Button");
	}
	
	/**
	 * Click Instructor Console Menu Button
	 */
	public void clickInstructorConsoleMenuButton() {
		//scrollToTop();
		hardWait(2);
		//click(element("btn_instructorConsole"));
		waitScrollAndClick("btn_instructorConsole");
		logMessage("Clicked 'Instructor Console' Menu Button");
		waitForLoaderToDisappear();
	}
	
	/**
	 * Click Preview as Student Menu Button
	 */
	public void clickPreviewAsStudentMenuButton() {
		//waitScrollAndClick("btn_previewAsStudent");
		scrollToBottom();
		click(element("btn_previewAsStudent"));
		
		logMessage("Clicked 'Preview as Student' Menu Button");
		waitForLoaderToDisappear();
	}
	
	/*******************************************************
	 * 2. LEFT SIDE NAVIGATION MENU : COMPUNDED OPERATIONS
	 *******************************************************/
	
	/**
	 * Verify Left Side Navigation Menu is displayed
	 */
	public void verifyLeftNavigationMenuDisplayed() {
		verifyMenuResizeButtonDisplayed();
		verifyEbookMenuButtonDisplayed();
		verifyGradebookMenuButtonDisplayed();
		verifyCalendarMenuButtonDisplayed();
		verifyResourcesMenuButtonDisplayed();
		verifyWelcomeCenterMenuButtonDisplayed();
		verifyInstructorConsoleMenuButtonDisplayed();
		verifyPreviewAsStudentMenuButtonDisplayed();
	}
}

