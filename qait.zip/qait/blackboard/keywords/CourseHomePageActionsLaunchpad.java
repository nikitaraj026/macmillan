package com.qait.blackboard.keywords;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.google.common.collect.Ordering;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;
//import com.thoughtworks.selenium.webdriven.commands.GetAttribute;

import org.testng.Assert;

public class CourseHomePageActionsLaunchpad extends GetPage {

	FandEPageActionsLaunchpad fnePage;

	public CourseHomePageActionsLaunchpad(WebDriver driver) {
		super(driver, "CourseHomePageLaunchpad");
		fnePage = new FandEPageActionsLaunchpad(driver);
	}

	public void scrollToBookCover() {
		waitAndScrollToElement("img_bookCover");
	}

	public void pressEnterKey() {
		Actions ac = new Actions(driver);
		ac.sendKeys(Keys.ENTER);
		ac.build().perform();
	}

	/**
	 * Verifies that Marketing Banner Is Not Displayed
	 */
	public void verifyMarketngBannerIsNotDisplayed() {
		verifyElementNotDisplayed("container_topPanel", "LCE-914");
		verifyElementNotDisplayed("img_info_large", "LCE-914");
		verifyElementNotDisplayed("pnl_title_area", "LCE-914");
		verifyElementNotDisplayed("pnl_info_sub-title", "LCE-914");
		verifyElementNotDisplayed("pnl_authr", "LCE-914");
		verifyElementNotDisplayed("publisher_logo", "LCE-914");
	}

	/**************
	 * CONTENTS ************** 1. TOP SIDE(ABOVE TOC) 2. TOC 3. MODAL/WINDOW/WIDGET
	 * GENERAL 4. CREATE NEW ASSIGNMENT MODAL 5. CREATE NEW UNIT MODAL 6. MANAGE
	 * ASSIGNMENT WIDGET 7. STUDENT VIEW
	 **************************************/

	/********************** Toast Message *******************/

	/**
	 * Verify that Toast message is displayed and is correct
	 */
	public void verifyToastMessageAppears(String msgSubstring) {
		element("msg_notification").isDisplayed();
		waitForMsgToastToAppear(msgSubstring);
		waitForMsgToastToDisappear();
	}

	public void clickToastMessageCloseButton() {
		element("btn_closeToastMessage").click();
	}

	public void verifyMsgToastIsDisplayed() {
		waitForElementToBeVisible("msg_toast");
		isElementDisplayed("msg_toast");
	}

	public void verifyMsgToastIsNotDisplayed() {
		verifyElementNotDisplayed("msg_toast", "");
	}

	/********************** TOP SIDE(ABOVE TOC) *******************/

	/*******************************************
	 * 1. TOP SIDE(ABOVE TOC) : BASIC OPERATIONS a. Verifications
	 *******************************************/

	/**
	 * Verifies that Course Name at Top is correct
	 */
	public void verifyCourseName(String courseName) {
		verifyTextOfElementIsCorrect("txt_courseNameTitle", courseName);
		clickElementIfVisible("btn_closeToastMessage");
	}

	/**
	 * Verifies that School Name at Top in Partial Course Info is correct
	 */
	public void verifySchoolPartialCourseInfo(String schoolName) {
		String actualText = element("txt_schoolName").getText().trim();
		customAssert.customAssertTrue(actualText.contains(schoolName.split("-")[0].toUpperCase().trim()),
				"Assertion Failed : " + "School Name is not correct in Partial Course Info");
	}

	/**
	 * Verifies that Instructor Name at Top in Partial Course Info is correct
	 */
	public void verifyInstructorNamePartialCourseInfo(String instructorName) {
		verifyTextOfElementIsCorrect("txt_instructorName", instructorName);
	}

	/**
	 * Verifies that Course value at Top in Partial Course Info is correct
	 */
	public void verifyCoursePartialCourseInfo(String course) {
		verifyTextOfElementIsCorrect("txt_course", course);
	}

	/**
	 * Verifies that Section value at Top in Partial Course Info is correct
	 */
	public void verifySectionPartialCourseInfo(String section) {
		verifyTextOfElementIsCorrect("txt_section", section);
	}

	/**
	 * Verifies that Semester value at Top in Expanded Course Info is correct
	 */
	public void verifySemesterExpandedCourseInfo(String semester) {
		verifyTextOfElementIsCorrect("txt_semesterCourseInfo", semester);
	}

	/**
	 * Verifies that Course value at Top in Expanded Course Info is correct
	 */
	public void verifyCourseExpandedCourseInfo(String course) {
		verifyTextOfElementIsCorrect("txt_courseCourseInfo", course);
	}

	/**
	 * Verifies that Section value at Top in Expanded Course Info is correct
	 */
	public void verifySectionExpandedCourseInfo(String section) {
		verifyTextOfElementIsCorrect("txt_sectionCourseInfo", section);
	}

	/**
	 * Verifies that Instructor Name at Top in Expanded Course Info is correct
	 */
	public void verifyInstructorNameExpandedCourseInfo(String instructor) {
		verifyTextOfElementIsCorrect("txt_instructorNameCourseInfo", instructor);
	}

	/**
	 * Verifies that Email at Top in Expanded Course Info is correct
	 */
	public void verifyEmailExpandedCourseInfo(String email) {
		verifyTextOfElementIsCorrect("txt_emailCourseInfo", email);
	}

	/**
	 * Verifies that Phone at Top in Expanded Course Info is correct
	 */
	public void verifyPhoneExpandedCourseInfo(String phone) {
		verifyTextOfElementIsCorrect("txt_phoneCourseInfo", phone);
	}

	/**
	 * Verifies that Office Hours at Top in Expanded Course Info is correct
	 */
	public void verifyOfficeHoursExpandedCourseInfo(String officeHours) {
		verifyTextOfElementIsCorrect("txt_officeHoursCourseInfo", officeHours);
	}

	/**
	 * Verifies that View Syllabus at Top in Expanded Course Info is correct
	 */
	public void verifyViewSyllabusExpandedCourseInfo(String viewSyllabusUrl) {
		verifyAttributeOfElementIsCorrect("link_viewSyllabusCourseInfo", "href", viewSyllabusUrl);
	}

	/**
	 * Verifies that No Assignments Due message is displayed
	 */
	public void verifyNoAssignmentsDueMessageDisplayed() {
		isElementDisplayed("txt_noAssignmentDue");
	}

	/**
	 * Verifies that Assignments Due message is correct
	 */
	public void verifyAssignmentsDueMessageDisplayedIsCorrect(String num) {
		if (num.equals("1"))
			verifyTextOfElementIsCorrect("txt_assignmentDue", "You have 1 assignment due in the next 7 days.");
		else
			verifyTextOfElementIsCorrect("txt_assignmentDue",
					"You have " + num + " assignments due in the next 7 days.");
	}

	/**
	 * Verifies Ebook section is displayed on Course Page
	 */
	public void verifyEbookSectionDisplayed() {
		waitForLoaderToDisappear();
		isElementDisplayed("txt_viewingEbookHeading");
	}

	/**
	 * Verifies Activate link is displayed on Course Page
	 */
	public void verifyActivateLinkIsNotDisplayed() {

		customAssert.customAssertFalse(element("btn_activateThisCourse").isDisplayed(),
				"Assertion Failed: Activate link is appeared");
	}

	/*******************************************
	 * 1. TOP SIDE(ABOVE TOC) : BASIC OPERATIONS b. Fill Text Fields
	 *******************************************/

	/**
	 * Fill Search Course field
	 */
	public void fillSearchCourse(String searchCourse) {
		fillText("txtinput_searchCourse", searchCourse);
	}

	/*******************************************
	 * 1. TOP SIDE(ABOVE TOC) : BASIC OPERATIONS c. Click
	 *******************************************/

	/**
	 * Click Search Course Button
	 */
	public void clickSearchCourseButton() {
		waitScrollAndClick("btn_searchCourse");
		logMessage("Clicked Search Course Button");
	}

	/**
	 * Click Search Course Button for Video Tool Kit
	 */
	public void clickSearchButton() {
		waitScrollAndClick("btn_search");
		logMessage("Clicked Search Button");
	}

	/**
	 * Launch Video Tool Kit from Resources
	 */
	public void searchAndLaunchVideoToolKit() {
		hover(element("txtField_hover"));
		element("txt_field").click();
		element("txt_field").sendKeys("Video Tool Kit");
		element("icon_search").click();
		waitForElementToBeVisible("lnk_videoToolKit");
		element("lnk_videoToolKit").click();
		logMessage("Launched FnE window of Video Toolkit Activity");
		waitForLoaderToDisappear();
	}

	/**
	 * Click 'Add New' Link
	 */
	public void clickAddNewLink() {
		waitAndScrollToElement("link_addNew");
		waitForElementToBeVisible("link_addNew");
		// js.executeScript("document.getElementsByClassName('lnkTopCreateContent')[0].click();");
		hardWait(7);
		//element("link_addNew").click();
		waitAndClick("link_addNew");
		logMessage("Clicked 'Add New' Link");
	}

	/**
	 * Click Expand Course Info Link
	 */
	public void clickExpandCourseInfoLink() {
		waitScrollAndClick("link_courseInfoExpand");
		logMessage("Clicked Expand Course Info Link");
	}

	/**
	 * Click Collapse Course Info Link
	 */
	public void clickCollapseCourseInfoLink() {
		waitScrollAndClick("link_courseInfoCollapse");
		logMessage("Clicked Collapse Course Info Link");
	}

	/**
	 * Click Activate This Course Button
	 */
	public void clickActivateThisCourseButton() {
		waitScrollAndClick("btn_activateThisCourse");
		logMessage("Clicked Activate This Course Button");
	}

	/***********************************************
	 * 2. TOP SIDE(ABOVE TOC) : COMPUNDED OPERATIONS
	 ***********************************************/

	/**
	 * Clicks 'Add New' Button and selects specified Assignment from 'Create a New
	 * Assignment' Modal
	 * 
	 * @param assignMentType Name of Assignment Type as specified in 'Create a New
	 *                       Assignment' Modal
	 */
	public void createNewAssignment(String assignmentType) {
		clickAddNewLink();
		verifyModalWindowTitle("Add a new assignment");
		clickAssignmentType(assignmentType);
	}

	/**
	 * Create an Assignment of Type : Dropbox, HTML Page, Discussion Board,
	 */
	public void createAssignmentCategory1(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createNewAssignment(assignmentType);
		fnePage.verifyHeadingOfPage(assignmentType);
		fnePage.fillTitleOnBasicInfo(assignmentName);
		fnePage.clickOnSaveButtonOnBasicInfo();
		fnePage.clickSettingsTab();
		fnePage.enterNumberOfAttemptsOnSettingsTab("Unlimited");
		fnePage.clickSaveButtonOnSettingsTab();
		if (assign)
			fnePage.assignAssignment(assignmentScore, dueDate);
	}

	/**
	 * Create an Assignment of Type : Document Collection, Link Collection, Link
	 */
	public void createAssignmentCategory2(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createNewAssignment(assignmentType);
		waitForLoaderToDisappear();
		fnePage.verifyHeadingOfPage(assignmentType);
		fnePage.fillTitleOnBasicInfo2(assignmentName);
		if (assignmentType.equals("Link"))
			fnePage.fillUrlOnBasicInfo("http://www.macmillan.com");
		if (assignmentType.equals("Link Collection"))
			fnePage.attachLinkToLinkCollection("google", "http://www.google.com");
		fnePage.clickOnSaveButtonOnBasicInfo2();
		if (assign)
			fnePage.assignAssignment(assignmentScore, dueDate);
	}

	/**
	 * Create a Document Collection Assignment
	 */
	public void createDocumentCollectionAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createAssignmentCategory2(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		fnePage.clickDoneEditingAndHomeButton();
	}

	/**
	 * Create a Link Collection Assignment
	 */
	public void createLinkCollectionAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createAssignmentCategory2(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		fnePage.clickDoneEditingAndHomeButton();
	}

	/**
	 * Create a Link Assignment
	 */
	public void createLinkAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createAssignmentCategory2(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		fnePage.clickDoneEditingAndHomeButton();
	}

	/**
	 * Create a Dropbox Assignment
	 */
	public void createDropboxAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		fnePage.clickDoneEditingAndHomeButton();
	}

	/**
	 * Create an HTML Page Assignment
	 */
	public void createHTMLPageAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		fnePage.clickDoneEditingAndHomeButton();
	}

	/**
	 * Create a Discussion Board Assignment
	 */
	public void createDiscussionBoardAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		fnePage.clickOnDoneEditingButton();
		int height = fnePage.getDocumentCollectionFrameSize();
		customAssert.customAssertTrue(height > 550,
				"Assertion Failed : Height of Discussion Board section is small, that is " + height + " px");
		fnePage.clickOnHomeButton();
	}

	/**
	 * Create a Quiz Assignment
	 */
	public void createQuizAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate, boolean addQuestions, String chapterName, String questionBank) {
		createAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		if (addQuestions)
			fnePage.addQuestions(chapterName, questionBank);
		fnePage.clickDoneEditingAndHomeButton();
	}

	/**
	 * Create a Quiz Assignment without done editing
	 */
	public void createQuizAssignment_(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate, boolean addQuestions, String chapterName, String questionBank) {
		createAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		if (addQuestions)
			fnePage.addQuestions(chapterName, questionBank);
	}

	/******************************* TOC ******************************/

	/*******************************************
	 * 1. TOC : BASIC OPERATIONS a. Verifications
	 *******************************************/
	/**
	 * Verifies Assigned Assignment Due Date
	 * 
	 * @param assignmentName
	 * @param desiredDate
	 */
	public void verifyAssignedAssignmentDateInTOC(String assignmentName, String desiredDate) {
		String date = element("txt_dayDueDateItemTOC", assignmentName).getText().trim();
		// String date = element("txt_startDayDueDateItemTOC",
		// assignmentName).getText().trim()+"-"+element("txt_dayDueDateItemTOC",
		// assignmentName).getText().trim();
		customAssert.customAssertEquals(date, desiredDate, "Assertion failed: due date range is not correct");
		logMessage("'" + assignmentName + "' assigndate is correct : " + desiredDate);
	}

	/**
	 * Verifies that TOC Item is displayed
	 */
	public void verifyTOCItemDisplayed(String linkName) {
		isElementDisplayed("link_assignedItemTOC", linkName);
		hardWait(1);
	}

	/**
	 * Verifies that same assignment is clicked
	 */
	public void clickOnSameAssignment(String newTitle) {
		element("link_itemTOC", newTitle).click();

	}

	/**
	 * Verifies that TOC Item is not displayed
	 */
	public void verifyTOCItemNotDisplayed(String linkName) {
		hardWait(5);
		verifyElementNotDisplayed("link_itemTOC", linkName, "");
	}

	/**
	 * Verifies that TOC Item is displayed in Assigned Section
	 */
	public void verifyTOCItemInAssignedSection(String linkName) {
		isElementDisplayed("link_assignedItemTOC", linkName);
	}

	/**
	 * Verifies that Due Date (Month) of TOC Item is correct
	 */
	public void verifyTOCItemMonthDueDate(String linkName, String expectedMonth) {
		logMessage("linkName : " + linkName);
		logMessage("expected month : " + expectedMonth);
		verifyTextOfElementIsCorrect("txt_monthDueDateItemTOC", linkName, expectedMonth);
	}

	/**
	 * Verifies that Due Date (Day) of TOC Item is correct
	 */
	public void verifyTOCItemDayDueDate(String linkName, String expectedDay) {
		hardWait(2);
		verifyTextOfElementIsCorrect("txt_dayDueDateItemTOC", linkName, expectedDay);
	}

	/**
	 * Verifies that Points displayed for TOC Item is correct
	 */
	public void verifyTOCItemPoints(String linkName, String expectedPointsString) {
		verifyTextOfElementIsCorrect("txt_pointsItemTOC", linkName, expectedPointsString);
	}

	/**
	 * Verifies that 'You have not yet added any content to this unit.' message is
	 * displayed on Course Page
	 */
	public void verifyNotYetAddedAnyContentMessageDisplayed() {
		waitForElementToBeVisible("txt_notAddedAnyContentMessage");
		verifyTextOfElementIsCorrect("txt_notAddedAnyContentMessage", "There is currently no content or "
				+ "assignments in this course. Click the \"Add\" button below to add an assignment.");
	}

	public void verifyTOCItemAssignButtonNotDisplayed(String linkName) {
		scrollDown(element("link_itemTOC", linkName));
		hardWait(1);
		hover(element("link_itemTOC", linkName));
		hardWait(1);
		verifyElementNotDisplayed("link_assignItemTOC", linkName, "");
	}

	public void verifyTOCItemExpandedTitle(String expectedTitle) {
		isElementDisplayed("txt_titleItemTOCExpanded", expectedTitle);
	}

	public void verifyTOCItemExpandedDescription(String expectedDescription) {
		isElementDisplayed("txt_descriptionItemTOCExpanded", expectedDescription);
	}

	public void verifyTOCItemImage(String src) {
		isElementDisplayed("img_itemTOC", src);
		hardWait(2);
	}

	/*******************************************
	 * 1. TOC : BASIC OPERATIONS b. Click
	 *******************************************/

	/**
	 * Click TOC Item
	 */
	public void clickUnassignedTOCItem(String linkName) {
		waitForElementToBeVisible("link_itemTOC",linkName);
		isElementDisplayed("link_itemTOC", linkName);
		// click(element("link_itemTOC",linkName));
		waitScrollAndClick("link_itemTOC", linkName);
		logMessage("Clicked TOC Item '" + linkName + "'");
		waitForLoaderToDisappear();
	}

	/*
	 * Click assigned TOC item
	 */
	public void verify_freeTrialMessageIsDisplayed() {
		assertTrue(element("txt_freeTrial").isDisplayed(),
				"The free Trial text is not displayed on" + " Launchpad homepage");
		System.out.println("Free Trial message has been Verified");
		assertTrue(element("purchase_Access").isDisplayed(),
				"the purchase acess test is not displayed on launchpad homepage");
		System.out.println("purchase message is passed");

		assertTrue(element("enter_Access_code").isDisplayed(),
				"the enter access code is not displayed on launchpad homepage");
		System.out.println("enter access message is passed");
	}

	public void verify_freeTrialMessageIsNotDisplayed() {
		List<WebElement> freetrialMsg = elements("txt_freeTrial");
		assertEquals(freetrialMsg.size(), 0, "Free Trial Message is still displayed");
		System.out.println("Free Trial Message not displayed");
	}

	public void clickAssignedTOCItem(String linkName) {
		scrollToTop();
		hardWait(3);
		waitScrollAndClick("link_assignedItemTOC", linkName);
		// waitScrollAndClick("link_itemTOC", linkName);
		logMessage("Clicked TOC Item '" + linkName + "'");
		waitForLoaderToDisappear();
	}

	/**
	 * Click TOC Item
	 */
	public void clickTOCItemWithoutScrolling(String linkName) {

		element("link_itemTOC", linkName).click();

		logMessage("Clicked TOC Item '" + linkName + "'");
		waitForLoaderToDisappear();
	}

	/**
	 * Verify Status of TOC Item
	 */
	public void verifyTocItemStatus(String linkName, String statusText) {
		verifyTextOfElementIsCorrect("lnk_TOC_Item_Status", linkName, statusText);
	}

	/**
	 * Verify Status of TOC Item
	 */
	public void verifyTocStatus(String linkName, String parent, String statusText) {
		customAssert.customAssertTrue(element("lnk_TOC_Status", linkName, parent).getText().contains(statusText),
				"Status Of TOC is Not Correct");
//		logMessage("Status of TOC is correct");
	}

	/**
	 * Click TOC Item 'Assign' Button
	 */
	public void clickTOCItemAssignButton(String linkName) {
		waitAndScrollToElement("link_itemTOC", linkName);
		hardWait(4);
		@SuppressWarnings("unused")
		int i = -1;
		for (WebElement el : elements("list_contentTOC")) {
			if (el.getText().contains(linkName)) {
				i++;
				break;
			}
		}
//		executeJavascript("$('span:contains(\""+linkName+"\")').trigger('mouseenter');");
		// hover(element("link_itemTOC", linkName));
		// hardWait(2);
		isElementDisplayed("link_assignItemTOC", linkName);
//		click(element("link_assignItemTOC", linkName));
		clickUsingJavaScript("link_assignItemTOC", linkName);

		// hardWait(3);
		// executeJavascript("document.getElementsByClassName('faceplate-item-assign')["+i+"].click()");
		logMessage("Clicked Assign Button for TOC Item '" + linkName + "'");
	}

	public void clickTOCItemAssignButtonForAssigned(String linkName) {
		waitAndScrollToElement("link_assignedItemTOC", linkName);
		hardWait(4);
		@SuppressWarnings("unused")
		int i = -1;
		for (WebElement el : elements("list_contentTOC")) {
			if (el.getText().contains(linkName)) {
				i++;
				break;
			}
		}
//		executeJavascript("$('span:contains(\""+linkName+"\")').trigger('mouseenter');");
		hover(element("link_assignedItemTOC", linkName));
		hardWait(2);
		isElementDisplayed("link_assignItemTOC", linkName);
		click(element("link_assignItemTOC", linkName));
		// waitAndClick("link_assignItemTOC", linkName);

		hardWait(3);
		// executeJavascript("document.getElementsByClassName('faceplate-item-assign')["+i+"].click()");
		logMessage("Clicked Assign Button for TOC Item '" + linkName + "'");
	}

	public void doubleClickAssignButton(String linkName) {
		hover(element("link_assignedItemTOC", linkName));
		hardWait(2);
		Actions action = new Actions(driver);
		action.doubleClick(element("link_assignItemTOC", linkName)).build().perform();
		;
//		element("link_assignItemTOC", linkName).click();
//		hover(element("link_itemTOC", linkName));
//		element("link_assignItemTOC", linkName).click();
		logMessage("Double clicked on Assign");
	}

	public void verifyOnlyOneManagementCardOpens() {
		customAssert.customAssertEquals(elements("txt_titleWidget").size(), 1,
				"Assertion failed : Two management card opens on double clicking the assign button");
		logMessage("Assertion passed : Only one management card opens on double clicking the assign button");
		verifyWidgetTitle("Manage Assignment");
	}

	/**
	 * Click TOC Item 'More Options' Button
	 */
	public void clickTOCItemMoreOptionsButton(String linkName) {
		waitForElementToBeVisible("link_itemTOC", linkName);
		scrollDown(element("link_itemTOC", linkName));
		hover(element("link_itemTOC", linkName));
		// hardWait(1);
		// wait.waitForElementToBeVisible(element("link_moreOptionsItemTOC", linkName));
		element("link_moreOptionsItemTOC", linkName).click();
		logMessage("Clicked 'More Options' Button for TOC Item '" + linkName + "'");
	}

	public void clickTOCItemMoreOptionsButtonForAssignedItems(String linkName) {
		waitForElementToBeVisible("link_assignedItemTOC", linkName);
		// waitAndScrollToElement("link_assignedItemTOC", linkName);
		hover(element("link_assignedItemTOC", linkName));
		// hardWait(1);
		// wait.waitForElementToBeVisible(element("link_moreOptionsItemTOC", linkName));
		waitAndClick("link_moreOptionsItemTOC", linkName);
		logMessage("Clicked 'More Options' Button for TOC Item '" + linkName + "'");
	}

	/**
	 * Click option 'Edit Title & Directions' from TOC Item 'More Options' Menu
	 */
	public void clickTOCItemMoreOptionsEditTitleDescriptionButton(String linkName) {
		element("link_editTitleDescriptionItemTOC", linkName).click();
		logMessage(
				"Clicked 'Edit Title & Description' option from 'More Options' menu for TOC Item '" + linkName + "'");
	}

	/**
	 * Click option 'Move or Copy' from TOC Item 'More Options' Menu
	 */
	public void clickTOCItemMoreOptionsMoveOrCopyButton(String linkName) {
		element("link_moveOrCopyItemTOC", linkName).click();
		logMessage("Clicked 'Move or Copy' option from 'More Options' menu for TOC Item '" + linkName + "'");
	}

	/**
	 * Click option 'Remove' from TOC Item 'More Options' Menu
	 */
	public void clickTOCItemMoreOptionsRemoveButton(String linkName) {
		element("link_removeItemTOC", linkName).click();
		logMessage("Clicked 'Remove' option from 'More Options' menu for TOC Item '" + linkName + "'");
	}

	/**
	 * Verify TOC Item is Hidden
	 */
	public void verifyTOCItemHidden(String linkName) {
		isElementDisplayed("lnk_hiddenTOCItem", linkName);
		logMessage("TOC Item '" + linkName + "' is hidden for Students");
	}

	public void verifyTOCItemHidden1(String linkName) {
		isElementDisplayed("lnk_hiddenTOCItem1", linkName);
		logMessage("TOC Item '" + linkName + "' is hidden for Students");
	}

	public void verifyDueDateNotDisplayed(String linkName) {
		refreshPage();
		CustomAssert.assertFalse(isElementDisplayed("txt_dayDueDateItemTOC", linkName), "Due Date is visible");
	}

	/**
	 * Click option 'Close Menu' from TOC Item 'More Options' Menu
	 */
	public void clickTOCItemMoreOptionsCloseMenuButton(String linkName) {
		element("link_closeMenuItemTOC", linkName).click();
		logMessage("Clicked 'Close Menu' option from 'More Options' menu for TOC Item '" + linkName + "'");
	}

	/**
	 * Click 'Browse Resources for this Unit' for TOC Item
	 */
	public void clickTOCItemBrowseResourcesForThisItemButton(String linkName) {
		waitScrollAndClick("btn_browseResourcesForThisUnitItemTOC", linkName);
		logMessage("Clicked 'Browse Resources for this Unit' Button for TOC Item '" + linkName + "'");
		hardWait(3);
	}

	/**
	 * Click TOC Item 'Manage' Button to open Management Card
	 */
	public void clickTOCItemManageButton(String linkName) {
		waitScrollAndClick("btn_manageItemTOC", linkName);
		logMessage("Clicked 'Manage' button for assigned TOC Item '" + linkName + "'");
	}

	/**
	 * Click TOC Item 'Add to this Unit' Button
	 */
	public void clickTOCItemAddToThisUnitButton(String unitName) {
		waitScrollAndClick("btn_addToThisUnitItemTOC", unitName);
		logMessage("Clicked 'Add to this Unit' button for TOC Unit '" + unitName + "'");
	}

	/**
	 * Click TOC Item 'Create New...' under 'Add to this Unit' Button
	 */
	public void clickAddToThisUnitCreateNewLink() {
		waitAndClick("link_createNewAddToThisUnit");
		logMessage("Clicked 'Create New...' under 'Add to this Unit' Button");
	}

	/*******************************************
	 * 2. TOC : COMPOUNDED OPERATIONS
	 *******************************************/

	/**
	 * Assigns the specified TOC Item to next month's specified date
	 */
	public void assignTOCItem(String linkName, String nextMonthDate, boolean fillGradePoints, String gradePoints) {
		clickTOCItemAssignButton(linkName);
		// verifyWidgetDisplayed();
		// verifyWidgetTitle("Manage Assignment");
		waitForElementToBeVisible("assignWindow");
		clickNextMonthButtonFromDatePicker();
		clickDateFromDatePicker(nextMonthDate);
		if (fillGradePoints)
			fillGradePointsManageAssignmentWidget(gradePoints);
		clickManageAssignmentAssignButtonNew();
	}

	public void assignTOCItemForAssignedChapters(String linkName, String nextMonthDate, boolean fillGradePoints,
			String gradePoints) {
		clickTOCItemAssignButtonForAssigned(linkName);
		// verifyWidgetDisplayed();
		// verifyWidgetTitle("Manage Assignment");
		waitForElementToBeVisible("assignWindow");
		clickNextMonthButtonFromDatePicker();
		clickDateFromDatePicker(nextMonthDate);
		if (fillGradePoints)
			fillGradePointsManageAssignmentWidget(gradePoints);
		clickManageAssignmentAssignButton();
	}

	public void assignTOCItemWithoutDueDate(String linkName) {
		clickTOCItemAssignButton(linkName);
		waitAndClick("btn_assignManageAssignment");
		waitForMsgToastToAppear();
		isElementDisplayed("msg_notification");
		customAssert.customAssertEquals(element("msg_notification").getText(),
				"To assign this item, you must select a due date.",
				"Assertion failed : No error message appered on assigning content without due date");
		waitForMsgToastToDisappear();
	}

	/**
	 * Assigns the specified TOC Item to previous month's specified date
	 */
	public void assignTOCItem1(String linkName, String previousMonthDate, boolean fillGradePoints, String gradePoints) {
		clickTOCItemAssignButton(linkName);
		// verifyWidgetDisplayed();
		// verifyWidgetTitle("Manage Assignment");

		clickPreviousMonthButtonFromDatePicker();
		clickDateFromDatePicker(previousMonthDate);
		if (fillGradePoints)
			fillGradePointsManageAssignmentWidget(gradePoints);
		clickManageAssignmentAssignButton();
		handleAlert();
		hardWait(4);
		waitForLoaderToDisappear();
	}

	/**
	 * Opens 'Manage Assignment' widget and performs specified operations
	 */
	public void manageTOCItem(String linkName, String nextMonthDate, boolean fillGradePoints, String gradePoints) {
		scrollDown(element("txt_courseNameTitle"));
		clickTOCItemManageButton(linkName);
		// verifyWidgetDisplayed();
		// verifyWidgetTitle("Manage Assignment");
		clickNextMonthButtonFromDatePicker();
		clickDateFromDatePicker(nextMonthDate);
		if (fillGradePoints)
			fillGradePointsManageAssignmentWidget(gradePoints);
		clickManageAssignmentAssignButton();
	}

	/**
	 * Attempts a Document Collection Assignment
	 */
	public void attemptDocumentCollectionAssignment(String linkName, String assignmentScore) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		fnePage.clickOnHomeButton();
	}

	/**
	 * Attempts a Dropbox Assignment
	 */
	public void attemptDropboxAssignment(String linkName, String assignmentScore, String fileName) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.submitFileForDropboxAssignment(fileName);
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		fnePage.clickOnHomeButton();
	}

	/**
	 * Attempts a Link Assignment
	 */
	public void attemptLinkAssignment(String linkName, String assignmentScore) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		fnePage.clickOnHomeButton();
	}

	/**
	 * Attempts an HTML Page Assignment
	 */
	public void attemptHTMLPageAssignment(String linkName, String assignmentScore) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		fnePage.clickOnHomeButton();
	}

	/**
	 * Attempts a Link Collection Assignment
	 */
	public void attemptLinkCollectionAssignment(String linkName, String assignmentScore) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		fnePage.clickOnHomeButton();
	}

	/**
	 * Attempts a Quiz Assignment with single question
	 */
	public void attemptQuizAssignment(String linkName, String assignmentScore) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.attemptQuizAndClickSubmit();
		// fnePage.switchToCourseContentFrame();
		if (!fnePage.isCorrectlyAnswered()) {
			String correctAnswer = fnePage.getCorrectAnswerOfQuestion();
			fnePage.clickDoneButton();
			fnePage.attemptQuizCorrectly(correctAnswer);
		}
		fnePage.clickDoneButton();
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		switchToDefaultContent();
		fnePage.clickOnHomeButton();
	}

	public void attemptQuizAssignmentWithoutClose(String linkName, String assignmentScore) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.attemptQuizAndClickSubmit();
		// fnePage.switchToCourseContentFrame();
		if (!fnePage.isCorrectlyAnswered()) {
			String correctAnswer = fnePage.getCorrectAnswerOfQuestion();
			switchToDefaultContent();
			fnePage.clickOnDoneEditingButton();
			fnePage.attemptQuizCorrectly(correctAnswer);
		}
		fnePage.clickOnDoneEditingButton();
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		switchToDefaultContent();
		fnePage.clickOnHomeButton();
	}

	public void attemptOneOutOfThreeQuestionsCorrect(String linkName) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.attemptQuizAndClickSubmit();
		// fnePage.switchToCourseContentFrame();
		if (!fnePage.isCorrectlyAnswered()) {
			String correctAnswer = fnePage.getCorrectAnswerOfQuestion();
			fnePage.clickDoneButton();
			fnePage.attemptQuizCorrectly(correctAnswer);
		}
		fnePage.clickDoneButton();
		switchToDefaultContent();
	}

	/**
	 * Attempts a Discussion Board Assignment
	 */
	public void attemptDiscussionBoardAssignment(String linkName, String assignmentScore) {
		clickAssignedTOCItem(linkName);
		fnePage.verifyHeadingOfPage(linkName);
		fnePage.postNewThreadOnDiscussionBoard("New Thread", false);
		fnePage.verifyScoringIsDisplayed(assignmentScore);
		fnePage.clickOnHomeButton();
	}

	/********************** MODAL/WINDOW/WIDGET GENERAL *******************/

	/***************************************************
	 * 1. MODAL/WINDOW/WIDGET GENERAL : BASIC OPERATIONS a. Verifications
	 ***************************************************/

	/**
	 * Verifies that Widget is displayed
	 */
	public void verifyWidgetDisplayed() {
		isElementDisplayed("widget");
	}

	/**
	 * Verifies that title of Modal/Window is correct
	 */
	public void verifyModalWindowTitle(String expectedTitle) {
		waitForElementToBeVisible("txt_titleModal", expectedTitle);
		isElementDisplayed("txt_titleModal", expectedTitle);
	}

	/**
	 * Verifies that title of Widget is correct
	 */
	public void verifyWidgetTitle(String expectedTitle) {
		waitForElementToBeVisible("txt_titleWidget");
		verifyTextOfElementIsCorrect("txt_titleWidget", expectedTitle);
	}

	/***************************************************
	 * 1. MODAL/WINDOW/WIDGET GENERAL : BASIC OPERATIONS a. Click
	 ***************************************************/

	/**
	 * Click Close Button of Modal/Window
	 */
	public void clickModalWindowCloseButton() {
		element("btn_closeModal").click();
		logMessage("Clicked Close Button of Modal/Window");
	}

	/**
	 * Click Close Button of Widget
	 */
	public void clickWidgetCloseButton() {
		element("btn_closeWidget").click();
		logMessage("Clicked Close Button of Widget");
	}

	/********************** CREATE NEW ASSIGNMENT MODAL *******************/

	/***************************************************
	 * 1. CREATE NEW ASSIGNMENT MODAL : BASIC OPERATIONS a. Verifications
	 ***************************************************/

	/**
	 * Verifies that specified Assignment Type Link is displayed in 'Create a New
	 * Assignment' Modal
	 */
	public void verifyCreateNewAssignmentModalAssignmentTypeLinkDisplayed(String assignmentType) {
		isElementDisplayed("link_assignmentType", assignmentType);
	}

	/**
	 * Verifies that Assignment Type Title is correct on 'Create a New Assignment'
	 * Modal
	 */
	public void verifyAssignmentTypeTitleCreateNewAssignmentModal(String expectedAssignmentType) {
		verifyTextOfElementIsCorrect("txt_assignmentTypeTitle", expectedAssignmentType);
	}

	/***************************************************
	 * 1. CREATE NEW ASSIGNMENT MODAL : BASIC OPERATIONS a. Click
	 ***************************************************/

	/**
	 * Click specified Assignment Type from 'Create a New Assignment' Modal
	 */
	public void clickAssignmentType(String assignmentType) {
		waitAndClick("link_assignmentType", assignmentType);
	}

	/***************************************************
	 * 1. CREATE NEW ASSIGNMENT MODAL : COMPOUNDED OPERATIONS
	 ***************************************************/

	/**
	 * Verifies that Assignment Types specified in List are displayed on 'Create a
	 * New Assignment' Modal
	 * 
	 * @param assignmentTypes List of String with various Assignment Types
	 */
	public void verifyCreateNewAssignmentModalAssignmentTypeLinksDisplayed(List<String> assignmentTypes) {
		for (String assignment : assignmentTypes) {
			verifyCreateNewAssignmentModalAssignmentTypeLinkDisplayed(assignment);
		}
	}

	/********************** CREATE NEW UNIT MODAL *******************/

	/***************************************************
	 * 1. CREATE NEW UNIT MODAL : BASIC OPERATIONS a. Fill Text Fields
	 ***************************************************/

	/**
	 * Fill Title in 'Create New Unit' Modal
	 */
	public void fillTitleCreateNewUnitModal(String title) {
		element("txtinput_titleCreateNewUnit").clear();
		element("txtinput_titleCreateNewUnit").sendKeys(title);
		waitForElementToBeVisible("txtBoxDescription");
	}

	/***************************************************
	 * 1. CREATE NEW UNIT MODAL : BASIC OPERATIONS b. Click
	 ***************************************************/

	/**
	 * Click Save Button on 'Create New Unit' Modal
	 */
	public void clickCreateNewUnitModalSaveButton() {
		element("btn_saveCreateNewUnit").click();
	}

	/**
	 * Click Cancel Button on 'Create New Unit' Modal
	 */
	public void clickCreateNewUnitModalCancelButton() {
		element("btn_cancelCreateNewUnit").click();
	}

	/********************** MANAGE ASSIGNMENT WIDGET *******************/

	/***************************************************
	 * 1. MANAGE ASSIGNMENT WIDGET : BASIC OPERATIONS a. Verifications
	 ***************************************************/

	/**
	 * Verifies that Assignment Title is correct on 'Manage Assignment' Widget
	 */
	public void verifyAssignmentTitleManageAssignmentWidget(String expectedTitle) {
		verifyTextOfElementIsCorrect("txt_assignmentTitleManageAssignment", expectedTitle);
	}

	public void verifyManageAssignmentTimeSelectorList() {
		element("txtinput_timeManageAssignment").click();
		isElementDisplayed("timeselector");
	}

	/***************************************************
	 * 1. MANAGE ASSIGNMENT WIDGET : BASIC OPERATIONS b. Fill Text Fields
	 ***************************************************/

	/**
	 * Fill Date field in 'Manage Assignment' Widget
	 */
	public void fillDateManageAssignmentWidget(String date) {
		waitAndScrollToElement("txtinput_dateManageAssignment");
		fillText("txtinput_dateManageAssignment", date);
	}

	/**
	 * Fill Time field in 'Manage Assignment' Widget
	 */
	public void fillTimeManageAssignmentWidget(String time) {
		fillText("txtinput_timeManageAssignment", time);
	}

	/**
	 * Fill Grade Points field in 'Manage Assignment' Widget
	 */
	public void fillGradePointsManageAssignmentWidget(String points) {
		fillText("txtinput_gradePointsManageAssignment", points);
	}

	/***************************************************
	 * 1. MANAGE ASSIGNMENT WIDGET : BASIC OPERATIONS c. Click
	 ***************************************************/

	/**
	 * Click Previous Month Button from Date Picker in 'Manage Assignment' Widget
	 */
	public void clickPreviousMonthButtonFromDatePicker() {
		scrollDown(element("datePicker_goPrev"));
		element("datePicker_goPrev").click();
	}

	/**
	 * Click Next Month Button from Date Picker in 'Manage Assignment' Widget
	 */
	public void clickNextMonthButtonFromDatePicker() {
		hardWait(2);
		// waitAndClick("datePicker_goNext");
		click(element("datePicker_goNext"));
	}

	/**
	 * Click specified Date from Date Picker in 'Manage Assignment' Widget
	 */
	public void clickDateFromDatePicker(String date) {
		element("datePicker_date", date).click();
	}

	/**
	 * Click 'Clear' Date field Button in 'Manage Assignment' Widget
	 */
	public void clickClearDateFieldManageAssignment() {
		element("btn_clearDateFieldManageAssignment").click();
	}

	/**
	 * Click 'Assign' Button in 'Manage Assignment' Widget
	 */
	public void clickManageAssignmentAssignButton() {
		waitScrollAndClick("btn_assignManageAssignment");
		hardWait(1);
		System.out.println("Handling First Alert...");
		handleAlert();
		hardWait(1);
		handleAlert();
		waitForLoaderToDisappear();
		/*
		 * waitForElementToDisappear("btn_assignManageAssignment"); if
		 * (elements("btn_assignManageAssignment").size() == 1){ //executeJavascript(
		 * "document.getElementsByClassName('assign-showCalendar-close')[0].click();");
		 * hardWait(1); handleAlert();
		 * waitForElementToDisappear("btn_assignManageAssignment"); }
		 */
	}

	/**
	 * Copy created assignment to a sub chapter
	 */
	public void copyCreatedAssignment(String assignment, String subChapter) {
		clickTOCItemMoreOptionsButton(assignment);
		clickOnMoveOrCopyOnMoreOption(assignment);
		waitForLoaderToAppearAndDisappear();
		isElementDisplayed("link_itemTOC2", subChapter);
		waitScrollAndClick("link_itemTOC2", subChapter);
		clickOnCopyButtonInConfirmationDialog();
		verifyTOCItemDisplayed(assignment + " copy");
	}

	/**
	 * Click 'Cancel' Button in 'Manage Assignment' Widget
	 */
	public void clickManageAssignmentCancelButton() {
		scroll(element("btn_cancelManageAssignment"));
		executeJavascript(
				"document.getElementsByClassName('managementcard-close px-button medium secondary')[0].click()");
//		waitAndClick("btn_cancelManageAssignment");
		hardWait(1);
	}

	/**
	 * Click 'Visible to Students' Checkbox in 'Manage Assignment' Widget
	 */
	public void clickManageAssignmentVisibleToStudentsCheckBox() {
		element("chkbox_visibleToStudentsManageAssignment").click();
	}

	/**
	 * Click 'Edit' link 'Manage Assignment' Widget
	 */
	public void clickManageAssignmentEditLink() {
		element("link_editManageAssignment").click();
	}

	/**
	 * Click 'Remove' link 'Manage Assignment' Widget
	 */
	public void clickManageAssignmentRemoveLink() {
		element("link_removeManageAssignment").click();
	}

	/**
	 * Clicks on Unassign link on management card
	 */
	public void clickOnManageUnassignLink() {
		waitAndClick("link_unassignManageAssignment");
	}

	/**
	 * Clicks on Unassign button on confirmation dialog
	 */
	public void clickOnUnassignButtonOnManageConfirmationDialog() {
		element("btn_unassignOnCofirmDialog").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Clicks on the move or copy link on management card
	 */
	public void clickOnMoveOrCopyOnMoreOption(String assignmentName) {
		waitScrollAndClick("link_moveOrCopyItemTOC", assignmentName);
	}

	/**
	 * Click on move button in pop up
	 */
	public void clickOnMoveButtonOnConfirmationDialog(String chapterName) {
//		waitScrollAndClick("txt_copyormoveContent", chapterName);
		scrollDown(element("txt_copyormoveContent", chapterName));
		element("txt_copyormoveContent", chapterName).click();
//		waitForLoaderToDisappear();
//		scrollDown(element("btn_moveOnMoveOrCopyDialog"));
		element("btn_moveOnMoveOrCopyDialog").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Clicks on Copy button on copy assignment wizard
	 */
	public void clickOnCopyButtonInConfirmationDialog() {
		element("btn_copyOnMoveOrCopyDialog").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		element("btn_saveOnCopyItemDialog").click();
	}

	/***************************************************
	 * 1. MANAGE ASSIGNMENT WIDGET : BASIC OPERATIONS d. Dropdown Option Select
	 ***************************************************/

	/**
	 * Select Option from Category Dropdown in Manage Assignment Widget
	 */
	public void selectManageAssignmentCategory(String option) {
		hardWait(3);
		selectProvidedTextFromDropDown(element("dropdown_cateoryManageAssignment"), option);
	}

	/**
	 * Select time mode on from time selector on manage card
	 * 
	 * @param timeMode Value of time Mode should be AM or PM
	 */
	public void selectManageAssignmentTimeMode(String timeMode) {
		waitAndClick("btn_timeMode", timeMode);
	}

	/**
	 * Select hours from time selector on manage card
	 * 
	 * @param hour
	 */
	public void selectHoursOnManageAssignmentCard(String hour) {
		element("list_selectHour", hour).click();
	}

	/**
	 * Select minutes from time selector on Manage Card
	 * 
	 * @param minutes Minutes should be multiple of 5
	 */
	public void selectMinutesOnManageAssignment(String minutes) {
		element("list_selectMinutes", minutes).click();
	}

	/********************** CREATE NEW CATEGORY WIDGET *******************/

	/***************************************************
	 * 1. CREATE NEW CATEGORY WIDGET : BASIC OPERATIONS a. Fill Text Fields
	 ***************************************************/

	/**
	 * Fill Category Name in 'Create New Category' Widget
	 */
	public void fillCategoryNameCreateNewCategoryWidget(String categoryName) {
		fillText("txtinput_categoryName", categoryName);
	}

	/***************************************************
	 * 1. CREATE NEW CATEGORY WIDGET : BASIC OPERATIONS b. Click
	 ***************************************************/

	/**
	 * Click 'Add' button on 'Create New Category' Widget
	 */
	public void clickCreateNewCategoryAddButton() {
		element("btn_addCreateNewCategory").click();
		hardWait(3);
	}

	/********************** REMOVE ACTIVITY WIDGET *******************/

	/***************************************************
	 * 1. REMOVE ACTIVITY WIDGET : BASIC OPERATIONS a. Click
	 ***************************************************/

	/**
	 * Click 'Remove' link 'Remove Activity' Widget
	 */
	public void clickRemoveActivityRemoveButton() {
		waitAndClick("btn_removeRemoveActivity");
	}

	/********************** STUDENT VIEW *******************/

	/***************************************************
	 * 1. STUDENT VIEW : BASIC OPERATIONS a. Verifications
	 ***************************************************/

	/**
	 * Verify Student View Widget is displayed
	 */
	public void verifyStudentViewWidgetDisplayed() {
		isElementDisplayed("div_studentViewWidget");
	}

	/**
	 * Verifies that 'You are currently viewing the site in Student Mode' message is
	 * displayed at top of student view
	 */
	public void verifyStudentViewMessage() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("div_studentViewWidget");
		waitForElementToBeVisible("txt_currentlyViewingInStudentMode");
		verifyTextOfElementIsCorrect("txt_currentlyViewingInStudentMode",
				"You are currently viewing the site in Student Mode.");
	}

	/***************************************************
	 * 1. STUDENT VIEW : BASIC OPERATIONS b. Click
	 ***************************************************/

	/**
	 * Click 'Return to Faculty View' Button
	 */
	public void clickReturnToFacultyViewButton() {
		scrollDown(element("btn_returnToFacultyView"));
		element("btn_returnToFacultyView").click();
		logMessage("Clicked 'Return to Faculty View' Button");
	}

	/********************** EDIT TITLE AND DIRECTIONS WIDGET *******************/

	/***************************************************
	 * 1. EDIT TITLE AND DIRECTIONS WIDGET : BASIC OPERATIONS a. Verifications
	 ***************************************************/

	/**
	 * Verifies Title in 'Edit Title and Directions' Widget is correct
	 */
	public void verifyTitleEditTitleDirectionsWidget(String expectedTitle) {
		String actualTitle = element("txtinput_titleEditTitleDirections").getAttribute("value");
		customAssert.customAssertEquals(actualTitle, expectedTitle,
				"Assertion Failed : Title on 'Edit Title and Directions' " + "Widget is incorrect");
	}

	/**
	 * Verify correct image is displayed on 'Edit Title and Directions' Widget
	 */
	public void verifyImageEditTitleDirectionsWidget(String imageUrl) {
		isElementDisplayed("img_imageEditTitleDirections");
		String propertyValue = element("img_imageEditTitleDirections").getAttribute("src");
		customAssert.customAssertEquals(imageUrl, propertyValue,
				"Assertion Failed : Image Url is incorrect on " + "'Edit Title and Directions' widget");
	}

	/***************************************************
	 * 1. EDIT TITLE AND DIRECTIONS WIDGET : BASIC OPERATIONS b. Click
	 ***************************************************/

	/**
	 * Click 'Click to Edit' link on 'Edit Title and Directions' Widget
	 */
	public void clickEditTitleDirectionsWidgetClickToEditLink() {
		element("link_clickToEditImage").click();
	}

	/**
	 * Click 'Save' button on 'Edit Title and Directions' Widget
	 */
	public void clickEditTitleDirectionsWidgetSaveButton() {
		element("btn_saveEditTitleDirections").click();
	}

	/***************************************************
	 * 1. EDIT TITLE AND DIRECTIONS WIDGET : BASIC OPERATIONS c. Fill Text Fields
	 ***************************************************/

	/**
	 * Fill Title in 'Edit Title and Directions' Widget
	 */
	public void fillTitleEditTitleDirectionsWidget(String title) {
		fillText("txtinput_titleEditTitleDirections", title);
	}

	/**
	 * Fill Directions in 'Edit Title and Directions' Widget
	 */
	public void fillDirectionsEditTitleDirectionsWidget(String directions) {
		hardWait(5);
		((JavascriptExecutor) driver).executeScript(
				"document.getElementsByClassName('mceIframeContainer mceFirst mceLast')[0].getElementsByTagName('iframe')[0].contentDocument.getElementById('tinymce').getElementsByTagName('p')[0].innerHTML='"
						+ directions + "'");
	}

	/***************************************************
	 * 2. EDIT TITLE AND DIRECTIONS WIDGET : COMPOUNDED OPERATIONS
	 ***************************************************/

	public void uploadImageEditTitleDirectionsWidget(String imageUrl) {
		switchToDefaultContent();
		switchToFrame(element("iframe_imageUpload"));
		fillText("txtinput_imageUrlIframeImageUpload", imageUrl);
		hardWait(1);
//		element("txt_preview").click();
//		isElementDisplayed("img_previewImageIframeImageUpload");
		element("btn_insertIframeImageUpload").click();
		switchToDefaultContent();
	}

	/*************************** OLD FUNCTIONS ***********************************/

	/**
	 * CLICK METHODS
	 * 
	 */

	public void clickRemoveLinkOnGearBoxModal() {
		element("link_removeInGearbox").click();
	}

	public void clickGearBoxForSubContentOfChapter(String stringInSubcontentSection) {
		hover(element("link_sectionInSubContent", stringInSubcontentSection));
		hardWait(1);
		element("btn_chapterGearBox", stringInSubcontentSection).click();
	}

	public void clickRemoveOnRemoveActivityDialog() {
		waitForElementToBeVisible("btn_removeOnRemoveActivityDialog");
		element("btn_removeOnRemoveActivityDialog").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void clickSaveOnNameThisCopyDialog() {
		element("btn_saveOnNameThisCopyDialog").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Clicks Done button on Assignment wizard
	 */
	public void clickOnDoneButtonOnAssignmentWizard() {
		waitForElementToBeVisible("btn_assignDone");
		element("btn_assignDone").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Clicks cancel to switch back to instructor view
	 */
	public void clickCancelToCloseStudentView() {
		waitForElementToBeVisible("btn_cancelStudentView");
		element("btn_cancelStudentView").click();
	}

	/*
	 * VERIFICATION METHODS
	 */
	/**
	 * Verifies that Course Home page is displayed by checking Title of page is as
	 * specified as argument
	 * 
	 * @param courseHomePageTitle
	 */
	public void verifyUserIsOnCourseHomePage(String courseHomePageTitle) {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("txt_courseHomePageTitle");
		System.out.println(element("txt_courseHomePageTitle").getText());
		customAssert.customAssertEquals(element("txt_courseHomePageTitle").getText(), courseHomePageTitle,
				"Assertion Failed: Course Home Page title is not correct.");
		logMessage("Assertion Passed: User is on Course HomePage, Verified Page title visibility and Title text to be: "
				+ courseHomePageTitle);
	}

	public void verifyChangedEbookInfo(String ebookTitleEdited) {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("link_firstContentItem");
		hardWait(2);
		customAssert.customAssertTrue(element("link_firstContentItem").getText().equalsIgnoreCase(ebookTitleEdited),
				"Assertion Failed : " + "First Content Item link text is incorrect");

		logMessage("Changes in ebook info reflects on course home page");
	}

	public void verifySubcontentIsDisplayed(String name) {
		customAssert.customAssertTrue(element("btn_assignedAssignment", name).isDisplayed(),
				"Assertion Failed : Subcontent '" + name + "' is not displayed on course home page");
		logMessage("Assertion Passed : Subcontent '" + name + "' is displayed on course home page");
	}

	public void verifySubcontentIsNotDisplayed(String name) {
		if (elements("btn_assignedAssignment", name).size() != 0) {
			customAssert.customAssertTrue(false,
					"Assertion Failed : Subcontent '" + name + "' is getting displayed on course home page");
		}
	}

	public void verifyScoringIsDisplayedForAssignment(String assignmentName, String maxScore, String expectedScore) {
		waitForElementToBeVisible("txt_pointsItemTOC", assignmentName);
		String actualScoring = element("txt_pointsItemTOC", assignmentName).getText();
		String expectedScoring = expectedScore + " / " + maxScore + " pts";
		customAssert.customAssertEquals(actualScoring, expectedScoring,
				"Assertion Failed : Assignment '" + assignmentName
						+ "' scoring is incorrectly displayed on Course Home Page. " + "Actual='" + actualScoring
						+ "', Expected='" + expectedScoring + "'");
		logMessage("Assertion Passed : Assignment '" + assignmentName
				+ "' scoring is correctly displayed on Course Home Page.");
	}

	public void verifyResourcesByChapterShortcutLinkIsDisplayed() {
		customAssert.customAssertTrue(isElementDisplayed("link_linkClass", "Resources by chapter"),
				"Assertion Failed : Shortcut Link 'Resources by chapter' is not displayed on Course Hpme page");
	}

	public void verifyTitleOfUIDialog(String title) {
		String actualTitle = element("txt_uiDialogTitle").getText();
		customAssert.customAssertEquals(actualTitle, title, "Assertion Failed : Title of UI Dialog Box is incorrect");
		logMessage("Assertion Passed : Title of UI Dialog Box is incorrect '" + actualTitle + "'");
	}

	/**
	 * Verify instructor is on Student view
	 */
	public void verifyInstructorIsOnStudentView() {
		element("btn_cancelStudentView").isDisplayed();
		customAssert.customAssertTrue(
				element("txt_viewingStudentSite").getText()
						.contains("You are currently " + "viewing the site as a Student"),
				"Instructor is not switched to student view");
	}

	/**
	 * Verifies that Due Date for an Item is displayed
	 * 
	 * @param itemName Item name displayed on Course Home Page
	 */
	public void verifyDueDateIsDisplayedForContentItem(String itemName) {
		customAssert.customAssertTrue(isElementDisplayed("icon_dueDateContentItem", itemName),
				"Assertion Failed : " + "Due date is not displayed for Assigned item '" + itemName + "'");
		logMessage("Assertion Passed : Due date is displayed for Assigned item '" + itemName + "'");
	}

	/*
	 * OTHER METHODS
	 */

	public void expandChapterAndItsContent(String chapter) {
		element("link_chapterPath", chapter).click();
		waitForLoaderToDisappear();
		logMessage(chapter + " expanded");
	}

	public void expandAndSelecteBookChapter() {
		element("lnk_expandFirst").click();
		waitForLoaderToDisappear();
		element("lnk_eBook").click();
		waitForLoaderToDisappear();
		logMessage("expanded and ebook chapter selected");
	}

	public void expandSubContentOfChapter(String subcontentName) {
		waitForElementToBeVisible("link_chapterSubContent", subcontentName);
		element("link_chapterSubContent", subcontentName).click();
		waitForLoaderToDisappear();
		logMessage(subcontentName + " is expanded");
	}

	public void selectActionFromAccountActionList(String accountAction) {
		waitForLoaderToDisappear();
		// verifyUserIsOnCourseHomePage();
		element("drpdown_arrowIcon").click();
		element("drpdown_optionSelect", accountAction).click();
	}

	public List<String> getListOfAllAssignmentTypes() {
		List<String> types = new ArrayList<String>();
		waitForElementToBeVisible("txt_createNewAssignmentModalHeader");
		List<WebElement> elems = elements("link_allNewAssignmentTypes");
		for (int i = 0; i < elems.size(); i++) {
			String text = elems.get(i).getText();
			types.add(text);
		}
		return types;
	}

	// /**
	// * Creates Assignments of various Types as specified in arguments(except
	// 'Homework', 'Unit' and 'Learning Curve')
	// * @param assignmentTypes List of Type of Assignments for which Assignment is
	// to be created
	// * @param assignmentNamePrefix String to be prefixed when saving Assignment
	// name
	// * @param assign boolean true if need to assign the item
	// * @param assignmentScore Score to be assigned to the Assignment
	// */
	// public void createAssignmentsByInstructor(List<String> assignmentTypes,
	// String assignmentNamePrefix,
	// boolean assign, String assignmentScore, String chapterNumber, String
	// selectQuestionFrom) {
	// for (int i = 0; i < assignmentTypes.size(); i++){
	// String assignmentType = assignmentTypes.get(i);
	// if (assignmentType.equals("Homework") || assignmentType.equals("Unit") ||
	// assignmentType.equals("Learning Curve") || assignmentType.equals(""))
	// continue;
	// else{
	// // Fill Basic Info Tab
	// createNewAssignment(assignmentType);
	// String newTitle = assignmentNamePrefix + assignmentType;
	// if (assignmentType.equals("Document Collection") ||
	// assignmentType.equals("Link") || assignmentType.equals("Link Collection"))
	// fandePage.fillTitleOnBasicInfo2(newTitle);
	// else
	// fandePage.fillTitleOnBasicInfo(newTitle);
	// if (assignmentType.equals("Link")){
	// fandePage.fillUrlOnBasicInfo("http://www.macmillan.com");
	// }
	// if (assignmentType.equals("Document Collection") ||
	// assignmentType.equals("Link") || assignmentType.equals("Link Collection"))
	// fandePage.clickOnSaveButtonOnBasicInfo2();
	// else
	// fandePage.clickOnSaveButtonOnBasicInfo();
	// // Fill Assign Tab
	// if (assign) {
	// fandePage.clickAssignmentTab();
	// fandePage.selectDateInDatePicker();
	// fandePage.fillGradePointsForAssignment(assignmentScore);
	// fandePage.clickAssignButtonFromAssignmentTab();
	// }
	// // Add a Question from Question Tab
	// if (assignmentType.equals("Quiz") || assignmentType.equals("Homework")){
	// fandePage.clickQuestionsTab();
	// fandePage.clickChapterOneFromQuestionBank(chapterNumber);
	// fandePage.clickTestBankOneFromChapterOne(selectQuestionFrom);
	// fandePage.checkFirstQuestionFromQuestionsAvailable();
	// fandePage.clickAddButtonInQuestions();
	// fandePage.verifyQuestionAddedToAssignment();
	// fandePage.removeAllQuestion();
	// fandePage.checkFirstQuestionFromQuestionsAvailable();
	// fandePage.clickAddButtonInQuestions();
	// }
	// fandePage.clickOnDoneEditingButton();
	// //test.fandePage.waitForPageToBeDisplayed(newTitle);
	// fandePage.clickOnHomeButton();
	// }
	// }
	//
	// }
	//
	// /**
	// * Attempts successfully any type of Assignment if created using
	// 'createAssignmentsByInstructor' function(except 'Homework', 'Unit' and
	// 'Learning Curve')
	// * @param assignmentTypes List of Type of Assignments for which Assignment is
	// to be attempted
	// * @param assignmentNamePrefix Prefix used for Assignment name
	// * @param assignmentScore Score of assignment
	// */
	// public void attemptAssignmentsByStudent(List<String> assignmentTypes, String
	// assignmentNamePrefix, String assignmentScore) {
	// for (int i = 0; i < assignmentTypes.size(); i++){
	// String assignmentType = assignmentTypes.get(i);
	// String assignmentName = assignmentNamePrefix + assignmentType;
	// logMessage("Attempting Assignment : " + assignmentName);
	// if (assignmentType.equals("Homework") || assignmentType.equals("Unit") ||
	// assignmentType.equals("Learning Curve") || assignmentType.equals(""))
	// continue;
	// else{
	// //clickAssignedAssignment(assignmentName);
	// fandePage.waitForPageHeaderToBeDisplayed(assignmentName);
	// if (!(assignmentType.equals("HTML Page") || assignmentType.equals("Link"))){
	// fandePage.waitForPageToBeDisplayed(assignmentName);
	// }
	// if (assignmentType.equals("Discussion Board")){
	// fandePage.postNewThreadOnDiscussionBoard("New Thread");
	// }else if (assignmentType.equals("Quiz")) {
	// fandePage.attemptQuizAndClickSubmit();
	// fandePage.switchToDefaultFrame();
	// if (!fandePage.isCorrectlyAnswered()){
	// String correctAnswer = fandePage.getCorrectAnswerOfQuestion();
	// fandePage.clickCloseButton();
	// fandePage.attemptQuizCorrectly(correctAnswer);
	// fandePage.switchToDefaultFrame();
	// }
	// fandePage.clickCloseButton();
	// }else if (assignmentType.equals("Homework")) {
	// fandePage.attemptHomework();
	// fandePage.switchToDefaultFrame();
	// if (!fandePage.isCorrectlyAnswered()){
	// String correctAnswer = fandePage.getCorrectAnswerOfQuestion();
	// fandePage.clickCloseButton();
	// fandePage.attemptHomeworkCorrectly(correctAnswer);
	// fandePage.switchToDefaultFrame();
	// }
	// fandePage.clickCloseButton();
	// }else if (assignmentType.equals("Dropbox")){
	// fandePage.submitFileForDropboxAssignment("sample.jpg");
	// }
	// fandePage.switchToTopWindow();
	// fandePage.verifyScoringIsDisplayed(assignmentScore);
	// fandePage.clickOnHomeButton();
	// verifyScoringIsDisplayedForAssignment(assignmentName, assignmentScore,
	// assignmentScore);
	// }
	// }
	//
	// }

	public void hoverOverAssignmentAndClickAssignButton(String assignment) {
		waitForElementToBeVisible("btn_assignedAssignment", assignment);
		hover(element("btn_assignedAssignment", assignment));
		((JavascriptExecutor) driver)
				.executeScript("document.getElementsByClassName('faceplate-item-assign')[0].click();");
	}

	// Hover over assignment and assign it from Course Homepage
	public void hoverOverAssignmentAndClickSettingGearIcon(String assignment) {
		waitForElementToBeVisible("btn_assignedAssignment", assignment);
		hover(element("btn_assignedAssignment", assignment));
		((JavascriptExecutor) driver)
				.executeScript("document.getElementsByClassName('gearbox-icon pxicon pxicon-gear')[0].click();");
	}

	// /**
	// * Assign the assignment from Course Home Page
	// * @param points
	// */
	// public void assignAssignment(String points){
	// fandePage.selectDateInDatePicker();
	// enterGradesForTheQuiz(points);
	// clickOnDoneButtonOnAssignmentWizard();
	// }

	/**
	 * Input grades for the Quiz in Assignment wizard
	 * 
	 * @param points
	 */
	public void enterGradesForTheQuiz(String points) {
		waitForElementToBeVisible("txtinput_gradePoints");
		element("txtinput_gradePoints").click();
		element("txtinput_gradePoints").clear();
		element("txtinput_gradePoints").sendKeys(points);
	}

	/**
	 * Switch to student view
	 */
	public void switchToStudentView() {
		element("lnk_studentView").isDisplayed();
		element("lnk_studentView").click();
	}

	public void selectCategoryFromGradebookCategoryDropdown(String option) {
		Select select = new Select(element("dropdown_gradebookCategory"));
		select.selectByVisibleText(option);
		hardWait(1);
	}

	public void fillCategoryNameInCreateNewCategoryDialog(String categoryName) {
		element("txtinput_categoryName").sendKeys(categoryName);
	}

	public void clickAddButtonOnCreateNewCategoryDialog() {
		element("btn_addOnCreateNewCategory").click();
	}

	public void verifyChapterIsDisplayed(String chapterName) {
		customAssert.customAssertTrue(isElementDisplayed("link_chapter", chapterName),
				"Assertion Failed : Chapter '" + chapterName + "' is not displayed on Course Home Page");
		logMessage("Assertion Passed : Chapter '" + chapterName + "' is displayed on Course Home Page");
	}

	/**
	 * Clicks "Is Visible to student" check box on management card
	 */
	public void clickIsVisibleToStudentCheckBox() {
		waitForElementToBeVisible("chkbox_visibletostudents");
		hardWait(1);
		element("chkbox_visibletostudents").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Clicks 'Yes'/'No' hide button on management card and verifies item is hidden
	 */
	public void clickAndVerifyHideContent(String visible, String stringInSubcontentSection) {
		if (visible.equalsIgnoreCase("yes")) {
			waitForElementToBeVisible("btn_yesVisibleToStudent");
			hardWait(1);
			element("btn_yesVisibleToStudent").click();
			waitForLoaderToDisappear();
			verifyContentIsHidden(visible, stringInSubcontentSection);
		} else {
			waitForElementToBeVisible("btn_noInvisibleToStudent");
			hardWait(1);
			element("btn_noInvisibleToStudent").click();
			waitForLoaderToDisappear();
			verifyContentIsHidden(visible, stringInSubcontentSection);
		}
	}

	/**
	 * Verifies content gets faded after hiding it
	 */
	public void verifyContentIsHidden(String visible, String stringInSubcontentSection) {
		isElementDisplayed("lnk_hiddenQuiz", stringInSubcontentSection);
		if (visible.equalsIgnoreCase("yes")) {
			customAssert.customAssertEquals(
					element("lnk_hiddenQuiz", stringInSubcontentSection).getAttribute("data-ud-isvisibletostudents"),
					"false", "Assertion Failed: Content item is not faded out and is not hidden from student");
		} else {
			customAssert.customAssertEquals(
					element("lnk_hiddenQuiz", stringInSubcontentSection).getAttribute("data-ud-isvisibletostudents"),
					"true", "Assertion Failed: Content item is not visible to student");
		}
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Clicks on Browse More Resources link
	 */
	public void clickOnBrowseMoreResources() {
		waitForElementToBeVisible("lnk_browseMoreResources");
		element("lnk_browseMoreResources").click();
	}

	/**
	 * Verifies content has been removed
	 */
	public void verifyContentIsRemoved(String contentName) {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		hardWait(1);// wait for page to be refreshed
		if (elements("link_chapterPath", contentName).size() != 0) {
			customAssert.customAssertTrue(false,
					"Assertion Failed : Subcontent '" + contentName + "' is getting displayed on course home page");
		}
		logMessage("Assertion Passed : Subcontent '" + contentName + "' is not displayed on course home page");
	}

	/**
	 * Hover and click on the assigned assignment inside the chapter
	 */
	public void hoverOverAssignmentInCapterAndClickOnGearIcon(String stringInSubcontentSection) {
		hover(element("btn_assignedAssignment", stringInSubcontentSection));
		hardWait(1);
		executeJavascript("document.getElementsByClassName('gearbox-icon pxicon pxicon-gear')[1].click();");
	}

	/**
	 * Verify content moved under the specified chapter
	 */
	public void verifyMovedContent(String quizTitle) {
		isElementDisplayed("link_itemTOC", quizTitle);
	}

	/**
	 * Verify content copied under the specified chapter
	 */
	public void verifyCopiedContent(String copyOfAssignment) {
		isElementDisplayed("link_itemTOC", copyOfAssignment);
	}

	/**
	 * Verifies Time Zone
	 */
	public void verifyChangeInTimeZone(String timeZoneType, String assignmentTitle) {
		scrollDown(element("icon_calenderOnHomePage"));
		hover(element("txt_dayDueDateItemTOC", assignmentTitle));
		logMessage(element("txt_ISTMatchOfTimeZone").getText().toString());
		customAssert.customAssertTrue(element("txt_ISTMatchOfTimeZone").getText().toString().contains(timeZoneType),
				"Assertion Failed : " + "Time Zone is incorrect");
		logMessage("The current timezone is: " + timeZoneType);
	}

	public void verifySortingOfChapters() {
		List<String> list1 = new ArrayList<String>();
		List<String> list2 = new ArrayList<String>();
		int count = 0;
		for (WebElement ele : elements("lnk_allChapters")) {
			if (count == 0) {
				count++;
			} else if (count < 10) {
				list1.add(ele.getText());
				count++;
			} else {
				list2.add(ele.getText());
				count++;
			}
		}
		customAssert.customAssertTrue(Ordering.from(String.CASE_INSENSITIVE_ORDER).isOrdered(list1),
				"Chapter list is not in sequential order");
		customAssert.customAssertTrue(Ordering.from(String.CASE_INSENSITIVE_ORDER).isOrdered(list2),
				"Chapter list is not in sequential order");
		logMessage("Chapters are in sorted order");
	}

	public void verifyAllChapterClosed() {
		for (WebElement ele : elements("lnk_allChapters")) {
			String chapterClassName = ele.getAttribute("class");
			customAssert.customAssertFalse(chapterClassName.toLowerCase().contains("active"),
					"Any Chapter from Course is opened");
		}
		logMessage("Verified that all coourses are closed");

	}

	public void verifyChapterOpened() {
		element("lnk_firstChapter").click();
		waitForLoaderToDisappear();
		String firstChapterClassName = element("lnk_firstChapterTab").getAttribute("class");
		customAssert.customAssertTrue(firstChapterClassName.toLowerCase().contains("active"),
				"Any Chapter from Course is not opened");
		logMessage("Verified that course is opened");
	}

	public void verifyHideItemIsUnvisible(String stringInSubcontentSection) {
		verifyElementNotDisplayed("lnk_hiddenQuiz", stringInSubcontentSection, "");
		logMessage("Item " + stringInSubcontentSection + " Is Hidden for the student");
	}

	public void verifyContentDisplayedAfterSpecifiedTime(String expectedTime, String assignmentName) {
		wait.resetImplicitTimeout(4 * 60);
		waitForElementToBeVisible("link_itemTOC", assignmentName);
		wait.resetImplicitTimeout(wait.timeout);
//		String currentMinute = DateUtil.getCurrentTime().split(" ")[0].split(":")[1];
//		String expectedMinute = expectedTime.split(" ")[0].split(":")[1];
//		while(!currentMinute.equals(expectedMinute)){
//			hardWait(1);
//			currentMinute = DateUtil.getCurrentTime().split(" ")[0].split(":")[1];
//		}
//		
//		hardWait(1);
		refreshPage();
		isElementDisplayed("link_itemTOC", assignmentName);
	}

	/**
	 * Method which verifies whether the Due Date icon is present for an unassigned
	 * Quiz
	 * 
	 */
	public void verifyDueDateOfUnassignedQuiz() {
		if (elements("icon_unassignedDueDate").size() != 0) {
			customAssert.customAssertTrue(false, "Due Date is displayed for an unassigned Quiz!!!");
		}
		logMessage("Due Date is NOT displayed for Un-Assigned Quiz");
	}

	/**
	 * Method which clicks on 'Show/Hide past Due' Link
	 * 
	 */
	public void clickOnShowOrHidePastDueLink() {
		scrollDown(element("lnk_hideOrshowPastDue"));
		element("lnk_hideOrshowPastDue").click();
		logMessage("Clicked on 'Show/Hide past Due' Link");
	}

	/**
	 * Method Scoring Icon is NOT displayed for Past due date whose Grace Period has
	 * lapsed
	 * 
	 * @param assignmentName - the name of assignment
	 * @param maxScore       - the maximum marks of assignment
	 * 
	 */
	public void verifyScoringIsNotDisplayedForAssignment(String assignmentName, String maxScore) {
		String actualScoring = element("txt_pointsItemTOC", assignmentName).getText();
		String expectedScoring = maxScore + " pts";
		customAssert.customAssertEquals(actualScoring, expectedScoring,
				"Assertion Failed : Assignment '" + assignmentName
						+ "' scoring is incorrectly displayed on Course Home Page. " + "Actual='" + actualScoring
						+ "', Expected='" + expectedScoring + "'");
		logMessage("Assertion Passed : Assignment score is not displayed");
	}

	/**
	 * Method which verifies the Due Date for the Entire class to be displayed after
	 * deleting the Roaster and Group for those students who were added to Roaster
	 * and Group
	 * 
	 * @param dueDateOfRosterGroup - Due Date which was assigned to Roaster n Group
	 */
	public void verifyDueDateOfEntireClassAfterRosterAndGroupIsDeleted(String dueDateOfRosterGroup) {
		if (Integer.parseInt(dueDateOfRosterGroup) < 10) {
			dueDateOfRosterGroup = "0" + dueDateOfRosterGroup;
		}

		if (element("txt_dueDateRosterAndGroup").getText().equalsIgnoreCase(dueDateOfRosterGroup)) {
			Assert.fail("Assertion Failed: Due Date of Roster And Group is getting displayed!!!");
		} else {
			logMessage("Assertion Passed: Due Date of Entire Class is Displayed!!!");
		}
	}

	public void verifySyllabusIsDisplayed() {
		isElementDisplayed("lnk_downloadSyallabus");
	}

	public void clickCategoryDropdown() {
		element("dropdown_cateoryManageAssignment").click();
		hardWait(2);
	}

	public void verifyUnassignedItemsVisibility(String visibilityStatus) {
		hardWait(1);
		Boolean status = (Boolean) executeJavascript("return document.getElementById('collapse_all').checked;");
		if (visibilityStatus.equals("true")) {
			// customAssert.customAssertEquals(element("chkbox_hideOrShowUnassignedTOC").isSelected(),false,"Assertion
			// failed : Unasigned items are not visible");
			customAssert.customAssertEquals(status, false, "Assertion failed : Unasigned items are not visible");
			customAssert.customAssertTrue(elements("list_unassignedItems", visibilityStatus).size() == 0,
					"Assertion failed : Unasigned items are not visible");
		} else if (visibilityStatus.equals("false")) {
			// customAssert.customAssertEquals(element("chkbox_hideOrShowUnassignedTOC").isSelected(),true,"Assertion
			// failed : Unasigned items are not visible");
			customAssert.customAssertEquals(status, true, "Assertion failed : Unasigned items are not visible");
			customAssert.customAssertTrue(elements("list_unassignedItems", visibilityStatus).size() == 0,
					"Assertion failed : Unasigned items are not visible");
		}
	}

	/**
	 * Click 'Add From Resources' Link
	 */
	public void clickAddFromResourcesLink() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("link_addFromResources");
		scrollDown(element("link_addFromResources"));
		element("link_addFromResources").click();
		logMessage("Clicked 'Add From Resources' Link");
	}

	/**
	 * Verify Assignment Label Link
	 */
	public void VerifyAssignmentLabelLink(String assignmentName, String labelText) {
		waitForElementToBeVisible("link_itemTOC", assignmentName);
		verifyTextOfElementIsCorrect("txt_assignmentMarker", assignmentName, labelText);
		logMessage("Label text for assignment '" + assignmentName + "' is correct");
	}

	/**
	 * Click 'Assign' Button in 'Manage Assignment' Widget
	 */
	public void clickManageAssignmentAssignButtonNew() {
		waitForElementToBeVisible("btn_assignManageAssignment");
		executeJavascript(
				"return document.evaluate(\"//input[contains(@class,'assign-showCalendar-close')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click();");
		logMessage("Clicked Assign Button.");
	}

	/**
	 * hide and show unassigned
	 */
	public void clickOnShowOrHideUnassigned() {
		// waitAndClick("chkbox_hideOrShowUnassignedTOC");
		waitAndScrollToElement("chkbox_hideOrShowUnassignedTOC");
		isElementDisplayed("chkbox_hideOrShowUnassignedTOC");
		executeJavascript("document.getElementById('collapse_all').click();");
		logMessage("Clicked on 'Show/Hide past Due' Link");
	}

	public void verifyIsTOCItemExpanded(String linkName) {
		hardWait(1);
		isElementDisplayed("list_MenuItemTOC", linkName);
		customAssert.customAssertTrue(
				element("list_MenuItemTOC", linkName).getAttribute("class").contains("nodeExpanded"),
				linkName + " is not expanded.");
		logMessage("Verified: " + linkName + " is expanded.");
	}

	public void verifyIsTOCItemCollapsed(String linkName) {
		isElementDisplayed("list_MenuItemTOC", linkName);
		customAssert.customAssertFalse(
				element("list_MenuItemTOC", linkName).getAttribute("class").contains("nodeExpanded"),
				linkName + " is not expanded.");
		logMessage("Verified: " + linkName + " is collapsed.");
	}

	public void unassignTOCItem(String linkName) {
		clickTOCItemAssignButtonForAssigned(linkName);
		waitForElementToBeVisible("assignWindow");
		clickOnManageUnassignLink();
		clickOnUnassignButtonOnManageConfirmationDialog();
	}

	public void verifyAssignmentsCategoryLabel() {
		isElementDisplayed("txt_Assignments_Category");
	}

	public void verifyUnassignedCategoryLabel() {
		isElementDisplayed("txt_Unassigned_category");
	}

	public void verifyAssignmentAndUnassignedCategoryLabel() {
		verifyAssignmentsCategoryLabel();
		verifyUnassignedCategoryLabel();
	}

	public void isSearchCourseDisplayed() {
		isElementDisplayed("txtinput_searchCourse");
	}

	public void dragAndDrop(WebElement fromEl, WebElement toEl) {
		Actions builder = new Actions(driver);
		org.openqa.selenium.interactions.Action dragAndDrop = builder.clickAndHold(fromEl).moveToElement(toEl)
				.release(toEl).build();
		dragAndDrop.perform();
		hardWait(2);
		logMessage("Instructor successfully Dragged TOC Content");
	}

	public void dragAndDropUnassignedTOCtoTOCSubContent(String fromlink, String toLink) {
		dragAndDrop(element("link_itemTOC", fromlink), element("div_itemTOC_subContent", toLink));
		// verifyToastMessageAppears(fromlink+" has been moved.");
		logMessage("Instructor successfully Dragged TOC Content: " + fromlink + " to " + toLink);
	}

	public void createPastAssignmentCategory1(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createNewAssignment(assignmentType);
		fnePage.verifyHeadingOfPage(assignmentType);
		fnePage.fillTitleOnBasicInfo(assignmentName);
		fnePage.clickOnSaveButtonOnBasicInfo();
		if (assign)
			fnePage.assignPastDateAssignment(assignmentScore, dueDate);
	}

	public void createPastDueQuizAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate, boolean addQuestions, String chapterName, String questionBank) {
		createPastAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		if (addQuestions)
			fnePage.addQuestions(chapterName, questionBank);
		fnePage.clickDoneEditingAndHomeButton();
	}

	public void verifyAssignmentVisible(String assignment) {
		waitForElementToBeVisible("li_itemTOCVisible", assignment);
		// isElementDisplayed("li_itemTOCVisible",assignment);
		executeJavascript(
				"document.evaluate(\"//*[(@class='unitfptitle' or @class='fptitle' or @class='faux-tree-link') and text()[normalize-space()='Quiz_002']]/ancestor::li[contains(@style,'display: list-item')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;");
		logMessage(assignment + " is displayed.");
	}

	public void verifyAssignmentNotVisible(String assignment) {
		waitForElementToBeVisible("li_itemTOCVisible", assignment);
		// isElementDisplayed("li_itemTOCNotVisible",assignment);
		executeJavascript(
				"document.evaluate(\"//*[(@class='unitfptitle' or @class='fptitle' or @class='faux-tree-link') and text()[normalize-space()='Quiz_002']]/ancestor::li[contains(@style,'display: none')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;");
		logMessage(assignment + " is not displayed.");
	}
}
