package com.qait.blackboard.keywords;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class LoginPageAction extends GetPage {
	public LoginPageAction(WebDriver driver) {
		super(driver, "LoginPage");
	}

	public void handleCookiesWindow() {
		try {
		int timeout = wait.getTimeout();
		wait.resetImplicitTimeout(2);
		if (element("btn_agreeAndContinue").isDisplayed()) {
			click(element("btn_agreeAndContinue"));
			logMessage("Clicked on Agree and continue btn");
		}
		wait.resetImplicitTimeout(timeout);
		}
		catch(NoSuchElementException e) {
			logMessage("No Cookies Modal window is present");
		}
	}

	public void verifyUserIsOnLoginPage() {
//		waitAndClick("btn_agreeTerm");
		verifyPageTitleExact("Blackboard Learn");
//		isElementDisplayed("img_logo");
		isElementDisplayed("txtinput_userName");
		isElementDisplayed("txtinput_password");
		isElementDisplayed("btn_login");
		logMessage("User is successfully navigated to Login Page");
	}

	public void verify_ErrorMessageDispalyed() {
        hardWait(3);
        waitForElementToBeVisible("txt_errorMsg");
        isElementDisplayed("txt_errorMsg");
        logMessage("Error Message Displayed Successfully on sending invalid Credentials");
	}

	public void loginToTheApplication(String userName, String password) {
		fillText(element("txtinput_userName"), userName);
		fillText(element("txtinput_password"), password);
		waitAndClick("btn_login");
		logMessage("User " + userName + " logins to the application");
	}
}
