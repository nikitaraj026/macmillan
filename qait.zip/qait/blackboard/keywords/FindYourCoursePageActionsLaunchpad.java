package com.qait.blackboard.keywords;

import org.openqa.selenium.WebDriver;

//import com.googlecode.javacv.FrameRecorder.Exception;
import com.qait.automation.getpageobjects.GetPage;

public class FindYourCoursePageActionsLaunchpad extends GetPage {
	
	public FindYourCoursePageActionsLaunchpad(WebDriver driver) {
		super(driver, "FindYourCoursePageLaunchpad");
	}

	
	public void switchToMainFrame() {
		switchToDefaultContent();
		waitForElementToBeVisible("iframe_findYourCourse");
		//switchToFrame(element("iframe_findYourCourse"));
	}
	
	public void closeToastMessageIfVisible() {
		clickElementIfVisible("btn_closeToastMessage");
	}
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * a. Verifications
	 ***************************/
	
	/**
	 * Verify User is on 'Find Your Course' Page
	 */
	public void verifyUserIsOnFindYourCoursepage() {
//		switchToMainFrame();
		waitForElementToBeVisible("txt_findYourCourseTitle");
		isElementDisplayed("txt_findYourCourseTitle");
		closeToastMessageIfVisible();
//		switchToDefaultContent();
	}
	
	/**
	 * Verify User is on 'Enter a Course ID' Page
	 */
	public void verifyUserIsOnEnterCourseIdPage() {
//		switchToMainFrame();
		waitForElementToBeVisible("txt_enterCourseIdTitle");
		isElementDisplayed("txt_enterCourseIdTitle");
		closeToastMessageIfVisible();
//		switchToDefaultContent();
	}
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * b. Fill Text Fields
	 ***************************/
	
	public void fillCourseId(String courseId) {
		waitAndScrollToElement("txtinput_courseId");
		fillText("txtinput_courseId", courseId);
	}
	
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * c. Click
	 ***************************/
	
	public void clickEnterYourCourseIdLink() {
		waitScrollAndClick("link_enterYourCourseId");
	}
	
	public void clickEnrollInGenericCourseLink() {
		switchToMainFrame();
		waitScrollAndClick("link_enrollInGenericCourse");
		switchToDefaultContent();
	}
	
	public void clickContinueButton() {
//		switchToMainFrame();
		scrollToTop();
		waitAndClick("btn_continue");
//		switchToDefaultContent();
	}
	
	public void clickAccessLaunchpadButton() {
		switchToMainFrame();
		logMessage("Switched to frame");
		hardWait(2);
		waitAndClick("btn_access_launchpad");
		switchToDefaultContent();
	}
	
	public void addFirstItemToCart()
	{
		switchToMainFrame();
		waitForElementToBeVisible("btn_add_first_item_to_cart");
		element("btn_add_first_item_to_cart").click();
		switchToDefaultContent();
	}
	
	public void verifyItemAddedToCart()
	{
		switchToMainFrame();
		isElementDisplayed("lnk_item_added");
		switchToDefaultContent();
	}
	
	public void clickCheckoutButton()
	{
		switchToMainFrame();
		isElementDisplayed("btn_checkout");
		element("btn_checkout").click();
		switchToDefaultContent();
	}
	
	public void verifyCheckOutPageTitle()
	{
		switchToMainFrame();
		waitForElementToBeVisible("txt_checkoutpagetitle");
		switchToDefaultContent();
	}
	
	public void clickCheckoutNowButton()
	{
		switchToMainFrame();
		waitForElementToBeVisible("btn_check_out_now");
		element("btn_check_out_now").click();
		switchToDefaultContent();
	}
	
	public void verifyPaymentInProcessMessage()
	{
		switchToMainFrame();
		waitForElementToBeVisible("txt_payment_in_process");
		switchToDefaultContent();
	}
	
	/*************************
	 * 2. COMPUNDED OPERATIONS
	 *************************/

	
}
