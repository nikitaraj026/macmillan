package com.qait.blackboard.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import org.openqa.selenium.interactions.Actions;

//import com.googlecode.javacv.FrameRecorder.Exception;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;

public class DashboardPageActionsLaunchpad extends GetPage {
	
	public DashboardPageActionsLaunchpad(WebDriver driver) {
		super(driver, "DashBoardPageLaunchpad");
	}

	/**
	 * This keyword deletes all but one courses
	 *  from the Dashboard Page.
	 */
	public void bulkDeleteCourses() {
		int i = elements("list_courseName").size();
		logMessage("Deleting " + i + " Courses");
		logMessage(" ");
		for (WebElement course : elements("list_courseName")) {
			if (--i < 2) {
				break;
			}
			logMessage(i + ". Course Named " + course.getText()
					+ " is deleted!!!");
			try {
				deleteCourse(course.getText());
			}catch(Exception e){
				continue;
			}
			//waitForElementToDisappear(course);
		}
//		while(true){
//			List<WebElement> courseList = elements("list_courseName");
//			i = courseList.size();
//			if (i < 2) {
//				break;
//			}
//			WebElement course = courseList.get(0);
//			String courseName = course.getText();
//			deleteCourse(courseName);
//			logMessage(i + ". Course Named " + course.getText()
//					+ " is deleted!!!");
//			waitForElementToDisappear("btn_deleteDeleteCourse");
//			waitForElementToDisappear("link_courseName", courseName);
//		}

	}
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * a. Verifications
	 ***************************/
	
	/**
	 * Verifies User is on Dashboard Page
	 */
	public void verifyUserIsOnDashboardPage() {
		clickElementIfVisible("btn_closeToastMessage");
		waitForLoaderToDisappear();
		isElementDisplayed("txt_myCoursesTitle");
		//hardWait(1);
	}
	
	/**
	 * Verifies that Marketing Banner Is Not Displayed
	 */
	public void verifyMarketingBannerIsNotDisplayed() {
		verifyElementNotDisplayed("container_topPanel", "LCE-914");
		verifyElementNotDisplayed("img_info_small", "LCE-914");
		verifyElementNotDisplayed("pnl_title_area", "LCE-914");
		verifyElementNotDisplayed("pnl_info_sub-title", "LCE-914");
		verifyElementNotDisplayed("pnl_authr", "LCE-914");
		verifyElementNotDisplayed("publisher_logo", "LCE-914");
	}
	
	public void verifyCreatedCourseIsOnTop(String courseName) {
		List<WebElement> courseList = elements("list_courseName");
		CustomAssert.assertEquals(courseList.get(0).getText().trim(), courseName, "Assertion Failed : "
				+ "Created Course is not on top of Dashboard Course list");
	}
	
		
	/**
	 * Verifies that Create Course Link is displayed
	 */
	public void verifyCreateCourseLinkDisplayed() {
		isElementDisplayed("link_createCourse");
	}
	
	/**
	 * Verifies that Course Name Link is displayed
	 */
	public void verifyCourseNameLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseName", courseName);
	}
	
	/**
	 * Verfies only one course is created after clicking double click on 'Create' button
	 * @param courseName
	 */
	public void verifyOneCourseCreatedAfterDoubleClick(String courseName) {
		System.out.println(elements("link_courseName", courseName).size());
		customAssert.customAssertEquals(elements("link_courseName", courseName).size(),1,"Assertion failed: Two course created after double clicking on Create button");
		logMessage("Assertion Passed: Only one course crated after double clicking 'Create' button");
	}
	
	/**
	 * Verifies that Course Information : Url is displayed
	 */
	public void verifyCourseInfoUrlDisplayed(String courseName) {
		isElementDisplayed("txt_courseUrl", courseName);
	}
	
	/**
	 * Verifies that Course Information : Domain Name(School Name) is correct
	 */
	public void verifyCourseInfoDomainName(String courseName, String domainName) {
		verifyTextOfElementIsCorrect("txt_courseDomainName", courseName, domainName);
	}
	
	/**
	 * Verifies that Course Information : Term is correct
	 */
	public void verifyCourseInfoTerm(String courseName, String term) {
		verifyTextOfElementIsCorrect("txt_courseTerm", courseName, term);
	}
	
	/**
	 * Verifies that Course Information : Id is displayed
	 */
	public void verifyCourseInfoIdDisplayed(String courseName) {
		isElementDisplayed("txt_courseId", courseName);
	}
	
	/**
	 * Verifies that Course Information : Id is correct
	 */
	public void verifyCourseInfoId(String courseName, String id) {
		verifyTextOfElementIsCorrect("txt_courseId", courseName, id);
	}
	
	/**
	 * Verifies that Course Information : Instructor is correct
	 */
	public void verifyCourseInfoInstructor(String courseName, String instructor) {
		verifyTextOfElementIsCorrect("txt_courseInstructor", courseName, instructor);
	}
	
	/**
	 * Verifies that Course Information : Status is correct
	 */
	public void verifyCourseInfoStatus(String courseName, String status) {
		verifyTextOfElementIsCorrect("txt_courseStatus", courseName, status);
	}
	public void verifyCourseInfoAcademicTerm(String courseName, String AcademicTerm) {
		verifyTextOfElementIsCorrect("txt_courseAcademicTerm", courseName,AcademicTerm);
	}
	
	/**
	 * Verifies that Course Information : Student count is correct
	 */
	public void verifyCourseInfoStudentCount(String courseName, String studentCount) {
		
		//System.out.print("///////////////////  "+courseName);

		isElementDisplayed("txt_courseStudentCount", courseName);
		verifyTextOfElementIsCorrect("txt_courseStudentCount", courseName, studentCount);
	}

	/**
	 * Verify Course View Activation Message Link displayed
	 */
	public void verifyCourseViewActivationMessageLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseViewActivationMessage", courseName);
	}
	
	/**
	 * Verify Course Activate Link displayed
	 */
	public void verifyCourseActivateLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseActivate", courseName);
	}
	
	/**
	 * Verify Course Deactivate Link displayed
	 */
	public void verifyCourseDeactivateLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseDeactivate", courseName);
	}
	
	/**
	 * Verify 'Branch this course' Link displayed
	 */
	public void verifyCourseBranchThisCourseLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseBranchThisCourse", courseName);
	}
	
	/**
	 * Verify Course Edit Link displayed
	 */
	public void verifyCourseEditLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseEdit", courseName);
	}
	
	/**
	 * Verify Course Delete Link displayed
	 */
	public void verifyCourseDeleteLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseDelete", courseName);
	}
	
	/**
	 * Verify course number is correct
	 * @param courseNumber
	 * @param courseTitle
	 */
	public void verifyCourseNumber(String courseNumber , String courseTitle){
		customAssert.customAssertEquals(element("txt_courseNumber", courseTitle).getText(), courseNumber,"Assertion Failed : Course number is incorrect expected = "+ courseNumber
				+" but found = " +element("txt_courseNumber", courseTitle).getText());
		logMessage("Assertion Passed : Course number is correct expected = "+ courseNumber
				+"  found = " +element("txt_courseNumber", courseTitle).getText());
	}
	
	/**
	 * Verify course section number is correct
	 * @param sectionNumber
	 * @param courseTitle
	 */
	public void verifyCourseSectionNumber(String sectionNumber , String courseTitle){
		customAssert.customAssertEquals(element("txt_sectionNmuber", courseTitle).getText(), sectionNumber,"Assertion Failed : Course section is incorrect expected = "+ sectionNumber
				+" but found = " +element("txt_sectionNmuber", courseTitle).getText());
		logMessage("Assertion Passed : Course section is correct expected = "+ sectionNumber
				+"  found = " +element("txt_sectionNmuber", courseTitle).getText());
	}
	/***************************
	 * 1. BASIC OPERATIONS
	 * b. Fill Text Fields
	 ***************************/
	
	
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * c. Click
	 ***************************/
	
	/**
	 * Click Create Course Link
	 */
	public void clickCreateCourseLink(String productName, String author) {
		wait.waitForLoaderToAppearAndDisappear();
		waitForElementToBeVisible("link_createCourse");
		scrollDown(element("link_createCourse"));
		executeJavascript("document.getElementById('createcourseoption').click()");
		logMessage("Clicked Create Course Link");
		_clickAndVerifyCorrectProduct(productName, author);
		
	}
	
	private void _clickAndVerifyCorrectProduct(String productName, String author) {
		waitForElementToBeVisible("div_confirmProductMessage");
		//Assert.assertEquals(element("div_confirmProductMessage").getText().replaceAll("[^\\x00-\\x7F]", "'"),productName+", "+author);
		//logMessage("Assertion Passed : Product in which course is being created is correct");
		waitForElementToBeVisible("btn_NextConfirmCourse");
		element("btn_NextConfirmCourse").click();
		logMessage("Clicked on next button to confirm correct course");
	}
	
	/**
	 * Click Course Name Link
	 */
	public void clickCourseNameLink(String courseName) {
		waitScrollAndClick("link_courseName", courseName);
		logMessage("Clicked Course '" + courseName + "' Link");
	}

	public String getCourseId(String courseName){
		String courseId = element("txt_courseId", courseName).getText();
		return courseId ;	
	}
	
	/**
	 * Click 'View Activation Message' Link
	 */
	public void clickCourseViewActivationMessageLink(String courseName) {
		waitScrollAndClick("link_courseViewActivationMessage", courseName);
		logMessage("Clicked Course '" + courseName + "' View Activation Message Link");
	}
	
	/**
	 * Click Course Activate Link
	 */
	public void clickCourseActivateLink(String courseName) {
		waitScrollAndClick("link_courseActivate", courseName);
		logMessage("Clicked Course '" + courseName + "' Activate Link");
	}
	
	/**
	 * Click Course Deactivate Link
	 */
	public void clickCourseDeactivateLink(String courseName) {
		hardWait(2);
		waitScrollAndClick("link_courseDeactivate", courseName);
		logMessage("Clicked Course '" + courseName + "' Deactivate Link");
	}
	
	/**
	 * Click Course 'Branch this course' Link
	 */
	public void clickCourseBranchThisCourseLink(String courseName) {
		waitScrollAndClick("link_courseBranchThisCourse", courseName);
		logMessage("Clicked Course '" + courseName + "' Branch this course Link");
	}
	
	/**
	 * Click Course Delete Link
	 */
	public void clickCourseDeleteLink(String courseName) {
		waitScrollAndClick("link_courseDelete", courseName);
		logMessage("Clicked Course '" + courseName + "' Delete Link");
	}
	
	/**
	 * Click Course Edit link
	 */
	public void clickCourseEditLink(String courseName) {
		waitScrollAndClick("link_courseEdit", courseName);
		logMessage("Clicked Course '" + courseName + "' Edit Link");
	}
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * d. Get Element Text/Attribute
	 ***************************/
	
	/**
	 * Returns the Course Url of the specified Course Name
	 */
	public String getCourseUrl(String courseName) {
		return element("txt_courseUrl", courseName).getText().trim();
	}
	
	/*************************
	 * 2. COMPUNDED OPERATIONS
	 *************************/
	
	/**
	 * Deletes a provided course name 
	 */
	public void deleteCourse(String courseName) {
		clickCourseDeleteLink(courseName);
		clickDeleteCourseDeleteButton();
	}
	
	/**
	 * Activates a provided course name 
	 */
	public void activateCourse(String courseName) {
		clickCourseActivateLink(courseName);
		//verifyActivateCourseWidgetDisplayed();
		clickActivateCourseActivateButton();
		clickActivateCourseDoneButton();
	}
	
	/**
	 * Deactivates a provided course name 
	 */
	public void deactivateCourse(String courseName) {
		clickCourseDeactivateLink(courseName);
		//verifyDeactivateCourseWidgetDisplayed();
		clickDeactivateCourseDeactivateButton();
	}
	
	/********************* CREATE COURSE WIDGET *********************/

	/*********************************************
	 * 1. CREATE COURSE WIDGET : BASIC OPERATIONS
	 * a. Verifications
	 *********************************************/
	
	/**
	 * Verifies that Create Course Widget is displayed
	 */
	public void verifyCreateCourseWidgetDisplayed() {
		isElementDisplayed("widget_createCourse");
	}
	
	
	/*********************************************
	 * 1. CREATE COURSE WIDGET : BASIC OPERATIONS
	 * b. Click
	 *********************************************/
	
	/**
	 * Click Create Course Widget 'Yes' Radio Button
	 */
	public void clickCreateCourseYesRadioButton() {
		element("radiobtn_yesCreateCourse").click();
		logMessage("Clicked Create Course 'Yes' Radio Button");
	}

	/**
	 * Click Create Course Widget 'No' Radio Button
	 */
	public void clickCreateCourseNoRadioButton() {
		element("radiobtn_noCreateCourse").click();
		logMessage("Clicked Create Course 'No' Radio Button");
	}
	
	/**
	 * Click Create Course Widget 'Next' Button
	 */
	public void clickCreateCourseNextButton() {
		element("btn_nextCreateCourse").click();
		logMessage("Clicked Create Course 'Next' Button");
	}
	
	/**
	 * Click Create Course Widget 'Create' Button
	 */
	public void clickCreateCourseCreateButton() {
		scrollDown(element("btn_createCreateCourse"));
		element("btn_createCreateCourse").click();
		logMessage("Clicked Create Course 'Create' Button");
	}
	
	public void selectCourseToCreateNewCourseBasedOnExisting(String existingCourseName){
		element("link_selectExistingCourse", existingCourseName).click();
		logMessage("Existing course selected for craeting new course based on it");
	}
	
	/*********************************************
	 * 1. CREATE COURSE WIDGET : BASIC OPERATIONS
	 * c. Fill Text Fields
	 *********************************************/
	
	/**
	 * Fill Course Title in Create Course Widget
	 */
	public void fillCreateCourseWidgetCourseTitle(String courseTitle) {
		fillText("txtinput_courseTitleCreateCourse", courseTitle);
	}
	
	/**
	 * Fill Course Number in Create Course Widget
	 */
	public void fillCreateCourseWidgetCourseNumber(String courseNumber) {
		fillText("txtinput_courseNumberCreateCourse", courseNumber);
	}
	
	/**
	 * Fill Section Number in Create Course Widget
	 */
	public void fillCreateCourseWidgetSectionNumber(String sectionNumber) {
		fillText("txtinput_sectionNumberCreateCourse", sectionNumber);
	}
	
	/**
	 * Fill Instructor Name in Create Course Widget
	 */
	public void fillCreateCourseWidgetInstructorName(String instructorName) {
		fillText("txtinput_instructorNameCreateCourse", instructorName);
	}
	
	/**
	 * Fill School Name in Create Course Widget
	 */
	public void fillCreateCourseWidgetSchoolName(String schoolName) {
		waitForElementToBeVisible("txtinput_schoolNameCreateCourse");
		sendKeys(element("txtinput_schoolNameCreateCourse"), schoolName);
		element("txtinput_schoolNameCreateCourse").click();
		waitAndClick("dropdown_schoolNameCreateCourse", schoolName);	
	}
	
	/*********************************************
	 * 1. CREATE COURSE WIDGET : BASIC OPERATIONS
	 * c. Dropdown Option Select
	 *********************************************/
	
	/**
	 * Select provided School Name from dropdown in Create Course Widget
	 */
	public void selectCreateCourseWidgetSchoolName(String schoolName) {
		element("dropdown_schoolNameCreateCourse", schoolName).click();
	}
	
	/**
	 * Select Academic term in Create Course Widget
	 */
	public void selectCreateCourseWidgetAcademicTerm(String academicTerm) {
		selectProvidedTextFromDropDown(element("dropdown_academicTermCreateCourse"), academicTerm);
	}
	
	/**
	 * Select Time Zone in Create Course Widget
	 */
	public void selectCreateCourseWidgetTimeZone(String timeZone) {
		selectProvidedTextFromDropDown(element("dropdown_timezoneCreateCourse"), timeZone);
	}
	
	/*************************************************
	 * 2. CREATE COURSE WIDGET : COMPUNDED OPERATIONS
	 *************************************************/
	
	/**
	 * Create Course Widget : Select 'No' then click 'Next' 
	 */
	public void createCourseNotBasedOnExistingCourse(String productName, String author) {
		clickCreateCourseLink(productName, author);
		clickCreateCourseNoRadioButton();
		clickCreateCourseNextButton();
	}
	
	/**
	 * Create Course Widget : Select 'Yes' and course name then click 'Next' 
	 * @param courseName Course name to be taken as base
	 */
	public void createCourseBasedOnExistingCourse(String courseName, String productName, String author) {
		clickCreateCourseLink(productName, author);
		clickCreateCourseYesRadioButton();
		selectCourseToCreateNewCourseBasedOnExisting(courseName);
		clickCreateCourseNextButton();
	}
	
	/**
	 * Create Course Widget : Fill Course Name and other details and click Create
	 */
	public String createCourse(String courseTitle, String courseNumber, String sectionNumber,
			String instructorName, String schoolName, String academicTerm) {
		if (!courseTitle.equals("")) fillCreateCourseWidgetCourseTitle(courseTitle);
		if (!courseNumber.equals("")) fillCreateCourseWidgetCourseNumber(courseNumber);
		if (!sectionNumber.equals("")) fillCreateCourseWidgetSectionNumber(sectionNumber);
		if (!instructorName.equals("")) fillCreateCourseWidgetInstructorName(instructorName);
		if (!schoolName.equals("")) {
			/*fillCreateCourseWidgetSchoolName(schoolName);
			selectCreateCourseWidgetSchoolName(schoolName);*/
			waitForElementToBeVisible("txtinput_schoolNameCreateCourse");
			sendKeys(element("txtinput_schoolNameCreateCourse"), schoolName);
			element("txtinput_schoolNameCreateCourse").click();
			waitAndClick("dropdown_schoolNameCreateCourse", schoolName);			
			
		}
		String timeZone = element("txt_selectedTimeZone").getText();
		hardWait(1);
		if (!academicTerm.equals("")) selectCreateCourseWidgetAcademicTerm(academicTerm);
		clickCreateCourseCreateButton();
		return timeZone;
	}
	
	
	public String createCourseWithDoubleClickOnCreateButton(String courseTitle, String courseNumber, String sectionNumber,
			String instructorName, String schoolName, String academicTerm) {
		if (!courseTitle.equals("")) fillCreateCourseWidgetCourseTitle(courseTitle);
		if (!courseNumber.equals("")) fillCreateCourseWidgetCourseNumber(courseNumber);
		if (!sectionNumber.equals("")) fillCreateCourseWidgetSectionNumber(sectionNumber);
		if (!instructorName.equals("")) fillCreateCourseWidgetInstructorName(instructorName);
		if (!schoolName.equals("")) {
			/*fillCreateCourseWidgetSchoolName(schoolName);
			selectCreateCourseWidgetSchoolName(schoolName);*/
			waitForElementToBeVisible("txtinput_schoolNameCreateCourse");
			sendKeys(element("txtinput_schoolNameCreateCourse"), schoolName);
			element("txtinput_schoolNameCreateCourse").click();
			waitAndClick("dropdown_schoolNameCreateCourse", schoolName);			
			
		}
		String timeZone = element("txt_selectedTimeZone").getText();
		hardWait(1);
		if (!academicTerm.equals("")) selectCreateCourseWidgetAcademicTerm(academicTerm);
		Actions action = new Actions(driver);
		action.doubleClick(element("btn_createCreateCourse")).build().perform();
		return timeZone;
	}
	
	/********************* DELETE COURSE WIDGET *********************/

	/*********************************************
	 * 1. DELETE COURSE WIDGET : BASIC OPERATIONS
	 * a. Verifications
	 *********************************************/
	
	/**
	 * Verifies that Delete Course Widget is displayed
	 */
	public void verifyDeleteCourseWidgetDisplayed() {
		isElementDisplayed("widget_deleteCourse");
	}
	
	/*********************************************
	 * 1. DELETE COURSE WIDGET : BASIC OPERATIONS
	 * b. Click
	 *********************************************/
	
	/**
	 * Click Delete Course Widget 'Delete' Button
	 */
	public void clickDeleteCourseDeleteButton() {
		element("btn_deleteDeleteCourse").click();
		logMessage("Clicked Delete Course 'Delete' Button");
	}

	
	/********************* ACTIVATE COURSE WIDGET *********************/

	/*********************************************
	 * 1. ACTIVATE COURSE WIDGET : BASIC OPERATIONS
	 * a. Verifications
	 *********************************************/
	
	/**
	 * Verifies that Activate Course Widget is displayed
	 */
	public void verifyActivateCourseWidgetDisplayed() {
		isElementDisplayed("widget_activateCourse");
	}
	
	/*********************************************
	 * 1. ACTIVATE COURSE WIDGET : BASIC OPERATIONS
	 * b. Click
	 *********************************************/
	
	/**
	 * Click Activate Course Widget 'Activate' Button
	 */
	public void clickActivateCourseActivateButton() {
		waitForElementToBeVisible("btn_activateActivateCourse");
		element("btn_activateActivateCourse").click();
		logMessage("Clicked Activate Course 'Activate' Button");
		hardWait(1);
	}
	
	/**
	 * Click Activate Course Widget 'Done' Button
	 */
	public void clickActivateCourseDoneButton() {
		waitForLoaderToDisappear();
		hardWait(2);
		waitForElementToBeVisible("btn_doneActivateCourse");
		element("btn_doneActivateCourse").click();
		waitForElementToDisappear("btn_doneActivateCourse");
		logMessage("Clicked Activate Course 'Done' Button");
	}
	
	
	/********************* DEACTIVATE COURSE WIDGET *********************/

	/*********************************************
	 * 1. DEACTIVATE COURSE WIDGET : BASIC OPERATIONS
	 * a. Verifications
	 *********************************************/
	
	/**
	 * Verifies that Deactivate Course Widget is displayed
	 */
	public void verifyDeactivateCourseWidgetDisplayed() {
		waitForElementToBeVisible("widget_deactivateCourse");
		isElementDisplayed("widget_deactivateCourse");
	}
	
	/*********************************************
	 * 1. DEACTIVATE COURSE WIDGET : BASIC OPERATIONS
	 * b. Click
	 *********************************************/
	
	/**
	 * Click Deactivate Course Widget 'Deactivate' Button
	 */
	public void clickDeactivateCourseDeactivateButton() {
		element("btn_deactivateDeactivateCourse").click();
		logMessage("Clicked Deactivate Course 'Deactivate' Button");
	}
	
	/*********************************************
	 * 1. BRANCH COURSE WIDGET : BASIC OPERATIONS
	 * b. Click
	 *********************************************/
	
	/**
	 * Click Branch Course Widget 'Yes, I'd like to branch this course' Button
	 */
	public void clickConfirmButtonOnBranchCourseModal(){
		waitForElementToBeVisible("btn_branchConfirm");
		if (elements("btn_branchConfirm").size() == 1) {
			element("btn_branchConfirm").click();
		}
	}


	
	/*********************************************
	 * 1. EDIT COURSE WIDGET : BASIC OPERATIONS
	 * a. Click
	 *********************************************/
	
	/**
	 * Click Delete Course Widget 'Delete' Button
	 */
	public void saveEditedDetails() {
		waitForLoaderToDisappear();
		waitScrollAndClick("btn_Save");
		logMessage("Clicked 'Save' Button");
	}
	
	
	/*********************************************
	 * Other operations
	 * Author: Moksh
	 *********************************************/
	
	public void verifyPrivacyPolicyLink(){
		waitForElementToBeVisible("lnk_privacy");
		isElementDisplayed("lnk_privacy");			
	}
	
	public void clickPrivacyPolicyLink(){
		element("lnk_privacy").click();
		logMessage("Clicked on Privacy Policy Link");			
	}
	
	public void verifyPrivacyPolicyPage(String Title){
		changeWindow(1);
		wait.waitForPageTitleToContain(Title);
		verifyPageTitleContains(Title);			
	}
	
	public void DeleteCourseVerifyInstructions(String courseName, String deleteInstruction){
		clickCourseDeleteLink(courseName);
		verifyInstructionsonDeletePage(deleteInstruction);
		clickDeleteCourseDeleteButton();	
	}
	
	public void verifyInstructionsonDeletePage(String deleteInstruction){
		waitForElementToBeVisible("txt_deleteCourseMessage");
		isElementDisplayed("txt_deleteCourseMessage");
		verifyTextOfElementIsCorrect("txt_deleteCourseMessage",deleteInstruction);	
	}
	
	public void verifyCourseIsDeleted(String courseName){
		verifyElementNotDisplayed("link_courseName", courseName, "");	
	}
	
	public void createCourseWithLMSPromt(String courseTitle, String courseNumber, String sectionNumber,
			String instructorName, String schoolName, String academicTerm, String LMSMessage) {
		if (!courseTitle.equals("")) fillCreateCourseWidgetCourseTitle(courseTitle);
		if (!courseNumber.equals("")) fillCreateCourseWidgetCourseNumber(courseNumber);
		if (!sectionNumber.equals("")) fillCreateCourseWidgetSectionNumber(sectionNumber);
		if (!instructorName.equals("")) fillCreateCourseWidgetInstructorName(instructorName);
		if (!schoolName.equals("")) {
			/*fillCreateCourseWidgetSchoolName(schoolName);
			selectCreateCourseWidgetSchoolName(schoolName);*/
			waitForElementToBeVisible("txtinput_schoolNameCreateCourse");
			sendKeys(element("txtinput_schoolNameCreateCourse"), schoolName);
		}
		if (!academicTerm.equals("")) selectCreateCourseWidgetAcademicTerm(academicTerm);
		selectLMSPromptRadioButton();
		enterLMSMessage(LMSMessage);
		clickCreateCourseCreateButton();
	}
	
	public void selectLMSPromptRadioButton(){
		waitForElementToBeVisible("radio_lmsprompt");
		element("radio_lmsprompt").click();	
	}

	public void enterLMSMessage(String message){
		waitForElementToBeVisible("txtinput_LMSPrompt");
		isElementDisplayed("txtinput_LMSPrompt");
		element("txtinput_LMSPrompt").sendKeys(message);	
	}

	public void activateCourseandverifyInstructions(String courseName, String url, String color){
		clickCourseActivateLink(courseName);
		clickActivateCourseActivateButton();
		verifyActivationPageInstrctions(url, color);
		clickActivateCourseDoneButton();	
	}
	
	public void verifyActivationPageInstrctions(String url, String color){
		waitForElementToBeVisible("txt_urltext");
		isElementDisplayed("txt_urltext");
		isElementDisplayed("txt_urldisplay",url);
		isElementDisplayed("txt_copypaste");
		verifyColorOfCopyPaste("txt_copypaste", color);
		isElementDisplayed("txt_studentmessage");	
	}
	
	public void verifyColorOfCopyPaste(String elementToken, String color){
		verifyBackgroundColorHexCode(elementToken,"","",color);
	}
	
	public void viewActivationMessageAndVerifyInstructions(String courseName, String url, String color){
		clickViewActivationMessageLink(courseName);
		verifyActivationPageInstrctions(url, color);
		clickActivateCourseDoneButton();	
	}
	
	public void clickViewActivationMessageLink(String courseName) {
		waitScrollAndClick("link_courseViewActivationMessage", courseName);
		logMessage("Clicked Course '" + courseName + "' View Activation Message Link");
	}

	public void verifyActivateWindowCourseDetail(String property, String expectedValue) {
		String actual = element("txt_activateWidgetPropertyValue", property).getText();   
		customAssert.customAssertEquals(actual, expectedValue.toUpperCase(), "Assertion Failed : Value of '" + property
				 + "' is incorrect");
	}
	
	public void verifyDeactivateWindowCourseDetail(String property, String expectedValue){
		String actual = element("txt_activateWidgetPropertyValue", property).getText();  
		if(property.equals("Course Start Date"))
			actual = actual.split(" ")[0];
		customAssert.customAssertEquals(actual, expectedValue.toUpperCase(), "Assertion Failed : Value of '" + property
				 + "' is incorrect");
	}

	public void verifyDeleteWindowCourseDetail(String property, String expectedValue) {
		String actual = element("txt_activateWidgetPropertyValue", property).getText();   
		customAssert.customAssertEquals(actual, expectedValue.toUpperCase(), "Assertion Failed : Value of '" + property
				 + "' is incorrect");
	}
	
	public void verifyEditLinkOnActivateCourseModal() {
		isElementDisplayed("link_edit");
	}

	public void clickEditLinkOnActivateCourseModal() {
		waitScrollAndClick("link_edit");
		logMessage("Clicked Edit this information from Activate Course widget");
	}
	
}

