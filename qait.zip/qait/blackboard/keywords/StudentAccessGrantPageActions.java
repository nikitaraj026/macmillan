package com.qait.blackboard.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class StudentAccessGrantPageActions extends GetPage{
	public StudentAccessGrantPageActions(WebDriver driver){
		super(driver,"StudentAccessPage");
	}
	
	public void clickBackToBlackBoardOnStudentAccessPage() {
		waitAndClick("button_backToBlackboard");
		logMessage("Clicked: Back to Blackboard");
	}
	
	public void clickenterAnAccessCode(){
		waitAndClick("button_enterAnAccessCode");
		logMessage("Clicked: Enter an Access Code");
	}
	
	public void clickPurchaseAccess() {
		waitAndClick("button_purchaseAccess");
		logMessage("Clicked: Purchase Access");
	}
	
	public void clickRequestFreeTrial(){
		waitAndClick("button_requestFreeTrial");
		logMessage("Clicked: Request Free Trial");
	}
	
	//Enter Student Access Code Mars
	public void verifyUserIsOnEnterStudentAccessCodePage() {
		verifyTextOfElementIsCorrect("StudentAccessCodeTitle", "Enter Student Access Code");
		logMessage("User is on 'Enter Student Access Code' page.");
	}
	
	public void fillAccessCodeOnEnterStudentAccessCode(String accessCode) {
		fillText("input_accessCode", accessCode);
	}
	
	public void clickSubmitOnEnterStudentAccessCode() {
		waitAndClick("btn_submitStudentAccessCodeMars");
		logMessage("Clicked: 'Submit' button on 'Enter Student Access Code' page.");
	}
	
	public void clickCancelOnEnterStudentAccessCode() {
		waitAndClick("btn_cancelStudentAccessCodeMars");
		logMessage("Clicked: 'Cancel' button on 'Enter Student Access Code' page.");
	}
	
	//Purchase Access
	public void verifyUserIsOnPurchaseAccessPage() {
		isElementDisplayed("txt_purchaseAccessTitle");
		logMessage("User is on 'Purchase access' page.");
	}
	
	public void select180DaysAccess() {
		hardWait(4);
		waitForElementToBeClickable(element("input_180daysAccess"));
		waitAndClick("input_180daysAccess");
		logMessage("Selected: '180 days access' on 'Purchase access' page");
	}
	
	public void selectCountryAndEnterZipForTaxCalculation()
	{
		selectProvidedTextFromDropDown(element("dropdown_country"), "United States");
		fillText("input_zip", "10003");
		logMessage("Student has selected/entered information in 'Country' and 'Zip' fields");
	}
	
	public void select1yearAccess() {
		waitAndClick("input_1yearAccess");
		logMessage("Selected: '1 year access' on 'Purchase access' page");
	}
	
	public void select2yearAccess() {
		waitAndClick("input_2yearAccess");
		logMessage("Selected: '2 year access' on 'Purchase access' page");
	}
	
	public void clickAddToCart() {
		hardWait(3);
		waitAndClick("button_addToCart");
		hardWait(2);
		waitAndClick("button_addToCart");
		logMessage("Clicked: 'Add to Cart' on 'Purchase access' page.");
	}
	public void choosePaymentMethod(String paymentName) {
		waitForElementToBeVisible("btn_payment_name",paymentName);
		isElementDisplayed("btn_payment_name",paymentName);
		hardWait(3);
		waitAndClick("btn_payment_name",paymentName);
		logMessage("Clicked on "+paymentName+" method");
		
	}

	
	//Purchase Access > Payment Details
	public void verifyUserIsOnPaymentDetailsPage() {
		isElementDisplayed("txt_paymentDetailsTitle");
		logMessage("User is on 'Payment Details' page.");
	}
	
	public void clickPaypalOnPaymentDetailsPage() {
		switchToFrame("frame_paymentFormPaypal");
		waitAndClick("button_paypal");
		logMessage("Clicked: 'PayPal' on 'Payment Details' page.");
		switchToDefaultContent();
	}
	
	public void handlePaypalSandbox() {
		changeWindow(1);
		isElementDisplayed("paypalWindowTitle");
		waitAndClick("button_proceedSandboxPurchase");
		changeWindow(0);
		switchToFrame("frame_paymentFormPaypal");
		isElementDisplayed("txt_paymentMethodTypePaypal");
		switchToDefaultContent();
		logMessage("'Paypal Sandbox' has been handled.");
	}

	public void enterCardNumberOnPaymentDetailsPage(String cardNumber) {
		switchToFrame("iframe_payPal");
		waitForElementToBeVisible("input_cardNumber");
		element("input_cardNumber").sendKeys(cardNumber);
		logMessage("User has entered card number on 'Payment Details' page");		
	}


	public void enterExpirationAndCVVOnPaymentDetailsPage(String expiration, String cvv) {
		switchToFrame("iframe_expiration_Date");
		isElementDisplayed("input_expiration");
		
		element("input_expiration").sendKeys(expiration);
		hardWait(2);
		switchToFrame("iframe_cvv");
		isElementDisplayed("input_cvv");
		element("input_cvv").sendKeys(cvv);
		switchToDefaultContent();
		logMessage("User has entered card expiration date and CVV");		
	}
	
	public void clickContinueOnPaymentDetailsPage() {
		waitAndClick("button_continuePaymentDetails");
		logMessage("Clicked: 'Continue' button on 'Payment Details' page.");
	}
	
	//Purchase Access > Review Your Order
	public void verifyUserIsOnReviewYourOrderPage() {
		waitAndClick("txt_reviewYourOrderTitle");
		logMessage("User is on 'Review Your Order' page.");
	}
	
	public void clickConfirmPaymentOnReviewYourOrderPage() {
		waitAndClick("button_confirmPayment");
		logMessage("Clicked 'Confirm payment' on 'Review Your Order' page.");
	}
	
	//Purchase Access > Purchase Confirmation
	public void verifyUserIsOnPurchaseConfirmationPage() {
		isElementDisplayed("txt_purchaseConfirmationTitle");
		logMessage("User is on 'Purchase Confirmation' page.");
	}
	
	public void clickContinueOnPurchaseConfirmationPage() {
		waitAndClick("button_continuePurchaseConfirmation");
		logMessage("Clicked: 'Continue' button on 'Purchase Confirmation' page.");
	}
	
	//Request Free Trial
	public void clickContinueToSite(){
		waitAndClick("button_continueToSite");
		logMessage("Clicked: Continue to Site");
	}
}
