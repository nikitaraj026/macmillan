package com.qait.blackboard.keywords;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.qait.automation.getpageobjects.GetPage;

public class WelcomePageActionsLaunchpad extends GetPage {

	String currentDir = System.getProperty("user.dir");

	public WelcomePageActionsLaunchpad(WebDriver driver) {
		super(driver, "WelcomePageLaunchpad");
	}
	
	public void switchToTopWindow() {
		switchToDefaultContent();
	}

	public void switchToWelcomeIframe() {
//		switchToDefaultContent();
//		switchToFrame(element("iframe_welcomePage"));
	}
	
	public void verifyWelcomePageDisplayed() {
		isElementDisplayed("button_enterCourse");
		clickElementIfVisible("btn_closeToastMessage");
	}
	
	/**
	 * Verifies that Marketing Banner Is Not Displayed
	 */
	public void verifyMarktngBannerIsNotDisplayed() {
		verifyElementNotDisplayed("container_topPanel", "LCE-914");
		verifyElementNotDisplayed("img_info_large", "LCE-914");
		verifyElementNotDisplayed("pnl_title_area", "LCE-914");
		verifyElementNotDisplayed("pnl_info_sub-title", "LCE-914");
		verifyElementNotDisplayed("pnl_authr", "LCE-914");
		verifyElementNotDisplayed("publisher_logo", "LCE-914");
	}

	
//	public void verifyUserIsOnWelcomePage(){
//		verifyUserIsOnWelcomePage("Welcome to LaunchPad!");
//	}

	public void verifyUserIsOnWelcomePage(String welcomePageTitle) {
		isElementDisplayed("txt_welcomePageTitle",welcomePageTitle);
		logMessage("Assertion Passed: User is on Welcome Page, Verified Page title visibility and text to be: " + welcomePageTitle);
	}

	public void verifyUserIsOnEditPage() {
		customAssert.customAssertTrue(isElementDisplayed("button_doneEditing"), "Assertion Failed: Edit Page is not correct");
		logMessage("Assertion Passed: User is on Edit Page");
	}

	public void clickEditPageFromWelcomePage(){
		//waitScrollAndClick("button_editPage");
		scrollDown(element("txt_welcomePageTitle"));
		element("button_editPage").click();
	}

	public void enterCourseFromWelcomePage(){
		switchToDefaultContent();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		waitForElementToBeVisible("button_enterCourse");
		js.executeScript("document.getElementsByClassName('EnterCourse')[0].click();");
		//element("button_enterCourse").click();
		logMessage("User clicks on 'Enter Course' button on Welcome Page");
	}

	public void clickDoneEditingOnEditPage(){
		waitScrollAndClick("button_doneEditing");
	}

	public void dragAndDropWidget() {
		Actions builder = new Actions(driver);
		org.openqa.selenium.interactions.Action dragAndDrop = builder.clickAndHold(element("dragWidgetFrom")).moveToElement(element("dragWidgetTo")).release(element("dragWidgetTo")).build();
		dragAndDrop.perform();
		hardWait(2);
		logMessage("Instructor Drag the widget");
	}

	/*
	 * Selects Add Widget Option(number) and waits for loader to disappear
	 */
	public void addNewWidget(String widgetName){
		clickElementIfVisible("btn_closeToastMessage");
		scrollDown(element("txt_welcomePageTitle"));
		element("lnk_addNewWidget").click();
		waitForElementToBeVisible("lnk_createwidget", widgetName);
		element("lnk_createwidget", widgetName).click();
	}

	/*
	 * Verifies number of specific widget present on Edit page 
	 */
	public void verifyWidgetCountOnPage(String widgetName, int count){
		waitForLoaderToDisappear();
		hardWait(5);
		wait.waitForElementsToBeVisible(elements("listOfHeadingOfSpecificWidget", widgetName));
		List<WebElement> elems = elements("listOfHeadingOfSpecificWidget", widgetName);
		customAssert.customAssertEquals(elems.size(), count, "Assertion Failed : Total Widgets '" + widgetName + "' on page are incorrect");
		logMessage("Assertion Passed : Total Widgets '" + widgetName + "' on page are correct");
		hardWait(2);
	}

	/*
	 * Fills a TextInput Field
	 */
	private void fillTextInputField(String elemName, String text) {
		waitAndClick(elemName);
		element(elemName).clear();
		element(elemName).sendKeys(text);
	}

	/*
	 * Clicks on Welcome Title Widget on Edit Page
	 */
	public void clickWelcomeTitleWidget(){
		hardWait(2);
		scrollDown(element("txt_welcomePageTitle"));
		hardWait(5);
		((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('blockWidgetUI widgetBlocker_OFF')[0].setAttribute('class','blockWidgetUI widgetBlocker_ON');");
		hardWait(1);
		//element("welcomeTitleWidget").click();
		executeJavascript("document.getElementsByClassName('blockWidgetUI widgetBlocker_ON')[0].click()");
		waitForLoaderToDisappear();
	}

	/*
	 * Updates Title of Course from Edit Page
	 */
	public void updateTitle(String newTitle) {
		clickWelcomeTitleWidget();
		customAssert.customAssertTrue(isElementDisplayed("headingTitleUpdateDialogBox"), "Assertion Failed: Title Update Dialog Box did not open");
		logMessage("Assertion Passed: User is on Title Update dialog box");
		fillTextInputField("txtinput_welcomePageTitle", newTitle);
		element("button_save").click();
	}

	/**
	 * Verifies that the Welcome Title is correct on Edit Page
	 */
	public void verifyWelcomeTitleOnEditPage(String title) {
		customAssert.customAssertTrue(element("welcomeTitle", title).isDisplayed(), "Assertion Failed : Title on Edit Page is incorrect");
		logMessage("Assertion Passed : Title on Edit page is correct");
	}

	/*
	 * Verifies RSS Feed Dialog Box(on Edit Page) is open and sumbits an RSS Feed
	 */
	public void sumbitRssFeed(String rssFeedUrl) {
		customAssert.customAssertTrue(isElementDisplayed("txt_rssFeedTitle"), "Assertion Failed: RSS Feed Dialog Box did not open");
		logMessage("Assertion Passed: User is on RSS Feed Update dialog box");
		fillTextInputField("txtinput_rssFeedUrl", rssFeedUrl);
		element("button_add").click();	
		waitForLoaderToDisappear();
	}

	/**
	 * Verifies user is on TinyMCE Editor
	 */
	public void verifyUserIsOnTinyMceEditor(){
		isElementDisplayed("headingTitleUpdateDialogBox");
		isElementDisplayed("tinyMCE_Editor");
		isElementDisplayed("toolbar_mceEditor");
		isElementDisplayed("button_save");
		isElementDisplayed("btn_cancel");
		logMessage("Assertion Passed: User is on TinyMCE editor");
	}

	/*
	 * Removes the default Assignment widget from Edit Page
	 */
	public void removeDefaultAssignmentWidget() {
		waitAndClick("button_removeAssignmentWidget");
		//element("button_removeAssignmentWidget").click();
		logMessage("Instructor remove the Assignment Widget");
		hardWait(3);
	}

	/**
	 * Enters text in TinyMCE editor
	 */
	public void enterTextInTinyMCEEditor(String text){
		((JavascriptExecutor) driver).executeScript("document.getElementById('Contents_ifr').contentDocument.getElementById('tinymce').getElementsByTagName('p')[0].innerHTML='"+text+"'");
		element("button_save").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Inserts video in TinyMCE Editor
	 */
	public void insertsVideo(String filename){
		switchToDefaultContent();
		clickInsertsMediaIcon();
		enterVideoUrl(filename);
		_verifyVideoAppearInPreviewModal(filename);
		clickOnInsertButton();
		scrollDown(element("button_save"));
		executeJavascript("document.getElementsByClassName('ui-dialog-buttonset')[0].getElementsByTagName('button')[0].click();");
		waitForLoaderToDisappear();
	}

	/**
	 * Verifies video loads in preview modal
	 */
	private void _verifyVideoAppearInPreviewModal(String filename){
		//waitForElementToBeVisible("iframe_videoPreview", filename);
		//isElementDisplayed("iframe_videoPreview", filename);
	}
	
	/**
	 * Verifies video loads on mce editor
	 *//*
	public void verifyVideoOnMceEditor(){
		switchToDefaultContent();
		switchToFrame(element("iframe_ContentEditor"));
		if(isElementDisplayed("img_videoMceEditor")){
			customAssert.customAssertTrue(false, "Assertion Failed: Video not loaded in mce editor");
		}
		else{
			logMessage("Video is loaded in MCE editor");
		}
		switchToDefaultContent();
	}
	*/
	/**
	 * Clicks the inserts media icon
	 */
	public void clickInsertsMediaIcon(){
		waitForElementToBeVisible("icon_mceMedia");
		element("icon_mceMedia").click();
	}

	/**
	 * Enter file/video url 
	 */
	public void enterVideoUrl(String filename){
		switchToDefaultContent();
		waitForElementToBeVisible("iframe_media");
		switchToFrame(element("iframe_media"));
		waitForElementToBeVisible("txtinput_mediaUrl");
		element("txtinput_mediaUrl").click();
		element("txtinput_mediaUrl").clear();
		element("txtinput_mediaUrl").sendKeys(filename);
		element("txtinput_dimension").click();
		/*		if (System.getProperty("os.name").contains("Windows")) {
			element("txtinput_mediaUrl").sendKeys(currentDir + "\\src\\test\\resources\\testdata\\" + filename);
		} else {
			element("txtinput_mediaUrl").sendKeys(currentDir + "/src/test/resources/testdata/" + filename);
		}
		}*/
	}

	/**
	 * Selects a text and clicks Link icon
	 */
	public void clickOnInsertLinkIcon(){
		switchToFrame(element("iframe_ContentEditor"));
		waitForElementToBeVisible("txt_mceEditor");
		selectText(element("txt_mceEditor"));
		switchToDefaultContent();
		switchToWelcomeIframe();
		element("icon_mceLink").click();	
	}

	/**
	 * Insert the link and clicks insert button
	 * @param url
	 */
	public void insertLink(String url){
		switchToFrame(element("iframe_link"));
		hardWait(2);
		waitForElementToBeVisible("txtinput_linkUrl");

		element("txtinput_linkUrl").click();
		element("txtinput_linkUrl").clear();
		element("txtinput_linkUrl").sendKeys(url);
		element("btn_insert").click();
		hardWait(5);
		switchToDefaultContent();
		scrollDown(element("button_save"));
		//element("button_save").click();
		executeJavascript("document.getElementsByClassName('ui-dialog-buttonset')[0].getElementsByTagName('button')[0].click();");
		//scrollDown(element("button_save"));
//		element("button_save").click();
		waitForLoaderToDisappear();
		logMessage("User successfully inserted the link");
	}

	/**
	 * Verifies the inserted link on start welcome message
	 */
	public void verifyInsertedLinkOnStartWelcomeMessage(String url,String mceText){
		switchToDefaultContent();
		customAssert.customAssertTrue(element("link_startWelcomeMessage",mceText).getAttribute("href").contains(url), "Assertion Failed: Link appearing on start welcome message is not correct");
		logMessage("Assertion Passed: Link appearing on start welcome message is  correct");
	}

	/**
	 * Inserts image
	 */
	public void insertImage(String imageTitle, String imageDescription, String imageURL){
		switchToDefaultContent();
		clickImageIcon();
		//enterFilePathOnInsertImageModalAndClickUpload(filename);
		switchToFrame(element("iframe_image"));
		fillText("txtinput_imgUrl", imageURL);
		entersImageDescription(imageDescription);
		hardWait(2);
		_verifyImageLoadedInPreviewModal();
		clickOnInsertButton();
		hardWait(2);
		_verifyImageLoadedInTinyMceEditor();
		hardWait(2);
		scrollDown(element("button_save"));
		executeJavascript("document.getElementsByClassName('ui-dialog-buttonset')[0].getElementsByTagName('button')[0].click();");
		waitForLoaderToDisappear();
//		clickOnSaveButtonOnMCEEditor();
	}

	/**
	 * Click on Image icon to insert image
	 */
	public void clickImageIcon(){
		waitForElementToBeVisible("icon_mceImage");
		element("icon_mceImage").click();
	}

	/**
	 * Enter file path for an image
	 * @param filename
	 */
	public void enterFilePathOnInsertImageModalAndClickUpload(String filename){
		switchToFrame(element("iframe_image"));
		currentDir = System.getProperty("user.dir");
		if (System.getProperty("os.name").contains("Windows")) {
			element("txtinput_uploadFile").sendKeys("c:\\" +  filename);
			//element("txtinput_uploadFile").sendKeys(currentDir + "\\src\\test\\resources\\testdata\\" +  filename);
		} else {
			element("txtinput_uploadFile").sendKeys(currentDir + "/src/test/resources/testdata/"+  filename);
		}
		hardWait(10);
		element("btn_upload").click();
		waitForElementToDisappear("txt_uploadError");
	}
	
	/**
	 * Verifies image is loaded in Preview modal
	 */
	private void _verifyImageLoadedInPreviewModal(){
		waitForElementToBeVisible("img_preview");
		isElementDisplayed("img_preview");
	}

	/**
	 * Verifies image is loaded in tinymce editor
	 */
	public void _verifyImageLoadedInTinyMceEditor(){
		switchToWelcomeIframe();
		switchToFrame(element("iframe_ContentEditor"));
		isElementDisplayed("img_tinyMceEditor");
		switchToDefaultContent();
	}
	/**
	 * Enters image description
	 */
	public void entersImageDescription(String description){
		element("txtinput_imgDescription").click();
		element("txtinput_imgDescription").clear();
		element("txtinput_imgDescription").sendKeys(description);
	}

	/**
	 * Clicks Insert button on image editor dialog
	 */
	public void clickOnInsertButton(){
		element("btn_insert").click();
		switchToDefaultContent();
		hardWait(3);
	}

	/**
	 * Verifies the image inserted is appearing on start welcome message
	 */
	public void verifyImageOnStartWelcomeMessage(String imageURL){
		switchToDefaultContent();
		isElementDisplayed("img_startWelcomeMessage");
		customAssert.customAssertTrue(element("img_startWelcomeMessage").getAttribute("src").contains(imageURL), "Assertion Failed : "
				+ " Image link is not correct");
		logMessage("Asssertion Passed : Image link is "
				+element("img_startWelcomeMessage").getAttribute("src"));
	}

	/**
	 * Clicks on Save button
	 */
	public void clickOnSaveButtonOnMCEEditor(){
		switchToDefaultContent();
		element("button_save").click();
		waitForLoaderToDisappear();
	}
	
	/**
	 * Verifies video loads on start welcome message
	 */
	public void verifyVideoOnStartWelcomeMessage(String videoUrl){
		switchToDefaultContent();
		String videoUrl_temp = videoUrl.replaceAll("\\/watch\\?v\\=", "\\/embed\\/");
		isElementDisplayed("iframe_videoPreview", videoUrl_temp);
		switchToFrame(element("iframe_videoPreview", videoUrl_temp));
		isElementDisplayed("icon_videoPlayer");
		waitForLoaderToDisappear();
		hardWait(2);
	}
	
	public void clickOnMonthViewLink(){
		scrollDown(element("lnk_monthZView"));
		((JavascriptExecutor) driver).executeScript("document.getElementsByClassName('monthView')[0].click()");
		hardWait(1);
	}
	
	public String getFirstCustomRSSLink() {
		return elements("links_customRSSLinks").get(0).getText().trim();
	}
	
	public void clickCustomRSSLink(String linkName) {
		waitScrollAndClick("link_customRSSLink", linkName);
		//element("link_customRSSLink", linkName).click();
	}

	public void verifyUpcomingAssignmentDisplayed(String assignmentName) {
		isElementDisplayed("link_assignmentUpcomingAssignmentWidget", assignmentName);
	}

	public void clickAssignmentFromUpcomingAssignmentWidget(
			String assignmentName) {
		element("link_assignmentUpcomingAssignmentWidget", assignmentName).click();
		
		// TODO Auto-generated method stub
		
	}

	public void clickCalendarUpcomingAssignmentsWidget() {
		element("btn_calendar").click();
	}

	public void clickListViewUpcomingAssignmentsWidget() {
		element("btn_listViewCalendar").click();
	}
	
	public void clickMonthViewUpcomingAssignmentsWidget() {
		element("btn_monthViewCalendar").click();
	}
}
