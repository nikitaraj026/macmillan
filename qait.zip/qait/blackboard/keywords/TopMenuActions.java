package com.qait.blackboard.keywords;

import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import com.qait.automation.getpageobjects.GetPage;

public class TopMenuActions extends GetPage{
	public TopMenuActions(WebDriver driver){
		super(driver,"TopMenu");
	}

	//Top Menu
	public void logout(){
		waitAndClick("link_logout");
		logMessage("User has been successfully logged out.");
	}
}
