package com.qait.blackboard.keywords;

import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.gdata.data.dublincore.Date;
import com.qait.automation.getpageobjects.GetPage;

public class SaplingStudentActions extends GetPage {

	public SaplingStudentActions(WebDriver driver) {
		super(driver, "SaplingStudentAction");
	}

	public void studentAttemptFlowUptoQuestion(String answer) {
		hardWait(2);
		executeJavascript("document.querySelector('.singlebutton input[value=\"Yes\"]').click()");
//		executeJavascript("window.stop();");
		logMessage("Clicked on Yes Button");
		waitAndClick("bnt_freeTrial");
		waitAndClick("btn_continueEnroll");
//		sendKeys(element("input_InstitutionName"), "Sapling Learn");
    	hardWait(3);
		element("input_InstitutionName").click();
		hardWait(3);
		sendKeys(element("input_InstitutionName"), "Sapling Learn");
		//element("input_InstitutionName").click();
		hardWait(2);
		element("input_InstitutionName").sendKeys("i");
		hardWait(3);
		//element("input_InstitutionName").click();
		//hardWait(3);
		waitAndClick("dropdown_textSaplingLearning");
		waitAndClick("btn_OK");
		hardWait(6);
		waitAndClick("link_question");
		switchToFrame("iframe_question");
		List<WebElement> list = elements("list_question");
		for (int i = 0; i < list.size(); i++) {
			wait.hardWait(4);
			String labelValue = (String) executeJavascript(
					"return document.querySelectorAll('label.sl-list-label')[" + i + "].textContent");
			if (labelValue.equals(answer)) {
				wait.hardWait(4);
				list.get(i).click();
				break;
			}
		}
		waitAndClick("btn_checkAnswer");
		closeWindow();
		changeWindow(0);
		logMessage("Clicked on Yes button");
	}

	public void verifyUserOnSaplingSide() {
		changeWindow(1);
		waitForElementToBeVisible("img_Sapling");
		isElementDisplayed("img_Sapling");
		waitForElementToBeVisible("heading_SitePolicy");
		isElementDisplayed("heading_SitePolicy");
		logMessage("User is on Sapling side now");
	}
}