package com.qait.blackboard.keywords;

//import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

//import org.sikuli.api.robot.Mouse;
//import org.sikuli.api.robot.desktop.DesktopMouse;
//import org.sikuli.api.DesktopScreenRegion;
//import org.sikuli.api.ImageTarget;
//import org.sikuli.api.ScreenRegion;
import org.testng.Assert;
import org.testng.Reporter;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.DataReadWrite;

import static com.qait.automation.utils.YamlReader.getData;
//import static com.qait.automation.utils.YamlReader.getData;

//import com.adobe.genie.executor.Genie;
//import com.adobe.genie.executor.LogConfig;
//import com.adobe.genie.executor.components.GenieButton;
//import com.adobe.genie.executor.exceptions.StepFailedException;
//import com.adobe.genie.executor.exceptions.StepTimedOutException;
//import com.adobe.genie.genieCom.SWFApp;

public class FandEPageActionsLaunchpad extends GetPage {

	String PageNumberText, nextPageNumberText, previousPageNumberText;
	String ebookTitleEdit = "ebook";
	String questionCheckBoxCss = ".questions>li:nth-child(%) input[type=checkbox]";
	JavascriptExecutor jse = (JavascriptExecutor) driver;

	// protected SWFApp app1;

	public FandEPageActionsLaunchpad(WebDriver driver) {
		super(driver, "FandEPageLaunchpad");

	}

	/*
	 * CLICK METHODS
	 */

	public void clickOnNextButton() {
		switchToDefaultContent();
		switchToFrame(element("frame_document"));
		PageNumberText = element("pageNo").getText();
		switchToDefaultContent();
		element("btn_next").click();
		logMessage("Instructor clicked Next button");
		waitForLoaderToDisappear();

	}

	public void clickOnPreviousButton() {
		switchToDefaultContent();
		// switchToFrame(element("frame_document"));
		element("btn_previous").click();
		logMessage("Instructor clicked Previous button");
		waitForLoaderToDisappear();
	}

	public void clickOnEditButton() {
		element("dropdown_edit").click();
		logMessage("Instructor clicked Edit button");
		waitForLoaderToDisappear();
	}

	private void hoverOnEditButton() {
		waitForElementToBeVisible("dropdown_edit");
		hover(element("dropdown_edit"));
		logMessage("Instructor Hover Edit button");
	}

	public void selectOptionFromEditDropDown(String option) {
		hoverOnEditButton();
		element("dropdown_option", option).click();
		logMessage("Instructor select" + option + " From Edit drop down list");
		waitForLoaderToDisappear();
	}

	public void clickOnBeginAndSubmitVideoAssignment() {
		switchToFrame(element("frame"));
		element("lnk_beginQuiz").click();
		String question1 = element("txt_ques1").getText();
		element("radiobtn_1").click();
		element("btn_submit_1").click();
		if ((element("txt_ques2").getText()) != question1) {
			switchToDefaultContent();
			element("btn_homeVideo").click();
		}

		else
			logMessage("Submit Button is not active");
	}

	/**
	 * Clicks 'Save' Button(in Basic Info Tab) and verifies Message Toast after
	 * Save.
	 */
	public void clickOnSaveButtonOnBasicInfo() {
		element("btn_saveBasicInfo").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		hardWait(5);
		logMessage("Title of Assignment changed");
	}

	public void clickOnSaveButtonOnBasicInfo2() {
		element("btn_saveBasicInfo2").click();
		hardWait(2);
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		// hardWait(2);
		logMessage("Title of Assignment changed");
	}

	// Clicks 'Save' Button(in Settings Tab) and verifies Message Toast after
	// Save.
	public void clickOnSaveButtonOnSettingsPage() {
		waitForElementToBeVisible("btn_save");
		element("btn_save").click();
		waitForMsgToastToAppearAndDisappear();
		logMessage("Save Button on Settings page is clicked");
		hardWait(1);
	}

	public int getDocumentCollectionFrameSize() {
		waitForElementToBeVisible("iframe_easyXDMDefault");
		int height = element("iframe_easyXDMDefault").getSize().getHeight();
		return height;
	}

	// Clicks on 'Done Editing' Button
	public void clickOnDoneEditingButton() {
		switchToDefaultContent();
		// waitForLoaderToDisappear();
		waitAndClick("btn_done_editing_fne");
		handleAlert();
		logMessage("User Clicked on Done button");
		// waitForLoaderToDisappear();
	}

	// Clicks 'Assign' Button(in Assignment Tab)
	public void clickAssignButtonFromAssignmentTab() {
		waitForElementToBeVisible("btn_assignInAssignmentTab");
		element("btn_assignInAssignmentTab").click();
		handleAlert();
		waitForLoaderToDisappear();
		hardWait(2);// wait till unassign button appeared
		logMessage("Clicked 'Assign' Button from Assignment Settings");
		waitForElementToBeVisible("btn_unassignInAssignmentTab");
	}

	/*
	 * Clicks on Unassign button in Assignment Setting tab
	 */
	public void clicksUnassignButtonInAssignmenttab() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		wait.waitForElementsToBeVisible(elements("btn_unassignInAssignmentTab"));
		js.executeScript("document.getElementById('btnUnassign').click();");
		logMessage("User clicks on 'Enter Course' button on Welcome Page");
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

	}

	// Clicks 'Hide Grade from student until due date has passed'
	public void clickHideGradeSetting() {
		waitForElementToBeVisible("chkBox_hideGrade");
		element("chkBox_hideGrade").click();
		logMessage("Clicked Hide Grade Checkbox");
	}

	// Clicks 'Assignment' Tab
	public void clickAssignmentTab() {
		waitForElementToBeVisible("btn_assignmentTab");
		element("btn_assignmentTab").click();
		waitForLoaderToDisappear();
		logMessage("User clicked on Assignment Tab");
		waitForElementToBeVisible("txt_dueDateAndTime");
	}

	// Clicks 'Questions' Tab(for Quiz type of Assignments)
	public void clickQuestionsTab() {
		waitForElementToBeVisible("btn_questionsTab");
		element("btn_questionsTab").click();
		hardWait(2);
		waitForLoaderToDisappear();
		logMessage("User clicked on Questions Tab");
	}

	// Clicks 'Settings' tab
	public void clickSettingsTab() {
		waitForElementToBeVisible("btn_settingsTab");
		element("btn_settingsTab").click();
		waitForLoaderToDisappear();
		logMessage("User clicked on Settings Tab");
		// waitForElementToBeVisible(("txt_sectionTitle"));
	}

	/**
	 * Clicks on 'Home' Button at the top-left of FandE Page
	 * 
	 */
	public void clickOnHomeButton() {
		switchToDefaultContent();
		waitScrollAndClick("btn_home");
		logMessage("User Clicked on Home button");
	}

	public void clickOnImage() {
		switchToDefaultContent();
		switchToFrame(element("frame_document"));
		hardWait(2);
		waitAndScrollToElement("img_InEbook");
		waitForElementToBeVisible("img_InEbook");
		new Actions(driver).doubleClick(element("img_InEbook")).build().perform();
		switchToDefaultContent();
		logMessage("User clicked on Image on ebook");
	}

	// Selects 'Chapter 1' Link from list of Question Bank(under Questions Tab)
	public void clickChapterOneFromQuestionBank(String chapterNumber) {
		waitForElementToBeVisible("btn_chapter1QuestionBank", chapterNumber);
		element("btn_chapter1QuestionBank", chapterNumber).click();
		logMessage("Instrutor clicks on " + chapterNumber + " from Question Bank");
		waitForLoaderToDisappear();
	}

	// Selects 'Test Bank 1' link from 'Chapter 1'(under Questions Tab)
	public void clickTestBankOneFromChapterOne(String selectQuestionFrom) {
		hardWait(1);
		waitForLoaderToDisappear();
		hardWait(3);
		waitForElementToBeVisible("btn_testBank1Chapter1", selectQuestionFrom);
		// Actions act=new Actions(driver);
		// act.click(element("btn_testBank1Chapter1",
		// selectQuestionFrom)).build().perform();
		// Actions ob = new Actions(driver);
		// ob.click(element("btn_testBank1Chapter1", selectQuestionFrom));
		// Action action = ob.build();
		// action.perform();
		//element("btn_testBank1Chapter1", selectQuestionFrom).click();
		waitAndClick("btn_testBank1Chapter1", selectQuestionFrom);
		logMessage("Instrutor clicks on " + selectQuestionFrom + " from Chapter 1");
		waitForLoaderToDisappear();
	}

	// Selects 1st link from 'Chapter 1'(under Questions Tab)
	public void clickOnAnyExerciseFromChapterOne() {
		String txtExercise1 = element("lnk_exercise1").getText();
		element("lnk_exercise1").click();
		logMessage("Instrutor clicks on " + txtExercise1 + " from Chapter 1");
		waitForLoaderToDisappear();
	}

	/**
	 * Clicks 'Add' Button to add selected Questions for Quiz(under Questions
	 * Tab)
	 * 
	 */
	public void clickAddButtonInQuestions() {
		waitForElementToBeVisible("btn_add");
		element("btn_add").click();
		logMessage("User clicks on 'Add' button to add the question to Assignment");
		waitForLoaderToDisappear();
	}

	// Clicks 'New Thread' Button(for Discussion Board type Assignment)
	public void clickNewThreadButton() {
		waitForElementToBeVisible("btn_newThread");
		element("btn_newThread").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Submits a new Thread by clicking 'Post' Button (for Discussion Board type
	 * Assignment)
	 * 
	 */
	public void clickPostNewThreadButton(String title) {
		waitForElementToBeVisible("btn_postNewThread");
		element("btn_postNewThread").click();
		hardWait(10);
		waitForElementToBeVisible("txt_titleThread", title);
	}

	/**
	 * Student starts Quiz by clicking 'Start the Quiz' Button(for Quiz type
	 * Assignments)
	 * 
	 */
	public void clickStartTheQuizButton() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_home");
		hardWait(5);
		waitForElementToBeVisible("btn_startTheQuiz");
		isElementDisplayed("btn_startTheQuiz");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementsByClassName(\"start-quiz\")[0].click();");
		waitForElementToDisappear("btn_startTheQuiz");
		logMessage("User Clicked on 'Start the Quiz' button");
		waitForLoaderToDisappear();
	}

	public void clickStartQuizButton() {
		waitAndClick("btn_startTheQuiz");
	}

	public void startQuizButtonisDisappear() {
		switchToDefaultContent();
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_home");
		verifyElementNotDisplayed("btn_startTheQuiz", "");
	}

	/**
	 * Student verifies text editor after clicking 'Start the Quiz' Button(for
	 * Quiz type Assignments)
	 * 
	 */
	public void textEditorDisplayed() {
		Assert.assertTrue(isElementDisplayed("lnk_editor"), "Text editor for Essay Question is not Displayed!");
	}

	/**
	 * Student starts Homework by clicking 'Start the Homework' Button(for
	 * Homework type Assignments)
	 * 
	 */
	public void clickStartTheHomeworkButton() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_startTheHomework");
		element("btn_startTheHomework").click();
		logMessage("User Clicked on 'Start the Homework' button");
		waitForLoaderToDisappear();
	}

	public void clickStartNextQuestion() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_startNextQuestion");
		element("btn_startNextQuestion").click();
		logMessage("User Clicked on 'Start# ' button");
		waitForLoaderToDisappear();
	}

	// Submits the Quiz/Homework
	public void clickSubmit() {
		waitForElementToBeVisible("btn_submitQuiz");
		scrollDown(element("btn_submitQuiz"));
		click(element("btn_submitQuiz"));
	}

	/**
	 * Student save the Quiz by clicking Save button
	 * 
	 */
	private void _clickSave() {
		waitForElementToBeVisible("btn_saveQuiz");
		element("btn_saveQuiz").click();
	}

	/**
	 * Clicks OK on Save dialog
	 * 
	 */
	public void clickOkOnSaveDialog() {
		waitForElementToBeVisible("saveDialogTitle");
		element("btn_OkSaveQuiz").click();
		waitForLoaderToDisappear();
	}

	// Clicks 'Close' Button on 'History of Quiz/Homework' Section
	public void clickDoneButton() {
		switchToDefaultContent();
		waitAndClick("btn_done_fne");
		handleAlert();
		logMessage("User Clicked on Done button");
	}

	public void clickSubmitFileButtonForDropbox() {
		waitForElementToBeVisible("btn_submitFileDropbox");
		element("btn_submitFileDropbox").click();
		waitForLoaderToDisappear();
	}

	public void clickSubmitButtonOnDropboxModal() {
		waitForElementToBeVisible("btn_submitDropboxModal");
		element("btn_submitDropboxModal").click();
		hardWait(3);
		waitForLoaderToDisappear();
	}

	public void clickAssignButtonInHeader() {
		wait.waitForElementToBeVisible(element("btn_assign"));
		element("btn_assign").click();
		waitForLoaderToDisappear();

	}

	/**
	 * VERIFICATION METHODS
	 * 
	 */

	public void verifyThreadNotVisible(String threadTitle) {
		switchToCourseContentFrame();
		verifyElementNotDisplayed("txt_titleThread", threadTitle, "");
		switchToDefaultContent();
	}

	public void verifyThreadVisible(String threadTitle) {
		switchToCourseContentFrame();
		isElementDisplayed("txt_titleThread", threadTitle);
		switchToDefaultContent();
	}

	public void verifyHeaderOfFnePage(String assignmentName, String points, String dueDate) {
		isElementDisplayed("txt_fneTitle");
		customAssert.customAssertEquals(element("txt_fneTitle").getText().trim(), assignmentName,
				"Assertion failed: Title on fne matches the assignment name");
		isElementDisplayed("btn_results");
		isElementDisplayed("btn_home1");
		isElementDisplayed("dropdown_edit");
		isElementDisplayed("txt_achievedPoints");
		customAssert.customAssertEquals(element("txt_achievedPoints").getText().trim(), points + " pts",
				"Assertion failed: Assignment points correct");
		isElementDisplayed("calender_dueDateDisplay");
		customAssert.customAssertEquals(element("calender_dueDateDisplay").getText().trim(), dueDate,
				"Assertion failed: Due date correct");
	}

	public void verifyBodyOfDiscussionBoardAssignmentOnFnePage(String assignmentName) {
		isElementDisplayed("txt_contentTitle");
		customAssert.customAssertEquals(element("txt_contentTitle").getText().trim(), assignmentName,
				"Assertion failed: Assignment name in fne is correct");
		switchToCourseContentFrame();
		isElementDisplayed("btn_newThread");
		isElementDisplayed("drpdown_orderBy");
		isElementDisplayed("link_expandAll");
		isElementDisplayed("link_collapseAll");
		isElementDisplayed("chkbox_newMsgOnly");
		switchToDefaultContent();
	}

	public void verifyEbookOpenInFandE() {
		waitForLoaderToDisappear();
		isElementDisplayed("content_At_Fne");
		isElementDisplayed("btn_previous");
		isElementDisplayed("btn_next");
	}

	public void navigateNextTillEndOfChapter() {
		while (!(element("btn_next").getAttribute("class").contains("disabled-navigation-button"))) {
			clickOnNextButton();
			switchToDefaultContent();
			verifyInstructorOnNextPage();
		}
	}

	public void navigateBackTillStartOfChapter() {
		while (!(element("btn_previous").getAttribute("class").contains("disabled-navigation-button"))) {
			clickOnPreviousButton();
			switchToDefaultContent();
			verifyInstructorOnPreviousPage();
		}
	}

	public void verifyInstructorOnNextPage() {
		switchToFrame(element("frame_document"));
		nextPageNumberText = element("pageNo").getText();
		logMessage("Current Page Number is : " + nextPageNumberText);
		customAssert.customAssertTrue(!nextPageNumberText.equals(PageNumberText), "Assertion Failed : Page tittle "
				+ PageNumberText + " is equal to " + nextPageNumberText);
		logMessage("Instructor navigated to next page");
		switchToDefaultContent();
	}

	public void verifyInstructorOnPreviousPage() {
		switchToFrame(element("frame_document"));
		previousPageNumberText = element("pageNo").getText();
		customAssert.customAssertTrue(previousPageNumberText.equals(PageNumberText), "Assertion Failed : Page number"
				+ PageNumberText + "is not equal to " + previousPageNumberText);
		logMessage("Instructor navigated to previous page");
		switchToDefaultContent();
	}

	public void verifyImageOpenInNewWindow() {
		changeWindow(1);
		isElementDisplayed("img_inNewWindow");
		closeWindow();
		changeWindow(0);
	}

	public void verifyGlossary() {
		switchToFrame(element("frame_document"));
		waitForElementToBeVisible("glossaryTerm");
		element("glossaryTerm").click();
		isElementDisplayed("popup_glossary");
		element("popup_close").click();
		switchToDefaultContent();
	}

	public void verifyInteractiveElement() {
		waitForElementToBeVisible("btn_home");
		customAssert.customAssertTrue(element("txt_fneTitle").getText().contains("Interactive"),
				"Assertion Failed : FnE Page title does not contain 'Interactive'");
		logMessage("Interactive Elememnt open in FnE Page");
		switchToFrame(element("frame_document"));
		isElementDisplayed("interactive_element");
		switchToDefaultContent();
	}

	/**
	 * Verifies scoring achieved and Tick image displayed for the assignment in
	 * the FandE Header section
	 * 
	 */
	public void verifyScoringIsDisplayed(String score) {
		// hardWait(4);// wait for displaying achievedPoints
		// String expectedScoring = score + " / " + score + " pts";
		// verifyTextOfElementIsCorrect("txt_achievedPoints", expectedScoring);
		// logMessage("Assertion Passed : Submitted Item's scoring is correctly displayed on FandE Page.");

	}

	public void verifyFileSubmittedOnDropbox(String filename) {
		waitForElementToBeVisible("link_submittedFileNameDropbox", filename.split("[.]")[0]);
	}

	public void verifySubcontentActivity(String subContent) {
		waitForLoaderToDisappear();
		switchToFrame(element("iframe_contentActivities"));
		element("txt_bannerActivityTitle").isDisplayed();
		customAssert.customAssertTrue(element("txt_bannerActivityTitle").getText().equalsIgnoreCase(subContent),
				"Wrong subcontent is opened in FandE");
		switchToDefaultContent();
		// verifyFlashContent();
		// intializingGenie();
		// verifyFlashContentUsingGenie();
	}

	public void verifyQuizPoints() {
		String point = getData("Quiz.points");
		customAssert.customAssertTrue(element("txt_achievedPoints").getText().contains(point),
				"Points set for the quiz by instructor does not match the points on Student console");
	}

	public void verifyTimeLimit(String timelimit) {
		customAssert.customAssertTrue(element("txt_timeLimitStringOnStudentPage").getText().contains(timelimit),
				"Time set by instructor for quiz mismatches time of quiz on student console");
	}

	public void verifyScoredAttempt(String attempt) {
		String attempt_temp = attempt.toLowerCase();
		customAssert.customAssertTrue(element("txt_scoredAttemptStringOnStudentPage").getText().contains(attempt_temp),
				"Scored attempt set for the quiz by instructor mismatches attempt on Student console");
	}

	public void verifyQuizAttempts() {
		if (elements("btn_startTheQuiz").size() != 0) {
			customAssert.customAssertTrue(false,
					"Assertion Failed : Start the Quiz button is displayed even after attempts are exhausted");
		}
		logMessage("Assertion Passed: Start the Quiz button is not displayed");
	}

	/**
	 * Verify Student is on FandE page
	 * 
	 */
	public void verifyStudentIsOnQuizStartPage() {
		hardWait(5);
		waitForElementToBeVisible("btn_startTheQuiz");
		element("btn_startTheQuiz").isDisplayed();
		element("txt_achievedPoints").isDisplayed();
		element("txt_fneTitle").isDisplayed();
		element("heading_policies").isDisplayed();
		logMessage("Verified that Student is on FandE page");
	}

	/**
	 * OTHER METHODS
	 * 
	 */

	/**
	 * Fills Title Field(in Basic Info Tab)
	 * 
	 * @param newTitle
	 * 
	 */
	public void fillTitleOnBasicInfo(String newTitle) {
		waitForLoaderToDisappear();
		hardWait(1);
		waitForElementToBeVisible("inp_title");
		element("inp_title").clear();
		element("inp_title").sendKeys(newTitle);
	}

	public String changeTitleForEbook() {
		fillText("inp_ebookTitle", ebookTitleEdit);
		element("btn_save").click();
		hardWait(1);
		waitForMsgToastToDisappear();
		logMessage("Ebook info changed");
		return ebookTitleEdit;
	}

	/**
	 * Chooses a date which is not more than 7 days from current date
	 */
	public void selectOneWeekOrLessDueDateInDatePicker(String currentDate) {
		int currDate = Integer.parseInt(currentDate);
		String selectDate = "";
		if (currDate > 27) {
			waitForElementToBeVisible("datePicker_goNext");
			element("datePicker_goNext").click();
			selectDate = "1";
			waitForElementToBeVisible("datePicker_date", "1");
			element("datePicker_date", "1").click();
		} else {
			selectDate = String.valueOf(currDate + 1);
		}
		waitForElementToBeVisible("datePicker_date", selectDate);
		element("datePicker_date", selectDate).click();

		logMessage("Date selected from Calendar : " + selectDate);
	}

	/**
	 * Chooses the specified date from next month
	 */
	public void selectDateInDatePicker(String date) {
		waitForElementToBeVisible("datePicker_goNext");
		element("datePicker_goNext").click();
		waitForElementToBeVisible("datePicker_date", date);
		element("datePicker_date", date).click();
		logMessage("Date selected from Calendar: " + date);
	}

	/**
	 * Return selected Date & Month
	 * 
	 * @return date
	 */
	public String selectDateInDatePickerAndReturnDate() {
		waitForElementToBeVisible("datePicker_goNext");
		element("datePicker_goNext").click();
		String date = element("datePicker_date", "25").getText();
		waitForElementToBeVisible("datePicker_date");
		element("datePicker_date").click();
		return date;
	}

	/**
	 * Method which selects Date from previous month for Date picker field
	 * 
	 */
	public void selectDateFromPreviousMonth(String date) {
		waitForElementToBeVisible("datePicker_goPrev");
		element("datePicker_goPrev").click();
		waitForElementToBeVisible("datePicker_date", date);
		element("datePicker_date", date).click();
	}

	/**
	 * Fills Grade Points input field(in Assignment Tab)
	 * 
	 * @param gradePoints
	 */
	public void fillGradePointsForAssignment(String gradePoints) {
		waitForElementToBeVisible("txtinput_gradePoints");
		fillText("txtinput_gradePoints", gradePoints);
	}

	/**
	 * Verifies Grade Points input field is correct(in Assignment Tab)
	 */
	public void verifyGradePointsTextFieldForAssignment(String expectedGradePts) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String actualValue = js.executeScript("return document.getElementById('txtGradePoints').value;").toString();
		customAssert.customAssertEquals(actualValue, expectedGradePts,
				"Assertion Failed : Grade Points Text Field is not correct");
	}

	/**
	 * Verifies Due Date input field is correct(in Assignment Tab)
	 */
	public void verifyDueDateTextFieldForAssignment(String expectedDate) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String actualValue = js.executeScript("return document.getElementById('settingsAssignDueDate').value;")
				.toString();
		customAssert.customAssertEquals(actualValue, expectedDate,
				"Assertion Failed : Due Date Text Field is not correct");
	}

	/**
	 * Verifies that the FandE Title(next to 'Home' Button) is correct in Header
	 * section
	 * 
	 */
	public void waitForPageHeaderToBeDisplayed(String pageTitle) {
		waitForElementToBeVisible("txt_fneTitle");
		String title = element("txt_fneTitle").getText();
		customAssert.customAssertEquals(title, pageTitle, "Assertion Failed : Page Header '" + pageTitle
				+ "' is not displayed");
		logMessage("Assertion Passed : Page Header '" + pageTitle + "' is displayed");
	}

	// Verifies that the Content Title is correct for FandE Page
	public void waitForPageToBeDisplayed(String pageTitle) {
		waitForElementToBeVisible("txt_contentTitle");
		String title = element("txt_contentTitle").getText();
		customAssert.customAssertEquals(title, pageTitle, "Assertion Failed : Page '" + pageTitle
				+ "' is not displayed");
		logMessage("Assertion Passed : Page '" + pageTitle + "' is displayed");
	}

	// Checks if 'Questions' Tab is available in Assignment's FandE page
	public Boolean checkQuestionsTabVisible() {
		if (elements("btn_questionsTab").size() != 0)
			return true;
		else
			return false;
	}

	/**
	 * Selects First Question Checkbox from the Questions List available(under
	 * Questions Tab)
	 * 
	 */
	public void checkFirstQuestionFromQuestionsAvailable() {
		WebElement elem = driver.findElement(By.cssSelector(questionCheckBoxCss.replaceAll("%", String.valueOf(1))));
		scrollDown(elem);
		elem.click();
		logMessage("1st question is selected from all the available questions");
	}

	/**
	 * Selects Nth Question Checkbox from the Questions List available(under
	 * Questions Tab)
	 */
	public void checkNthQuestionFromQuestionsAvailable(int questionNumber) {
		WebElement elem = driver.findElement(By.cssSelector(questionCheckBoxCss.replaceAll("%",
				String.valueOf(questionNumber))));
		elem.click();
	}

	public void verifyQuestionAddedToAssignment() {
		isElementDisplayed("link_previewForAddedQuestion");
		logMessage("Assertion Passed : Question Added to Question pool");
	}

	// Fills Url input on Basic Info Tab(For Link type of Assignment)
	public void fillUrlOnBasicInfo(String url) {
		waitForElementToBeVisible("txtinput_linkUrl");
		fillText("txtinput_linkUrl", url);
	}

	// Fills Title input for a new Thread(for Discussion Board type Assignment)
	public void fillTitleForThread(String title) {
		waitForElementToBeVisible("txtinput_titleNewThread");
		fillText("txtinput_titleNewThread", title);
	}

	// Checks if the Answer of Quiz/Homework was attempted correctly or not
	public boolean isCorrectlyAnswered() {
		switchToDefaultContent();
		hardWait(2);
		switchToFrame(element("iframe_easyXDMDefault"));
		// switchToFrame(element("iframe_contentBody"));
		// switchToFrame(element("iframe_courseContentFrame"));
		if (elements("img_crossWrongAnswer").size() != 0) {
			logMessage("Found that the Quiz/Homework was attempted incorrectly");
			return false;
		} else {
			logMessage("Found that the Quiz/Homework was attempted correctly");
			return true;
		}
	}

	/*
	 * Returns the Answer by finding the option corresponding to which Tick
	 * image is displayed
	 */
	public String getCorrectAnswerOfQuestion() {
		waitForElementToBeVisible("txt_correctAnswerOfQuestion");
		logMessage("Storing correct Answer of Question...");
		return element("txt_correctAnswerOfQuestion").getText();
	}

	// Waits for Quiz Question to load
	public void waitForQuestionToLoad() {
		waitForElementToBeVisible("txt_startQuizTime");
	}

	// Selects Option 1 radiobutton for Quiz/Homework Question's Answer
	public void selectOptionOneForQuestion() {
		waitForElementToBeVisible("radio_option1");
		element("radio_option1").click();
	}

	// Selects Correct Option for Quiz/Homework Question
	public void selectCorrectOptionOfQuestion(String correctAnswer) {
		waitForElementToBeVisible("radio_correctOption", correctAnswer);
		element("radio_correctOption", correctAnswer).click();
	}

	// Clicks Yes in Confirm Dialog Box
	public void submitYesInConfirmDialogBox() {
		waitForElementToBeVisible("confirmDialogTitle");
		waitAndClick("btn_yesConfirmDialog");
		waitForLoaderToDisappear();
	}

	// Waits till Quiz/Homework is successfully submitted
	public void waitTillSuccessullySubmitted() {
		waitForMsgToastToDisappear();
		logMessage("Quiz or Homework was successfully submitted");
		waitForLoaderToDisappear();
	}

	/**
	 * Waits till Quiz/Homework is saved successfully
	 */
	public void waitTillSavedSuccessfully() {
		waitForMsgToastToDisappear();
		logMessage("Quiz or Homework was successfully saved");
		waitForLoaderToDisappear();
	}

	/**
	 * get question text from quiz question for verify randomized question
	 * 
	 * @param numberOfQuestion
	 * @return
	 */
	public List<String> getQuestiontextFromQuiz(String numberOfQuestionAtPool) {
		List<String> questionText = new ArrayList<String>();
		int numberOfQuestion = elements("txt_quizQuestionText").size();
		List<WebElement> questionTexts = elements("txt_quizQuestionText");
		for (int i = 0; i < numberOfQuestion; i++) {
			questionText.add(i, questionTexts.get(i).getText());
		}
		customAssert.customAssertEquals(Integer.parseInt(numberOfQuestionAtPool), numberOfQuestion,
				"number of question at Quiz for student is not equal from assign by instructor");
		logMessage("Number of Question on Quiz page are verified");
		return questionText;
	}

	public void verifyQuestionAreRandamized(List<String> actualString) {
		@SuppressWarnings("unused")
		int numberOfQuestion = elements("txt_quizQuestionText").size();
		List<WebElement> questionTexts = elements("txt_quizQuestionText");
		customAssert.customAssertFalse(questionTexts.equals(actualString),
				"Assertion failed : Questions are in same order");
		// for(int i = 0; i< numberOfQuestion; i++) {
		// customAssert.customAssertFalse(actualString.get(i).equals(questionTexts.get(i).getText()),
		// "randomized question are not sort");
		// }
		logMessage("Question are Randomized and verified ");
	}

	/**
	 * Start Quiz. Attempt one Question of Quiz. Select Option 1 as Answer.
	 * Submit the Quiz
	 * 
	 * @param numberOfQuestion
	 * @return
	 */
	public List<String> attemptQuizAndClickSubmit(String numberOfQuestion) {
		switchToTopWindow();
		clickStartTheQuizButton();
		wait.hardWait(3);
		switchToCourseContentFrame();
		selectOptionOneForQuestion();
		List<String> questionList = getQuestiontextFromQuiz(numberOfQuestion);
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment");
		return questionList;
	}

	public void attemptQuizAndClickSubmit() {
		switchToTopWindow();
		clickStartTheQuizButton();
		hardWait(3);
		switchToCourseContentFrame();
		selectOptionOneForQuestion();
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment");
	}

	public void clickOnViewSubmission() {
		waitForElementToBeVisible("link_viewSubmission");
		element("link_viewSubmission").click();
		logMessage("Clicked on View Submission Link");
	}

	public void attemptTimeLimitQuizAndClickSubmit(String timeLimit, List<String> questionList) {
		switchToTopWindow();
		clickStartTheQuizButton();
		wait.hardWait(3);
		switchToCourseContentFrame();
		selectOptionOneForQuestion();
		verifyQuestionAreRandamized(questionList);
		verifyTimeLimitOnQuiz(timeLimit);
		switchToTopWindow();
		// switchToCourseContentFrame();
		// clickSubmit();
		// submitYesInConfirmDialogBox();
		// switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment");
	}

	public void verifyTimeLimitOnQuiz(String timeLimit) {
		wait.setTimeout(Integer.parseInt(timeLimit) * 60);
		System.out.println(wait.timeout);
		isElementDisplayed("span_remainingTimeOnQuiz");
		waitForElementToBeVisible("btn_doneQuiz");
		wait.resetImplicitTimeout(wait.getTimeout());
	}

	/*
	 * Start Quiz. Submit the Quiz without selecting any answer
	 */
	public void attemptQuizAndClickSubmitWithoutSelectingAnyOption() {
		switchToTopWindow();
		clickStartTheQuizButton();
		wait.hardWait(3);
		switchToCourseContentFrame();
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment");
		hardWait(2);
	}

	/**
	 * Start Quiz. Attempt Question of Quiz Select option 1 as Answer. Save the
	 * Quiz
	 */
	public void attemptQuizAndClickSave() {
		switchToTopWindow();
		clickStartTheQuizButton();
		switchToCourseContentFrame();
		selectOptionOneForQuestion();
		_clickSave();
		// clickOkOnSaveDialog();
		// clickDoneButtonAfterSaveQuiz();
		handleAlert();
		waitForMsgToastToDisappear();
		switchToTopWindow();
		waitTillSavedSuccessfully();
		logMessage("Attempted Quiz Assignment and Save the Quiz");
	}

	public void clickDoneButtonAfterSaveQuiz() {
		element("btn_doneQuiz").click();
	}

	/*
	 * Start Quiz. Attempt one Question of Quiz. Answer correctly. Submit the
	 * Quiz.
	 */
	public void attemptQuizCorrectly(String correctAnswer) {
		switchToTopWindow();
		clickStartTheQuizButton();
		switchToCourseContentFrame();
		waitForQuestionToLoad();
		selectCorrectOptionOfQuestion(correctAnswer);
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment correctly");
		//switchToDefaultContent();
		//hardWait(2);
		//switchToFrame(element("iframe_easyXDMDefault"));
	}

	/*
	 * Start Homework. Attempt one Question of Homework. Select Option 1 as
	 * Answer. Submit Homework
	 */
	public void attemptHomework() {
		switchToTopWindow();
		clickStartTheHomeworkButton();
		switchToCourseContentFrame();
		waitForQuestionToLoad();
		selectOptionOneForQuestion();
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Homework Assignment");
	}

	/*
	 * Start Homework. Attempt one Question of Homework. Answer correctly.
	 * Submit Homework.
	 */
	public void attemptHomeworkCorrectly(String correctAnswer) {
		switchToTopWindow();
		clickStartTheHomeworkButton();
		switchToCourseContentFrame();
		waitForQuestionToLoad();
		selectCorrectOptionOfQuestion(correctAnswer);
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Homework Assignment correctly");
	}

	/*
	 * Switches to easyXDMDefault Frame then to Content Body Frame and then to
	 * Course Content Frame
	 */
	public void switchToCourseContentFrame() {
		switchToDefaultContent();
		hardWait(2);
		switchToFrame(element("iframe_easyXDMDefault"));
		switchToFrame(element("iframe_contentBody"));
		switchToFrame(element("iframe_courseContentFrame"));
	}

	// Switches to Top Window and out of Frames
	public void switchToTopWindow() {
		switchToDefaultContent();
	}

	// Switches to Top Window and out of Frames
	public void switchToDocumentBodyFrame() {
		switchToDefaultContent();
		switchToFrame(element("iframe_documentBodyFrame"));
	}

	// Switches to easyXDMDefault Frame
	public void switchToDefaultFrame() {
		switchToDefaultContent();
		hardWait(5);
		waitForElementToBeVisible("iframe_easyXDMDefault");
		switchToFrame(element("iframe_easyXDMDefault"));
	}

	public void postNewThreadOnDiscussionBoard(String title, boolean checkVisibleToEntireClassCheckbox) {
		hardWait(5);
		switchToCourseContentFrame();
		clickNewThreadButton();
		fillTitleForThread(title);
		if (checkVisibleToEntireClassCheckbox)
			element("chkbox_visibleToEntireClass").click();
		clickPostNewThreadButton(title);
		switchToDefaultContent();
	}

	public void enterFilepathToUpload(String filename, String locator) {
		waitForElementToBeVisible(locator);
		String currentDir = System.getProperty("user.dir");
		if (System.getProperty("os.name").contains("Windows")) {
			element(locator).sendKeys(currentDir + "\\src\\test\\resources\\testdata\\LAUNCHPAD\\" + filename);
		} else {
			element(locator).sendKeys(currentDir + "/src/test/resources/testdata/LAUNCHPAD/" + filename);
		}
	}

	public void verifySizeOfFile() {
		customAssert.customAssertEquals(element("txt_sizeOfFile").getText(), "(0Kb)",
				"Assertion failed: Size of file is correct");
		logMessage("Assertion passed: Size of file is correct");
	}

	public void submitFileForDropboxAssignment(String filename) {
		clickSubmitFileButtonForDropbox();
		enterFilepathToUpload(filename, "txtinput_fileBrowseDropbox");
		clickSubmitButtonOnDropboxModal();
		verifyFileSubmittedOnDropbox(filename);
	}

	// Changes time limit of Quiz
	public void changeTimeSetting(String timelimit) {
		waitForElementToBeVisible("inp_timeLimit");
		hardWait(3);
		fillText("inp_timeLimit", timelimit);
	}

	// Changes 'randomize question' setting of a quiz
	public void changeQuizSettingsRandomize() {
		waitForElementToBeVisible("chkBox_randomizeQuestion");
		element("chkBox_randomizeQuestion").click();
	}

	// Changes 'Question attempts' of a quiz
	public void changeQuizSettingQuestionAttempt(int index) {
		Select select = new Select(element("select_numberOfAttempts"));
		select.selectByIndex(index);
	}

	public void changeScoredAttempts(String attempt) {
		selectProvidedTextFromDropDown(element("select_scoredAttempts"), attempt);
	}

	/**
	 * Selects specific option from Drop down on Assignment/Setting tab
	 * 
	 * @param text
	 */
	public void selectSettingsForIndividual(String text) {
		System.out.println("Text to be selected from Setting Dropdown:" + text);
		selectProvidedTextFromDropDown(element("dropdwn_settingFor"), text);
		waitForLoaderToDisappear();
	}

	/**
	 * Fill details for enrolled student and clicks on "Add" button
	 * 
	 * @param username
	 */
	public void fillDetailsForIndividual(String username) {
		waitForElementToBeVisible("txtinput_addIndividual");
		fillText("txtinput_addIndividual", username);
		element("drpdown_individualName").isDisplayed();
		element("drpdown_individualName").click();
		element("btn_addSearchPopup").click();
	}

	public void createCategoryFromAssignmentTab(String categoryName) {
		selectProvidedTextFromDropDown(element("drpdown_gradebookCategory"), "Create new category");
		waitForElementToBeVisible("input_category");
		element("input_category").sendKeys(categoryName);
		element("btn_addCategory").click();
		waitForLoaderToDisappear();
	}

	public void selectCategoryFromAssignmentTab(String categoryName) {
		selectProvidedTextFromDropDown(element("drpdown_gradebookCategory"), categoryName);
	}

	public void verifyCategorySelected(String categoryName) {
		customAssert.customAssertEquals(element("txt_selectedCategory").getText(), categoryName,
				"Assertion failed : Category does not match");
		logMessage("Assertion passed : Selected category matches with the created category");
	}

	/**
	 * Adds bulk question in Quiz
	 */
	public void addBulkQuestion() {
		waitForElementToBeVisible("drpdown_selectMenu");
		element("drpdown_selectMenu").isDisplayed();
		element("drpdown_selectMenu").click();
		waitForElementToBeVisible("lnk_AllInSelectMenu");
		element("lnk_AllInSelectMenu").click();
		waitForElementToBeVisible("btn_add");
		element("btn_add").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Removes all question from the quiz
	 */
	public void removeAllQuestion() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForElementToBeVisible("chkbox_removeAllQuestion");
		hardWait(2);
		executeJavascript("document.getElementsByName('selectall')[0].click();");
		clickRemoveButtonInQuestionsTab();
	}

	public void clickRemoveButtonInQuestionsTab() {
		hardWait(2);
		waitForElementToBeVisible("btn_remove");
		executeJavascript("document.getElementsByClassName('remove-question')[0].click();");
		waitForElementToBeVisible("btn_confirmationRemove");
		element("btn_confirmationRemove").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void setDueDateAndScoreThenClickAssignInAssignmentTab(String assignmentScore, String date) {
		selectDateInDatePicker(date);
		fillGradePointsForAssignment(assignmentScore);
		clickAssignButtonFromAssignmentTab();
	}

	/**
	 * Clicks Resume the Quiz button
	 * 
	 * @param assignmentScore
	 * @return achievedScore
	 */
	public String clickResumeTheQuizAndSubmitQuiz(String assignmentScore) {
		String achievedScore = "0";
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_resumeTheQuiz");
		element("btn_resumeTheQuiz").click();
		waitForLoaderToDisappear();
		switchToCourseContentFrame();
		// waitForQuestionToLoad();
		selectOptionOneForQuestion();
		clickSubmit();
		submitYesInConfirmDialogBox();
		waitTillSuccessullySubmitted();
		switchToDefaultFrame();
		if (isCorrectlyAnswered()) {
			achievedScore = assignmentScore;
		}
		switchToDefaultContent();
		logMessage("Attempted Quiz Assignment");
		return achievedScore;
	}

	public void selectChapterText() {
		switchToDefaultContent();
		switchToDocumentBodyFrame();
		isElementDisplayed("txt_ebookTitle1");
		WebElement elem = element("txt_ebookTitle1");

		Actions act = new Actions(driver);

		if (browser.contains("Chrome")) {
			act.doubleClick(elem).build().perform();
		} else {
			act.clickAndHold(elem).build().perform();
			act.release().perform();
			act.moveToElement(elem, 0, 0).build().perform();
			act.release().build().perform();
		}

		// act.doubleClick(elem).build().perform();

		// act.clickAndHold(elem).build().perform();
		// act.release().perform();
		// act.clickAndHold(elem).build().perform();
		// act.moveToElement(elem, 0, 0).build().perform();
		// act.release().build().perform();
		// act.clickAndHold(elem).build().perform();
		// act.release().perform();
		hardWait(3);
		switchToDefaultContent();

		// System.out.println(element("txt_ebookTitle").getLocation());
		// System.out.println(element("txt_ebookTitle").getSize());
		// act.moveToElement(element("txt_ebookTitle"),0,0).build().perform();
		// act.moveByOffset(0, 0).build().perform();
		// act.doubleClick().build().perform();

	}

	public void selectPartialChapterText() {
		switchToDefaultContent();
		switchToDocumentBodyFrame();
		WebElement elem = element("txt_ebookTitle");
		Actions act = new Actions(driver);
		act.clickAndHold(elem).build().perform();
		act.release().perform();
		act.clickAndHold(elem).build().perform();
		act.moveToElement(elem, 0, 50).build().perform();
		act.release().build().perform();
	}

	public void verifyHeadingDisplayed() {
		isElementDisplayed("txt_fneTitle");
	}

	public void verifyHeadingOfPage(String expected) {
		hardWait(2);
		waitForElementToBeVisible("txt_fneTitle");
		verifyTextOfElementIsCorrect("txt_fneTitle", expected);
		logMessage("Assertion Passed : Heading Of FandE Page is '" + expected + "'");
	}

	public void clickResultsButton() {
		element("btn_results").click();
	}

	public void highlightTextPink() {
		switchToDefaultContent();
		switchToDocumentBodyFrame();
		hardWait(1);
		waitAndClick("btn_pinkHighlightWidget");
		logMessage("Highlighted Text");
		// click(element("btn_pinkHighlightWidget"));
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		// js.executeScript("document.getElementById('document-body-iframe').contentDocument.getElementById('highlight-widget-color-4').click();");
		switchToDefaultContent();
		hardWait(2);

	}

	public void verifyHighlightedTextDisplayed(String colourNum) {
		switchToDefaultContent();
		switchToDocumentBodyFrame();
		isElementDisplayed("txt_highlightedPink", colourNum);
		logMessage("Highlighted Text pink");
		wait.hardWait(1);
		logMessage("Assertion Passed : Highlighted Pink text is displayed");
		switchToDefaultContent();
	}

	public void selectOptionFromHighlightNoteGearbox(String optionName) {
		waitForLoaderToDisappear();
		waitAndClick("img_gearbox");
		element("option_gearbox", optionName).click();
		hardWait(2);
		handleAlert();
	}

	public void verifyHighlightRemoved() {
		switchToDefaultContent();
		switchToDocumentBodyFrame();
		verifyElementNotDisplayed("txt_highlightedPink", "4", "");
		logMessage("Assertion Passed : Highlight of text removed");
		switchToDefaultContent();
	}

	public void addNoteToSelectedText() {
		switchToDefaultContent();
		switchToDocumentBodyFrame();
		hardWait(1);
		isElementDisplayed("AddNote");
		click(element("AddNote"));
		logMessage("add note button clicked");
		switchToDefaultContent();
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		// js.executeScript("document.getElementById('document-body-iframe').contentDocument."
		// + "getElementById('highlight-widget-add-note').click();");

	}

	public void verifyAddNoteBoxIsDisplayed() {
		isElementDisplayed("box_addNote");
		logMessage("Assertion Passed : Add Note box is displayed after clicking Add Note");
	}

	public void clickOnBoldIconOnNote() {
		switchToDefaultContent();
		hardWait(2);
		waitForElementToBeVisible("btn_boldAtTinymce");
		element("btn_boldAtTinymce").click();
	}

	public void postNoteInAddNoteBox(String note, Boolean boldAllText, String dropDownText) {
		switchToDefaultContent();
		hardWait(2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('CommentText_ifr').contentDocument.getElementById('tinymce').getElementsByTagName('p')[0].innerHTML='"
				+ note + "'");
		if (boldAllText == true) {
			Actions act = new Actions(driver);
			switchToDefaultContent();
			switchToFrame(element("iframe_tinymceFrame"));
			act.moveToElement(element("txt_tinymceNoteEdit")).build().perform();
			act.sendKeys(Keys.chord(Keys.CONTROL, "a")).build().perform();
			clickOnBoldIconOnNote();
		}
		switchToDefaultContent();
		waitForElementToBeVisible("btn_postInAddNoteBox");
		selectProvidedTextFromDropDown(element("select_highlightMiddleMenu"), dropDownText);
		scrollDown(element("btn_postInAddNoteBox"));
		wait.waitForElementToBeClickable(element("btn_postInAddNoteBox"));
		if (elements("btn_postInAddNoteBox").size() == 1)
			element("btn_postInAddNoteBox").click();
		else if (elements("btn_postInEditNoteBox").size() == 1)
			element("btn_postInEditNoteBox").click();
	}

	public void postNoteInAddNoteBox(String note) {
		switchToDefaultContent();
		hardWait(2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('CommentText_ifr').contentDocument.getElementById('tinymce').getElementsByTagName('p')[0].innerHTML='"
				+ note + "'");
		waitForElementToBeVisible("btn_postInAddNoteBox");

		if (elements("btn_postInAddNoteBox").size() == 1)
			element("btn_postInAddNoteBox").click();
		else if (elements("btn_postInEditNoteBox").size() == 1)
			element("btn_postInEditNoteBox").click();

	}

	public void postNoteInEditNoteBox(String note) {
		switchToDefaultContent();
		hardWait(1);
		String idFrame = element("iframe_noteTextEdit").getAttribute("id");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('" + idFrame + "').contentDocument.getElementById('tinymce')."
				+ "getElementsByTagName('p')[0].innerHTML='" + note + "'");
		element("btn_postInEditNoteBox").click();
	}

	public void verifyBoldTextOnNote(String note) {
		switchToDefaultContent();
		isElementDisplayed("txt_boldNoteInNoteBox", note);
		logMessage("Assertion Passed : Note '" + note + "' is added");
	}

	public void verifyNoteIsDisplayed(String note) {
		switchToDefaultContent();
		isElementDisplayed("txt_noteInNoteBox", note);
		logMessage("Assertion Passed : Note '" + note + "' is added");
	}

	public void verifyAuthorNameIsDisplayOnNote(String instructorUserName) {
		switchToDefaultContent();
		System.out.println(instructorUserName);
		System.out.println(element("txt_noteAuthorName").getText());
		verifyTextOfElementIsCorrect("txt_noteAuthorName", instructorUserName);

	}

	public void clickOnReplyText(String editReply) {
		isElementDisplayed("icon_clickOnNoteReply");
		element("icon_clickOnNoteReply").click();
		hardWait(1);
		postNoteInAddNoteBox(editReply);
		hardWait(1);
		isElementDisplayed("txt_noteReplyAuthorName");
		isElementDisplayed("txt_noteReplyNoteDate");

	}

	public void verifyNoteIsLock(String lockAndUnlock) {
		waitForElementToBeVisible("icon_gearNote");
		hover(element("icon_gearNote"));
		hardWait(1);
		element("option_LockGearNote", lockAndUnlock).click();
		waitForJqueryToFinish();
		hardWait(1);
		handleAlert();
		hardWait(2);
	}

	public void verifyGearNoteIconNotDisplay() {
		switchToDefaultContent();
		hardWait(2);
		if (elements("icon_gearNote").size() != 0) {
			customAssert.customAssertEquals(true, false, "Student side gear icon is display");
		} else {
			logMessage("Student unable to edit or deleted Top Note");
		}
	}

	public void selectEditNoteUsingGearIcon() {
		waitForElementToBeVisible("icon_gearNote");
		hover(element("icon_gearNote"));
		hardWait(1);
		waitAndClick("option_editGearNote");
	}

	public void selectDeleteNoteUsingGearIcon() {
		waitForElementToBeVisible("icon_gearNote");
		hover(element("icon_gearNote"));
		hardWait(1);
		hover(element("icon_gearNote"));
		hardWait(1);
		element("option_LockGearNote", "Delete").click();
		hardWait(1);
		handleAlert();
		hardWait(2);
	}

	public void selectDeleteLastNoteUsingGearIcon() {
		waitForElementToBeVisible("icon_gearNote");
		// hover(element("icon_gearNote"));

		int no_of_gears = elements("icon_gearNote").size();
		executeJavascript("document.getElementsByClassName('highlight-note-action-menu-list')[" + (no_of_gears - 1)
				+ "].style.display='block'");

		element("option_DeleteLockGearNote").click();
		hardWait(1);
		handleAlert();
		hardWait(2);
	}

	public void lockNote(String loackandunlock) {
		waitForElementToBeVisible("icon_gearNote");
		// hover(element("icon_gearNote"));

		int no_of_gears = elements("icon_gearNote").size();
		executeJavascript("document.getElementsByClassName('highlight-note-action-menu-list')[" + (no_of_gears - 1)
				+ "].style.display='block'");

		element("option_LockGearNote", loackandunlock).click();
		hardWait(1);
		handleAlert();
		hardWait(2);
	}

	public void verifyDeletedReplyShouldNotBeDisplayed() {
		waitForElementToBeVisible("icon_gearNote");
		// hover(element("icon_gearNote"));

		int no_of_gears = elements("icon_gearNote").size();
		executeJavascript("document.getElementsByClassName('highlight-note-action-menu-list')[" + (no_of_gears - 1)
				+ "].style.display='block'");

		element("option_LockGearNote", "Edit").click();
		if (elements("icon_allGearNotes").size() > 1) {

			customAssert.customAssertTrue(false, "Deleted Notes are displaying after locking the note");

		} else {

			customAssert.customAssertTrue(true, "Deleted Notes are not displaying");
		}

	}

	public void verifyDefaultGradebookSettings() {
		String points = element("txt_studentPoints").getText();
		String score = element("txt_studentScore").getText();
		String regex1 = "[0-9]/[0-9]";
		String regex2 = "[0-9]%";

		if (points.matches(regex1) && score.matches(regex2))
			customAssert.customAssertEquals(true, false, "Points Displayed");

	}

	public void verifyNoteIsNotDisplayed() {
		verifyElementNotDisplayed("txt_firstNote", "");
	}

	public void clickReplyLinkOnNote() {
		verifyTextOfElementIsCorrect("link_noteDescriptionInNoteBox", "Reply");
		waitAndClick("link_noteDescriptionInNoteBox");
	}

	public void clickNResponseLinkOnNote(String num) {
		verifyTextOfElementIsCorrect("link_noteDescriptionInNoteBox", num + " Response");
		waitAndClick("link_noteDescriptionInNoteBox");
	}

	/**
	 * Verifies LC opens in FandE
	 */
	public void verifyLCOpenInFnE() {
		waitForElementToBeVisible("frame_document");
		// isElementDisplayed("frame_document");
		switchToFrame(element("frame_document"));
		waitForElementToBeVisible("lc_startScreen");
		isElementDisplayed("lc_startScreen");
		switchToDefaultContent();
	}

	/**
	 * Verify content of LC
	 * 
	 * @param role
	 */
	public void verifyLCContent(String role) {
		switchToFrame(element("frame_document"));
		isElementDisplayed("lc_policies");
		isElementDisplayed("link_FAQ");
		isElementDisplayed("lc_classTopicPerformanceReportORTopicsCovered");
		isElementDisplayed("btn_startOrResumeActivityOrPreviewActivityAsStudent");
		if (role.equalsIgnoreCase("instructor")) {
			isElementDisplayed("btn_showSampleResult");
			isElementDisplayed("btn_changeTargetScore");
		}
		switchToDefaultContent();
		isElementDisplayed("btn_previous");
		isElementDisplayed("btn_next");
		isElementDisplayed("btn_home1");
		isElementDisplayed("lc_duedate");
		if (role.equalsIgnoreCase("instructor")) {
			isElementDisplayed("dropdown_edit");
			isElementDisplayed("btn_results");
		}
	}

	/**
	 * Start LC activity
	 */
	public void startLearningCurve() {
		waitForElementToBeVisible("frame_document");
		switchToFrame(element("frame_document"));
		element("btn_startOrResumeActivityOrPreviewActivityAsStudent").click();
		logMessage("Student clicked on start activity");
	}

	/**
	 * Verifies First question of LC activity is displayed
	 */
	public void verifyFirstQuestionDisplayed() {
		isElementDisplayed("div_question");
		switchToDefaultContent();
	}

	/**
	 * Verifies Hint and Show me buttons are present on LC activity
	 */
	public void verifyButtonsPresent() {
		isElementDisplayed("btn_getAHintOrTakeABreak");
		isElementDisplayed("btn_showMeOrNextQuestion");
	}

	/**
	 * Clicks and verifies the Get a hint button functionality
	 */
	public void clickAndVerifyGetAHint3Times() {
		switchToFrame(element("frame_document"));
		for (int i = 0; i < 4; i++) {
			element("btn_getAHintOrTakeABreak").click();
			_verifyHintPopup(i);
			hardWait(1);
		}
		switchToDefaultContent();
	}

	/**
	 * Verifies content of hint popup
	 * 
	 * @param timesHintClicked
	 */
	private void _verifyHintPopup(int timesHintClicked) {
		if (timesHintClicked != 3) {
			customAssert.customAssertTrue(element("div_hint").getText().contains("Hint"),
					"Assertion Failed: Hint not Available");
			logMessage("Assertion Passed: Hint Available");
		} else {
			customAssert.customAssertTrue(element("div_hint").getText().contains("Sorry!"),
					"Assertion Failed: Hint not available for third time");
			logMessage("Assertion Passed: Hint not available for third time");
		}
	}

	/**
	 * Clicks Show me button on LC question
	 */
	public void clickShowMeButton() {
		switchToDefaultContent();
		switchToFrame(element("frame_document"));
		element("btn_showMeOrNextQuestion").click();
		handleAlert();
		logMessage("Student clicks Show Me Button");
	}

	/**
	 * Verifies Show me popup
	 */
	public void verifyShowMePopup() {
		String text = "The correct answer is";
		isElementDisplayed("popup_showMe");
		isElementDisplayed("lnk_reportQuestion");
		customAssert.customAssertTrue(element("txt_correctAnswer").getText().contains(text),
				"Assertion Failed: Show Me popuop doesn't displays the correct answer text");
	}

	/**
	 * Student clicks on Take A Break button
	 */
	public void clickOnTakeABreak() {
		switchToDefaultContent();
		switchToFrame(element("frame_document"));
		element("btn_getAHintOrTakeABreak").click();
		logMessage("Student took a break");
	}

	public void verifyGraceIsAssigned(String periodDuration, String durationType) {
		clickAssignmentTab();
		waitForLoaderToDisappear();
		customAssert.customAssertEquals(element("txtinput_gracePeriodDuration").getAttribute("value").trim(),
				periodDuration, "Assertion Failed: Grace Period is not set");
		customAssert.customAssertEquals(element("drpdown_sameDurationType").getText().trim(), durationType,
				"Assertion Failed: Grace Period is not set");
		logMessage("Assertion Passed: Grace Period is set");
	}

	/**
	 * Verifies clicking on Take A Break button navigates to a correct page
	 */
	public void verifyBreak() {
		switchToDefaultContent();
		switchToFrame(element("frame_document"));
		waitForElementToBeVisible("div_fullReportSummary");
		isElementDisplayed("div_fullReportSummary");
		isElementDisplayed("btn_doneLC");
		isElementDisplayed("link_moreQuestions");
	}

	/**
	 * Student clicks on Next Question
	 */
	public void clickOnNextQuestion() {
		element("btn_showMeOrNextQuestion").click();
		logMessage("Student takes Next Question");
	}

	/**
	 * Student clicks Ebook Link
	 * 
	 * @return name of the ebook
	 */
	public String clickEbookTitle() {
		switchToFrame(element("frame_document"));

		element("lnk_ebook").click();
		logMessage("Student opens ebook");
		logMessage(element("lnk_ebook").getText() + ": Title");
		return element("lnk_ebook").getText();
	}

	/**
	 * Verifies Ebook
	 */
	public void verifyEbook(String ebookTitle, String role) {

		switchToDefaultContent();
		isElementDisplayed("div_ebook");
		isElementDisplayed("heading_ebook");
		Reporter.log("Ebook link title: " + ebookTitle);
		Reporter.log("Ebook content heading: " + element("heading_ebook").getText());
		String ebookHeading = element("heading_ebook").getText().replaceAll("[^\\x00-\\x7F]", "'");
		String ebookLinkTitle = ebookTitle.replaceAll("[^\\x00-\\x7F]", "'");
		customAssert.customAssertTrue(ebookLinkTitle.contains(ebookHeading),
				"Assertion Failed: Ebook link and heading doesn't match");
		waitForElementToBeVisible("iframe_ebook");
		switchToFrame(element("iframe_ebook"));
		isElementDisplayed("txt_printedPageEbook");
		isElementDisplayed("txt_headingEbookContent");
		isElementDisplayed("txt_ebookPara");
		switchToDefaultContent();
	}

	/**
	 * Student closes ebook
	 */
	public void closeEbook() {
		element("btn_closeEbook").click();
	}

	/**
	 * Student clicks LC activity Done button
	 */
	public void clickLCActivityDoneButton() {
		element("btn_doneLC").click();
		handleAlert();
		logMessage("Student click LC activity Done button");
		switchToDefaultContent();
	}

	/**
	 * Student clicks on "Show Full Personalized Study Plan" link
	 */
	public void clickOnPersonalizePlan() {
		switchToDefaultContent();
		switchToFrame(element("frame_document"));
		element("lnk_personalizePlan").click();
		logMessage("Student view Personalized plan");
	}

	/**
	 * Verifies the Personalized Plan
	 */
	public void verifyPersonalizedPlan() {
		waitForElementToBeVisible("txt_topicsNeedWork");
		isElementDisplayed("txt_topicsNeedWork");
	}

	/**
	 * Instructor clicks "Preview Activity as Student" button
	 */
	public void clickPreviewActivityAsStudent() {
		waitForElementToBeVisible("frame_document");
		switchToFrame(element("frame_document"));
		waitForElementToBeVisible("btn_startOrResumeActivityOrPreviewActivityAsStudent");
		element("btn_startOrResumeActivityOrPreviewActivityAsStudent").click();
	}

	/**
	 * Student clicks Resume Activity
	 */
	public void clickOnResumeActivity() {
		waitForElementToBeVisible("frame_document");
		switchToFrame(element("frame_document"));
		waitForElementToBeVisible("btn_startOrResumeActivityOrPreviewActivityAsStudent");
		element("btn_startOrResumeActivityOrPreviewActivityAsStudent").click();
	}

	// Results Page
	public void verifyGradeDetailLabelValueDisplayed(String label) {
		isElementDisplayed("txt_gradeDetailLabelValue", label);
		logMessage("Assertion Passed : Value of '" + label + "' is displayed");
	}

	// Results Page
	public void verifyGradeDetailLabelValue(String label, String expectedValue) {
		customAssert.customAssertEquals(element("txt_gradeDetailLabelValue", label).getText(), expectedValue,
				"Assertion Failed : Value of '" + label + "' is not correct");
		logMessage("Assertion Passed : Value of '" + label + "' is correct");
	}

	/**
	 * Clicks and enter link in Link Collection
	 */
	public void attachLinkToLinkCollection(String title, String linkurl) {
		_clickAttachLink();
		_verifyAddLinkFormIsDisplayed();
		_fillLinkDetails(title, linkurl);
		_clickSaveButtonOnLinkForm();
	}

	/**
	 * Clicks on link " Attach a Link"
	 */
	private void _clickAttachLink() {
		waitForElementToBeVisible("lnk_attachALink");
		element("lnk_attachALink").click();
	}

	/**
	 * Verifies Add link form for providing link is displayed
	 */
	private void _verifyAddLinkFormIsDisplayed() {
		isElementDisplayed("txt_titleModal", "Attach a link");
	}

	/**
	 * Enter the link title and link url
	 */
	private void _fillLinkDetails(String title, String linkurl) {
		fillText("txtinput_linkTitle", title);
		fillText("txtinput_linkCollectionUrl", linkurl);
	}

	/**
	 * Clicks on Save button on Link collection form
	 */
	private void _clickSaveButtonOnLinkForm() {
		element("btn_saveLinkForm").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Verifies attached link is displayed on Basic Info page of Link Collection
	 */
	public void verifyAttachedLinkDisplayedOnBasicInfoPage(String linkUrl) {
		isElementDisplayed("lnk_attachedLink");
		customAssert.customAssertTrue(element("lnk_attachedLink").getAttribute("href").contains(linkUrl),
				"Link attached in Link Collection is not displayed on Basic Info Page");
	}

	/**
	 * Verifies attached link is displayed on FandE Home page
	 */
	public void verifyAttachedLinkDisplayedOnFandEPage(String linkUrl) {
		isElementDisplayed("lnk_attachedLinkOnFnEPage");
		customAssert.customAssertTrue(element("lnk_attachedLinkOnFnEPage").getAttribute("href").contains(linkUrl),
				"Link attached in Link Collection is not displayed on FandE HomePage");
	}

	/**
	 * Creates a New Question type from the set of values
	 * 
	 * @param questionType
	 */
	public void createNewQuestionType(String questionType) {
		waitForElementToBeVisible("button_newQuestionMenu");
		element("button_newQuestionMenu").click();
		hardWait(2);
		isElementDisplayed("link_questionTypeContext", questionType);
		element("link_questionTypeContext", questionType).click();
		logMessage("Clicked on " + questionType + " type question from Question Menu");
		waitForLoaderToDisappear();
	}

	/**
	 * Fills New Question details for Advance Question
	 * 
	 * @param questionType
	 */
	public void enterNewQuestionDetails(String questionName, String responseAreaType, String defaultAnswer) {
		switchToDefaultContent();
		switchToFrame(element("advanceQuestionMainFrame"));
		switchToFrame(element("advanceQuestionQuestionFrame"));
		waitForElementToBeVisible("txt_advancequestion");
		element("txt_advancequestion").click();
		element("txt_advancequestion").clear();
		element("txt_advancequestion").sendKeys(questionName);
		logMessage("Entered name: " + questionName + " for Advance Question");
		switchToDefaultContent();
		switchToFrame(element("advanceQuestionMainFrame"));
		waitForElementToBeVisible("btn_insertResponseArea");
		hover(element("btn_insertResponseArea"));
		element("btn_insertResponseArea").click();

		waitForElementToBeVisible("lnk_responseAreaType", responseAreaType);
		element("lnk_responseAreaType", responseAreaType).click();
		logMessage("Clicked " + responseAreaType + " type Response Area for Advance Question");

		switchToDefaultContent();
		switchToFrame(element("advanceQuestionMainFrame"));
		switchToFrame(element("advanceQuestionAnswerFieldFrame"));
		waitForElementToBeVisible("txt_advanceQuestionAnswerField");
		scroll(element("txt_advanceQuestionAnswerField"));
		element("txt_advanceQuestionAnswerField").sendKeys(defaultAnswer);
		logMessage("Entered " + defaultAnswer + " as default answer for Advance Question");
		waitForElementToBeVisible("btn_saveAdvanceQuestion");
		element("btn_saveAdvanceQuestion").click();

		switchToDefaultContent();
		switchToFrame(element("advanceQuestionMainFrame"));
		waitForElementToBeVisible("btn_saveQuestion");
		element("btn_saveQuestion").click();
		logMessage("Clicked on Save button");
		switchToDefaultContent();
		waitForLoaderToDisappear();
	}

	/**
	 * Method which uses external XML file to create a New Advanced Question
	 */
	public void useXmlToCreateQuestion() {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForElementToBeVisible("btn_Bold");
		waitForElementToBeVisible("btn_rawXML");
		element("btn_rawXML").click();
	}

	/**
	 * Verifies whether the Raw XML frame is displayed
	 * 
	 * @param xmlName
	 */
	public void verifyRawXMLEditorFrameIsDisplayed(String rawXMLEditorTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		isElementDisplayed("txt_rawXMLEditorTitle");
		verifyTextOfElementIsCorrect("txt_rawXMLEditorTitle", rawXMLEditorTitle);
		logMessage("Assertion Passed: User is on Question Editor page, Verified Raw-XML Editor title visibility and Title text to be: "
				+ rawXMLEditorTitle);
	}

	/**
	 * Reads the XML file & writes the content in the provided Text area &
	 * Clicks in Apply button
	 * 
	 * @param string
	 */
	public void fillXmlInTheEditorRawXmlFieldAndApply(String xmlName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));

		element("textarea_rawXMLEditor").clear();

		String questxmlloc = "";
		if (xmlName.contains("/")) {
			questxmlloc = DataReadWrite.readXmlFromFile(xmlName);
		} else {
			questxmlloc = DataReadWrite.readXmlFromFile("./src/test/resources/testdata/LAUNCHPAD/" + xmlName);
		}

		element("textarea_rawXMLEditor").sendKeys(questxmlloc);
		waitForElementToBeVisible("btn_editor");
		element("btn_editor").click();
		waitForElementToBeVisible("popUp_applyChanges");
		element("popUp_applyChanges").sendKeys(Keys.RETURN);
		switchToDefaultContent();
	}

	public void clearXMLEditor() {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		element("textarea_rawXMLEditor").clear();
		waitForElementToBeVisible("btn_editor");
		element("btn_editor").click();
		waitForElementToBeVisible("popUp_applyChanges");
		element("popUp_applyChanges").sendKeys(Keys.RETURN);
		switchToDefaultContent();
	}

	/**
	 * Method saves the advanced question after editing the advanced question
	 */
	public void saveAdvancedQuestionAfterEditing() {
		waitForMsgToastToDisappear();
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForElementToBeVisible("btn_editorSave");
		element("btn_editorSave").click();
		switchToDefaultContent();
		waitForMsgToastToDisappear();
	}

	/**
	 * Start Quiz. Attempt one Question of Quiz & click on "Submit" button
	 */
	public void attemptAQEQuizAndClickedOnSubmit() {
		switchToTopWindow();
		clickStartTheQuizButton();
		switchToCourseContentFrame();
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToTopWindow();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment");
	}

	public void selectNoQuestions() {
		waitForElementToBeVisible("drpdown_selectMenu");
		element("drpdown_selectMenu").isDisplayed();
		element("drpdown_selectMenu").click();
		waitForElementToBeVisible("lnk_AllInSelectMenu");
		element("lnk_AllInSelectMenu").click();
		waitForElementToBeVisible("btn_add");
		element("drpdown_selectMenu").click();
		waitForElementToBeVisible("lnk_NoneInSelectMenu");
		element("lnk_NoneInSelectMenu").click();
	}

	public void verifyNoQuestionSelected() {
		if (elements("btn_add").size() != 0) {
			customAssert.customAssertTrue(false, "Button add is displayed after selecting no question");
		}
		logMessage("Add button is not present when no question is selected");
		for (WebElement chkbox_question : elements("chkbox_active")) {
			customAssert.customAssertFalse(chkbox_question.getAttribute("class").trim().equals("active"),
					"Atleast one question is still selected after selecting no question");
		}
	}

	public void editQuestion(String editedQuestion) {
		hover(element("firstQuestion"));
		element("lnk_editQuestion").click();
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_saveEdit");
		switchToFrame(element("iframe_easyXDMDefault"));
		isElementDisplayed("link_properties");
		isElementDisplayed("link_points");
		waitForLoaderToDisappear();
		switchToDefaultContent();
		waitForLoaderToDisappear();
		executeJavascript("document.getElementsByTagName('iframe')[1].contentDocument.getElementsByTagName('textarea')[0].value='"
				+ editedQuestion + "'");
		element("btn_saveEdit").click();
		// waitForLoaderToDisappear();
		// switchToFrame(element("iframe_easyXDMDefault"));
		// waitForLoaderToDisappear();
		// switchToDefaultContent();
		isElementDisplayed("msg_toast");
		waitForMsgToastToDisappear();
	}

	public void editSaveAdvancedQuestion(String editedQuestion) {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_saveEdit");
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForLoaderToDisappear();
		switchToDefaultContent();
		waitForLoaderToDisappear();
		executeJavascript("document.getElementsByTagName('iframe')[1].contentDocument.getElementsByTagName('textarea')[0].value='"
				+ editedQuestion + "'");
		saveAdvancedQuestionAfterEditing();
		clickAssignmentTab();
		clickQuestionsTab();
	}

	public void clickOnPreviewAndVerifyEditedAdvancedQuestion(String editedQuestion) {
		waitForElementToBeVisible("lnk_previewEdit");
		element("lnk_previewEdit").click();
		// switchToFrame(element("iframe_questionPreview"));
		hardWait(1);
		waitForElementToBeVisible("heading_previewAdvancedQuestion");
		// customAssert.customAssertEquals(
		// element("heading_previewAdvancedQuestion").getText().trim(),
		// editedQuestion,
		// "Edited question title is not displayed in preview");
		// switchToDefaultContent();
		element("btn_closePreview").click();
	}

	public void clickOnPreviewAndVerifyEditedQuestion(String editedQuestion) {
		waitForElementToBeVisible("lnk_previewEdit");
		element("lnk_previewEdit").click();
		waitForElementToBeVisible("heading_previewQuestion");
		customAssert.customAssertEquals(element("heading_previewQuestion").getText().trim(), editedQuestion,
				"Edited question title is not displayed in preview");
		switchToDefaultContent();
		element("btn_closePreview").click();
	}

	public void browseQuestionBank() {
		waitForElementToBeVisible("btn_browseQuestionBank");
		element("btn_browseQuestionBank").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void RemoveQuestion() {
		hover(element("firstQuestion"));
		executeJavascript("document.getElementsByClassName('delete-current-question')[0].click()");
		waitForElementToBeVisible("btn_removeConfirm");
		element("btn_removeConfirm").click();
		isElementDisplayed("msg_toast");
		waitForLoaderToDisappear();
	}

	public void verifyQuestionRemoved() {
		customAssert.customAssertTrue(element("firstQuestion").getText().contains("not yet added"),
				"Question is still visible after removing the question");
	}

	public void fillTitleOnBasicInfo2(String newTitle) {
		waitForElementToBeVisible("inp_title2");
		element("inp_title2").clear();
		element("inp_title2").sendKeys(newTitle);
	}

	/*
	 * clicks on Attach Document Link on Basic info
	 */
	public void clickOnAttachDocumentLink() {
		element("lnk_attachDocument").click();
		logMessage("Clicks on attach Document Collection");
	}

	/**
	 * Verifies icon of the submitted file on Dropbox
	 */
	public void verifySubmitAssignmentIcon(String fileName) {
		waitForElementToBeVisible("txt_submitFile");
		isElementDisplayed("txt_submitFile");
		logMessage(element("txt_submitFile").getText() + " file has been uploaded");
		isElementDisplayed("icon_submitDropBoxFile");
		logMessage("Uploaded file icon displayed");
	}

	/**
	 * Verifies Student Name is displayed on Assignment's Results Page
	 * 
	 * @param studentName
	 *            Name of Student
	 */
	public void verifyStudentNameOnAssignmentResultPage(String studentName) {
		String[] student = getLastNameFirstNameOfUser(studentName);
		String expectedText = student[1] + ", " + student[0];
		waitForElementToBeVisible("txt_studentNameOnResultPage", expectedText);
		customAssert.customAssertEquals(element("txt_studentNameOnResultPage", expectedText).getText(), expectedText,
				"Assertion Failed : Student '" + expectedText + "' is not displayed on Assignment Result page");
		logMessage("Assertion Passed : Student '" + expectedText + "' is displayed on Assignment Result page");
	}

	/**
	 * Returns First Name and Last Name of User as Array of String
	 * 
	 * @param userName
	 */

	/**
	 * Clicks on Student Name at Assignment's Result Page
	 * 
	 * @param studentName
	 *            Name of Student
	 */
	public void clickStudentNameOnAssignmentResultPage(String studentName) {
		String[] student = getLastNameFirstNameOfUser(studentName);
		String expectedText = student[1] + ", " + student[0];
		waitForElementToBeVisible("txt_studentNameOnResultPage", expectedText);
		element("txt_studentNameOnResultPage", expectedText).click();
		waitForElementToBeVisible("txt_studentNameHeadingOnResultPage");
		customAssert.customAssertEquals(element("txt_studentNameHeadingOnResultPage").getText(), expectedText,
				"Assertion Failed : " + "Student Name is incorrect on Result Page");
		logMessage("Assertion Passed : Student name is correct on Result Page");
	}

	/**
	 * Verifies that correct grade is displayed for Student on Assignment's
	 * result Page
	 * 
	 * @param grade
	 */
	public void verifyGradeOfStudentOnAssignmentResultPage(String grade) {
		hardWait(2);
		waitForElementToBeVisible("txt_gradeOfStudentOnResultPage");
		customAssert.customAssertEquals(element("txt_gradeOfStudentOnResultPage").getAttribute("value"), grade,
				"Assertion Failed : " + "Grade is incorrect for Student on Result Page");
		logMessage("Assertion Passed : Grade is correct for Student on Result Page");
	}

	public void verifyBtnsOnAssignmentResultStudentPage() {
		customAssert.customAssertTrue(isElementDisplayed("btn_xBtnText", "Submit Score"),
				"Assertion Failed : 'Submit Score' Button" + "is not present on Assignment Result Student Page");
		customAssert.customAssertTrue(isElementDisplayed("btn_xBtnText", "Continue Later"),
				"Assertion Failed : 'Continue Later' Button" + "is not present on Assignment Result Student Page");
		customAssert.customAssertTrue(isElementDisplayed("btn_xBtnText", "Excuse"),
				"Assertion Failed : 'Excuse' Button" + "is not present on Assignment Result Student Page");
		customAssert.customAssertTrue(isElementDisplayed("btn_xBtnText", "Allow Retry"),
				"Assertion Failed : 'Allow Retry' Button" + "is not present on Assignment Result Student Page");
		customAssert.customAssertTrue(isElementDisplayed("btn_xBtnText", "Cancel"),
				"Assertion Failed : 'Cancel' Button" + "is not present on Assignment Result Student Page");
	}

	public void clickCancelButtonOnAssignmentResultStudentPage() {
		element("btn_xBtnText", "Cancel").click();
	}

	/**
	 * Browse and Upload file In Document Collection
	 */
	public void submitFileForDocumentCollection(String fileName) {
		clickOnAttachDocumentLink();
		enterFilepathToUpload(fileName, "txtinput_fileBrowseDropbox");
		enterDocumentTitle(fileName);
		click(element("btn_upload"));
		// waitAndClick("btn_upload");
		// element("btn_upload").click();
		waitForLoaderToDisappear();
		hardWait(3);
	}

	/**
	 * Verify Upload File
	 */
	public void verifyFileSubmittedOnDocumentCollection(String fileName) {
		waitForElementToBeVisible("link_submittedFileNameDropbox", fileName);
		isElementDisplayed("link_submittedFileNameDropbox", fileName);
		logMessage("File is Attached");
	}

	/**
	 * Enter uploaded document collection title
	 */
	public void enterDocumentTitle(String docmentTitle) {
		fillText("txtinput_uploadedDocumentTitle", docmentTitle);
	}

	/**
	 * Clicks On Remove Link to remove Attached document on Basic Info
	 */
	public void clickOnRemoveDocumentOnBasicInfo() {
		waitForElementToBeVisible("lnk_removeDocument");
		element("lnk_removeDocument").click();
		logMessage("Click on Remove document on Basic Info");
		handleAlert();
		logMessage("Document successfully removed");
		waitForLoaderToDisappear();
	}

	/**
	 * Verify attachment
	 */
	public void verifyAttachmentIsRemoved(String fileName) {
		verifyElementNotDisplayed("link_submittedFileNameDropbox", fileName, "");
	}

	public void uploadDocumentinHTMLAssignemnt(String filename) {
		waitForElementToBeVisible("lnk_UploadDocumentHTMLAssignment");
		switchToFrame(element("iframe_tinyMice"));
		element("txt_DirectionsTextAreaBasicInfo").clear();
		switchToDefaultContent();
		element("lnk_UploadDocumentHTMLAssignment").click();
		enterFilepathToUpload(filename, "btn_BrowseUploadDocumentHTMLAssignment");
		hardWait(3);
		element("btn_SaveUploadFileInHTMLAssignment").click();
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_saveBasicInfo2");
		switchToFrame(element("iframe_tinyMice"));
		element("txt_DirectionsTextAreaBasicInfo").sendKeys("      ");
		switchToDefaultContent();
	}

	public void enterFilepathInUploadDocument(String filename) {
		waitForElementToBeVisible("btn_BrowseUploadDocumentHTMLAssignment");
		String currentDir = System.getProperty("user.dir");
		if (System.getProperty("os.name").contains("Windows")) {
			element("btn_BrowseUploadDocumentHTMLAssignment").sendKeys(
					currentDir + "\\src\\test\\resources\\testdata\\" + filename);
		} else {
			element("btn_BrowseUploadDocumentHTMLAssignment").sendKeys(
					currentDir + "/src/test/resources/testdata/" + filename);
		}
	}

	public void verifyUploadLink(String filepath) {
		switchToFrame(element("frame_document"));
		customAssert.customAssertEquals(element("lnk_UploadText", filepath).getText(), filepath,
				"Assertion Failed : FilePath is incorrect");
		switchToDefaultContent();
	}

	/**
	 * Verifies Assignment is unassigned in Assignment Setting Tab
	 */
	public void verifyAssignmentIsUnassignedInAssignmentSettingTab() {
		customAssert.customAssertTrue(element("txtinput_assignDueDate").getAttribute("value").equals(""),
				"Assertion Failed : The Assingment is not Unassigned ");
		logMessage("Assignment is Unassigned");
	}

	/**
	 * Clicks Schedule an Email reminder checkbox
	 */
	public void clickEmailReminderCheckbox() {
		waitForElementToBeVisible("chkBox_emailReminder");
		if (elements("txtinput_reminderDayCount").size() == 0) {
			element("chkBox_emailReminder").click();
		}
	}

	/**
	 * Fill in the details for Email reminder
	 */
	public void fillDetailsForEmailReminder(String reminderDayCount, String reminderBeforeType, String emailTitle,
			String emailMessage) {
		waitForElementToBeVisible("txtinput_reminderDayCount");
		scrollDown(element("txtinput_reminderDayCount"));
		fillText("txtinput_reminderDayCount", reminderDayCount);
		selectProvidedTextFromDropDown(element("drpdown_reminderBeforeType"), reminderBeforeType);
		fillText("txtinput_emailReminderSubject", emailTitle);
		fillText("txtinput_reminderEmailBody", emailMessage);
	}

	/**
	 * Clicks on Save Changes button on Assignment tab
	 */
	public void clickOnSaveChangesOnAssignmentTab() {
		element("btn_saveChanges").click();
		logMessage("User clicks on 'Save Changes' button on Assignment Tab");
		handleAlert();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Verifies Email reminder settings remains same for Entire Class.
	 */
	public void verifyEmailSettingForEntireClassAndIndividual(String reminderDayCount, String reminderBeforeType,
			String emailSubject, String emailMessage) {
		customAssert.customAssertEquals(element("txtinput_reminderDayCount").getAttribute("value"), reminderDayCount,
				"Assertion Failed: Reminder Day Count is incorrect");
		customAssert.customAssertEquals(element("txt_selectedOption").getText(), reminderBeforeType,
				"Assertion Failed: Reminder Before type is incorrect");
		customAssert.customAssertEquals(element("txtinput_emailReminderSubject").getText(), emailSubject,
				"Assertion Failed: Email Subject is not updated");
		customAssert.customAssertEquals(element("txtinput_reminderEmailBody").getText(), emailMessage,
				"Assertion Failed: Email Message is not updated");
	}

	/**
	 * Fill in the details for Email reminder
	 */
	public void fillDetailsForEmailReminder(String reminderDayCount, String reminderBeforeType) {
		waitForElementToBeVisible("txtinput_reminderDayCount");
		fillText("txtinput_reminderDayCount", reminderDayCount);
		selectProvidedTextFromDropDown(element("drpdown_reminderBeforeType"), reminderBeforeType);
		element("txtinput_emailReminderSubject").sendKeys("Email Reminder");
		element("txtinput_reminderEmailBody").sendKeys("Email Message.");
	}

	// /**
	// * Verifies Flash Content is rendered on FandE Page for ticket PX12341
	// */
	// public void verifyFlashContent() {
	// ScreenRegion s = new DesktopScreenRegion();
	// String currentDir = System.getProperty("user.dir");
	// try {
	// URL imageURL = new URL("file:///" + currentDir
	// + "/src/test/resources/testdata/FlashContent.PNG");
	// Target imageTarget = new ImageTarget(imageURL);
	// ScreenRegion r = s.wait(imageTarget, 10000);
	// r.find(imageTarget);
	// logMessage("Flash Content is rendered properly");
	// } catch (Exception e) {
	// customAssert.customAssertTrue(false,
	// "Flash Content is not rendered on FandE Page");
	// }
	// }

	/**
	 * Verifies Assigned Assignment date
	 */
	public void verifyAssignedAssignmentDate(String expectedDate) {
		String actualDate = element("calender_dueDateDisplay").getText();
		customAssert.customAssertEquals(actualDate, expectedDate,
				"Assertion Failed : Due  Date not eqauls to Assigned date");
		logMessage("Assertion Passed : Due  Date  eqauls to Assigned date");
	}

	/**
	 * Verifies Links on Assinment's Result Page for Student
	 */
	public void verifyLinksOnAssignmentResultStudentPage() {
		isElementDisplayed("link_scoreHistoryOnResultPage");
		isElementDisplayed("link_classStatisticsOnResultPage");
		isElementDisplayed("link_submissionHistoryOnResultPage");
		logMessage("All the links are correctly displayed on Assignment Result Student Page");
	}

	public void verifyDueDateOnAssinmentResultStudentPage() {
		String dueDate = element("txt_dueDateOnResultPage").getText();
		if (dueDate.equals("")) {
			customAssert.customAssertTrue(false,
					"Assertion Failed : Due Date is incorrect on Assignment Result Student Page");
		} else {
			logMessage("Assertion Passed : Due Date is displayed on Assignment Result Student Page");
		}
	}

	public void verifySubmittedDateOnAssinmentResultStudentPage() {
		String submittedDate = element("txt_submittedDateOnResultPage").getText();
		if (submittedDate.equals("")) {
			customAssert.customAssertTrue(false,
					"Assertion Failed : Submitted Date is incorrect on Assignment Result Student Page");
		} else {
			logMessage("Assertion Passed : Submitted Date is displayed on Assignment Result Student Page");
		}
	}

	public void verifyFeedbackButtonsOnAssignmentResultStudentPage() {
		isElementDisplayed("btn_addNotesFeedbackOnResultPage");
		isElementDisplayed("btn_insertTemplateFeedbackOnResultPage");
		logMessage("Assertion Passed : Feedback Buttons are present on Assignment Result Student Page");
	}

	public void verifyNotesToSelfButtonsOnAssignmentResultStudentPage() {
		isElementDisplayed("btn_addNotesToSelfOnResultPage");
		isElementDisplayed("btn_insertTemplateNotesToSelfOnResultPage");
		logMessage("Assertion Passed : Notes to self Buttons are present on Assignment Result Student Page");
	}

	public void clickOnSubmissionLinkOfStudentFromSubmissions(String studentName) {
		element("link_submission", studentName).click();
		logMessage("Clicked on Submission link");
	}

	public void verifyStudentSubmissionModal(String studentName, String assignmentName) {
		switchToFrame(element("iframe_submission"));
		verifyTitleOfAssignment(studentName, assignmentName);
		verifyItemOnSubmissionModal(assignmentName);
		verifyLinksOnAssignmentResultStudentPage();
		verifyDueDateOnAssinmentResultStudentPage();
		verifySubmittedDateOnAssinmentResultStudentPage();
		verifyFeedbackButtonsOnAssignmentResultStudentPage();
		verifyNotesToSelfButtonsOnAssignmentResultStudentPage();
		verifyBtnsOnAssignmentResultStudentPage();
		switchToDefaultContent();
		// switchToDefaultFrame();
	}

	private void verifyItemOnSubmissionModal(String assignmentName) {
		customAssert.customAssertEquals(element("txt_itemName").getText(), assignmentName,
				"Assertion Failed: Item name correct");
		logMessage("Assertion Passed: Item name correct");
	}

	private void verifyTitleOfAssignment(String studentName, String assignmentName) {
		String[] student = getLastNameFirstNameOfUser(studentName);
		String expectedText = student[1] + ", " + student[0];
		customAssert.customAssertEquals(element("txt_submissionModalTitle").getText(), "History for '" + assignmentName
				+ "' - " + expectedText, "Assertion Failed : Title of assignment on overlay is correct");
		logMessage("Assertion Passed : Title of assignment on overlay is correct");
	}

	public void AddNotesToSelf(String selfNotes) {
		element("btn_addNotesToSelfOnResultPage").click();
		// switchToFrame(element("iframe_notes"));
		// element("txtarea_notes").sendKeys(selfNotes);
		switchToDefaultContent();
		executeJavascript("document.getElementsByClassName('frame-api')[1].contentDocument.getElementsByTagName('iframe')[0].contentDocument.getElementsByTagName('div')[0].innerHTML='"
				+ selfNotes + "'");
		switchToDefaultFrame();
		element("btn_xBtnText", "Continue Later").click();
		logMessage("Self notes added");
		waitForElementToDisappear("loader");
	}

	public void verifySelfNotes(String selfNotes) {
		customAssert.customAssertEquals(element("txt_selfnotes").getText(), selfNotes,
				"Assertion Failed : Self notes correct");
		logMessage("Assertion Passed : Self notes correct");
	}

	public void addFeedbackForStudent(String feedback) {
		element("btn_addNotesFeedbackOnResultPage").click();
		// switchToFrame(element("iframe_notes"));
		// element("txtarea_notes").sendKeys(feedback);
		switchToDefaultContent();
		executeJavascript("document.getElementsByClassName('frame-api')[1].contentDocument.getElementsByTagName('iframe')[0].contentDocument.getElementsByTagName('div')[0].innerHTML='"
				+ feedback + "'");
		switchToDefaultFrame();
		element("btn_xBtnText", "Continue Later").click();
		logMessage("Feedback added");
		waitForElementToDisappear("loader");
	}

	public void verifyFeedback(String feedback) {
		customAssert.customAssertEquals(element("txt_feedback").getText(), feedback,
				"Assertion Failed : Feedback correct");
		logMessage("Assertion Passed : Feedback correct");
	}

	public String getCalculatedScore() {
		return element("txtbox_grade").getText();
	}

	public void modifyScore(String modifiedScore) {
		element("txtbox_grade").clear();
		switchToDefaultContent();
		executeJavascript("document.getElementsByClassName('frame-api')[1].contentDocument.getElementById('grade').value='"
				+ modifiedScore + "'");
		switchToDefaultFrame();
		hardWait(2);
		logMessage("Grades Modified");
	}

	public void verifyModifiedScore(String modifiedScore) {
		hardWait(2);
		customAssert.customAssertEquals(element("txtbox_grade").getAttribute("value"), modifiedScore,
				"Assertion failed : Grades modified successfully");
		logMessage("Assertion passed : Grades modified successfully");
		customAssert.customAssertEquals(element("txt_modifiedOrCalculated").getText().trim(), "(Modified)",
				"Assertion failed : Label changed to modified");
		logMessage("Assertion passed : Label changed to modified");
	}

	public void revertToCalculatedScore() {
		element("link_revertToCalculatedScore").click();
		logMessage("Clicked on Revert to calculated link");
	}

	public void verifyCalculatedScore(String calculatedScore) {
		customAssert.customAssertEquals(element("txtbox_grade").getText(), calculatedScore,
				"Assertion failed : Grades reverted to calculated successfully");
		logMessage("Assertion passed : Grades reverted to calculated successfully");
		customAssert.customAssertEquals(element("txt_modifiedOrCalculated").getText(), "(Calculated)",
				"Assertion failed : Label changed to calculated");
		logMessage("Assertion passed : Label changed to calculated");
	}

	public void clickOnSubmissionHistory() {
		element("link_submissionHistoryOnResultPage").click();
		logMessage("Clicked on Submission History link");
		customAssert.customAssertEquals(element("txt_header").getText(), "Submission History",
				"Assertion failed : Submission history link verified");
		logMessage("Assertion passed : Submission history link verified");
	}

	public void clickOnScoreHistory() {
		element("link_scoreHistoryOnResultPage").click();
		logMessage("Clicked on Score History link");
		customAssert.customAssertEquals(element("txt_header").getText(), "Score History",
				"Assertion failed : Score history link verified");
		logMessage("Assertion passed : Score history link verified");
	}

	public void closeOverlay() {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		element("btn_closeOverlay").click();
		logMessage("Overlay closed");
	}

	public void clickOnZeroScoreForUnsubmittedLink() {
		element("btn_xBtnText", "Zero Score for Unsubmitted").click();
		logMessage("Clicked on Zero Score For Unsubmitted button");
		element("btn_xBtnText", "Yes").click();
		logMessage("Clicked on Yes button");
	}

	public void verifyZeroAwardedToSecondStudent(String studentName) {
		hardWait(2);
		String[] student = getLastNameFirstNameOfUser(studentName);
		String expectedText = student[1] + ", " + student[0];
		customAssert.customAssertEquals(element("txt_scoreForSecondStudent", expectedText).getText(), "0",
				"Assertion failed : Scores changed to zero for unsubmitted attempts");
		logMessage("Assertion passed : Scores changed to zero for unsubmitted attempts");
	}

	public String verifyScoreOfStudent(String studentName, String score, String score1) {
		hardWait(2);
		String[] student = getLastNameFirstNameOfUser(studentName);
		String expectedText = student[1] + ", " + student[0];
		customAssert.customAssertTrue(element("txt_scoreForSecondStudent", expectedText).getText().trim().equals(score)
				|| element("txt_scoreForSecondStudent", expectedText).getText().trim().equals(score),
				"Assertion Failed: Scores are in decimal upto 2 decimal point on results page");
		logMessage("Assertion Passed: Scores are in decimal upto 2 decimal point on results page");
		return element("txt_scoreForSecondStudent", expectedText).getText().trim();
	}

	public void verifySubmissionsSorting() {
		_verifySortingByDate();
		_verifySortingByName();
		_verifySortingByScore();
	}

	private void _verifySortingByScore() {
		ArrayList<String> text = new ArrayList<String>();
		for (WebElement e : elements("list_studentScores")) {
			text.add(e.getText());
		}
		ArrayList<String> sortedText = new ArrayList<String>();
		sortedText = text;
		Collections.sort(sortedText);
		element("header_score").click();
		int i = 0;
		for (String s : sortedText) {
			customAssert.customAssertEquals(elements("list_studentScores").get(i).getText(), s,
					"Assertion failed : Score Sorting correct");
			i++;
		}
		logMessage("Assertion passed: Score Sorting correct in ascending order");
		Collections.reverse(sortedText);
		element("header_score").click();
		i = 0;
		for (String s : sortedText) {
			customAssert.customAssertEquals(elements("list_studentScores").get(i).getText(), s,
					"Assertion failed : Score Sorting correct");
			i++;
		}
		logMessage("Assertion passed: Score Sorting correct in descending order");
	}

	private void _verifySortingByName() {
		ArrayList<String> text = new ArrayList<String>();
		for (WebElement e : elements("list_studentNames")) {
			text.add(e.getText());
		}
		ArrayList<String> sortedText = new ArrayList<String>();
		sortedText = text;
		Collections.sort(sortedText);
		element("header_name").click();
		int i = 0;
		for (String s : sortedText) {
			customAssert.customAssertEquals(elements("list_studentNames").get(i).getText(), s,
					"Assertion failed : Name Sorting correct");
			i++;
		}
		logMessage("Assertion passed: Name Sorting correct in ascending order");
		Collections.reverse(sortedText);
		element("header_name").click();
		i = 0;
		for (String s : sortedText) {
			customAssert.customAssertEquals(elements("list_studentNames").get(i).getText(), s,
					"Assertion failed : Name Sorting correct");
			i++;
		}
		logMessage("Assertion passed: Name Sorting correct in descending order");
	}

	private void _verifySortingByDate() {
		ArrayList<String> text = new ArrayList<String>();
		for (WebElement e : elements("list_submissionDates")) {
			text.add(e.getText());
		}
		ArrayList<String> sortedText = new ArrayList<String>();
		sortedText = text;
		Collections.sort(sortedText);
		Collections.reverse(sortedText);
		element("header_date").click();
		int i = 0;
		for (String s : sortedText) {
			customAssert.customAssertEquals(elements("list_submissionDates").get(i).getText(), s,
					"Assertion failed : Date Sorting correct");
			i++;
		}
		logMessage("Assertion passed: Date Sorting correct in descending order");
		Collections.reverse(sortedText);
		element("header_date").click();
		i = 0;
		for (String s : sortedText) {
			customAssert.customAssertEquals(elements("list_submissionDates").get(i).getText(), s,
					"Assertion failed : Date Sorting correct");
			i++;
		}
		logMessage("Assertion passed: Date Sorting correct in ascending order");
	}

	public void clickOnClassStatistics() {
		element("link_classStatisticsOnResultPage").click();
		logMessage("Clicked on Class Statistics link");
		customAssert.customAssertEquals(element("txt_header").getText(), "Class Statistics",
				"Assertion failed : Score history link verified");
		logMessage("Assertion passed : Class Statistics link verified");
	}

	public void clickOnExcuseButton() {
		element("btn_xBtnText", "Excuse").click();
		logMessage("Clicked on Excuse button");
		waitForElementToDisappear("loader");
	}

	public void verifyCrossCorrespondingToStudent(String studentName) {
		hardWait(3);
		customAssert.customAssertEquals(element("txt_scoreAfterExcuse").getText(), "X",
				"Assertion Failed : Cross displayed in score field after excusing the student");
		logMessage("Assertion Failed : Cross displayed in score field after excusing the student");
	}

	public void verifyHtmlTagsNotDisplayedOnResultPage() {
		customAssert.customAssertFalse(areHtmlTagsDisplayed(element("div_mainSummaryFrameContentOnResultPage")),
				"Assertion Failed : " + "Html Tags are displayed on Result Page");
		logMessage("Assertion Passed : No Html Tags are displayed on Result Page");
	}

	/**
	 * Method which verifies the text in Flyer message when we are saving Blank
	 * Question
	 * 
	 */
	public void verifyFlyerTextMessageWhileSavingBlankQuetion(String flyerMessage) {
		waitForElementToBeVisible("txt_flyerError");
		hover(element("txt_flyerError"));
		customAssert.customAssertTrue(element("txt_flyerError").getText().contains(flyerMessage),
				"Toast Error message is NOT matching!!!");
		logMessage("Toast Message with error is DISPLAYED!!!");
	}

	/**
	 * Method which Saves a blank question in Question Editor
	 * 
	 */
	public void saveBlankQuestion() {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForElementToBeVisible("img_advancedFormatting");
		isElementDisplayed("link_properties");
		isElementDisplayed("link_points");
		switchToDefaultContent();
		element("btn_saveQuestionEditor").click();
		logMessage("Saved the blank question");
		verifyFlyerTextMessageWhileSavingBlankQuetion("Blank questions cannot be saved");
		waitForMsgToastToDisappear();
	}

	/**
	 * Method which verifies that Quiz does not contain any Question in it
	 * 
	 */
	public void verifyQuizHasNoQuestion(String noQuestionText) {
		waitForElementToBeVisible("txt_noQuestionMessage");
		customAssert.customAssertTrue(element("txt_noQuestionMessage").getText().equalsIgnoreCase(noQuestionText),
				"Quiz contains Mutiple Answer Questions!!!");
	}

	/**
	 * Method navigates no of Months back from calender
	 * 
	 */
	public void goMonthsBackDateInDatePicker(int noOfMonths) {
		for (int i = 0; i < noOfMonths; i++) {
			waitForElementToBeVisible("datePicker_goPrev");
			element("datePicker_goPrev").click();
		}
	}

	/**
	 * Method navigates no of Months forward from calender
	 * 
	 */
	public void goMonthsForwardDateInDatePicker(int noOfMonths) {
		for (int i = 0; i < noOfMonths; i++) {
			waitForElementToBeVisible("datePicker_goNext");
			element("datePicker_goNext").click();
		}
	}

	/**
	 * Method selects individual from Settings for dropdown
	 * 
	 */
	public void selectAssignedStudentFromSettingsFor(String studentName) {
		selectProvidedTextFromDropDown(element("dropdwn_settingFor"), "Add Individual");
		element("txtinput_SearchRoster").sendKeys(studentName);
		element("drpdwn_searchRoster", studentName).click();
		// selectProvidedTextFromDropDown(element("txtinput_SearchRoster"),
		// studentName);
		// element("txtinput_SearchRoster").sendKeys(studentName);
		hardWait(2);
		element("btn_Add_SearchRoster").click();
		// element("btn_closeSearchRoster").click();
		waitForLoaderToDisappear();
		hardWait(2);
	}

	/**
	 * Select visibility from from Setting Tab
	 */
	public void selelctVisibiltyOptionInSettingtab(String visibiltyName) {
		element("radiobtn_visibility", visibiltyName).click();
	}

	public void selelctVisibiltyOptionInSettingtabForQuiz(String visibiltyName) {
		element("radiobtn_visibilityQuiz", visibiltyName).click();
	}

	public String enterTimeOf4MinLater() {
		String time = element("txtinput_assignTime").getAttribute("value").split(" ")[0];
		String meridian = element("txtinput_assignTime").getAttribute("value").split(" ")[1];
		int minutes = Integer.parseInt(time.split(":")[1]);
		int hours = Integer.parseInt(time.split(":")[0]);
		if (minutes + 4 < 60) {
			minutes = minutes + 4;
		} else {
			minutes = (minutes + 4) % 60;
			hours = hours + 1;
		}
		if (hours > 12) {
			if (meridian.equals("AM"))
				meridian = "PM";
			else
				meridian = "AM";
		}
		String timeAfter4Mins = hours + ":" + minutes + " " + meridian;
		fillText("txtinput_assignTime", timeAfter4Mins);
		System.out.println(timeAfter4Mins);
		element("btn_calanderClose").click();
		return timeAfter4Mins;
	}

	/**
	 * Enter assignment date in textbox
	 */
	public void enterDateInTextBox() {
		hardWait(2);
		String assignDate = element("txtinput_assignDueDate").getAttribute("value");
		fillText("txtinput_assignDueDate", assignDate);
	}

	/**
	 * Select random questions
	 * 
	 * @param numberOfQuestionsToBeAdded
	 */
	public void addRandomQuestions(String numberOfQuestionsToBeAdded) {
		waitForElementToBeVisible("txt_questionCount");
		element("drpdown_selectMenu").click();
		waitForElementToBeVisible("lnk_SelectRandomQuestionInSelectMenu");
		element("lnk_SelectRandomQuestionInSelectMenu").click();
		enterNumberOfRandomQuestionInPopUpTextInput(numberOfQuestionsToBeAdded);

	}

	/**
	 * Enter number of question to be select randomly
	 * 
	 * @param numberOfQuestions
	 */
	public void enterNumberOfRandomQuestionInPopUpTextInput(String numberOfQuestions) {
		waitForElementToBeVisible("txtinput_enterNumberOfQuestionsInPopUp");
		fillText("txtinput_enterNumberOfQuestionsInPopUp", numberOfQuestions);
		element("btn_selectQuestions").click();
	}

	/**
	 * Clicks on Add To Poll Button
	 */
	public void clickOnAddToPool() {
		waitForElementToBeVisible("btn_addToPool");
		element("btn_addToPool").click();
	}

	/**
	 * Clicks on Add To new Pool
	 */
	public void clickOnAddToNewPool() {
		waitForElementToBeVisible("lnk_addToNewPool");
		element("lnk_addToNewPool").click();
	}

	/**
	 * Creates a Question Pool
	 * 
	 * @param poolTitle
	 * @param numberOFQuestionToPull
	 */
	public void createQuestionPool(String poolTitle, String numberOFQuestionToPull) {
		waitForElementToBeVisible("txtinput_poolTitle");
		fillText("txtinput_poolTitle", poolTitle);
		fillText("txtinput_pullQuestionsInPoll", numberOFQuestionToPull);
		element("btn_createPool").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}

	/**
	 * Verifies Pool is created
	 * 
	 * @param poolName
	 */
	public void verifyPoolIsCreated(String poolName) {
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		isElementDisplayed("txt_poolTitle", poolName);
	}

	/**
	 * Method which creates "Multiple Choice" type question & adds it to Quiz
	 * 
	 */
	public void addMultipleChoiceQuestionToQuiz() {
		switchToDefaultContent();
		waitForElementToBeVisible("iframe_easyXDMDefault");
		if (elements("iframe_easyXDMDefault").size() != 0) {
			switchToFrame(element("iframe_easyXDMDefault"));
		}

		waitForLoaderToDisappear();
		waitForElementToBeVisible("txtarea_QuestionTextArea");
		isElementDisplayed("link_properties");
		isElementDisplayed("link_points");
		element("txtarea_QuestionTextArea").click();
		element("txtarea_QuestionTextArea").sendKeys(
				"The process of removing the deficiencies " + "and loopholes in the data is called as");
		element("txtarea_QuestionTextArea").sendKeys(Keys.RETURN);
		element("input_choice1").sendKeys("Aggregation of data");
		element("input_choice1").sendKeys(Keys.RETURN);
		element("input_choice2").sendKeys("Extracting of data");
		element("input_choice2").sendKeys(Keys.RETURN);
		element("input_choice3").sendKeys("Cleaning up of data");
		element("input_choice3").sendKeys(Keys.RETURN);
		element("input_choice4").sendKeys("Loading of data");
		element("input_choice4").sendKeys(Keys.RETURN);
		element("input_choice5").sendKeys("Compression of data");
		waitForElementToBeVisible("input_choice3");
		element("btn_radioChoice3").click();
		switchToDefaultContent();
		element("btn_saveQuestionEditor").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Method which clicks on 'Expand Editor' link
	 * 
	 */
	public void clickOnExpandEditor() {
		waitForElementToBeVisible("lnk_expandEditor");
		element("lnk_expandEditor").click();
		logMessage("Clicked on 'Expand Editor' link");
	}

	/**
	 * Method which verifies the presence of Question Editor Icon on the title
	 * of the page
	 * 
	 */
	private boolean _verifiesQuestionEditorIcon() {
		waitForElementToBeVisible("txt_questionEditor");
		String valueCSS = element("txt_questionEditor").getCssValue("background-image");

		if (valueCSS.contains("brainhoney")) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method which validates the presence of Question Editor Icon on the Title
	 * of the page before & after clicking on 'Expand Editor' link & compares
	 * the X & Y coordinates of HTS Editor Links
	 * 
	 */
	public void clickOnExpandEditorAndValidatesQuestionEditorIcon() {
		int locationX = getLocationXCoordinateOfHtsEditorPanel();
		int locationY = getLocationYCoordinateOfHtsEditorPanel();
		System.out.println("Location(X -Coordinates) of HTS Editor Panel: " + locationX);
		System.out.println("Location(Y -Coordinates) of HTS Editor Panel: " + locationY);

		waitForLoaderToDisappear();
		clickOnExpandEditor();

		int locationXNew = getLocationXCoordinateOfHtsEditorPanel();
		int locationYNew = getLocationYCoordinateOfHtsEditorPanel();
		System.out.println("Location(X -Coordinates) of HTS Editor Panel after clicking on Expand Editor: "
				+ locationXNew);
		System.out.println("Location(Y -Coordinates) of HTS Editor Panel after clicking on Expand Editor: "
				+ locationYNew);

		if ((locationX > locationXNew) && (locationY > locationYNew)) {
			logMessage("HTS Editor Panel is MOVED to the same line as of 'Question Editor' Title!!!");
		} else {
			Assert.fail("Assertion Failed: HTS Editor Panel is NOT moved to the same line as of 'Question Editor' Title!!!");
		}

		customAssert.customAssertFalse(_verifiesQuestionEditorIcon(), "Question Editor Icon is VISIBLE!!!");
		logMessage("Question Editor is Expanded successfully!!!");
	}

	/**
	 * Method which get the location i.e., X coordinates of HTS Editor Panel
	 * link
	 * 
	 * @return locationXOfEditorPanel
	 */
	public int getLocationXCoordinateOfHtsEditorPanel() {
		int locationXOfEditorPanel = element("link_htsEditorPanel").getLocation().getX();
		return locationXOfEditorPanel;
	}

	/**
	 * Method which get the location i.e., Y coordinates of HTS Editor Panel
	 * link
	 * 
	 * @return locationYOfEditorPanel
	 */
	public int getLocationYCoordinateOfHtsEditorPanel() {
		int locationYOfEditorPanel = element("link_htsEditorPanel").getLocation().getY();
		return locationYOfEditorPanel;
	}

	/**
	 * Method which validates the presence of Question Editor Icon on the Title
	 * of the page before & after clicking on 'Collapse Editor' link & compares
	 * the X & Y coordinates of HTS Editor Links
	 * 
	 */
	public void clickOnCollapseEditorAndValidatesQuestionEditorIcon() {
		int locationX = getLocationXCoordinateOfHtsEditorPanel();
		int locationY = getLocationYCoordinateOfHtsEditorPanel();
		System.out.println("Location(X -Coordinates) of HTS Editor Panel: " + locationX);
		System.out.println("Location(Y -Coordinates) of HTS Editor Panel: " + locationY);

		waitForLoaderToDisappear();
		clickOnCollapseEditor();

		int locationXNew = getLocationXCoordinateOfHtsEditorPanel();
		int locationYNew = getLocationYCoordinateOfHtsEditorPanel();
		System.out.println("Location(X -Coordinates) of HTS Editor Panel after clicking on Collapse Editor: "
				+ locationXNew);
		System.out.println("Location(Y -Coordinates) of HTS Editor Panel after clicking on Collapse Editor: "
				+ locationYNew);

		if ((locationX < locationXNew) && (locationY < locationYNew)) {
			logMessage("HTS Editor Panel is MOVED BACK to the same line as it was Earlier!!!");
		} else {
			Assert.fail("Assertion Failed: HTS Editor Panel is NOT moved to the same line as it was Earlier!!!");
		}

		customAssert.customAssertTrue(_verifiesQuestionEditorIcon(), "Question Editor Icon is NOT Visible!!!");
		logMessage("Question Editor is Collapsed successfully!!!");
	}

	/**
	 * Method which clicks on 'Collapse Editor' link
	 * 
	 */
	public void clickOnCollapseEditor() {
		waitForElementToBeVisible("lnk_collapseEditor");
		element("lnk_collapseEditor").click();
		logMessage("Clicked on 'Collapse Editor' link");
	}

	/**
	 * Method which verifies that Advanced Question is created
	 * 
	 * @param newQuestionTitle
	 *            - the Title of Newly Created Question
	 * 
	 */
	private void _verifyTitleLinkOfNewQuestion(String newQuestionTitle) {
		waitForElementToBeVisible("txt_editorLink");
		if (element("txt_editorLink").getText().contains(newQuestionTitle)) {
			logMessage("New Question Title is displayed as Editor Link");
		} else {
			Assert.fail("New Question Title is NOT displayed as Editor Link");
		}
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Method which verifies whether the Newly created Question is added under
	 * selected questions in Quiz
	 * 
	 * @param selectedQuestionTitle
	 *            - the title of Selected Question under available Questions in
	 *            the Quiz
	 */
	private void _verifyNewQuestionIsCreatedUnderQuizEditorQuestions(String selectedQuestionTitle) {
		int count = 0;

		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForElementToBeVisible("btn_Bold");
		logMessage("Question Editor is loaded completely!!!");
		switchToDefaultContent();

		for (WebElement elem : elements("list_availableQuizQuestions")) {
			if (elem.getText().equalsIgnoreCase(selectedQuestionTitle)) {
				logMessage("Newly created Question is added to the List of questions in Quiz");
				count++;
			}
		}
		if (count == 0) {
			Assert.fail("Newly created Question is NOT ADDED to the List of questions in Quiz");
		}
	}

	/**
	 * Method which validates whether new Question is created
	 * 
	 * @param titleText
	 *            the Title/Header of Newly Created Question
	 * @param selectedTitle
	 *            the title of Selected Question under available Questions in
	 *            the Quiz
	 * 
	 */
	public void validateNewQuestionIsCreated(String titleText, String selectedTitle) {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		_verifyTitleLinkOfNewQuestion(titleText);
		_verifyNewQuestionIsCreatedUnderQuizEditorQuestions(selectedTitle);
	}

	/**
	 * Method which allows the Student to submit Assignment until grace period
	 * 
	 * @param durationType
	 *            the Type of Duration for Grace Period
	 * @param periodDuration
	 *            the Duration of Grace Period
	 * 
	 */
	public void allowLateSubmissionUntilGracePeriod(String periodDuration, String durationType) {
		element("chkbox_allowLateSubmissions").click();
		logMessage("Instructor selects Allow Late Submissions Checkbox");
		waitForElementToBeVisible("txtinput_gracePeriodDuration");
		element("txtinput_gracePeriodDuration").clear();
		element("txtinput_gracePeriodDuration").sendKeys(periodDuration);
		// Select durationDropdown = (Select)
		// element("drpdown_gracePeriodDurationType");
		// durationDropdown.selectByValue("Day");
		selectProvidedTextFromDropDown(element("drpdown_gracePeriodDurationType"), durationType);
		logMessage("Instructor enters the Grace Period for Late submission of Assignment");
	}

	public void verifyGracePeriod(String periodDuration, String durationType) {
		isElementDisplayed("chkbox_allowLateSubmissions");
		customAssert.customAssertTrue(element("chkbox_allowLateSubmissions").isSelected(),
				"Assertion failed: Grace period checkbox is not selected");
		logMessage("Assertion passed : Grace period checkbox selected");
		customAssert.customAssertEquals(element("txtinput_gracePeriodDuration").getAttribute("value"), periodDuration,
				"Assertion failed : Grace period ducration is not correct");
		logMessage("Assertion passed : Garce period duration is correct");
		customAssert.customAssertEquals(element("drpdown_sameDurationType").getText().trim(), durationType,
				"Assertion failed: Grace period duration type is not correct");
		logMessage("Assertion passed : Grace period duration type is correct");
	}

	/**
	 * Verifies scoring achieved and Tick image is NOT displayed for the
	 * assignment in the FandE Header section
	 * 
	 * @param pastDueDateAssignmentScore
	 *            - score of Past due date Assignment
	 */
	public void verifyScoringIsNotDisplayed(String pastDueDateAssignmentScore) {
		if (elements("img_itemSubmitted").size() != 0) {
			logMessage("Scoring Item submitted image is DISPLAYED on FandE Page");
			customAssert.customAssertTrue(false,
					"Assertion Failed : Scoring Item submitted image is DISPLAYED on FandE Page");
		} else {
			logMessage("Assertion Passed : Scoring Item submitted image is NOT DISPLAYED on FandE Page!!!");
		}

		waitForElementToBeVisible("txt_achievedPoints");
		WebElement achievedPoints = element("txt_achievedPoints");
		String actualScoring = achievedPoints.getText();
		String expectedScoring = pastDueDateAssignmentScore + " / " + "10 pts";
		customAssert.customAssertEquals(actualScoring, expectedScoring,
				"Assertion Failed : Submitted Item's scoring is incorrectly displayed on FandE Page. " + "Actual='"
						+ actualScoring + "', Expected='" + expectedScoring + "'");
		logMessage("Assertion Passed : '" + pastDueDateAssignmentScore
				+ "' assignment marks is DISPLAYED on FandE Page!!!");

	}

	/**
	 * Method which fetches the System's time & then enters time
	 * 
	 * @param additionalTime
	 *            - Time to be added to the current time
	 */
	public String enterCurrentTime(int additionalTime) {
		DateFormat timeFormat = new SimpleDateFormat("HH:mm a");
		Date date = new Date();
		String newTime;
		String currentTime = timeFormat.format(date);
		String hour = currentTime.substring(0, 2).replaceFirst("^0+(?!$)", "");
		logMessage(hour);
		/*
		 * @SuppressWarnings("unused") String minutes = currentTime.substring(3,
		 * 5); logMessage(minutes);
		 */
		String marker = currentTime.substring(6, 8);
		logMessage(marker);
		int counter = Integer.parseInt(hour) + additionalTime;
		if (counter > 12) {
			counter = counter % 12;
			if (marker.equalsIgnoreCase("PM")) {
				marker = "AM";
			} else {
				marker = "PM";
			}
		}
		String hourNew = String.valueOf(counter);
		System.out.println("Modified Hour from current time: " + hourNew);
		hardWait(1);
		element("txtinput_assignTime").click();
		waitForElementToBeVisible("icon_close");
		element("txt_selectHrMarker", marker).click();
		element("txt_selectHour", hourNew).click();
		element("txt_selectMinutes", "55").click();
		hardWait(2);
		logMessage("User selects the Modified Due Time of assigned Quiz for An Individual: " + hourNew + ":55 "
				+ marker);
		element("icon_close").click();
		newTime = hourNew + ":55 " + marker;
		return newTime;
	}

	/**
	 * Change Question Answer display setting in setting tab
	 * 
	 * @param displaySetting
	 * @param checkedRadioButton
	 * 
	 */
	public void changeQuestioAnswerDisplayInSettingTab(String displaySetting, String checkedRadioButton) {
		element("radiobtn_displayQuestionAnswerSetting", displaySetting, checkedRadioButton).click();
	}

	/**
	 * Method which verifies user is on 'Setting' Tab
	 * 
	 * @param settingsPageTitle
	 */
	public void verifyUserIsOnSettingsPage(String settingsPageTitle) {
		isElementDisplayed("txt_settingsPageTitle");
		customAssert.customAssertEquals(element("txt_settingsPageTitle").getText(), settingsPageTitle,
				"Assertion Failed: Settinga Page Title is not correct!!!");
		logMessage("Assertion Passed: User is on Settings Page, Verified Page title visibility and Title text to be: "
				+ settingsPageTitle);
	}

	/**
	 * Verifies text of attempt display on quiz start page
	 * 
	 * @param numberOfAttempt
	 */
	public void verifiesTextOfAttemptInPoliciesOnQuizStartPage(String numberOfAttempt) {
		customAssert.customAssertTrue(element("txt_attemptInPolicies").getText().contains(numberOfAttempt),
				"Assertion Failed : Number of attempt not correct");
		logMessage("Displayed : Number of attempt=" + numberOfAttempt);
	}

	/**
	 * Method which verifies user is on 'Questions' Tab
	 * 
	 * @param settingsPageTitle
	 */
	public void verifyUserIsOnQuestionsPage(String questionsPageTitle) {
		isElementDisplayed("txt_questionsPageTitle");
		customAssert.customAssertEquals(element("txt_questionsPageTitle").getText(), questionsPageTitle,
				"Assertion Failed: Questions Page Title is not correct!!!");
		logMessage("Assertion Passed: User is on Questions Page, Verified Page title visibility and Title text to be: "
				+ questionsPageTitle);
	}

	/**
	 * Method which edit the newly created Question by hovering on 'Preview'
	 * link & then clicking on 'Edit' link
	 * 
	 */
	public void editNewlyCreatedQuestion() {
		waitForElementToBeVisible("link_previewForAddedQuestion");
		hover(element("link_previewForAddedQuestion"));
		element("lnk_editQuestion").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Click on properties in question editor
	 */
	public void clickOnProperties() {
		element("lnk_properties").click();
	}

	/**
	 * Change graphical question title
	 * 
	 * @param newTitle
	 */
	public void changeQuestionTitle(String newTitle) {
		clickOnProperties();
		isElementDisplayed("lable_questionProperties");
		sendTextInTextbox("txtinput_graphicQuestionTitle", newTitle);
		element("btn_close").click();
		logMessage("User change question title");
		isElementDisplayed("lnk_properties");

	}

	/**
	 * Send input to any text box
	 * 
	 * @param elementName
	 * @param text
	 */
	public void sendTextInTextbox(String elementName, String text) {
		element(elementName).click();
		element(elementName).clear();
		element(elementName).sendKeys(text);
	}

	// /**
	// * Draw grap question
	// */
	// public void drawGraphQuestion() {
	// Mouse mouse = new DesktopMouse();
	// ScreenRegion s = new DesktopScreenRegion();
	// ImageTarget imageTarget;
	// String currentDir;
	// //ScreenRegion r;
	//
	// try {
	// currentDir = System.getProperty("user.dir");
	// URL imageURL;
	// imageURL = new URL("file:///" + currentDir +
	// "/src/test/resources/testdata/");
	// imageTarget = new ImageTarget(new URL(imageURL+"select_Box.png"));
	// ScreenRegion r = s.wait(imageTarget, 5000);
	// r = s.find(imageTarget);
	// mouse.click(r.getCenter());
	// imageTarget = new ImageTarget(new URL(imageURL+"XandYArea.png"));
	// r = s.find(imageTarget);
	// mouse.click(r.getCenter());
	// hardWait(1);
	// int x = (int) MouseInfo.getPointerInfo().getLocation().getX();
	// int y = (int) MouseInfo.getPointerInfo().getLocation().getY();
	// hardWait(1);
	// Robot ro = new Robot();
	// ro.mouseMove(x+10, y+10);
	// ro.mousePress(InputEvent.BUTTON1_MASK);
	// ro.mouseRelease(InputEvent.BUTTON1_MASK);
	// hardWait(1);
	// logMessage("draw Graph Question");
	// } catch (MalformedURLException e) {
	// e.printStackTrace();
	// } catch (AWTException e) {
	// e.printStackTrace();
	// }
	// }

	/**
	 * Click on save button in question editor
	 */
	public void clickOnSaveInQuestionEditor() {
		element("btn_saveEdit").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Verifies question title in question tab
	 * 
	 * @param questionTitle
	 */
	public void verifiesQuestionIsCreated(String questionTitle) {
		isElementDisplayed("txt_questionTitle", questionTitle);
	}

	/**
	 * Click on preview link
	 */
	public void previewCreatedQuestion() {
		element("lnk_previewQuestion").click();
		waitForLoaderToDisappear();
	}

	/**
	 * Verifies question title on question preview popup
	 * 
	 * @param questionTitle
	 */
	public void verifyQuestionTitleOnPreviewWidow(String questionTitle) {
		isElementDisplayed("txt_titleOnPreviewWindow");
		customAssert.customAssertEquals(element("txt_titleOnPreviewWindow").getText(), questionTitle,
				"Assertion Failed : Title does not match");
		logMessage("Question title appears on the preview window");
	}

	/**
	 * Clicks 'Done Editing' Button then 'Home' Button
	 */
	public void clickDoneEditingAndHomeButton() {
		clickOnDoneEditingButton();
		waitForLoaderToDisappear();
		clickOnHomeButton();
		waitForLoaderToDisappear();
	}

	/**
	 * verify flashcontent is present on whole page
	 * 
	 * @param imageName
	 */
	// public void verifyFlashContent(String imageName)
	// {
	// String currentDir;
	// URL imageURL;
	// ImageTarget imageTarget;
	// ScreenRegion s = new DesktopScreenRegion();
	// try{
	// currentDir = System.getProperty("user.dir");
	//
	// imageURL = new URL("file:///" + currentDir +
	// "/src/test/resources/testdata/");
	// imageTarget = new ImageTarget(new URL(imageURL+"XandYArea.png"));
	// ScreenRegion r = s.wait(imageTarget, 5000);
	// r = s.find(imageTarget);
	// customAssert.customAssertTrue(!r.equals(""),
	// "Assertion Failed : Question does't have any content.");
	// }
	// catch(Exception e){
	//
	// }
	// }

	/**
	 * Click close button in preview PopUp
	 */
	public void closeQuestionPreview() {
		element("btn_previewClose").click();
	}

	/**
	 * Verify specified Tab is Active
	 */
	public void verifyTabActive(String tabName) {
		WebElement el;
		if (tabName.equals("Basic Info")) {
			el = element("btn_basicInfoTab");
		} else if (tabName.equals("Assignment")) {
			el = element("btn_assignmentTab");
		} else if (tabName.equals("Settings")) {
			el = element("btn_settingsTab");
		} else if (tabName.equals("Questions")) {
			el = element("btn_questionsTab");
		} else {
			System.out.println("Incorrect Tab Name provided");
			return;
		}
		String className = el.getAttribute("class");
		if (className.indexOf("active") < 0) {
			customAssert.customAssertTrue(false, "Assertion Failed : Tab '" + tabName + "' is not active");
		} else {
			logMessage("Assertion Passed : Tab '" + tabName + "' is active");
		}
	}

	/**
	 * Go to Assignment Tab and Assign Assignment
	 * 
	 * @param assignmentScore
	 * @param date
	 */
	public void assignAssignment(String assignmentScore, String date) {
		clickAssignmentTab();
		selectDateInDatePicker(date);
		fillGradePointsForAssignment(assignmentScore);
		clickAssignButtonFromAssignmentTab();
	}

	/**
	 * Go to Assignment Tab and Assign Assignment with Grace
	 * 
	 * @param assignmentScore
	 * @param date
	 * @param grace
	 */
	public void assignAssignmentWithGrace(String date, String gradePoints, String periodDuration, String durationType) {
		clickAssignmentTab();
		selectDateInDatePicker(date);
		waitForLoaderToDisappear();
		allowLateSubmissionUntilGracePeriod(periodDuration, durationType);
		fillGradePointsForAssignment(gradePoints);
		clickAssignButtonFromAssignmentTab();
	}

	/**
	 * Go to Questions Tab and Add Question by previewing
	 * 
	 * @param assignmentScore
	 */

	public void previewAndAddQuestions(String chapterName, String questionBank, String poolTitle, String poolCount) {
		clickQuestionsTab();
		clickChapterOneFromQuestionBank(chapterName);
		clickTestBankOneFromChapterOne(questionBank);
		checkFirstQuestionFromQuestionsAvailable();
		clickPreviewFirstQuestion();
		clickAddToThisAssessment();
		clickAddToNewPool();
		enterPoolTitle(poolTitle);
		enterPoolCount(poolCount);
		clickCreatePoolButton();
		waitForLoaderToDisappear();
		waitForLoaderToAppearAndDisappear();
	}

	public void clickPreviewFirstQuestion() {
		hardWait(2);
		jse.executeScript("document.getElementsByClassName('preview-available-question displayquestionmenu')[0].click();");
		logMessage("Preview button clicked");
	}

	public void clickAddToThisAssessment() {
		waitForElementToBeVisible("btn_addtothisassessment");
		hardWait(2);
		jse.executeScript("document.getElementsByClassName('add-to-pool-preview-quiestion-btn-wrapper ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only')[0].click();");
		logMessage("Add To This Assessment button clicked");
	}

	public void clickAddToNewPool() {
		waitForElementToBeVisible("link_addtonewpool", "2");
		hardWait(2);
		element("link_addtonewpool", "2").click();
		logMessage("Add To New Pool button clicked");
	}

	public void enterPoolTitle(String poolTitle) {
		waitForElementToBeVisible("txt_pooltitle1");
		hardWait(2);
		element("txt_pooltitle1").sendKeys(poolTitle);
		logMessage("User Entered Pool Title");
		verifyElementNotDisplayed("link_addtonewpool", "1", "");
	}

	public void enterPoolCount(String poolCount) {
		waitForElementToBeVisible("txt_poolcount1");
		hardWait(2);
		element("txt_poolcount1").sendKeys(poolCount);
		logMessage("User Entered Pool Count");
	}

	public void clickCreatePoolButton() {
		waitForElementToBeVisible("btn_createpool1");
		hardWait(2);
		element("btn_createpool1").click();
		logMessage("Create Pool button clicked");
	}

	/**
	 * Go to Questions Tab and Add Question
	 * 
	 * @param assignmentScore
	 */
	public void addQuestions(String chapterName, String questionBank) {
		clickQuestionsTab();
		clickChapterOneFromQuestionBank(chapterName);
		clickTestBankOneFromChapterOne(questionBank);
		checkFirstQuestionFromQuestionsAvailable();
		clickAddButtonInQuestions();
		verifyQuestionAddedToAssignment();
		//removeAllQuestion();
		//checkFirstQuestionFromQuestionsAvailable();
		//clickAddButtonInQuestions();
	}

	public void createQuestionsVerifyNoErrorOccur() {

		element("btn_gearbox").click();
		waitForElementToBeVisible("lnk_multipleChoice");
		element("lnk_multipleChoice").click();
		waitForLoaderToDisappear();
		verifyElementNotDisplayed("container_error", "LPT-239");
		waitForLoaderToDisappear();
		element("btn_backToQuestionBank").click();
		waitForLoaderToDisappear();
		element("btn_gearbox").click();
		waitForElementToBeVisible("lnk_multipleChoice");
		element("lnk_essay").click();
		waitForLoaderToDisappear();
		verifyElementNotDisplayed("container_error", "LPT-239");
		waitForLoaderToDisappear();
		element("btn_backToQuestionBank").click();
		waitForLoaderToDisappear();
		element("btn_gearbox").click();
		waitForElementToBeVisible("lnk_multipleChoice");
		element("lnk_advancedQuestion").click();
		waitForLoaderToDisappear();
		verifyElementNotDisplayed("container_error", "LPT-239");

	}

	public void fillShortAnswerQuestion(String question) {
		waitForElementToBeVisible("txtarea_shortAnswerQuestion");
		isElementDisplayed("link_properties");
		isElementDisplayed("link_points");
		fillText("txtarea_shortAnswerQuestion", question);
	}

	public void fillShortAnswerAnswer(String answer) {
		waitForElementToBeVisible("txtinput_shortAnswerAnswer");
		fillText("txtinput_shortAnswerAnswer", answer);
	}

	public void clickQuestionEditorSaveButton() {
		waitAndClick("btn_saveQuestionEditor");
	}

	public void verifyQuestionEditorPreviewLinkDisplayed() {
		isElementDisplayed("link_questionEditorPreview");
	}

	public void switchToQuestionEditorIframe() {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
	}

	/**
	 * Verify that Toast message is displayed and is correct
	 */
	public void verifyToastMessageAppears(String msgSubstring) {
		waitForMsgToastToAppear(msgSubstring);
		waitForMsgToastToDisappear();
	}

	public void clickAddToCourseButton() {
		scrollDown(element("btn_addToCourse"));
		element("btn_addToCourse").click();
		hardWait(1);
		waitForMsgToastToDisappear();
	}

	public void clickClearDueDateLink() {
		waitAndClick("link_clearDueDate");
	}

	public void verifyInvalidDateTimeMessageDisplayed() {
		isElementDisplayed("txt_invalidDateMessage");
		isElementDisplayed("txt_invalidTimeMessage");
	}

	public void deleteHighlight() {
		// switchToDocumentBodyFrame();
		// JavascriptExecutor js = (JavascriptExecutor) driver;
		switchToDefaultContent();
		switchToDocumentBodyFrame();
		hardWait(1);
		//
		// Actions act = new Actions(driver);
		// act.moveToElement(element("txt_ebookTitleHighlight"),1,1).build().perform();
		// act.click().build().perform();
		// hardWait(4);
		// wait.waitForElementToBeClickable(element("btn_deleteHighlight"));
		// isElementDisplayed("btn_deleteHighlight");
		// switchToDefaultContent();

		// switchToDocumentBodyFrame();
		waitAndClick("txt_ebookTitle1");
		waitAndClick("btn_deleteHighlight");
		// js.executeScript("document.getElementById('document-body-iframe').contentDocument.getElementById('highlight-widget-delete').click();");
		switchToDefaultContent();
		// switchToDocumentBodyFrame();
		// element("btn_deleteHighlight").click();

	}

	public void clickEbookChapterTitle() {
		switchToDefaultContent();
		waitForElementToBeVisible("frame_document");
		switchToFrame(element("frame_document"));
		waitAndClick("txt_ebookTitle");
	}

	public void verifyQuestionDeliverySelected() {
		waitForElementToBeVisible("checkbox_questionDelivery");
		boolean checkbox = element("checkbox_questionDelivery").isSelected();
		customAssert.customAssertTrue(checkbox, "checkBox is not selected");
		logMessage("All Question are selected by default");
	}

	public void verifyInvalidDateTimeMessageNotDisplayed() {
		verifyElementNotDisplayed("txt_invalidDateMessage", "");
		verifyElementNotDisplayed("txt_invalidTimeMessage", "");
	}

	public void clickFullCreditCheckbox() {
		element("chkbox_extraCredit").click();
		logMessage("Clicked on Extra credit check box");
	}

	public void selectCalculationType(String calculationType) {
		selectProvidedTextFromDropDown(element("drpdown_calculationType"), calculationType);
		logMessage("Selected " + calculationType + " as calculation type");
	}

	public void verifySelectedTextInDropdown(String calculationType) {
		String text = verifySelectedTextInDropdown(element("drpdown_calculationType"));
		customAssert
				.customAssertTrue(text.contains(calculationType),
						"Dropdown Value for calculation type is not Correct. Expected:" + calculationType
								+ "but found:" + text);
		logMessage("Assertion Passed: Calculation type selected is correct");
	}

	public void verifyScoreInDecimal(String scoreInDecimal, String scoreInDecimal2) {
		customAssert.customAssertTrue(
				element("txt_score").getText().trim().equals(scoreInDecimal)
						|| element("txt_score").getText().trim().equals(scoreInDecimal2),
				"Assertion Failed: Scores are in decimal upto 2 decimal point");
		logMessage("Assertion Passed: Scores are in decimal upto 2 decimal point");
	}

	public void moveEbookTitleWindow() {
		switchToDefaultContent();
		waitForElementToBeVisible("div_referenceWindowTitlebar");
		hardWait(2);
		Actions builder = new Actions(driver);
		Action dragAndDrop = builder.dragAndDropBy(element("div_referenceWindowTitlebar"), 30, 30).build();
		dragAndDrop.perform();
		hardWait(2);
	}

	public void verifyEbookTitleWindowDisplayed() {
		isElementDisplayed("div_referenceWindowTitlebar");
	}

	public void switchToDocumentBodyIframe() {
		switchToDefaultContent();
		waitForElementToBeVisible("frame_document");
		switchToFrame(element("frame_document"));
	}

	public void attemptVideoToolkitActivity() {
		switchToDocumentBodyIframe();
		waitAndClick("lnk_beginVideoAssessmentQuiz");
		hardWait(1);
		List<WebElement> answer1 = elements("radiobtn_listAnswerOptions", "1");
		answer1.get(0).click();
		element("btn_submitAnswer", "1").click();
		hardWait(1);
		List<WebElement> answer2 = elements("radiobtn_listAnswerOptions", "2");
		answer2.get(0).click();
		element("btn_submitAnswer", "2").click();
		hardWait(1);
		List<WebElement> answer3 = elements("radiobtn_listAnswerOptions", "3");
		answer3.get(0).click();
		element("btn_submitAnswer", "3").click();
		hardWait(2);
		handleAlert();

	}

	public void verifyHomeButtonNotDisplayed() {
		verifyElementNotDisplayed("btn_home", "");
	}

	public void verifyAssignmentLabelNotDisplayed(String assignmentName) {
		customAssert.customAssertTrue(verifyElementNotDisplayed("txt_fneTitle1", assignmentName),
				"Assignment name is still displayed, user is not on homepage");
		logMessage("User has navigated to home page");
	}

	public void clickLinkOfLinkActivityAndVerify(String pageTitle) {
		waitAndClick("link_linkLinkAssignment");
		hardWait(3);
		changeWindow(1);
		customAssert.customAssertEquals(driver.getTitle(), pageTitle, "Assertion Failed : Clicking Link of "
				+ "Link Assignment does not open correct link");
		closeWindow();
		changeWindow(0);
	}

	public void clickLinkOfLinkActivityAndVerifyWhenNoHttp(String pageTitle) {
		waitAndClick("link_linkLinkAssignment");
		hardWait(3);
		changeWindow(1);
		wait.waitForPageToLoadCompletely();
		customAssert.customAssertTrue(driver.getCurrentUrl().contains("qa.macmillanhighered.com/launchpad/myers10e"),
				"Assertion Failed : Clicking Link of " + "Link Assignment opens correct link even without http");
		closeWindow();
		changeWindow(0);
	}

	public void verifyChangesLostSaveButtonDisplayed() {
		hardWait(2);
		isElementDisplayed("btn_changesLostSave");
	}

	public void clickChangesLostSaveButton() {
		element("btn_changesLostSave").click();
		hardWait(2);
	}

	public void verifyChangesLostSaveButtonNotDisplayed() {
		waitForMsgToastToDisappear();
		hardWait(2);
		verifyElementNotDisplayed("btn_changesLostSave");
	}

	public void clickDatePickerMonthYear() {
		waitAndClick("datepicker_month");
	}

	public void selectMonthFromDatePickerMonthList(String currMonth) {
		waitAndClick("datepicker_monthSelect", currMonth);
		hardWait(2);
	}

	public void verifyDateFieldValue() {
		String actualVal = executeJavascript("return document.getElementById('settingsAssignDueDate').value;")
				.toString();
		customAssert.customAssertEquals(actualVal, "", "Assertion Failed : Date Field value is incorrect");
	}

	public void attemptRandomHomeWorkQuestionsFromMultipleChoiceQuiz(int totalQuestions) {
		switchToTopWindow();
		clickStartTheHomeworkButton();
		hardWait(3);
		switchToCourseContentFrame();

		for (int i = 1; i <= 5; i++) {
			waitForQuestionToLoad();
			int j = 1;
			int randomOpt = 1 + (int) (Math.random() * 4);
			if (randomOpt > 4)
				randomOpt = 4;
			waitAndClick("radiobtn_anyMCQOption", Integer.toString(j), Integer.toString(randomOpt));
			clickSubmit();
			if (i == 5) {
				clickDoneButtonAfterSaveQuiz();
				break;
			} else {
				clickStartNextQuestion();
			}
		}

		switchToTopWindow();
		
		clickOnDoneButtonUsingJScript();
		handleAlert();
		switchToDefaultContent();
		//waitTillSuccessullySubmitted();
		logMessage("Attempted HomeWork Assignment");
	}

	public void clickOnDoneButtonUsingJScript(){
		switchToDefaultContent();
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('fne-done').click();");
		logMessage("User Clicked on Done button");
	}
	
	public void attemptRandomQuestionsFromMultipleChoiceQuiz(int totalQuestions) {
		switchToTopWindow();
		clickStartQuizButton();
		hardWait(3);
		switchToCourseContentFrame();
		// int randomQ = 1 + (int)(Math.random() * totalQuestions);
		// if (randomQ > totalQuestions) randomQ = totalQuestions;

		for (int i = 1; i <= 5; i++) {
			int randomOpt = 1 + (int) (Math.random() * 4);
			if (randomOpt > 4)
				randomOpt = 4;
			waitAndClick("radiobtn_anyMCQOption", Integer.toString(i), Integer.toString(randomOpt));
		}
		clickSubmit();
		submitYesInConfirmDialogBox();
		clickDoneButton();
		switchToDefaultContent();
		// waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment");
	}
	
	//methods by Gaurav Jain
	public void verifyOptionDropdownSettingsForAssignmentTabQuiz(String option) {
		customAssert.customAssertTrue(isElementDisplayed("Option_drpdown_SettingsFor"), "\""+option+"\" in Settings For dropdown is not present in partial text.");
		logMessage("\""+option+"\" in Settings For dropdown is present in partial text.");
	}
	
	public void assignPastDateAssignment(String assignmentScore, String pastDate) {
		clickAssignmentTab();
		selectDateFromPreviousMonth(pastDate);
		fillGradePointsForAssignment(assignmentScore);
		clickAssignButtonFromAssignmentTab();
	}
	
	public void clickBackToBlackboard() {
		switchToDefaultContent();
		waitAndScrollToElement("btn_backToBlackboard");
		clickUsingJavaScript("btn_backToBlackboard");
		//waitAndClick("btn_backToBlackboard");
		logMessage("Clicked on 'Back To BlackBoard'");
	}
	
	public void enterNumberOfAttemptsOnSettingsTab(String number) {
		switchToDefaultContent();
		selectTextFromDropDown("select_numberOfAttempts", number);
		logMessage("Number of attempts sets to: "+number);
	}
	
	public void clickSaveButtonOnSettingsTab() {
		switchToDefaultContent();
		waitAndClick("btn_save");
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		hardWait(4);
		logMessage("Clicked on 'Save' Button on Setting Tab.");
	}
}
/*
 * //Initializing Genie public void intializingGenie() { try {
 * Thread.sleep(10000); } catch (InterruptedException e1) {
 * e1.printStackTrace(); } LogConfig l = new LogConfig(); Genie g = null; try {
 * Genie.EXIT_ON_FAILURE = true; g = Genie.init(l); app1 =
 * g.connectToApp("[object BrightcoveBootloader]"); } catch (Exception e) {
 * System.out.println(e.getMessage()); } }
 * 
 * public void verifyFlashContentUsingGenie(){ try { (new
 * GenieButton("SP^ImageContainer:::FP^Loader:::SE^Bitmap::PX^0::PTR^0::IX^0::ITR^0"
 * ,app1)).isVisible(); } catch (StepFailedException e) { e.printStackTrace(); }
 * catch (StepTimedOutException e) { e.printStackTrace(); } catch (Exception e)
 * { e.printStackTrace(); } }
 */

