package com.qait.blackboard.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.PropFileHandler;

public class OnboardingPageActions extends GetPage {
	public OnboardingPageActions(WebDriver driver) {
		super(driver, "OnboardingPage");
	}

	/**
	 * General Methods
	 */
	public void verifyUrlSecured() {
		String url = getCurrentURL();
		customAssert.customAssertTrue(url.startsWith("https"),
				"[Assertion Failed] : Request Instructor Access Page URL is not secured");
		logMessage("[Assertion Passed] : Request Instructor Page Url is secured");
	}

	/**
	 * Header
	 */
	public void logout() {
		clickElementIfVisible("btn_closeToastMessage");
		hoverUserNameMenu();
		// element("link_usernameMenu").click();
		clickUserMenuItem("Sign Out");
		waitForElementToBeVisible("link_helpMenu");
		hardWait(2);
		waitForLoaderToDisappear();
//		try{
//			hoverUserNameMenu();
//			clickUserMenuItem("Sign Out");
//		}catch (Exception e) {
//			System.out.println("User already signed out");
//		}
	}

	public void hoverUserNameMenu() {
		hardWait(2);
		// hover(element("link_usernameMenu"));
		executeJavascript("document.getElementsByClassName('hidden-menu profileMenu')[0].style.display='block';");
	}

	public void clickUserMenuItem(String itemName) {
		waitForElementToBeVisible("link_usernameMenuItem", itemName);
		hardWait(2);
		element("link_usernameMenuItem", itemName).click();
		logMessage("Clicked User Name Menu Item '" + itemName + "'");
	}

	/**
	 * Request Instructor Access Page
	 */
	public void verifyTitle(String expectedTitle) {
		isElementDisplayed("txt_title");
		verifyTextOfElementIsCorrect("txt_title", expectedTitle);
		verifyUrlSecured();
	}

	public void verifyErrorMessageOnRequestInstructorAccessPage(String errorNum, String email) {
		if (errorNum.equals("1"))
			verifyTextOfElementIsCorrect("txt_errorMessage", "No Macmillan account exists for " + email
					+ ". Click [Next] to register, or try a different email address.");
		else if (errorNum.equals("2"))
			verifyTextOfElementIsCorrect("txt_errorMessage",
					"A Macmillan account already exists with that address. Please enter your password to continue.");
	}

	public void verifyWantToSignUpRadioBtnChecked() {
		customAssert.customAssertEquals(element("radiobtn_wantToSignUp").getAttribute("checked"), "true",
				"[Assertion Failed] : I want to Sign Up Radio Button is not checked");
	}

	public void submitMacmillanRepresentative(String username, String password, String email) {
		element("radiobtn_representative").click();
		fillText("txtinput_macmillanUserName", username);
		fillText("txtinput_passwordRepresentative", password);
		customAssert.customAssertEquals(element("txtinput_emailRepresentative").getAttribute("value").trim(), email,
				"[Assertion Failed] : Email is not filled correctly");
		clickNext();
	}

	public void clickNext() {
		element("btn_next").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}

	/**
	 * Instructor Registration Page
	 */
	public void fillInstructorFirstAndLastName(String fName, String lName) {
		scrollToTop();
		fillText("txtinput_firstName_instructor_registeration", fName);
		fillText("txtinput_lastName_instructor_registeration", lName);
	}

	public void fillInstructorPasswordAndConfirmPassword(String password) {
		fillText("txtinput_password_instructor_registeration", password);
		fillText("txtinput_confirmPassword_instructor_registeration", password);
	}

	public void verifyInstructorEmailCorrect(String email) {
		verifyTextOfElementIsCorrect("txt_emailLabel_instructor_registeration", email);
	}

	public void completeStudent_Registration(String email, String password) {
		waitForElementToBeVisible("inpt_FName");
		fillText(element("inpt_FName"), "fname");
		waitForElementToBeVisible("inpt_LName");
		fillText(element("inpt_LName"), "fname");
		waitForElementToBeVisible("E_Email");
		fillText(element("E_Email"), email);
		logMessage("student entered in email field " + email);
		waitForElementToBeVisible("confirm_Email");
		fillText(element("confirm_Email"), email);
		logMessage("student entered in confirm email field ");
		waitForElementToBeVisible("Password");
		fillText(element("Password"), password);
		logMessage("student entered in password " + password);
		waitForElementToBeVisible("confirmPassword");
		fillText(element("confirmPassword"), password);
		logMessage("student confirm password");
		isElementDisplayed("termCheckBox");
		waitAndClick("termCheckBox");
		logMessage("clicked on checkbox");
		isElementDisplayed("submit_button");
		hoverClick(element("submit_button"));
		logMessage("student registered successfully");
		waitForLoaderToDisappear();
		executeJavascript("document.getElementsByClassName('EnterCourse px-button right').item(0).click()");
		hardWait(3);
		logMessage("student clicked on enter your course button");
	}
	
	public void useAccessCodeFromFreeTrialMessage() {
		element("enter_Acess_Code").isDisplayed();
		click(element("enter_Acess_Code"));
		logMessage("Clicked on Enter Access Code Button");
		verifyStudentIsOnEnterAccessCodePage();
	}
	
	public void verifyStudentIsOnEnterAccessCodePage() {
		waitForElementToBeVisible("accessCodeHeading");
		isElementDisplayed("accessCodeHeading");
		logMessage("User is on enter Access Code page");
	}

	public void findYourSchoolByZipCode(String zipCode, String searchRange, String schoolType) {
		scrollToTop();
		element("radiobtn_zipCode").click();
		hardWait(1);
		fillText("txtinput_zipCode", zipCode);
		selectTextFromDropDown("dropdown_searchRange", searchRange);
		selectTextFromDropDown("dropdown_schoolType", schoolType);
		clickSearchBtn();
	}

	public void clickSearchBtn() {
		element("btn_search").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}

	public void selectSchoolDepartmentAndPosition(String school, String department, String position) {
		element("option_school", school).click();
		hardWait(2);
		waitForLoaderToDisappear();
		element("option_department", department).click();
		selectTextFromDropDown("select_position", position);
	}

	public void acceptCompanyPrivacyPolicy() {
		element("checkbox_accept").click();
	}

	public void clickSubmit() {
		element("btn_submit").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}

	/**
	 * Instructor Access Granted Page
	 */
	public void verifyInstructorAccessGrantedTitle(String expectedTitle) {
		isElementDisplayed("txt_instructorAccessGrantedIitle");
		verifyTextOfElementIsCorrect("txt_instructorAccessGrantedIitle", expectedTitle);
	}

	public void clickProceedToWebsiteBtn() {
		element("btn_proceedToTheWebsite").click();
	}

	/**
	 * Privacy Notice Page
	 */
	public void verifyEulaContentDisplayed() {
		isElementDisplayed("iframe_terms");
		switchToFrame(element("iframe_terms"));
		isElementDisplayed("txt_titlePrivacyNotice");
		isElementDisplayed("txt_titleTermsOfUse");
		switchToDefaultContent();
	}

	public void accept_LaunchPage() {
		isElementDisplayed("checkBox_dontShowMessage");
		waitScrollAndClick("checkBox_dontShowMessage");
		isElementDisplayed("bnt_launch");
		waitScrollAndClick("bnt_launch");
	}

	public void verifyEulaContentDisplayed(String env, String studEmail) {
		if (env.equalsIgnoreCase("lt")) {
			hardWait(3);
			isElementDisplayed("iframe_terms");
			switchToFrame(element("iframe_terms"));
			isElementDisplayed("txt_titlePrivacyNotice");
			isElementDisplayed("txt_titleTermsOfUse");
//			switchToDefaultContent();
		}

		else if (env.equalsIgnoreCase("prod") && PropFileHandler.readProperty("module").equalsIgnoreCase("Sapling")
				|| env.equalsIgnoreCase("prod") && PropFileHandler.readProperty("module").equalsIgnoreCase("Achieve")) {
			isElementDisplayed("txt_MLLaunchPage");
			isStringMatching(element("txt_MLLaunchPage").getText(), "Macmillan Learning Launch Page");
			isElementDisplayed("chkbox_agree");
			executeJavascript(
					"document.getElementsByClassName('radiorow').item(0).getElementsByTagName('input').item(0).click();");
			isElementDisplayed("bnt_launch");
			waitScrollAndClick("bnt_launch");
			changeWindow(1);
		}

		else if (env.equalsIgnoreCase("qa") | env.equalsIgnoreCase("prod")) {
			/*
			 * isElementDisplayed("txt_MLLaunchPage");
			 * isStringMatching(element("txt_MLLaunchPage").getText(),
			 * "Macmillan Learning Launch Page"); isElementDisplayed("chkbox_agree");
			 * executeJavascript(
			 * "document.getElementsByClassName('radiorow').item(0).getElementsByTagName('input').item(0).click();"
			 * ); isElementDisplayed("bnt_launch"); waitScrollAndClick("bnt_launch");
			 * changeWindow(1); waitForElementToBeVisible("iframe_terms");
			 * isElementDisplayed("iframe_terms"); switchToFrame(element("iframe_terms"));
			 * isElementDisplayed("txt_titlePrivacyNotice");
			 * isElementDisplayed("txt_titleTermsOfUse");
			 */
		}

	}

	public void agreeLegalTerms() {
		switchToDefaultContent();
		scroll(element("checkbox_readLegalTerms"));
//		element("checkbox_readLegalTerms").click();
//		element("btn_agree").click();
//		executeJavascript("document.getElementById('divIHaveRead').click()");
		executeJavascript("document.getElementById('EulaAgreement').click()");
		wait.hardWait(4);
		executeJavascript("document.getElementById('Button_Eula_Agree').click()");
		waitForLoaderToDisappear();
	}

	public void fillFirstNameLastNameAndPassword(String fName, String lName, String password) {
		fillText("txtinput_firstName", fName);
		fillText("txtinput_lastName", lName);
		fillText("txtinput_password", password);
	}

	public void fillConfirmEmailAndPassword(String email, String password) {
		fillText("txtinput_confirmEmail", email);
		fillText("txtinput_confirmPassword", password);
	}

	public void clickRegister() {
		element("btn_register").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}

	public void handleInstitutionWindow(String instName) {
		wait.resetImplicitTimeout(2);
		try {
			if (isElementDisplayed("input_instName")) {
				fillText("input_instName", instName);
				waitAndClick("list_inst", instName);
				waitAndClick("btn_Ok");
				logMessage("Fill the institution details");
			}
			wait.resetImplicitTimeout(wait.getTimeout());
		} catch (Exception e) {
			wait.resetImplicitTimeout(wait.getTimeout());
			logMessage("Institution Popup not found");
		}
	}
	
	/**
	 * This method is used to click on agree checkbox before registration
	 * 
	 */
	public void clickAcceptCompanyPrivacyPolicy() {
		isElementDisplayed("chkbox_agree");
		executeJavascript(
				"document.getElementsByClassName('radiorow').item(0).getElementsByTagName('input').item(0).click();");
		isElementDisplayed("bnt_launch");
		waitScrollAndClick("bnt_launch");
		changeWindow(1);
	}
}