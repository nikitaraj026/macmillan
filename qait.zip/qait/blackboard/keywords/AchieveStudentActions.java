package com.qait.blackboard.keywords;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class AchieveStudentActions extends GetPage {

	public AchieveStudentActions(WebDriver driver) {
		super(driver, "AchieveStudentAction");
	}

	public void useGracePeriodAsEnrollmentOption(String courseHeading) {
		wait.waitForElementToBeVisible(element("btn_gracePeriod"));
		element("btn_gracePeriod").click();
		wait.waitForElementToBeVisible(element("chkbox_agree"));
		hardWait(1);
		element("chkbox_agree").click();
		wait.waitForElementToBeVisible(element("btn_finishEnroll"));
		element("btn_finishEnroll").click();
		waitForLoaderToDisappear();
		waitForElementToBeVisible("heading_courseName", courseHeading);
		isElementDisplayed("heading_courseName", courseHeading);
		logMessage("Successfully navigated to Achieve Course Page");
	}

	public void switchToDefaulFrame() {
		waitForElementToBeVisible("iframe_ToolContent");
		switchToFrame("iframe_ToolContent");
	}

	public String attempt_AchieveQuiz1() {
		waitAndClick("btn_MyCourseTab", "COURSE PLAN");
		wait.waitForElementToBeVisible(element("link_quiz"));
		element("link_quiz").click();
		String points = "";
		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		switchToFrame("iframeAchieveQuiz");
		closeDisplayedModal("ratingModal");
		waitForElementToBeVisible("btn_beginQuiz");
		isElementDisplayed("btn_beginQuiz");
		waitAndClick("btn_beginQuiz");
		waitForPageToLoadCompletely("Macmillan Learning Achieve");
		List<WebElement> underLinedWords = elements("underline_words");

		for (int i = 0; i < underLinedWords.size(); i++) {
			if (i == 0)
				hardWait(5);
			else
				hardWait(1);

			underLinedWords.get(i).click();

			if (isCongratulationsMsgDisplayed() || isPtsDisplayed()) {
				System.out.println("The text displayed is -------------->" + element("status_answer").getText());
				break;
			}
			if (isCloseWrongWindowModalDisplayed()) {
				element("btnCloseWrongModalWindow").click();
				logMessage("Closed Wrong Answer Modal Window");
			}
			if (i == 3) {
				wait.waitForElementToBeVisible(element("btn_nextQues"));
				element("btn_nextQues").click();
				i = -1;
				underLinedWords = elements("underline_words");
			}
		}
		wait.waitForElementToBeVisible(element("back_toStudy"));
		element("back_toStudy").click();
		wait.waitForPageToLoadCompletely();
		waitForElementToBeVisible("points_fromAchieve");
		points = element("points_fromAchieve").getText();
		points = StringUtils.substringBefore(points, "pts").trim();
		System.out.println("Points from Achieve is -------------->" + points);
		closeWindowAndSwitchBackToOriginalWindow(0);
		return points;
	}

	private boolean isPtsDisplayed() {
		try {
			int timeout = wait.getTimeout();
			wait.resetImplicitTimeout(1);
			if (element("status_answer").getText().contains("pts")) {
				logMessage("Points are displayed on the screen");
				return true;
			}
			wait.resetImplicitTimeout(timeout);
		} catch (NoSuchElementException e) {
		}
		return false;
	}

	private boolean isCongratulationsMsgDisplayed() {
		try {
			int timeout = wait.getTimeout();
			wait.resetImplicitTimeout(1);
			if (element("status_answer1").getText() == "Congratulations!") {
				logMessage("Close Wrong Window Modal is Displayed");
				return true;
			}
			wait.resetImplicitTimeout(timeout);
		} catch (NoSuchElementException e) {
		}
		return false;
	}

	private boolean isCloseWrongWindowModalDisplayed() {
		try {
			int timeout = wait.getTimeout();
			wait.resetImplicitTimeout(1);
			if (element("btnCloseWrongModalWindow").isDisplayed()) {
				logMessage("Close Wrong Window Modal is Displayed");
				return true;
			}
			wait.resetImplicitTimeout(timeout);
		} catch (NoSuchElementException e) {
		}
		return false;
	}

	public void attempt_AchieveQuiz2() {
		changeWindow(1);
		waitForPageToLoadCompletely("Macmillan Learning Achieve");
		try {
			wait.resetImplicitTimeout(5);
			if (element("welcomeModal").isDisplayed()) {
				logMessage("Welcome Modal is displayed");
				executeJavascript("document.querySelector('._pendo-close-guide').click();");
				logMessage("Closed the Welcome Modal");
			} else {
				logMessage("Welcome Modal is not displayed");
			}
		} catch (NoSuchElementException e) {
			logMessage("Welcome Modal is not displayed");
			wait.resetExplicitTimeout(wait.timeout);
		}
		waitAndClick("btn_MyCourseTab", "COURSE PLAN");
		waitAndClick("link_quiz1");
		verifyUserIsOnSecondQuizAchPage();
		closeWindowAndSwitchBackToOriginalWindow(0);
	}

	private void verifyUserIsOnSecondQuizAchPage() {
		isElementDisplayed("div_Glossary");
		logMessage("User is on Second Quiz Page");
	}

	public void attempSecond_Quiz(String quizName1) {
		isElementDisplayed("click_onAssigment1", quizName1);
		waitAndClick("click_onAssigment1", quizName1);
		logMessage("clicked on nouns " + "+++++=====================");
		closeWindowAndSwitchBackToOriginalWindow(0);
	}

	public void verifyEnrollmentOptionsModalWindow() {
		wait.waitForPageToLoadCompletely();
		isElementDisplayed("modal_EnrollOptions");
		logMessage("Modal window for Enrollment options is displaying successfully");
		isElementDisplayed("btn_PurchaseAccess");
		isElementDisplayed("inpt_AccessCode");
		logMessage("Also verified all three enrollment options on the modal window");
	}

	private void closeDisplayedModal(String ratingModal) {
		try {
			if (element(ratingModal).isDisplayed()) {
				element(ratingModal).click();
				logMessage("Clicked on close button of rating modal window");
			} else {
				logMessage("Rating modal window is not displayed");
			}
		} catch (NoSuchElementException e) {
			logMessage("Rating modal window is not displayed");
		}
	}

	public void useAccessCodedAsEnrollmentOption(String accCode, String coursename) {
		waitForElementToBeVisible("inpt_AccessCode");
		fillText("inpt_AccessCode", accCode);
		waitAndClick("btn_Enter");
		waitAndClick("btn_finishEnroll");
		waitForLoaderToDisappear();
		// Needs to take locator from instructor action
		waitForElementToBeVisible("heading_courseName", coursename);
		isElementDisplayed("heading_courseName", coursename);
		logMessage("Successfully navigated to Achieve Course Page");
		waitAndClick("btn_MyCourseTab", "COURSE PLAN");
		waitAndClick("link_quiz");
		attempt_AchieveQuiz1();
	}
}