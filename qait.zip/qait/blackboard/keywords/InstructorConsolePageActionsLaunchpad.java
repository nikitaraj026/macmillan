package com.qait.blackboard.keywords;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;

public class InstructorConsolePageActionsLaunchpad extends GetPage {

	public InstructorConsolePageActionsLaunchpad(WebDriver driver) {
		super(driver, "InstructorConsolePageLaunchpad");
	}

	public void verifyUserIsOnInstructorConsolePage(){
		verifyUserIsOnPage("txt_instructorConsolePageTitle", "Instructor Console");
	}

	public void verifyUserIsOnInstructorConsoleGradebookPage(){
		verifyUserIsOnPage("txt_gradebookPageTitle", "Gradebook");
		logMessage("User is on 'Gradebook' page.");
	}

	public void verifyUserIsOnInstructorConsoleGradebookPreferencesPage(){
		verifyUserIsOnPage("txt_instructorConsolePageTitle", "Instructor Console » Gradebook Preferences");
	}

	public void verifyUserIsOnInstructorConsoleGradebookPreferencesPageNew(){
		verifyUserIsOnPage("txt_instructorConsolePageTitle", "Instructor Console");
		isElementDisplayed("txt_gradPreferences");
	}

	public void verifyUserIsOnInstructorConsoleNavigationPage(){
		verifyUserIsOnPage("txt_instructorConsoleNavigationHeading", "Navigation");
	}

	public void verifyUserIsOnInstructorConsoleGeneralPage(){
		verifyUserIsOnPage("txt_instructorConsoleGeneralHeading", "General");
	}

	public void verifyUserIsOnInstructorConsoleLaunchpadPage(){
		verifyUserIsOnPage("txt_instructorConsoleLaunchpadHeading", "Launch Pad");
	}

	public void verifyUserIsOnInstructorConsoleEditLinksPage(){
		String pageTitle = "Check the links that should appear in your console";
		isElementDisplayed("txt_instructorConsolePageHeading", pageTitle);
		customAssert.customAssertEquals(element("txt_instructorConsolePageHeading", pageTitle).getText(), pageTitle, 
				"Assertion Failed: '" + pageTitle + "' Page title is not correct.");
		logMessage("Assertion Passed: User is on '" + pageTitle + "' Page");
	}

	public void verifyUserIsOnBatchUpdaterPage(){
		isElementDisplayed("txt_batchUpdaterTitle");
		customAssert.customAssertEquals(element("txt_batchUpdaterTitle").getText(), "Batch due date updater", 
				"Assertion Failed : Title of 'Batch Updater' Page is incorrect");
		logMessage("Assertion Passed : Title of 'Batch Updater' Page is correct");
	}

	/*
	 * Verifies if the user is present on a specified page
	 */
	public void verifyUserIsOnPage(String elemName, String pageTitle) {
		waitForLoaderToDisappear();
		waitForElementToBeVisible(elemName);
		//isElementDisplayed(elemName);
		System.out.println("========================================");
		System.out.println("Element Name : " + elemName);
		customAssert.customAssertEquals(element(elemName).getText().trim(), pageTitle, 
				"Assertion Failed: '" + pageTitle + "' Page title is not correct.");
		logMessage("Assertion Passed: User is on '" + pageTitle + "' Page");
	}

	public void verifyInstructorConsolePageLinksDisplayed(List<String> linkList) {
		for (int i = 0; i < linkList.size(); i++) {
			isElementDisplayed("link_linkClass", linkList.get(i));
		}
	}

	/*
	 * Click Button Navigation(Settings) on Instructor Console
	 */
	public void clickGeneralNavigationAndLaunchPadSettings(){
		refreshPage();
		hardWait(2);
		//waitForElementToBeVisible("link_linkClass", "General, Navigation, and LaunchPad Settings");
		waitScrollAndClick("link_linkClass", "General, Navigation, and LaunchPad Settings");
		//click(element("link_linkClass", "General, Navigation, and LaunchPad Settings"));
		waitForLoaderToDisappear();
	}

	/*
	 * Click Button Navigation(Settings) on Instructor Console
	 */
	public void clickRosterAndGroups(){
		waitAndClick("link_linkClass", "Roster & Groups");
		waitForLoaderToDisappear();
	}	


	/*
	 * Click Button General(Settings) on Instructor Console
	 */
	public void clickGeneralSettings(){
		waitForElementToBeVisible("link_linkClass", "General");
		element("link_linkClass", "General").click();
		waitForLoaderToDisappear();
	}

	/*
	 * Click Button Launchpad(Settings) on Instructor Console
	 */
	public void clickLaunchpadSettings(){
		waitAndClick("link_linkClass", "Launch Pad");
		waitForLoaderToDisappear();
	}

	public void clickNavigationSettings() {
		waitAndClick("btn_navigation");
	}

	/*
	 * Click Button Gradebook Preferences on Instructor Console
	 */
	public void clickGradebookPreferences(){
		element("link_linkClass", "Gradebook Preferences").click();
		waitForLoaderToDisappear();
	}

	/*
	 * Verifies checkbox is selected or not
	 */
	public void verifyCheckBoxIsChecked(String elemName, Boolean checked){
		waitForElementToBeVisible(elemName);
		if (checked){
			customAssert.customAssertTrue(element(elemName).isSelected(), "Assertion Failed : Checkbox is not selected");
			logMessage("Assertion Passed : Checkbox is selected");
		}else{
			customAssert.customAssertFalse(element(elemName).isSelected(), "Assertion Failed : Checkbox is selected");
			logMessage("Assertion Passed : Checkbox is not selected");
		}
	}

	public void verifyIncludeWelcomeScreenInCourseCheckBoxIsChecked() {
		verifyCheckBoxIsChecked("checkbox_includeWelcomeScreenInCourse", true);
	}

	public void clickIncludeWelcomeScreenInCourseCheckBox() {
		waitScrollAndClick("checkbox_includeWelcomeScreenInCourse");
	}

	public void switchToDefaultFrame() {
		switchToDefaultContent();
		waitForElementToBeVisible("iframe_easyXDMDefault");
		switchToFrame(element("iframe_easyXDMDefault"));
	}

	public void verifyAssignmentScoreInGradebook(String assignmentName, String assignmentScore, String assignmentNumber) {
		waitForElementToBeVisible("txt_assignmentmentScoreInGradebook", assignmentNumber);
		String score = element("txt_assignmentmentScoreInGradebook", assignmentNumber).getText();
		customAssert.customAssertEquals(score, assignmentScore, "Assertion Failed : Assignment '" + assignmentName + "' score is incorrect in Gradebook");
		logMessage("Assertion Passed : Assignment '" + assignmentName + "' score is correct in Gradebook");
	}

	// Updates General Settings on Instructor Console Page
	public void updateInstructorConsoleGeneralSettings(String courseName, String instructorName, String academicTerm,
			String courseNumber, String courseSection, String officeHours, String email, String phone, String syllabusUrl) {
		hardWait(2);
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("document.getElementById('AcademicTerm').children[14].selected='selected';");
		js.executeScript("document.getElementById('AcademicTerm').children[14].click;");
		customAssert.customAssertEquals(element("txtinput_courseNameInGeneral").getAttribute("value"), courseName, "Assertion Failed : "
				+ "Course Name on Instructor Console General Settings page is incorrect");
		fillText("txtinput_courseNameInGeneral", courseName);
		fillText("txtinput_courseNumberInGeneral", courseNumber);
		fillText("txtinput_courseSectionInGeneral", courseSection);		
		customAssert.customAssertEquals(element("txtinput_instructorNameInGeneral").getAttribute("value"), instructorName, "Assertion Failed : "
				+ "Instructor Name on Instructor Console General Settings page is incorrect");
		fillText("txtinput_instructorNameInGeneral", instructorName);
		fillText("txtinput_officeHoursInGeneral", officeHours);

		element("link_newPointOfContactInGeneral").click();
		hardWait(1);
		element("link_newPointOfContactInGeneral").click();
		hardWait(1);
		element("link_newPointOfContactInGeneral").click();
		hardWait(1);
		//		WebElement dropdown1 = elements("dropdown_contactInfoInGeneral").get(0);
		//		element("dropdown_contactInfoInGeneral").click();
		//		List<String> options = Arrays.asList("Email", "Phone", "Fax", "Other");
		//		for (int i = 0; i < options.size(); i++){
		//			customAssert.customAssertTrue(element("option_contactInfoInGeneral", options.get(i)).isDisplayed(), "Assertion Failed : "
		//					+ "Contact Info dropdown does not have option " + options.get(i));
		//		}
		WebElement inputContactInfo1 = elements("txtinput_contactInfoInGeneral").get(0);
		WebElement inputContactInfo2 = elements("txtinput_contactInfoInGeneral").get(1);
		WebElement inputContactInfo3 = elements("txtinput_contactInfoInGeneral").get(2);
		fillText(inputContactInfo1, email);
		selectProvidedTextFromDropDown(elements("dropdown_contactInfoInGeneral").get(1), "Phone");
		fillText(inputContactInfo2, phone);
		selectProvidedTextFromDropDown(elements("dropdown_contactInfoInGeneral").get(2), "Fax");
		fillText(inputContactInfo3, "xyz");
		int noOfContacts = elements("list_btnDeleteContactInfoInGeneral").size();
		scrollDown(elements("list_btnDeleteContactInfoInGeneral").get(noOfContacts-1));
		elements("list_btnDeleteContactInfoInGeneral").get(noOfContacts-1).click();
		hardWait(2);
		verifyElementNotDisplayed("btn_deleteContactInfoInGeneral", "3", "");

		customAssert.customAssertEquals(element("optionSelected_timeZoneInGeneral").getText(), "(UTC-05:00) Eastern Time (US & Canada)", "Assertion Failed : "
				+ "Default Timezone selected is not '(UTC-05:00) Eastern Time (US & Canada)'");
		fillText("txtinput_syllabusUrl", syllabusUrl);

		element("btn_saveInGeneral").click();

	}

	// Verifies score of individual Assignments passed as list on Gradebook page
	public void verifyScoreOfAssignmentsInGradebook(List<String> assignmentTypes, String assignmentScore) {
		for (int i = 0; i < assignmentTypes.size(); i++){
			verifyAssignmentScoreInGradebook(assignmentTypes.get(i), assignmentScore, Integer.toString(i+1));
		}
	}

	// Verifies Total score of all Assignments on Gradebook Page
	public void verifyTotalScoreOfAllAssignmentsInGradebook(List<String> assignmentTypes, int totalExpectedScore) {
		verifyAssignmentScoreInGradebook("Total", Integer.toString(totalExpectedScore), Integer.toString(assignmentTypes.size()+1));
	}

	// Clicks Resources Button on Instructor Console Page
	public void clickResourcesButton(){
		element("btn_resources").click();
	}

	public void clickEditConsoleLinksAppearingOnHomePage(){
		element("link_linkClass", "Edit console links appearing on home page").click();
	}

	public void clickCheckboxResourcesByChapterOnEditLinksPage(){
		element("checkbox_resourcesByChapter").click();
	}

	public void changeDefaultSettingsofGradebook(String passingScore,String weight){
		updatePassingScore(passingScore);
		selectCheckBoxUseWeightedCategories();
		changeWeight(weight);
		changeGradebookScore();
		logMessage("Default settings of gradebook has been modified.");
	}
	public void changeGradebookScore(){
		//element("chkbox_pointsEarned").click();
		executeJavascript("document.getElementById('pointsEarned').click();");
		waitForLoaderToDisappear();
		//element("chkbox_percentageGrade").click();
		//executeJavascript("document.getElementById('percentageGrade').click();");
		//waitForLoaderToDisappear();
		//element("chkbox_letterGrade").click();
		executeJavascript("document.getElementById('letterGrade').click();");
		waitForLoaderToDisappear();
	}

	public void updatePassingScore(String passingScore){
		element("txtArea_passingScore").click();
		element("txtArea_passingScore").clear();
		element("txtArea_passingScore").sendKeys(passingScore);
		element("btn_okPassingScore").click();	
		waitForLoaderToDisappear();
		logMessage("Passing Score modified : "+passingScore);
	}

	public void changeWeight(String weight){
		//element("txt_labelWeight").click();
		executeJavascript("document.getElementById('labelWeight_0').click();");
		//element("txtArear_labelWeight").click();
		executeJavascript("document.getElementsByClassName('textWeight')[0].click();");
		//element("txtArear_labelWeight").clear();
		//element("txtArear_labelWeight").sendKeys(weight);
		executeJavascript("document.getElementsByClassName('textWeight')[0].value='"+weight+"';");
		//element("btn_labelWeight").click();	
		executeJavascript("document.getElementsByClassName('btnWeight')[0].click();");
		waitForLoaderToDisappear();
		logMessage("Weights/Points modified : "+weight);
	}

	public void clickDoneOnEditLinksPage(){
		element("btn_doneEditLinks").click();
		waitForLoaderToDisappear();
	}

	public void clickBatchDueDateUpdater(){
		element("link_linkClass", "Batch Due Date Updater").click();
		waitForLoaderToDisappear();
	}

	public void clickBatchItemSettings(){
		element("link_linkClass", "Batch Item Settings").click();
		waitForLoaderToDisappear();
		isElementDisplayed("lbl_titleBatchAssignmentSettings");
	}

	// Removes Units from Course from Launch Pad page on Instructor Console
	public void removeUnitsFromLaunchpadSettings() {
		verifyTextOfElementIsCorrect("link_removeUnitsFromCourse", "Remove these units from your course?");
		element("link_removeUnitsFromCourse").click();
		customAssert.customAssertEquals(element("txt_uiDialogTitle").getText(), "Are you sure?", "Assertion Failed : Incorrect Dialog Box opens on "
				+ "clicking Remove Units link");
		isElementDisplayed("btn_uiButtonText", "Remove units");
		isElementDisplayed("btn_uiButtonText", "Cancel");
		element("btn_uiButtonText", "Remove units").click();
		waitForElementToBeVisible("msg_toast","Default units successfully removed from your course");
		waitForMsgToastToDisappear();
	}

	//Clicks on Collapse on unassigned items by default checkbox
	public void clickOnCollapseUnassignedItemsByDefaultCheckbox() {
		scrollDown(element("checkbox_collapseUnassigned"));
		element("checkbox_collapseUnassigned").click();
	}

	// Add Units to Course from Launch Pad page on Instructor Console
	public void addUnitsFromLaunchpadSettings() {
		verifyTextOfElementIsCorrect("link_removeUnitsFromCourse", "Add these units to your course?");
		element("link_removeUnitsFromCourse").click();
		waitForElementToBeVisible("msg_toast","Default units successfully added to your course!");
		waitForMsgToastToDisappear();
	}

	/*
	 * Takes "start" or "end" as string value
	 * Chooses a date in 20's from next month for datepicker field
	 */
	public void selectDateInDatePicker(String type) {
		waitForElementToBeVisible("datePicker_goNext");
		element("datePicker_goNext").click();
		if (type.equals("start")){
			waitForElementToBeVisible("datePicker_fromDate");
			element("datePicker_fromDate").click();
		} else {
			waitForElementToBeVisible("datePicker_toDate");
			element("datePicker_toDate").click();
		}
	}

	public void clickFromDateInputInBatchUpdaterPage(){
		element("txtinput_fromDateInBatchUpdater").click();
	}

	public void clickToDateInputInBatchUpdaterPage(){
		element("txtinput_todateInBatchUpdater").click();
	}

	public void clickNewDueDateInputInBatchUpdaterPage(){
		element("txtinput_newDueDateInBatchUpdater").click();
	}

	//Pass total number of expected assignments for the range as String
	public void verifyMessageTotalAssignmentsInBatchUpdater(String numItems) {
		waitForLoaderToDisappear();
		hardWait(3);
		String message = element("txt_messageTotalAssignmentsInBatchUpdater").getText();
		if (message.indexOf("You have " + numItems + " assignment") == -1){
			customAssert.customAssertTrue(false, "Assertion Failed : Total Assignments displayed message is incorrect on Batch Updater Page");
		}else{
			logMessage("Assertion Passed : Total Assignments displayed message is correct on Batch Updater Page");
		}
	}

	// Pass Total number of expected days shifted as String(Eg. "0", "+1", "-1")
	public void verifyMessageTotalDaysShiftedInBatchUpdater(String daysShifted) {
		String message = element("txt_messageTotalDaysShiftedInBatchUpdater").getText();
		if (message.indexOf("All selected due dates will be shifted " + daysShifted + " day") == -1){
			customAssert.customAssertTrue(false, "Assertion Failed : Total Days Shifted message is incorrect on Batch Updater Page");
		}else{
			logMessage("Assertion Passed : Total Days Shifted message is correct on Batch Updater Page");
		}
	}

	// Verifies Batch Updater page on Instructor Console
	public void verifyBatchUpdaterPage() {
		clickFromDateInputInBatchUpdaterPage();
		selectDateInDatePicker("start");
		clickToDateInputInBatchUpdaterPage();
		selectDateInDatePicker("end");
		verifyMessageTotalAssignmentsInBatchUpdater("0");
		clickNewDueDateInputInBatchUpdaterPage();
		selectDateInDatePicker("start");
		verifyMessageTotalDaysShiftedInBatchUpdater("0");
		clickUpdateDueDatesInBatchUpdaterPage();
		waitForMsgToastToDisappear();
	}

	public void clickUpdateDueDatesInBatchUpdaterPage(){
		element("btn_updateDueDatesInBatchUpdater").click();
		waitForLoaderToDisappear();
	}

	public void clickHomeButton() {
		waitForLoaderToDisappear();
		switchToDefaultContent();
		waitAndClick("btn_home");
		logMessage("User clicks on home button");
	}

	public void verifyAssignmentNameDisplayedOnGradebook(String assignmentName) {
		switchToDefaultFrame();
		waitAndScrollToElement("txt_assignmentName",assignmentName);
		customAssert.customAssertEquals(element("txt_assignmentName",assignmentName).getText(), assignmentName, "Assertion Failed : "
				+ "Assignment Name is not correct");
		logMessage("Assertion Passed : Assignment Name is correct");
		switchToDefaultContent();
	}

	public void verifyAssignmentCategoryDisplayedOnGradebook(String assignmentName) {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("txt_gradebookCategory",assignmentName);
		customAssert.customAssertEquals(element("txt_gradebookCategory",assignmentName).getText(), assignmentName, "Assertion Failed : "
				+ "Assignment Name is not correct");
		logMessage("Assertion Passed : Assignment Name is correct");
	}

	public void verifyssignmentCategoryNotDisplayedOnGradebook() {
		waitForLoaderToDisappear();
		customAssert.customAssertTrue(elements("txt_gradebookCategory").size()==0, "Assertion failed : Content removed from Gradebook after removing it from management card");
		logMessage("Assertion passed : Content removed from Gradebook after removing it from management card");
	}

	public void clickTopButtonInGradebook(String buttonName) {
		switchToDefaultFrame();
		element("btn_topNavigationInGradebook", buttonName).click();
		switchToDefaultContent();
		logMessage("Clicked "+buttonName+" on Gradebook.");
	}

	public void selectOptionOfDisplayOptionInGradebook(String optionName) {
		switchToDefaultFrame();
		element("option_displayOptionsInGradebook", optionName).click();
		switchToDefaultContent();
		logMessage(optionName+" has been selected.");
	}

	private void checkOptionsInDisplayOptionsOnGradebook(String displayOption, String... options) {
		switchToDefaultFrame();
		for(String option: options){
			selectCheckbox("chkbox_displayOptions",displayOption,option);
			logMessage(option+" has been checked on "+displayOption+".");
		}
		switchToDefaultContent();
	}
	
	public void checkOptionsInVisibleColumnsOnGradebook(String... options) {
		checkOptionsInDisplayOptionsOnGradebook("Visible Columns", options);
	}
	
	private void clickOKInDisplayOptionsOnGradebook(String displayOptions) {
		switchToDefaultFrame();
		waitAndClick("btn_OKGradebook",displayOptions);
		logMessage("Clicked 'OK' button on "+displayOptions+".");
		switchToDefaultContent();
	}
	
	public void clickOKInVisibleColumnsOnGradebook() {
		clickOKInDisplayOptionsOnGradebook("Visible Columns");
	}

	public void verifyOptionOfDisplayOptionIsDisplayedInGradebook(String optionName) {
		isElementDisplayed("option_displayOptionsInGradebook", optionName);
	}

	public void verifyMinutesDisplayedForAssignmentInGradebook(String assignmentNumber) {
		isElementDisplayed("txt_minutesForNthAssignmentInGradebook", assignmentNumber);
	}

	public void verifyTotalMinutesDisplayedInGradebook() {
		isElementDisplayed("txt_totalMinutesInGradebook");
	}

	public void verifyTextOfWindowInGradebook(String windowName) {
		customAssert.customAssertEquals(element("txt_windowHeaderInGradebook").getText(), windowName, "Assertion Failed : "
				+ "Window name is incorrect");
		logMessage("Assertion Passed : Window name is correct");
	}

	public void clickCloseButtonInImportExportScoresWindow() {
		element("btn_closeInImportExportScores").click();
	}

	public void clickOnDropStudentButtton() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_dropStudent");
		element("btn_dropStudent").click();
		logMessage("Clicked on Drop Student button");
	}

	public void selectStudentAndClickDrop() {
		switchToFrame(element("iframe_dropStudent"));
		element("div_studentName").click();
		logMessage("Clicked on student name");
		hardWait(1);
		element("btn_drop").click();
		logMessage("Clicked on Drop button");
		waitForElementToBeVisible("btn_yes");
		element("btn_yes").click();
		logMessage("Clicked on Yes button");
		waitForElementToBeVisible("btn_Ok");
		element("btn_Ok").click();
		element("btn_closeInImportExportScores").click();
	}

	public void clickShowHideAssignmentsInGradebookPreferences() {
		element("link_showAssignmentsInGradebookPreferences").click();
		hardWait(1);
	}

	public void verifyCategoryDisplayedInGradebookPreferences(String categoryName) {
		isElementDisplayed("txt_categoryNameInGradebookPreferences", categoryName);
	}

	public void verifyAssignmentDisplayedInGradebookPreferences(String assignmentName) {
		isElementDisplayed("txt_assignmentNameInGradebookPreferences", assignmentName);
	}

	public List<String> changeSequenceOfCategories() {
		List<String> sequenceOfCategories = new ArrayList<String>();
		selectProvidedTextFromDropDown(element("dropdwn_categorySequence","0"), "2");
		waitForLoaderToDisappear();
		hardWait(3);
		for (int i = 0; i <2; i++) {
			sequenceOfCategories.add(elements("txt_categorySequenceName").get(i).getText());
		}
		return sequenceOfCategories;
	}

	public void verifyTextOfShowHideAssignmentsInGradebookPreferences(String expectedText) {
		customAssert.customAssertEquals(element("link_showAssignmentsInGradebookPreferences").getText(), expectedText, "Assertion Failed : "
				+ "Text of Show/Hide Assignments link is incorrect");
		logMessage("Assertion Passed : Text of Show/Hide Assignments link is incorrect");
	}

	public void verifyDropLowestForCategoryInGradebookPreferences(String categoryName, String expectedValue) {
		waitForLoaderToDisappear();
		customAssert.customAssertEquals(element("txt_dropLowestForCategory", categoryName).getText(), expectedValue, "Assertion Failed : "
				+ "Value of Drop Lowest is incorrect for Category '" + categoryName + "'");
		logMessage("Assertion Passed : Value of Drop Lowest is correct for Category '" + categoryName + "'");
	}

	public void sumbitDropLowestForCategoryInGradebookPreferences(String categoryName, String newDrop) {
		element("txt_dropLowestForCategory", categoryName).click();
		element("txtinput_dropLowestForCategory", categoryName).click();
		element("txtinput_dropLowestForCategory", categoryName).clear();
		element("txtinput_dropLowestForCategory", categoryName).sendKeys(newDrop);
		element("btn_okDropLowestForCategory", categoryName).click();
		waitForLoaderToDisappear();
	}

	public void verifyPointsForCategoryInGradebookPreferences(String categoryName, String expectedValue) {
		System.out.println("grade points "+ element("txt_pointsForCategory", categoryName).getText().trim());
		customAssert.customAssertEquals(element("txt_pointsForCategory", categoryName).getText().trim(), expectedValue, "Assertion Failed : "
				+ "Value of Weight/Points is incorrect for Category '" + categoryName + "'");
		logMessage("Assertion Passed : Value of Weight/Points is correct for Category '" + categoryName + "'");
	}

	public void verifyWeightForCategoryInGradebookPreferences(String categoryName, String expectedValue) {
		hardWait(2);
		customAssert.customAssertEquals(element("txt_weightForCategory", categoryName).getText().trim(), expectedValue, "Assertion Failed : "
				+ "Value of Weight/Points is incorrect for Category '" + categoryName + "'");
		logMessage("Assertion Passed : Value of Weight/Points is incorrect for Category '" + categoryName + "'");		
	}

	public void selectCheckBoxUseWeightedCategories() {
		element("chkbox_useWeightedCategories").click();
		waitForLoaderToDisappear();
		logMessage("Use Weighted Categories toggled.");
	}
	/**
	 * Select New Time Zone from drop down list
	 */
	public void timeZoneSelection(String newTimeZone){
		waitForElementToBeVisible("dropdown_timeZoneInGeneral");
		selectProvidedTextFromDropDown(element("dropdown_timeZoneInGeneral"),newTimeZone);
		logMessage("Instructor select new time zone : "+newTimeZone);
	}

	/**
	 * Clicks on save button in General
	 */
	public void clickOnSaveButtonInGeneral(){
		element("btn_saveInGeneral").click();
		waitForLoaderToDisappear();
		logMessage("User clicks on Save button in Genreal");	
	}

	public void verifyUserIsOnRosterNGroupsPage(){
		isElementDisplayed("txt_RosterNGroupsHeading");
		logMessage("Verified user is on Roster & Groups page");
	}

	public void createNewRosterGroupSet(String groupPrefix, String groupAssignment){
		waitAndClick("lnk_CreateNewGroupSet");
		waitForLoaderToDisappear();
		switchToFrame(element("iframe_easyXDMDefault"));
		_verifyGenerateGroupPopUp();
		waitAndClick("radio_GroupAssignment",groupAssignment);
		//element("radio_GroupAssignment",groupAssignment).click();
		fillText("txtinput_GroupPrefix", groupPrefix);
		//element("txtinput_GroupPrefix").sendKeys(groupPrefix);
		//element("btn_GenerateGroups").click();
		waitAndClick("btn_GenerateGroups");
		waitScrollAndClick("btn_Ok");
		switchToDefaultContent();
		_verifyIncorrectMessageIsNotDisplayed();
		logMessage("New roster group added successfully");
		waitForLoaderToDisappear();
	}

	private void _verifyIncorrectMessageIsNotDisplayed() {
		verifyElementNotDisplayed("msg_toast","Blank questions cannot be saved","");		
	}

	private void _verifyGenerateGroupPopUp(){
		isElementDisplayed("txtinput_GroupPrefix");
		isElementDisplayed("radioBtn_NumberOfGroups");
		isElementDisplayed("btn_GenerateGroups");
		isElementDisplayed("btn_CancelGenerateGroup");
	}

	public void cloneExistingGroupSet(String groupPrefix, String newCloneGroupPrefix) {
		waitScrollAndClick("btn_clone", groupPrefix);
		waitForLoaderToDisappear();
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForElementToBeVisible("lnk_RenameGroupClone");
		switchToDefaultContent();
		executeJavascript("document.getElementsByTagName('iframe')[1].contentDocument.getElementsByClassName('groupsetup-header-rename')[0].click();");
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForElementToBeVisible("txtinput_GroupName");
		isElementDisplayed("txtinput_GroupName");
		fillText("txtinput_GroupName", groupPrefix + " Renamed");
		waitScrollAndClick("btn_RenameGroupOK");
		fillText("txtinput_GroupSetName", newCloneGroupPrefix);
		waitScrollAndClick("btn_Ok");
		switchToDefaultContent();
		logMessage("Cloned existing group set");
	}

	public void editExistingGroupSet(String groupPrefix, String groupName) {
		waitScrollAndClick("btn_edit",groupPrefix);
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitAndClick("lnk_RenameGroupClone");
		switchToDefaultContent();
		//executeJavascript("document.getElementsByTagName('iframe')[1].contentDocument.getElementsByClassName('groupsetup-header-rename')[0].click();");
		switchToFrame(element("iframe_easyXDMDefault"));
		waitAndClick("txtinput_GroupName");
		fillText("txtinput_GroupName", groupName);
		waitAndClick("btn_RenameGroupOK");
		waitAndClick("btn_Ok");
		switchToDefaultContent();
		logMessage("Edited existing group set");
	}

	public void deleteExistingGroupSet(String groupPrefix) {
		waitAndClick("btn_Delete",groupPrefix);
		handleAlert();
		logMessage("Deleted group successfully");
	}

	public void verifyStudentInRoster(String studentEmail) {
		isElementDisplayed("lnk_EmailStudentInRoster");
		customAssert.customAssertEquals(element("lnk_EmailStudentInRoster").getText(), studentEmail, "Assertion Failed : "
				+ "Link of student Email is incorrect");
	}

	public void studentInGroup(String includeOrDelete, String groupPrefix) {
		waitScrollAndClick("btn_edit",groupPrefix);
		waitForLoaderToDisappear();
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		waitForElementToBeVisible("lnk_RenameGroupClone");
		waitAndClick("btn_AddRemoveStudentInGroup");
		waitAndClick("btn_Ok");
		switchToDefaultContent();
		clickTopInstructorConsoleLink();
		clickRosterAndGroups();
		verifyIncludeDeleteStudentInGroup(includeOrDelete);
		logMessage(includeOrDelete + "verified successfully");
	}

	private void verifyIncludeDeleteStudentInGroup(String includeOrDelete) {
		if(includeOrDelete.equalsIgnoreCase("Include Student in a group")){
			customAssert.customAssertTrue(element("lbl_GroupSetCount").getText().contains("1 Student"), "Assertion Failed : "
					+ "Group Set count does not contain '1 Student'");
		}
		if(includeOrDelete.equalsIgnoreCase("Delete Student from a group")){
			customAssert.customAssertTrue(element("lbl_GroupSetCount").getText().contains("0 Student"), "Assertion Failed : "
					+ "Group Set count does not contain '0 Student'");
		}
	}

	public void createNewRosterGroupSetWithApproximateUsers(String groupPrefix, String groupAssignment) {
		waitAndClick("lnk_CreateNewGroupSet");
		waitForLoaderToDisappear();
		switchToFrame(element("iframe_easyXDMDefault"));
		_verifyGenerateGroupPopUp();
		waitAndClick("radio_GroupAssignment",groupAssignment);
		fillText("txtinput_GroupPrefix",groupPrefix + " With Approximate Users");
		fillText("txtinput_ApproxStudentPerGroup", "4");
		waitAndClick("btn_GenerateGroups");
		waitAndClick("btn_Ok");
		switchToDefaultContent();
		logMessage("New roster group added successfully");
	}

	public void verifyAssignmentNameNotDisplayedOnGradebook(String assignmentName) {
		verifyElementNotDisplayed("txt_assignmentName", assignmentName, "");
		logMessage("No Assingment is assinged ");
	}

	public void verifyStudentNameOnGradeBook(String studentName){
		String[] student = getLastNameFirstNameOfUser(studentName);
		String expectedText = student[1] + ", " + student[0];
		switchToDefaultFrame();
		customAssert.customAssertTrue(element("txt_studentMail").getText().contains(expectedText), "Incorrect student name displayed in gradebook");
		switchToDefaultContent();
		logMessage("Registered student name displayed on grade book");
	}

	public void verifyAssignmentPointsOnGradebook(String assignmentScore){
		switchToDefaultFrame();
		isElementDisplayed("txt_studentAssignmentPointsInGradeBook", assignmentScore);
		customAssert.customAssertEquals(element("txt_studentAssignmentPointsInGradeBook", assignmentScore).getText(), assignmentScore, "Assertion Failed : Assignment score is incorrect in Gradebook");
		switchToDefaultContent();
		logMessage("Assertion Passed : Assignment score is correct in Gradebook");
	}

	public void clickStudentNameOnGradeBook() {
		switchToDefaultFrame();
		isElementDisplayed("lbl_studentNameOnGradeBook");
		element("lbl_studentNameOnGradeBook").click();
		waitForElementToBeVisible("txt_studentMail");
		switchToDefaultContent();
		logMessage("Clicked on Sudent name on GradeBook");
	}

	public void instructorBackToGradebook() {
		element("icon_backToGradebookFromStduentView").click();
		logMessage("Instructor returned to Gradebook");
	}

	public void verifyCategorySequence(List<String> categorySequence) {
		elements("txt_gradebookCategory");
		int i = 0;
		for(WebElement e : elements("txt_gradebookCategory")) {
			customAssert.customAssertEquals(e.getText(), categorySequence.get(i), "Assertion failed : Category sequence correct");
			i++;
		}
		logMessage("Assertion failed : Category sequence correct");
	}

	/**
	 * Method which verifies whether the assignment is showing 'Submission Late'
	 * message
	 * 
	 */
	public void verifyLateSubmissionMessageOnAssignment() {
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		element("txt_quizContent").click();
		waitForElementToBeVisible("quizWidget");
		//wait.waitForElementToBeClickable(element("quizWidget"));
		//hoverClick(element("txt_quizContent"));

		SimpleDateFormat compareDate = new SimpleDateFormat(
				"EEEEEE, MMMM dd, yyyy HH:mm a");
		try {
			String dueDate = element("txt_dueDate").getText();
			String submittedDate = element("txt_submittedDate").getText();

			logMessage("Due Date of assignment on GradeBook: " + dueDate);
			logMessage("Submitted Date of assignment on GradeBook: "
					+ submittedDate);

			Date dueDateOfAssignment = compareDate.parse(dueDate);
			Date submittedDateOfAssignment = compareDate.parse(submittedDate);

			if (dueDateOfAssignment.after(submittedDateOfAssignment)) {
				logMessage("Due Date of assignment is after "
						+ "Submission Date");
			} else if (dueDateOfAssignment.before(submittedDateOfAssignment)) {
				logMessage("Due Date of assignment is before"
						+ " Submission Date");
				Assert.fail("Assignment is submitted after Due Date!!!");
			} else if (dueDateOfAssignment.equals(submittedDateOfAssignment)) {
				logMessage("Due Date of assignment is on"
						+ " same day Submission");
			}
		} catch (ParseException e) {
			e.printStackTrace();
		}

		element("btn_cancelModalWindow").click();
		hover(element("txt_quizContent"));

		String submittedlate = element("txt_quizDetails").getAttribute(
				"ext:qtip").toString();

		if (submittedlate.contains("Submitted late")) {
			Assert.fail("Assertion Failed: GradeBook is displaying Late Submission of " +
					"Quiz attempted by the student!!!");
		} else {
			logMessage("Assertion Passed: GradeBook is displaying Submission of Quiz " +
					"attempted by the student defore Due Date");
		}
		switchToDefaultContent();
	}

	public void instructorUploadSyallabus(String syallabusTittle){
		click(element("checkbox_uploadSyallabus"));
		//element("checkbox_uploadSyallabus").click();
		logMessage("User select upoad syallabus radio button");
		isElementDisplayed("btn_upload");
		enterFilepathToUpload(syallabusTittle, "btn_browse");
		hardWait(1);
		element("btn_upload").click();
		logMessage("User click on upload button");
		hardWait(2);
	}

	public void enterFilepathToUpload(String filename, String locator) {
		waitForElementToBeVisible(locator);
		String currentDir = System.getProperty("user.dir");
		if (System.getProperty("os.name").contains("Windows")) {
			element(locator).sendKeys(
					currentDir + "\\src\\test\\resources\\testdata\\LAUNCHPAD\\"
							+ filename);
		} else {
			element(locator).sendKeys(
					currentDir + "/src/test/resources/testdata/LAUNCHPAD/" + filename);
		}
	}

	public void verifySyallabusIsUploaded(String syllabusTitle){
		while(element("label_uploadText").getText().toString().contains("Uploading"));
		String uploadMsg= element("label_uploadText").getText();
		customAssert.customAssertEquals(uploadMsg, syllabusTitle+" was uploaded successfully.", "Assertion Failed : File can't be uploaded");
		logMessage(syllabusTitle+" was uploaded successfully.");
	}

	public void verifyLMSIdRequiredFalseRadioBtnSelected() {
		customAssert.customAssertTrue(element("radiobtn_LMSIdRequiredFalse").isSelected(), "Assertion Failed : "
				+ "'LMS ID Required False' Radio Button is not selected");
	}

	public void verifyLMSIdRequiredTrueRadioBtnSelected() {
		customAssert.customAssertTrue(element("radiobtn_LMSIdRequiredTrue").isSelected(), "Assertion Failed : "
				+ "'LMS ID Required True' Radio Button is not selected");
	}

	public void clickLMSIdRequiredFalseRadioBtn() {
		element("radiobtn_LMSIdRequiredFalse").click();
	}

	public void clickLMSIdRequiredTrueRadioBtn() {
		element("radiobtn_LMSIdRequiredTrue").click();
	}

	public void clickGeneralSettingsSaveButton(){
		element("btn_saveInGeneral").click();
	}

	public void clickNaviationSettingsSaveButton(){
		waitAndClick("btn_saveInGeneral");
		//	element("btn_saveInGeneral").click();
	}

	public void clickLaunchpadSettingsSaveButton(){
		element("btn_saveInGeneral").click();
		waitForLoaderToDisappear();
	}

	public void clickCancelRosterAndGroupsFooter() {
		switchToFrame(element("iframe_easyXDMDefault"));
		waitScrollAndClick("btn_footerCancelRosterGroup");
		//hardWait(2);
		//verifyElementNotDisplayed("btn_footerCancelRosterGroup", "");
		switchToDefaultContent();
	}

	public void chooseContentTypeBatchItemSettings(String contentType) {
		selectProvidedTextFromDropDown(element("dropdwn_chooseContentType"), contentType);
		hardWait(1);
		waitForLoaderToDisappear();
	}

	public void clickUserCreatedRadioButton() {
		element("radiobtn_userCreated").click();
		hardWait(2);
	}

	public void clickSelectAllBatchItemSettings() {
		waitAndClick("btn_selectAllBatchAssignmentSettings");
	}

	public void fillGradePointsBatchItemSettings(String gradePoints) {
		fillText("txtinput_gradebookPoints", gradePoints);
	}

	public void clickApplySettingsToSelectedItems() {
		element("btn_applySettingsToSelectedItems").click();
	}

	public void clickUpdateAssignmentSettingsFromConfirmAssignmentSettingsChangeModal() {
		waitForElementToBeVisible("txt_titleConfirmAssignmentSettingsChange");
		isElementDisplayed("txt_titleConfirmAssignmentSettingsChange");
		element("btn_updateAssignmentSettings").click();
		hardWait(1);
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void verifyGradesNotVisible() {
		System.out.println(element("txt_totalscore").getText());
		customAssert.customAssertEquals(element("txt_totalscore").getText(), "", "Assertion Failed : Grades are still visible after removing the content");
		logMessage("Assertion Passed : Grades are removed after content is removed");
	}

	//modified by Gaurav Jain
	public void selectContentTypeBatchItemSettings(String contentType){
		selectProvidedTextFromDropDown(element("dropdwn_chooseContentType"), contentType);
		waitForLoaderToDisappear();
		logMessage("Selected User Created Content: "+contentType);
	}

	public void clickTopInstructorConsoleLink(){
		waitScrollAndClick("link_instructorConsolePageTitle");
		logMessage("Clicked: Instructor Console Link");
	}

	public void clickTopInstructorConsoleLinkUsingJavascript(){
		executeJavascript("(document.evaluate(\"//div[@id='fne-title']/a[text()='Instructor Console']\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue).click();");
	}

	public String getGroupPageLastGroupSetText() {
		isElementDisplayed("link_lastGroupSet");
		return element("link_lastGroupSet").getText();
	}

	public void verifyGroupPageLastGroupSet(String groupSet) {
		customAssert.customAssertEquals(getGroupPageLastGroupSetText(), groupSet, "Assertion Failed : Last Group Set are not matching.");
		logMessage("Assertion Passed : Last Group Set matched.");
	}

	public void clickBackToBlackboardOnGradebook() {
		switchToDefaultContent();
		hardWait(2);
		waitAndClick("btn_backtoblackboard");
		logMessage("Clicked 'Back To Blackboard' button.");
	}
	
	//for Gradebook
	private int getColumnNumberAssignmentOnGradebook(String assignmentName) {
		int colNum = -1;
		switchToDefaultFrame();
		for(WebElement element:elements("col_assignment")){
			colNum++;
			if(element.getText().equalsIgnoreCase(assignmentName))
				return colNum;
		}
		return colNum;
	}
	
	private int getColumnNumberStudentInfoOnGradebook(String coulumnName) {
		int colNum = -1;
		switchToDefaultFrame();
		for(WebElement element:elements("col_studentInfo")){
			colNum++;
			if(element.getText().equalsIgnoreCase(coulumnName))
				return colNum;
		}
		return colNum;
	}
	
	private int getRowNumberStudentEmailOnGradebook(String studentEmail){
		int colNum = getColumnNumberStudentInfoOnGradebook("Email");
		int rowNum = -1;
		switchToDefaultFrame();
		for(WebElement element:elements("row_studentInfo",Integer.toString(colNum))){
			rowNum++;
			if(element.getText().equals(studentEmail))
				return rowNum;
		}
		return rowNum;
	}
	
	public void verifyStudentAssignmentScoreOnGradebook(String studentEmail, String assignmentName, String assignmentScore) {
		int rowNum = getRowNumberStudentEmailOnGradebook(studentEmail);
		int colNum = getColumnNumberAssignmentOnGradebook(assignmentName);
		switchToDefaultFrame();
		String score = element("txt_passingScoreAssignment", Integer.toString(rowNum), Integer.toString(colNum)).getText();
		customAssert.customAssertEquals(score, assignmentScore, "Assertion Failed : Assignment '" + assignmentName + "' score for "+studentEmail+" is incorrect in Gradebook");
		logMessage("Assertion Passed : Assignment '" + assignmentName + "' score for "+studentEmail+" is correct in Gradebook");
	}
}
