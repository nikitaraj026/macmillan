package com.qait.blackboard.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class SupportPageActionsCatalog extends GetPage {
	static String tier;
	public SupportPageActionsCatalog(final WebDriver driver) {
		super(driver, "SupportPageCatalog");
	}
	
	public void verifyUserIsOnSupportCenterPage() {
		changeWindow(1);
		isElementDisplayed("txt_supportCenter");
		logMessage("User is on 'Support Center' page.");
		changeWindow(0);
	}
	
	public void closeSupportCenterPage() {
		changeWindow(1);
		closeWindow();
		changeWindow(0);
	}
}
