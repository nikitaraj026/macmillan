package com.qait.blackboard.keywords;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.asserts.SoftAssert;
import org.yaml.snakeyaml.Yaml;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.YamlReader;

public class CoursePageAction extends GetPage {
	public static String studUserName = "";

	public CoursePageAction(WebDriver driver) {
		super(driver, "CoursePage");
		new SoftAssert();
	}

	// *************************************************************
	// Dynamic Yaml File

	public void writeDataToYaml(Map<String, Object> data) {
		Yaml yaml = new Yaml();
		FileWriter writer = null;
		try {
			writer = new FileWriter("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "BLACKBOARD" + File.separator + "QA_DynamicTestData.yml");
			yaml.dump(data, writer);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static String getMapValue(Map<String, Object> object, String token) {
		// TODO: check for proper yaml token string based on presence of '.'
		String[] st = token.split("\\.");
		return parseMap(object, token).get(st[st.length - 1]).toString();
	}

	private static Map<String, Object> parseMap(Map<String, Object> object, String token) {
		if (token.contains(".")) {
			String[] st = token.split("\\.");
			object = parseMap((Map<String, Object>) object.get(st[0]), token.replace(st[0] + ".", ""));
		}
		return object;
	}

	public String readDataFromYaml(String token) {
		Reader doc = null;
		try {
			doc = new FileReader("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "BLACKBOARD" + File.separator + "QA_DynamicTestData.yml");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		Yaml yaml = new Yaml();
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);
		return getMapValue(object, token);
	}

	// **************************************************************

	public void verifyAlertMessageOnCoursePage(String message) {
		isElementDisplayed("txt_alertMsg");
		customAssert.assertEquals(element("txt_alertMsg").getText(), message, message + " is not displayed.");
		logMessage("'" + message + "'" + " has been displayed.");
	}

	public void verifyPartialAlertMessageOnCoursePage(String text) {
		isElementDisplayed("txt_alertMsg");
		customAssert.assertTrue(element("txt_alertMsg").getText().contains(text), "Alert not verified");
		logMessage("Alert containing " + "'" + text + "'" + " has been displayed.");
	}

	// Courses > Left Menu
	public void clickOnLeftMenu(String linkName) {
		waitAndClick("link_leftMenu", linkName);
		logMessage("Clicked on " + linkName);
	}

	public void clickOnLeftMenuHomePage() {
		clickOnLeftMenu("Home Page");
	}

	public void clickOnLeftMenuInformation() {
		clickOnLeftMenu("Information");
	}

	public void clickOnLeftMenuContent() {
		clickOnLeftMenu("Content");
	}

	public void clickOnLeftMenuDiscussions() {
		clickOnLeftMenu("Discussions");
	}

	public void clickOnLeftMenuGroups() {
		clickOnLeftMenu("Groups");
	}

	public void clickOnLeftMenuTools() {
		hardWait(4);
		clickOnLeftMenu("Tools");
	}

	public void clickOnLeftMenuHelp() {
		clickOnLeftMenu("Help");
	}

	// Left Menu > Course Management
	public void clickOnUsersAndGroupsCourseManagement() {
		waitScrollAndClick("link_CourseManagement", "Users and Groups");
		logMessage("Clicked Users and Groups link ");
	}

	public void clickOnGradeCenterCourseManagement() {
		waitAndClick("link_CourseManagement", "Grade Center");
	}

	public void navigateToFullGradeCenter() {
		clickOnGradeCenterCourseManagement();
		scroll(element("sublink_CourseManagement", "Grade Center", "Full Grade Center"));
		waitAndClick("sublink_CourseManagement", "Grade Center", "Full Grade Center");
		logMessage("Navigated to 'Full Grade Center' page.");
	}

	public void navigateToUsersPage() {
		clickOnUsersAndGroupsCourseManagement();
		waitAndClick("sublink_CourseManagement", "Users and Groups", "Users");
		logMessage("Navigated to 'Users' page.");
	}

	// Course Home Page
	public void verifyUserIsOnCourseHomePage() {
		isElementDisplayed("txt_PageTitle", "Home Page");
		logMessage("User is on Home Page");
	}

	// Information Page
	public void verifyUserIsOnInformationPage() {
		isElementDisplayed("txt_PageTitle", "Information");
		logMessage("User is on Information Page");
	}

	// Content Page
	public void verifyUserIsOnContentPage() {
		isElementDisplayed("txt_PageTitle", "Content");
		logMessage("User is on Content Page");
	}

	// verify 'content page' header has Build Content, Assessments, Tools,
	// Partner Content
	public void verifyContentPageHeaderMenu() {
		isElementDisplayed("link_contentPage", "Build Content");
		isElementDisplayed("link_contentPage", "Assessments");
		isElementDisplayed("link_contentPage", "Tools");
		isElementDisplayed("link_contentPage", "Partner Content");
		logMessage("Content Page Header is displayed.");
	}

	public void clickContentMarketInPartnerContent() {
//		hardWait(1);
		hover(element("link_contentPage", "Partner Content"));
		hardWait(1);
		waitAndClick("link_contentPage", "Content Market");
		logMessage("'Content Market' is clicked.");
	}

	public void verifyAssignmentDisplayedOnContentPage(String assignmentName) {
		isElementDisplayed("link_firstdeployedAssignment", assignmentName);
		logMessage(assignmentName + " is displayed on Content Page.");
	}

	public void clickAssignmentOnContentPage(String assignmentName) {
		hoverClick(element("link_firstdeployedAssignment", assignmentName));
//		if (YamlReader.getTier().equals("lt"))
		// changeWindow(1);
		logMessage(assignmentName + " clicked on Content Page.");
	}

	public void removeAllDeployedAssignmentsOnContentPage() {
		int count = getElementCount("dropdown_contentList");
		for (int i = 1; i <= count; i++) {
			hover(element("list_topContent"));
//			hardWait(3);
			waitAndClick("dropdown_topContent");
			waitAndClick("link_assignmentOption", "Delete");
			handleAlert();
		}
		logMessage("All Deployed Asssignments have been removed.");
	}

	// Content > Content Market
	public void verifyUserIsOnContentMarketPage() {
		isElementDisplayed("txt_PageTitle", "Content Market");
		isElementDisplayed("txt_usedInThisCourse");
		isElementDisplayed("txt_selectContentProvider");
	}

	public void clickMacmillanInSelectContentProviderOnContentMarketPage() {
		/*
		 * obsolete
		 * if(element("link_availablePartnerSmallcarouselMacmillan").isDisplayed ()){
		 * waitAndClick("link_availablePartnerSmallcarouselMacmillan");
		 * waitAndClick("link_availablePartnerLargecarouselMacmillan"); } else {
		 * waitAndClick("link_availablePartnerleftArrow");
		 * waitAndClick("link_availablePartnerSmallcarouselMacmillan");
		 * waitAndClick("link_availablePartnerLargecarouselMacmillan"); }
		 */
		scroll(element("link_macmillanContentProvider"));
		waitAndClick("link_macmillanContentProvider");
		logMessage("Clicked Macmillan in Content Provider.");
	}

	// content > Macmillan Higher Education Launch Page
	// appear only first time instructor user
	public void verifyUserIsOnMacmillanEducationLaunchPadPage() {
		isElementDisplayed("txt_macmillanHigherTitle");
		customAssert.customAssertTrue(element("txt_userPrivacyInformation").getText().toLowerCase()
				.contains("User Privacy Information".toLowerCase()), "'User Privacy Information' is not found.");
		logMessage("'User Privacy Information' on 'Macmillan Higher Education Launch Page' is verified.");
		isElementDisplayed("radio_agreeShareUserInfo");
		isElementDisplayed("radio_disagreeShareUserInfo");
		customAssert.customAssertTrue(
				element("txt_acknowledgement").getText().toLowerCase().contains("Acknowledgment".toLowerCase()),
				"'Acknowledgment' is not found.");
		logMessage("'Acknowledgment' on 'Macmillan Higher Education Launch Page' is verified.");
		isElementDisplayed("chkBox_acknowledgementDontShowMessage");
		isElementDisplayed("button_launchLaunchPage");
		isElementDisplayed("button_cancelLaunchPage");
	}

	public void clickAgreeUserShareRadioButtonOnMacmillanHigherEducationLaunchPage() {
		waitAndClick("radio_agreeShareUserInfo");
		logMessage(
				"Clicked radio button 'I agree to share my user information with the Macmillan Higher Education system.'");
	}

	public void clickDisagreeUserShareRadioButtonOnMacmillanHigherEducationLaunchPage() {
		waitAndClick("radio_disagreeShareUserInfo");
		logMessage(
				"Clicked radio button 'I do not agree to share my user information with the Macmillan Higher Education system.'");
	}

	public void clickOnShareUserInfoAgree() {
		scroll(element("radio_agreeShareUserInfo"));
		waitAndClick("radio_agreeShareUserInfo");
		logMessage("clicked radio button: Share user info");
	}

	public void clickCheckBoxDontShowAcknowledgementOnMacmillanHigherEducationLaunchPage() {
		waitAndClick("chkBox_acknowledgementDontShowMessage");
		logMessage("clicked checkbox: Do not show me this message again.");
	}

	public void clickMacmillanHigherEducationLaunchPageCancel() {
		waitAndClick("button_cancelLaunchPage");
		logMessage("'Cancel' button on  Macmillan Higher Education Launch Page is clicked.");
	}

	public void clickMacmillanHigherEducationLaunchPageLaunch() {
		// waitAndClick("button_launchLaunchPage");
		waitScrollAndClick("button_launchLaunchPage");
		logMessage("'Launch' button on  Macmillan Higher Education Launch Page is clicked.");
		handleAlert();
		changeWindow(1);
	}

	// first time function ends
	public boolean softverifyUserIsOnMacmillanEducationLaunchPadPage() {
		try {
			wait.resetImplicitTimeout(5);
			WebElement element = wait.waitForElementToBeVisible(element("txt_macmillanHigherTitle"));
			if (element.isDisplayed()) {
				logMessage("User is on Macmillan Education Launchpad Page.");
				return true;
			} else {
				logMessage("User is not on Macmillan Education Launchpad Page.");
				return false;
			}
		} catch (NoSuchElementException e) {
			logMessage("User is not on Macmillan Education Launchpad Page.");
		}
		wait.resetExplicitTimeout(wait.timeout);
		return false;
	}

	// content > Macmillan Higher Education Launch Page ends

	// content > Macmillan Course Assosiation Page
	public void clickCreateNewCourseButtonOnMacmillanAssociationPage(String bookTitle) {
		hardWait(2);
		waitForLoaderToDisappear();
		scroll(element("button_createNewCourse", bookTitle));
		wait.hardWait(3);
		waitAndClick("button_createNewCourse", bookTitle);
		logMessage("Clicked Create New Course button.");
	}

	public void click_ConnectWithAchieve() {
		waitAndClick("link_gettingStarted", "Connect with Achieve");
		changeWindow(1);
	}

	public void click_ConnectWithSapling() {
		waitAndClick("link_gettingStarted", "Connect with Sapling");
		changeWindow(1);
	}

	public void verifySSOPageForAchieve() {
		isElementDisplayed("btn_submit");
		List<WebElement> footer = elements("txt_footer");
		customAssert.customAssertEquals(footer.get(0).getText(), "Privacy Policy", "Privacy Policy text not matched");
		customAssert.customAssertEquals(footer.get(1).getText(), "Terms of Use", "Terms of Use text not matched");
		customAssert.customAssertEquals(footer.get(2).getText(), "Accessibility", "Accessibility text not matched");
		customAssert.customAssertEquals(footer.get(3).getText(), "Refund Policy", "Refund Policy text not matched");
		customAssert.customAssertEquals(footer.get(4).getText(), "Customer Service/Support",
				"Customer Service/Support text not matched");
		logMessage("User is on Macmillan Learning LMSLink Canvas Token Registration page");
	}

	public void submit_SSOPageAndContinue() {
		isElementDisplayed("btn_submit");
		scroll(element("btn_submit"));
		waitAndClick("btn_submit");
		logMessage("User clicked on 'Submit' button");
		hardWait(2);
		waitForElementToBeVisible("btn_continueProvisioning");
		isElementDisplayed("btn_continueProvisioning");
		element("btn_continueProvisioning").click();
		logMessage("User clicked on 'Continue' button");
	}

	public void authenticateToken() {
		isElementDisplayed("btn_authenticate");
		scroll(element("btn_authenticate"));
		waitAndClick("btn_authenticate");
		logMessage("User clicked on 'Authenticate' button");
//		waitAndClick("lnk_userName","Inst Load");
//		changeWindow(2);
//		verifyPageTitleContains("User Settings: Inst Load");
//		closeWindow();
//		isElementDisplayed("btn_cancel");
		isElementDisplayed("btn_loginTokenRegistration");
		element("btn_loginTokenRegistration").click();
		logMessage("User clicked on 'Authorize' button");

		waitForElementToBeVisible("btn_continueTokenRegistration");
		isElementDisplayed("btn_continueTokenRegistration");
		element("btn_continueTokenRegistration").click();
		logMessage("User clicked on 'Continue' button");
	}

	public String associateCourse(String courseName) {
		waitScrollAndClick("btn_associateWithCourseName", courseName);
		waitAndScrollToElement("txt_associateCourseModalTitle");
		isElementDisplayed("txt_associateCourseModalTitle");
		waitAndScrollToElement("button_yesAssociateCourseModal");
		waitAndClick("button_yesAssociateCourseModal");
		waitForLoaderToDisappear();
		String courseId = element("txt_courseIDSuccessModal").getText();
		hardWait(3);
		clickUsingJavaScript("btn_Ok");
		changeWindow(0);
		switchToDefaultContent();
		return courseId;
	}

	public void verifyProvisionPageOpensForSapling() {
		isElementDisplayed("logo_macmillan");
		isElementDisplayed("btn_refresh");
		isElementDisplayed("lnk_ViewMacmillanCatalog");
		isElementDisplayed("inp_courseKey");
		isElementDisplayed("btn_courseKey_Associate");
		logMessage("User is navigated to Provision Page successfully");
	}

	public void verifyTokenRegistrationPage() {
		isStringMatching(element("txt_canvasTokenRegistration").getText(),
				"Macmillan Learning LMSLink Canvas Token Registration");
		// isStringMatching(element("txt_authenticateCanvas").getText(), "Authenticate
		// with your Canvas installation");
		isElementDisplayed("txt_fieldSetBox");
		isElementDisplayed("btn_authenticate");
		List<WebElement> footer = elements("txt_footer");
		customAssert.customAssertEquals(footer.get(0).getText(), "Privacy Policy", "Privacy Policy text not matched");
		customAssert.customAssertEquals(footer.get(1).getText(), "Terms of Use", "Terms of Use text not matched");
		customAssert.customAssertEquals(footer.get(2).getText(), "Accessibility", "Accessibility text not matched");
		customAssert.customAssertEquals(footer.get(3).getText(), "Refund Policy", "Refund Policy text not matched");
		customAssert.customAssertEquals(footer.get(4).getText(), "Customer Service/Support",
				"Customer Service/Support text not matched");
		logMessage("User is on Macmillan Learning LMSLink Canvas Token Registration page");
	}

	public void createNewCourseMacmillanAssociationPage(String bookTitle, String courseTitle, String courseNumber,
			String sectionNumber, String instructorName, String academicTerm, Boolean isTimeZonePresent,
			String timeZone, String middleWareName) {
		waitAndClick("link_gettingStarted", middleWareName);
		changeWindow(1);
		List<WebElement> submitPres = elements("btn_submit");
		if (submitPres.size() > 0)
			submit_SSOPageAndContinue();
		clickCreateNewCourseButtonOnMacmillanAssociationPage(bookTitle);
		waitForLoaderToDisappear();
		hardWait(5);
		waitAndScrollToElement("input_courseTitle");
		fillText("input_courseTitle", courseTitle);
		logMessage("Filled Course Title: " + courseTitle);
		waitAndScrollToElement("input_courseNumber");
		fillText("input_courseNumber", courseNumber);
		logMessage("Filled Course Number: " + courseNumber);
		waitAndScrollToElement("input_sectionNumber");
		fillText("input_sectionNumber", sectionNumber);
		logMessage("Filled Section Number: " + sectionNumber);
		waitAndScrollToElement("input_instructorName");
		fillText("input_instructorName", instructorName);
		logMessage("Filled Instructor Name: " + instructorName);
		waitAndScrollToElement("dropDown_academicTerm");
		selectTextFromDropDown("dropDown_academicTerm", academicTerm);
		logMessage("Selected Academic Term: " + academicTerm);
		if (isTimeZonePresent) {
			waitAndScrollToElement("dropDown_timeZone");
			selectTextFromDropDown("dropDown_timeZone", timeZone);
			logMessage("Selected timezone: " + timeZone);
		}
		scroll(element("button_createNewCourseModal"));
		waitAndClick("button_createNewCourseModal");
		logMessage("Clicked 'Create New Course'");
	}

	public void clickOnSapling() {
		waitAndClick("link_sapling");
		changeWindow(2);
		logMessage("Clicked on sapling link after association");
	}

	public void verifyCourseCreatedMacmillanAssociationPage(String courseName) {
		waitForLoaderToDisappear();
		waitAndScrollToElement("txt_courseName", courseName);
		isElementDisplayed("txt_courseName", courseName);
		logMessage(courseName + " has been verified.");
	}

	public String getNextDate() {
		Date today = new Date();
		SimpleDateFormat formattedDate = new SimpleDateFormat("MMM dd, YYYY");
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 1); // number of days to add
		return (formattedDate.format(c.getTime()));
	}

	public void createQuizAssessmentForSapling(String assignmentName) {

		removePreviousAssessment(assignmentName);
		selectTextFromDropDown("drpDown_AddActivity", "Assessment");
		fillText("assessmentName", assignmentName);
		List<WebElement> list = elements("checkbox_date");
		scroll(list.get(0));
		scrollDownWithGivenDimension(-300);
		list.get(0).click();
		list.get(1).click();
		wait.hardWait(4);
		executeJavascript("document.querySelectorAll('.datePicker-date.availableDate.hasDatepicker')[1].value='"
				+ getNextDate() + "'");
		scroll(element("btn_saveNContinue"));
		waitAndClick("btn_saveNContinue");
		switchToFrame("iframe_description");
		wait.hardWait(15);
		waitAndClick("questionList");
		waitAndClick("btn_addQuestion");
		closeWindow();
		changeWindow(1);
	}

	public void createQuizAssessmentForSapling(String assignmentName, String testRunEnvironment) {

		removePreviousAssessmentForSap(assignmentName);
		selectTextFromDropDown("drpDown_AddActivity", "Assessment");
		fillText("assessmentName", assignmentName);
		List<WebElement> list = elements("checkbox_date");
		scroll(list.get(0));
		scrollDownWithGivenDimension(-300);
		list.get(0).click();
		list.get(1).click();
		wait.hardWait(4);
		executeJavascript("document.querySelectorAll('.datePicker-date.availableDate.hasDatepicker')[1].value='"
				+ getNextDate() + "'");
		scroll(element("btn_saveNContinue"));
		waitAndClick("btn_saveNContinue");
		switchToFrame("iframe_description");
		waitForElementToBeVisible("btn_QuestionBank");

		waitAndClick("btn_QuestionBank");
		wait.hardWait(4);
		switchToFrame("iframe_QuestionList");
		if (testRunEnvironment.equalsIgnoreCase("prod"))
			element("input_filter")
					.sendKeys("Determine whether a verbal representation of a relation is a function and explain why.");
		waitForElementToBeVisible("questionList");
		waitAndClick("questionList");
		waitForElementToBeVisible("btn_addQuestion");
		waitAndClick("btn_addQuestion");
		closeWindow();
		changeWindow(0);
	}

	public void removePreviousAssessment(String assessName) {
		List<WebElement> assessList = elements("btn_assessment", assessName);
		for (int i = 0; i < assessList.size(); i++) {
			assessList.get(i).click();
			wait.hardWait(2);
			waitAndClick("link_delete", assessName);
		}
		waitAndClick("btn_yes");
		logMessage("Remove all the assessment");
	}

	public void removePreviousAssessmentForSap(String assessName) {
		List<WebElement> assessList = elements("btn_assessment", assessName);
		List<WebElement> deleteLinkList = elements("link_delete", assessName);
		while (assessList.size() > 0) {
			assessList.get(0).click();
			wait.hardWait(2);
			deleteLinkList.get(0).click();
			refreshPage();
			assessList = elements("btn_assessment", assessName);
			waitAndClick("btn_yes");
			deleteLinkList = elements("link_delete", assessName);
		}

		logMessage("Remove all the assessment");
	}

	public String clickAssociateMacmillanAssociationPage(String courseName, String middlewareName) {
		hardWait(3);
		waitAndClick("button_associateWithCourseName", courseName);
		waitAndScrollToElement("txt_associateCourseModalTitle");
		isElementDisplayed("txt_associateCourseModalTitle");
		waitForElementToBeClickable(element("button_yesAssociateCourseModal"));
		hardWait(3);
		waitAndScrollToElement("button_yesAssociateCourseModal");
		waitAndClick("button_yesAssociateCourseModal");
		waitForLoaderToDisappear();
		String courseId = element("txt_courseIDSuccessModal").getText();
		waitAndScrollToElement("button_backToBlackboardCourseAssociation");
		waitAndClick("button_backToBlackboardCourseAssociation");
		return courseId;
	}

	public String clickAssociateMacmillanAssociationPage1(String courseName) {
		hardWait(3);
		waitAndClick("button_associateWithCourseName", courseName);
		waitAndScrollToElement("txt_associateCourseModalTitle");
		isElementDisplayed("txt_associateCourseModalTitle");
		waitForElementToBeClickable(element("button_yesAssociateCourseModal"));
		hardWait(3);
		waitAndScrollToElement("button_yesAssociateCourseModal");
		waitAndClick("button_yesAssociateCourseModal");
		waitForLoaderToDisappear();
		String courseId = element("txt_courseIDSuccessModal").getText();
		waitAndScrollToElement("button_backToBlackboardCourseAssociation");
		waitAndClick("button_backToBlackboardCourseAssociation");
		return courseId;
	}

	public void click_BackToBB() {
		waitAndScrollToElement("btn_BackToBB");
		waitAndClick("btn_BackToBB");
	}

	public String clickAssociateMacmillanAssociationPageForSapling(String courseName) {
		waitAndClick("button_associateWithCourseName", courseName);
		waitAndScrollToElement("txt_associateCourseModalTitle");
		isElementDisplayed("txt_associateCourseModalTitle");
		waitForElementToBeClickable(element("button_yesAssociateCourseModal"));
		hardWait(3);
		waitAndScrollToElement("button_yesAssociateCourseModal");
		waitAndClick("button_yesAssociateCourseModal");
		waitForLoaderToDisappear();
		String courseId = element("txt_courseIDSuccessModal").getText();
		waitAndScrollToElement("button_backToBlackboardCourseAssociation");
		waitAndClick("button_backToBlackboardCourseAssociation");
		return courseId;
	}

	public void reConnectCourseForBlackboardSap() {
		waitAndClick("link_unlinkMacmillanCourse");
		assertTrue(element("sapling_Logo").isDisplayed(), "sapling learning is not displayed");
		waitAndClick("btn_disassociateCourse");
		isElementDisplayed("reConnect_Course");
		waitAndClick("reConnect_Course");
		hardWait(5);
		// waitForElementToBeVisible("txt_successReconnectCourse");
		assertTrue(element("txt_successReconnectCourse").isDisplayed(), "success message is not displayed");
		waitAndClick("backtoBlackBoard");
		logMessage("reconnect method");
	}

	public void viewAvailableCoursesForBB(String courseName) {
		assertTrue(element("pageTitle").isDisplayed(), "Macmillan Learning Tools is not displayed");
		waitAndClick("link_unlinkMacmillanCourse");
		assertTrue(element("sapling_Logo").isDisplayed(), "sapling learning is not displayed");
		waitAndClick("btn_disassociateCourse");
		waitAndClick("availableCourses");
		assertTrue(element("sapling_Courses").isDisplayed(), "sapling courses is not displayed");
		waitAndClick("button_associateWithCourseName", courseName);
		waitAndScrollToElement("txt_associateCourseModalTitle");
		isElementDisplayed("txt_associateCourseModalTitle");
		waitForElementToBeClickable(element("button_yesAssociateCourseModal"));
		hardWait(3);
		waitAndScrollToElement("button_yesAssociateCourseModal");
		waitAndClick("button_yesAssociateCourseModal");
		waitForLoaderToDisappear();
		String courseId = element("txt_courseIDSuccessModal").getText();
		waitAndScrollToElement("button_backToBlackboardCourseAssociation");
		waitAndClick("button_backToBlackboardCourseAssociation");
	}

	public void reConnectForBBAchieve() {
		clickUnlinkMacmillanCourseOnMacmillanHigherEducationToolsPage();
		verifyUserIsOnSeverThisCourseAssociation();
		clickDisassociateThisCourseOnSeverThisCourseAssociationPage();
		verifyUserIsOnCourseLinkSeveredPage();
		clickReconnectThisCourseOnCourseLinkSeveredPage();
		verifycourseReconnected();
		clickBackToBlackboardUnlinkMacmillanCourse();
	}

	public void viewAvailableCourseBBLP(String courseName, String message) {
		assertTrue(element("pageTitle").isDisplayed(), "Macmillan Learning Tools is not displayed");
		clickUnlinkMacmillanCourseOnMacmillanHigherEducationToolsPage();
		verifyUserIsOnSeverThisCourseAssociation();
		clickDisassociateThisCourseOnSeverThisCourseAssociationPage();
		verifyUserIsOnCourseLinkSeveredPage();
		waitAndClick("availableCourses");
		hardWait(7);
		clickAssociateMacmillanAssociationPage(courseName, message);

	}

	// Discussions Page
	public void verifyUserIsOnDiscussionsPage() {
		isElementDisplayed("txt_PageTitle", "Discussion Board");
		logMessage("User is on Content Page");
	}

	// Group Page
	public void verifyUserIsOnGroupsPage() {
		isElementDisplayed("txt_PageTitle", "Groups");
		logMessage("User is on Content Page");
	}

	// Tools Page
	public void verifyUserIsOnToolsPage() {
		isElementDisplayed("txt_PageTitle", "Tools");
		logMessage("User is on Tools Page");
	}

	public void clickContentMarketToolsOnToolsPage() {
		scroll(element("link_contentMarketTools"));
		waitAndClick("link_contentMarketTools");
		logMessage("Clicked 'Content Market Tools' on Tools Page.");
	}

	// Tools Page ends

	// Content Market Tools Page
	public void verifyUserIsOnContentMarketToolsPage() {
		isElementDisplayed("txt_PageTitle", "Content Market Tools");
		logMessage("User is on Content Market Tool");
	}

	public void clickLaunchPadInAssociatedPartners() {
		isElementDisplayed("txt_asociatedPartnersHeading");
		waitAndClick("link_launchpadAvailablePartners");
		logMessage("Clicked LaunchPad for Psychology in Associated Partners.");
	}

	public void click_AvialablePartner() {
		isElementDisplayed("link_availablePartner");
		waitAndClick("link_availablePartner");
		logMessage("Clicked on Available Partner");
	}

	public void clickMacmillanInContentProviderOnContentMarketTools() {
		isElementDisplayed("txt_selectContentProvider");
		scroll(element("link_macmillanContentProvider"));
		waitAndClick("link_macmillanContentProvider");
		logMessage("Clicked 'Macmillan Highered Education' in Content Provider On Content Market Tools.");
	}

	public void clickMacmillanOnUsedInThisCourseOnContentMarketTools() {
		isElementDisplayed("txt_usedInThisCourse");
		waitAndClick("link_macmillanUsedInThisCourse");
		logMessage("Clicked 'Macmillan Learning' in 'Used in this Course' On Content Market Tools.");
	}

	// Content Market Tools Page ends

	// Content Market Tools > Macmillan Higher Education Tools Page
	public void verifyUserIsOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("txt_PageTitle", "Macmillan Learning Tools");
		isElementDisplayed("txt_macmillanHigherEducationSupportToolsTitle");
		logMessage("User is on 'Macmillan Higher Education Tools Page'.");
	}

	public void clickonMacmilanToo() {
		hardWait(3);
		element("lin_macTool").click();
	}

	public void verifyGettingStartedPresentOnMacmillanHigherEducationToolsPage(String middleWareName) {
		isElementDisplayed("link_gettingStarted", middleWareName);
		logMessage("'Getting Started...' is displayed on Macmillan Higher Education Tools Page.");
	}

	public void verifyLaunchPadPresentOnMacmillanHigherEducationToolsPage() {
//		isElementDisplayed("link_launchPadMacmillanTools");
		logMessage("LaunchPad is displayed on Macmillan Higher Education Tools Page.");
	}

	public void verifyAchievePresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_AchieveMacmillanTools");
		logMessage("Achieve is displayed on Macmillan Higher Education Tools Page.");
	}

	public void clickAchieveOnMacmillanHigherEducationToolsPage() {
		waitAndClick("link_AchieveMacmillanTools");
		logMessage("Clicked on Achieve - Macmillan Higher Education Tools Page.");
	}

	public void useToolLink() {
		waitForElementToBeVisible("toolLink");
		waitAndClick("toolLink");
		logMessage("Selected available integration tool from Macmillan Learning tools page");
	}

	public void clickLaunchPadOnMacmillanHigherEducationToolsPage() {
		hoverClick(element("link_launchPadMacmillanTools"));
		logMessage("Clicked on LaunchPad - Macmillan Higher Education Tools Page.");
	}

	public void verifyEbookPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_ebookMcmillanTools");
		logMessage("Ebook is dispayed on Macmillan Higher Education Tools Page.");
	}

	public void clickEbookOnMacmillanHigherEducationToolsPage() {
		waitAndClick("link_ebookMcmillanTools");
		logMessage("Clicked on E-book - Macmillan Higher Education Tools Page.");
	}

	public void verifyGradebookPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_gradebookMacmillanTools");
		logMessage("Gradebook is displayed on Macmillan Higher Education Tools Page.");
	}

	public void clickGradebookOnMacmillanHigherEducationToolsPage() {
		waitAndClick("link_gradebookMacmillanTools");
		logMessage("Clicked on Gradebook - Macmillan Higher Education Tools Page.");
	}

	public void verifyMacmillanHigherEducationDiagnosticsPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_macmilanHigheredEducationDiagnostics");
		logMessage("Macmillan Higher Education Diagnostics is dispayed on Macmillan Higher Education Tools Page.");
	}

	public void clickMacmillanHigherEducationDiagnosticsOnMacmillanHigherEducationToolsPage() {
		scroll(element("link_macmilanHigheredEducationDiagnostics"));
		waitAndClick("link_macmilanHigheredEducationDiagnostics");
		logMessage("Clicked on 'Macmillan Higher Education Diagnostics' - Macmillan Higher Education Tools Page.");
	}

	public void verifyMacmillanTechnicalSupportPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_macmillanTechnicalSupport");
		logMessage("Macmillan Technical Support is displayed on Macmillan Higher Education Tools Page.");
	}

	public void clickMacmillanTechnicalSupportOnMacmillanHigherEducationToolsPage() {
		waitAndClick("link_macmillanTechnicalSupport");
		logMessage("Clicked on 'Macmillan Technical Support' - Macmillan Higher Education Tools Page.");
	}

	public void verifyMacmillanUserProfilePresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_macmillanUserProfile");
		logMessage("Macmillan User Profile is displayed on Macmillan Higher Education Tools Page.");
	}

	public void unlink_macmillan_Learning_User_Profile(String emailUser) {
		changeWindow(1);
		waitForElementToBeVisible("macmillan_userProfileLink");
		scroll(element("macmillan_userProfileLink"));
		waitAndClick("macmillan_userProfileLink");
		logMessage("Clicked on 'Macmillan User Profile link");
		hardWait(4);
		System.out.println("Total window instances are ----------->" + driver.getWindowHandles());
		changeWindow(2);
		if (!softVerifyProfileIsLinked()) {
			closeWindowAndSwitchBackToOriginalWindow(1);
			;
			throw new SkipException("Profile already disconnected");
		}
		verifyMacmillanUserProfilePageWhenConnected(emailUser);
		clickOnDisconnectThisAccount();
		clickBtnConfirmDisconnect();
		closeWindowAndSwitchBackToOriginalWindow(1);

	}

	public boolean softVerifyProfileIsLinked() {
		boolean isPresent = false;

		String text = executeJavascriptAndReturnValue(
				"document.getElementsByClassName('right-content-contain').item(0).textContent");

		if (text.contains("Profile not found.")) {
			logMessage("Profile is already unlinked");
			isPresent = false;
		} else {
			logMessage("Profile is linked");
			isPresent = true;
		}
		return isPresent;
	}

	public void clickMacmillanUserProfileOnMacmillanHigherEducationToolsPage() {
		scroll(element("link_macmillanUserProfile"));
		waitAndClick("link_macmillanUserProfile");
		logMessage("Clicked on 'Macmillan User Profile' - Macmillan Higher Education Tools Page.");
//		changeWindow(1);
//		waitAndClick("link_macmillanUserProfile");
//		changeWindow(2);
//		closeWindowAndSwitchBackToOriginalWindow(1);
	}

	public void clickBtnConfirmDisconnect() {
		element("btn_disconnectConfirm").isDisplayed();
		click(element("btn_disconnectConfirm"));
		logMessage("Clicked on yes Disconnect this account");

	}

	public void clickOnDisconnectThisAccount() {
		verifyPageTitleContains("User Profile");
		element("lnk_disconnectAccount").isDisplayed();
		element("lnk_disconnectAccount").click();
		logMessage("Clicked on Disconnect this Account");
		hardWait(3);
	}

	public void verifyMacmillanUserProfilePageWhenConnected(String emailUser) {
		verifyPageTitleContains("User Profile");
		isElementDisplayed("lnk_disconnectAccount");
//		isElementDisplayed("txt_emailUser", emailUser);
		logMessage("User is on 'User Profile' page");
	}

	public void verifyMacmillanRosterInformationPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_macmillanRosterInformation");
		logMessage("Macmillan Roster Information is displayed on Macmillan Higher Education Tools Page.");
	}

	public void clickMacmillanRosterInformationOnMacmillanHigherEducationToolsPage() {
		scroll(element("link_macmillanRosterInformation"));
		waitAndClick("link_macmillanRosterInformation");
		logMessage("Clicked on 'Macmillan Roster Information' - Macmillan Higher Education Tools Page.");
	}

	public void verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_macmillanGradeRefresh");
		logMessage("Macmillan Grade Refresh is displayed on Macmillan Higher Education Tools Page.");
	}

	public void clickMacmillanGradeRefreshOnMacmillanHigherEducationToolsPage() {
		scroll(element("link_macmillanGradeRefresh"));
		waitAndClick("link_macmillanGradeRefresh");
		logMessage("Clicked on 'Macmillan Grade Refresh' on Macmillan Higher Education Tools Page.");
	}

	public void verifyUnlinkMacmillanCoursePresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_unlinkMacmillanCourse");
		logMessage("Unlink Macmillan Course is displayed on Macmillan Higher Education Tools Page.");
	}

	public void clickUnlinkMacmillanCourseOnMacmillanHigherEducationToolsPage() {
		scroll(element("link_unlinkMacmillanCourse"));
		waitAndClick("link_unlinkMacmillanCourse");
		logMessage("Clicked on 'Unlink Macmillan Course' on Macmillan Higher Education Tools Page.");

	}

	public void verifyMacmillanContentRefreshPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_macmillanContentRefresh");
		logMessage("Macmillan Content Refresh is displayed on Macmillan Higher Education Tools Page.");
	}

	public void clickMacmillanContentRefreshOnMacmillanHigherEducationToolsPage() {
		scroll(element("link_macmillanContentRefresh"));
		waitAndClick("link_macmillanContentRefresh");
		logMessage("Clicked on 'Macmillan Content Refresh' on Macmillan Higher Education Tools Page.");
	}

	public void verifySuccessfulGradeUpdateAlert() {
		verifyPartialAlertMessageOnCoursePage("Success");
	}

	public void clickMacmillanHigherEducationToolsBreadcrumbs() {
		// scroll(element("link_macmillanHigherEducationToolsBreadcrumb"));
		hardWait(3);
		// waitAndClick("link_macmillanHigherEducationToolsBreadcrumb");
		element("link_macmillanHigherEducationToolsBreadcrumb").click();
		logMessage("Clicked on 'Macmillan Higher Education Tools' on breadcrumb");
	}

	// compound methods
	public void unlinkMacmillanCourse(String middleWareName) {
		if (getElementCount("link_unlinkMacmillanCourse") == 1) {
			System.out.println("if condition true");
			clickUnlinkMacmillanCourseOnMacmillanHigherEducationToolsPage();
			verifyUserIsOnSeverThisCourseAssociation();
			clickDisassociateThisCourseOnSeverThisCourseAssociationPage();
			verifyUserIsOnCourseLinkSeveredPage();
			clickBackToBlackboardUnlinkMacmillanCourse();
			verifyUserIsOnMacmillanHigherEducationToolsPage();
			verifyGettingStartedPresentOnMacmillanHigherEducationToolsPage(middleWareName);
			logMessage("Macmillan Course has been unlinked from the course.");
		} else {
			System.out.println("else condition true");
			verifyUserIsOnMacmillanHigherEducationToolsPage();
			verifyGettingStartedPresentOnMacmillanHigherEducationToolsPage(middleWareName);
			logMessage("Macmillan Course was already unlinked from the course.");
		}
	}

	// Content Market Tools > Macmillan Higher Education Tools Page ends

	// Content Market Tools > Macmillan Higher Education Tools > Macmillan
	// Higher Education Integration Diagnostics
	public void verifyUserIsOnMacmillanHigherEducationIntegrationDiagnosticsPage() {
		isElementDisplayed("txt_PageTitle", "Macmillan Learning Integration Diagnostics");
		logMessage("User is on 'Macmillan Learning Integration Diagnostics' page.");
		navigateBack();

	}

	// Content Market Tools > Macmillan Higher Education Tools > Macmillan User
	// Profile
	public void verifyUserIsOnMacmillanUserProfilePage() {
		changeWindow(1);
		isElementDisplayed("txt_macmillanUserProfileTitle");
		logMessage("User is on 'Macmillan User Profile' page.");
	}

	public void clickBackToBlackboardOnMacmillanUserProfile() {
		waitAndClick("button_backToBlackboardUserProfile");
		logMessage("Clicked on 'Back to Blackboard' on Macmillan User Profile.");
	}

	// Content Market Tools > Macmillan Higher Education Tools > Macmillan
	// Higher Education Roster
	public void verifyUSerIsOnMacmillanHigherEducationRosterPage() {
		isElementDisplayed("txt_PageTitle", "Macmillan Learning Roster");
		logMessage("User is on 'Macmillan Learning Roster' page.");
	}

	// Content Market Tools > Macmillan Higher Education Tools > Macmillan
	// Higher Education Grade Sync Refresh
	public void verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage() {
		isElementDisplayed("txt_PageTitle", "Macmillan Learning Grade Sync Refresh");
		logMessage("User is on 'Macmillan Learning Grade Sync Refresh' page.");
	}

	public void selectContentOnMacmillanHigherEducationGradeSyncRefresh(String content) {
		scroll(element("input_contentGradeRefresh", content));
		waitAndClick("input_contentGradeRefresh", content);
		logMessage(content + " has been selected.");
	}

	public void clickSubmitOnMacmillanHigherEducationGradeSyncRefresh() {
		scroll(element("button_submitGradeSyncRefresh"));
		hardWait(3);
		waitAndClick("button_submitGradeSyncRefresh");
		logMessage("Clicked 'Submit' button on Macmillan Learning Grade Sync Refresh");
	}

	// Content Market Tools > Macmillan Higher Education Tools > Macmillan
	// Higher Education Grade Sync Refresh ends

	// Content Market Tools > Macmillan Higher Education Tools > Unlink
	// Macmillan Course
	public void verifyUserIsOnSeverThisCourseAssociation() {
		isElementDisplayed("txt_serverThisCourseAssociation");
		logMessage("User is on 'Sever this Course Association' page.");
	}

	public void clickDisassociateThisCourseOnSeverThisCourseAssociationPage() {
		scroll(element("btn_disassociateCourse"));
		waitAndClick("btn_disassociateCourse");
		logMessage("Clicked 'Yes, Disassociate this Course' button on 'Sever this Course Association' Page.");
	}

	public void clickCancelOnSeverThisCourseAssociationPage() {
		waitAndScrollToElement("btn_cancel");
		waitAndClick("btn_cancel");
		logMessage("Clicked 'Cancel' button on 'Sever this Course Association' Page.");
	}

	public void verifyUserIsOnCourseLinkSeveredPage() {
		isElementDisplayed("txt_courseLinkSevered");
		logMessage("User is on 'Course Link Severed' page.");
	}

	public void clickBackToBlackboardUnlinkMacmillanCourse() {
		waitAndClick("link_backToBlackboardUnlinkMacmillanCourse");
		logMessage("Clicked 'Back to Blackboard'");
	}

	public void clickReconnectThisCourseOnCourseLinkSeveredPage() {
		hardWait(2);
		waitAndClick("link_reconnectCourse");
		logMessage("Clicked 'Reconnect this course' on 'Course Link Severed' page.");
	}

	public void verifycourseReconnected() {
		isElementDisplayed("txt_successReconnectCourse");
		logMessage("Course has been successfully reconnnected.");
	}

	// Content Market Tools > Macmillan Higher Education Tools > Unlink
	// Macmillan Course ends

	// Content Market Tools > Macmillan Higher Education Tools > Macmillan
	// Higher Education Content Refresh
	public void verifyUserIsOnMacmillanHigherEducationContentRefreshPage() {
		isElementDisplayed("txt_PageTitle", "Macmillan Learning Content Refresh");
		logMessage("User is on 'Macmillan Learning Content Refresh' page.");
	}

	// Content > Content Market > Add Macmillan Higher Education Content
	public void verifyUserIsOnAddMacmillanHigherEducationContentPage() {
		isElementDisplayed("txt_pageTitle", "Add Macmillan Learning Content");
		logMessage("User is on 'Add Macmillan Learning Content' page.");
	}

	private boolean isListExpandedAddMacmillanHigherEducationContentPage(String listElement, String replacement) {
		String expanded = element(listElement, replacement).getAttribute("aria-expanded");
		if (expanded.equalsIgnoreCase("true"))
			return true;
		else if (expanded.equalsIgnoreCase("false"))
			return false;
		return false;
	}

	private boolean isListLoadedAddMacmillanHigherEducationContentPage(String listElement, String replacement) {
		String loaded = element(listElement, replacement).getAttribute("aria-busy");
		if (loaded.equalsIgnoreCase("true"))
			return true;
		else if (loaded.equalsIgnoreCase("false"))
			return false;
		return false;
	}

	public void showLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPage() {
		if (!isListExpandedAddMacmillanHigherEducationContentPage("list_addMacmillanContent", "LaunchPad Units")) {
			waitAndClick("arrow_addMacmillanContent", "LaunchPad Units");
			if (!isListExpandedAddMacmillanHigherEducationContentPage("list_addMacmillanContent", "Assignments")) {
				waitAndClick("arrow_addMacmillanContent", "Assignments");
				logMessage("Assignments have been expanded.");
			}
		} else {
			logMessage("Launchpad Units are already expanded.");
		}
	}

	public void showLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPageForAchieve() {
		if (!isListExpandedAddMacmillanHigherEducationContentPage("list_addMacmillanContent", "Assignments")) {
			waitAndClick("arrow_addMacmillanContent", "Assignments");
			logMessage("Assignments have been expanded.");
		} else {
			logMessage("Launchpad Units are already expanded.");
		}
	}

	public void showLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPageForSapling() {
		if (!isListExpandedAddMacmillanHigherEducationContentPage("list_addMacmillanContent", "Assignments")) {
			waitAndClick("arrow_addMacmillanContent", "Assignments");
			logMessage("Assignments have been expanded.");
		} else {
			logMessage("Launchpad Units are already expanded.");
		}
	}

	public void hideLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPage() {
		if (isListExpandedAddMacmillanHigherEducationContentPage("list_launchpadUnits", "LaunchPad Units")) {
			waitAndClick("arrow_addMacmillanContent", "LaunchPad Units");
			logMessage("Launchpad Units have been collapsed.");
		} else {
			logMessage("Launchpad Units are already collapsed.");
		}
	}

	public void verifyAssignmentsOnAddMacmillanHigherEducationContentPage(String assignmentName) {
		// optional invoke
		// showOrHideLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPage()
		// before using it
		isElementDisplayed("txt_addMacmillanContent", assignmentName);
		logMessage(assignmentName + " is displayed.");
	}

	public void checkAssignmentsOnAddMacmillanHigherEducationContentPage(String assignmentName) {
		// optional invoke
		// showOrHideLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPage()
		// before using it
		verifyAssignmentsOnAddMacmillanHigherEducationContentPage(assignmentName);
		hardWait(5);
		waitForElementToBeClickable(element("chkbox_addMacmillanContent", assignmentName));
		hardWait(3);
		waitAndClick("chkbox_addMacmillanContent", assignmentName);
		logMessage(assignmentName + " has been checked.");
	}

	public void clickSubmitOnAddMacmillanHigherEducationContentPage() {
		waitAndClick("button_submitContentPicker");
		logMessage("Clicked Submit button on Add Macmillan Higher Education Content page.");
	}

	public void clickCancelOnAddMacmillanHigherEducationContentPage() {
		waitAndClick("button_cancelContentPicker");
		logMessage("Clicked cancel button on Add Macmillan Higher Education Content page.");
	}

	// Content > Content Market > Add Macmillan Higher Education Content ends

	// Content > Content Market > Add Macmillan Higher Education Content >
	// Selected Macmillan Higher Education Content
	public void verifyUserIsOnSelectedMacmillanHigherEducationContentPage() {
		isElementDisplayed("txt_selectedMacmillanHigherEducationContentTitle");
		logMessage("User is on 'Selected Macmillan Higher Education Content Page'.");
	}

	public void checkSelectAllOnSelectedMacmillanHigherEducationContentPage() {
		scroll(element("chkbox_selectAllSelectedMacmillanContent"));
		waitAndClick("chkbox_selectAllSelectedMacmillanContent");
		logMessage("Checked all assignments on 'Selected Macmillan Learning Content' Page.");
	}

	public void clickSubmitButtonOnSelectedMacmillanContentPage() {
		scroll(element("buttonSubmitSelectedMacmillanContent"));
		waitAndClick("buttonSubmitSelectedMacmillanContent");
		logMessage("Clicked Submit button on 'Selected Macmillan Higher Education Content' Page.");
	}

	// Content > Content Market > Add Macmillan Higher Education Content >
	// Selected Macmillan Higher Education Content ends

	// Full Grade Center
	public void verifyUserIsOnFullGradeCenterPage() {
		isElementDisplayed("txt_fullGradeCenterTitle");
		logMessage("User is on 'Full Grade Center' Page.");
	}

	public String getContentColumnNumberOnFullGradeCenterPage(String contentName) {
		isElementDisplayed("txt_contentHeadingFullGradeCenter", contentName);
		String columnID = element("txt_contentHeadingFullGradeCenter", contentName).getAttribute("id");
		return columnID.split("_")[2];
	}

	public String getUsernameRowNumberOnFullGradeCenterPage(String userName) {
//		scrollToElementUsingJavaScript();
//		scrollToElementUsingJavaScript("tableCell_studentUserNameFullGradeCenter",userName);
//		dragAndDropToParticularPosition(element("scrollbar_forGradeTable"), 1206, 402);
		isElementDisplayed("tableCell_studentUserNameFullGradeCenter", userName);
		String rowID = element("tableCell_studentUserNameFullGradeCenter", userName).getAttribute("id");
		return rowID.split("_")[1];
	}

	public void verifyContentScoreOnFullGradeCenterPage(String userName, String contentName, String contentScore) {
		String columnNumber = getContentColumnNumberOnFullGradeCenterPage(contentName);
		String rowNumber = getUsernameRowNumberOnFullGradeCenterPage(userName);
		String cellID = "cell_" + rowNumber + "_" + columnNumber;
		waitAndScrollToElement("link_tableDataFullGradeCenter", cellID);
		verifyTextOfElementIsCorrect("link_tableDataFullGradeCenter", cellID, contentScore);
	}

	// Full Grade Center ends

	// Users Page
	public void verifyUserIsOnUserPage() {
		isElementDisplayed("txt_PageTitle", "Users");
		logMessage("User is on 'Users' Page.");
	}

	public void verifyUsernameDisplayedOnUsersPage(String username) {
//		isElementDisplayed("txt_usernameListUserPage", username);
		logMessage(username + " displayed on Users Page.");
	}

	// User > Create User Page
	public void verifyUserIsOnCreateUserPage() {
		isElementDisplayed("txt_pageTitle", "Create User");
		logMessage("User is on 'Create User' Page.");
	}

	public void createNewUser(String firstName, String lastName, String email, String userName, String password,
			String role) {
		wait.waitForElementToBeVisible(element("link_enrollUser"));
		hover(element("link_enrollUser"));
		wait.waitForElementToBeVisible(element("link_createUser"));
		element("link_createUser").click();
		verifyUserIsOnCreateUserPage();
		fillText("input_firstName", firstName);
		fillText("input_lastName", lastName);
		fillText("input_email", email);
		fillText("input_userName", userName);
		fillText("input_password", password);
		fillText("input_verifyPassword", password);
		scroll(element("radio_role", role));
		waitAndClick("radio_role", role);
		wait.waitForElementToBeVisible(element("button_submitBottomCreateUser"));
		element("button_submitBottomCreateUser").click();
		verifyUserIsOnUserPage();
		logMessage(userName + " has been created.");
	}

	public void removeAllUsersExceptGivenUser(String userName) {
		waitAndScrollToElement("input_selectAllUsers");
		selectCheckbox("input_selectAllUsers");
		waitAndScrollToElement("chkbox_userbyUserName", userName);
		unselectCheckbox("chkbox_userbyUserName", userName);
		waitAndClick("btn_removeUserFromCourse");
		handleAlert();
		logMessage("All users except login user has been removed.");
	}

	public void removeAllUsersExceptInstructors() {
		if (YamlReader.getTier().equalsIgnoreCase("prod")) {

		} else {
			waitAndScrollToElement("input_selectAllUsers");
			selectCheckbox("input_selectAllUsers");
			int instructorCount = getElementCount("td_instructorCount");
			System.out.println("Instructor count - " + instructorCount);
			for (int count = 1; count <= instructorCount; count++) {
				scroll(element("chkbox_selectInstructorByNumber", String.valueOf(count)));
				unselectCheckbox("chkbox_selectInstructorByNumber", String.valueOf(count));
			}
			waitAndClick("btn_removeUserFromCourse");
			handleAlert();
			logMessage("All users except login user has been removed.");
		}
	}

	public void userNavigateToPxWindow() {
		handleAlert();
	}

	public void verify_User_Is_On_AchieveSide() {
		hardWait(10);
		waitForLoaderToDisappear();
		waitForElementToBeVisible("img_AchieveLogo");
		isElementDisplayed("img_AchieveLogo");
	}

	public void verify_User_Is_On_LPSide() {
		changeWindow(1);
		hardWait(10);
		waitForLoaderToDisappear();
		assertTrue(element("txt_freeTrial").isDisplayed(),
				"The free Trial text is not displayed on" + " Launchpad homepage");
		assertTrue(element("purchase_Access").isDisplayed(), "the purchase access is not displayed");
		assertTrue(element("enter_Access_Code").isDisplayed(), "the enter acess code is not diplayed");
	}

	public void selecting_CourseEndDate() {
		isElementDisplayed("due_CalenderDate");
		waitAndClick("due_CalenderDate");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("var first = {" + "  second: function myFunc7(){"
				+ "document.getElementsByClassName('_2eGJ wbLx').item(0).click();"
				+ "document.getElementsByClassName('_2XMC ').item(9).click();" + "}};" + "   first.second();");

	}

	public void verifyGradebookForAchieve() {
		waitForElementToBeVisible("link_menuItem", "Gradebook");
		isElementDisplayed("link_menuItem", "Gradebook");
		waitAndClick("link_menuItem", "Gradebook");
		waitForElementToBeVisible("inpt_searchTab");
		isElementDisplayed("inpt_searchTab");
		waitForElementToBeVisible("link_assignmentName");
		isElementDisplayed("link_assignmentName");
		waitForElementToBeVisible("btn_percentage");
		isElementDisplayed("btn_percentage");
		waitForElementToBeVisible("btn_pts");
		isElementDisplayed("btn_pts");
		waitForElementToBeVisible("btn_syncExport");
		isElementDisplayed("btn_syncExport");
		waitForElementToBeVisible("btn_settings");
		isElementDisplayed("btn_settings");

	}

	public void handleSecurityAlert() throws AWTException {

		// hardWait(10);
		// //changeWindow(1);
		// Robot robot = new Robot();
		// robot.keyPress(KeyEvent.VK_ENTER);
		hardWait(3);
		try {
			Robot robot;
			robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void switchToDefaulFrame() {
		waitForElementToBeVisible("iframe_ToolContent");
		switchToFrame("iframe_ToolContent");
	}

	public void navigateTOTools() {
		element("tools").click();
		hardWait(4);
		waitAndClick("link_contentMarketTools");
		hardWait(3);
		waitAndClick("saplingbaseurl");
	}

	/**
	 * This method is used to click on "Show All" button
	 */
	public void clickOnShowAllBtn() {
		waitAndClick("btn_showAll");
		logMessage("User clicked on Show All button");
		wait.hardWait(3);
	}

	/**
	 * This method is used to hide the column of gradetable in full grade center
	 */
	public void hideColumn(String columnName) {
		element("link_clickForMoreOptions", columnName).click();
		waitForElementToBeVisible("btn_hideColumn");
		waitAndClick("btn_hideColumn");
		logMessage("Instructor hide the column " + columnName);
	}
	
	/**
	 * This method is used to verify that column is deleted from gradetable
	 */
	public void verifyColumnisDeleted(String columnName) {
		element("link_clickForMoreOptions", columnName).click();
		waitForElementToBeVisible("btn_deleteColumn");
		element("btn_deleteColumn").click();
		handleAlert();
		assertFalse(element("btn_deleteColumn").isDisplayed(),
				"[Assertion Failed] : Column with " + columnName + "is not displayed");
		logMessage("Instructor delete the column " + columnName );
	}
}
