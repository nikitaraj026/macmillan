package com.qait.blackboard.keywords;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class ToolsPageAction extends GetPage {
	public ToolsPageAction(WebDriver driver) {
		super(driver, "ToolsPage");
	}

	public void clickOnMacmillanBackgroundUpdatesLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		scroll(element("lnk_macmillanBackgroundUpdates"));
		waitAndClick("lnk_macmillanBackgroundUpdates");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Background Updates' link");
	}

	public void verifyMacmillanBackgroundUpdatesPage() {
		verifyPageTitleContains("Macmillan Learning Background Updates");
		isElementDisplayed("txt_backgroundUpdates");

		logMessage("User is on 'Macmillan Learning Background Updates' page");
	}

	public void switchToDefaulFrame() {
		waitForElementToBeVisible("iframe_ToolContent");
		switchToFrame("iframe_ToolContent");
	}

	public void closeSecondryWindowAndComeBacktoMainWindow() {
		closeWindow();
		logMessage("Closed newly opened window");
		changeWindow(0);
	}

	public void reConnectCourseForAchieve() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(5);
		waitAndClick("lnk_ReconnectThisCourse");
		logMessage("User verifies the Sever This Course Page");

		closeWindowAndSwitchBackToOriginalWindow(0);
		refreshPage();
	}

	public void viewAvailableCoursesForAchieve() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(3);
		waitAndClick("lnk_viewAvailableCourses");
	}

	public void clickOnUnlinkMacmillanToolLink() {
		switchToDefaultContent();
		// switchToDefaulFrame();
		hardWait(5);
		waitAndClick("lnk_Unlink_Macmillan_Course");
		hardWait(5);
		changeWindow(1);
	}

	public void verifyEndCourseAssociationPage() {
		verifyPageTitleContains("End Course Association");
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		isElementDisplayed("checkbox_removeDeployedContent");
		logMessage("Instructor is on 'End Course Association' page");

	}

	public void disassociateCourse() {
		element("btn_Yes_DisassociateThisCourse").click();
		logMessage("Instructor clicked on 'Yes, Disassociate This Course' button");
	}

	public void verifyAllAssignmentsTextIsNotClickable() {
		hardWait(2);
		waitForElementToBeVisible("txt_assignments");
		isElementDisplayed("txt_assignments");
		assertTrue(element("txt_assignments").getAttribute("class").contains("inactive"));
		logMessage("Verified that the text Select All Assignments is not clickable");
	}

	public void clickOnMacmillanRosterLink() {
		switchToDefaultContent();
		// switchToDefaulFrame();
		waitForElementToBeVisible("lnk_macmillanRoster");
		waitAndClick("lnk_macmillanRoster");
		changeWindow(1);
		logMessage("User has clicked on 'Macmillan Roster Information' link");
	}

	public void addContentToCourse() {
		waitForElementToBeVisible("click_On_browse");
		waitAndClick("click_On_browse");
		waitAndClick("Learning_Curve");
		assertTrue(element("btn_Addcontent").isDisplayed(), "added button is not displayed");
		hoverClick(elements("btn_Addcontent").get(0));
		hardWait(3);
		waitAndClick("Reading");
		assertTrue(element("btn_Addcontent").isDisplayed(), "added button is not displayed");
		hardWait(4);
		hoverClick(elements("btn_Addcontent").get(0));
		hardWait(3);
		element("my_Course").click();
	}

	public void verifyMacmillanRosterPage(String userEmail) {
		verifyPageTitleContains("Macmillan Learning Roster");
		isElementDisplayed("txt_macmillanRoster");
		isElementDisplayed("txt_userEmail", userEmail);
		logMessage("Instructor is on 'Macmillan Higher Education Roster' page");
	}

	public void verifyUserNavigatedToMacmillanRosterPage() {
		verifyPageTitleContains("Macmillan Learning Roster");
		isElementDisplayed("txt_macmillanRoster");
		logMessage("Instructor is on 'Macmillan Higher Education Roster' page");
	}

	public void clearBrowserCache() {
		driver.manage().deleteAllCookies();
	}
}
