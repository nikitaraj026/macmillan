package com.qait.blackboard.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


//import com.googlecode.javacv.FrameRecorder.Exception;
import com.qait.automation.getpageobjects.GetPage;

public class LoginPageActionsLaunchpad extends GetPage {
	
	FindYourCoursePageActionsLaunchpad findYourCourse;
	public LoginPageActionsLaunchpad(WebDriver driver) {
		super(driver, "LoginPageLaunchpad");
		findYourCourse = new FindYourCoursePageActionsLaunchpad(driver);
	}

	/***************************
	 * 1. BASIC OPERATIONS
	 * a. Verifications
	 ***************************/
	
	/**
	 * Verifies User is on Login Page
	 */
	public void verifyUserIsOnLoginPage() {
		waitForLoaderToDisappear();
		clickElementIfVisible("btn_closeToastMessage");
//		if (elements("link_showDetails").size() == 0) {
//			element("link_hideDetails").click();
//		}
		verifyTextOfElementIsCorrect("txt_signIn", "Instructor sign in");
	}
	
	/**
	 * Verifies that Marketing Banner Is Displayed On Login page
	 */
	public void verifyMarketingBannerIsDisplayed() {
		//isElementDisplayed("container_topPanel");
		isElementDisplayed("img_info_small");
		//isElementDisplayed("pnl_title_area");
		//isElementDisplayed("pnl_info_sub-title");
		//isElementDisplayed("pnl_authr");
		isElementDisplayed("publisher_logo");
	}
	
	/**
	 * Verifies that Sign In Email input field is displayed
	 */
	public void verifySignInEmailInputDisplayed() {
		isElementDisplayed("txtinput_email");
	}
	
	/**
	 * Verifies Launchpad logo is displayed
	 */
	public void verifyLaunchpadLogoDisplayed() {
		isElementDisplayed("lnk_launchpadLogo");
	}
	
	/**
	 * Verifies Login Page title is displayed
	 */
	public void verifyLoginPageTitleDisplayed(String replacement) {
		isElementDisplayed("lnk_loginPageTitle", replacement);
	}
	
	/**
	 * Verifies that Sign In Password input field is displayed
	 */
	public void verifySignInPasswordInputDisplayed() {
		isElementDisplayed("txtinput_password");
	}

	/**
	 * Verifies that Sign In Button is displayed
	 */
	public void verifySignInButtonDisplayed() {
		isElementDisplayed("btn_signIn");
	}
	
	/**
	 * Verifies that Sign In Email Error message is not displayed
	 */
	public void verifySignInEmailErrorMessageNotDisplayed() {
		verifyElementNotDisplayed("txt_emailErrorMessage", "");
	}

	/**
	 * Verify Email Error Message
	 * @param expected expected Email Error message
	 */
	public void verifySignInEmailErrorMessage(String expected) {
		isElementDisplayed("txt_emailErrorMessage");
		customAssert.customAssertEquals(element("txt_emailErrorMessage").getText().toString().trim(), expected, "Assertion Failed : Email Error Message is not as expected");
		logMessage("Assertion Passed : Email Error Message is '" + expected + "'");
	}
	
	/**
	 * Verify Email and Password Error Message
	 * @param expected expected Email Error message
	 */
	public void verifySignInEmailAndPasswordErrorMessage(String expected) {
		isElementDisplayed("txt_username_or_password_error");
		hardWait(3);
		customAssert.customAssertEquals(element("txt_username_or_password_error").getText().toString().trim(), expected, "Assertion Failed : Email Error Message is not as expected");
		logMessage("Assertion Passed : Email Error Message is '" + expected + "'");
	}
	
	/**
	 * Verifies that Sign In Password Error message is not displayed
	 */
	public void verifySignInPasswordErrorMessageNotDisplayed() {
		verifyElementNotDisplayed("txt_passwordErrorMessage", "");
	}
	
	/**
	 * Verify Password Error Message
	 * @param expected expected Password Error Message
	 */
	public void verifySignInPasswordErrorMessage(String expected) {
		isElementDisplayed("txt_passwordErrorMessage");
		customAssert.customAssertEquals(element("txt_passwordErrorMessage").getText(), expected, "Assertion Failed : Password Error Message is not as expected");
		logMessage("Assertion Passed : Password Error Message is '" + expected + "'");
	}
	
	/**
	 * Verifies that 'I have a student access code' radio button is displayed
	 */
	public void verifyStudentAccessCodeRadioButtonDisplayed() {
		isElementDisplayed("radiobtn_studentAccessCode");
	}
	
	/**
	 * Verifies that 'I want to purchase access' radio button is displayed
	 */
	public void verifyPurchaseAccessRadioButtonDisplayed() {
		isElementDisplayed("radiobtn_purchaseAccess");
	}
	
	/**
	 * Verifies that 'I want temporary access' radio button is displayed
	 */
	public void verifyTemporaryAccessRadioButtonDisplayed() {
		isElementDisplayed("radiobtn_temporaryAccess");
	}
	
	/**
	 * Verifies that 'I have a student access code' radio button is selected
	 */
	public void verifyStudentAccessCodeRadioButtonSelected() {
		verifyRadioButtonSelected("radiobtn_studentAccessCode");
	}
	
	/**
	 * Verifies that 'I want to purchase access' radio button is selected
	 */
	public void verifyPurchaseAccessRadioButtonSelected() {
		verifyRadioButtonSelected("radiobtn_purchaseAccess");
	}
	
	/**
	 * Verifies that 'I want temporary access' radio button is selected
	 */
	public void verifyPayLaterRadioButtonSelected() {
		verifyRadioButtonSelected("radiobtn_temporaryAccess");
	}
	
	/**
	 * Verifies that Student Access code input box is displayed
	 */
	public void verifyStudentAccessCodeTextInputDisplayed() {
		isElementDisplayed("txtinput_studentAccessCode");
	}
	
	/**
	 * Verifies that Student Access code input box is not displayed
	 */
	public void verifyStudentAccessCodeTextInputNotDisplayed() {
		verifyElementNotDisplayed("txtinput_studentAccessCode", "");
	}
	
	/**
	 * Verifies that email input box for purchase access is displayed
	 */
	public void verifyPurchaseAccessEmailTextInputDisplayed() {
		isElementDisplayed("txtinput_purchaseAccessEmail");
	}
	
	/**
	 * Verifies that Purchase Access email input box is not displayed
	 */
	public void verifyPurchaseAccessEmailTextInputNotDisplayed() {
		verifyElementNotDisplayed("txtinput_purchaseAccessEmail", "");
	}
	
	/**
	 * Verifies that email input box for temporary access is displayed
	 */
	public void verifyPayLaterEmailTextInputDisplayed() {
		isElementDisplayed("txtinput_temporaryAccessEmail");
	}

	/**
	 * Verifies that Temporary Access email input box is not displayed
	 */
	public void verifyTemporaryAccessEmailTextInputNotDisplayed() {
		verifyElementNotDisplayed("txtinput_temporaryAccessEmail", "");
	}
	
	/**
	 * Verifies that Student Access Code Submit Button is displayed
	 */
	public void verifyStudentAccessCodeSubmitButtonDisplayed() {
		isElementDisplayed("btn_submitStudentAccessCode");
	}
	
	/**
	 * Verifies that Student Access Code Submit Button is not displayed
	 */
	public void verifyStudentAccessCodeSubmitButtonNotDisplayed() {
		verifyElementNotDisplayed("btn_submitStudentAccessCode", "");
	}
	
	/**
	 * Verifies that Purchase Access Submit Button is displayed
	 */
	public void verifyPurchaseAccessSubmitButtonDisplayed() {
		isElementDisplayed("btn_submitPurchaseAccessEmail");
	}
	
	/**
	 * Verifies that Purchase Access Submit Button is not displayed
	 */
	public void verifyPurchaseAccessSubmitButtonNotDisplayed() {
		verifyElementNotDisplayed("btn_submitPurchaseAccessEmail", "");
	}
	
	/**
	 * Verifies that Temporary Access Submit Button is displayed
	 */
	public void verifyPayLaterSubmitButtonDisplayed() {
		isElementDisplayed("btn_submitTemporaryAccessEmail");
	}
	
	/**
	 * Verifies that Temporary Access Submit Button is not displayed
	 */
	public void verifyTemporaryAccessSubmitButtonNotDisplayed() {
		verifyElementNotDisplayed("btn_submitTemporaryAccessEmail", "");
	}
	
	/**
	 * Verifies that tooltip is open
	 */
	public void verifyTooltipDisplayed() {
		isElementDisplayed("tooltip_open");
	}
	
	/**
	 * Verifies that tooltip is not open
	 */
	public void verifyTooltipNotDisplayed() {
		verifyElementNotDisplayed("tooltip_open", "");
	}
	
	/**
	 * Verifies Need Assistance Panel is displayed
	 */
	public void verifyNeedAssistancePanel(){
		isElementDisplayed("lnk_assistancePanel");
	}
	
	/**
	 * Verifies Need Assistance Panel is not displayed
	 */
	public void verifyNeedAssistancePanelNotVisible(){
		verifyElementNotDisplayed("lnk_assistancePanel", "");
		logMessage("Assistance panel is not displayed");
	}
	
	/**
	 * Verifies text on assistance page 
	 * @param linkName
	 */
	public void verifyOpenAssistancepage(String linkName){
		customAssert.customAssertTrue(linkName.contains(element("txt_linkName").getText()),"Assertion Failed  :"
				+ "link text is not correct");
		logMessage("Link Having text : "+linkName + "is displayed on Assistance window");
	}
	
	/**
	 * Verifies Assistance winow url is correct
	 */
	public void verifyAssitanceWindowURL(){
		customAssert.customAssertTrue(driver.getCurrentUrl().contains("http://cmg.screenstepslive.com"), "Assertion Failed : "
				+ " The URL of Assistance windowl is not correct expected http://cmg.screenstepslive.com");
		logMessage("Assertion Passed : The URL of Assistance window is : "+ driver.getCurrentUrl());
	}
	
	/**
	 * Verifies that Need Assistance tooltip for SignIn section is displayed
	 */
	public void verifyNeedAssistanceSignInTooltipDisplayed() {
		isElementDisplayed("tooltip_needAssistanceSignIn");
	}
	
	/**
	 * Verifies that Need Assistance tooltip for SignIn section is not displayed
	 */
	public void verifyNeedAssistanceSignInTooltipNotDisplayed() {
		verifyElementNotDisplayed("tooltip_needAssistanceSignIn", "");
	}
	
	/**
	 * Verifies links in Need Assistance tooltip for SignIn section
	 */
	public void verifyLinksNeedAssistanceSignInTooltip() {
		List<WebElement> links = elements("links_needAssistanceSignInTooltip");
		for (WebElement link:links) {
			link.click();
			changeWindow(1);
			//isElementDisplayed("img_logoMacmillan");
			logMessage("User move to next window and verified macmillan logo");
			closeWindow();
			changeWindow(0);
		}
	}
	
	/**
	 * Verifies that Need Assistance tooltip for Student Registration section is displayed
	 */
	public void verifyNeedAssistanceStudentRegistrationTooltipDisplayed() {
		isElementDisplayed("tooltip_needAssistanceStudentRegistration");
	}
	
	/**
	 * Verifies that Need Assistance tooltip for Student Registration section is not displayed
	 */
	public void verifyNeedAssistanceStudentRegistrationTooltipNotDisplayed() {
		verifyElementNotDisplayed("tooltip_needAssistanceStudentRegistration", "");
	}
	
	/**
	 * Verifies links in Need Assistance tooltip for Student Registration section
	 */
	public void verifyLinksNeedAssistanceStudentRegistrationTooltip() {
		List<WebElement> links = elements("links_needAssistanceStudentRegistrationTooltip");
		for (WebElement link:links) {
			link.click();
			changeWindow(1);
			//isElementDisplayed("img_logoMacmillan");
			logMessage("User move to next window and verified macmillan logo");
			closeWindow();
			changeWindow(0);
		}
	}
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * b. Fill Text Fields
	 ***************************/
	
	/**
	 * Fill Email in Sign In Section
	 */
	public void fillSignInEmail(String email) {
		fillText("txtinput_email", email);
	}
	
	/**
	 * Fill Password in Sign In Section
	 */
	public void fillSignInPassword(String password) {
		fillText("txtinput_password", password);
	}
	
	/**
	 * Fill Student Access Code in Text Box
	 */
	public void fillStudentAccessCode(String accessCode) {
		fillText("txtinput_studentAccessCode", accessCode);
	}
	
	/**
	 * Fill Purchase Access email in Text Box
	 */
	public void fillPurchaseAccessEmail(String email) {
		fillText("txtinput_purchaseAccessEmail", email);
	}
	
	/**
	 * Fill Temporary Access email in Text Box
	 */
	public void fillTemporaryAccessEmail(String email) {
		fillText("txtinput_temporaryAccessEmail", email);
	}
	
	public void fillInstructorAccessMail(String email){
		fillText("txtinput_instructorAccessEmail", email);
	}
	
	/***************************
	 * 1. BASIC OPERATIONS
	 * c. Click
	 ***************************/
	
	/**
	 * Click Sign In Button
	 */
	public void clickSignIn() {
		element("btn_signIn").click();
		
		logMessage("Clicked 'Sign in' Button");
	}
	
	/**
	 * Click 'I have a student access code' radio button
	 */
	public void clickStudentAccessCodeRadioButton() {
		element("radiobtn_studentAccessCode").click();
		logMessage("Clicked 'I have a student access code' Radio Button");
	}
	
	/**
	 * Click Student Access Code 'Submit' Button
	 */
	public void clickStudentAccessCodeSubmitButton() {
		element("btn_submitStudentAccessCode").click();
		logMessage("Clicked Student Access Code 'Submit' Button");
	}
	
	/**
	 * Click 'I want to purchase access' radio button
	 */
	public void clickPurchaseAccessRadioButton() {
		element("radiobtn_purchaseAccess").click();
		logMessage("Clicked 'I want to purchase access' Radio Button");
	}
	
	/**
	 * Click Purchase Access 'Submit' button
	 */
	public void clickPurchaseAccessSubmitButton() {
		element("btn_submitPurchaseAccessEmail").click();
		logMessage("Clicked Purchase Access 'Submit' Button");
	}
	
	/**
	 * Click 'I want temporary access' radio button
	 */
	public void clickPayLaterRadioButton() {
		element("radiobtn_temporaryAccess").click();
		logMessage("Clicked 'I want temporary access' Radio Button");
	}
	
	/**
	 * Click Temporary Access 'Submit' button
	 */
	public void clickTemporaryAccessSubmitButton() {
		element("btn_submitTemporaryAccessEmail").click();
		logMessage("Clicked Temporary Access 'Submit' Button");
	}
	
	/**
	 * Click Need Assistance Link in Sign In Section
	 */
	public void clickNeedAssistanceSignIn() {
		element("link_needAssistanceSignIn").click();
		logMessage("Clicked Need Assistance Link in Sign In section");
	}
	
	/**
	 * Click Need Assistance Link in Student Registration Section
	 */
	public void clickNeedAssistanceStudentRegistration() {
		element("link_needAssistanceStudentRegistration").click();
		logMessage("Clicked Need Assistance Link in Student Registration section");
	}
	
	/**
	 * close Assistance panel
	 */
	public void closeAssistancePanel(){
		element("txtinput_email").click();
		logMessage("User clik on email text box to close assistance panel");
	}
	
	public void clickGoButton(){
		element("btn_go").click();
	}
	/*************************
	 * 2. COMPOUNDED OPERATIONS
	 *************************/
	
	/**
	 * Login using email and password
	 */
	public void login(String email, String password) {
		waitForLoaderToDisappear();
//		if (elements("link_showDetails").size() == 0) {
//			element("link_hideDetails").click();
//		}
		fillSignInEmail(email);
		fillSignInPassword(password);
		clickSignIn();
	}

	/**
	 * Verifies Sign In Panel Section is displayed
	 */
	public void verifySignInPanelDisplayed() {
		verifySignInEmailInputDisplayed();
		verifySignInPasswordInputDisplayed();
		verifySignInButtonDisplayed();
	}

	/**
	 * Verifies New Student Registration Panel is displayed correctly
	 */
	public void verifyNewStudentRegistrationPanelDisplayed() {
		verifyStudentAccessCodeRadioButtonSelected();
		verifyPurchaseAccessRadioButtonDisplayed();
		verifyTemporaryAccessRadioButtonDisplayed();
		verifyStudentAccessCodeTextInputDisplayed();
		verifyStudentAccessCodeSubmitButtonDisplayed();
	}
	
	public void clickAndVerifyLinksOnAssistancePanel(List<String> links){
		for (String link: links) {
			scrollDown(element("lnk_onAssistancePanel", link));
			element("lnk_onAssistancePanel", link).click();
			changeWindow(1);
			hardWait(1);
			verifyAssitanceWindowURL();
			verifyOpenAssistancepage(link);
			closeWindow();
			changeWindow(0);
		}
	}
	
	public void verifyCourseIsNotAvailiable(){
		 customAssert.customAssertTrue(element("txt_courseNotAvailiable").getText().contains("Attempt to access a course that is not available"),
				 "Assertion Failed : Course is not avaliable for already erolled student");
		 logMessage("Assertion Passed : Course is avaliable for already erolled student");
	}
	
	public void verifyMsgToastIsDisplayed() {
		isElementDisplayed("msg_toast");
	}
	
	public void verifyMsgToastIsNotDisplayed() {
		verifyElementNotDisplayed("msg_toast", "");	
	}	
	
	/***************************
	 * 1. Core Services Features OPERATION
	 ***************************/
//	public void switchToMainFrame() {
//		switchToDefaultContent();
//		waitForElementToBeVisible("iframe_findYourCourse");
//		switchToFrame(element("iframe_findYourCourse"));
//	}
	
	public void verifyEmailField(String email) {
		findYourCourse.switchToMainFrame();
		waitForElementToBeVisible("lnk_enter_email");
		isElementDisplayed("txt_enter_email");
		element("txt_enter_email").sendKeys(email);
		isElementDisplayed("btn_submit_email");
		element("btn_submit_email").click();
		switchToDefaultContent();
	}
	
	public void agreeTermsAndConditions()
	{
		findYourCourse.switchToMainFrame();
		waitForElementToBeVisible("chkbox_agree_terms");
		element("chkbox_agree_terms").click();
		waitAndScrollToElement("btn_agree_terms");
		element("btn_agree_terms").click();
		switchToDefaultContent();
	}
	
	public void enterStudentDetails(String fName, String lName, String password, String email)
	{
		findYourCourse.switchToMainFrame();
		waitForElementToBeVisible("lnk_page_title");
		verifyTextOfElementIsCorrect("lnk_page_title", "Register");
		switchToDefaultContent();
		fillStudentFirstName(fName);
		fillStudentLastName(lName);
		fillStudentPassword(password);
		fillStudentConfirmEmail(email);
		fillStudentConfirmPassword(password);
		clickRegisterButton();
	}
	
	public void clickRegisterButton()
	{
		findYourCourse.switchToMainFrame();
		waitAndScrollToElement("btn_register");
		element("btn_register").click();
		switchToDefaultContent();
	}
	
	public void clickSubmitButton()
	{
		findYourCourse.switchToMainFrame();
		waitAndScrollToElement("btn_submit_password");
		element("btn_submit_password").click();
		switchToDefaultContent();
	}
	
	public void fillStudentFirstName(String name)
	{
		findYourCourse.switchToMainFrame();
		isElementDisplayed("txt_firstname");
		element("txt_firstname").sendKeys(name);
		switchToDefaultContent();
	}
	
	public void fillStudentLastName(String name)
	{
		findYourCourse.switchToMainFrame();
		isElementDisplayed("txt_lastname");
		element("txt_lastname").sendKeys(name);
		switchToDefaultContent();
	}
	
	public void fillStudentPassword(String password)
	{
		findYourCourse.switchToMainFrame();
		isElementDisplayed("txt_password");
		element("txt_password").sendKeys(password);
		switchToDefaultContent();
	}
	
	public void fillStudentConfirmPassword(String password)
	{
		findYourCourse.switchToMainFrame();
		isElementDisplayed("txt_confirm_password");
		element("txt_confirm_password").sendKeys(password);
		switchToDefaultContent();
	}
	
	public void fillStudentConfirmEmail(String email)
	{
		findYourCourse.switchToMainFrame();
		isElementDisplayed("txt_confirm_email");
		element("txt_confirm_email").sendKeys(email);
		switchToDefaultContent();
	}
	
	public void fillStudentEmailForTemporaryAccess(String email)
	{
		element("txtinput_temporaryAccessEmail").sendKeys(email);
	}
	
	public void clickSubmitButtonForTemporaryAccess()
	{
		element("btn_submitTemporaryAccessEmail").click();
	}
	
	public void verifyFreeTrialAccessStartedAndContinue(String message)
	{
		findYourCourse.switchToMainFrame();
		scrollToTop();
		verifyFreeTrialMessage(message);
		isElementDisplayed("lnk_free_trial_validity");
		waitAndScrollToElement("lnk_continue_to_site");
		element("lnk_continue_to_site").click();
		switchToDefaultContent();
	}
	
	public void verifyFreeTrialMessage(String message)
	{
		waitForElementToBeVisible("lnk_free_trial_access", message);
	}
	
	public void clearBrowserCache()
	{
		driver.manage().deleteAllCookies();
	}
	
	// ************************* REQUEST INSTRUCTOR ACCESS ***************************** //
	
	public void requestInstructorAccess(String email) {
		fillText("txtinput_instructorEmail", email);
		element("btn_goRequestInstructorAccess").click();
	}
}
