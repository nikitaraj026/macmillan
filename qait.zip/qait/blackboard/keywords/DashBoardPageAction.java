package com.qait.blackboard.keywords;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;

import com.qait.automation.getpageobjects.GetPage;

public class DashBoardPageAction extends GetPage{
	public DashBoardPageAction(WebDriver driver){
		super(driver,"DashBoardPage");
	}
	
	public void verifyUserIsOnDashboardPage() {
		isElementDisplayed("link_myInstitution");
		logMessage("User is successfully navigated to Login Page");
	}
	
	public void verifyWidgetHeadingDisplayed(String widgetName){
		isElementDisplayed("txt_widgetHeading", widgetName);
		logMessage(widgetName+" is displayed on page.");
	}
	
	public void verifyToolsWidgetDispalyed() {
		verifyWidgetHeadingDisplayed("Tools");
	}
	
	public void verifyMyCoursesWidgetDispalyed() {
		verifyWidgetHeadingDisplayed("My Courses");
	}
	
	public void clickOnCourse(String courseName){
		verifyMyCoursesWidgetDispalyed();
		hoverClick(element("link_myCourseWidgetSublink",courseName));
		logMessage("Successfully navigated to "+courseName);
	}
	
	public void isDoItLaterdispayedOnStudentDashboardPage() {
		try {
			int timeout = wait.getTimeout();
			wait.resetImplicitTimeout(5);
			if(element("link_doItLater").isDisplayed()) {
				clickDoItLater();
			}
			wait.resetImplicitTimeout(timeout);
		}
		catch(NoSuchElementException e) {
			logMessage("Do it later link is not present");
		}
	}

	public void create_NewCourse(String courseName,String courseId) {
		hardWait(3);
		element("link_SystemAdmin").click();
		hardWait(2);
		element("link_Courses").click();
		element("link_CreateCourse").click();
		hardWait(2);
		element("link_newCourse").click();
		hardWait(1);
		element("inpt_courseName").sendKeys(courseName);
		element("inpt_courseID").sendKeys(courseId);;
		scroll(element("btn_findNode"));
		element("btn_findNode").click();
		hardWait(2);
	    switchWindow();
	    element("field_nodeSearchValue").sendKeys("macmillan");
	    element("btn_Go").click();
	    hardWait(2);
	    element("link_Macmillan").click();
	    hardWait(3);
	    element("btn_Submit").click();
	    hardWait(3);
	    changeWindow(0);
	    scroll(element("checkbox_startDate"));
	    element("checkbox_startDate").click();
	    element("checkbox_endDate").click();
	    element("btn_Submit").click();
	   
	}
	public void clickDoItLater() {
		waitAndClick("link_doItLater");
		logMessage("Clicked on 'I'll do it later'");
	}
}
