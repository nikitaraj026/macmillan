package com.qait.blackboard.tests;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;



import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Smoke_Instructor_Deploy_Content extends Parent_Test{
	BlackBoardTestSessionInitiator blackboard;
	private String courseName;
	String instructorUserName, instructorEmail, instructorPassword;
	private String courseTitle, courseNumber, sectionNumber, instructorName, academicTerm;
	
	String accessCode;
	String bookTitle;
	String quizTitle, quizTitle2;
	String chapterName, chapterNumber, chapterIntroduction;
	String courseUrl, schoolName, assignDate, editedSchoolName, partialSchoolName;

	String studentUserName, studentName;
	String selectQuestionFrom;
	String registerStudentPassword;
	String mytier;
	
	private void initVars(){
		courseTitle = getStringWithTimestamp("BB",blackboard.getCurrentDateWithTime());
		courseNumber = "";
		sectionNumber = "";
		instructorUserName = getData("users.instructor.user_name1");
		instructorEmail = getData("users.instructor.user_email1");
		instructorName = getData("users.instructor.name1");
		instructorPassword = getData("users.instructor.password");
		courseName= getData("course.name1");
		bookTitle = getData("bookTitle");
		
		String bookIdentifier = "myers";
		academicTerm = getData(bookIdentifier + ".academic_term");
		chapterName = getData(bookIdentifier + ".TOC_chapter5");
		chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
		quizTitle = getData(bookIdentifier + ".quiz1.name");
		quizTitle2= getData(bookIdentifier + ".quiz2.name");
		chapterNumber = getData(bookIdentifier + ".chapterNumber");
		selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		assignDate = "15";
		accessCode = getData(bookIdentifier+".accessCode");
		registerStudentPassword = getData("users.student.registerPassword");
		mytier=System.getProperty("env");
		if(mytier==null) {
		mytier=ConfigPropertyReader.getProperty("tier");
		}
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID, @Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}	

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method){
		blackboard.stepStartMessage(method.getName()); 
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		//if(mytier.equalsIgnoreCase("lt"))
		blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods="Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(instructorUserName+"1", instructorPassword+"1");
		blackboard.loginPage.verify_ErrorMessageDispalyed();
		blackboard.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Go_To_Content_Page() {
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
		blackboard.coursePage.verifyContentPageHeaderMenu();
	}

	@Test(dependsOnMethods = "Step04_Go_To_Content_Page")
	public void Step05_Go_To_Content_Market_Page() {
		blackboard.coursePage.clickContentMarketInPartnerContent();
		blackboard.coursePage.verifyUserIsOnContentMarketPage();
		blackboard.coursePage
				.clickMacmillanInSelectContentProviderOnContentMarketPage();
	}

	@Test(dependsOnMethods = "Step05_Go_To_Content_Market_Page")
	public void Step06a_Verify_Macmillan_Higher_Education_Launch_Page_And_Click_Cancel() {
		if (!blackboard.coursePage
				.softverifyUserIsOnMacmillanEducationLaunchPadPage()) {
			throw new SkipException("Skipping the 6a-9a test cases");
		}
		blackboard.coursePage.verifyUserIsOnMacmillanEducationLaunchPadPage();
		blackboard.coursePage.clickMacmillanHigherEducationLaunchPageCancel();
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = "Step06a_Verify_Macmillan_Higher_Education_Launch_Page_And_Click_Cancel")
	public void Step07a_Go_To_Content_Market_Page() {
		blackboard.coursePage.clickContentMarketInPartnerContent();
		blackboard.coursePage.verifyUserIsOnContentMarketPage();
		blackboard.coursePage
				.clickMacmillanInSelectContentProviderOnContentMarketPage();
	}

	@Test(dependsOnMethods = "Step07a_Go_To_Content_Market_Page")
	public void Step08a_Verify_User_Privacy_PopUp_Macmillan_Higher_Education_Launch_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanEducationLaunchPadPage();
		blackboard.coursePage.clickMacmillanHigherEducationLaunchPageLaunch();
	}

	@Test(dependsOnMethods = "Step08a_Verify_User_Privacy_PopUp_Macmillan_Higher_Education_Launch_Page")
	public void Step09a_Pass_Macmillan_Higher_Education_Launch_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanEducationLaunchPadPage();
		blackboard.coursePage
				.clickAgreeUserShareRadioButtonOnMacmillanHigherEducationLaunchPage();
		blackboard.coursePage
				.clickCheckBoxDontShowAcknowledgementOnMacmillanHigherEducationLaunchPage();
		blackboard.coursePage.clickMacmillanHigherEducationLaunchPageLaunch();
	}

	@Test(dependsOnMethods="Step05_Go_To_Content_Market_Page")
	public void Step06b_Course_Association_Page() {
		blackboard.coursePage.createNewCourseMacmillanAssociationPage(bookTitle, courseTitle, courseNumber, sectionNumber, instructorName, academicTerm, false, "","Connect with LaunchPad");
		//courseTitle must be short enough so that <br> tag not added in course name in table
		blackboard.coursePage.verifyCourseCreatedMacmillanAssociationPage(courseTitle);
		blackboard.coursePage.clickAssociateMacmillanAssociationPage(courseTitle,"Connect with LaunchPad");
	}

	@Test(dependsOnMethods="Step06b_Course_Association_Page")
	public void Step07b_Go_To_Tools_Page(){
		blackboard.coursePage.clickOnLeftMenuTools();
		blackboard.coursePage.verifyUserIsOnToolsPage();
	}

	@Test(dependsOnMethods="Step07b_Go_To_Tools_Page")
	public void Step08b_Go_To_Content_Market_Tools_Page() {
		blackboard.coursePage.clickContentMarketToolsOnToolsPage();
		blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
		blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
	}

	@Test(dependsOnMethods="Step08b_Go_To_Content_Market_Tools_Page")
	public void Step09b_Go_To_Macmillan_Higher_Education_Tools() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyLaunchPadPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickLaunchPadOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.userNavigateToPxWindow();
	}

	@Test(dependsOnMethods= "Step09b_Go_To_Macmillan_Higher_Education_Tools")
	public void Step10_Add_and_Assign_New_Quiz() {
		blackboard.courseHomePageLaunchpad.changeWindow(2);
		blackboard.courseHomePageLaunchpad.createQuizAssignment("Quiz", quizTitle, true, "10", "15", true, chapterNumber, selectQuestionFrom);
		blackboard.courseHomePageLaunchpad.createQuizAssignment("Quiz", quizTitle2, true, "10", "15", true, chapterNumber, selectQuestionFrom);
	}

	@Test(dependsOnMethods = "Step10_Add_and_Assign_New_Quiz")
	public void Step11_Assign_TOC_Ebook() {
		blackboard.courseHomePageLaunchpad.clickUnassignedTOCItem(chapterName);
		blackboard.courseHomePageLaunchpad.assignTOCItem(chapterIntroduction, "15", true, "10");
	}

	@Test(dependsOnMethods = "Step11_Assign_TOC_Ebook")
	public void Step12_Verify_Assignment_On_Gradebook_And_Navigate_Back_To_Blackboard(){
		blackboard.menuLaunchpad.clickGradebookMenuButton();
		blackboard.instructorConsolePageLaunchpad.switchToDefaultFrame();
//		blackboard.instructorConsolePageLaunchpad.verifyAssignmentNameDisplayedOnGradebook(quizTitle);
//		blackboard.instructorConsolePageLaunchpad.verifyAssignmentNameDisplayedOnGradebook(quizTitle2);
//		blackboard.instructorConsolePageLaunchpad.verifyAssignmentNameDisplayedOnGradebook(chapterIntroduction);
		blackboard.coursePage.closeWindow();
		blackboard.coursePage.changeWindow(1);
	}
	
	@Test(dependsOnMethods="Step12_Verify_Assignment_On_Gradebook_And_Navigate_Back_To_Blackboard")
	public void Step13_Go_To_Content_Page(){
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
		blackboard.coursePage.verifyContentPageHeaderMenu();
	}

	@Test(dependsOnMethods="Step13_Go_To_Content_Page")
	public void Step14_Go_To_Content_Market_Page(){
		blackboard.coursePage.clickContentMarketInPartnerContent();
		blackboard.coursePage.verifyUserIsOnContentMarketPage();
		blackboard.coursePage.clickMacmillanInSelectContentProviderOnContentMarketPage();
	}

	@Test(dependsOnMethods="Step14_Go_To_Content_Market_Page")
	public void Step15_Deploy_Assignments_Macmillan_Higher_Education_Content() {
		blackboard.coursePage.verifyUserIsOnAddMacmillanHigherEducationContentPage();
		blackboard.coursePage.showLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPage();
		blackboard.coursePage.checkAssignmentsOnAddMacmillanHigherEducationContentPage(quizTitle);
		blackboard.coursePage.checkAssignmentsOnAddMacmillanHigherEducationContentPage(quizTitle2);
		blackboard.coursePage.checkAssignmentsOnAddMacmillanHigherEducationContentPage(chapterIntroduction);
		blackboard.coursePage.clickSubmitOnAddMacmillanHigherEducationContentPage();
		blackboard.coursePage.verifyUserIsOnSelectedMacmillanHigherEducationContentPage();
		blackboard.coursePage.checkSelectAllOnSelectedMacmillanHigherEducationContentPage();
		blackboard.coursePage.clickSubmitButtonOnSelectedMacmillanContentPage();
	}

	@Test(dependsOnMethods="Step15_Deploy_Assignments_Macmillan_Higher_Education_Content")
	public void Step16_Verify_Deployed_Assignments_On_Content_Page() {
		blackboard.coursePage.verifyUserIsOnContentPage();
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle2);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterIntroduction);
	}
	
	@Test(dependsOnMethods="Step16_Verify_Deployed_Assignments_On_Content_Page")
	public void Step17_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}
	
	@AfterClass
	public void stop_test_session() {
		blackboard.closebrowserSession();
	}
	
}