package com.qait.blackboard.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;
import com.qait.automation.utils.YamlReader;

public class Smoke_Student_Purchase_Access extends Parent_Test {
	BlackBoardTestSessionInitiator blackboard;
	private String userName, password;
	private String courseName;
	String quizTitle, quizTitle2;
	private String correctAnswer1Quiz1, correctAnswer1Quiz2;
	String accessCode;
	String studentUserName1;
	String studentEmail1;
	String studentFirstName1;
	String studentLastName1;
	String studentPassword;
	String registerStudentPassword;
	private String chapterName, chapterIntroduction;
	private String cardNumber, expiration, cvv;
	String mytier;
	private String px_password;

	private void initVars() {
		String bookIdentifier = "myers";
		courseName = getData("course.name1");
		userName = getData("users.instructor.user_name1");
		password = getData("users.instructor.password");
		accessCode = getData(bookIdentifier + ".accessCode");
		chapterName = getData(bookIdentifier + ".TOC_chapter5");
		chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
		quizTitle = getData(bookIdentifier + ".quiz1.name");
		correctAnswer1Quiz1 = getData(bookIdentifier + ".quiz1.correctAnswer1");
		quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		correctAnswer1Quiz2 = getData(bookIdentifier + ".quiz2.correctAnswer1");
		studentPassword = getData("users.student.password");
		registerStudentPassword = getData("users.student.registerPassword");
		cardNumber = getData("cardNumber");
		expiration = getData("cardExpiration");
		cvv = getData("cardCVV");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
		// Initialize dynamic yaml variables
		px_password="Password1!";
		studentUserName1 = blackboard.coursePage.readDataFromYaml("studentUserName1");
		studentEmail1 = blackboard.coursePage.readDataFromYaml("studentEmail1");
		studentFirstName1 = blackboard.coursePage.readDataFromYaml("studentFirstName1");
		studentLastName1 = blackboard.coursePage.readDataFromYaml("studentLastName1");
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		mytier = PropFileHandler.readProperty("tier");
		blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Student() {
		blackboard.loginPage.loginToTheApplication(studentUserName1, studentPassword);
		blackboard.dashboardPage.isDoItLaterdispayedOnStudentDashboardPage();
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Student")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Go_To_Content_Page() {
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = "Step04_Go_To_Content_Page")
	public void Step05_Verify_Assignments_On_Content_Page_And_Click_On_Manual_Assignment() {
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle2);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterIntroduction);
		blackboard.coursePage.clickAssignmentOnContentPage(quizTitle2);
	}

	@Test(dependsOnMethods = "Step05_Verify_Assignments_On_Content_Page_And_Click_On_Manual_Assignment")
	public void Step06_Pass_Macmillan_Higher_Education_Launch_Page_Acknowlegement_For_Student() {
		if (YamlReader.getTier().equals("prod")) {
		blackboard.coursePage.clickOnShareUserInfoAgree();
		blackboard.coursePage.clickCheckBoxDontShowAcknowledgementOnMacmillanHigherEducationLaunchPage();
		blackboard.coursePage.clickMacmillanHigherEducationLaunchPageLaunch();
		}
	}

	/*
	 * @Test(dependsOnMethods=
	 * "Step05_Verify_Assignments_On_Content_Page_And_Click_On_Assignment") public
	 * void Step06_Pass_Privacy_Page(){
	 * blackboard.coursePage.verifyUserIsOnMacmillanEducationLaunchPadPage();
	 * blackboard.coursePage.
	 * clickAgreeUserShareRadioButtonOnMacmillanHigherEducationLaunchPage();
	 * blackboard.coursePage.
	 * clickCheckBoxDontShowAcknowledgementOnMacmillanHigherEducationLaunchPage();
	 * blackboard.coursePage.clickMacmillanHigherEducationLaunchPageLaunch(); }
	 */
	@Test(dependsOnMethods = "Step06_Pass_Macmillan_Higher_Education_Launch_Page_Acknowlegement_For_Student")
	public void Step07_Accept_Launchpad_Eula_Notice_And_Register_Student() {		
		if(mytier.equalsIgnoreCase("prod")) {
			blackboard.onboardingPage.clickAcceptCompanyPrivacyPolicy();
			}
			if(mytier.equalsIgnoreCase("lt")) {
			blackboard.toolsPage.changeWindow(1);
			}
			blackboard.onboardingPage.completeStudent_Registration(studentEmail1, px_password);
		
	}

	@Test(dependsOnMethods = "Step07_Accept_Launchpad_Eula_Notice_And_Register_Student")
	public void Step08_Student_Purchase_Access() {
		blackboard.studentAccessGrantPage.clickPurchaseAccess();
		blackboard.studentAccessGrantPage.verifyUserIsOnPurchaseAccessPage();
		blackboard.studentAccessGrantPage.select180DaysAccess();
		blackboard.studentAccessGrantPage.selectCountryAndEnterZipForTaxCalculation();
		blackboard.studentAccessGrantPage.clickAddToCart();
		blackboard.studentAccessGrantPage.verifyUserIsOnPaymentDetailsPage();
		blackboard.studentAccessGrantPage.choosePaymentMethod("Card");
	//	blackboard.studentAccessGrantPage.clickPaypalOnPaymentDetailsPage();
	//	blackboard.studentAccessGrantPage.handlePaypalSandbox();
		blackboard.studentAccessGrantPage.enterCardNumberOnPaymentDetailsPage(cardNumber);
		blackboard.studentAccessGrantPage.enterExpirationAndCVVOnPaymentDetailsPage(expiration, cvv);
		blackboard.studentAccessGrantPage.clickContinueOnPaymentDetailsPage();
		blackboard.studentAccessGrantPage.verifyUserIsOnReviewYourOrderPage();
		blackboard.studentAccessGrantPage.clickConfirmPaymentOnReviewYourOrderPage();
		blackboard.studentAccessGrantPage.clickContinueOnPurchaseConfirmationPage();
		//blackboard.studentAccessGrantPage.clickContinueToSite();
		blackboard.coursePage.userNavigateToPxWindow();
	}

	@Test(dependsOnMethods = "Step08_Student_Purchase_Access")
	public void Step09_Student_Attempt_Manual_Quiz_Correctly_And_Open_Ebook() {
		blackboard.coursePage.userNavigateToPxWindow();
		blackboard.fandEPageLaunchpad.waitForLoaderToDisappear();
		blackboard.courseHomePageLaunchpad.clickAssignedTOCItem(quizTitle2);
		blackboard.fandEPageLaunchpad.verifyStudentIsOnQuizStartPage();
		blackboard.fandEPageLaunchpad.attemptQuizCorrectly(correctAnswer1Quiz2);
		blackboard.fandEPageLaunchpad.clickDoneButton();
		blackboard.fandEPageLaunchpad.clickOnHomeButton();
		blackboard.courseHomePageLaunchpad.clickAssignedTOCItem(chapterName);
		blackboard.courseHomePageLaunchpad.clickAssignedTOCItem(chapterIntroduction);
		blackboard.fandEPageLaunchpad.closeWindowAndSwitchBackToOriginalWindow(0);
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = "Step09_Student_Attempt_Manual_Quiz_Correctly_And_Open_Ebook")
	public void Step10_Verify_Assignments_On_Content_Page_And_Click_On_Auto_Assignment() {
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle2);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterIntroduction);
		blackboard.coursePage.clickAssignmentOnContentPage(quizTitle);
	}

	@Test(dependsOnMethods = "Step10_Verify_Assignments_On_Content_Page_And_Click_On_Auto_Assignment")
	public void Step11_Student_Attempt_Auto_Quiz_Correctly() {
		blackboard.coursePage.userNavigateToPxWindow();
		blackboard.fandEPageLaunchpad.waitForLoaderToDisappear();
		blackboard.fandEPageLaunchpad.verifyStudentIsOnQuizStartPage();
		blackboard.fandEPageLaunchpad.attemptQuizCorrectly(correctAnswer1Quiz1);
		blackboard.fandEPageLaunchpad.closeWindowAndSwitchBackToOriginalWindow(0);
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = { "Step11_Student_Attempt_Auto_Quiz_Correctly" })
	public void Step12_Student_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step12_Student_Logout")
	public void Step13_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step13_Log_In_As_Instructor")
	public void Step14_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step14_Go_To_Course_Page")
	public void Step15_Go_To_Tools_Page() {
		blackboard.coursePage.clickOnLeftMenuTools();
		blackboard.coursePage.verifyUserIsOnToolsPage();
	}

	@Test(dependsOnMethods = "Step15_Go_To_Tools_Page")
	public void Step16_Go_To_Content_Market_Tools_Page() {
		blackboard.coursePage.clickContentMarketToolsOnToolsPage();
		blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
		blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
	}

	@Test(dependsOnMethods = "Step16_Go_To_Content_Market_Tools_Page")
	public void Step17_Manual_Grade_Refresh() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanGradeRefreshOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage();
		blackboard.coursePage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle2);
		blackboard.coursePage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(chapterIntroduction);
		blackboard.coursePage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
		blackboard.coursePage.verifySuccessfulGradeUpdateAlert();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
	}

	@Test(dependsOnMethods = "Step17_Manual_Grade_Refresh")
	public void Step18_Verify_Content_Score() {
		blackboard.coursePage.navigateToFullGradeCenter();
		blackboard.coursePage.verifyUserIsOnFullGradeCenterPage();
		blackboard.coursePage.verifyContentScoreOnFullGradeCenterPage(studentUserName1, quizTitle2, "10.00");
	}

	@Test(dependsOnMethods = "Step18_Verify_Content_Score")
	public void Step19_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@AfterClass
	public void stop_test_session() {
		blackboard.closeBrowserSession();
	}
}