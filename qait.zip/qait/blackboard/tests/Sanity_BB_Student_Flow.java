package com.qait.blackboard.tests;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.lang.reflect.Method;

import static com.qait.automation.utils.YamlReader.getData;

/**
 * Created by vijaykumar on 7/21/2017.
 */
public class Sanity_BB_Student_Flow extends Parent_Test {
    BlackBoardTestSessionInitiator blackboard;
    private String userName, password;
    private String courseName;
    String quizTitle, quizTitle2;
    String correctAnswer1Quiz1;
    String correctAnswer1Quiz2;
    String accessCode;
    String studentUserName1;
    String studentEmail1;
    String studentFirstName1;
    String studentLastName1;
    String studentPassword;
    String registerStudentPassword;
    String chapterName, chapterIntroduction;

    private void initVars(){
        String bookIdentifier = "myers";
        courseName= getData("course.name2");
        userName = getData("users.instructor.user_name2");
        password = getData("users.instructor.password");
        accessCode = getData(bookIdentifier+".accessCode");
        chapterName = getData(bookIdentifier+".TOC_chapter5");
        chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
        quizTitle = getData(bookIdentifier + ".quiz1.name");
        correctAnswer1Quiz1 =  getData(bookIdentifier + ".quiz1.correctAnswer1");
        studentPassword = getData("users.student.password");
        registerStudentPassword = getData("users.student.registerPassword");
    }

    @BeforeSuite
    public void deleteExecutionFile() {
        beforeSuiteMethod();
    }

    @AfterMethod
    public void onFailure(ITestResult result) {
        afterMethod(blackboard, result, this.getClass().getName());
    }

    @BeforeClass
    public void Start_Test_Session() {
        blackboard = new BlackBoardTestSessionInitiator();
        initVars();
        //initialize variables from dynamic yaml
        studentUserName1 = blackboard.coursePage.readDataFromYaml("studentUserName1");
        studentEmail1 = blackboard.coursePage.readDataFromYaml("studentEmail1");
        studentFirstName1 = blackboard.coursePage.readDataFromYaml("studentFirstName1");
        studentLastName1 = blackboard.coursePage.readDataFromYaml("studentLastName1");
    }

    @BeforeMethod
    public void handleTestMethodName(Method method){
        blackboard.stepStartMessage(method.getName());
    }

    @Test
    public void Launch_Application() {
        blackboard.launchApplication();
        blackboard.loginPage.verifyUserIsOnLoginPage();
    }

    @Test(dependsOnMethods="Launch_Application")
    public void Log_In_As_Student() {
        blackboard.loginPage.loginToTheApplication(studentUserName1, studentPassword);
        blackboard.dashboardPage.isDoItLaterdispayedOnStudentDashboardPage();
        blackboard.dashboardPage.verifyUserIsOnDashboardPage();
    }

    @Test(dependsOnMethods = "Log_In_As_Student")
    public void Student_Navigates_To_Content_Page(){
        blackboard.dashboardPage.clickOnCourse(courseName);
        blackboard.coursePage.verifyUserIsOnCourseHomePage();

        blackboard.coursePage.clickOnLeftMenuContent();
        blackboard.coursePage.verifyUserIsOnContentPage();

        blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
        blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterIntroduction);
        blackboard.coursePage.clickAssignmentOnContentPage(quizTitle);
    }

    @Test(dependsOnMethods = "Student_Navigates_To_Content_Page")
    public void Verify_Student_Complete_SSO_Access_Code() {
        blackboard.onboardingPage.verifyEulaContentDisplayed(blackboard.getEnv(), studentEmail1);
        blackboard.onboardingPage.agreeLegalTerms();
        blackboard.onboardingPage.verifyTitle("Register");
        blackboard.onboardingPage.fillFirstNameLastNameAndPassword(studentFirstName1, studentLastName1, registerStudentPassword);
        blackboard.onboardingPage.fillConfirmEmailAndPassword(studentEmail1, registerStudentPassword);
        blackboard.onboardingPage.clickRegister();

        blackboard.studentAccessGrantPage.clickenterAnAccessCode();
        blackboard.studentAccessGrantPage.verifyUserIsOnEnterStudentAccessCodePage();
        blackboard.studentAccessGrantPage.fillAccessCodeOnEnterStudentAccessCode(accessCode);
        blackboard.studentAccessGrantPage.clickSubmitOnEnterStudentAccessCode();
        blackboard.studentAccessGrantPage.clickContinueToSite();
        blackboard.coursePage.userNavigateToPxWindow();
    }

    @Test(dependsOnMethods = "Verify_Student_Complete_SSO_Access_Code")
    public void Verify_Student_Attempt_Assignment_And_Grade_Reflect_In_LMS_Gradebook() {
        blackboard.coursePage.userNavigateToPxWindow();
        blackboard.fandEPageLaunchpad.waitForLoaderToDisappear();
        blackboard.fandEPageLaunchpad.verifyStudentIsOnQuizStartPage();
        blackboard.fandEPageLaunchpad.attemptQuizCorrectly(correctAnswer1Quiz1);
        blackboard.fandEPageLaunchpad.clickDoneButton();
        blackboard.fandEPageLaunchpad.clickOnHomeButton();
        blackboard.courseHomePageLaunchpad.clickAssignedTOCItem(chapterName);
        blackboard.courseHomePageLaunchpad.clickAssignedTOCItem(chapterIntroduction);
        blackboard.fandEPageLaunchpad.clickBackToBlackboard();
        blackboard.coursePage.verifyUserIsOnContentPage();

        blackboard.topMenu.logout();
        blackboard.loginPage.verifyUserIsOnLoginPage();

        // Instructor update grades.
        blackboard.loginPage.loginToTheApplication(userName, password);
        blackboard.dashboardPage.verifyUserIsOnDashboardPage();

        blackboard.dashboardPage.clickOnCourse(courseName);
        blackboard.coursePage.verifyUserIsOnCourseHomePage();

        blackboard.coursePage.clickOnLeftMenuTools();
        blackboard.coursePage.verifyUserIsOnToolsPage();

        blackboard.coursePage.clickContentMarketToolsOnToolsPage();
        blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
        blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();

        blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
        blackboard.coursePage.verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage();
        blackboard.coursePage.clickMacmillanGradeRefreshOnMacmillanHigherEducationToolsPage();
        blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage();
        blackboard.coursePage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle);
        blackboard.coursePage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(chapterIntroduction);
        blackboard.coursePage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
        blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
        blackboard.coursePage.verifySuccessfulGradeUpdateAlert();

        blackboard.coursePage.navigateToFullGradeCenter();
        blackboard.coursePage.verifyUserIsOnFullGradeCenterPage();
        blackboard.coursePage.verifyContentScoreOnFullGradeCenterPage(studentUserName1, quizTitle, "10.00");

        blackboard.topMenu.logout();
        blackboard.loginPage.verifyUserIsOnLoginPage();
    }

    @AfterClass
    public void stop_test_session() {
        blackboard.closeBrowserSession();
    }
}
