package com.qait.blackboard.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.lang.reflect.Method;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.yaml.snakeyaml.Yaml;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Smoke_Instructor_Change_Content_Settings_And_Check_Gradebook_From_LaunchPad extends Parent_Test{
	BlackBoardTestSessionInitiator blackboard;
	private String userName, password;
	String courseName;
	String quizTitle, quizTitle2;
	String chapterContent;
	String studentUserName2;
	String studentEmail2;
	String studentFirstName2;
	String studentLastName2;

    private static Map<String, Object> parseMap(Map<String, Object> object,
            String token) {
        if (token.contains(".")) {
            String[] st = token.split("\\.");
            object = parseMap((Map<String, Object>) object.get(st[0]),
                    token.replace(st[0] + ".", ""));
        }
        return object;
    }
	
	public static String getMapValue(Map<String, Object> object, String token) {
		// TODO: check for proper yaml token string based on presence of '.'
		String[] st = token.split("\\.");
		return parseMap(object, token).get(st[st.length - 1]).toString();
	}

	private static String readDataFromYaml(String token){
		Reader doc=null;
		try {
			doc = new FileReader("src"+File.separator + "test"+File.separator + "resources"+File.separator + "testdata" + File.separator + "BLACKBOARD" + File.separator +"QA_DynamicTestData.yml");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		Yaml yaml = new Yaml();
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);
		return getMapValue(object, token);
	}

	private void initVars(){
		courseName= getData("course.name1");
		userName = getData("users.instructor.user_name1");
		password = getData("users.instructor.password");

		studentUserName2 = readDataFromYaml("studentUserName2");
		studentEmail2 = readDataFromYaml("studentEmail2");
		studentFirstName2 = readDataFromYaml("studentFirstName2");
		studentLastName2 = readDataFromYaml("studentLastName2");

		String bookIdentifier = "myers";
		quizTitle = getData(bookIdentifier + ".quiz1.name");
		quizTitle2= getData(bookIdentifier + ".quiz2.name");
		chapterContent = getData(bookIdentifier + ".TOC_chapter2_subcontent1");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}	

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method){
		blackboard.stepStartMessage(method.getName()); 
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods="Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods="Step02_Log_In_As_Instructor")
	public void Step03_Go_To_Course_Page(){
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}
	/*
	@Test(dependsOnMethods="Step03_Go_To_Course_Page")
	public void Step04_Go_To_Content_Page(){
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
		blackboard.coursePage.verifyContentPageHeaderMenu();
	}

	@Test(dependsOnMethods="Step04_Go_To_Content_Page")
	public void Step05_Verify_Deployed_Assignments_On_Content_Page() {
		blackboard.coursePage.verifyUserIsOnContentPage();
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle2);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterContent);
	}

	@Test(dependsOnMethods="Step05_Verify_Deployed_Assignments_On_Content_Page")
	public void Step06_Change_Assignment_Settings() {
		blackboard.coursePage.clickAssignmentOnContentPage(quizTitle2);
		blackboard.coursePage.userNavigateToPxWindow();
		blackboard.fandEPageLaunchpad.verifyHeadingOfPage(quizTitle2);
		blackboard.fandEPageLaunchpad.selectOptionFromEditDropDown("Settings");
		blackboard.fandEPageLaunchpad.verifyUserIsOnSettingsPage("Quiz Settings");
		blackboard.fandEPageLaunchpad.changeScoredAttempts("Last");
		blackboard.fandEPageLaunchpad.clickSaveButtonOnSettingsTab();
		blackboard.fandEPageLaunchpad.clickOnDoneEditingButton();
		blackboard.fandEPageLaunchpad.clickBackToBlackboard();
		blackboard.coursePage.verifyUserIsOnContentPage();
	}
	 */
	@Test(dependsOnMethods="Step03_Go_To_Course_Page")
	public void Step07_Go_To_Tools_Page() {
		blackboard.coursePage.clickOnLeftMenuTools();
		blackboard.coursePage.verifyUserIsOnToolsPage();
	}

	@Test(dependsOnMethods="Step07_Go_To_Tools_Page")
	public void Step08_Go_To_Macmillan_Higher_Education_Tools_Page() {
		blackboard.coursePage.clickContentMarketToolsOnToolsPage();
		blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
		blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
	}

	@Test(dependsOnMethods="Step08_Go_To_Macmillan_Higher_Education_Tools_Page")
	public void Step09_Check_Gradebook_Score_From_LP() {
		blackboard.coursePage.clickGradebookOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.userNavigateToPxWindow();
		blackboard.fandEPageLaunchpad.verifyHeadingOfPage("Gradebook");
		blackboard.instructorConsolePageLaunchpad.verifyAssignmentNameDisplayedOnGradebook(quizTitle2);
		blackboard.instructorConsolePageLaunchpad.clickTopButtonInGradebook("Display Options");
		blackboard.instructorConsolePageLaunchpad.selectOptionOfDisplayOptionInGradebook("Visible Columns...");
		blackboard.instructorConsolePageLaunchpad.checkOptionsInVisibleColumnsOnGradebook("Email","Points","Score");
		blackboard.instructorConsolePageLaunchpad.clickOKInVisibleColumnsOnGradebook();
		blackboard.instructorConsolePageLaunchpad.verifyStudentAssignmentScoreOnGradebook(studentEmail2, quizTitle2, "10");
		blackboard.instructorConsolePageLaunchpad.clickBackToBlackboardOnGradebook();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
	}
	
	@Test(dependsOnMethods="Step09_Check_Gradebook_Score_From_LP")
	public void Step10_Unlink_Macmillan_Course() {
		blackboard.coursePage.verifyUnlinkMacmillanCoursePresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickUnlinkMacmillanCourseOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnSeverThisCourseAssociation();
		blackboard.coursePage.clickDisassociateThisCourseOnSeverThisCourseAssociationPage();
		blackboard.coursePage.verifyUserIsOnCourseLinkSeveredPage();
		blackboard.coursePage.clickReconnectThisCourseOnCourseLinkSeveredPage();
		blackboard.coursePage.clickBackToBlackboardUnlinkMacmillanCourse();
	}
}
