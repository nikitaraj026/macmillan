package com.qait.blackboard.tests;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import org.testng.DependencyMap;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

/**
 * Created by AjitSingh on 7/21/2017.
 */
public class Sanity_BB_Instructor_Flow extends Parent_Test{
    BlackBoardTestSessionInitiator blackboard;
    private String userName, password,instructorUserName, instructorEmail, instructorPassword, instructorName;
    String courseName, courseTitle, courseNumber, sectionNumber;
    String quizTitle;
    String chapterContent;
    String bookTitle, academicTerm, chapterName, chapterIntroduction, chapterNumber;
    String selectQuestionFrom, assignDate, accessCode;
    String studentUserName1 = getStringWithTimestamp("bb_stu1",blackboard.getCurrentDateWithTime());
    String studentFirstName1 = "FSName";
    String studentLastName1 = "LSName";
    String studentEmail1 = studentUserName1+"@fake123.com";
    String studentPassword;
    Map<String, Object> data = new HashMap<String, Object>();

    private void initVars(){
        userName = getData("users.instructor.user_name2");
        password = getData("users.instructor.password");

        String bookIdentifier = "myers";
        quizTitle = getData(bookIdentifier + ".quiz1.name");

        chapterContent = getData(bookIdentifier + ".TOC_chapter5_subcontent1");

        courseTitle = getStringWithTimestamp("BB",blackboard.getCurrentDateWithTime());
        courseNumber = "";
        sectionNumber = "";
        instructorUserName = getData("users.instructor.user_name2");
        instructorEmail = getData("users.instructor.user_email2");
        instructorName = getData("users.instructor.name2");
        instructorPassword = getData("users.instructor.password");
        courseName= getData("course.name2");
        bookTitle = getData("bookTitle");

        academicTerm = getData(bookIdentifier + ".academic_term");
        chapterName = getData(bookIdentifier + ".TOC_chapter5");
        chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
        quizTitle = getData(bookIdentifier + ".quiz1.name");

        chapterNumber = getData(bookIdentifier + ".chapterNumber");
        selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
        assignDate = "15";
        accessCode = getData(bookIdentifier+".accessCode");
        studentPassword = getData("users.student.password");

        data.put("studentUserName1", studentUserName1);
        data.put("studentEmail1", studentEmail1);
        data.put("studentFirstName1", studentFirstName1);
        data.put("studentLastName1", studentLastName1);
    }

    @BeforeSuite
    public void deleteExecutionFile() {
        beforeSuiteMethod();
    }

    @AfterMethod
    public void onFailure(ITestResult result) {
        afterMethod(blackboard, result, this.getClass().getName());
    }

    @BeforeClass
    public void Start_Test_Session() {
        blackboard = new BlackBoardTestSessionInitiator();
        initVars();
        blackboard.coursePage.writeDataToYaml(data);
    }

    @BeforeMethod
    public void handleTestMethodName(Method method){
        blackboard.stepStartMessage(method.getName());
    }

    @Test
    public void Launch_Blackboard_Application() {
        blackboard.launchApplication();
        blackboard.loginPage.verifyUserIsOnLoginPage();
    }

    @Test(dependsOnMethods="Launch_Blackboard_Application")
    public void Log_In_As_Instructor() {
        blackboard.loginPage.loginToTheApplication(userName, password);
        blackboard.dashboardPage.verifyUserIsOnDashboardPage();
    }

    @Test(dependsOnMethods = "Log_In_As_Instructor")
    public void Remove_Deployed_Assignment() {
        blackboard.dashboardPage.clickOnCourse(courseName);
        blackboard.coursePage.verifyUserIsOnCourseHomePage();
        blackboard.coursePage.clickOnLeftMenuContent();
        blackboard.coursePage.verifyUserIsOnContentPage();
        blackboard.coursePage.verifyContentPageHeaderMenu();
        blackboard.coursePage.removeAllDeployedAssignmentsOnContentPage();
    }

    @Test(dependsOnMethods = "Remove_Deployed_Assignment")
    public void Unlink_Macmillan_Course() {
        blackboard.coursePage.clickOnLeftMenuTools();
        blackboard.coursePage.verifyUserIsOnToolsPage();

        blackboard.coursePage.clickContentMarketToolsOnToolsPage();
        blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
        blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
        blackboard.coursePage.unlinkMacmillanCourse("Connect with LaunchPad");
    }

    @Test(dependsOnMethods = "Unlink_Macmillan_Course")
    public void Instructor_Remove_All_Students() {
        blackboard.coursePage.navigateToUsersPage();
        blackboard.coursePage.verifyUserIsOnUserPage();
        blackboard.coursePage.removeAllUsersExceptInstructors();
    }

    @Test(dependsOnMethods = "Instructor_Remove_All_Students")
    public void Instructor_Associate_Course_With_LP() {
        blackboard.coursePage.clickOnLeftMenuContent();
        blackboard.coursePage.verifyUserIsOnContentPage();
        blackboard.coursePage.verifyContentPageHeaderMenu();

        blackboard.coursePage.clickContentMarketInPartnerContent();
        blackboard.coursePage.verifyUserIsOnContentMarketPage();
        blackboard.coursePage.clickMacmillanInSelectContentProviderOnContentMarketPage();

        blackboard.coursePage.createNewCourseMacmillanAssociationPage(bookTitle, courseTitle, courseNumber, sectionNumber, instructorName, academicTerm, false, "","Connect with LaunchPad");
        //courseTitle must be short enough so that <br> tag not added in course name in table
        blackboard.coursePage.verifyCourseCreatedMacmillanAssociationPage(courseTitle);
        blackboard.coursePage.clickAssociateMacmillanAssociationPage(courseTitle,"Connect with LaunchPad");

        blackboard.coursePage.clickOnLeftMenuTools();
        blackboard.coursePage.verifyUserIsOnToolsPage();

        blackboard.coursePage.clickContentMarketToolsOnToolsPage();
        blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
        blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();

        blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
        blackboard.coursePage.verifyLaunchPadPresentOnMacmillanHigherEducationToolsPage();
        blackboard.coursePage.clickLaunchPadOnMacmillanHigherEducationToolsPage();
        blackboard.coursePage.userNavigateToPxWindow();
        blackboard.courseHomePageLaunchpad.verifyUserIsOnCourseHomePage(courseTitle);
    }

    @Test(dependsOnMethods = "Instructor_Associate_Course_With_LP")
    public void Instructor_Create_Assignment_In_LP() {
        blackboard.courseHomePageLaunchpad.createQuizAssignment("Quiz", quizTitle, true, "10", "15", true, chapterNumber, selectQuestionFrom);

        blackboard.courseHomePageLaunchpad.clickUnassignedTOCItem(chapterName);
        blackboard.courseHomePageLaunchpad.assignTOCItem(chapterIntroduction, "15", true, "10");

        blackboard.menuLaunchpad.clickGradebookMenuButton();
        blackboard.instructorConsolePageLaunchpad.switchToDefaultFrame();
        blackboard.instructorConsolePageLaunchpad.verifyAssignmentNameDisplayedOnGradebook(quizTitle);
        blackboard.instructorConsolePageLaunchpad.verifyAssignmentNameDisplayedOnGradebook(chapterIntroduction);
        blackboard.instructorConsolePageLaunchpad.clickBackToBlackboardOnGradebook();
        blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
    }

    @Test(dependsOnMethods = "Instructor_Create_Assignment_In_LP")
    public void Instructor_Deploy_Assignment_In_LP() {

        blackboard.coursePage.clickOnLeftMenuContent();
        blackboard.coursePage.verifyUserIsOnContentPage();
        blackboard.coursePage.verifyContentPageHeaderMenu();

        blackboard.coursePage.clickContentMarketInPartnerContent();
        blackboard.coursePage.verifyUserIsOnContentMarketPage();
        blackboard.coursePage.clickMacmillanInSelectContentProviderOnContentMarketPage();

        blackboard.coursePage.verifyUserIsOnAddMacmillanHigherEducationContentPage();
        blackboard.coursePage.showLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPage();
        blackboard.coursePage.checkAssignmentsOnAddMacmillanHigherEducationContentPage(quizTitle);
        blackboard.coursePage.checkAssignmentsOnAddMacmillanHigherEducationContentPage(chapterIntroduction);
        blackboard.coursePage.clickSubmitOnAddMacmillanHigherEducationContentPage();
        blackboard.coursePage.verifyUserIsOnSelectedMacmillanHigherEducationContentPage();
        blackboard.coursePage.checkSelectAllOnSelectedMacmillanHigherEducationContentPage();
        blackboard.coursePage.clickSubmitButtonOnSelectedMacmillanContentPage();

        blackboard.coursePage.verifyUserIsOnContentPage();
        blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
        blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterIntroduction);
    }

    @Test(dependsOnMethods = "Instructor_Deploy_Assignment_In_LP")
    public void Instructor_Enroll_Student() {
        blackboard.topMenu.logout();
        blackboard.loginPage.loginToTheApplication(userName, password);
        blackboard.dashboardPage.verifyUserIsOnDashboardPage();
        blackboard.dashboardPage.clickOnCourse(courseName);
        blackboard.coursePage.verifyUserIsOnCourseHomePage();

        blackboard.coursePage.navigateToUsersPage();
        blackboard.coursePage.verifyUserIsOnUserPage();
        blackboard.coursePage.createNewUser(studentFirstName1, studentLastName1, studentUserName1+"@fake123.com", studentUserName1, studentPassword, "Student");
        blackboard.coursePage.verifyUsernameDisplayedOnUsersPage(studentUserName1);
    }

    @Test(dependsOnMethods="Instructor_Enroll_Student")
    public void Instructor_Logout() {
        blackboard.topMenu.logout();
        blackboard.loginPage.verifyUserIsOnLoginPage();
    }

    @AfterClass
    public void stop_test_session() {
        blackboard.closeBrowserSession();
    }

}
