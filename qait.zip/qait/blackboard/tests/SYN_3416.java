package com.qait.blackboard.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

//To be completed :: Issue unresolved, left with verification of greyed out checkboxes

public class SYN_3416 extends Parent_Test{
	BlackBoardTestSessionInitiator blackboard;
	private String userName, password;
	private String courseName;
	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	
	String accessCode;
	String bookTitle;
	String quizTitle, quizTitle2;
	String chapterName, chapterNumber, chapterContent, chapterSubcontent, chapterIntroduction;
	String courseUrl, schoolName, assignDate, editedSchoolName, partialSchoolName;

	String studentUserName, studentName;
	String selectQuestionFrom;
	String registerStudentPassword;
	
	private void initVars(){
		//contentName = getData("contentName");
		userName = getData("users.instructor.user_name3");
		password = getData("users.instructor.password");
		courseName = getData("courses.name2");
		bookTitle = getData("bookTitle");
				
		String bookIdentifier = "myers";
		chapterName = getData(bookIdentifier + ".TOC_chapter5");
		chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
		chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
		chapterSubcontent = getData(bookIdentifier + ".TOC_chapter5_subcontent1");
		quizTitle = getData(bookIdentifier + ".quiz1.name");
		quizTitle2= getData(bookIdentifier + ".quiz2.name");
		chapterNumber = getData(bookIdentifier + ".chapterNumber");
		selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		assignDate = "15";
		accessCode = getData(bookIdentifier+".accessCode");
		registerStudentPassword = getData("users.student.registerPassword");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}	

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method){
		blackboard.stepStartMessage(method.getName()); 
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods="Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods="Step02_Log_In_As_Instructor")
	public void Step03_Go_To_Course_Page(){
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods="Step03_Go_To_Course_Page")
	public void Step04_Go_To_Content_Page(){
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
		blackboard.coursePage.verifyContentPageHeaderMenu();
	}
	
	@Test(dependsOnMethods="Step04_Go_To_Content_Page")
	public void Step05_Verify_Deployed_Assignments_On_Content_Page() {
		blackboard.coursePage.verifyUserIsOnContentPage();
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle2);
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterSubcontent);
	}
	
	@Test(dependsOnMethods="Step05_Verify_Deployed_Assignments_On_Content_Page")
	public void Step06_Go_To_Content_Market_Page(){
		blackboard.coursePage.clickContentMarketInPartnerContent();
		blackboard.coursePage.verifyUserIsOnContentMarketPage();
		blackboard.coursePage.clickMacmillanInSelectContentProviderOnContentMarketPage();
	}

	@Test(dependsOnMethods="Step06_Go_To_Content_Market_Page")
	public void Step07_Verify_Instructor_Is_Unable_To_Select_Deployed_Assignment() {
		blackboard.coursePage.verifyUserIsOnAddMacmillanHigherEducationContentPage();
		blackboard.coursePage.showLaunchpadAssignmentsOnAddMacmillanHigherEducationContentPage();

		//left with the verification of verification of greyed-out checkboxes
		
		blackboard.coursePage.clickCancelOnAddMacmillanHigherEducationContentPage();
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods="Step07_Verify_Instructor_Is_Unable_To_Select_Deployed_Assignment")
	public void Step08_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}
	
	@AfterClass
	public void stop_test_session() {
		blackboard.closeBrowserSession();
	}
	
}
