package com.qait.blackboard.sapling.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;
import com.qait.blackboard.keywords.CoursePageAction;

public class Smoke_Student_RequestFreeTrial extends Parent_Test {
	BlackBoardTestSessionInitiator blackboard;
	public CoursePageAction coursePage;
	private String userName, password;
	private String courseName;
	String quizTitle, quizTitle2;
	private String correctAnswer1Quiz1, correctAnswer1Quiz2;
	String accessCode;
	String studentUserName1;
	String studentEmail1;
	String studentFirstName1;
	String studentLastName1;
	String studentPassword;
	String registerStudentPassword;
	private String chapterName, chapterIntroduction;
	private String cardNumber, expiration, cvv, answer, grade, mytier;

	private void initVars() {

		String bookIdentifier = "myers";
		courseName = getData("courseName_sapling");
		userName = getData("sap_users.instructor.user_name1");
		password = getData("sap_users.instructor.password");
		accessCode = getData(bookIdentifier + ".accessCode");

		quizTitle = "Sapling_auto_quiz";
		answer = getData("sap_users.answer");
		grade = getData("sap_users.grade");
		studentPassword = getData("users.student.password");
		registerStudentPassword = getData("users.student.registerPassword");
		mytier = System.getProperty("env");
		if (mytier == null) {
			mytier = ConfigPropertyReader.getProperty("tier");
		}
		// cardNumber = getData("cardNumber");
//		expiration = getData("cardExpiration");
//		cvv = getData("cardCVV");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
		studentUserName1 = blackboard.coursePage.readDataFromYaml("studentUserName1");
		studentEmail1 = blackboard.coursePage.readDataFromYaml("studentEmail1");
		studentFirstName1 = blackboard.coursePage.readDataFromYaml("studentFirstName1");
		studentLastName1 = blackboard.coursePage.readDataFromYaml("studentLastName1");
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Student_Purchase() {
		blackboard.loginPage.loginToTheApplication(studentUserName1, studentPassword);
		blackboard.dashboardPage.isDoItLaterdispayedOnStudentDashboardPage();
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Student_Purchase")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Go_To_Content_Page() {
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = "Step04_Go_To_Content_Page")
	public void Step05_Verify_Assignments_On_Content_Page_And_Click_On_Manual_Assignment_Purchase() {
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle);
		blackboard.coursePage.clickAssignmentOnContentPage(quizTitle);
	}

	@Test(dependsOnMethods = "Step05_Verify_Assignments_On_Content_Page_And_Click_On_Manual_Assignment_Purchase")
	public void Step06_Pass_Macmillan_Higher_Education_Launch_Page_Acknowlegement_For_Student() {
	}
	
	@Test(dependsOnMethods = "Step06_Pass_Macmillan_Higher_Education_Launch_Page_Acknowlegement_For_Student")
	public void Step07_Accept_Launchpad_Eula_Notice_And_Register_Student_Purchase() {
		blackboard.toolsPage.changeWindow(1);
		blackboard.saplingStudentPage.verifyUserOnSaplingSide();
		blackboard.saplingStudentPage.studentAttemptFlowUptoQuestion(answer);
	}

	@Test(dependsOnMethods = { "Step07_Accept_Launchpad_Eula_Notice_And_Register_Student_Purchase" })
	public void Step08_Verify_Macmillan_Learning_Tools_Page() {
		blackboard.coursePage.navigateTOTools();
		blackboard.coursePage.verifyMacmillanHigherEducationDiagnosticsPresentOnMacmillanHigherEducationToolsPage();
	    blackboard.coursePage.verifyMacmillanTechnicalSupportPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanUserProfilePresentOnMacmillanHigherEducationToolsPage();
	}

	@Test(dependsOnMethods = { "Step08_Verify_Macmillan_Learning_Tools_Page" })
	public void Step09_Student_Logout_Purchase() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step09_Student_Logout_Purchase")
	public void Step10_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step10_Log_In_As_Instructor")
	public void Step11_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step11_Go_To_Course_Page")
	public void Step12_Go_To_Tools_Page() {
		blackboard.coursePage.clickOnLeftMenuTools();
		blackboard.coursePage.verifyUserIsOnToolsPage();
	}

	@Test(dependsOnMethods = "Step12_Go_To_Tools_Page")
	public void Step13_Go_To_Content_Market_Tools_Page() {
		blackboard.coursePage.clickContentMarketToolsOnToolsPage();
		blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
		blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
	}

	@Test(dependsOnMethods = "Step13_Go_To_Content_Market_Tools_Page")
	public void Step14_Manual_Grade_Refresh_Purchase() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanGradeRefreshOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage();
		blackboard.coursePage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle);
		blackboard.coursePage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
		blackboard.coursePage.verifySuccessfulGradeUpdateAlert();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
	}

	@Test(dependsOnMethods = "Step14_Manual_Grade_Refresh_Purchase")
	public void Step15_Verify_Content_Score_Purchase() {
		blackboard.coursePage.navigateToFullGradeCenter();
		blackboard.coursePage.verifyUserIsOnFullGradeCenterPage();
		blackboard.coursePage.verifyContentScoreOnFullGradeCenterPage(studentUserName1, quizTitle, "100.00");
	}

	@Test(dependsOnMethods = "Step15_Verify_Content_Score_Purchase")
	public void Step16_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@AfterClass
	public void stop_test_session() {
		blackboard.closebrowserSession();
	}
}