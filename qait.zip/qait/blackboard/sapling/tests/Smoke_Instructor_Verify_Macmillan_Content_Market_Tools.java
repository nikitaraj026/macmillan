package com.qait.blackboard.sapling.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Smoke_Instructor_Verify_Macmillan_Content_Market_Tools extends Parent_Test {
	BlackBoardTestSessionInitiator blackboard;
	private String userName, password, mytier;
	String courseName;

	private void initVars() {
		courseName = getData("courseName_sapling");
		userName = getData("sap_users.instructor.user_name1");
		password = getData("sap_users.instructor.password");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		mytier = ConfigPropertyReader.getProperty("tier");
		blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Go_To_Tools_Page() {
		blackboard.coursePage.clickOnLeftMenuTools();
		blackboard.coursePage.verifyUserIsOnToolsPage();
	}

	@Test(dependsOnMethods = "Step04_Go_To_Tools_Page")
	public void Step05_Go_To_Content_Market_Tools_Page() {
		blackboard.coursePage.clickContentMarketToolsOnToolsPage();
		blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
		blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
	}

	@Test(dependsOnMethods = "Step05_Go_To_Content_Market_Tools_Page")
	public void Step06_Verify_DiagnosticMacmillanPage() {
		blackboard.coursePage.verifyMacmillanHigherEducationDiagnosticsPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanHigherEducationDiagnosticsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationIntegrationDiagnosticsPage();
	}

	@Test(dependsOnMethods = "Step06_Verify_DiagnosticMacmillanPage")
	public void Step07_Verify_TechnicalSupportPage() {
		blackboard.coursePage.verifyMacmillanTechnicalSupportPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanTechnicalSupportOnMacmillanHigherEducationToolsPage();
		blackboard.supportPageActionsCatalog.verifyUserIsOnSupportCenterPage();
		blackboard.supportPageActionsCatalog.closeSupportCenterPage();
	}

	@Test(dependsOnMethods = "Step07_Verify_TechnicalSupportPage")
	public void Step08_Verify_RosterInformationPage() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanRosterInformationPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanRosterInformationOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUSerIsOnMacmillanHigherEducationRosterPage();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
	}

	@Test(dependsOnMethods = "Step08_Verify_RosterInformationPage")
	public void Step09_Verify_User_ProfilePage() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanUserProfilePresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanUserProfileOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanUserProfilePage();
		blackboard.coursePage.clickBackToBlackboardOnMacmillanUserProfile();
	}

	@Test(dependsOnMethods = "Step09_Verify_User_ProfilePage")
	public void Step10_Verify_Content_Refresh_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanContentRefreshPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanContentRefreshOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationContentRefreshPage();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
	}

	@Test(dependsOnMethods = "Step10_Verify_Content_Refresh_Page")
	public void Step11_Go_To_Macmillan_Higher_Education_Tools() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyLaunchPadPresentOnMacmillanHigherEducationToolsPage();
		// **********************
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();

		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanGradeRefreshOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
		// **********************
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUnlinkMacmillanCoursePresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickUnlinkMacmillanCourseOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnSeverThisCourseAssociation();
		blackboard.coursePage.clickDisassociateThisCourseOnSeverThisCourseAssociationPage();
		blackboard.coursePage.verifyUserIsOnCourseLinkSeveredPage();
//		blackboard.coursePage.clickReconnectThisCourseOnCourseLinkSeveredPage();
//		blackboard.coursePage.verifycourseReconnected();
		blackboard.coursePage.clickBackToBlackboardUnlinkMacmillanCourse();

	}

	@Test(dependsOnMethods="Step11_Go_To_Macmillan_Higher_Education_Tools")
	public void Step12_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@AfterClass
	public void stop_test_session() {
		blackboard.closeBrowserSession();
	}
}