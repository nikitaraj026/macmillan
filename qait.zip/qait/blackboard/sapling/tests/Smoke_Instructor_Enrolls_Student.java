package com.qait.blackboard.sapling.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.yaml.snakeyaml.Yaml;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Smoke_Instructor_Enrolls_Student extends Parent_Test {
	BlackBoardTestSessionInitiator blackboard;
	public String userName, password;
	String courseName, timeStamp,studentEmail1,studentEmail2,studentEmail3;
	String studentPassword,studentFirstName,studentLastName;
	String registerStudentPassword,studentUserName1,studentUserName2,studentUserName3,mytier;
	Map<String, Object> data = new HashMap<String, Object>();

	private void initVars() {
		studentUserName1 = getStringWithTimestamp("bb_stu1", blackboard.getCurrentDateWithTime());
		studentFirstName = "FSName";
		studentLastName = "LSName";
		
		studentEmail1 = studentUserName1 + "@fake123.com";
		courseName = getData("courseName_sapling");
		userName = getData("sap_users.instructor.user_name1");
		password = getData("sap_users.instructor.password");
		studentPassword = getData("users.student.password");

		data.put("studentUserName1", studentUserName1);

		data.put("studentEmail1", studentEmail1);

		data.put("studentFirstName1", studentFirstName);

		data.put("studentLastName1", studentLastName);
		mytier=System.getProperty("env");
		if(mytier==null) {
		mytier=ConfigPropertyReader.getProperty("tier");
		}
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
		blackboard.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor_ForEnrollPage() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor_ForEnrollPage")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Create_New_Student_User() {
		blackboard.coursePage.navigateToUsersPage();
		blackboard.coursePage.verifyUserIsOnUserPage();
		blackboard.coursePage.createNewUser(studentFirstName,
				studentLastName, studentUserName1 + "@fake123.com",
				studentUserName1, studentPassword, "Student");
		blackboard.coursePage
				.verifyUsernameDisplayedOnUsersPage(studentUserName1);
	}

	@Test(dependsOnMethods = "Step04_Create_New_Student_User")
	public void Step05_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@AfterClass
	public void stop_test_session() {
		blackboard.closebrowserSession();
	}

}