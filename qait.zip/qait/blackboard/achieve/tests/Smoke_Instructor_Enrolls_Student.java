package com.qait.blackboard.achieve.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;

public class Smoke_Instructor_Enrolls_Student extends Parent_Test {
	BlackBoardTestSessionInitiator blackboard;
	public String userName, password;
	String courseName, timeStamp, studentEmail1, studentEmail2, studentEmail3;
	String studentPassword, studentFirstName, studentLastName;
	String registerStudentPassword, studentUserName1, studentUserName2, studentUserName3;
	String mytier;
	Map<String, Object> data = new HashMap<String, Object>();

	private void initVars() {
		studentUserName1 = getStringWithTimestamp("bb_stu1", blackboard.getCurrentDateWithTime());
		studentUserName2 = getStringWithTimestamp("bb_stu2", blackboard.getCurrentDateWithTime());
		studentUserName3 = getStringWithTimestamp("bb_stu3", blackboard.getCurrentDateWithTime());
		studentFirstName = "FSName";
		studentLastName = "LSName";

		studentEmail1 = studentUserName1 + "@yopmail.com";
		studentEmail2 = studentUserName2 + "@yopmail.com";
		studentEmail3 = studentUserName3 + "@yopmail.com";
		courseName = getData("courseName_achieve");
		userName = getData("achieve_users.instructor.user_name1");
		password = getData("achieve_users.instructor.password");
		studentPassword = getData("users.student.password");

		data.put("studentUserName1", studentUserName1);
		data.put("studentUserName2", studentUserName2);
		data.put("studentUserName3", studentUserName3);

		data.put("studentEmail1", studentEmail1);
		data.put("studentEmail2", studentEmail2);
		data.put("studentEmail3", studentEmail3);

		data.put("studentFirstName1", studentFirstName);
		data.put("studentFirstName2", studentFirstName);
		data.put("studentFirstName3", studentFirstName);

		data.put("studentLastName1", studentLastName);
		data.put("studentLastName2", studentLastName);
		data.put("studentLastName3", studentLastName);
		mytier = System.getProperty("env");
		if (mytier == null) {
			mytier = ConfigPropertyReader.getProperty("tier");
		}
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
		blackboard.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor_ForEnrollPage() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor_ForEnrollPage")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Create_New_Student_User() {
		blackboard.coursePage.navigateToUsersPage();
		blackboard.coursePage.verifyUserIsOnUserPage();
		blackboard.coursePage.createNewUser(studentFirstName, studentLastName, studentUserName1 + "@yopmail.com",
				studentUserName1, studentPassword, "Student");
		blackboard.coursePage.createNewUser(studentFirstName, studentLastName, studentUserName2 + "@yopmail.com",
				studentUserName2, studentPassword, "Student");
		blackboard.coursePage.createNewUser(studentFirstName, studentLastName, studentUserName3 + "@yopmail.com",
				studentUserName3, studentPassword, "Student");
		blackboard.coursePage.verifyUsernameDisplayedOnUsersPage(studentUserName1);
		blackboard.coursePage.verifyUsernameDisplayedOnUsersPage(studentUserName2);
		blackboard.coursePage.verifyUsernameDisplayedOnUsersPage(studentUserName3);
	}

	@Test(dependsOnMethods = "Step04_Create_New_Student_User")
	public void Step05_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@AfterClass
	public void stop_test_session() {
		blackboard.closebrowserSession();
	}
}