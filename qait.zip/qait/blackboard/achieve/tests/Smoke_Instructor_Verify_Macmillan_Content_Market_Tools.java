package com.qait.blackboard.achieve.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Smoke_Instructor_Verify_Macmillan_Content_Market_Tools extends Parent_Test {
	BlackBoardTestSessionInitiator blackboard;
	private String userName, password;
	String courseName, mytier;

	private void initVars() {
		courseName = getData("courseName_achieve");
		userName = getData("achieve_users.instructor.user_name1");
		password = getData("achieve_users.instructor.password");
		mytier=System.getProperty("env");
		if(mytier==null) {
		mytier=ConfigPropertyReader.getProperty("tier");
		}
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Go_To_Tools_Page() {
		blackboard.coursePage.clickOnLeftMenuTools();
		blackboard.coursePage.verifyUserIsOnToolsPage();
	}

	@Test(dependsOnMethods = "Step04_Go_To_Tools_Page")
	public void Step05_Go_To_Content_Market_Tools_Page() {
		blackboard.coursePage.clickContentMarketToolsOnToolsPage();
		blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
		blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
	}

	@Test(dependsOnMethods = "Step05_Go_To_Content_Market_Tools_Page")
	public void Step06_verify_Gradebook_For_Achieve() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickAchieveOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.changeWindow(1);
		blackboard.coursePage.verify_User_Is_On_AchieveSide();
		blackboard.coursePage.verifyGradebookForAchieve();
		blackboard.toolsPage.closeWindowAndSwitchBackToOriginalWindow(0);
	}

	@Test(dependsOnMethods = "Step06_verify_Gradebook_For_Achieve")
	public void Step07_verfiy_Diagnostics_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanHigherEducationDiagnosticsPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanHigherEducationDiagnosticsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationIntegrationDiagnosticsPage();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
	}

	@Test(dependsOnMethods = "Step07_verfiy_Diagnostics_Page")
	public void Step08_verfiy_User_Profile_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanUserProfilePresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanUserProfileOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.changeWindow(1);
		blackboard.coursePage.verifyUserIsOnMacmillanUserProfilePage();
		blackboard.coursePage.clickBackToBlackboardOnMacmillanUserProfile();
	}

	@Test(dependsOnMethods = "Step08_verfiy_User_Profile_Page")
	public void Step09_verfiy_Roster_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanRosterInformationPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanRosterInformationOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUSerIsOnMacmillanHigherEducationRosterPage();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
	}

	@Test(dependsOnMethods = "Step09_verfiy_Roster_Page")
	public void Step10_verfiy_Grade_Refresh_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanGradeRefreshOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
	}

	@Test(dependsOnMethods = "Step10_verfiy_Grade_Refresh_Page")
	public void Step11_verfiy_Unlink_Course() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUnlinkMacmillanCoursePresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickUnlinkMacmillanCourseOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnSeverThisCourseAssociation();
		blackboard.coursePage.clickDisassociateThisCourseOnSeverThisCourseAssociationPage();
		blackboard.coursePage.verifyUserIsOnCourseLinkSeveredPage();
		blackboard.coursePage.clickReconnectThisCourseOnCourseLinkSeveredPage();
		blackboard.coursePage.verifycourseReconnected();
		blackboard.coursePage.clickBackToBlackboardUnlinkMacmillanCourse();
	}

	@Test(dependsOnMethods = { "Step11_verfiy_Unlink_Course" })
	public void Step12_verfiy_Content_Refresh_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanContentRefreshPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanContentRefreshOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationContentRefreshPage();
		blackboard.coursePage.clickMacmillanHigherEducationToolsBreadcrumbs();
	}

	@Test(dependsOnMethods = { "Step12_verfiy_Content_Refresh_Page" })
	public void Step13_verfiy_Technical_Support_Page() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanTechnicalSupportPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanTechnicalSupportOnMacmillanHigherEducationToolsPage();
		blackboard.supportPageActionsCatalog.verifyUserIsOnSupportCenterPage();
		blackboard.supportPageActionsCatalog.closeSupportCenterPage();
	}

	@Test(dependsOnMethods = "Step13_verfiy_Technical_Support_Page")
	public void Step14_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@AfterClass
	public void stop_test_session() {
		blackboard.closebrowserSession();
	}
}