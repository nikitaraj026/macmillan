package com.qait.blackboard.achieve.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Student_Enter_Access_Code extends Parent_Test {

	BlackBoardTestSessionInitiator blackboard;
	private String userName, password;
	private String courseName;
	String mytier, points;
	String pxCourseName;

	String quizTitle, quizTitle2, quizName;
	private String correctAnswer1Quiz1, correctAnswer1Quiz2;
	String accessCode;
	String studentUserName1;
	String studentEmail1;
	String studentFirstName1;
	String studentLastName1;
	String studentPassword;
	String registerStudentPassword;
	String emailFirstStudent;
	private String chapterName, chapterIntroduction;

	private void initVars() {
		String bookIdentifier = "myers";
		courseName = getData("courseName_achieve");
		pxCourseName=getData("achieve_users.pxCourseName");
		userName = getData("achieve_users.instructor.user_name1");
		password = getData("achieve_users.instructor.password");
		accessCode = getData(bookIdentifier + "achieve_users.accessCode");
		chapterName = getData(bookIdentifier + ".TOC_chapter5");
		chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
		quizTitle = getData(bookIdentifier + ".quiz1.name");
		correctAnswer1Quiz1 = getData(bookIdentifier + ".quiz1.correctAnswer1");
		quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		quizName = "Apostrophes";
		correctAnswer1Quiz2 = getData(bookIdentifier + ".quiz2.correctAnswer1");
		studentPassword = getData("users.student.password");
		registerStudentPassword = getData("users.student.registerPassword");
		mytier=System.getProperty("env");
		if(mytier==null) {
		mytier=ConfigPropertyReader.getProperty("tier");
		}
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		initVars();
		studentUserName1 = blackboard.coursePage.readDataFromYaml("studentUserName1");
		studentEmail1 = blackboard.coursePage.readDataFromYaml("studentEmail1");
		studentFirstName1 = blackboard.coursePage.readDataFromYaml("studentFirstName1");
		studentLastName1 = blackboard.coursePage.readDataFromYaml("studentLastName1");
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		blackboard.launchApplication();
		
			blackboard.loginPage.handleCookiesWindow();
		blackboard.loginPage.verifyUserIsOnLoginPage();
		
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Student_Request() {
		blackboard.loginPage.loginToTheApplication(studentUserName1, studentPassword);
		blackboard.dashboardPage.isDoItLaterdispayedOnStudentDashboardPage();
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Student_Request")
	public void Step03_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step03_Go_To_Course_Page")
	public void Step04_Go_To_Content_Page() {
		blackboard.coursePage.clickOnLeftMenuContent();
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = "Step04_Go_To_Content_Page")
	public void Step05_Verify_Assignments_On_Content_Page_And_Click_On_Assignment() {
		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizName);
//		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle2);
//		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterIntroduction);
		blackboard.coursePage.clickAssignmentOnContentPage(quizName);
		//blackboard.coursePage.submit_SSOPageAndContinue();
	}

	@Test(dependsOnMethods = "Step05_Verify_Assignments_On_Content_Page_And_Click_On_Assignment")
	public void Step06_Pass_Macmillan_Higher_Education_Launch_Page_Acknowlegement_For_Student() {
//		blackboard.coursePage.clickOnShareUserInfoAgree();
//		blackboard.coursePage.clickCheckBoxDontShowAcknowledgementOnMacmillanHigherEducationLaunchPage();
//		blackboard.coursePage.clickMacmillanHigherEducationLaunchPageLaunch();
	}

	/*
	 * @Test(dependsOnMethods=
	 * "Step06_Pass_Macmillan_Higher_Education_Launch_Page_For_Student") public void
	 * Step07_Pass_Privacy_Page(){
	 * blackboard.coursePage.verifyUserIsOnMacmillanEducationLaunchPadPage();
	 * blackboard.coursePage.
	 * clickAgreeUserShareRadioButtonOnMacmillanHigherEducationLaunchPage();
	 * blackboard.coursePage.
	 * clickCheckBoxDontShowAcknowledgementOnMacmillanHigherEducationLaunchPage();
	 * blackboard.coursePage.clickMacmillanHigherEducationLaunchPageLaunch(); }
	 */
	@Test(dependsOnMethods = "Step06_Pass_Macmillan_Higher_Education_Launch_Page_Acknowlegement_For_Student")
	public void Step07_Accept_Launchpad_Eula_Notice_And_Register_Student() {
//		blackboard.onboardingPage.verifyEulaContentDisplayed(blackboard.getEnv(), studentEmail2);
//		blackboard.onboardingPage.agreeLegalTerms();
//		blackboard.onboardingPage.verifyTitle("Register");
//		blackboard.onboardingPage.fillFirstNameLastNameAndPassword(studentFirstName2, studentLastName2,
//				registerStudentPassword);
//		blackboard.onboardingPage.fillConfirmEmailAndPassword(studentEmail2, registerStudentPassword);
//		blackboard.onboardingPage.clickRegister();
	}

	@Test(dependsOnMethods = "Step07_Accept_Launchpad_Eula_Notice_And_Register_Student")
	public void Step08_Student_Enter_Access_Code() {
//		blackboard.studentAccessGrantPage.clickRequestFreeTrial();
//		blackboard.studentAccessGrantPage.clickContinueToSite();
	}

	@Test(dependsOnMethods = "Step08_Student_Enter_Access_Code")
	public void Step09_Student_Attempt_Quiz() {
		/*
		 * if (mytier.equalsIgnoreCase("prod"))
		 * blackboard.onboardingPage.verifyEulaContentDisplayed(blackboard.getEnv(),
		 * studentEmail1); blackboard.coursePage.userNavigateToPxWindow();
		 * 
		 * blackboard.fandEPageLaunchpad.waitForLoaderToDisappear(); points =
		 * blackboard.achieveStudentPage.attempt_AchieveQuiz();
		 */
//		blackboard.fandEPageLaunchpad.verifyStudentIsOnQuizStartPage();
//		blackboard.fandEPageLaunchpad.attemptQuizCorrectly(correctAnswer1Quiz2);
//		blackboard.fandEPageLaunchpad.clickDoneButton();
//		blackboard.fandEPageLaunchpad.clickOnHomeButton();
//		blackboard.courseHomePageLaunchpad.verify_freeTrialMessageIsDisplayed();
//		blackboard.courseHomePageLaunchpad.clickAssignedTOCItem(chapterName);
//		blackboard.courseHomePageLaunchpad.clickAssignedTOCItem(chapterIntroduction);
//		blackboard.fandEPageLaunchpad.closeWindowAndSwitchBackToOriginalWindow(0);
		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = "Step09_Student_Attempt_Quiz")
	public void Step10_Verify_Assignments_On_Content_Page_And_Click_On_Auto_Assignment() {
		//blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizName);
//		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(quizTitle2);
//		blackboard.coursePage.verifyAssignmentDisplayedOnContentPage(chapterIntroduction);
		//blackboard.coursePage.clickAssignmentOnContentPage(quizTitle);
		blackboard.achieveStudentPage.verifyEnrollmentOptionsModalWindow();
		blackboard.achieveStudentPage.useAccessCodedAsEnrollmentOption(accessCode,pxCourseName);
	}

	@Test(dependsOnMethods = "Step10_Verify_Assignments_On_Content_Page_And_Click_On_Auto_Assignment")
	public void Step11_Student_Attempt_Auto_Quiz_Correctly() {
//		blackboard.coursePage.userNavigateToPxWindow();
//		blackboard.fandEPageLaunchpad.waitForLoaderToDisappear();
//		blackboard.fandEPageLaunchpad.verifyStudentIsOnQuizStartPage();
//		blackboard.fandEPageLaunchpad.attemptQuizCorrectly(correctAnswer1Quiz1);
//		blackboard.fandEPageLaunchpad.closeWindowAndSwitchBackToOriginalWindow(0);
//		blackboard.coursePage.verifyUserIsOnContentPage();
	}

	@Test(dependsOnMethods = { "Step11_Student_Attempt_Auto_Quiz_Correctly" })
	public void Step12_Student_Logout_Request() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}
   
	@Test(dependsOnMethods = "Step12_Student_Logout_Request")
	public void Step13_Log_In_As_Instructor() {
		blackboard.loginPage.loginToTheApplication(userName, password);
		blackboard.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step13_Log_In_As_Instructor")
	public void Step14_Go_To_Course_Page() {
		blackboard.dashboardPage.clickOnCourse(courseName);
		blackboard.coursePage.verifyUserIsOnCourseHomePage();
	}

	@Test(dependsOnMethods = "Step14_Go_To_Course_Page")
	public void Step15_Go_To_Tools_Page() {
		blackboard.coursePage.clickOnLeftMenuTools();
		blackboard.coursePage.verifyUserIsOnToolsPage();
	}

	@Test(dependsOnMethods = "Step15_Go_To_Tools_Page")
	public void Step16_Go_To_Content_Market_Tools_Page() {
		blackboard.coursePage.clickContentMarketToolsOnToolsPage();
		blackboard.coursePage.verifyUserIsOnContentMarketToolsPage();
		blackboard.coursePage.clickMacmillanInContentProviderOnContentMarketTools();
	}

	@Test(dependsOnMethods = "Step16_Go_To_Content_Market_Tools_Page")
	public void Step17_Manual_Grade_Refresh_Request() {
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.clickMacmillanGradeRefreshOnMacmillanHigherEducationToolsPage();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage();
		blackboard.coursePage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizName);
//		blackboard.coursePage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(chapterIntroduction);
		blackboard.coursePage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
		blackboard.coursePage.verifySuccessfulGradeUpdateAlert();
		blackboard.coursePage.clickonMacmilanToo();
		blackboard.coursePage.verifyUserIsOnMacmillanHigherEducationToolsPage();
		
	}

	@Test(dependsOnMethods = "Step17_Manual_Grade_Refresh_Request")
	public void Step18_Verify_Content_Score_Request() {
		blackboard.coursePage.navigateToFullGradeCenter();
		blackboard.coursePage.verifyUserIsOnFullGradeCenterPage();
		blackboard.coursePage.verifyContentScoreOnFullGradeCenterPage(studentUserName1, quizName, "30");
	}

	@Test(dependsOnMethods = "Step18_Verify_Content_Score_Request")
	public void Step19_Instructor_Logout() {
		blackboard.topMenu.logout();
		blackboard.loginPage.verifyUserIsOnLoginPage();
	}

	@AfterClass
	public void stop_test_session() {
		blackboard.closeBrowserSession();
	}

}