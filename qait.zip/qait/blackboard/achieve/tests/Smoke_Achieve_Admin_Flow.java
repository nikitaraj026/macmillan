package com.qait.blackboard.achieve.tests;

import java.awt.AWTException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.BlackBoardTestSessionInitiator;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Achieve_Admin_Flow extends Parent_Test {

	BlackBoardTestSessionInitiator blackboard;
	Map<String, Object> data = new HashMap<String, Object>();

	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor, instructorName;
	private String firstStudent, firstStudentLogin, emailFirstStudent;
	private String password, inst_password, px_password;
	String emailAdmin, passwordAdmin, newCourseName, courseCode, emailForNewAccount;
	String template,tempCode,tempISBN;
	String copyCourse,copyCourseCode;

	private void _initVars() {
		String dateWithTime = blackboard.getCurrentDateWithTime();
		template=RandomStringUtils.randomAlphabetic(6);
		tempCode=RandomStringUtils.randomAlphanumeric(5);
		tempISBN=RandomStringUtils.randomAlphabetic(13);
		
        copyCourse="blackboard_Achieve"+dateWithTime;
		copyCourseCode=RandomStringUtils.randomAlphanumeric(5);
		
		emailAdmin = getData("achieve_users.admin.user_name");
		passwordAdmin = getData("achieve_users.admin.password");
		newCourseName = RandomStringUtils.randomAlphabetic(6);
		courseCode = RandomStringUtils.randomAlphanumeric(5);
		courseName = getData("courseName_achieve");

		instructorName = getData("achieve_users.instructor.name1");
		instructor = getData("achieve_users.instructor.user_name1");
		emailInstructor = getData("achieve_users.instructor.user_email1");

		firstStudent = "Stud First";
		firstStudentLogin = "StudFirst" + dateWithTime;
		emailFirstStudent = firstStudentLogin + "@yopmail.com";
		inst_password = getData("users.instructor.password");
		password = getData("users.student.password");
		DashBoardPageAction.courseName = courseName;
		px_password = "Password1!";
		if (PropFileHandler.readProperty("tier").equalsIgnoreCase("lt"))
			emailForNewAccount = "adminflowtest@yopmail.com";
		else
		emailForNewAccount = "adminflowtestprod@yopmail.com";
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(blackboard, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		blackboard = new BlackBoardTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		blackboard.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		
		blackboard.launchAchieveApplication();
		blackboard.toolsPage.clearBrowserCache();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Verfiy_Admin_Able_To_Login() {

		blackboard.achieveAdminPage.login_TO_Achieve(emailAdmin, passwordAdmin);
	}

	@Test(dependsOnMethods = { "Step02_Verfiy_Admin_Able_To_Login" })
	public void Step03_Verfiy_Admin_Able_To_Create_TemplateAndCourse() {
		blackboard.achieveAdminPage.create_template(template, tempCode, tempISBN);
		blackboard.achieveAdminPage.find_TestCourse(template);
		blackboard.achieveAdminPage.input_Content(template);
		blackboard.achieveAdminPage.copy_Course(copyCourse, copyCourseCode);
		blackboard.achieveAdminPage.find_TestCourse(copyCourse);
		blackboard.achieveAdminPage.create_Content(copyCourse);
		blackboard.achieveAdminPage.assignAssigments();
	}

	@Test(dependsOnMethods = { "Step03_Verfiy_Admin_Able_To_Create_TemplateAndCourse" })
	public void Step04_Verfiy_Admin_Able_To_Find_Test_Course() {
		blackboard.achieveAdminPage.find_TestCourse(copyCourse);
	}

	@Test(dependsOnMethods = { "Step04_Verfiy_Admin_Able_To_Find_Test_Course" })
	public void Step05_Verfiy_Admin_Able_To_Enroll_Instructor() {
		blackboard.achieveAdminPage.verify_Enroll_Instructor_Modal_Window();
		blackboard.achieveAdminPage.add_Instructor_Email(emailForNewAccount);

	}

	@Test(dependsOnMethods = { "Step05_Verfiy_Admin_Able_To_Enroll_Instructor" })
	public void Step06_Verify_Admin_Able_To_Unenroll_Instructor() {
		blackboard.achieveAdminPage.remove_Instructor(emailForNewAccount);
	}

	@Test(dependsOnMethods = { "Step06_Verify_Admin_Able_To_Unenroll_Instructor" })
	public void Step07_Verify_Admin_Able_To_Edit_Course_Details() {
		//blackboard.achieveAdminPage.editTestCourseDetails();
	}

	@Test(dependsOnMethods = { "Step07_Verify_Admin_Able_To_Edit_Course_Details" })
	public void Step08_Verify_Admin_Able_To_Provide_Content_For_Instructor() throws InterruptedException, AWTException {
		//blackboard.achieveAdminPage.add_Activity();
		//blackboard.achieveAdminPage.find_TestCourse(newCourseName);
	}

	@Test(dependsOnMethods = { "Step08_Verify_Admin_Able_To_Provide_Content_For_Instructor" })
	public void Step09_Verfiy_Admin_Able_To_Delete_Course() {
		blackboard.achieveAdminPage.delete_Course();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		blackboard.closebrowserSession();
	}
}