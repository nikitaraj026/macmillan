package com.qait.clever.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CleverTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;

public class SyncDistrict extends Parent_Test {
	CleverTestSessionInitiator clever;

	String baseURL, cleverDistrictUrl, distAdminUname, distAdminPass;
	String userName, userEmail, userPassword;
	String districtName;
	String teacherEmail, mytier;

	private void initVars() {

		cleverDistrictUrl = getData("cleverDistrictUrl");
		distAdminUname = getData("districtAdminUsername");
		distAdminPass = getData("districtAdminPassword");
		userName = getData("username");
		userPassword = getData("password");
		districtName = getData("cleverDistrictName");
		mytier = System.getProperty("env");
		if (mytier == null) {
			mytier = ConfigPropertyReader.getProperty("tier");
		}
		
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		clever = new CleverTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		clever.stepStartMessage(method.getName());
	}

	@Test
	public void LaunchCleverApplication() {
		clever.launchApplication(cleverDistrictUrl);
	}

	@Test(dependsOnMethods = "LaunchCleverApplication")
	public void VerifySyncDistrictHomePage() {
		clever.syncDistrictClever.verifyHomePage();
	}

	@Test(dependsOnMethods = "VerifySyncDistrictHomePage")
	public void SyncDistricts() {
		clever.syncDistrictClever.chooseOptionFromInstallationDrpdwn(districtName);
		clever.syncDistrictClever.clickSyncDistrict();
		clever.syncDistrictClever.verifyCleverSyncRunningAndGotSuccessful();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		clever.closeBrowserSession();
	}
}