package com.qait.clever.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CleverTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;

public class InsertFreshData extends Parent_Test {
	CleverTestSessionInitiator clever;

	String baseURL, cleverUrl, distAdminUname, distAdminPass;
	String userName, userEmail, userPassword;
	String districtName;
	String teacherEmail, mytier;
	String studentsDataInJSON, teachersDataInJSON;
	String teacherFname1, teacherFname2, teacherFname3, teacherFname4;
	String teacherLname1, teacherLname2, teacherLname3, teacherLname4;
	String studentFname1, studentFname2, studentFname3, studentFname4;
	String studentLname1, studentLname2, studentLname3, studentLname4;
	String teacherEmail1, teacherEmail2, teacherEmail3, teacherEmail4;
	String studentEmail1, studentEmail2, studentEmail3, studentEmail4;
	int schoolId;

	Map<String, Object> data = new HashMap<String, Object>();

	private void initVars() {

		cleverUrl = getData("cleverUrl");
		distAdminUname = getData("districtAdminUsername");
		distAdminPass = getData("districtAdminPassword");
		userName = getData("username");
		userPassword = getData("password");
		mytier = System.getProperty("env");
		if (mytier == null) {
			mytier = ConfigPropertyReader.getProperty("tier");
		}
	}

	private void saveNewlyAddedData() {
		JSONObject jsonobjTeachers = new JSONObject(teachersDataInJSON);
		JSONObject jsonobjStudents = new JSONObject(studentsDataInJSON);
		teacherFname1 = jsonobjTeachers.getString("fname1");
		teacherFname2 = jsonobjTeachers.getString("fname2");
		teacherFname3 = jsonobjTeachers.getString("fname3");
		teacherFname4 = jsonobjTeachers.getString("fname4");
		teacherEmail1 = jsonobjTeachers.getString("email1");
		teacherEmail2 = jsonobjTeachers.getString("email2");
		teacherEmail3 = jsonobjTeachers.getString("email3");
		teacherEmail4 = jsonobjTeachers.getString("email4");

		studentFname1 = jsonobjStudents.getString("fname1");
		studentFname2 = jsonobjStudents.getString("fname2");
		studentFname3 = jsonobjStudents.getString("fname3");
		studentFname4 = jsonobjStudents.getString("fname4");
		studentEmail1 = jsonobjStudents.getString("email1");
		studentEmail2 = jsonobjStudents.getString("email2");
		studentEmail3 = jsonobjStudents.getString("email3");
		studentEmail4 = jsonobjStudents.getString("email4");
	}

	private void writeNewlyAddedDataToYaml() {

		data.put("teacher1fname", teacherFname1);
		data.put("teacher2fname", teacherFname2);
		data.put("teacher3fname", teacherFname3);
		data.put("teacher4fname", teacherFname4);
		data.put("student1fname", studentFname1);
		data.put("student2fname", studentFname2);
		data.put("student3fname", studentFname3);
		data.put("student4fname", studentFname4);

		data.put("teacher1email", teacherEmail1);
		data.put("teacher2email", teacherEmail2);
		data.put("teacher3email", teacherEmail3);
		data.put("teacher4email", teacherEmail4);
		data.put("student1email", studentEmail1);
		data.put("student2email", studentEmail2);
		data.put("student3email", studentEmail3);
		data.put("student4email", studentEmail4);

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		clever = new CleverTestSessionInitiator();
		initVars();

	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		clever.stepStartMessage(method.getName());
	}

	@Test
	public void LaunchCleverApplication() {
		clever.launchApplication(cleverUrl);
	}

	@Test(dependsOnMethods = "LaunchCleverApplication")
	public void verifyCleverLandingPageAndLogin() {
		clever.loginPageClever.verfiyLandingPageTitle();
		clever.loginPageClever.verifyLandingPage();
		clever.loginPageClever.chooseOptionFromloginDropdown("District admin");
		clever.loginPageClever.enterLoginDetails(userName, userPassword);
	}

	@Test(dependsOnMethods = "verifyCleverLandingPageAndLogin")
	public void verifyCleverHomePage() {
		clever.homePageClever.verifyHomePage();
	}

	@Test(dependsOnMethods = "verifyCleverHomePage")
	public void writeNewEntriesInSheets() throws Exception {
		clever.homePageClever.clickMenuItem("Sync");
		clever.homePageClever.clickOnTab("Upload");
		clever.homePageClever.verifyUploadSheetButtonsDisplayed();
		clever.insertEntriesClever.insertNewEntriesInEnrollmentsFile();
		clever.insertEntriesClever.insertNewEntriesInSectionsFile(mytier);
		studentsDataInJSON = clever.insertEntriesClever.insertNewEntriesInStudentsFile(mytier);
		teachersDataInJSON = clever.insertEntriesClever.insertNewEntriesInTeachersFile(mytier);
		saveNewlyAddedData();
		writeNewlyAddedDataToYaml();
		clever.chooseCoursePage.writeDataToYaml(data);
		clever.excel2csvClever.convertAllFilesToCSVForm("schools", "students", "enrollments", "admins", "sections",
				"teachers");

	}

	@Test(dependsOnMethods = "writeNewEntriesInSheets")
	public void uploadCSVFiles() {
		clever.homePageClever.uploadAllFiles();
		clever.homePageClever.clickUploadButton();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		clever.closeBrowserSession();
	}
}
