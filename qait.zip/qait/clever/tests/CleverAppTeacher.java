package com.qait.clever.tests;

import static com.qait.automation.utils.YamlReader.getData;
import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CleverTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;

public class CleverAppTeacher extends Parent_Test {
	CleverTestSessionInitiator clever;
	String appName, quizNameSec, quizNameMap;
	String module, instructorName;
	String baseURL, cleverAppUrl;
	String userName, userEmail, userPassword;
	String districtName, teacherName, courseCode;
	String teacherEmail, mytier;
	String fnameStud1, fnameStud2, fnameStud3, fnameStud4;
	String lnameStud1, lnameStud2, lnameStud3, lnameStud4;
	String fnameTeach1, fnameTeach2, fnameTeach3, fnameTeach4;
	String lnameTeach1, lnameTeach2, lnameTeach3, lnameTeach4;
	String emailTeach1, emailTeach2, emailTeach3, emailTeach4;

	private void initVars() {

		appName = getData("appName");
		cleverAppUrl = getData("cleverAppUrl");
		userName = getData("email");
		userPassword = getData("pass");
		mytier = System.getProperty("env");
		module = System.getProperty("module");
		districtName = getData("cleverDistrictName");
		if (mytier == null) {
			mytier = ConfigPropertyReader.getProperty("tier");
		}

		module = ConfigPropertyReader.getProperty("module");
		if (module.equalsIgnoreCase("launchpad") || module.equalsIgnoreCase("lp")) {
			appName = getData("appNameLP");
			quizNameSec = getData("QuizNames.quiz1");
			quizNameMap = getData("QuizNames.quiz3");
		} else {
			appName = getData("appNameSap");
			quizNameSec = getData("QuizNames.quiz2");
			quizNameMap = getData("QuizNames.quiz4");
		}

//		fnameStud1 = clever.chooseCoursePage.readDataFromYaml("student1fname");
//		fnameStud2 = clever.chooseCoursePage.readDataFromYaml("student2fname");
//		fnameStud3 = clever.chooseCoursePage.readDataFromYaml("student3fname");
//		fnameStud4 = clever.chooseCoursePage.readDataFromYaml("student4fname");
//		lnameStud1 = getData("LastNames.lname1");
//		lnameStud1 = getData("LastNames.lname2");
//		lnameStud1 = getData("LastNames.lname3");
//		lnameStud1 = getData("LastNames.lname4");
//		fnameTeach1 = clever.chooseCoursePage.readDataFromYaml("teacher1fname");
//		fnameTeach2 = clever.chooseCoursePage.readDataFromYaml("teacher2fname");
//		fnameTeach3 = clever.chooseCoursePage.readDataFromYaml("teacher3fname");
//		fnameTeach4 = clever.chooseCoursePage.readDataFromYaml("teacher4fname");
//		lnameTeach1 = getData("LastNames.lname1");
//		lnameTeach2 = getData("LastNames.lname2");
//		lnameTeach3 = getData("LastNames.lname3");
//		lnameTeach4 = getData("LastNames.lname4");
//		emailTeach1 = getData("teacher1email");
//		emailTeach2 = getData("teacher2email");
//		emailTeach3 = getData("teacher3email");
//		emailTeach4 = getData("teacher4email");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		clever = new CleverTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		clever.stepStartMessage(method.getName());
	}

	@Test
	public void LaunchCleverApplication() {
		clever.launchApplication(cleverAppUrl);
	}

	@Test(dependsOnMethods = "LaunchCleverApplication")
	public void VerifyLoginPageAndLogIn() {
		clever.appClever.verifyLoginPage();
		clever.appClever.enterLoginDetails(userName, userPassword);
	}

	@Test(dependsOnMethods = "VerifyLoginPageAndLogIn")
	public void VerifyHomePageAndClickDataBrowser() {
		clever.appClever.verifyHomePage();
		clever.appClever.chooseAppFromAppSwitcher(appName);
		clever.appClever.verifyCurrentApp(appName);
		clever.appClever.clickMenuOption("Settings", "Clever | Application Settings");
		clever.appClever.verifyWebsiteUrlUnderSettings(mytier);
		clever.appClever.clickMenuOption("Data Browser", "Clever | Data Browser");
	}

	@Test(dependsOnMethods = "VerifyHomePageAndClickDataBrowser")
	public void VerifyStudentDataIsDisplayed() throws InterruptedException {
		clever.appClever.verifyAllDataBrowserTabs();
		clever.appClever.chooseTab("District Admins");
		clever.appClever.chooseDistrct(districtName);
		clever.appClever.verifyHeadingFilterDisplayed();
		clever.appClever.chooseTab("Sections");
		clever.appClever.clickOnSection(quizNameSec);
	}

	@Test(dependsOnMethods = "VerifyStudentDataIsDisplayed")
	public void VerifyTeacherDataIsDisplayed() throws InterruptedException {
	}

	@Test(dependsOnMethods = "VerifyTeacherDataIsDisplayed")
	public void verifyStudentDataOnModalWindowAndNavigation() throws InterruptedException {
		clever.appClever.verifyForTeacher();
		clever.appClever.useFirstStudent();
		clever.appClever.clickLoginLink();
		courseCode = clever.pxpageActions.verifyChkboxAndCourseTitle(districtName, quizNameSec);
		clever.pxpageActions.verifyUserNavigatedToIntegratedComponent(module, courseCode);
		clever.appClever.closeModalWindow();
		clever.appClever.verifyHeadingFilterDisplayed();
	}

	@Test(dependsOnMethods = "verifyStudentDataOnModalWindowAndNavigation")
	public void verifyTeacherDataOnModalWindowAndNavigation() throws InterruptedException {
		clever.appClever.chooseTab("Sections");
		clever.appClever.clickOnSection(quizNameMap);
		teacherName = clever.appClever.getTeacherName();
		clever.appClever.verifyForTeacher();
		clever.appClever.useFirstStudent();
		clever.appClever.clickLoginLink();
		courseCode = clever.pxpageActions.verifyChkboxAndCourseTitle(districtName, teacherName);
		clever.pxpageActions.verifyUserNavigatedToIntegratedComponent(module, courseCode);
		clever.appClever.closeModalWindow();
		clever.appClever.verifyHeadingFilterDisplayed();

	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		clever.closeBrowserSession();
	}
}
