package com.qait.clever.keywords;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.awt.Window;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class PXPageActions extends GetPage {

	public PXPageActions(WebDriver driver) {
		super(driver, "PXPage");
	}

	public String verifyChkboxAndCourseTitle(String courseName, String otherName) throws InterruptedException {
		verifyUserNavigatedToPXPage();
		verifyPageContent();
		int stats = clickChkbox();
		if (stats == 1) {
			clickChkbox();
			verifyCourseLinkDisabled();
			clickChkbox();
			verifyCourseLinkEnabled();
		}
		verifyCourseTitle(courseName, otherName);
		String courseCode = getCourseCode(courseName, otherName);
		clickCourseTitle();
		return courseCode;
	}

	public String getCourseCodeForLP() {
		String currentUrl = getCurrentURL();
		System.out.println("The current Url is " + currentUrl);
		String parts[] = currentUrl.split("/");
		System.out.println("Course Code is " + parts[5]);
		return parts[5];
	}

	public String getCourseCodeForSap() {
		String currentUrl = getCurrentURL();
		String arr[] = currentUrl.split("=");
		return arr[1];

	}

	public void verifyCourseTitle(String courseName, String otherName) {
		String mylinkText = courseName + "-" + otherName;
		waitForElementToBeVisible("link_RightCourseName", mylinkText);
		assertTrue(element("link_RightCourseName", mylinkText).isDisplayed(), mylinkText);
		logMessage("Verified CourseName and is as expected " + courseName);
	}

	public String getCourseCode(String courseName, String otherName) {
		String myCourseName = courseName + "-" + otherName;
		waitForElementToBeVisible("link_CourseCode", myCourseName);
		return element("link_CourseCode", myCourseName).getText();
	}

	public void verifyUserOnSaplingHomepage() {
		waitForElementToBeVisible("heading_SapPage");
		isElementDisplayed("heading_SapPage");
		logMessage("User is on the Sapling Page now");
//		waitAndClick("btn_YES");
//		waitForElementToBeVisible("input_Inst");
//		assertTrue(isElementDisplayed("input_Inst"));
		List<WebElement> yesbutton = elements("btn_YES");
		if (yesbutton.size() == 1) {
			waitAndClick("btn_YES");
			System.out.println("Clicked on yes btn");
		}
	}

	public void verifyUserOnLaunchPadHomepage() {
		waitForElementToBeVisible("heading_launchpadPage");
		isElementDisplayed("heading_launchpadPage");
		logMessage("User is on the launchpad homepage ");
	}

	public void verifyUserNavigatedToPXPage() throws InterruptedException {
		changeWindow(1);
		Thread.sleep(5000);
	}

	public void verifyPageContent() {
		verifybfwImageIconDisplayed();
		verifyLeftAndRightContentIsDisplayed();

	}

	public void verifybfwImageIconDisplayed() {

		waitForElementToBeVisible("bfw_Logo");
		isElementDisplayed("bfw_Logo");
		logMessage("successfully navigated to PX page");

	}

	public int clickChkbox() {
		List<WebElement> myelementlist = elements("chkbox_Eula");
		if (myelementlist.size() == 1) {
			waitForElementToBeVisible("chkbox_Eula");
			isElementDisplayed("chkbox_Eula");
			waitAndClick("chkbox_Eula");
			return 1;
		} else
			return 0;
	}

	public void verifyCourseLinkEnabled() {
		assertTrue(isCourseTitleLinkEnabled());
	}

	public void verifyCourseLinkDisabled() {
		assertTrue(isCourseTitleLinkDisabled());
	}

	public boolean isCourseTitleLinkEnabled() {
		waitForElementToBeVisible("link_EnabledCourse");
		return isElementDisplayed("link_EnabledCourse");

	}

	public boolean isCourseTitleLinkDisabled() {
		waitForElementToBeVisible("link_DisabledCourse");
		return isElementDisplayed("link_DisabledCourse");

	}

	public void clickCourseTitle() {
		isElementDisplayed("link_CourseTitle");
		waitAndClick("link_CourseTitle");
		logMessage("Clicked on Course Title");
	}

	public void verifyLeftAndRightContentIsDisplayed() {
		waitForElementToBeVisible("course_content");
		isElementDisplayed("course_content");
		waitForElementToBeVisible("left_content");
		isElementDisplayed("left_content");
		logMessage("Content is displayed on the page");

	}

	public void verifyUserNavigatedToIntegratedComponent(String module, String mycourseCode) {
		if (module.equalsIgnoreCase("sapling")) {
			verifyUserOnSaplingHomepage();
			String courseCode = getCourseCodeForSap();
			assertEquals(mycourseCode, courseCode);
			logMessage("Verified the course Code " + courseCode);
			closeWindowAndSwitchBackToOriginalWindow(0);

		} else {
			verifyUserOnLaunchPadHomepage();
			String courseCode = getCourseCodeForLP();
			assertEquals(mycourseCode, courseCode);
			logMessage("Verified the course Code " + courseCode);
			closeWindowAndSwitchBackToOriginalWindow(0);
		}

	}

}
