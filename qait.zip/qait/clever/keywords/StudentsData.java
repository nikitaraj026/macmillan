package com.qait.clever.keywords;

public class StudentsData {

	public String fname1, fname2, fname3, fname4;
	public String lname1, lname2, lname3, lname4;
	public String email1, email2, email3, email4;
	public int schoolID;

	public void setStudentFname1(String fname1) {
		this.fname1 = fname1;
	}

	public void setStudentFname2(String fname2) {
		this.fname2 = fname2;
	}

	public void setStudentFname3(String fname3) {
		this.fname3 = fname3;
	}

	public void setStudentFname4(String fname4) {
		this.fname4 = fname4;
	}

	public void setStudentLname1(String lname1) {
		this.lname1 = lname1;
	}

	public void setStudentLname2(String lname2) {
		this.lname2 = lname2;
	}

	public void setStudentLname3(String lname3) {
		this.lname3 = lname3;
	}

	public void setStudentLname4(String lname4) {
		this.lname4 = lname4;
	}

	public void setStudentEmail1(String email1) {
		this.email1 = email1;
	}

	public void setStudentEmail2(String email2) {
		this.email2 = email2;
	}

	public void setStudentEmail3(String email3) {
		this.email3 = email3;
	}

	public void setStudentEmail4(String email4) {
		this.email4 = email4;
	}

	public void setSchoolID(int schoolID) {
		this.schoolID = schoolID;
	}

}