package com.qait.clever.keywords;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.yaml.snakeyaml.Yaml;

import com.qait.automation.getpageobjects.GetPage;

public class ChooseCoursePageActions extends GetPage{
	
	public ChooseCoursePageActions(WebDriver driver) {
		super(driver, "ChooseCoursePage");
	}

	public void verifyUserIsOnChooseCoursePage()
	{
		isElementDisplayed("logo_bfw");
		logMessage("User is on Choose Course page");
	}
	
	public void clickOnCourseNameLink(String courseName)
	{
		waitScrollAndClick("lnk_courseName", courseName);
		logMessage("User has clicked on the course name link on Choose Course page");
	}
	
	public void writeDataToYaml(Map<String, Object> data) {
		Yaml yaml = new Yaml();
		FileWriter writer = null;
		try {
			writer = new FileWriter("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "CLEVER" + File.separator + "DynamicTestData.yml");
			yaml.dump(data, writer);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	public String readDataFromYaml(String token) {
		Reader doc = null;
		try {
			doc = new FileReader("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "CLEVER" + File.separator + "DynamicTestData.yml");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		Yaml yaml = new Yaml();
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);
		return getMapValue(object, token);
	}
	private static String getMapValue(Map<String, Object> object, String token) {
		// TODO: check for proper yaml token string based on presence of '.'
		String[] st = token.split("\\.");
		return parseMap(object, token).get(st[st.length - 1]).toString();
	}
	
	private static Map<String, Object> parseMap(Map<String, Object> object, String token) {
		if (token.contains(".")) {
			String[] st = token.split("\\.");
			object = parseMap((Map<String, Object>) object.get(st[0]), token.replace(st[0] + ".", ""));
		}
		return object;
	}
}
