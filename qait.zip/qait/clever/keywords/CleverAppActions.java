package com.qait.clever.keywords;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class CleverAppActions extends GetPage {

	public CleverAppActions(WebDriver driver) {
		super(driver, "CleverApp");
	}

	public void verifyLoginPage() {
		waitForElementToBeVisible("inpt_Email");
		isElementDisplayed("inpt_Email");
		waitForElementToBeVisible("inpt_Password");
		isElementDisplayed("inpt_Password");
		waitForElementToBeVisible("btn_Login");
		isElementDisplayed("btn_Login");
		waitForElementToBeVisible("forgot_passwordLink");
		isElementDisplayed("forgot_passwordLink");

		logMessage("Login Page has been verified");
	}

	public void enterLoginDetails(String uname, String password) {

		fillText("inpt_Email", uname);
		fillText("inpt_Password", password);
		waitAndClick("btn_Login");

	}

	public void verifyMenuItems() {
		String menuOptions[] = { "Menu", "Home", "Data Browser", "Analytics", "Dev Tools", "Library", "Settings",
				"Team", "Billing", "Clever Concierge" };

		for (int i = 0; i < menuOptions.length; i++) {
			isElementDisplayed("item_Menu", menuOptions[i]);
		}
		logMessage("All menu options has been verified");

	}

	public void verifyHomePage() {
		isElementDisplayed("inpt_Search");
		logMessage("Input Search Element has been verified");
		verifyMenuItems();
	}

	public void clickMenuOption(String option, String pageTitle) {

		waitForElementToBeVisible("item_Menu", option);
		isElementDisplayed("item_Menu", option);
		waitAndClick("item_Menu", option);
		waitForPageToLoadCompletely(pageTitle);

	}

	public void verifyWebsiteUrlUnderSettings(String mytier) {
		waitForElementToBeVisible("websiteURl");
		String websiteUrl = element("websiteURl").getText();
		if (mytier.equalsIgnoreCase("lt"))
			assertTrue(websiteUrl.contains("load"));
		else
			assertFalse(websiteUrl.contains("load"));
		logMessage("Verified the website Url text");

	}

	public void verifyAllDataBrowserTabs() {
		String tabsName[] = { "Districts", "Schools", "Students", "Teachers", "School Admins", "District Admins",
				"Sections", "Contacts (v2)", "Terms", "Courses" };

		for (int i = 0; i < tabsName.length; i++) {
			waitForElementToBeVisible("browse_tabs", tabsName[i]);
			isElementDisplayed("browse_tabs", tabsName[i]);
		}
		logMessage("All menu options has been verified");
		hardWait(5);
	}

	public void chooseAppFromAppSwitcher(String appName) {
		waitForElementToBeVisible("btn_AppSwitcher");
		isElementDisplayed("btn_AppSwitcher");
		waitAndClick("btn_AppSwitcher");
		waitForElementToBeVisible("btn_AppItem", appName);
		waitAndClick("btn_AppItem", appName);
		logMessage("Selected " + appName + " as the app from App Switcher");
		waitForPageToLoadCompletely("Clever | District Overview");

	}

	public void verifyCurrentApp(String appName) {
		waitForElementToBeVisible("current_App", appName);
		isElementDisplayed("current_App", appName);
		logMessage("Current App is" + appName);
	}

	public void chooseTab(String tabName) {
		waitForElementToBeVisible("browse_tabs", tabName);
		waitAndScrollToElement("browse_tabs", tabName);
		waitAndClick("browse_tabs", tabName);
		logMessage("Clicked on " + tabName + " from Data Browser tabs");
	}

	public void clickOnSection(String secName) throws InterruptedException {

		waitForElementToBeVisible("sectionName", secName);
		Thread.sleep(3000);
		waitAndClick("sectionName", secName);
		verifyModalWindowDisplayed();
	}

	public void chooseDistrct(String districtName) {
		waitForElementToBeVisible("btn_enterValue");
		isElementDisplayed("btn_enterValue");
		waitAndClick("btn_enterValue");
		waitForElementToBeVisible("option_distrName", districtName);
		isElementDisplayed("option_distrName", districtName);
		waitAndClick("option_distrName", districtName);
	}

	public void verifyHeadingFilterDisplayed() throws InterruptedException {
		waitForElementToBeVisible("heading_filter");
		isElementDisplayed("heading_filter");
		logMessage("Heading filter is displayed");
		Thread.sleep(5000);

	}

	public void verfiyNewlyAddedStudentDisplayedOnStudentsTab(String fname, String lname, String distName) {

		waitForElementToBeVisible("cell_firstName", fname);
		waitAndScrollToElement("cell_firstName", fname);
		isElementDisplayed("cell_firstName", fname);

		waitForElementToBeVisible("cell_lastName", fname, lname);
		isElementDisplayed("cell_lastName", fname, lname);

		waitForElementToBeVisible("cell_districtName", fname, distName);
		isElementDisplayed("cell_districtName", fname, distName);
		logMessage("All Details for the newly added student are displayed uder Students tab");
	}

	public void verfiyNewlyAddedTeacherDisplayedOnTeachersTab(String fname, String lname, String distName,
			String email) {
		waitForElementToBeVisible("cell_firstName", fname);
		waitAndScrollToElement("cell_firstName", fname);
		isElementDisplayed("cell_firstName", fname);
		waitForElementToBeVisible("cell_lastName", fname, lname);
		isElementDisplayed("cell_lastName", fname, lname);
		waitForElementToBeVisible("cell_districtName", fname, distName);
		isElementDisplayed("cell_districtName", fname, distName);

		waitForElementToBeVisible("cell_email", email);
		isElementDisplayed("cell_email", email);
		logMessage("All Details for the newly added teacher are displayed uder Teachers tab");
	}

	public void verifyModalWindowDisplayed() {
		waitForElementToBeVisible("modal_Box");
		isElementDisplayed("modal_Box");
		waitForElementToBeVisible("header_DetailView");
		executeJavascript("window.scrollBy(0,-1000)");
		isElementDisplayed("header_DetailView");
		logMessage("Modal window is displayed successfully");

	}

	public void verifyModalWindowEntry(String fieldName, String fieldValue) {
		waitForElementToBeVisible("entry_ModalWindow", fieldName, fieldValue);
		isElementDisplayed("entry_ModalWindow", fieldName, fieldValue);
		logMessage("Field name " + fieldName + " has value " + fieldValue);

	}

	public void clickLoginLink() {
		waitForElementToBeVisible("link_Login");
		isElementDisplayed("link_Login");
		waitAndClick("link_Login");
	}

	public void verifyForStudent() {
		waitForElementToBeVisible("studentLink");
		waitAndClick("studentLink");
	}

	public void verifyForTeacher() {
		waitForElementToBeVisible("teacherLink");
		waitAndClick("teacherLink");
	}

	public void useTeacher() {
		waitForElementToBeVisible("teacherLink");
		waitAndClick("teacherLink");
		logMessage("Clicked on the teacher link for the course");
	}

	public String getTeacherName() {
		waitForElementToBeVisible("teacherLink");
		String teachName = element("teacherLink").getText();
		String teachFullName[] = teachName.split("\\s+");
		System.out.println("Got teacher lastName" + teachFullName[2]);
		return teachFullName[2];
	}

	public void useFirstStudent() {
		waitForElementToBeVisible("first_Stud");
		waitAndClick("first_Stud");
	}

	public void closeModalWindow() {
		waitForElementToBeVisible("btn_CloseModalWindow");
		isElementDisplayed("btn_CloseModalWindow");
		waitAndClick("btn_CloseModalWindow");
		logMessage("Successfully closed the modal window");

	}

	public void verifyDataOnModalWindow(String fName, String lName, String districtName) throws InterruptedException {
		waitForElementToBeVisible("cell_firstName", fName);
		waitAndScrollToElement("cell_firstName", fName);
		waitAndClick("cell_firstName", fName);
		verifyModalWindowDisplayed();
		verifyModalWindowEntry("district", districtName);
		verifyModalWindowEntry("name.first", fName);
		verifyModalWindowEntry("name.last", lName);
		logMessage("For Student " + fName + " " + lName + " details are displayed on the Modal window");

	}

}