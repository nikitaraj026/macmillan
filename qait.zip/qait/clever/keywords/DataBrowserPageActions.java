package com.qait.clever.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class DataBrowserPageActions extends GetPage{
	public DataBrowserPageActions(WebDriver driver) {
		super(driver, "DataBrowserPage");
	}
	
	public void verifyBrowseTextDisplayed() {
		isElementDisplayed("txt_browse");
		logMessage("Browse text is displayed");
	}
	
	public void districtDropDownFilterIsDisplayed() {
		isElementDisplayed("dropdown_districtFilter");
		logMessage("District dropdown filter is displayed");
	}
	
	public void verifyNavigationMenuTabIsDisplayed(List<String> menuName) {
		
	}
	
	public void verifyDataBrowsepage() {
		verifyBrowseTextDisplayed();
	}
	
	public void verifyFilterOptionForDistrict(String districtName) {
		hardWait(5);
		areElementsDisplayed("lnk_list_districtName", districtName);
		logMessage("Teachers are filter according to district: " + districtName);
	}
	
	public void verifyDetailViewWindowDisplayed() {
		isElementDisplayed("txt_detailView");
		logMessage("Detail View window is displayed");
	}
	
	public void clickDistrictDropdownFilter() {
		waitAndClick("dropdown_districtFilter");
		logMessage("Clicked on District dropdown filter");
	}
	
	public void clickSearchResultOption() {
		waitAndClick("dropDown_searchResult");
		logMessage("Click on searched result");
	}
	
	public void enterDistrictNameAndSelect(String districtName) {
		clickDistrictDropdownFilter();
		fillText("input_districtName", districtName);
		clickSearchResultOption();
	}
	
	public void clickOnTabOnDataBrowsePage(String tabName) {
		waitAndClick("lnk_tabMenu", tabName);
		logMessage("Clicked on tab name: " +  tabName);
	}
	
	public void clickOnUserEmail(String email) {
		waitScrollAndClick("lnk_userEmail", email);
		logMessage("Clicked on user email:" +  email);
	}
	
	public void clickOnLoginAsUserName() {
		try {
			element("lnk_loginAs").click();
		}
		catch (org.openqa.selenium.StaleElementReferenceException e) {
			logMessage("Exception in finding login link");
			System.out.println(e);
			element("lnk_loginAs").click();
		}
		
//		waitForElementToBeClickable(element("lnk_loginAs"));
//		waitScrollAndClick("lnk_loginAs");
		logMessage("Click on link login as uesr name");
		changeWindow(1);
	}
}
