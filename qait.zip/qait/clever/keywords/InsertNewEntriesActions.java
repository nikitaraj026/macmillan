package com.qait.clever.keywords;

//Author -> Rishabh


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;
import static com.qait.automation.utils.YamlReader.getData;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jackson.map.ObjectMapper;
import org.openxmlformats.schemas.wordprocessingml.x2006.main.STUnderline;

import com.google.api.client.util.StringUtils;
import com.qait.automation.utils.ConfigPropertyReader;

import bsh.StringUtil;
import net.bytebuddy.utility.RandomString;

public class InsertNewEntriesActions {

	public void addDataToCell(Workbook workbook, String fpath, Row row, int cellNum, String value) throws IOException {
		Cell cell = row.createCell(cellNum);
		cell.setCellType(cell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
		FileOutputStream fos = new FileOutputStream(fpath);
		workbook.write(fos);

	}

	public void addDataToCell(Workbook workbook, String fpath, Row row, int cellNum, int value) throws IOException {
		Cell cell = row.createCell(cellNum);
		cell.setCellType(cell.CELL_TYPE_NUMERIC);
		cell.setCellValue(value);
		FileOutputStream fos = new FileOutputStream(fpath);
		workbook.write(fos);

	}

	public void addNewRowInTeachers(HSSFWorkbook workbook, HSSFSheet sheet, int totalRows, String fpath, String fname,
			String lname, int schoolId, int stateTeacherId, String teacherEmail, int teacherId, int teacherNum,
			String title) throws IOException {
		Row row = sheet.createRow(totalRows);
		addDataToCell(workbook, fpath, row, 0, fname);
		addDataToCell(workbook, fpath, row, 1, lname);
		addDataToCell(workbook, fpath, row, 4, schoolId);
		addDataToCell(workbook, fpath, row, 5, stateTeacherId);
		addDataToCell(workbook, fpath, row, 6, teacherEmail);
		addDataToCell(workbook, fpath, row, 7, teacherId);
		addDataToCell(workbook, fpath, row, 8, teacherNum);
		addDataToCell(workbook, fpath, row, 9, title);

	}

	public void addNewRowInStudents(HSSFWorkbook workbook, HSSFSheet sheet, int totalRows, String fpath,
			String conEmail, String conName, String conPhone, String ConType, String dob, String fname, String gender,
			int grade, String lname, int schoolId, int stateId, String studEmail, int studId, int stuNum)
			throws IOException {

		Row row = sheet.createRow(totalRows);
		addDataToCell(workbook, fpath, row, 0, conEmail);
		addDataToCell(workbook, fpath, row, 1, conName);
		addDataToCell(workbook, fpath, row, 2, conPhone);
		addDataToCell(workbook, fpath, row, 3, ConType);
		addDataToCell(workbook, fpath, row, 4, dob);
		addDataToCell(workbook, fpath, row, 6, fname);
		addDataToCell(workbook, fpath, row, 8, gender);
		addDataToCell(workbook, fpath, row, 9, grade);
		addDataToCell(workbook, fpath, row, 12, lname);
		addDataToCell(workbook, fpath, row, 16, schoolId);
		addDataToCell(workbook, fpath, row, 17, stateId);
		addDataToCell(workbook, fpath, row, 18, studEmail);
		addDataToCell(workbook, fpath, row, 19, studId);
		addDataToCell(workbook, fpath, row, 20, stuNum);

	}

	public void addNewRowInSections(HSSFWorkbook workbook, HSSFSheet sheet, int totalRows, String fpath, int schoolId,
			String secId, int teacherId, String name, int grade, String subject) throws IOException {

		Row row = sheet.createRow(totalRows);
		addDataToCell(workbook, fpath, row, 0, schoolId);
		addDataToCell(workbook, fpath, row, 1, secId);
		addDataToCell(workbook, fpath, row, 2, teacherId);
		addDataToCell(workbook, fpath, row, 6, name);
		addDataToCell(workbook, fpath, row, 7, grade);
		addDataToCell(workbook, fpath, row, 11, subject);

	}

	public void addNewRowInEnrollments(HSSFWorkbook workbook, HSSFSheet sheet, int totalRows, String fpath,
			int schoolId, String sectionId, int studId) throws IOException {

		Row row = sheet.createRow(totalRows);
		addDataToCell(workbook, fpath, row, 0, schoolId);
		addDataToCell(workbook, fpath, row, 1, sectionId);
		addDataToCell(workbook, fpath, row, 2, studId);

	}

	public int getSchool_Id() throws IOException {
		File dirFile = new File(System.getProperty("user.dir"), "ScoresImportExport");
		String fpath = dirFile.getAbsolutePath() + File.separator + "CleverXSL" + File.separator + "schools.xls";

		FileInputStream fis = new FileInputStream(fpath);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheetAt(0);
		Row row = sheet.getRow(1);
		Cell cell = row.getCell(6);
		return (int) cell.getNumericCellValue();

	}

	public String getRandomString(String sample) {
		return sample + RandomStringUtils.randomAlphabetic(6);
	}

	public String getRandomInstrEmail() {
		return "cleverInstr" + RandomStringUtils.randomAlphanumeric(5) + "@yopmail.com";

	}

	public String getRandomStudEmail() {
		return "cleverStud" + RandomStringUtils.randomAlphanumeric(5) + "@yopmail.com";

	}

	public String getStudContactName() {
		return "studname" + RandomStringUtils.randomAlphanumeric(5);
	}

	public String getStudContactPh() {
		return "989736" + RandomStringUtils.randomNumeric(4);
	}

	public String getIncrementalSectionId(Cell cell, int incrementBy) {
		String strArr[] = cell.getStringCellValue().split("-");

		int toInc = Integer.parseInt(strArr[1]) + incrementBy;

		return strArr[0] + "-" + toInc + "-" + strArr[2];

	}

	public int getIncrementedValueOfCell(Cell cell) {
		cell.setCellType(cell.CELL_TYPE_NUMERIC);
		return (int) (cell.getNumericCellValue() + 1);
	}

	public String insertNewEntriesInTeachersFile(String env) throws IOException {

		TeachersData saveData = new TeachersData();

		File dirFile = new File(System.getProperty("user.dir"), "ScoresImportExport");
		String fpath = dirFile.getAbsolutePath() + File.separator + "CleverXSL" + File.separator + "teachers.xls";

		FileInputStream fis = new FileInputStream(fpath);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheetAt(0);

		int totalRows = sheet.getLastRowNum() + 1;

		Row row = sheet.getRow(totalRows - 1);
		int totalCols = row.getLastCellNum();
		Cell cellStateTeacherID = row.getCell(5);
		int nextStateTID = getIncrementedValueOfCell(cellStateTeacherID);
		Cell cellTeacherID = row.getCell(7);
		int nextTID = getIncrementedValueOfCell(cellTeacherID);
		Cell cellTeacherNum = row.getCell(8);
		int nextTNum = getIncrementedValueOfCell(cellTeacherNum);
		String lname1, lname2, lname3, lname4;
		String fname1, fname2, fname3, fname4;
		String email1, email2, email3, email4;
		fname1 = getRandomString("Teacher");
		fname2 = getRandomString("Teacher");
		fname3 = getRandomString("Teacher");
		fname4 = getRandomString("Teacher");
		lname1 = getData("LastNames.lname1");
		lname2 = getData("LastNames.lname2");
		lname3 = getData("LastNames.lname3");
		lname4 = getData("LastNames.lname1");
		email1 = getRandomInstrEmail();
		email2 = getRandomInstrEmail();
		email3 = "";
		email4 = getRandomInstrEmail();

		saveData.setTeacherLname1(lname1);
		saveData.setTeacherLname2(lname2);
		saveData.setTeacherLname3(lname3);
		saveData.setTeacherLname4(lname4);
		saveData.setTeacherFname1(fname1);
		saveData.setTeacherFname2(fname2);
		saveData.setTeacherFname3(fname3);
		saveData.setTeacherFname4(fname4);
		saveData.setTeacherEmail1(email1);
		saveData.setTeacherEmail2(email2);
		saveData.setTeacherEmail3(email3);
		saveData.setTeacherEmail4(email4);
		saveData.setSchoolID(getSchool_Id());
		ObjectMapper obj = new ObjectMapper();

		String jsonStr = obj.writeValueAsString(saveData);

		addNewRowInTeachers(workbook, sheet, totalRows, fpath, fname1, lname1, getSchool_Id(), nextStateTID, email1,
				nextTID, nextTNum, "Teacher");
		addNewRowInTeachers(workbook, sheet, totalRows + 1, fpath, fname2, lname2, getSchool_Id(), nextStateTID + 1,
				email2, nextTID + 1, nextTNum + 1, "Teacher");
		addNewRowInTeachers(workbook, sheet, totalRows + 2, fpath, fname3, lname3, getSchool_Id(), nextStateTID + 2,
				email3, nextTID + 2, nextTNum + 2, "Teacher");
		addNewRowInTeachers(workbook, sheet, totalRows + 3, fpath, fname4, lname4, getSchool_Id(), nextStateTID + 3,
				email4, nextTID + 3, nextTNum + 3, "Teacher");

		System.out.println("Successfully Added new Entries in Teachers file");
		return jsonStr;
	}

	public String insertNewEntriesInStudentsFile(String env) throws IOException {
		StudentsData saveData = new StudentsData();

		File dirFile = new File(System.getProperty("user.dir"), "ScoresImportExport");
		String fpath = dirFile.getAbsolutePath() + File.separator + "CleverXSL" + File.separator + "students.xls";

		FileInputStream fis = new FileInputStream(fpath);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheetAt(0);

		int totalRows = sheet.getLastRowNum() + 1;

		Row row = sheet.getRow(totalRows - 1);
		int totalCols = row.getLastCellNum();
		Cell cellStateID = row.getCell(17);
		int nextCellSID = getIncrementedValueOfCell(cellStateID);
		Cell cellStudID = row.getCell(19);
		int nextStudID = getIncrementedValueOfCell(cellStudID);
		Cell cellStudNum = row.getCell(20);
		int nextStudNum = getIncrementedValueOfCell(cellStudNum);

		String email1 = getRandomStudEmail();
		String email2 = getRandomStudEmail();
		String email3 = getRandomStudEmail();
		String name1 = getStudContactName();
		String name2 = getStudContactName();
		String name3 = getStudContactName();
		String name4 = getStudContactName();

		String lname1, lname2, lname3, lname4;

		lname1 = getData("LastNames.lname1");
		lname2 = getData("LastNames.lname2");
		lname3 = getData("LastNames.lname3");
		lname4 = getData("LastNames.lname1");
		
		saveData.setStudentFname1(name1);
		saveData.setStudentFname2(name2);
		saveData.setStudentFname3(name3);
		saveData.setStudentFname4(name4);
		saveData.setStudentLname1(lname1);
		saveData.setStudentLname2(lname2);
		saveData.setStudentLname3(lname3);
		saveData.setStudentLname4(lname4);
		saveData.setStudentEmail1(email1);
		saveData.setStudentEmail2(email2);
		saveData.setStudentEmail3("");
		saveData.setStudentEmail4(email3);
        saveData.setSchoolID(getSchool_Id());
        
        ObjectMapper obj = new ObjectMapper();
        String jsonStr = obj.writeValueAsString(saveData);
        
		addNewRowInStudents(workbook, sheet, totalRows, fpath, email1, name1, getStudContactPh(), "Parent", "", name1,
				"M", 10, lname1, getSchool_Id(), nextCellSID, email1, nextStudID, nextStudNum);
		addNewRowInStudents(workbook, sheet, totalRows + 1, fpath, email2, name2, getStudContactPh(), "Parent",
				"3/10/2001", name2, "M", 10, lname2, getSchool_Id(), nextCellSID + 1, email2, nextStudID + 1,
				nextStudNum + 1);

		addNewRowInStudents(workbook, sheet, totalRows + 2, fpath, "", name3, getStudContactPh(), "Parent", "3/10/2001",
				name3, "M", 10, lname3, getSchool_Id(), nextCellSID + 2, "", nextStudID + 2, nextStudNum + 2);
		addNewRowInStudents(workbook, sheet, totalRows + 3, fpath, email3, name4, getStudContactPh(), "Parent", "",
				name4, "M", 10, lname4, getSchool_Id(), nextCellSID + 3, email3, nextStudID + 3, nextStudNum + 3);

		System.out.println("Successfully Added new Entries in Students file");

		return jsonStr;
	
	}

	public void insertNewEntriesInSectionsFile(String env) throws IOException {

		File dirFile = new File(System.getProperty("user.dir"), "ScoresImportExport");
		String fpath = dirFile.getAbsolutePath() + File.separator + "CleverXSL" + File.separator + "sections.xls";

		FileInputStream fis = new FileInputStream(fpath);
		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheetAt(0);

		int totalRows = sheet.getLastRowNum() + 1;

		Row row = sheet.getRow(totalRows - 1);
		int totalCols = row.getLastCellNum();
		Cell teacherID = row.getCell(2);
		int nextTeachID = getIncrementedValueOfCell(teacherID);
		Cell sectionId = row.getCell(1);
		String quiz1, quiz2, quiz3, quiz4, quiz5;

		quiz1 = getData("QuizNames.quiz1");
		quiz2 = getData("QuizNames.quiz2");
		quiz3 = getData("QuizNames.quiz3");
		quiz4 = getData("QuizNames.quiz4");
		quiz5 = getData("QuizNames.quiz5");
		addNewRowInSections(workbook, sheet, totalRows, fpath, getSchool_Id(), getIncrementalSectionId(sectionId, 1),
				nextTeachID, quiz1, 99, "admin");
		addNewRowInSections(workbook, sheet, totalRows + 1, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 2), nextTeachID + 1, quiz2, 99, "admin");
		addNewRowInSections(workbook, sheet, totalRows + 2, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 3), nextTeachID + 2, quiz3, 99, "admin");
		addNewRowInSections(workbook, sheet, totalRows + 3, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 4), nextTeachID, quiz4, 99, "admin");
		addNewRowInSections(workbook, sheet, totalRows + 4, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 5), nextTeachID + 3, quiz5, 99, "admin");

		System.out.println("Successfully Added new Entries in Sections file");
	}

	public void insertNewEntriesInEnrollmentsFile() throws IOException {
		File dirFile = new File(System.getProperty("user.dir"), "ScoresImportExport");
		String fpath = dirFile.getAbsolutePath() + File.separator + "CleverXSL" + File.separator + "enrollments.xls";

		FileInputStream fis = new FileInputStream(fpath);

		HSSFWorkbook workbook = new HSSFWorkbook(fis);
		HSSFSheet sheet = workbook.getSheetAt(0);

		int totalRows = sheet.getLastRowNum() + 1;

		Row row = sheet.getRow(totalRows - 1);
		int totalCols = row.getLastCellNum();
		Cell studID = row.getCell(2);
		int nextStudID = getIncrementedValueOfCell(studID);
		Cell sectionId = row.getCell(1);

		addNewRowInEnrollments(workbook, sheet, totalRows, fpath, getSchool_Id(), getIncrementalSectionId(sectionId, 1),
				nextStudID);
		addNewRowInEnrollments(workbook, sheet, totalRows + 1, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 2), nextStudID + 1);
		addNewRowInEnrollments(workbook, sheet, totalRows + 2, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 3), nextStudID + 2);
		addNewRowInEnrollments(workbook, sheet, totalRows + 3, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 4), nextStudID);
		addNewRowInEnrollments(workbook, sheet, totalRows + 4, fpath, getSchool_Id(),
				getIncrementalSectionId(sectionId, 5), nextStudID + 3);

		System.out.println("Successfully Added new Entries in Enrollments file");
	}
}