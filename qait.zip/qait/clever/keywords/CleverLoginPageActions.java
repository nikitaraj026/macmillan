package com.qait.clever.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class CleverLoginPageActions extends GetPage {

	public CleverLoginPageActions(WebDriver driver) {
		super(driver, "CleverLoginPage");
	}

	public void verfiyLandingPageTitle() {
		waitForElementToBeVisible("page_Title");
		isElementDisplayed("page_Title");
		logMessage("Page title has been verfified");
	}

	public void verifyLandingPage() {
		isElementDisplayed("drpdwn_Login");
		isElementDisplayed("btn_getStarted");
		logMessage("Clever Landing Page has been verified");
	}

	public void chooseOptionFromloginDropdown(String option) {
		hover(element("drpdwn_Login"));
		waitForElementToBeVisible("login_As", option);
		isElementDisplayed("login_As", option);
		waitAndClick("login_As", option);
	}

	public void enterLoginDetails(String uname, String password) {
		waitForElementToBeVisible("inpt_userName");
		waitForElementToBeVisible("inpt_pass");
		waitForElementToBeVisible("btn_Login");
		fillText("inpt_userName", uname);
		fillText("inpt_pass", password);
		waitAndClick("btn_Login");
		logMessage("Entered Login Details: " + uname + ", " + password);

	}

}
