package com.qait.clever.keywords;

import java.io.*;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.*;
import java.util.Iterator;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;

public class excel2csv {

	private static final String NEW_LINE_CHARACTER = "\r\n";
	private static final String CVS_SEPERATOR_CHAR = ",";
	private static final String OUTPUT_DATE_FORMAT = "yyyy-MM-dd";

	public static void excelToCSV(String excelFileName, String csvFileName) throws Exception {
		checkValidFile(csvFileName);
		HSSFWorkbook myWorkBook = new HSSFWorkbook(new POIFSFileSystem(new FileInputStream(excelFileName)));
		HSSFSheet mySheet = myWorkBook.getSheetAt(0);
		Iterator rowIter = mySheet.rowIterator();
		String csvData = "";
		while (rowIter.hasNext()) {
			HSSFRow myRow = (HSSFRow) rowIter.next();
			for (int i = 0; i < myRow.getLastCellNum(); i++) {
				csvData += getCellData(myRow.getCell(i));
			}
			csvData += NEW_LINE_CHARACTER;
		}
		writeCSV(csvFileName, csvData);
		System.out.println("Successfully written from xsl to csv");
	}

	private static void writeCSV(String csvFileName, String csvData) throws Exception {
		FileOutputStream writer = new FileOutputStream(csvFileName);
		writer.write(csvData.getBytes());
		writer.close();
	}

	public static String getCellData(HSSFCell myCell) throws Exception {
		String cellData = "";
		if (myCell == null) {
			cellData += CVS_SEPERATOR_CHAR;
			;
		} else {
			switch (myCell.getCellType()) {
			case HSSFCell.CELL_TYPE_STRING:
			case HSSFCell.CELL_TYPE_BOOLEAN:
				cellData += myCell.getRichStringCellValue() + CVS_SEPERATOR_CHAR;
				break;
			case HSSFCell.CELL_TYPE_NUMERIC:
				cellData += getNumericValue(myCell);
				break;
			case HSSFCell.CELL_TYPE_FORMULA:
				cellData += getFormulaValue(myCell);
			default:
				cellData += CVS_SEPERATOR_CHAR;
				;
			}
		}
		return cellData;
	}

	public static String getFormulaValue(HSSFCell myCell) throws Exception {
		String cellData = "";
		if (myCell.getCachedFormulaResultType() == HSSFCell.CELL_TYPE_STRING
				|| myCell.getCellType() == HSSFCell.CELL_TYPE_BOOLEAN) {
			cellData += myCell.getRichStringCellValue() + CVS_SEPERATOR_CHAR;
		} else if (myCell.getCachedFormulaResultType() == HSSFCell.CELL_TYPE_NUMERIC) {
			cellData += getNumericValue(myCell) + CVS_SEPERATOR_CHAR;
		}
		return cellData;
	}

	public static void checkValidFile(String fileName) {
		boolean valid = true;
		try {
			File f = new File(fileName);
			if (!f.exists() || f.isDirectory()) {
				valid = false;
			}
		} catch (Exception e) {
			valid = false;
		}
		if (!valid) {
			System.out.println("File doesn't exist: " + fileName);
			System.exit(0);
		}
	}

	public static String getNumericValue(HSSFCell myCell) throws Exception {
		String cellData = "";
		if (HSSFDateUtil.isCellDateFormatted(myCell)) {
			cellData += new SimpleDateFormat(OUTPUT_DATE_FORMAT).format(myCell.getDateCellValue()) + CVS_SEPERATOR_CHAR;
		} else {
			cellData += new BigDecimal(myCell.getNumericCellValue()).toString() + CVS_SEPERATOR_CHAR;
		}
		return cellData;
	}

	public static void convertXSLToCSV(String filename) throws Exception {
		File dirFile = new File(System.getProperty("user.dir"), "ScoresImportExport");
		String file1 = dirFile.getAbsolutePath() + File.separator + "CleverXSL" + File.separator + filename+".xls";
		String file2 = dirFile.getAbsolutePath() + File.separator + "CleverCSV" + File.separator + filename+".csv";
		excelToCSV(file1, file2);
	}
	
	public static void convertAllFilesToCSVForm(String file1,String file2, String file3,String file4,String file5,String file6) throws Exception {
		convertXSLToCSV(file1);
		convertXSLToCSV(file2);
		convertXSLToCSV(file3);
		convertXSLToCSV(file4);
		convertXSLToCSV(file5);
		convertXSLToCSV(file6);
	}
	

}