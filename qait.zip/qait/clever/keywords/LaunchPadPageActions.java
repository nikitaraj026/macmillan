package com.qait.clever.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class LaunchPadPageActions extends GetPage{
	
	public LaunchPadPageActions(WebDriver driver) {
		super(driver, "LaunchPadPage");
	}

	public void VerifyIfUserIsTakenToLPCourseHomePage() {
		waitForPageToLoadCompletely(getPageTitle());
		if(getPageTitle().equals("Macmillan Launchpad: Login") )
		{
			logMessage("SSO not successful. Instructor is on LP login page");
			customAssert.customAssertEquals(getPageTitle().contains("Home"), true, "[Assertion failed]: User is on LP login page");
		}
		
		else if(getElementCount("txt_noAssignments") > 0)
		{
			logMessage("Instructor is redirected to LP Course Homepage");
		}
		
		else if(getElementCount("btn_enterYourCourse") > 0)
		{
			logMessage("Instructor is on LP Course Welcome page");
		}
	}
}
