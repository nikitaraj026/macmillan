package com.qait.clever.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class HomePageActions extends GetPage{
	public HomePageActions(WebDriver driver) {
		super(driver, "HomePage");
	}
	
	/***************************
	 * 1. BASIC OPERATIONS a. Verifications
	 ***************************/
	public void verifyMenuToggleButtonDisplayed() {
		isElementDisplayed("toggle_Menu");
		logMessage("Toggle menu is displayed");
	}
	
	public void verifyLeftPanelNavigationMenuDisplayed(List <String> menu) {
		
	}
	
	public void verifyLoggedinUserNameDisplayed(String userName) {
		isElementDisplayed("txt_userName");
		String actualUserName = element("txt_userName").getText();
		customAssert.customAssertEquals(actualUserName.equalsIgnoreCase(userName), true, "[Assertion Failed]: User name is not displayed");
		logMessage("Loggedin user name is displayed: " + actualUserName);
	}
	
	public void verifyYourDistrictTabDisplayed() {
		isElementDisplayed("lnk_tab_yourDistricts");
		logMessage("Your District tab is displayed");
	}
	
	public void verifyPendingRequestTabDisplayed() {
		isElementDisplayed("lnk_tab_pendingRequest");
		logMessage("Pending Request tab is displayed");
	}
	
	public void verifyInvitedDistrictsTabdisplayed() {
		isElementDisplayed("lnk_tab_invitedDistricts");
		logMessage("Invited Disctrict tab is displayed");
	}
	
	public void verifyCleverHomePage(String userName) {
		verifyMenuToggleButtonDisplayed();
		
		verifyLoggedinUserNameDisplayed(userName);
		verifyYourDistrictTabDisplayed();
		verifyPendingRequestTabDisplayed();
		verifyInvitedDistrictsTabdisplayed();
	}
	
	public void clickOnLeftPanelMenu(String menuName) {
		waitAndClick("lnk_leftPanelMenu", menuName);
		logMessage("Clicked on " + menuName + " link");
	}
	
}
