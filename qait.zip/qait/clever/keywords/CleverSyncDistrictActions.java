package com.qait.clever.keywords;

import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qait.automation.getpageobjects.GetPage;

public class CleverSyncDistrictActions extends GetPage {

	public CleverSyncDistrictActions(WebDriver driver) {
		super(driver, "SyncDistrictPage");
	}

	public void verifyHomePage() {
		String headerTabs[] = { "Admin Dashboard", "Admin tools", "DB Query", "Config", "Clever Districts",
				"Grade Refresh", "Error Email Filter", "phpinfo" };
		for (int i = 0; i < headerTabs.length; i++) {
			isElementDisplayed("header_Options", headerTabs[i]);
		}
	}

	public void chooseOptionFromInstallationDrpdwn(String option) {

		waitForElementToBeVisible("drpdwn_Installation");
		isElementDisplayed("drpdwn_Installation");
		waitAndClick("drpdwn_Installation");

		waitForElementToBeVisible("option_Installation", option);
		isElementDisplayed("option_Installation", option);
		waitAndClick("option_Installation", option);
	}

	public void clickSyncDistrict() {
		waitForElementToBeVisible("btn_SyncDistr");
		isElementDisplayed("btn_SyncDistr");
		waitAndClick("btn_SyncDistr");
		hardWait(5);
		handleAlert();

	}

	public void verifyCleverSyncRunningAndGotSuccessful() {
		waitForElementToBeVisible("txt_StillRunn");
		isElementDisplayed("txt_StillRunn");
		logMessage("Sync is in Running State");
		waitForElementToBeVisible("txt_SuccessSync");
		assertTrue(element("txt_SuccessSync").isDisplayed());
	}

	public String getSaplingCourseTitle() {
		return element("sapling_Course").getText();
	}

}
