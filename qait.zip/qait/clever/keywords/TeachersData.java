package com.qait.clever.keywords;

public class TeachersData {

	public String fname1, fname2, fname3, fname4;
	public String lname1, lname2, lname3, lname4;
	public String email1, email2, email3, email4;
	public int schoolID;

	public void setTeacherFname1(String fname1) {
		this.fname1 = fname1;
	}

	public void setTeacherFname2(String fname2) {
		this.fname2 = fname2;
	}

	public void setTeacherFname3(String fname3) {
		this.fname3 = fname3;
	}

	public void setTeacherFname4(String fname4) {
		this.fname4 = fname4;
	}

	public void setTeacherLname1(String lname1) {
		this.lname1 = lname1;
	}

	public void setTeacherLname2(String lname2) {
		this.lname2 = lname2;
	}

	public void setTeacherLname3(String lname3) {
		this.lname3 = lname3;
	}

	public void setTeacherLname4(String lname4) {
		this.lname4 = lname4;
	}

	public void setTeacherEmail1(String email1) {
		this.email1 = email1;
	}

	public void setTeacherEmail2(String email2) {
		this.email2 = email2;
	}

	public void setTeacherEmail3(String email3) {
		this.email3 = email3;
	}

	public void setTeacherEmail4(String email4) {
		this.email4 = email4;
	}

	public void setSchoolID(int schoolID) {
		this.schoolID = schoolID;
	}

}