package com.qait.clever.keywords;

import static org.testng.Assert.assertTrue;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class CleverHomePageActions extends GetPage {

	public CleverHomePageActions(WebDriver driver) {
		super(driver, "CleverHomePage");
	}

	public void verifyHeaderItems() {
		String headerItems[] = { "Dashboard", "Portal", "Community", "Help Center", "Profile", "Log out" };
		for (int i = 0; i < headerItems.length; i++) {
			isElementDisplayed("item_Header", headerItems[i]);
		}
		logMessage("All header items has been verified");
	}

	public void verifyMenuItems() {
		String menuOptions[] = { "Menu", "Home", "Clever Academy", "Applications", "Portal", "Analytics", "Badges",
				"Support Tools", "Sync", "Team" };

		for (int i = 0; i < menuOptions.length; i++) {
			isElementDisplayed("item_Menu", menuOptions[i]);
		}
		logMessage("All menu options has been verified");

	}

	public void verifyHomePage() {
		verifyHeaderItems();
		isElementDisplayed("inpt_Search");
		logMessage("Input Search Element has been verified");
		verifyMenuItems();
	}

	public void clickMenuItem(String itemName) {

		waitForElementToBeVisible("item_Menu", itemName);
		waitAndClick("item_Menu", itemName);
		logMessage("Clicked on " + itemName + " from Menu options");
	}

	public void clickOnTab(String tabName) {
		waitForElementToBeVisible("tab_toolbar", tabName);
		isElementDisplayed("tab_toolbar", tabName);
		waitAndClick("tab_toolbar", tabName);

	}

	public void verifyUploadSheetButtonsDisplayed() {

		String sheetNames[] = { "schools", "teachers", "students", "staff", "sections", "enrollments" };
		for (int i = 0; i < sheetNames.length; i++) {
			isElementDisplayed("btn_SheetUpload", sheetNames[i]);
		}
		logMessage("Upload Sheet buttons are displayed");

	}

	public void uploadFile(String nameOfFile, String locatorName) {

		File dirFile = new File(System.getProperty("user.dir"), "ScoresImportExport");
		File files[] = dirFile.listFiles();

		System.out.println(dirFile.getAbsolutePath() + File.separator + nameOfFile);
		waitForElementToBeVisible(locatorName);
		WebElement upload = (element(locatorName));
//		waitForElementToBeClickable(element("btn_SheetUpload"));
		upload.sendKeys(dirFile.getAbsolutePath() + File.separator + "CleverCSV" + File.separator + nameOfFile);
		System.out.println("selected file " + nameOfFile + " from the location");
	}

	public void uploadAllFiles() {
//		uploadFile("schools.csv", "btn_SchoolsUpload");
		uploadFile("students.csv", "btn_StudentsUpload");
		uploadFile("teachers.csv", "btn_TeachersUpload");
		uploadFile("sections.csv", "btn_SectionsUpload");
		uploadFile("enrollments.csv", "btn_EnrollmentsUpload");
//		uploadFile("admins.csv", "btn_StaffUpload");
		hardWait(8);

	}

	public void clickUploadButton() {
		waitAndScrollToElement("btn_Upload");
		waitForElementToBeClickable(element("btn_Upload"));
		waitAndClick("btn_Upload");

	}

}