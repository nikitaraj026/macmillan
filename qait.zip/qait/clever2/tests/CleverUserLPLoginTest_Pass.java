package com.qait.clever2.tests;

import com.qait.automation.Clever2TestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import org.testng.annotations.*;

import java.lang.reflect.Method;

import static com.qait.automation.utils.YamlReader.getData;

public class CleverUserLPLoginTest_Pass extends Parent_Test{
	Clever2TestSessionInitiator clever;
	
	String baseURL;
	String userName, userEmail, userPassword;
	String districtName;
	String teacherEmail;
	
	private void initVars() {
		baseURL = getData("baseUrl");
		userName = getData("userName");
		userEmail = getData("userEmail");
		userPassword = getData("userPassword");
		districtName = getData("districtName2");
		teacherEmail = getData("user.email2");
	}
	
	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID, @Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void start_test_Session() {
		clever = new Clever2TestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		clever.stepStartMessage(method.getName()); 
	}

	@Test
	public void LaunchCleverApplication() {
		clever.launchApplication(baseURL);
	}
	
	@Test(dependsOnMethods = "LaunchCleverApplication")
	public void VerifyCleverHomePageAndLogin() {
		clever.loginPage.verifyCleverLoginPage();
		clever.loginPage.enterUserEmail(userEmail);
		clever.loginPage.enterUserPassword(userPassword);
		clever.loginPage.clickLoginButton();
		clever.homePage.verifyCleverHomePage(userName);
	}
	
	@Test(dependsOnMethods="VerifyCleverHomePageAndLogin", alwaysRun = true)
	public void UserNavigateToDataBowseTabAndClickTeacherTab() {
		clever.homePage.clickOnLeftPanelMenu("Data Browser");
		clever.dataBrowsePage.verifyDataBrowsepage();
		clever.dataBrowsePage.clickOnTabOnDataBrowsePage("teachers");
	}
	
	@Test(dependsOnMethods="UserNavigateToDataBowseTabAndClickTeacherTab", alwaysRun = true)
	public void UserSelectDistrictAndClickOnUserEmail() {
		clever.dataBrowsePage.enterDistrictNameAndSelect(districtName);
		clever.dataBrowsePage.verifyFilterOptionForDistrict(districtName);
		clever.dataBrowsePage.clickOnUserEmail(teacherEmail);
	}
	
	@Test(dependsOnMethods="UserSelectDistrictAndClickOnUserEmail", alwaysRun=true)
	public void VerifyDetailPageAndNavigateToLoginWithCleverPage() {
		clever.dataBrowsePage.verifyDetailViewWindowDisplayed();
		clever.dataBrowsePage.clickOnLoginAsUserName();
	}
	
	@Test(dependsOnMethods="VerifyDetailPageAndNavigateToLoginWithCleverPage", alwaysRun=true)
	public void VerifyChooseCoursePage() {
		clever.chooseCoursePage.verifyUserIsOnChooseCoursePage();
		clever.chooseCoursePage.clickOnCourseNameLink("Myers, Psychology for AP, 2e");
	}
	
	@Test(dependsOnMethods="VerifyChooseCoursePage", alwaysRun=true)
	public void VerifyIfInstructorIsSSOdIntoTheCourse() {
		clever.LaunchPadPage.VerifyIfUserIsTakenToLPCourseHomePage();
		
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		clever.closeBrowserSession();
	}
}
