package com.qait.clever2.keywords;

import com.qait.automation.getpageobjects.GetPage;
import org.openqa.selenium.WebDriver;

public class ChooseCoursePageActions extends GetPage{
	
	public ChooseCoursePageActions(WebDriver driver) {
		super(driver, "ChooseCoursePage");
	}

	public void verifyUserIsOnChooseCoursePage()
	{
		isElementDisplayed("logo_bfw");
		logMessage("User is on Choose Course page");
	}
	
	public void clickOnCourseNameLink(String courseName)
	{
		waitScrollAndClick("lnk_courseName", courseName);
		logMessage("User has clicked on the course name link on Choose Course page");
	}
}
