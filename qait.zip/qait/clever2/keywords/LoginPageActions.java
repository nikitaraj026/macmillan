package com.qait.clever2.keywords;

import com.qait.automation.getpageobjects.GetPage;
import org.openqa.selenium.WebDriver;

public class LoginPageActions extends GetPage{

	public LoginPageActions(WebDriver driver) {
		super(driver, "LoginPage");
	}
	
	/***************************
	 * 1. BASIC OPERATIONS a. Verifications
	 ***************************/
	
	public void verifyLoginTextDisplayed() {
		isElementDisplayed("txt_login");
		logMessage("Login text is displayed");
	}
	
	public void verifyEmailTextboxDisplayed() {
		isElementDisplayed("input_email");
		logMessage("Email textbox is displayed");
	}
	
	public void verifyPasswordTextboxDisplayed() {
		isElementDisplayed("input_password");
		logMessage("Password textbox is displayed");
	}
	
	
	public void verifyForgotYourPasswordLinkDisplayed() {
		isElementDisplayed("lnk_forgotPassword");
		logMessage("Forgot your passoword link is displayed");
	}
	
	public void verifyLoginButtonDisplayed() {
		isElementDisplayed("btn_login");
		logMessage("Login button is displayed");
	}
	
	public void verifyCleverLoginPage() {
		verifyLoginTextDisplayed();
		verifyEmailTextboxDisplayed();
		verifyPasswordTextboxDisplayed();
		verifyForgotYourPasswordLinkDisplayed();
		verifyLoginButtonDisplayed();
	}
	
	public void enterUserEmail(String email) {
		fillText("input_email", email);
		logMessage("Filled " + email + " in the email field");
	}
	
	public void enterUserPassword(String password) {
		fillText("input_password", password);
		logMessage("Filled password");
	}
	
	public void clickLoginButton() {
		waitAndClick("btn_login");
		logMessage("Click on Login button");
	}
}

