package com.qait.BQT.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class CourseHomePageActions extends GetPage {

	public CourseHomePageActions(WebDriver driver) {
		super(driver, "CourseHomePage");
	}
	
	/**
	 * Verifies that Course Name at Top is correct
	 */
	public void verifyCourseName(String courseName) {
		verifyTextOfElementIsCorrect("txt_courseNameTitle", courseName);
		clickElementIfVisible("btn_closeToastMessage");
	}

	public void createAssignment(String assignmentType) {
		clickAddNewLink();
		clickOnAssignment(assignmentType);
	}

	public void clickOnAssignment(String assignmentType) {
		element("link_assignmentType", assignmentType).click();
		logMessage("Clicked on "+assignmentType);
	}

	public void clickAddNewLink() {
		element("lnk_addNew").click();
		logMessage("Clicked on Add New link");
	}
	
	/**
	 * Click TOC Item
	 */
	public void clickTOCItem(String linkName) {
		isElementDisplayed("link_itemTOC", linkName);
		waitScrollAndClick("link_itemTOC", linkName);
		logMessage("Clicked TOC Item '" + linkName + "'");
		waitForLoaderToDisappear();
	}
	
	/**
	 * Method which clicks on 'Show/Hide past Due' Link
	 * 
	 */
	public void clickOnShowOrHidePastDueLink(){
		scrollDown(element("lnk_hideOrshowPastDue"));
		element("lnk_hideOrshowPastDue").click();
		logMessage("Clicked on 'Show/Hide past Due' Link");
	}
}
