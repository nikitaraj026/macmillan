package com.qait.BQT.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class DashboardPageActions extends GetPage{
	
	public DashboardPageActions(WebDriver driver) {
		super(driver, "DashboardPage");
	}
	
	public void verifyUserIsOnDashboardPage() {
		clickElementIfVisible("btn_closeToastMessage");
		waitForLoaderToDisappear();
		isElementDisplayed("txt_myCoursesTitle");
		hardWait(1);
	}
	
	public void createCourseNotBasedOnExistingCourse() {
		clickCreateCourseLink();
		clickCreateCourseNoRadioButton();
		clickCreateCourseNextButton();
	}
	
	public void clickCreateCourseLink() {
		wait.waitForLoaderToAppearAndDisappear();
		waitForElementToBeVisible("link_createCourse");
		scrollDown(element("link_createCourse"));
		executeJavascript("document.getElementById('createcourseoption').click()");
		logMessage("Clicked Create Course Link");
		waitForElementToBeVisible("div_confirmProductMessage");
		waitForElementToBeVisible("btn_NextConfirmCourse");
		element("btn_NextConfirmCourse").click();
		logMessage("Clicked on next button to confirm correct course");
	}
	
	/**
	 * Click Create Course Widget 'No' Radio Button
	 */
	public void clickCreateCourseNoRadioButton() {
		element("radiobtn_noCreateCourse").click();
		logMessage("Clicked Create Course 'No' Radio Button");
	}

	/**
	 * Click Create Course Widget 'Next' Button
	 */
	public void clickCreateCourseNextButton() {
		element("btn_nextCreateCourse").click();
		logMessage("Clicked Create Course 'Next' Button");
	}
	
	/**
	 * Create Course Widget : Fill Course Name and other details and click Create
	 */
	public String createCourse(String courseTitle, String courseNumber, String sectionNumber,
			String instructorName, String schoolName, String academicTerm) {
		if (!courseTitle.equals("")) fillCreateCourseWidgetCourseTitle(courseTitle);
		if (!courseNumber.equals("")) fillCreateCourseWidgetCourseNumber(courseNumber);
		if (!sectionNumber.equals("")) fillCreateCourseWidgetSectionNumber(sectionNumber);
		if (!instructorName.equals("")) fillCreateCourseWidgetInstructorName(instructorName);
		if (!schoolName.equals("")) {
			/*fillCreateCourseWidgetSchoolName(schoolName);
			selectCreateCourseWidgetSchoolName(schoolName);*/
			waitForElementToBeVisible("txtinput_schoolNameCreateCourse");
			sendKeys(element("txtinput_schoolNameCreateCourse"), schoolName);
			hardWait(1);
			element("txtinput_schoolNameCreateCourse").click();
			waitAndClick("dropdown_schoolNameCreateCourse", schoolName);			
			
		}
		String timeZone = element("txt_selectedTimeZone").getText();
		hardWait(1);
		if (!academicTerm.equals("")) selectCreateCourseWidgetAcademicTerm(academicTerm);
		clickCreateCourseCreateButton();
		return timeZone;
	}
	
	/**
	 * Fill Course Title in Create Course Widget
	 */
	public void fillCreateCourseWidgetCourseTitle(String courseTitle) {
		fillText("txtinput_courseTitleCreateCourse", courseTitle);
	}
	
	/**
	 * Fill Course Number in Create Course Widget
	 */
	public void fillCreateCourseWidgetCourseNumber(String courseNumber) {
		fillText("txtinput_courseNumberCreateCourse", courseNumber);
	}
	
	/**
	 * Fill Section Number in Create Course Widget
	 */
	public void fillCreateCourseWidgetSectionNumber(String sectionNumber) {
		fillText("txtinput_sectionNumberCreateCourse", sectionNumber);
	}
	
	/**
	 * Fill Instructor Name in Create Course Widget
	 */
	public void fillCreateCourseWidgetInstructorName(String instructorName) {
		fillText("txtinput_instructorNameCreateCourse", instructorName);
	}
	
	/**
	 * Fill School Name in Create Course Widget
	 */
	public void fillCreateCourseWidgetSchoolName(String schoolName) {
		waitForElementToBeVisible("txtinput_schoolNameCreateCourse");
		sendKeys(element("txtinput_schoolNameCreateCourse"), schoolName);
		element("txtinput_schoolNameCreateCourse").click();
		waitAndClick("dropdown_schoolNameCreateCourse", schoolName);	
	}
	
	/**
	 * Select Academic term in Create Course Widget
	 */
	public void selectCreateCourseWidgetAcademicTerm(String academicTerm) {
		selectProvidedTextFromDropDown(element("dropdown_academicTermCreateCourse"), academicTerm);
	}
	
	/**
	 * Click Create Course Widget 'Create' Button
	 */
	public void clickCreateCourseCreateButton() {
		scrollDown(element("btn_createCreateCourse"));
		element("btn_createCreateCourse").click();
		logMessage("Clicked Create Course 'Create' Button");
	}
	
	/**
	 * Verifies that Course Name Link is displayed
	 */
	public void verifyCourseNameLinkDisplayed(String courseName) {
		isElementDisplayed("link_courseName", courseName);
	}
	
	/**
	 * Returns the Course Url of the specified Course Name
	 */
	public String getCourseUrl(String courseName) {
		return element("txt_courseUrl", courseName).getText().trim();
	}

	/**
	 * Activates a provided course name 
	 */
	public void activateCourse(String courseName) {
		clickCourseActivateLink(courseName);
		//verifyActivateCourseWidgetDisplayed();
		clickActivateCourseActivateButton();
		clickActivateCourseDoneButton();
	}
	
	/**
	 * Click Course Activate Link
	 */
	public void clickCourseActivateLink(String courseName) {
		waitScrollAndClick("link_courseActivate", courseName);
		logMessage("Clicked Course '" + courseName + "' Activate Link");
	}
	
	/**
	 * Click Activate Course Widget 'Activate' Button
	 */
	public void clickActivateCourseActivateButton() {
		waitForElementToBeVisible("btn_activateActivateCourse");
		element("btn_activateActivateCourse").click();
		logMessage("Clicked Activate Course 'Activate' Button");
		hardWait(1);
	}

	/**
	 * Click Activate Course Widget 'Done' Button
	 */
	public void clickActivateCourseDoneButton() {
		waitForLoaderToDisappear();
		hardWait(2);
		waitForElementToBeVisible("btn_doneActivateCourse");
		element("btn_doneActivateCourse").click();
		waitForElementToDisappear("btn_doneActivateCourse");
		logMessage("Clicked Activate Course 'Done' Button");
	}
	
	/**
	 * Click Course Name Link
	 */
	public void clickCourseNameLink(String courseName) {
		waitScrollAndClick("link_courseName", courseName);
		logMessage("Clicked Course '" + courseName + "' Link");
	}
}
