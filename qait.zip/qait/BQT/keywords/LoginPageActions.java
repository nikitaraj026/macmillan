package com.qait.BQT.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class LoginPageActions extends GetPage {

	public LoginPageActions(WebDriver driver) {
		super(driver, "LoginPage");
	}
	
	public void verifyUserIsOnLoginPage() {
		waitForLoaderToDisappear();
		clickElementIfVisible("btn_closeToastMessage");
		isElementDisplayed("txt_signIn");
	}
	
	public void login(String email, String password) {
		waitForLoaderToDisappear();
		element("txtinput_email").clear();
		element("txtinput_email").sendKeys(email);
		logMessage("User enters "+email+" in email field");
		element("txtinput_password").sendKeys(password);
		logMessage("User enters "+password+" in password field");
		waitForLoaderToDisappear();
		scrollDown(element("btn_signIn"));
		element("btn_signIn").click();
		logMessage("Clicked 'Sign in' Button");
	}
}
