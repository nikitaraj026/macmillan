package com.qait.BQT.keywords;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class EnrollPageActions extends GetPage{

	public EnrollPageActions(WebDriver driver) {
		super(driver, "EnrollPage");
	}
	
	public void verifyUserIsOnEnrollPage(){
		switchToDefaultContent();
		isElementDisplayed("iframe_joinCourse");
	}
	
	public void clickJoinCourseButton() {
		verifyUserIsOnEnrollPage();
		switchToMainFrame();
		waitForElementToBeVisible("btn_joinCourse");
		switchToDefaultContent();
		hardWait(2);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementsByClassName('mars-widget')[0].getElementsByTagName('iframe')[0]"
								+ ".contentDocument.getElementById('join-course-confirmation').click();");
		hardWait(1);
		waitForLoaderToDisappear();	
		hardWait(3);
	}
	
	public void switchToMainFrame() {
		switchToDefaultContent();
		switchToFrame(element("iframe_joinCourse"));
	}
	
	public void clickContinueAfterJoiningCourse(){
		verifyUserIsOnEnrollPage();
		switchToMainFrame();
		waitForElementToBeVisible("btn_continue");
		switchToDefaultContent();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementsByClassName('mars-widget')[0].getElementsByTagName('iframe')[0]"
				+ ".contentDocument.getElementsByClassName('course-continue')[0].click();");
		hardWait(2);
		switchToDefaultContent();
	}
}
