package com.qait.BQT.keywords;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;

public class FandEPageActions extends GetPage {

	String questionCheckBoxCss = ".questions>li:nth-child(%) input[type=checkbox]";

	public FandEPageActions(WebDriver driver) {
		super(driver, "FandEPage");
	}

	public void fillBasicInfo(String assignmentName) {
		element("inp_title").clear();
		element("inp_title").sendKeys(assignmentName);
		logMessage("User enters " + assignmentName + " in Title");
	}

	public void clickOnSaveButton() {
		element("btn_save").click();
		logMessage("Clicked on Save button");
		waitForMsgToastToAppearAndDisappear();
	}

	// Clicks 'Assignment' Tab
	public void clickAssignmentTab() {
		waitForElementToBeVisible("btn_assignmentTab");
		element("btn_assignmentTab").click();
		waitForLoaderToDisappear();
		logMessage("User clicked on Assignment Tab");
		waitForElementToBeVisible("txt_dueDateAndTime");
	}

	public void clickOnQuestionsTab() {
		waitForMsgToastToDisappear();
		element("btn_questions").click();
		logMessage("Clicked on Questions Tab");
		waitForLoaderToDisappear();
	}
	
	public void clickOnSettingsTab() {
		waitForElementToBeVisible("btn_settingsTab");
		element("btn_settingsTab").click();
		waitForLoaderToDisappear();
		logMessage("User clicked on Settings Tab");
	}
	
	public void uncheckRandomizeAnswerOrderCheckbox() {
		element("chkbox_randomizeAnswer").click();
		logMessage("Clicked on Randomize Answer order checkbox");
	}

	// Clicks on 'Done Editing' Button
	public void clickOnDoneButton() {
		switchToDefaultContent();
		waitForLoaderToDisappear();
		waitAndClick("btn_doneEditing");
		handleAlert();
		logMessage("User Clicked on Done Editing button");
		waitForLoaderToDisappear();
	}

	/**
	 * Clicks on 'Home' Button at the top-left of FandE Page
	 * 
	 */
	public void clickOnHomeButton() {
		switchToDefaultContent();
		waitForLoaderToDisappear();
		waitAndClick("btn_home");
		logMessage("User Clicked on Home button");
		waitForLoaderToDisappear();
		waitForElementToDisappear("btn_home");
	}

	/**************************************
	 * Questions Tab
	 ************************************************/
	public void addQuestionsToAssignment(String chapterName) {
		clickOnQuestionsTab();
		clickChapterOneFromQuestionBank(chapterName);
		clickExcerciseFromChapterOne();
		checkFirstQuestionFromQuestionsAvailable();
		clickAddButtonInQuestions();
		verifyQuestionAddedToAssignment();
	}

	public String[] getCorrectAnswer() {
		element("link_previewAddedQuestion").click();
		logMessage("Clicked on Preview link");
		String[] responses = new String[4];
		int i = 0;
		switchToFrame(element("iframe_questionPreview"));
		for (WebElement e : elements("list_correctResponses")) {
			logMessage(e.getText());
			responses[i] = e.getText();
			i++;
		}
		switchToDefaultContent();
		element("btn_close").click();
		logMessage("Clicked on Close icon");
		return responses;
	}
	
	public String getCorrectAnswerForQuiz() {
		element("link_previewAddedQuestion").click();
		logMessage("Clicked on Preview link");
		int i =1;
		for(WebElement e : elements("list_responsesForQuiz")){
			System.out.println("Attribute checked = "+e.getAttribute("checked"));
			if(e.isSelected()){
				System.out.println("Attribute checked = "+e.getAttribute("checked"));
				break;
			}
			else
				i++;
		}
		element("btn_close").click();
		logMessage("Clicked on Close icon");
		return i+"";
	}

	// Selects 'Chapter 1' Link from list of Question Bank(under Questions Tab)
	public void clickChapterOneFromQuestionBank(String chapterNumber) {
		waitForElementToBeVisible("btn_chapter1QuestionBank", chapterNumber);
		element("btn_chapter1QuestionBank", chapterNumber).click();
		logMessage("Instrutor clicks on " + chapterNumber + " from Question Bank");
		waitForLoaderToDisappear();
	}

	// Selects 'Test Bank 1' link from 'Chapter 1'(under Questions Tab)
	public void clickTestBankOneFromChapterOne() {
		waitForElementToBeVisible("btn_testBank1Chapter1", "Test Bank");
		//element("btn_testBank1Chapter1", selectQuestionFrom).click();
		executeJavascript("document.getElementsByClassName('level quiz-item available')[1].getElementsByTagName('a')[0].click();");
		logMessage("Instrutor clicks on Test Bank from Chapter 1");
		waitForLoaderToDisappear();
	}

	// Selects 'Test Bank 1' link from 'Chapter 1'(under Questions Tab)
			public void clickExcerciseFromChapterOne() {
				waitForLoaderToDisappear();
				waitForElementToBeVisible("btn_testBank1Chapter1", "Exercises");
				//element("btn_testBank1Chapter1", "Test Bank").click();
				executeJavascript("document.getElementsByClassName('level quiz-item available')[0].getElementsByTagName('a')[0].click();");
				logMessage("Instrutor clicks on Exercise from Chapter 1");
				waitForLoaderToDisappear();
			}

	/**
	 * Clicks 'Add' Button to add selected Questions for Quiz(under Questions
	 * Tab)
	 * 
	 */
	public void clickAddButtonInQuestions() {
		waitForElementToBeVisible("drpdown_selectMenu");
		waitForElementToBeVisible("btn_add");
		element("btn_add").click();
		logMessage("User clicks on 'Add' button to add the question to Assignment");
		waitForLoaderToDisappear();
	}

	/**
	 * Selects First Question Checkbox from the Questions List available(under
	 * Questions Tab)
	 * 
	 */
	public void checkFirstQuestionFromQuestionsAvailable() {
		waitForElementToBeVisible("drpdown_selectMenu");
		element("drpdown_selectMenu").isDisplayed();
		WebElement elem = driver.findElement(By.cssSelector(questionCheckBoxCss.replaceAll("%", String.valueOf(4))));
		scrollDown(elem);
		elem.click();
		logMessage("1st question is selected from all the available questions");
	}
	
	public void checkQuestionForQuizFromQuestionsAvailable(String questionNumber) {
		waitForElementToBeVisible("drpdown_selectMenu");
		element("drpdown_selectMenu").isDisplayed();
		hardWait(2);
		WebElement elem = driver.findElement(By.cssSelector(questionCheckBoxCss.replaceAll("%", questionNumber)));
		scrollDown(elem);
		scrollDownPX(elem);
		elem.click();
		logMessage("1st question is selected from all the available questions");
	}

	public void verifyQuestionAddedToAssignment() {
		isElementDisplayed("link_previewForAddedQuestion");
		logMessage("Assertion Passed : Question Added to Question pool");
	}

	/************************************************
	 * Assign Tab
	 ****************************************/

	public void assignTheAssignment(String assignmentScore, String date) {
		clickAssignmentTab();
		selectDateInDatePicker(date);
		fillGradePointsForAssignment(assignmentScore);
		clickAssignButtonFromAssignmentTab();
	}

	public void assignTheAssignmentInPastDate(String assignmentScore, String date, String periodDuration,
			String durationType) {
		clickAssignmentTab();
		selectPastDateInDatePicker(date);
		fillGradePointsForAssignment(assignmentScore);
		assignGracePeriod(periodDuration, durationType);
		clickAssignButtonFromAssignmentTab();
	}
	
	public void assignTheAssignmentWithFullCreditOnCompletion(String assignmentScore, String date) {
		clickAssignmentTab();
		selectDateInDatePicker(date);
		fillGradePointsForAssignment(assignmentScore);
		changeCalculationType();
		clickAssignButtonFromAssignmentTab();
	}
	
	public void assignTheAssignmentInNewCategory(String assignmentScore, String date) {
		clickAssignmentTab();
		selectDateInDatePicker(date);
		fillGradePointsForAssignment(assignmentScore);
		createNewCategory();
		clickAssignButtonFromAssignmentTab();
	}

	public void createNewCategory() {
		selectProvidedTextFromDropDown(element("drpdwn_category"), "Create new category");
		wait.waitForLoaderToDisappear();
		element("inp_categoryName").sendKeys("New Category");
		element("btn_addCategory").click();
		logMessage("Clicked on Add button to add a new category");
	}

	public void changeCalculationType() {
		selectByValueFromDropDown(element("drpdown_calculationType"), "Full_Credit");
	}

	public void assignGracePeriod(String periodDuration, String durationType) {
		element("chkbox_allowLateSubmissions").click();
		logMessage("Instructor selects Allow Late Submissions Checkbox");
		waitForElementToBeVisible("txtinput_gracePeriodDuration");
		element("txtinput_gracePeriodDuration").clear();
		element("txtinput_gracePeriodDuration").sendKeys(periodDuration);
		selectProvidedTextFromDropDown(element("drpdown_gracePeriodDurationType"), durationType);
		logMessage("Instructor enters the Grace Period for Late submission of Assignment");
	}

	/**
	 * Chooses the specified date from next month
	 */
	public void selectDateInDatePicker(String date) {
		waitForElementToBeVisible("datePicker_goNext");
		element("datePicker_goNext").click();
		waitForElementToBeVisible("datePicker_date", date);
		element("datePicker_date", date).click();
		logMessage("Date selected from Calendar: " + date);
	}

	/**
	 * Chooses the specified date from previous month
	 */
	public void selectPastDateInDatePicker(String date) {
		waitForElementToBeVisible("datePicker_goPrev");
		element("datePicker_goPrev").click();
		waitForElementToBeVisible("datePicker_date", date);
		element("datePicker_date", date).click();
		logMessage("Date selected from Calendar: " + date);
	}

	/**
	 * Fills Grade Points input field(in Assignment Tab)
	 * 
	 * @param gradePoints
	 */
	public void fillGradePointsForAssignment(String gradePoints) {
		waitForElementToBeVisible("txtinput_gradePoints");
		fillText("txtinput_gradePoints", gradePoints);
	}

	// Clicks 'Assign' Button(in Assignment Tab)
	public void clickAssignButtonFromAssignmentTab() {
		waitForElementToBeVisible("btn_assignInAssignmentTab");
		element("btn_assignInAssignmentTab").click();
		handleAlert();
		waitForLoaderToDisappear();
		hardWait(2);// wait till unassign button appeared
		logMessage("Clicked 'Assign' Button from Assignment Settings");
		waitForElementToBeVisible("btn_unassignInAssignmentTab");
		waitForMsgToastToDisappear();
	}

	/*****************************************
	 * Student FandE Page
	 *********************************/

	/**
	 * Verify Student is on FandE page
	 * 
	 */
	public void verifyStudentIsOnHomeworkStartPage() {
		waitForElementToBeVisible("btn_startTheHomework");
		element("btn_startTheHomework").isDisplayed();
		// element("txt_achievedPoints").isDisplayed();
		element("txt_fneTitle").isDisplayed();
		element("heading_policies").isDisplayed();
		logMessage("Verified that Student is on FandE page");
	}
	
	public void verifyStudentIsOnQuizStartPage() {
		waitForElementToBeVisible("btn_startTheQuiz");
		element("btn_startTheQuiz").isDisplayed();
		// element("txt_achievedPoints").isDisplayed();
		element("txt_fneTitle").isDisplayed();
		element("heading_policies").isDisplayed();
		logMessage("Verified that Student is on FandE page");
	}

	/**
	 * Student starts Homework by clicking 'Start the Homework' Button(for
	 * Homework type Assignments)
	 * 
	 */
	public void clickStartTheHomeworkButton() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_startTheHomework");
		element("btn_startTheHomework").click();
		logMessage("User Clicked on 'Start the Homework' button");
		waitForLoaderToDisappear();
	}
	
	public void clickStartTheQuizButton() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_startTheQuiz");
		element("btn_startTheQuiz").click();
		logMessage("User Clicked on 'Start the Quiz' button");
		waitForLoaderToDisappear();
	}
	
	public void clickResumeTheQuizButton() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_resumeTheQuiz");
		element("btn_resumeTheQuiz").click();
		logMessage("User Clicked on 'Resume the Quiz' button");
		waitForLoaderToDisappear();
	}

	public void attemptHomeworkWithCorrectAnswer(String[] correctResponses) {
		int i = 1;
		switchToCourseContentFrame();
		for (String answer : correctResponses) {
			element("radio_correctAnswer", answer, i + "").click();
			logMessage("Selected option " + answer + " for answer " + i);
			i++;
		}
		switchToDefaultContent();
		//switchToCourseContentFrame();
		//element("btn_submit").click();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[2].click()");
		logMessage("Clicked on Submit button");
	}
	
	public void attemptQuizWithInCorrectAnswer(String correctResponses) {
		switchToCourseContentFrame();
		element("radio_incorrectAnswerForQuiz", correctResponses).click();
		switchToDefaultContent();
		//switchToCourseContentFrame();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[2].click()");
		logMessage("Clicked on Submit button");
		switchToCourseContentFrame();
		waitForElementToBeVisible("confirmDialogTitle");
		element("btn_yesConfirmDialog").click();
		waitForLoaderToDisappear();
		switchToDefaultContent();
	}
	
	public void attemptQuizWithCorrectAnswer(String correctResponses) {
		switchToCourseContentFrame();
		element("radio_correctAnswerForQuiz", correctResponses).click();
		switchToDefaultContent();
		//switchToCourseContentFrame();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[2].click()");
		logMessage("Clicked on Submit button");
		switchToCourseContentFrame();
		waitForElementToBeVisible("confirmDialogTitle");
		element("btn_yesConfirmDialog").click();
		waitForLoaderToDisappear();
		switchToDefaultContent();
	}
	
	public void saveQuizWithInCorrectAnswer(String correctResponses) {
		switchToCourseContentFrame();
		element("radio_incorrectAnswerForQuiz", correctResponses).click();
		switchToDefaultContent();
		//switchToCourseContentFrame();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[1].click()");
		logMessage("Clicked on Save button");
//		switchToCourseContentFrame();
		switchToDefaultContent();
	}
	
	public void saveQuizWithCorrectAnswer(String correctResponses) {
		switchToCourseContentFrame();
		element("radio_correctAnswerForQuiz", correctResponses).click();
		switchToDefaultContent();
		//switchToCourseContentFrame();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[1].click()");
		logMessage("Clicked on Save button");
//		switchToCourseContentFrame();
		switchToDefaultContent();
	}

	public void saveHomeworkWithInCorrectAnswer(String[] correctResponses) {
		int i = 1;
		switchToCourseContentFrame();
		for (String answer : correctResponses) {
			element("radio_incorrectAnswer", answer, i + "").click();
			logMessage("Selected option " + answer + " for answer " + i);
			i++;
		}
		switchToDefaultContent();
		hardWait(2);
		//switchToCourseContentFrame();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[1].click();");
		logMessage("Clicked on Save button");
		switchToDefaultContent();
	}
	
	public void attemptHomeworkWithInCorrectAnswer(String[] correctResponses) {
		int i = 1;
		switchToCourseContentFrame();
		for (String answer : correctResponses) {
			element("radio_incorrectAnswer", answer, i + "").click();
			logMessage("Selected option " + answer + " for answer " + i);
			i++;
		}
		switchToDefaultContent();
		//switchToCourseContentFrame();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[2].click()");
		logMessage("Clicked on Submit button");
	}
	
	public void saveHomeworkWithCorrectAnswer(String[] correctResponses) {
		int i = 1;
		switchToCourseContentFrame();
		for (String answer : correctResponses) {
			element("radio_correctAnswer", answer, i + "").click();
			logMessage("Selected option " + answer + " for answer " + i);
			i++;
		}
		switchToDefaultContent();
		//switchToCourseContentFrame();
		executeJavascript("document.getElementById('"+element("iframe_easyXDMDefault").getAttribute("id")+"').contentDocument.getElementById('contentBody_FrameContent').contentDocument.getElementsByClassName('content x-panel-body page_color default_font')[0].contentDocument.getElementsByClassName('x-btn-text ')[1].click();");
		logMessage("Clicked on Save button");
		switchToDefaultContent();
	}

	/*
	 * Switches to easyXDMDefault Frame then to Content Body Frame and then to
	 * Course Content Frame
	 */
	public void switchToCourseContentFrame() {
		switchToDefaultContent();
		hardWait(2);
		switchToFrame(element("iframe_easyXDMDefault"));
		switchToFrame(element("iframe_contentBody"));
		switchToFrame(element("iframe_courseContentFrame"));
	}

	public void verifyAttemptMarkedIncorrect() {
		switchToCourseContentFrame();
		CustomAssert.assertEquals(elements("list_errorImages").size(), 5,
				"Assertion failed : Grading is not done correctly");
		logMessage("Assertion Passed : Grading is done correctly");
	}
	
	public void verifyQuizAttemptMarkedIncorrect() {
		hardWait(2);
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		CustomAssert.assertEquals(elements("list_errorImages").size(), 2,
				"Assertion failed : Grading is not done correctly");
		logMessage("Assertion Passed : Grading is done correctly");
	}
	
	public void verifyQuizAttemptMarkedCorrect() {
		hardWait(2);
		switchToDefaultContent();
		switchToFrame(element("iframe_easyXDMDefault"));
		CustomAssert.assertEquals(elements("list_errorImages").size(), 0,
				"Assertion failed : Grading is not done correctly");
		logMessage("Assertion Passed : Grading is done correctly");
	}

	public void verifyAttemptMarkedCorrect() {
		switchToCourseContentFrame();
		CustomAssert.assertEquals(elements("list_errorImages").size(), 0,
				"Assertion failed : Grading is not done correctly");
		logMessage("Assertion Passed : Grading is done correctly");
	}

	public void changeAnswersOfQuestion() {
		switchToFrame(element("iframe_easyXDMDefault"));
		// isElementDisplayed("link_properties");
		waitForLoaderToDisappear();
		// switchToDefaultContent();
		// waitForLoaderToDisappear();
		switchToFrame(element("iframe_questionEditor"));
		Actions action = new Actions(driver);
		action.doubleClick(element("img_response")).build().perform();
		driver.switchTo().parentFrame();
		switchToFrame(element("iframe_answerEdit"));
		element("radiobtn_incorrectAnswer").click();
		element("btn_saveAnswer").click();
		hardWait(2);
		driver.switchTo().parentFrame();
		driver.switchTo().parentFrame();
		element("btn_saveEdit").click();
		isElementDisplayed("msg_toast");
		waitForMsgToastToDisappear();
	}

	public void clickOnEditQuestion() {
		waitForLoaderToDisappear();
		hover(element("firstQuestion"));
		element("lnk_editQuestion").click();
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_saveEdit");
	}

	public void clickOnEditButton() {
		element("dropdown_edit").click();
		logMessage("Clicked on edit button");
	}

	public void addQuestionsToQuiz(String chapterName, String questionNumber) {
		clickOnQuestionsTab();
		clickChapterOneFromQuestionBank(chapterName);
		clickTestBankOneFromChapterOne();
		checkQuestionForQuizFromQuestionsAvailable(questionNumber);
		clickAddButtonInQuestions();
		verifyQuestionAddedToAssignment();
	}
}
