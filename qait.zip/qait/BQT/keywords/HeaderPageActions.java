package com.qait.BQT.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class HeaderPageActions extends GetPage{

	public HeaderPageActions(WebDriver driver) {
		super(driver, "HeaderPage");
	}
	
	/**
	 * Selects 'Sign out' option from User Menu to log out from the application
	 */
	public void logout() {
		clickElementIfVisible("btn_closeToastMessage");	
		hoverUserNameMenu();
		//element("link_usernameMenu").click();
		clickUserMenuItem("Sign Out");
		waitForElementToBeVisible("link_helpMenu");
	}
	
	/**
	 * Click specified User Name Menu Item link 
	 */
	public void clickUserMenuItem(String itemName) {
		waitForElementToBeVisible("link_usernameMenuItem", itemName);
		hardWait(2);
		element("link_usernameMenuItem", itemName).click();
		logMessage("Clicked User Name Menu Item '" + itemName + "'");
	}
	
	/**
	 * hovers over the User Name Menu in header
	 */
	public void hoverUserNameMenu() {
		hardWait(2);
		//hover(element("link_usernameMenu"));
		executeJavascript("document.getElementsByClassName('hidden-menu profileMenu')[0].style.display='block';");
	}

}
