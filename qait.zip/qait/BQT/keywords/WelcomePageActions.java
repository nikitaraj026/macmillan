package com.qait.BQT.keywords;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class WelcomePageActions extends GetPage{

	public WelcomePageActions(WebDriver driver) {
		super(driver, "WelcomePage");
	}
	
	public void verifyWelcomePageDisplayed() {
		waitForLoaderToDisappear();
		clickElementIfVisible("btn_closeToastMessage");
		isElementDisplayed("button_enterCourse");
	}
	
	public void enterCourseFromWelcomePage(){
		switchToDefaultContent();
		JavascriptExecutor js = (JavascriptExecutor) driver;
		waitForElementToBeVisible("button_enterCourse");
		js.executeScript("document.getElementsByClassName('EnterCourse')[0].click();");
		//element("button_enterCourse").click();
		logMessage("User clicks on 'Enter Course' button on Welcome Page");
		switchToDefaultContent();
	}
	
}
