package com.qait.BQT.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.BQTTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class AA_2043_Homework_Scenario7 extends Parent_Test {

	BQTTestSessionInitiator bqt;
	
	String courseName = getStringWithTimestamp("AA_2043_Homework_Scenario7");
	String welcomePageTitle, baseUrl;
	String schoolName;
	String courseUrl;
	String instructorUserName, instructorPassword;
	String studentUserName, studentPassword;
	String hwAsgnmtName1 = "Homework 001";
	String chapterName;
	String[] responses;
	
	private void initVars(String book) {
		String bookIdentifier =book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		welcomePageTitle = getData(bookIdentifier + ".welcomepageTitle");
		instructorUserName = getData("users.instructor.user_name4");
		instructorPassword = getData("users.instructor.password");
		schoolName = getData("courseDetails.schoolName");
		studentUserName = getData("users.student.user_name4");
		studentPassword = getData("users.student.password");
		chapterName = getData(bookIdentifier + ".chapterNumber");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(bqt, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("calculuset2e") String book) {
		 bqt = new BQTTestSessionInitiator();
		initVars(book);
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
		bqt.stepStartMessage(method.getName()); 
    }

	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		bqt.launchApplication(baseUrl);
		bqt.loginPage.verifyUserIsOnLoginPage();
		bqt.loginPage.login(instructorUserName,instructorPassword);
		bqt.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_New_Course(){
		bqt.dashboardPage.createCourseNotBasedOnExistingCourse();
		bqt.dashboardPage.createCourse(courseName, "", "", "", schoolName, "");
		bqt.dashboardPage.verifyCourseNameLinkDisplayed(courseName);
		courseUrl = bqt.dashboardPage.getCourseUrl(courseName);	
	}
	
	@Test(dependsOnMethods = "Step02_Instructor_Creates_New_Course")
	public void Step03_Instructor_Activates_Course_From_Dashboard(){
		bqt.dashboardPage.activateCourse(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Activates_Course_From_Dashboard")
	public void Step04_Instructor_Enters_Course(){
		bqt.dashboardPage.clickCourseNameLink(courseName);
		bqt.welcomePage.verifyWelcomePageDisplayed();
		bqt.welcomePage.enterCourseFromWelcomePage();
		bqt.courseHomePage.verifyCourseName(courseName);
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Enters_Course")
	public void Step05_Create_Homework_Assignment() {
		bqt.courseHomePage.createAssignment("Homework");
		bqt.fandePage.fillBasicInfo(hwAsgnmtName1);
		bqt.fandePage.clickOnSaveButton();
		bqt.fandePage.addQuestionsToAssignment(chapterName);
		responses = bqt.fandePage.getCorrectAnswer();
		bqt.fandePage.assignTheAssignmentInPastDate("10", "15", "80", "days");
		bqt.fandePage.clickOnDoneButton();
		bqt.fandePage.clickOnHomeButton();
		bqt.courseHomePage.verifyCourseName(courseName);
	}
	
	@Test(dependsOnMethods = "Step05_Create_Homework_Assignment")
	public void Step06_Instructor_Log_Out() {
		bqt.headerPage.logout();
	}
	
	@Test(dependsOnMethods = "Step06_Instructor_Log_Out")
	public void Step07_Student_Joins_The_Course() {
		bqt.launchApplication(courseUrl);
		bqt.loginPage.verifyUserIsOnLoginPage();
		bqt.loginPage.login(studentUserName, studentPassword);
		bqt.enrollPage.verifyUserIsOnEnrollPage();	
		bqt.enrollPage.clickJoinCourseButton();
		bqt.enrollPage.clickContinueAfterJoiningCourse();
		bqt.welcomePage.verifyWelcomePageDisplayed();
		bqt.welcomePage.enterCourseFromWelcomePage();
		bqt.courseHomePage.verifyCourseName(courseName);
	}
	
	@Test(dependsOnMethods = "Step07_Student_Joins_The_Course")
	public void Step08_Student_Opens_Homework() {
		bqt.courseHomePage.clickOnShowOrHidePastDueLink();
		bqt.courseHomePage.clickTOCItem(hwAsgnmtName1);
		bqt.fandePage.verifyStudentIsOnHomeworkStartPage();
	}
	
	@Test(dependsOnMethods = "Step08_Student_Opens_Homework")
	public void Step09_Student_Submits_The_Homework() {
		bqt.fandePage.clickStartTheHomeworkButton();
		bqt.fandePage.attemptHomeworkWithCorrectAnswer(responses);
	}
	
	@Test(dependsOnMethods = "Step09_Student_Submits_The_Homework")
	public void Step10_Verify_Attempt_Is_Marked_Correct() {
		bqt.fandePage.verifyAttemptMarkedCorrect();
	}
	
	@AfterClass
	public void closeBrowser() {
		bqt.closeBrowserSession();
	}
}
