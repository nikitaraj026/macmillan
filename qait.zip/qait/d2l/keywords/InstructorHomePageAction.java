package com.qait.d2l.keywords;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class InstructorHomePageAction extends GetPage {

	public InstructorHomePageAction(WebDriver driver) {
		super(driver, "InstructorHomePage");
	}

	public void closeStartTourModalWidow() {
		waitAndClick("btn_startTour");
	}

	public void click_AllCoursesUsingJS() {
		executeJavascript(
				"document.getElementsByClassName('d2l-body-standard style-scope d2l-my-courses-content-animated').item(0).click()");
	}

	public void courseNameDisplaysUsingJS(String course) {
		hardWait(4);
		waitAndScrollToElement("btn_viewAllCourses");
		click_AllCoursesUsingJS();
		hardWait(4);
		fillText("inpt_SearchBox", course);
		hardWait(2);
		click(element("icon_search"));
		hardWait(4);
		waitAndClick("link_courseName", course);

	}

	public void courseNameDisplays(String course) {
//		waitAndScrollToElement("txtbox_searchCourse");
//		fillText("txtbox_searchCourse", course);
//		waitAndClick("btn_search");
		hardWait(4);
		waitAndScrollToElement("btn_viewAllCourses");
		waitAndClick("btn_viewAllCourses");
		hardWait(4);
		fillText("inpt_SearchBox", course);
		hardWait(2);
		click(element("icon_search"));
//	isElementDisplayed("btn_selectCourse");
//	waitAndClick("btn_selectCourse");
//	scrollToElementUsingJavaScriptForLP("txt_courseName",course);
//	waitAndScrollToElement("txt_courseName",course);

//	scrollDownWithGivenDimension(330);
		hardWait(4);
		waitAndClick("link_courseName", course);

	}

	public void clickCourseTitle(String course) {
		hardWait(4);
		scroll(element("txt_courseName", course));
		waitAndClick("txt_courseName", course);
	}

	public void authentication() {

		waitAndClick("btn_authenticate");
	}

	public void continueButton() {
		waitAndClick("btn_authenticateContinue");
	}

	public void clickon_Continue() {
		waitAndClick("continue_button");
	}

	public void createCourse() {
//		verifyPageTitleContains("Macmillan Learning Integration Token Registration");
		// element("lnk_createCourse").click();
		wait.hardWait(3);
		waitScrollAndClick("lnk_createCourse");
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy ");
		Date date = new Date();
		String date1 = dateFormat.format(date);
		hardWait(4);
		waitAndScrollToElement("txtbox_courseTitle");
		element("txtbox_courseTitle").sendKeys("SmokeCourse " + date1);
		List<WebElement> dropdownSchool = elements("drodDown_school");
		if (dropdownSchool.size() == 1) {
			waitForElementToBeClickable(element("drodDown_school"));
			selectTextFromDropDown("drodDown_school", "BFWUsers");
		}
		waitAndScrollToElement("drpdwn_academicTerm");
		selectTextFromDropDown("drpdwn_academicTerm", "Summer 2016");
		isElementDisplayed("btn_createCourse");
		element("btn_createCourse").click();

		logMessage("Instructor has created a new course");

		hardWait(5);
	}

	public void courseProvisioning(String courseTitle) {
		// isElementDisplayed("txt_courseTitle");
		// changeWindow(1);
		hardWait(5);
		waitAndClick("btn_associateCourse", courseTitle);
//		executeJavascript("document.getElementsByClassName('associateSaplingCourseButton').item(0).click()");
		hardWait(5);
		waitAndClick("btn_yesAssociate");
		hardWait(5);
		waitAndClick("btn_ok");
		hardWait(2);
		isElementDisplayed("txt_successMessage");
		logMessage("New course is associated");
		closeWindow();
		changeWindow(0);
	}

	public void reConnectCourseForLP() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(5);
		waitAndClick("lnk_ReconnectThisCourse");
		logMessage("User verifies the Sever This Course Page");

		closeWindowAndSwitchBackToOriginalWindow(0);
		refreshPage();
	}

	public void viewAvailableCoursesForLP() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(3);
		waitAndClick("lnk_viewAvailableCourses");
	}

	public void clickOnUnlinkMacmillanToolLink() {
		switchToDefaultContent();
	    switchToDefaulFrame();
		hardWait(5);

		scroll(element("lnk_Unlink_Macmillan_Course"));
		hardWait(3);
		isElementDisplayed("lnk_Unlink_Macmillan_Course");
		hardWait(3);
		element("lnk_Unlink_Macmillan_Course").click();

		hardWait(5);
		logMessage("click on unlink link");
		changeWindow(1);
	}

	public void switchToDefaulFrame() {
		waitForElementToBeVisible("iframe_ToolContent");
		switchToFrame("iframe_ToolContent");
	}

	public void verifyEndCourseAssociationPage() {
		verifyPageTitleContains("End Course Association");
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		isElementDisplayed("checkbox_removeDeployedContent");
		logMessage("Instructor is on 'End Course Association' page");

	}

	public void disassociateCourse() {
		element("btn_Yes_DisassociateThisCourse").click();
		logMessage("Instructor clicked on 'Yes, Disassociate This Course' button");
	}

	public void sso_accept() {
//		waitAndClick("btn_submit");
//		waitAndClick("btn_continue");
		waitAndClick("btn_authenticate");
		waitAndClick("btn_ContinueAuthenticate");
		waitAndClick("btn_authenticateContinue");
	}

	public void acceptSSO() {
		waitAndClick("btn_authenticate");
		waitAndClick("btn_ContinueAuthenticate");
	}

	public void toolsWidgetDisplayed(String widgetName) {
		isElementDisplayed("txt_widgetName", widgetName);
		hardWait(5);
	}

	public void clickOnContinueButton() {
		waitAndClick("btn_continue");
	}

	public void clickOnCheckBox() {
		waitAndClick("btn_dontAsk");
	}

	public boolean softverifyMacmillanCourseIsAssociated() {
		boolean isPresent = false;
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		int count = getElementCount("lnk_gettingStarted");
		if (count == 1) {
			logMessage("Course is already disassociated");
			isPresent = false;
		} else if (count < 1) {
			logMessage("Course is associated");
			isPresent = true;
		}
		return isPresent;
	}
}
