package com.qait.d2l.keywords;

import java.util.Set;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class InstructorCourseAssociationAction extends GetPage{

	public InstructorCourseAssociationAction(WebDriver driver) {
		super(driver, "InstructorCourseAssociation");
	}
	
	public void launchpadRedirect()
	{
		hardWait(10);
		switchToDefaultContent();
		switchToFrame("switch_frame");
		element("lnk_launchPad").click();
		
	}
	
	
	

}
