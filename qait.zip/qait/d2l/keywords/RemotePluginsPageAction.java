package com.qait.d2l.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class RemotePluginsPageAction extends GetPage {

	public RemotePluginsPageAction(WebDriver driver) {
		super(driver, "RemotePluginsPage");
	}

	public void verifyRemotePluginsPageDisplayed() {
		isElementDisplayed("txt_sectionHeading", "Manage Remote Plugins");
	}

	public void openRemotePlugin(String pluginName) {
		scroll(element("link_remotePluginName", pluginName));
		waitAndClick("link_remotePluginName", pluginName);
	}

	public void verifyEditRemotePluginPageDisplayed(String pluginName) {
		isElementDisplayed("txt_sectionHeading", "Edit Remote Plugin");
		isElementDisplayed("txtinput_remotePluginName", pluginName);
	}

	public void clickAddOrgUnitsBtn() {
		waitForElementToBeClickable(element("btn_addOrgUnits"));
		clickUsingJavaScript("btn_addOrgUnits");
	}

	public void verifyAddOrgUnitsModalDisplayed() {
		isElementDisplayed("txt_addOrgUnitsModalTitle");
	}

	public void searchAndInsertCourseOffering(String courseOffering) {
		switchToFrame("iframe_addOrgUnits");
		hardWait(4);
		System.out
				.println("document.querySelector(\"input[placeholder='Search For…']\").value='" + courseOffering + "'");
		executeJavascript(
				"document.querySelector('.d2l-search-simple-wc-input').value='"
						+ courseOffering + "'");
//		isElementDisplayed("txtinput_searchFor_addOrgUnits", courseOffering);
//		fillText("txtinput_searchFor_addOrgUnits", courseOffering);
//		waitForElementToBeVisible("btn_searchFor_addOrgUnits");
//		waitAndClick("btn_searchFor_addOrgUnits");
		// scroll(element("checkbox_courseOffering_addOrgUnits", courseOffering));
		hardWait(2);
		executeJavascript("document.querySelector('.d2l-search-simple-wc-input').shadowRoot.querySelector('.d2l-input-search-container')"
				+ ".querySelector('.d2l-input-search-search').click()");
		hardWait(3);
		scroll(element("checkbox_courseOffering_addOrgUnits", courseOffering));
		hoverClick(element("checkbox_searchedCourse", courseOffering));
		switchToDefaultContent();
		waitScrollAndClick("btn_insert_addOrgUnits");
	}

	public void verifyCourseOfferingAddedAsOrgUnit(String courseOffering) {
		hardWait(2);
		isElementDisplayed("txt_courseOfferingName", courseOffering);
	}

	public void clickSaveBtnAndVerify() {
		hardWait(4);
		element("btn_save").click();
		isElementDisplayed("txt_savedSuccessfullyMessage");
	}

}
