package com.qait.d2l.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class StudentAccessGrantPageActions extends GetPage{
	public StudentAccessGrantPageActions(WebDriver driver){
		super(driver,"StudentAccessPage");
	}
	
	
	public void clickenterAnAccessCode(){
		waitAndClick("button_enterAnAccessCode");
		logMessage("Clicked: Enter an Access Code");
	}
	
	public void clickPurchaseAccess() {
		waitAndClick("button_purchaseAccess");
		logMessage("Clicked: Purchase Access");
	}
	
	public void clickRequestFreeTrial(){
		waitAndClick("button_requestFreeTrial");
		logMessage("Clicked: Request Free Trial");
		hardWait(2);
	}
	public void handleInstitutionWindow(String instName)
	{
		wait.resetImplicitTimeout(2);
		try{
			if(isElementDisplayed("input_instName"))
			{
				fillText("input_instName",instName);
				waitAndClick("list_inst",instName);
				waitAndClick("btn_Ok");
				logMessage("Fill the institution details");
			}
			wait.resetImplicitTimeout(wait.getTimeout());
		}
		catch(Exception e)
		{
			wait.resetImplicitTimeout(wait.getTimeout());
			logMessage("Institution Popup not found");
		}
	}
	public void clickRequestFreeTrialForSap(String value,String answer) {
//		waitForLoaderToDisappear();
//		switchToDefaultContent();
//		waitForLoaderToAppear();
//		executeJavascript("document.querySelector('.singlebutton input[value=\"Yes\"]').click()");
//		changeWindow(1);
		waitAndClick("bnt_freeTrial");
		waitAndClick("btn_continueEnroll");
		element("input_InstitutionName").click();
		sendKeys(element("input_InstitutionName"), "Sapling Learn");
		//element("input_InstitutionName").click();
		hardWait(2);
		element("input_InstitutionName").sendKeys("i");
		hardWait(3);
		//element("input_InstitutionName").click();
		waitAndClick("dropdown_textSaplingLearning");
		waitAndClick("btn_OK");
		hardWait(6);
		hardWait(3);
		waitAndClick("link_question");
		switchToFrame("iframe_question");
		List<WebElement> list=elements("list_question");
		for(int i=0;i<list.size();i++)
		{
			wait.hardWait(4);
			String labelValue=(String) executeJavascript("return document.querySelectorAll('label.sl-list-label')["+i+"].textContent");
			if(labelValue.equals(answer))
			{
				wait.hardWait(4);
				list.get(i).click();
				break;
			}
		}
		waitAndClick("btn_checkAnswer");
		closeWindow();
		changeWindow(0);
		logMessage("Clicked on "+value+" button");
	}
	
	
	//Enter Student Access Code Mars
	public void verifyUserIsOnEnterStudentAccessCodePage() {
		verifyTextOfElementIsCorrect("StudentAccessCodeTitle", "Enter Student Access Code");
		logMessage("User is on 'Enter Student Access Code' page.");
	}
	
	public void fillAccessCodeOnEnterStudentAccessCode(String accessCode) {
		fillText("input_accessCode", accessCode);
	}
	
	public void clickSubmitOnEnterStudentAccessCode() {
		waitAndClick("btn_submitStudentAccessCodeMars");
		logMessage("Clicked: 'Submit' button on 'Enter Student Access Code' page.");
		hardWait(2);
	}
	
	public void clickCancelOnEnterStudentAccessCode() {
		waitAndClick("btn_cancelStudentAccessCodeMars");
		logMessage("Clicked: 'Cancel' button on 'Enter Student Access Code' page.");
	}
	
	//Purchase Access
	public void verifyUserIsOnPurchaseAccessPage() {
		isElementDisplayed("txt_purchaseAccessTitle");
		logMessage("User is on 'Purchase access' page.");
	}
	
	public void select180DaysAccess() {
		hardWait(4);
		//waitAndClick("input_180daysAccess");
		waitAndClick("input_180daysAccess1");
		logMessage("Selected: '180 days access' on 'Purchase access' page");
	}

	public void selectCountryAndEnterZipForTaxCalculation() {
		selectProvidedTextFromDropDown(element("dropdown_country"), "United States");
		fillText("input_zip", "10003");
		logMessage("Student has selected/entered information in 'Country' and 'Zip' fields");
	}

	public void select1yearAccess() {
		waitAndClick("input_1yearAccess");
		logMessage("Selected: '1 year access' on 'Purchase access' page");
	}
	
	public void select2yearAccess() {
		waitAndClick("input_2yearAccess");
		logMessage("Selected: '2 year access' on 'Purchase access' page");
	}
	
	public void clickAddToCart() {
		waitAndClick("button_addToCart");
		logMessage("Clicked: 'Add to Cart' on 'Purchase access' page.");
	}
	
	//Purchase Access > Payment Details
	public void verifyUserIsOnPaymentDetailsPage() {
		isElementDisplayed("txt_paymentDetailsTitle");
		logMessage("User is on 'Payment Details' page.");
	}
	
	public void clickPaypalOnPaymentDetailsPage() {
		switchToFrame("frame_paymentFormPaypal");
		waitAndClick("button_paypal");
		logMessage("Clicked: 'PayPal' on 'Payment Details' page.");
		switchToDefaultContent();
	}
	
	public void handlePaypalSandbox() {
		//changeWindow(1);
		changeWindow(2);
		isElementDisplayed("paypalWindowTitle");
		waitAndClick("button_proceedSandboxPurchase");
		changeWindow(0);
		switchToFrame("frame_paymentFormPaypal");
		isElementDisplayed("txt_paymentMethodTypePaypal");
		switchToDefaultContent();
		logMessage("'Paypal Sandbox' has been handled.");
	}
	
	public void clickContinueOnPaymentDetailsPage() {
		waitAndClick("button_continuePaymentDetails");
		logMessage("Clicked: 'Continue' button on 'Payment Details' page.");
	}
	
	//Purchase Access > Review Your Order
	public void verifyUserIsOnReviewYourOrderPage() {
		waitAndClick("txt_reviewYourOrderTitle");
		logMessage("User is on 'Review Your Order' page.");
	}
	
	public void clickConfirmPaymentOnReviewYourOrderPage() {
		waitAndClick("button_confirmPayment");
		logMessage("Clicked 'Confirm payment' on 'Review Your Order' page.");
	}
	
	//Purchase Access > Purchase Confirmation
	public void verifyUserIsOnPurchaseConfirmationPage() {
		isElementDisplayed("txt_purchaseConfirmationTitle");
		logMessage("User is on 'Purchase Confirmation' page.");
	}
	
	public void clickContinueOnPurchaseConfirmationPage() {
		waitAndClick("button_continuePurchaseConfirmation");
		logMessage("Clicked: 'Continue' button on 'Purchase Confirmation' page.");
		hardWait(2);
	}
	
	//Request Free Trial
	public void clickContinueToSite(){
		hardWait(10);
		waitForElementToBeClickable(element("button_continueToSite"));
		logMessage("Element is clickable");
		hardWait(1);
		logMessage("hardwait 1");
		waitForElementToBeVisible("button_continueToSite");
		logMessage("Element is visible");
		hardWait(10);
		element("button_continueToSite").click();
		logMessage("Clicked: Continue to Site");
	}

	public void enterCardNumberOnPaymentDetailsPage(String cardNumber) {
		switchToFrame("iframe_payPal");
		waitForElementToBeVisible("input_cardNumber");
		element("input_cardNumber").sendKeys(cardNumber);
		logMessage("User has entered card number on 'Payment Details' page");		
	}


	public void enterExpirationAndCVVOnPaymentDetailsPage(String expiration, String cvv) {
		isElementDisplayed("input_expiration");
		isElementDisplayed("input_cvv");
		element("input_expiration").sendKeys(expiration);
		hardWait(2);
		element("input_cvv").sendKeys(cvv);
		switchToDefaultContent();
		logMessage("User has entered card expiration date and CVV");		
	}
}
