package com.qait.d2l.keywords;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class CourseDeploymentPageAction extends GetPage{
	String moduleName = null;
	int selectCount=0;
	public CourseDeploymentPageAction(WebDriver driver) {
		super(driver, "CourseDeploymentPageAction");
	}
	
	public void clickCourseAdmin()
	{
		waitAndClick("link_courseAdmin");
	}
	
	public void clickCourseBuilder()
	{
		if(!verifyElementNotDisplayed("btn_StartCourseBuilder"))
			waitAndClick("btn_StartCourseBuilder");
		waitAndClick("link_courseBuilder");
	}
	
	public void clickCreateModule()
	{
		waitAndClick("link_createModule");
	}
	
	public void modalWindowCreateModuleDispalys ()
	{    
		
		isElementDisplayed("modal_title");
		//switchToFrame("modal_window");
		//fillText("txtbox_name", "ModuleTestA");
		//switchToDefaultContent();
		executeJavascript("document.documentElement.getElementsByTagName('iframe') [0].contentDocument.getElementById('z_c').value = '"+ moduleName+"';");
		//waitAndClick("btn_create");
	}
	
	public void deployContent ()
	{
		/*waitScrollAndClick("img_widgetTool");
		//element("module_title1").click();
		executeJavascript("document.documentElement.getElementsByTagName('iframe')[0].contentDocument.getElementsByClassName('di_t');");
		switchToFrame("iframe");
		element("lnk_arrow").click();
		//executeJavascript("document.documentElement.getElementsByTagName('iframe')[0].contentDocument.getElementsByClassName('di_t');");
		//executeJavascript("document.documentElement.getElementsByTagName('iframe')[0].contentDocument.getElementById('mw_show_assignments');");
		waitAndClick("checkbox_autoQuiz");
		waitAndClick("checkbox_chapterIntroduction");
		waitAndClick("btn_deploySelectedContent");
		isElementDisplayed("msg_success");
		waitAndClick("link_closeDialogue");*/
		
		
		switchToFrame("iframe_path");
		waitAndClick("link_module");
		switchToDefaultContent();
		//switchToFrame("iframe_remote");
		//switchToFrameWithOutSwitchingDefault("iframe_remote");
		//switchToNestedFrames("iframe_remote");
		switchToFrame("iframe_nested");
		hardWait(10);
		switchToFrameWithOutSwitchingDefault("iframe_remote");
		waitAndClick("link_assignmentArrow");
	}
	
	public void contentDispalyed ()
	{
		waitAndClick("link_courseLink");
		waitAndClick("link_content");
	}
	
	public void chapterContentIsNotAddedContent ()
	{
		waitAndClick("link_chapterArrow");
		
	}

	public void clickOnCourseOfferingName() {
		switchToFrame("iframe_createModule");
//		click(element("link_courseOffering"));
//		switchToDefaultContent();
	}

	public void enterModuleName(String moduleName) {
		this.moduleName= moduleName;
		hardWait(4);
		fillText("input_moduleName", moduleName);
		switchToDefaultContent();
	}

	public void clickOnCreateButton() {
		click(element("btn_create"));
	}

	public void clickOnMacmillanLearningTOC(String toolTOC) {
		waitScrollAndClick("img_TOC", toolTOC);
	}

	public void selectModule() {
	   hardWait(2);
		element("cancel_button").click();
	    hardWait(2);
		dragAndDropElement(element("drag_Button"), element("tomodule"));
		isElementDisplayed("modal_title");
		//executeJavascript("document.documentElement.getElementsByTagName('iframe') [0].contentDocument.getElementById('z_c').value = '"+ moduleName+"';");
		switchToFrame("iframe_selectLocation");
		click(element("link_module", moduleName));
		switchToDefaultContent();
	}

	public void clickOnAssignmentArrow() {
		hardWait(3);
		dragAndDropElement(element("drag_Button"), element("tomodule"));
		hardWait(5);
		//switchToFrame("iframe_path");
		//waitAndClick("link_module", moduleName);
		//switchToDefaultContent();
		switchToFrame("iframe_nested");
		hardWait(10);
		switchToFrameWithOutSwitchingDefault("iframe_remote");
		waitAndClick("link_assignmentArrow");
	}

	public void selectAssignments() {
		int count= getElementCount("checkbox_assignmentsTotal");
		selectCount= getElementCount("checkbox_assignments");
		System.out.println(count);
		int i=1;
		click(element("checkbox_assignments1", Integer.toString(1)));
//		if(i!=0) {
//			do {
//				click(element("checkbox_assignments1", Integer.toString(i)));
//				i++;
//			}while(i<=count);
//		}
		//for(int i=1; i<=selectCount; i++) {
			//	click(element("checkbox_assignments1", Integer.toString(i)));			
		//}
	}

	public void verfiySelectedCount() {
		element("textbox_itemSelected").getText().equals(Integer.toString(selectCount));
		System.out.println("Selected count verified");
	}

	public void clickOnDeploySelectedCount() {
		click(element("btn_deploySelectedCount"));
		System.out.println("Content Deployed");
		switchToDefaultContent();
//		switchToFrameWithOutSwitchingDefault("iframe_ddial");
//		switchToFrameWithOutSwitchingDefault("iframe_remotel");
//		click(element("btn_OK"));
		hardWait(3);
		executeJavascript("document.getElementsByClassName('d2l-dialog-close')[0].click()");
	}

	public void clickOnContentNavBar() {
		clickUsingJavaScript("link_content");
		hardWait(3);
		logMessage("Clicked on Content Navigation Bar");
	}

	public void verifyContentDeployed() {
		click(element("lnk_tableOfContent", moduleName));
		int contentDeployedCount= getElementCount("link_d2lDataList");
		//customAssert.customAssertEquals(contentDeployedCount,selectCount-1, "Content Deployed count");
	}

	public void clickOnStartButton() {
		waitAndClick("btn_start");
	}

	public boolean softverifyModuleIsPresent() {
		boolean isPresent = false;
		int count = getElementCount("section_module");
		if(count == 1){
			logMessage("Module is present");
			isPresent = true;
		}
		else if(count < 1){
			logMessage("Module is deleted");
			isPresent = false;
		}
		return isPresent;
	}

	public void clickOnArrowIcon() {
		waitAndClick("module_arrowIcon");
		logMessage("Clicked on Arrow icon");
	}

	public void clickOnRemoveLink() {
		waitAndClick("lnk_remove");
		logMessage("Clicked on Removed link");
	}

	public void clickOnBtnRemoveConfirm() {
		waitAndClick("btn_remove");
		logMessage("Clicked on button remove");
	}

	public void removeModule() {
		clickOnArrowIcon();
		clickOnRemoveLink();
		clickOnBtnRemoveConfirm();
		refreshPage();
		verifyElementNotDisplayed("section_module");
		logMessage("Module has been deleted");
	}
	 public void verifyAllAssignmentsTextIsNotClickable() {
			hardWait(2);
			waitForElementToBeVisible("txt_assignments");
			isElementDisplayed("txt_assignments");
			assertTrue(element("txt_assignments").getAttribute("class").contains("inactive"));
			logMessage("Verified that the text Select All Assignments is not clickable");
		}
}
