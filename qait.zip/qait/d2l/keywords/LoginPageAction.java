package com.qait.d2l.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class LoginPageAction extends GetPage {

	public LoginPageAction(WebDriver driver) {
		super(driver, "LoginPage");
	}
	
	public void verifyLoginPageDisplayed() {
		isElementDisplayed("txt_welcomeHeading");
	}

	public void login(String userName, String password) {
		fillText("txtinput_username", userName);
		fillText("txtinput_password", password);
		waitAndClick("btn_login");
		logMessage("Trying to Login with User ID '" + userName + "'");
	}
	
	public void d2lLogout() {
		 element("link_profileMenu").click();
		 hardWait(2);
		waitAndClick("link_logout");
	}
	
	public void logout() {       
        element("link_profileArrow").click();
		waitAndClick("link_logout");	
	}

}