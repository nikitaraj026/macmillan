package com.qait.d2l.keywords;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import com.qait.automation.utils.CustomAssert;
import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class InstructorToolsWidgetAction extends GetPage {
	
	public InstructorToolsWidgetAction (WebDriver driver) {
		super(driver, "InstructorToolsWidget");
	}
	
	public void toolsWidgetName(String widgetName)
	{
		isElementDisplayed("link_widgetName", widgetName);
	}
	
	public void switchToToolsFrame()
	{
		switchToFrame("switch_Frame");
	}
	
	public void sectionCourseTools()
	{
		switchToFrame("switch_Frame");
		isElementDisplayed("link_sectionCourseTools");
		isElementDisplayed("link_launchPad");
		isElementDisplayed("link_eBook");
		isElementDisplayed("link_gradebook");
	}
	
	public void sectionCourseToolsForSap()
	{
		switchToFrame("switch_Frame");
		isElementDisplayed("link_sectionCourseTools");
		isElementDisplayed("link_Sapling");
    }
	
	public void sectionSupportTools()
	{
		isElementDisplayed("link_supportTools");
		isElementDisplayed("link_diagnostics");
		isElementDisplayed("link_roster");
		isElementDisplayed("link_gradeRefresh");
		isElementDisplayed("link_unlinkCourse");
		isElementDisplayed("link_techSupport");
		isElementDisplayed("link_userProfile");
		isElementDisplayed("link_contentRefresh");
		isElementDisplayed("link_missingContent");
		isElementDisplayed("link_backgraoundUpdates");
		isElementDisplayed("link_gradeSync");
		
	}
	
	public void gradeRefresh()
	{
		waitAndClick("link_gradeRefresh");
		changeWindow(2);
		waitAndClick("btn_refreshGrades");
		waitForElementToBeVisible("btn_okInProgress");
		hardWait(3);
		waitAndClick("btn_okInProgress");
		closeWindow();
		changeWindow(1);
		closeWindow();
		changeWindow(0);
	}
	public void d2lGradeRefresh()
	{
		waitAndClick("link_gradeRefresh");
		changeWindow(1);
		waitAndClick("btn_refreshGrades");
		waitForElementToBeVisible("btn_okInProgress");
		hardWait(3);
		waitAndClick("btn_okInProgress");
		closeWindow();
		changeWindow(0);
	}


	public void gradeRefreshForAutoQuiz(String quizName)
	{
		waitAndClick("link_gradeRefresh");
		changeWindow(2);
		clickOnSelectRadioButton();
		clickOnAssignmentRadioButton(quizName);
		waitAndClick("btn_refreshGrades");
		waitAndClick("btn_okInProgress");
		closeWindow();
		changeWindow(1);
		closeWindow();
		changeWindow(0);
	}

	public void clickOnSelectRadioButton() {
		waitAndClick("radioBtn_selectedContent");
		logMessage("Clicked on Select Content radio button");
	}

	public void clickOnAssignmentRadioButton(String assignmentName) {
		waitAndClick("checkBox_assignment", assignmentName);
		logMessage("Click on assingment " + assignmentName + " radio button");
	}

	public void verifyGrades(String firstName)
	{
		waitAndClick("link_forGrades");
		waitAndClick("lnk_forStud", firstName);
		isStringMatching(element("txtbox_manualGrade").getAttribute("value"), "10");
		logMessage("Grades Updated Successfully by Manual Grade Sync");
		waitAndClick("link_gradecToCourseHome");
		
	}
	
	public void verifyGradesOfStud(String firstName,String lastName)
	{
		waitAndClick("link_forGrades");
		waitAndClick("lnk_forStud",lastName,firstName);
		isStringMatching(element("txtbox_grade").getAttribute("value"), "100");
		logMessage("Grades Updated Successfully by Manual Grade Sync");
//		waitAndClick("link_gradecToCourseHome");
		
	}
	
	public void launchpadRedirect()
	{
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		element("link_launchPad").click();
		changeWindow(1);
	}
	
	public void saplingRedirect() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		element("link_Sapling").click();
		changeWindow(1);
		switchWindow();
		changeWindow(2);
	}
	

	public void handleSecurityAlert() throws AWTException
	{
		
//		hardWait(10);
//		//changeWindow(1);
//		Robot robot = new Robot();
//		robot.keyPress(KeyEvent.VK_ENTER);
		
		
//		hardWait(3);
//		try {
//			Robot robot;
//			robot = new Robot();
//			robot.keyPress(KeyEvent.VK_ENTER);
//			robot.keyRelease(KeyEvent.VK_ENTER);
//		} catch (AWTException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		try {
			Runtime.getRuntime().exec("D:\\Mozilla Security Warning Handle.exe");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	public void handleSecurityAlert(String server) throws AWTException
	{

//		hardWait(10);
//		//changeWindow(1);
//		Robot robot = new Robot();
//		robot.keyPress(KeyEvent.VK_ENTER);


//		hardWait(3);
//		try {
//			Robot robot;
//			robot = new Robot();
//			robot.keyPress(KeyEvent.VK_ENTER);
//			robot.keyRelease(KeyEvent.VK_ENTER);
//		} catch (AWTException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		System.out.println("Selenium server: " + server);
		if(server.equalsIgnoreCase("local")) {
			try {
				Runtime.getRuntime().exec("D:\\Mozilla Security Warning Handle.exe");
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}
		else if(server.equalsIgnoreCase("remote")) {
			try {
				Runtime.getRuntime().exec("S:\\Mozilla Security Warning Handle.exe");
			}
			catch(Exception e) {
				e.printStackTrace();
			}
		}

	}


	public void clickEBook() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		element("link_eBook").click();
		changeWindow(1);
	}

	public void clickGradeBook() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		element("link_gradebook").click();
		changeWindow(1);
	}

	public void clickOnMacmillanDiagnosticsLink() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_diagnostics");
		changeWindow(1);
		logMessage("User has clicked on 'Macmillan Learning Diagnostics page");
	}

	public void verifyMacmillanDiagnosticsPage() {
		isElementDisplayed("txt_macmillanDiagnostics");
		isElementDisplayed("txt_diagnosticsInformation", "Institution Information");
		isElementDisplayed("txt_diagnosticsInformation", "User Information");
		isElementDisplayed("txt_diagnosticsInformation", "Course Information");
		isElementDisplayed("txt_diagnosticsInformation", "Enrollment Information");
		isElementDisplayed("txt_diagnosticsInformation", "Integration and Web Service Information");
		isElementDisplayed("txt_diagnosticsInformation", "Technical Support");
		isElementDisplayed("lnk_macmillanSupport");
		logMessage("User is on Macmillan Learning Integration Diagnostics page");
		
	}

	public void closeSecondryWindowAndComeBacktoMainWindow() {
		closeWindow();
		logMessage("Closed newly opened window");
		changeWindow(0);		
	}

	public void clickOnMacmillanRosterLink() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_roster");
		changeWindow(1);
		logMessage("User has clicked on 'Macmillan Learning Roster page");		
	}

	public void verifyMacmillanRosterPage(String instructorEmail) {
		isElementDisplayed("txt_macmillanRoster");
		isElementDisplayed("txt_userEmail", instructorEmail);

		logMessage("Instructor is on 'Macmillan Higher Education Roster' page");
	}

	public void clickOnMacmillanUserProfile() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_userProfile");
		changeWindow(1);
		logMessage("User has clicked on 'Macmillan Learning User Profile page");		
	}

	public void verifyMacmillanUserProfilePage(String instructorEmail) {
		verifyPageTitleContains("User Profile");
		isElementDisplayed("lnk_disconnectAccount");
		isElementDisplayed("txt_emailUser", instructorEmail);

		logMessage("User is on 'User Profile' page");		
	}

	public void clickOnUnLinkMacmillanCourse() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_unlinkCourse");
		changeWindow(1);
		logMessage("User has clicked on 'Unlink Macmillan Course' link");
	}

	public void clickOnRemoveContentCheckBox() {
		waitAndClick("checkbox_removeAssignment");
		logMessage("User has clicked on remove macmillan content checkbox");
	}

	public void clickOnYesDisassociateThisCourse() {
		waitAndClick("btn_disassociate");
		logMessage("User has clicked on 'Yes disassociate this course' button");
	}

	public void verifyCourseIsDisassociated() {
		isElementDisplayed("txt_noLonger");
		String courseDisassociated = element("txt_noLonger").getText();
//		CustomAssert.assertEquals(courseDisassociated.contains("no longer"), true, "[Assertion Failed]: Course is not disassociated");
		logMessage("Course is disassociated");
		closeWindow();
		changeWindow(0);
	}

	public void disassociateCourseIfAssociated() {
		clickOnRemoveContentCheckBox();
		clickOnYesDisassociateThisCourse();
		verifyCourseIsDisassociated();
	}

	public void clickOnMacmillanContentRefreshLink() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_contentRefresh");
		changeWindow(1);
		logMessage("User has clicked on 'Macmillan Content Refresh' link");
	}

	public void verifyContentRefreshPage() {
		verifyPageTitleContains("Macmillan Learning Content Refresh");
		isElementDisplayed("btn_refreshContent");

		logMessage("User is on 'Macmillan Learning Content Refresh page");
	}

	public void selectAssignmentsForProcessing()
	{
		if(element("radiobtn_allContent").isSelected())
		{
			logMessage("'All Content' link is already chechked");
		}else
		{
			element("radiobtn_allContent").click();
			logMessage("User has selected 'All Content' radio button");
		}
	}

	public void clickOnMacmillanBackgroundUpdatesLink() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_backgraoundUpdates");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Background Updates' link");
	}

	public void verifyMacmillanBackgroundUpdatesPage()
	{
		verifyPageTitleContains("Macmillan Learning Background Updates");
		isElementDisplayed("txt_backgroundUpdates");

		logMessage("User is on 'Macmillan Learning Background Updates' page");
	}


	//Verify Unlink Macmillan Course
	public void clickOnUnlinkMacmillanToolLink() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_unlinkCourse");
		changeWindow(1);
	}

	public void verifyEndCourseAssociationPage() {
		verifyPageTitleContains("End Course Association");
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		isElementDisplayed("checkbox_removeDeployedContent");
		logMessage("Instructor is on 'End Course Association' page");

	}

	public void clickOnRemoveMacmillanContent() {
		waitAndClick("checkbox_removeDeployedContent");
		logMessage("User clicked on Remove Macmillan Content checkbox");
	}

	public void disassociateCourse()
	{
		element("btn_Yes_DisassociateThisCourse").click();
		logMessage("Instructor clicked on 'Yes, Disassociate This Course' button");
	}

	public void verifyEndCourseAssociationPageAfterCourseIsDisassociated()
	{
		isElementDisplayed("txt_courseLinkSevered");
		isElementDisplayed("lnk_reconnectCourse");
		isElementDisplayed("lnk_viewAvailableCourses");

		logMessage("Course has been successfully disassociated");
	}

	public void verifyNonAssociatedToolsPage(){
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		isElementDisplayed("lnk_GettingStarted");
		logMessage("User is on Macmillan Tools page of a non-associated course");
		switchToDefaultContent();
	}

	public void clickOnRefreshContentButton()
	{
		waitAndClick("btn_refreshContent");

		logMessage("User has clicked on 'Refresh Content Links' button");
	}

	public void clickOnOKButtonOnTaskInProgressPopUp()
	{
		waitScrollAndClick("btn_ok");
		logMessage("User clicked on 'OK' button in the pop-up");
	}

	public Boolean softAssertVerifyGradeSection() {
		boolean isPresent = false;
		int count = getElementCount("checkbox_selectAll");
		if(count == 1){
			logMessage("Grade to delete");
			isPresent = true;
		}
		else if(count < 1){
			logMessage("No grades to delete");
			isPresent = false;
		}
		return isPresent;
	}

		/*
	 * 	Disassociate Course
	 */

	public void clickOnMacmillanMissingContentLink()
	{
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_missingContent");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Missing Content' link");
	}

	public void verifyMacmillanMissingContentPage()
	{
		verifyPageTitleContains("Macmillan Learning Missing Content");
		isElementDisplayed("txt_Macmillan_Higher_Education_Broken_Conten_Links");
		isElementDisplayed("btn_Delete_Selected_Links");

		logMessage("User is on 'Macmillan Higher Education Missing Content' page");
	}

	public void clickOnDeleteSelectedContentButton()
	{
		waitAndClick("btn_Delete_Selected_Links");
		logMessage("User has clicked on 'Delete Selected Content' button on 'Macmillan Higher Education Missing Content' page");
	}

	public boolean softVerifyCourseIsAssociated() {
		boolean isPresent = false;
		int count = getElementCount("lnk_GettingStarted");

		if(getElementCount("lnk_GettingStarted") > 0) {
			logMessage("Course is already dissociated");
			isPresent = false;
		}
		else {
			logMessage("Course is associated");
			isPresent = true;
		}
		return isPresent;
	}

		/*
	 * 	Macmillan Roster Information functionality
	 */

	public void clickOnMacmillanTechnicalSupportLink() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_techSupport");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Technical Support' link");
	}

	public void verifyMacmillanTechnicalSupportPage() {
		verifyPageTitleContains("The Macmillan Community");
		logMessage("User is on Technical Support page");
	}

	public void clickOnGradeLink() {
		waitAndClick("lnk_grade");
		logMessage("Clicked on grade navigation menu");
	}

	public void clickOnManageGradeLink() {
		waitAndClick("lnk_manageGrades");
		logMessage("Clicked on manage grade link");
	}

	public void clickOnMoreOptions() {
		waitAndClick("btn_moreAction");
		logMessage("Clicked on More actions button");
	}

	public void clickOnDeleteOption() {
		waitAndClick("option_delete");
		logMessage("Clicked on delete option");
	}

	public void clickOnSelectAllCheckBox() {
		waitAndClick("checkbox_selectAll");
		logMessage("Clicked on select all checkbox");
	}

	public void clickOnBtnDelete() {
		waitAndClick("btn_delete");
		logMessage("Clicked on delete button");
	}

	public void clickOnConfirmDelete() {
		waitAndClick("btn_confirmDelete");
		logMessage("Clicked on Confirm delete");
	}

	public void navigateToDeleteGradeItemPage() {
		clickOnGradeLink();
		clickOnManageGradeLink();
		clickOnMoreOptions();
		clickOnDeleteOption();
	}

	public void clearGrade() {
		clickOnSelectAllCheckBox();
		clickOnBtnDelete();
		clickOnConfirmDelete();
	}

	//Macmillan Grade Sync token registration
	public void clickOnMacmillanGradeSyncTokenRegistration() {
		hardWait(5);
		switchToDefaultContent();
		switchToFrame("switch_Frame");
		waitAndClick("link_backgraoundUpdates");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Grade Sync Token registration' link");
	}

	public void verifyMacmillanIntegrationTokenRegistrationPage() {

	}
	public void clickGettingStartedLink(String middleWareName){
		switchToFrame("switch_Frame");
		System.out.println("size : "+elements("lnk_GettingStarted",middleWareName).size());
		if(elements("lnk_GettingStarted",middleWareName).size() == 1){
			scroll(element("lnk_GettingStarted",middleWareName));
			waitAndClick("lnk_GettingStarted",middleWareName);
			switchToDefaultContent();
			changeWindow(1);
		}
		else{
			clickOnUnlinkMacmillanToolLink();
			switchToDefaultContent();
			changeWindow(1);
			isElementDisplayed("btn_Yes_DisassociateThisCourse");
			waitAndClick("btn_Yes_DisassociateThisCourse");
			logMessage("User ends the Course Association");
			hardWait(3);
			closeWindow();
			changeWindow(0);
			switchToFrame(element("iframe_ToolContent"));
			waitAndClick("lnk_GettingStarted",middleWareName);
			switchToDefaultContent();
			changeWindow(1);
		}
	}
}

