package com.qait.d2l.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class MacmillanHigherEducationInstructorProfileActions extends GetPage{
	public MacmillanHigherEducationInstructorProfileActions(final WebDriver driver) {
		super(driver, "MacmillanHigherEducationInstructorProfilePage");
	}
	
	public void verifyInstructorIsOnInstructorProfilePage()
	{
		verifyPageTitleContains("macmillan learning instructor profile");
		waitForElementToBeVisible("logo_macmillan");
		//isElementDisplayed("lbl_pageHeader");
		
		logMessage("Instructor is on 'Macmillan Higher Education Instructor Profile' page");
	}
	
	public void instructorClicksOnSubmitButton()
	{
		isElementDisplayed("btn_submit");
		element("btn_submit").click();
		
		logMessage("Instructor has clicked on 'Submit' button on 'Macmillan Higher Education Instructor Profile' page");
	}
	
	public void verifyInformationInInputFieldsAndSubmit(String firstName, String lastName, String email)
	{
		/*
		 * if(element("input_firstName").getText().equals(firstName) &&
		 * element("input_lastName").getText().equals(lastName) &&
		 * element("input_email").getText().equals(email))
		 * 
		 * logMessage("All input fields on the page has values auto-populated");
		 * instructorClicksOnSubmitButton();
		 * 
		 * else element("input_firstName").sendKeys(firstName);
		 * element("input_lastName").sendKeys(lastName);
		 * element("input_email").sendKeys(email);
		 */
			
			logMessage("Instructor has entered values in all the input fields");
			instructorClicksOnSubmitButton();
		
	}
}
