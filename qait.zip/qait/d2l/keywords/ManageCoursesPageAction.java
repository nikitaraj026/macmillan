package com.qait.d2l.keywords;



import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class ManageCoursesPageAction extends GetPage {

	public static String courseOfferingName = ""; 
	
	public ManageCoursesPageAction(WebDriver driver) {
		super(driver, "ManageCoursesPage");
	}

	public void verifyManageCoursesDisplayed() {
		isElementDisplayed("iframe_manageCourses");
		switchToFrame("iframe_manageCourses");
		isElementDisplayed("txt_manageCoursesHeading");
	}

	public void verifyCreateNewCourseBtnDisplayed() {
		isElementDisplayed("btn_createNewCourse");
	}
	
	public void clickCreateNewCourseBtn() {
		waitAndClick("btn_createNewCourse");
	}

	public void verifyCourseCreationStep1Displayed() {
		isElementDisplayed("txt_byTextValue", "Step 1: Choose Course Creation Type");
	}
	
	public void verifyCreateNewCourseNeverOfferedBeforeOptionSelected() {
		verifyRadioButtonSelected("radiobtn_chooseCourseCreationType",
				"Create a new course template and a new course offering that has never been offered before.");
	}
	
	public void clickNextBtn() {
		waitAndClick("btn_next");
	}
	
	public void verifyCourseCreationStep2Displayed() {
		isElementDisplayed("txt_byTextValue", "Step 2: Enter Template Information");
	}
	
	public void fillAndSubmitCourseCreationStep2(String courseName, String courseCode, String department) {
		fillText("txtinput_courseTemplateName", courseName);
		fillText("txtinput_courseTemplateCode", courseCode);
		selectTextFromDropDown("select_department", department);
		clickNextBtn();
	}
	
	public void verifyCourseCreationStep3Displayed() {
		isElementDisplayed("txt_byTextValue", "Step 3: Enter Course Information");
	}

	public void verifyCourseCreationStep3Data(String courseName, String courseCode, String department) {
		isElementDisplayed("txt_courseTemplateName", courseName);
		isElementDisplayed("txt_courseTemplateCode", courseCode);
		isElementDisplayed("txt_department", department);
	}

	public void fillAndSubmitCourseCreationStep3(String offeringName, String offeringCode, String semester) {
		fillText("txtinput_courseOfferingName", offeringName);
		fillText("txtinput_courseOfferingCode", offeringCode);
		selectTextFromDropDown("select_semester", semester);
		clickNextBtn();
	}

	public void verifyCourseCreationStep4Displayed() {
		isElementDisplayed("txt_byTextValue", "Step 4: Confirm Course Template and Offering Create Information");
	}

	public void verifyCourseCreationStep4Data(String courseName, String courseCode, String department,
			String offeringName, String offeringCode, String semester) {
		isElementDisplayed("txt_courseTemplateName", courseName);
		isElementDisplayed("txt_courseTemplateCode", courseCode);
		isElementDisplayed("txt_department", department);
		isElementDisplayed("txt_courseOfferingName", offeringName);
		isElementDisplayed("txt_courseOfferingCode", offeringCode);
		isElementDisplayed("txt_semester", semester);
	}

	public void clickCreateBtn() {
		waitAndClick("btn_create");
	}

	public void verifyCourseSuccessfullyCreatedMessage(String courseName, String offeringName) {
		isElementDisplayed("txt_courseCreationMessage");
		String message = element("txt_courseCreationMessage").getText().trim();
		customAssert.customAssertTrue(message.contains("Template " + courseName + " was successfully created."), 
				"[Assertion Failed] : Course creation message is '" + message + "'");
		customAssert.customAssertTrue(message.contains("Course Offering " + offeringName + " was successfully created."), 
				"[Assertion Failed] : Course creation message is '" + message + "'");
		courseOfferingName = offeringName;
	}

	public void clickDoneBtn() {
		waitAndClick("btn_done");
	}
	
	
}