package com.qait.d2l.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class UsersPageActon extends GetPage {

	public static String instUserName = "";
	public static String studUserName = "";

	public UsersPageActon(WebDriver driver) {
		super(driver, "UsersPage");
	}

	public void verifyUsersPageDisplayed() {
		isElementDisplayed("tab_Users", "Users");
	}

	public void verifyCreateNewUserBtnDisplayed() {
		isElementDisplayed("btn_newUser");
	}

	public void clickNewUserBtn() {
		waitAndClick("btn_newUser");
	}

	public void verifyCreateUserSectionDisplayed() {
		isElementDisplayed("txt_anyHeading", "Create User");
	}

	public void verifyUserInformationFormDisplayed() {
		isElementDisplayed("txt_anyHeading", "User Information");
	}

	public void fillUserInformationForm(String firstName, String lastName, String email, String role, String username,
			String password) {
		hardWait(2);
		fillText("txtinput_firstName", firstName);
		fillText("txtinput_lastName", lastName);
		hardWait(4);
//		fillText("txtinput_email", email);
		executeJavascript(
				"document.getElementsByClassName(\"d_edt vui-input f-13585-legacy-input-keypress-events\").item(4).value=\""
						+ email + "\"");
		selectTextFromDropDown("select_role", role);
		scrollToBottom();
		fillText("txtinput_username", username);
		scrollToBottom();
		element("chkbox_manuallySetPassword").click();
		// waitScrollAndClick("chkbox_manuallySetPassword");
		// waitAndClick("chkbox_manuallySetPassword");
		hardWait(3);
		fillText("txtinput_password", password);
		if (role.equals("Instructor"))
			instUserName = username;
		else if (role.equals("Student"))
			studUserName = username;
	}

	public void clickSaveAndNewBtn() {
		waitScrollAndClick("btn_saveAndNew");
		hardWait(10);
	}

	public void clickSaveBtn() {
		waitScrollAndClick("btn_save");
		// hardWait(10);
	}

	public void verifyUserCreatedSuccessfully() {
		isElementDisplayed("txt_createdSuccessfullyAlert");
	}
}