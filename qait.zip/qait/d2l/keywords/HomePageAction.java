package com.qait.d2l.keywords;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
//import com.thoughtworks.selenium.webdriven.commands.GetTitle;

public class HomePageAction extends GetPage {

	public HomePageAction(WebDriver driver) {
		super(driver, "HomePage");
	}

	public void verifyHomePageDisplayed(String firstName, String lastName) {
		// verifyTextOfElementIsCorrect("txt_username", firstName + " " +
		// lastName );
		List<WebElement> loginLink = elements("link_loginPage");
		wait.hardWait(5);
		customAssert.customAssertEquals(loginLink.get(0).getText(), "Email",
				"Assertin Failed: Email is not mathced as expected");
		customAssert.customAssertEquals(loginLink.get(1).getText(), "Calendar",
				"Assertin Failed: Calendar is not mathced as expected");
		customAssert.customAssertEquals(loginLink.get(2).getText(), "ePortfolio",
				"Assertin Failed: ePortfolio is not mathced as expected");
		customAssert.customAssertEquals(loginLink.get(3).getText(), "Learning Repository",
				"Assertin Failed: Learning Repository is not mathced as expected");
		logMessage("Assertion Passed: Verified Home Page with valid user name and password");
	}

	public void clickAdminToolsBtn() {
		wait.hardWait(5);
//		waitAndClick("btn_adminTools");
		executeJavascript(
				"document.getElementsByTagName('d2l-navigation').item(0).firstChild.getElementsByClassName('d2l-navigation-s-admin-"
						+ "menu').item(0).getElementsByClassName('d2l-dropdown-opener').item(0).shadowRoot.lastChild.shadowRoot.querySelector('button"
						+ "[title=\"Admin Tools\"]').click()");

	}

	public void clickAdminToolsCourseManagementLink() {
		hardWait(5);
		waitForElementToBeVisible("link_adminToolOption", "Course Management");
		waitScrollAndClick("link_adminToolOption", "Course Management");
	}

	public void clickAdminToolsUsersLink() {
		waitAndClick("link_adminToolOption", "Users");
	}

	public void clickAdminToolsRemotePluginsLink() {
		wait.hardWait(6);
		waitAndClick("link_adminToolOption", "Remote Plugins");
		System.out.println("remotePluginNames");
	}

	private WebElement findByShadowRoot(WebDriver driver, String elementLocator) {
		return expandRootElement(element(elementLocator));
	}

	public void clickNavigationItem(int itemIndex) {// itemIndex-> lies between 0-6
		executeJavascript("document.getElementsByTagName('d2l-navigation-button-notification-icon')." + "item("
				+ itemIndex
				+ ").shadowRoot.querySelector('d2l-navigation-button').shadowRoot.querySelector('button').click()");
	}

	public void sendDataInSearchField(String dataToSearch) {
		executeJavascript("document.querySelector('d2l-input-search').shadowRoot.querySelector"
				+ "('.d2l-input-search-container').getElementsByTagName('input').item(0).value=\"" + dataToSearch
				+ "\"");

	}

	public void clickSearchIcon() {
		executeJavascript("document.querySelector('d2l-input-search').shadowRoot.querySelector('d2l-button-icon')."
				+ "shadowRoot.querySelector('button').click()");
	}

	public void clickShowAllCourses() {
		executeJavascript(
				"document.querySelector('d2l-my-courses').shadowRoot.querySelector('d2l-my-courses-content-animated')"
						+ ".shadowRoot.querySelector('.my-courses-content').querySelector('#viewAllCourses').querySelector('h3').click();");
	}

	public void sendTextInSearchBoxOnShowAllCourses(String searchText) {
		executeJavascript(
				"document.querySelector('d2l-my-courses').shadowRoot.querySelector('d2l-my-courses-content-animated')."
						+ "shadowRoot.querySelector('#allCoursesPlaceholder').getElementsByTagName('d2l-all-courses').item(0)."
						+ "shadowRoot.querySelector('#all-courses').querySelector('#search-and-filter').querySelector('.search-and-filter-row')."
						+ "querySelector('#search-widget').shadowRoot.querySelector('d2l-dropdown').querySelector('#opener').getElementsByTagName"
						+ "('iron-input').item(0).getElementsByTagName('input').item(0).value=\"" + searchText + "\";");
	}

	public void searchUsingAdvancedSearchButton(String courseName) {
		waitForElementToBeVisible("btnAdvanceSearch");
		waitAndClick("btnAdvanceSearch");
		waitForElementToBeVisible("txtbox_Search");
		hardWait(5);
		 executeJavascript("document.getElementById('Search').value=\"" + courseName +"\"");
		 hardWait(6);
	      executeJavascript(
		 "document.getElementsByTagName('d2l-input-search').item(0).shadowRoot.querySelector('.d2l-input-search-search').click()");
		// waitAndClick("clickon_Course");
	      hardWait(3);
	      executeJavascript("document.querySelector('table[alternating-rows] a[class=\"d2l-link\"]').click();");
		 logMessage("clicked on course link");
	}

	public void clickOnCourseLink(String courseName) {
		hardWait(3);
		clickNavigationItem(1);// clicking on SelectCourse
		logMessage("clciked on select Course button");
		wait.hardWait(3);
		waitAndClick("linkcourseName", courseName);
	}

	public void searchAndOpenCourse(String courseName) {
		hardWait(3);
		clickNavigationItem(1);// clicking on SelectCourse
		logMessage("clciked on select Course button");
		wait.hardWait(3);
		searchUsingAdvancedSearchButton(courseName);
		hardWait(2);
		/*
		 * waitForElementToBeVisible("courseLink", courseName);
		 * waitScrollAndClick("courseLink", courseName); logMessage("Clicked on Course"
		 * + courseName);
		 */
	}

	public void searchAndOpenCourse(String courseName, String env) {
		hardWait(3);
		clickNavigationItem(1);// clicking on SelectCourse
		logMessage("clciked on select Course button");
		wait.hardWait(3);
		if (env.equalsIgnoreCase("lt")) {
			searchUsingAdvancedSearchButton(courseName);

//		sendDataInSearchField(courseName);
//		fillText("txtinput_searchCourse",courseName);
			hardWait(2);
//		clickSearchIcon();
			logMessage("Clicked on search icon");
//		waitAndClick("option_selectCourseDropdown", courseName);
			//waitForElementToBeVisible("courseLink", courseName);
			//waitScrollAndClick("courseLink", courseName);
			logMessage("Clicked on Course" + courseName);
		} else {
			hardWait(4);
			waitAndClick("linkcourseName", courseName);
		}

	}

	public void studentNavigateToCourse(String courseName) {
		hardWait(3);
		clickNavigationItem(1);// clicking on SelectCourse
		logMessage("clciked on select Course button");
		waitAndClick("option_selectCourseDropdown", courseName);
	}

	public void handleGotItModalContent() {
		wait.resetImplicitTimeout(3);
		if (!verifyElementNotDisplayed("btn_gotIt"))
			waitAndClick("btn_gotIt");
		wait.resetImplicitTimeout(wait.getTimeout());
	}

}