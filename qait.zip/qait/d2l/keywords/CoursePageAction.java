package com.qait.d2l.keywords;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.yaml.snakeyaml.Yaml;

import com.qait.automation.getpageobjects.GetPage;

public class CoursePageAction extends GetPage {

	public CoursePageAction(WebDriver driver) {
		super(driver, "CoursePage");
	}

//**************Yaml Read Write**************************
	public void writeDataToYaml(Map<String, Object> data) {
		Yaml yaml = new Yaml();
		FileWriter writer = null;
		try {
			writer = new FileWriter("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "D2L" + File.separator + "DynamicTestData.yml");
			yaml.dump(data, writer);
			System.out.println("Written the test data");
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static Map<String, Object> parseMap(Map<String, Object> object, String token) {
		if (token.contains(".")) {
			String[] st = token.split("\\.");
			object = parseMap((Map<String, Object>) object.get(st[0]), token.replace(st[0] + ".", ""));
		}
		return object;
	}

	private static String getMapValue(Map<String, Object> object, String token) {
		// TODO: check for proper yaml token string based on presence of '.'
		String[] st = token.split("\\.");
		return parseMap(object, token).get(st[st.length - 1]).toString();
	}

	public String readDataFromYaml(String token) {
		Reader doc = null;
		try {
			doc = new FileReader("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "D2L" + File.separator + "DynamicTestData.yml");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		Yaml yaml = new Yaml();
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);
		return getMapValue(object, token);
	}
//**************************************************************************	

	public void verifyCoursePageDisplayed(String courseName) {
		isElementDisplayed("link_navbar", courseName);
	}

	public void clickNavTab(String tabName) {
		waitAndClick("link_navbar", tabName);
	}

	public void clickOnUnenrollLink() {
		waitAndClick("lnk_unenrollStud");
		logMessage("Clicked on unenroll link");
	}

	public void clickOnConfirmStudentEnrollment() {
		waitAndClick("btn_confirmYesStudUnenroll");
		logMessage("Clicked on Yes to confirm student enrollment");
	}

	public void selectAndUnenrollStudent() {
		List<WebElement> checkBoxStud;
		int numberOfStudent = getElementCount("checkBox_student");
		if (numberOfStudent > 0) {
			checkBoxStud = elements("checkBox_student");
			for (WebElement element : checkBoxStud) {
				element.click();
			}
			logMessage("All student are checked");
			clickOnUnenrollLink();
			clickOnConfirmStudentEnrollment();
		} else {
			logMessage("Student are already unenrolled from course");
		}
	}

	public void verifySectionHeading(String sectionName) {
		isElementDisplayed("txt_sectionHeading", sectionName);
		wait.hardWait(3);
	}

	public void verifySectionHeading1(String sectionName) {
		// isElementDisplayed("txt_sectionHeading1", sectionName);
		List<WebElement> tabName = elements("txt_sectionHeading1");
		customAssert.customAssertEquals(tabName.get(0).getText(), "Homepages",
				"Assertion Failed: Homepages is not matched as expected");
		customAssert.customAssertEquals(tabName.get(1).getText(), "Widgets",
				"Assertion Failed: Widgets is not matched as expected");
		logMessage("Assertion Passed: Verified Tab Name Of Create Fome Page");
	}

	public void verifySectionHeading2(String sectionName) {
		// isElementDisplayed("txt_sectionHeading2", sectionName);
	}

	public void selectAddParticipants(String option) {
		waitAndClick("btn_addParticipants");
		logMessage("Clicked on button Add Participants");
//		waitAndClick("option_addParticipantsDropdown", option);
		waitForElementToBeVisible("option_AddExistingUser");
		waitAndClick("option_AddExistingUser");
	}

	public void searchUser(String userName, String role) {
//		selectTextFromDropDown("select_roleEnrollmentOptions", role);
		waitForElementToBeVisible("search_container");
		isElementDisplayed("search_container");
//		fillText("txtinput_searchFor", userName);
//		sendKeys(element("txtinput_searchFor"), userName);
//		isElementDisplayed("txtinput_searchFor");
//		waitForElementToBeVisible("txtinput_searchFor");
		executeJavascriptWithRep("document.getElementsByTagName('d2l-input-" + "search').item(0).value=arguments[0]",
				userName);

		hardWait(2);
//		waitAndClick("btn_searchFor");
		executeJavascript("document.getElementsByTagName('d2l-input-search').item(0)."
				+ "shadowRoot.querySelector('.d2l-input-search-search').shadowRoot.querySelector('button').click()");
	}

	public void searchUserByAnotherMethod(String userName, String role) {
		isElementDisplayed("search_container");
		waitForElementToBeVisible("search_container");
		executeJavascriptWithRep("document.querySelector('d2l-input-search[label=\"Search\"]').value=arguments[0]",
				userName);
		hardWait(2);
		executeJavascript("document.getElementsByClassName('d2l-button-icon "
				+ "style-scope x-scope d2l-icon-0').item(1).click()");
	}

	public void verifyExistingUserDisplayed(String username) {
		isElementDisplayed("txt_usernameExistingUser", username);
	}

	public void selectExistingUser(String username, String role) {
		scroll(element("checkbox_selectUser", username));
		waitAndClick("checkbox_selectUser", username);
		selectTextFromDropDown("select_userRole", username, role);
	}

	public void clickEnrollSelectedUsersBtn() {
		waitAndClick("btn_enrollSelectedUsers");
	}

	public void verifySuccessfullEnrollmentMessage(String num) {
		isElementDisplayed("txt_successfullEnrollmentMessage", num);
	}

	public void verifyUsernameSuccessfullEnroll(String username) {
		isElementDisplayed("txt_userNameSuccessfullEnroll", username);
	}

	public void clickAddMoreParticipantsBtn() {
		waitAndClick("btn_addMoreParticipants");
	}

	public void clickDoneBtn() {
		waitAndClick("btn_done");
	}

	public void clickLinkUnderCourseAdministration(String linkName) {
		waitScrollAndClick("link_linksUnderCourseAdmin", linkName);
	}

	public void verifyHomepagesTabOpened() {
		isElementDisplayed("btn_createHomepage");
	}

	public void clickCreateHomepageBtn() {
		hardWait(2);
		waitAndClick("btn_createHomepage");
	}

	public void fillHomepageName(String homepageName) {
		fillText("txtinput_homePageName", homepageName);
	}

	public void selectHomepageType(String type) {
		selectTextFromDropDown("select_typeHomePage", type);
	}

	public void addWidgetsToHomepage(String widgetName) {
		scrollToBottom();
		element("btn_addWidgetsMainContentPanel").click();
		// waitAndClick("btn_addWidgetsMainContentPanel");
		isElementDisplayed("iframe_addWidgets");
		switchToFrame("iframe_addWidgets");
		isElementDisplayed("txt_addWidgetsHeading");
//		fillText("txtinput_search_addWidgets", widgetName);
		executeJavascriptWithRep(
				"document.getElementsByClassName('d2l-search-simple-wc-input').item(0).value=arguments[0]",
				widgetName);
//		waitAndClick("btn_search_addWidgets");
		executeJavascript(
				"document.querySelector('d2l-input-search').shadowRoot.querySelector('.d2l-input-search-container')."
				+ "querySelector('.d2l-input-search-search').click()");
		logMessage("Clicked search button");
		waitForElementToBeClickable(element("checkbox_item_addWidgets", widgetName));
		wait.hardWait(5);
		clickUsingJavaScript("checkbox_item_addWidgets", widgetName);
		logMessage("Clicked on check box " + widgetName);
		// waitAndClick("checkbox_item_addWidgets", widgetName);
		waitForElementToBeClickable(element("btn_add_addWidgets"));
		wait.hardWait(5);
		clickUsingJavaScript("btn_add_addWidgets");
		logMessage("Click on Add widget button");
		// waitAndClick("btn_add_addWidgets");

		switchToDefaultContent();
	}

	public void verifyWidgetAdded(String widgetName) {
		isElementDisplayed("txt_itemHeadingInWidgets", widgetName);
	}

	public void clickSaveAndCloseBtn() {
		waitAndClick("btn_saveAndClose");
	}

	public void verifyFlashMessage(String message) {
		wait.hardWait(4);
		verifyTextOfElementIsCorrect("txt_homePageCreationMessage", message);
	}

	public void selectAndApplyHomepage(String homepageName) {
		selectTextFromDropDown("select_activeHomePage", homepageName);
		waitAndClick("btn_applyHomePage");
	}
	
}