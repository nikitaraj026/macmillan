package com.qait.d2l.keywords;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.moodle.keywords.FandEPageActionsLaunchpad;

public class LaunchpadPageActions extends GetPage {

	FandEPageActionsLaunchpad fnePage;

	public LaunchpadPageActions(WebDriver driver) {
		super(driver, "PXPage");
		fnePage = new FandEPageActionsLaunchpad(driver);
	}

	public void verifyPxFnePageOpens() {
		handleAlert();

		isElementDisplayed("button_Home");
		logMessage("[Assertion Passed]: User is on the PX FNE Page");
	}

	public void userClosesPXWindow() {
		closeWindow();
		changeWindow(1);
	}

	public void userClosesPXWindowAndGoToPrimaryWindow() {
		closeWindow();
		changeWindow(0);
	}

	public void verifyPXCourseHomePage() {
		isElementDisplayed("label_LaunchPad");
		logMessage("User verifies that he is on a launchpad course home page");
	}

	public void verifyEbookSectionIsOpen() {
		isElementDisplayed("list_ebook");
		logMessage("User verfies that he is navigated to the ebook section");
	}

	public void verifyGradeBookPageOpens() {
		switchToFrame(element("iframe_easyXDMDefault"));
		isElementDisplayed("breadCrumb_Gradebook");
		switchToDefaultContent();
		logMessage("User is on the Gradebook page");
	}

	/**
	 * Create a Quiz Assignment
	 */
	public void createQuizAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate, boolean addQuestions, String chapterNumber, String questionBank) {
		createAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		if (addQuestions)
			fnePage.addQuestions(chapterNumber, questionBank);
		fnePage.clickDoneEditingAndHomeButton();
	}

	public void createQuizAssessmentForSapling(String assignmentName) {
		removePreviousAssessment(assignmentName);
		selectTextFromDropDown("drpDown_AddActivity", "Assessment");
		fillText("assessmentName", assignmentName);
		List<WebElement> list = elements("checkbox_date");
		scroll(list.get(0));
		scrollDownWithGivenDimension(-300);
		list.get(0).click();
		list.get(1).click();
		wait.hardWait(4);
		executeJavascript("document.querySelectorAll('.datePicker-date.availableDate.hasDatepicker')[1].value='"
				+ getNextDate() + "'");
		scroll(element("btn_saveNContinue"));
		waitAndClick("btn_saveNContinue");
		switchToFrame("iframe_description");
		wait.hardWait(15);
		waitAndClick("questionList");
		waitAndClick("btn_addQuestion");
		closeWindow();
		changeWindow(0);
	}

	public String getNextDate() {
		Date today = new Date();
		SimpleDateFormat formattedDate = new SimpleDateFormat("MMM dd, YYYY");
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 1); // number of days to add
		return (String) (formattedDate.format(c.getTime()));
	}

	public void removePreviousAssessment(String assessName) {
		List<WebElement> assessList = elements("btn_assessment", assessName);
		for (int i = 0; i < assessList.size(); i++) {
			assessList.get(i).click();
			wait.hardWait(2);
			waitAndClick("link_delete", assessName);
		}
		waitAndClick("btn_yes");
		logMessage("Remove all the assessment");
	}

	public void clickAddNewLink() {
		waitAndScrollToElement("link_addNew");
		waitForElementToBeVisible("link_addNew");
		// js.executeScript("document.getElementsByClassName('lnkTopCreateContent')[0].click();");
		hardWait(3);
		// executeJavascript("document.querySelector('.lnkTopCreateContent').click()");
		hoverClick(element("link_addNew"));
		logMessage("Clicked 'Add New' Link");
	}

	public void verifyModalWindowTitle(String expectedTitle) {
		waitForElementToBeVisible("txt_titleModal", expectedTitle);
		isElementDisplayed("txt_titleModal", expectedTitle);
	}

	public void clickAssignmentType(String assignmentType) {
		waitAndClick("link_assignmentType", assignmentType);
	}

	public void createNewAssignment(String assignmentType) {
		clickAddNewLink();
		verifyModalWindowTitle("Add a new assignment");
		clickAssignmentType(assignmentType);
	}

	/**
	 * 
	 * FandE Page Methods
	 */

	public void verifyHeadingOfPage(String expected) {
		hardWait(10);
		waitForElementToBeVisible("txt_fneTitle");
		verifyTextOfElementIsCorrect("txt_fneTitle", expected);
		logMessage("Assertion Passed : Heading Of FandE Page is '" + expected + "'");
	}

	public void fillTitleOnBasicInfo(String newTitle) {
		waitForLoaderToDisappear();
		hardWait(1);
		waitForElementToBeVisible("inp_title");
		element("inp_title").clear();
		element("inp_title").sendKeys(newTitle);
	}

	public void clickOnSaveButtonOnBasicInfo() {
		element("btn_saveBasicInfo").click();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		hardWait(2);
		logMessage("Title of Assignment changed");
	}

	public void clickSettingsTab() {
		waitForElementToBeVisible("btn_settingsTab");
		element("btn_settingsTab").click();
		waitForLoaderToDisappear();
		logMessage("User clicked on Settings Tab");
		// waitForElementToBeVisible(("txt_sectionTitle"));
	}

	public void enterNumberOfAttemptsOnSettingsTab(String number) {
		switchToDefaultContent();
		selectTextFromDropDown("select_numberOfAttempts", number);
		logMessage("Number of attempts sets to: " + number);
	}

	public void clickSaveButtonOnSettingsTab() {
		switchToDefaultContent();
		waitAndClick("btn_save");
		logMessage("Clicked on 'Save' Button on Setting Tab.");
	}

	// Clicks 'Assignment' Tab
	public void clickAssignmentTab() {
		waitForElementToBeVisible("btn_assignmentTab");
		element("btn_assignmentTab").click();
		waitForLoaderToDisappear();
		logMessage("User clicked on Assignment Tab");
		waitForElementToBeVisible("txt_dueDateAndTime");
	}

	public void selectDateInDatePicker(String date) {
		waitForElementToBeVisible("datePicker_goNext");
		element("datePicker_goNext").click();
		waitForElementToBeVisible("datePicker_date", date);
		element("datePicker_date", date).click();
		logMessage("Date selected from Calendar: " + date);
	}

	/**
	 * Fills Grade Points input field(in Assignment Tab)
	 * 
	 * @param gradePoints
	 */
	public void fillGradePointsForAssignment(String gradePoints) {
		waitForElementToBeVisible("txtinput_gradePoints");
		fillText("txtinput_gradePoints", gradePoints);
	}

	// Clicks 'Assign' Button(in Assignment Tab)
	public void clickAssignButtonFromAssignmentTab() {
		waitForElementToBeVisible("btn_assignInAssignmentTab");
		element("btn_assignInAssignmentTab").click();
		handleAlert();
		waitForLoaderToDisappear();
		hardWait(2);// wait till unassign button appeared
		logMessage("Clicked 'Assign' Button from Assignment Settings");
		waitForElementToBeVisible("btn_unassignInAssignmentTab");
	}

	public void assignAssignment(String assignmentScore, String date) {
		clickAssignmentTab();
		selectDateInDatePicker(date);
		fillGradePointsForAssignment(assignmentScore);
		clickAssignButtonFromAssignmentTab();
	}

	public void createAssignmentCategory1(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createNewAssignment(assignmentType);
		verifyHeadingOfPage(assignmentType);
		fillTitleOnBasicInfo(assignmentName);
		clickOnSaveButtonOnBasicInfo();
		clickSettingsTab();
		enterNumberOfAttemptsOnSettingsTab("Unlimited");
		clickSaveButtonOnSettingsTab();
		waitForLoaderToDisappear();
		hardWait(10);
		if (assign)
			assignAssignment(assignmentScore, dueDate);
	}

	public void clickTOCItem(String linkName) {
		isElementDisplayed("link_assignedItemTOC", linkName);
		// click(element("link_itemTOC",linkName));
		waitScrollAndClick("link_assignedItemTOC", linkName);
		logMessage("Clicked TOC Item '" + linkName + "'");
		waitForLoaderToDisappear();
	}

	public void clickTOCItemAssignButton(String linkName) {
		waitAndScrollToElement("link_itemTOC", linkName);
		hardWait(4);
		@SuppressWarnings("unused")
		int i = -1;
		for (WebElement el : elements("list_contentTOC")) {
			if (el.getText().contains(linkName)) {
				i++;
				break;
			}
		}
//		executeJavascript("$('span:contains(\""+linkName+"\")').trigger('mouseenter');");
		hover(element("link_itemTOC", linkName));
		hardWait(2);
		isElementDisplayed("link_assignItemTOC", linkName);
//		click(element("link_assignItemTOC", linkName));
		waitAndClick("link_assignItemTOC", linkName);

		hardWait(3);
		// executeJavascript("document.getElementsByClassName('faceplate-item-assign')["+i+"].click()");
		logMessage("Clicked Assign Button for TOC Item '" + linkName + "'");
	}

	public void clickNextMonthButtonFromDatePicker() {
		hardWait(2);
		// waitAndClick("datePicker_goNext");
		click(element("datePicker_goNext"));
	}

	public void clickDateFromDatePicker(String date) {
		element("datePicker_date", date).click();
	}

	public void fillGradePointsManageAssignmentWidget(String points) {
		fillText("txtinput_gradePointsManageAssignment", points);
	}

	public void clickManageAssignmentAssignButtonNew() {
		waitForElementToBeVisible("btn_assignManageAssignment");
		executeJavascript(
				"return document.evaluate(\"//input[contains(@class,'assign-showCalendar-close')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click();");
		logMessage("Clicked Assign Button.");
		// assignButton.click();
		// hardWait(2);
		// driver.switchTo().alert().accept();
		// System.out.println("Handling First Alert...");
		// driver.switchTo().alert().accept();
		// System.out.println("Handling Second Alert...");
		// waitForElementToDisappear("btn_assignManageAssignment");
		// hardWait(2);
	}

	public void assignTOCItem(String linkName, String nextMonthDate, boolean fillGradePoints, String gradePoints) {
		clickTOCItemAssignButton(linkName);
		// verifyWidgetDisplayed();
		// verifyWidgetTitle("Manage Assignment");
		waitForElementToBeVisible("assignWindow");
		clickNextMonthButtonFromDatePicker();
		clickDateFromDatePicker(nextMonthDate);
		if (fillGradePoints)
			fillGradePointsManageAssignmentWidget(gradePoints);
		clickManageAssignmentAssignButtonNew();
	}

	public void hoverUserNameMenu() {
		hardWait(2);
		// hover(element("link_usernameMenu"));
		executeJavascript("document.getElementsByClassName('hidden-menu profileMenu')[1].style.display='block';");
	}

	public void clickUserMenuItem(String itemName) {
		waitForElementToBeVisible("link_usernameMenuItem", itemName);
		hardWait(2);
		element("link_usernameMenuItem", itemName).click();
		logMessage("Clicked User Name Menu Item '" + itemName + "'");
	}

	public void launchPadLogout() {
		clickElementIfVisible("btn_closeToastMessage");
		hoverUserNameMenu();
		// element("link_usernameMenu").click();
		clickUserMenuItem("Sign Out");
		waitForElementToBeVisible("link_helpMenu");
//		try{
//			hoverUserNameMenu();
//			clickUserMenuItem("Sign Out");
//		}catch (Exception e) {
//			System.out.println("User already signed out");
//		}
	}

	public void removePreviousAssessmentForSap(String assessName) {
		List<WebElement> assessList = elements("btn_assessment", assessName);
		List<WebElement> deleteLinkList = elements("link_delete", assessName);
		while (assessList.size() > 0) {
			assessList.get(0).click();
			wait.hardWait(2);
			deleteLinkList.get(0).click();
			refreshPage();
			assessList = elements("btn_assessment", assessName);
			hardWait(2);
			waitAndClick("btn_yes");
			deleteLinkList = elements("link_delete", assessName);
		}

		logMessage("Remove all the assessment");
	}

	public void createQuizAssessmentForSapling(String assignmentName, String testRunEnvironment) {

		removePreviousAssessmentForSap(assignmentName);
		selectTextFromDropDown("drpDown_AddActivity", "Assessment");
		fillText("assessmentName", assignmentName);
		List<WebElement> list = elements("checkbox_date");
		scroll(list.get(0));
		scrollDownWithGivenDimension(-300);
		list.get(0).click();
		list.get(1).click();
		wait.hardWait(4);
		executeJavascript("document.querySelectorAll('.datePicker-date.availableDate.hasDatepicker')[1].value='"
				+ getNextDate() + "'");
		scroll(element("btn_saveNContinue"));
		waitAndClick("btn_saveNContinue");
		switchToFrame("iframe_description");
		wait.hardWait(4);
		waitAndClick("btn_QuestionBank");
		wait.hardWait(4);
		switchToFrame("iframe_QuestionList");
		if(testRunEnvironment.equalsIgnoreCase("prod"))
			element("input_filter").sendKeys("Determine whether a verbal representation of a relation is a function and explain why.");
		hardWait(5);
//		waitAndClick("");
		waitAndClick("questionList");
		waitAndClick("btn_addQuestion");
		System.out.println("Ho gya");
		closeWindow();
		changeWindow(0);
	}

	public void clickOnLPHomeLink() {
		isElementDisplayed("btn_LPHome");
		hardWait(2);
		hoverClick(element("btn_LPHome"));
		logMessage("User has clicked on LaunchPad homepage");

	}

}
