package com.qait.d2l.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class StudentHomePageAction extends GetPage {

	public StudentHomePageAction(WebDriver driver) {
		super(driver, "StudentHomePage");
	}
	
	public void clickCourseTitle(String courseName)
	{
		hardWait(5);
		waitAndClick("link_courseTitle", courseName);
	}
	
	public void clickContentTab()
	{
		waitAndClick("link_Content");
	}
	
	public void clickModuleLink()
	{
		//waitAndClick("link_module");
		logMessage("Module Clicked !");
	}
	
	public void clickManualQuiz() {
	   hardWait(5);
	   waitAndScrollToElement("link_quiz", "Manual_Quiz");
	   element("link_quiz", "Manual_Quiz").click();
	   
	}
	
	public void agreeLegalTerms() {
		switchToFrame("iframe1");
		scroll(element("check_box"));
		element("check_box").click();
		element("btn_agree").click();
		waitForLoaderToDisappear();
	}
	public void clickSaplingAutoQuiz() {
		   hardWait(3);
		   waitAndScrollToElement("link_Quiz", "Sapling_auto_quiz");
		   element("link_Quiz", "Sapling_auto_quiz").click();
		}

	
	public void clickAutoQuiz() {
		hardWait(3);
		waitAndScrollToElement("lnk_quiz", "Auto_Quiz");
		element("lnk_quiz", "Auto_Quiz").click();
	}
	
	public void launchQuiz() {
		switchToFrame("iframe");
		waitAndClick("link_here");
		changeWindow(1);
		//verifyPageTitleContains("Eula"); Remove comment
		hardWait(10);
	}
	
	public void launchQuizSSOComplete() {
		//switchToFrame("iframe");
		//waitAndClick("link_here");
		changeWindow(1);
	}

	public void clickOnChapterAssignment() {
		hardWait(3);
		element("lnk_quiz", "Chapter").click();
	}
	
}
