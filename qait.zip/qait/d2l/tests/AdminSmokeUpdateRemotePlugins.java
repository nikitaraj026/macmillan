package com.qait.d2l.tests;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import static com.qait.automation.utils.YamlReader.getYamlValues;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class AdminSmokeUpdateRemotePlugins extends Parent_Test{

	D2LTestSessionInitiator d2l;
	String baseUrl;
	String adminUserName, adminPassword, adminFirstName, adminLastName;
	String courseName;
	String remotePlugin1, remotePlugin2;
	Map<String, Object> remotePlugins;
	List<String> remotePluginNames;
	
	private void _initVars() {
		baseUrl = getData("baseUrl");
		adminUserName = getData("users.admin.userName");
		adminPassword = getData("users.admin.password");
		adminFirstName = getData("users.admin.firstName");
		adminLastName = getData("users.admin.lastName");
		courseName = d2l.coursePageAction.readDataFromYaml("offeringName");
		remotePlugins = getYamlValues("remotePlugins");
		remotePluginNames = new ArrayList<String>();
		for (Map.Entry<String, Object> entry : remotePlugins.entrySet()) {
			remotePluginNames.add(entry.getValue().toString());
		}
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(d2l, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
		if (method.getName().contains("Update_Plugin")) {
			if (remotePluginNames.size() == 0)
				throw new SkipException("Skipped Test Step : " + method.getName());
		}	
        d2l.stepStartMessage(method.getName()); 
    }

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_As_Admin() {
		d2l.loginPage.login(adminUserName, adminPassword);
		//d2l.homePage.verifyHomePageDisplayed(adminFirstName, adminLastName);
	}
	
	@Test(dependsOnMethods={"Step02_Log_As_Admin"})
	public void Step03_Open_Remote_Plugins_From_Admin_Tools() {
		d2l.homePage.handleGotItModalContent();
		d2l.homePage.clickAdminToolsBtn();
		d2l.homePage.clickAdminToolsRemotePluginsLink();
	}

	// Update Plugin 1
	
	@Test(dependsOnMethods={"Step03_Open_Remote_Plugins_From_Admin_Tools"})
	public void Step04_Update_Plugin_Open_Plugin() {
		d2l.remotePluginsPageAction.openRemotePlugin(remotePluginNames.get(0));
	}
	
	@Test(dependsOnMethods={"Step04_Update_Plugin_Open_Plugin"})
	public void Step05_Update_Plugin_Verify_Edit_Remote_Plugin_Page_Open() {
		d2l.remotePluginsPageAction.verifyEditRemotePluginPageDisplayed(remotePluginNames.get(0));
	}
	
	@Test(dependsOnMethods={"Step05_Update_Plugin_Verify_Edit_Remote_Plugin_Page_Open"})
	public void Step06_Update_Plugin_Add_New_Org_Unit() {
		d2l.remotePluginsPageAction.clickAddOrgUnitsBtn();
		d2l.remotePluginsPageAction.verifyAddOrgUnitsModalDisplayed();
		d2l.remotePluginsPageAction.searchAndInsertCourseOffering(courseName);
	}
	
	@Test(dependsOnMethods={"Step06_Update_Plugin_Add_New_Org_Unit"})
	public void Step07_Update_Plugin_Verify_Course_Offering_Displayed() {
		d2l.remotePluginsPageAction.verifyCourseOfferingAddedAsOrgUnit(courseName);
	}
	
	@Test(dependsOnMethods={"Step07_Update_Plugin_Verify_Course_Offering_Displayed"})
	public void Step08_Update_Plugin_Save_And_Verify() {
		d2l.remotePluginsPageAction.clickSaveBtnAndVerify();
		remotePluginNames.remove(0);
	}
	
	// Update Plugin 2
	
	@Test(dependsOnMethods={"Step08_Update_Plugin_Save_And_Verify"})
	public void Step09_Update_Plugin_Open_Plugin() {
		d2l.remotePluginsPageAction.openRemotePlugin(remotePluginNames.get(0));
	}
	
	@Test(dependsOnMethods={"Step09_Update_Plugin_Open_Plugin"})
	public void Step10_Update_Plugin_Verify_Edit_Remote_Plugin_Page_Open() {
		d2l.remotePluginsPageAction.verifyEditRemotePluginPageDisplayed(remotePluginNames.get(0));
	}
	
	@Test(dependsOnMethods={"Step10_Update_Plugin_Verify_Edit_Remote_Plugin_Page_Open"})
	public void Step11_Update_Plugin_Add_New_Org_Unit() {
		d2l.remotePluginsPageAction.clickAddOrgUnitsBtn();
		d2l.remotePluginsPageAction.verifyAddOrgUnitsModalDisplayed();
		d2l.remotePluginsPageAction.searchAndInsertCourseOffering(courseName);
	}
	
	@Test(dependsOnMethods={"Step11_Update_Plugin_Add_New_Org_Unit"})
	public void Step12_Update_Plugin_Verify_Course_Offering_Displayed() {
		d2l.remotePluginsPageAction.verifyCourseOfferingAddedAsOrgUnit(courseName);
	}
	
	@Test(dependsOnMethods={"Step12_Update_Plugin_Verify_Course_Offering_Displayed"})
	public void Step13_Update_Plugin_Save_And_Verify() {
		d2l.remotePluginsPageAction.clickSaveBtnAndVerify();
		remotePluginNames.remove(0);
	}
	
	
	
	@AfterClass
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}
}