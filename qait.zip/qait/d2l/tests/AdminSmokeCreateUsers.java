package com.qait.d2l.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.Parent_Test;

public class AdminSmokeCreateUsers extends Parent_Test {

	D2LTestSessionInitiator d2l;
	String baseUrl, courseTempName, courseTempCode, department, offeringName, offeringCode, semester;
	String adminUserName, adminPassword, adminFirstName, adminLastName;
	String instFirstName, instLastName, instUserName, instRole, instPassword, instEmail;
	String studFirstName, studLastName, studUserName1, studUserName2, studUserName3, studRole, studPassword, studEmail1,
			studEmail2, studEmail3;

	Map<String, Object> data = new HashMap<String, Object>();

	private void _initVars() {
		String timestamp = CustomFunctions.getStringWithTimestamp("");
		baseUrl = getData("baseUrl");
		adminUserName = getData("users.admin.userName");
		adminPassword = getData("users.admin.password");
		adminFirstName = getData("users.admin.firstName");
		adminLastName = getData("users.admin.lastName");
		courseTempName = d2l.coursePageAction.readDataFromYaml("courseTempName");
		courseTempCode = d2l.coursePageAction.readDataFromYaml("courseTempCode");
		department = getData("create.course.department");
		offeringName = d2l.coursePageAction.readDataFromYaml("offeringName");
		offeringCode = d2l.coursePageAction.readDataFromYaml("offeringCode");
		semester = getData("create.course.semester");

		instFirstName = getData("create.user.instructor.firstName");
		instLastName = getData("create.user.instructor.lastName");

		instUserName = getData("users.inst.userName1");

		instRole = getData("create.user.instructor.role");
		instPassword = getData("users.inst.password");
		instEmail = instUserName + "@fake123.com";

		studFirstName = getData("create.user.student.firstName");
		studLastName = getData("create.user.student.lastName");
		studUserName1 = getData("create.user.student.userName1") + timestamp;
		studUserName2 = getData("create.user.student.userName2") + timestamp;
		studUserName3 = getData("create.user.student.userName3") + timestamp;
//		studUserName1 = (String)data.get("studUserName1");
//		studUserName2 = (String)data.get("studUserName2");
//		studUserName3 = (String)data.get("studUserName3");
		studRole = getData("create.user.student.role");
		studPassword = getData("create.user.password");

		studEmail1 = studUserName1 + getData("create.user.emailDomain");
		studEmail2 = studUserName2 + getData("create.user.emailDomain");
		studEmail3 = studUserName3 + getData("create.user.emailDomain");

		data.put("courseTempName", courseTempName);
		data.put("courseTempCode", courseTempCode);
		data.put("offeringName", offeringName);
		data.put("offeringCode", offeringCode);
		data.put("instUserName", instUserName);
		data.put("instPassword", instPassword);
		data.put("studFirstName", studFirstName);
		data.put("studLastName", studLastName);
		data.put("studUserName1", studUserName1);
		data.put("studUserName2", studUserName2);
		data.put("studUserName3", studUserName3);
		data.put("studPassword", studPassword);
		data.put("instEmail", instEmail);
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(d2l, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
		d2l.coursePageAction.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		d2l.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_As_Admin() {
		d2l.loginPage.login(adminUserName, adminPassword);
		// d2l.homePage.verifyHomePageDisplayed(adminFirstName, adminLastName);
	}

	@Test(dependsOnMethods = { "Step02_Log_As_Admin" })
	public void Step03_Open_Users_From_Admin_Tools() {
		d2l.homePage.handleGotItModalContent();
		d2l.homePage.clickAdminToolsBtn();
		d2l.homePage.clickAdminToolsUsersLink();
	}

	@Test(dependsOnMethods = { "Step03_Open_Users_From_Admin_Tools" })
	public void Step04_Verify_Users_Page_Is_Open() {
		d2l.usersPageActon.verifyUsersPageDisplayed();
	}

	@Test(dependsOnMethods = { "Step04_Verify_Users_Page_Is_Open" })
	public void Step05_Start_Creation_Of_Instructor() {
		d2l.usersPageActon.clickNewUserBtn();
	}

	@Test(dependsOnMethods = { "Step05_Start_Creation_Of_Instructor" })
	public void Step06_Create_User_Section_Displayed() {
		d2l.usersPageActon.verifyCreateUserSectionDisplayed();
		d2l.usersPageActon.verifyUserInformationFormDisplayed();
	}

	@Test(dependsOnMethods = { "Step06_Create_User_Section_Displayed" })
	public void Step07_Fill_Instructor_Details() {
		// d2l.usersPageActon.fillUserInformationForm(instFirstName, instLastName,
		// instEmail, instRole, instUserName, instPassword);
	}

	@Test(dependsOnMethods = { "Step07_Fill_Instructor_Details" })
	public void Step08_Click_Save_And_New_Button() {
//		d2l.usersPageActon.clickSaveAndNewBtn();
//		d2l.usersPageActon.verifyUserCreatedSuccessfully();
//		d2l.usersPageActon.verifyUserInformationFormDisplayed();
	}

	@Test(dependsOnMethods = { "Step08_Click_Save_And_New_Button" })
	public void Step09_Create_Student1() {
		d2l.usersPageActon.verifyCreateUserSectionDisplayed();
		d2l.usersPageActon.verifyUserInformationFormDisplayed();
		d2l.usersPageActon.fillUserInformationForm(studFirstName + "1", studLastName + "1", studEmail1, studRole,
				studUserName1, studPassword);
		d2l.usersPageActon.clickSaveBtn();
		d2l.usersPageActon.verifyUserCreatedSuccessfully();
		d2l.usersPageActon.clickNewUserBtn();
	}

	@Test(dependsOnMethods = { "Step09_Create_Student1" })
	public void Step10_Create_Student2() {
		d2l.usersPageActon.verifyCreateUserSectionDisplayed();
		d2l.usersPageActon.verifyUserInformationFormDisplayed();
		d2l.usersPageActon.fillUserInformationForm(studFirstName + "2", studLastName + "2", studEmail2, studRole,
				studUserName2, studPassword);
		d2l.usersPageActon.clickSaveBtn();
		d2l.usersPageActon.verifyUserCreatedSuccessfully();
		d2l.usersPageActon.clickNewUserBtn();
		// d2l.usersPageActon.verifyUserInformationFormDisplayed();
	}

	@Test(dependsOnMethods = { "Step10_Create_Student2" })
	public void Step11_Create_Student3() {
		d2l.usersPageActon.verifyCreateUserSectionDisplayed();
		d2l.usersPageActon.verifyUserInformationFormDisplayed();
		d2l.usersPageActon.fillUserInformationForm(studFirstName + "3", studLastName + "3", studEmail3, studRole,
				studUserName3, studPassword);
		d2l.usersPageActon.clickSaveBtn();
		d2l.usersPageActon.verifyUserCreatedSuccessfully();
	}

	@Test(dependsOnMethods = "Step11_Create_Student3")
	public void Step12_Verify_Users_Page_Displayed() {
		d2l.usersPageActon.verifyUsersPageDisplayed();
		d2l.usersPageActon.verifyCreateNewUserBtnDisplayed();
	}

	@AfterClass
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}
}