package com.qait.d2l.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.Parent_Test;


public class AdminSmokeCreateNewCourse extends Parent_Test{

	D2LTestSessionInitiator d2l;
	String baseUrl;
	String adminUserName, adminPassword, adminFirstName, adminLastName;
	String courseTempName, courseTempCode, department, offeringName, offeringCode, semester;
	String instFirstName, instLastName, instUserName, instRole, instPassword, instEmail;
	String studFirstName, studLastName, studUserName1,studUserName2,studUserName3, studRole, studPassword, studEmail1, studEmail2, studEmail3;
	
	Map<String, Object> data = new HashMap<String, Object>();
	
	private void _initVars() {
		String timestamp = CustomFunctions.getStringWithTimestamp("");
		baseUrl = getData("baseUrl");
		adminUserName = getData("users.admin.userName");
		adminPassword = getData("users.admin.password");
		adminFirstName = getData("users.admin.firstName");
		adminLastName = getData("users.admin.lastName");
		courseTempName = getData("create.course.courseName")+timestamp;
		courseTempCode = getData("create.course.courseCode")+timestamp;
		department = getData("create.course.department");
		offeringName = getData("create.course.offeringName")+timestamp;
		offeringCode = getData("create.course.offeringCode")+timestamp;
		semester = getData("create.course.semester");
		
		instFirstName = getData("create.user.instructor.firstName");
		instLastName = getData("create.user.instructor.lastName");

		instUserName= getData("users.inst.userName1");

		instRole = getData("create.user.instructor.role");
		instPassword = getData("users.inst.password");
		instEmail = instUserName + "@fake123.com";

		studFirstName = getData("create.user.student.firstName");
		studLastName = getData("create.user.student.lastName");
		studUserName1 = getData("create.user.student.userName1") + timestamp;
		studUserName2 = getData("create.user.student.userName2")  + timestamp;
		studUserName3 = getData("create.user.student.userName3")  + timestamp;
		studRole = getData("create.user.student.role");
		studPassword = getData("create.user.password");

		studEmail1 = studUserName1 + getData("create.user.emailDomain");
		studEmail2 = studUserName2 + getData("create.user.emailDomain");
		studEmail3 = studUserName3 + getData("create.user.emailDomain");
		
		data.put("courseTempName", courseTempName);
		data.put("courseTempCode", courseTempCode);
		data.put("offeringName", offeringName);
		data.put("offeringCode", offeringCode);
		data.put("instUserName", instUserName);
		data.put("instPassword", instPassword);
		data.put("studFirstName", studFirstName);
		data.put("studLastName", studLastName);
		data.put("studUserName1", studUserName1);
		data.put("studUserName2", studUserName2);
		data.put("studUserName3", studUserName3);		
		data.put("studPassword", studPassword);
		data.put("instEmail", instEmail);
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(d2l, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
		d2l.coursePageAction.writeDataToYaml(data);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        d2l.stepStartMessage(method.getName()); 
    }

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_As_Admin() {
		d2l.loginPage.login(adminUserName, adminPassword);
		d2l.homePage.handleGotItModalContent();
		//d2l.homePage.verifyHomePageDisplayed(adminFirstName, adminLastName);
	}
	
	@Test(dependsOnMethods={"Step02_Log_As_Admin"})
	public void Step03_Open_Course_Management_From_Admin_Tools() {
		d2l.homePage.clickAdminToolsBtn();
		d2l.homePage.clickAdminToolsCourseManagementLink();
	}
	
	@Test(dependsOnMethods={"Step03_Open_Course_Management_From_Admin_Tools"})
	public void Step04_Start_New_Course_Creation() {
		d2l.manageCoursesPageAction.verifyManageCoursesDisplayed();
		d2l.manageCoursesPageAction.clickCreateNewCourseBtn();
	}
	
	@Test(dependsOnMethods={"Step04_Start_New_Course_Creation"})
	public void Step05_Verify_Course_Creation_Step1_Displayed() {
		d2l.manageCoursesPageAction.verifyCourseCreationStep1Displayed();
	}
	
	@Test(dependsOnMethods={"Step05_Verify_Course_Creation_Step1_Displayed"})
	public void Step06_Verify_Course_Creation_Step1_Default_Creation_Type() {
		d2l.manageCoursesPageAction.verifyCreateNewCourseNeverOfferedBeforeOptionSelected();
	}
	
	@Test(dependsOnMethods={"Step06_Verify_Course_Creation_Step1_Default_Creation_Type"})
	public void Step07_Click_Next_From_Course_Creation_Step1() {
		d2l.manageCoursesPageAction.clickNextBtn();
	}
	
	@Test(dependsOnMethods={"Step07_Click_Next_From_Course_Creation_Step1"})
	public void Step08_Verify_Course_Creation_Step2_Displayed() {
		d2l.manageCoursesPageAction.verifyCourseCreationStep2Displayed();
	}
	
	@Test(dependsOnMethods={"Step08_Verify_Course_Creation_Step2_Displayed"})
	public void Step09_Fill_And_Submit_Course_Creation_Step2() {
		d2l.manageCoursesPageAction.fillAndSubmitCourseCreationStep2(courseTempName, courseTempCode, department);
	}
	
	@Test(dependsOnMethods={"Step09_Fill_And_Submit_Course_Creation_Step2"})
	public void Step10_Verify_Course_Creation_Step3_Displayed() {
		d2l.manageCoursesPageAction.verifyCourseCreationStep3Displayed();
	}
	
	@Test(dependsOnMethods={"Step10_Verify_Course_Creation_Step3_Displayed"})
	public void Step11_Verify_Course_Creation_Step3_Data() {
		d2l.manageCoursesPageAction.verifyCourseCreationStep3Data(courseTempName, courseTempCode, department);
	}
	
	@Test(dependsOnMethods={"Step11_Verify_Course_Creation_Step3_Data"})
	public void Step12_Fill_And_Submit_Course_Creation_Step3() {
		d2l.manageCoursesPageAction.fillAndSubmitCourseCreationStep3(offeringName, offeringCode, semester);
	}
	
	@Test(dependsOnMethods={"Step12_Fill_And_Submit_Course_Creation_Step3"})
	public void Step13_Verify_Course_Creation_Step4_Displayed() {
		d2l.manageCoursesPageAction.verifyCourseCreationStep4Displayed();
	}
	
	@Test(dependsOnMethods={"Step13_Verify_Course_Creation_Step4_Displayed"})
	public void Step14_Verify_Course_Creation_Step4_Displayed() {
		d2l.manageCoursesPageAction.verifyCourseCreationStep4Displayed();
	}
	
	@Test(dependsOnMethods={"Step14_Verify_Course_Creation_Step4_Displayed"})
	public void Step15_Verify_Course_Creation_Step4_Data() {
		d2l.manageCoursesPageAction.verifyCourseCreationStep4Data(courseTempName, courseTempCode, department, offeringName, offeringCode, semester);
	}
	
	@Test(dependsOnMethods={"Step15_Verify_Course_Creation_Step4_Data"})
	public void Step16_Course_Creation_Step4_Click_Create() {
		d2l.manageCoursesPageAction.clickCreateBtn();
	}
	
	@Test(dependsOnMethods={"Step16_Course_Creation_Step4_Click_Create"})
	public void Step17_Verify_Course_Successfully_Created() {
		d2l.manageCoursesPageAction.verifyCourseSuccessfullyCreatedMessage(courseTempName, offeringName);
	}
	
	@Test(dependsOnMethods={"Step17_Verify_Course_Successfully_Created"})
	public void Step18_Click_Done() {
		d2l.manageCoursesPageAction.clickDoneBtn();
		d2l.manageCoursesPageAction.verifyCreateNewCourseBtnDisplayed();
	}
	
	@AfterClass
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}
}