package com.qait.d2l.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.Parent_Test;

public class AdminSmokeUserEnrollment extends Parent_Test {

	D2LTestSessionInitiator d2l;
	String baseUrl;
	String adminUserName, adminPassword, adminFirstName, adminLastName;
	String courseName;
	String instUserName, instRole,studEmail1,studEmail2,studEmail3;
	String studUserName1, studUserName2, studUserName3, studRole,studFirstName,studLastName;
	Map<String, Object> data = new HashMap<String, Object>();

	private void _initVars() {
		String timestamp = CustomFunctions.getStringWithTimestamp("");
		baseUrl = getData("baseUrl");
		adminUserName = getData("users.admin.userName");
		adminPassword = getData("users.admin.password");
		adminFirstName = getData("users.admin.firstName");
		adminLastName = getData("users.admin.lastName");
		courseName = d2l.coursePageAction.readDataFromYaml("offeringName");
		instUserName = getData("users.inst.userName1");
		studFirstName =d2l.coursePageAction.readDataFromYaml("studFirstName");
		studLastName = d2l.coursePageAction.readDataFromYaml("studLastName");
		studUserName1 =d2l.coursePageAction.readDataFromYaml("studUserName1");
		studUserName2 = d2l.coursePageAction.readDataFromYaml("studUserName2");
		studUserName3 = d2l.coursePageAction.readDataFromYaml("studUserName3");
		studRole = getData("create.user.student.role");
		instRole = getData("create.user.instructor.role");
		studEmail1 = studUserName1 + getData("create.user.emailDomain");
		studEmail2 = studUserName2 + getData("create.user.emailDomain");
		studEmail3 = studUserName3 + getData("create.user.emailDomain");
		//courseName = "OfferingName_1460970538125";
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(d2l, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		d2l.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_As_Admin() {
		d2l.loginPage.login(adminUserName, adminPassword);
		//d2l.homePage.verifyHomePageDisplayed(adminFirstName, adminLastName);
	}

	@Test(dependsOnMethods = { "Step02_Log_As_Admin" })
	public void Step03_Search_And_Open_Course() {
		d2l.homePage.handleGotItModalContent();
		d2l.homePage.searchAndOpenCourse(courseName);
	}

	@Test(dependsOnMethods = { "Step03_Search_And_Open_Course" })
	public void Step04_Verify_Course_Opens() {
		d2l.coursePageAction.verifyCoursePageDisplayed(courseName);
	}

	@Test(dependsOnMethods = { "Step04_Verify_Course_Opens" })
	public void Step05_Open_Classlist_Tab() {
		d2l.coursePageAction.clickNavTab("Classlist");
	}

	@Test(dependsOnMethods = { "Step05_Open_Classlist_Tab" })
	public void Step06_Verify_Classlist_Tab_Open() {
		d2l.coursePageAction.verifySectionHeading("Classlist");
	}

	@Test(dependsOnMethods = { "Step06_Verify_Classlist_Tab_Open" })
	public void Step07_Select_Add_Existing_Users() {
		d2l.coursePageAction.selectAddParticipants("Add existing users");
	}

	@Test(dependsOnMethods = { "Step07_Select_Add_Existing_Users" })
	public void Step08_Verify_Add_Existing_Users_Section_Open() {
		d2l.coursePageAction.verifySectionHeading("Add Existing Users");
	}

	@Test(dependsOnMethods = { "Step08_Verify_Add_Existing_Users_Section_Open" })
	public void Step09_Search_Instructor() {
		d2l.coursePageAction.searchUser(instUserName, instRole);
	}

	@Test(dependsOnMethods = { "Step09_Search_Instructor" })
	public void Step10_Verify_Existing_Instructor_Displayed() {
		d2l.coursePageAction.verifyExistingUserDisplayed(instUserName);
	}

	@Test(dependsOnMethods = { "Step10_Verify_Existing_Instructor_Displayed" })
	public void Step11_Select_And_Enroll_Instructor() {
		d2l.coursePageAction.selectExistingUser(instUserName, instRole);
		d2l.coursePageAction.clickEnrollSelectedUsersBtn();
	}

	@Test(dependsOnMethods = { "Step11_Select_And_Enroll_Instructor" })
	public void Step12_Verify_Confirmation_Of_Enrollment_Section() {
		d2l.coursePageAction.verifySectionHeading("Confirmation of Enrollment");
		d2l.coursePageAction.verifySuccessfullEnrollmentMessage("1");
		d2l.coursePageAction.verifyUsernameSuccessfullEnroll(instUserName);
	}

	@Test(dependsOnMethods = { "Step12_Verify_Confirmation_Of_Enrollment_Section" })
	public void Step13_Click_Add_More_Participants() {
		d2l.coursePageAction.clickAddMoreParticipantsBtn();
	}

	@Test(dependsOnMethods = { "Step13_Click_Add_More_Participants" })
	public void Step14_Verify_Add_Existing_Users_Section_Open() {
		d2l.coursePageAction.verifySectionHeading("Add Existing Users");
	}

	@Test(dependsOnMethods = { "Step14_Verify_Add_Existing_Users_Section_Open" })
	public void Step15_Search_Student() {
//		d2l.coursePageAction.searchUser("", "");
		d2l.coursePageAction.searchUser(studUserName1, studRole);
	}

	@Test(dependsOnMethods = { "Step15_Search_Student" })
	public void Step16_Verify_Existing_Student_Displayed() {
		d2l.coursePageAction.verifyExistingUserDisplayed(studUserName1);
	}

	@Test(dependsOnMethods = { "Step16_Verify_Existing_Student_Displayed" })
	public void Step17_Select_And_Enroll_Student1() {
		d2l.coursePageAction.selectExistingUser(studUserName1, studRole);
		d2l.coursePageAction.clickEnrollSelectedUsersBtn();
	}

	@Test(dependsOnMethods = { "Step17_Select_And_Enroll_Student1" })
	public void Step18_Verify_Confirmation_Of_Enrollment_Section() {
		d2l.coursePageAction.verifySectionHeading("Confirmation of Enrollment");
		d2l.coursePageAction.verifySuccessfullEnrollmentMessage("1");
		d2l.coursePageAction.verifyUsernameSuccessfullEnroll(studUserName1);
	}

	@Test(dependsOnMethods = "Step18_Verify_Confirmation_Of_Enrollment_Section")
	public void Step19_Select_And_Enroll_Student2() {
		d2l.coursePageAction.clickAddMoreParticipantsBtn();
		d2l.coursePageAction.verifySectionHeading("Add Existing Users");
		d2l.coursePageAction.searchUser(studUserName2, studRole);
		d2l.coursePageAction.verifyExistingUserDisplayed(studUserName2);
		d2l.coursePageAction.selectExistingUser(studUserName2, studRole);
		d2l.coursePageAction.clickEnrollSelectedUsersBtn();
		d2l.coursePageAction.verifySectionHeading("Confirmation of Enrollment");
		d2l.coursePageAction.verifySuccessfullEnrollmentMessage("1");
		d2l.coursePageAction.verifyUsernameSuccessfullEnroll(studUserName2);
	}
	
	@Test(dependsOnMethods= "Step19_Select_And_Enroll_Student2")
	public void Step20_Select_And_Enroll_Student3() {
		d2l.coursePageAction.clickAddMoreParticipantsBtn();
		d2l.coursePageAction.verifySectionHeading("Add Existing Users");
		d2l.coursePageAction.searchUser(studUserName3, studRole);
		d2l.coursePageAction.verifyExistingUserDisplayed(studUserName3);
		d2l.coursePageAction.selectExistingUser(studUserName3, studRole);
		d2l.coursePageAction.clickEnrollSelectedUsersBtn();
		d2l.coursePageAction.verifySectionHeading("Confirmation of Enrollment");
		d2l.coursePageAction.verifySuccessfullEnrollmentMessage("1");
		d2l.coursePageAction.verifyUsernameSuccessfullEnroll(studUserName3);
	}
	
	@Test(dependsOnMethods = { "Step20_Select_And_Enroll_Student3" })
	public void Step21_Click_Done_And_Verify_Classlist_Section_Displayed() {
		d2l.coursePageAction.clickDoneBtn();
		d2l.coursePageAction.verifySectionHeading("Classlist");
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}
}