package com.qait.d2l.sapling.tests;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.YamlReader.getYamlValues;

import java.awt.AWTException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Smoke_Instructor_Macmillan_Tools_Verification extends Parent_Test{
	D2LTestSessionInitiator d2l;
	String baseUrl;
	private String courseName;
	private String instructorUserName;
	private String instructorEmail, instructorPassword;
	private String remotePlugin1, remotePlugin2;
	Map<String, Object> remotePlugins;
	List<String> remotePluginNames;
	String quizTitle1, quizTitle2;
	
	private void _initVars() {
		baseUrl = getData("baseUrl");
		courseName = d2l.coursePageAction.readDataFromYaml("offeringName");
		instructorUserName = d2l.coursePageAction.readDataFromYaml("instUserName");
		instructorEmail = d2l.coursePageAction.readDataFromYaml("instEmail");
		instructorPassword = d2l.coursePageAction.readDataFromYaml("instPassword");
		quizTitle1 = "Auto_Quiz";
		remotePlugins = getYamlValues("remotePluginsforsap");
		remotePluginNames = new ArrayList<String>();
		for (Map.Entry<String, Object> entry : remotePlugins.entrySet()) {
			remotePluginNames.add(entry.getValue().toString());
		}
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        d2l.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(d2l, result, this.getClass().getName());     
	}
	
	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}
	
	@Test(dependsOnMethods="Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		d2l.loginPage.login(instructorUserName, instructorPassword);
		d2l.homePage.handleGotItModalContent();
		d2l.instructorHomePageAction.courseNameDisplays(courseName);
	}
	
	@Test(dependsOnMethods ="Step02_Log_In_As_Instructor")
	public void Step03_Go_To_Course_Page() {
		d2l.instructorHomePageAction.clickCourseTitle(courseName);
	}
	
	@Test(dependsOnMethods={"Step03_Go_To_Course_Page"})
	public void Step04_Tools_Widget_Name_Displayed () throws Exception {
		d2l.instructorToolsWidgetAction.toolsWidgetName(remotePluginNames.get(0));
		d2l.instructorToolsWidgetAction.sectionCourseTools();
		d2l.instructorToolsWidgetAction.sectionSupportTools();
		d2l.instructorToolsWidgetAction.handleSecurityAlert(d2l.getSeleniumServer());
	}

	/**
	 * Verify E-book link
	 */
	@Test(dependsOnMethods = { "Step04_Tools_Widget_Name_Displayed" })
	public void Step05_Verify_Ebook_Link() {
		d2l.instructorToolsWidgetAction.clickEBook();
		d2l.launchpadPageactions.verifyEbookSectionIsOpen();
		d2l.launchpadPageactions.clickOnLPHomeLink();
		d2l.launchpadPageactions.launchPadLogout();
		d2l.launchpadPageactions.userClosesPXWindowAndGoToPrimaryWindow();
	}

	/**
	 * Verify Gradebook link
	 */
	@Test(dependsOnMethods = { "Step05_Verify_Ebook_Link" })
	public void Step06_Verify_Gradebook_Link() {
		d2l.instructorToolsWidgetAction.clickGradeBook();
		d2l.launchpadPageactions.verifyGradeBookPageOpens();
		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();
		d2l.launchpadPageactions.launchPadLogout();
		d2l.launchpadPageactions.userClosesPXWindowAndGoToPrimaryWindow();
	}

	/**
	 * Verify Macmillan Learning Diagnostics link
	 */
	@Test(dependsOnMethods = { "Step06_Verify_Gradebook_Link" })
	public void Step07_Verify_Diagnostics_Page() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanDiagnosticsLink();
		d2l.instructorToolsWidgetAction.verifyMacmillanDiagnosticsPage();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}

	/**
	 * Verify Macmillan Roster Information
	 */
	@Test(dependsOnMethods = { "Step07_Verify_Diagnostics_Page" })
	public void Step08_Verify_Roster_Page() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanRosterLink();
		d2l.instructorToolsWidgetAction.verifyMacmillanRosterPage(instructorEmail);
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}

	/**
	 * Verify Macmillan Technical Support
	 */
	@Test(dependsOnMethods = { "Step08_Verify_Roster_Page" }, alwaysRun = true)
	public void Step09_Verify_Technical_Support_Page() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanTechnicalSupportLink();
		d2l.instructorToolsWidgetAction.verifyMacmillanTechnicalSupportPage();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();

	}

	/**
	 * Verify Macmillan User Profile
	 */
	@Test(dependsOnMethods = { "Step09_Verify_Technical_Support_Page" })
	public void Step10_Verify_User_Profile_Page() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanUserProfile();
		d2l.instructorToolsWidgetAction.verifyMacmillanUserProfilePage(instructorEmail);
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}

	/**
	 * Macmillan Content Refresh
	 */
	@Test(dependsOnMethods = { "Step10_Verify_User_Profile_Page" })
	public void Step11_Verify_Macmillan_Content_Refresh_Page() {
		d2l.instructorToolsWidgetAction.launchpadRedirect();
		d2l.launchpadPageactions.verifyPXCourseHomePage();
		d2l.pxPageActions.updateGradeValueOfAssignedTOCItem(quizTitle1, true, "12");

		//d2l.pxPageActions.updateGradeValueOfAssignedTOCItem(quizTitle1, true, "12");
		d2l.pxPageActions.launchPadLogout();
		d2l.instructorToolsWidgetAction.clickOnMacmillanContentRefreshLink();
		d2l.instructorToolsWidgetAction.verifyContentRefreshPage();
		d2l.instructorToolsWidgetAction.selectAssignmentsForProcessing();
		d2l.instructorToolsWidgetAction.clickOnRefreshContentButton();
		d2l.instructorToolsWidgetAction.clickOnOKButtonOnTaskInProgressPopUp();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
//		d2l.coursePage.clickModulesOnCoursePage();
//		d2l.modulePage.verifyGradesOnModulesPage("12");
//		d2l.coursePage.enterIntoToolsSection(external_Tool);
	}
	/**
	 * Verify Macmillan Background Updates
	 */
	@Test(dependsOnMethods = { "Step11_Verify_Macmillan_Content_Refresh_Page" })
	public void Step12_Verify_Macmillan_Background_Updates_Page() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanBackgroundUpdatesLink();
		d2l.instructorToolsWidgetAction.verifyMacmillanBackgroundUpdatesPage();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}

	/**
	 * Verify Grade Sync Token Registration
	 */
	@Test(dependsOnMethods = "Step12_Verify_Macmillan_Background_Updates_Page")
	public void Step13_Verify_Macmillan_Grade_Sync_Token_Registration() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanGradeSyncTokenRegistration();
		d2l.instructorToolsWidgetAction.verifyMacmillanIntegrationTokenRegistrationPage();
//		d2l.instructorToolsWidgetAction.verifyTokenRegistrationSuccessfullyRegistered();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}

	/**
	 * Verify Unlink Macmillan Course
	 */
	@Test(dependsOnMethods = { "Step13_Verify_Macmillan_Grade_Sync_Token_Registration" })
	public void Step14_Unlink_Macmillan_Course() {

		d2l.instructorToolsWidgetAction.clickOnUnlinkMacmillanToolLink();
		d2l.instructorToolsWidgetAction.verifyEndCourseAssociationPage();
		d2l.instructorToolsWidgetAction.disassociateCourse();
		d2l.instructorToolsWidgetAction.verifyEndCourseAssociationPageAfterCourseIsDisassociated();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
		d2l.instructorToolsWidgetAction.verifyNonAssociatedToolsPage();
	}

	/**
	 * Verify Macmillan Missing Content
	 */
	@Test(dependsOnMethods = { "Step14_Unlink_Macmillan_Course" })
	public void Step15_Associate_New_Course_And_Verify_Missing_Content_Link() {

		d2l.instructorHomePageAction.toolsWidgetDisplayed(remotePluginNames.get(0));
		d2l.instructorCourseAssociationAction.launchpadRedirect();
		d2l.instructorCourseAssociationAction.changeWindow(1);
		d2l.instructorHomePageAction.authentication();
		d2l.instructorHomePageAction.continueButton();
		d2l.instructorHomePageAction.createCourse();
		d2l.instructorHomePageAction.courseProvisioning("D2LSaplingLtCourse");
		d2l.instructorHomePageAction.toolsWidgetDisplayed(remotePluginNames.get(0));

		d2l.instructorToolsWidgetAction.clickOnMacmillanMissingContentLink();
		d2l.instructorToolsWidgetAction.verifyMacmillanMissingContentPage();
		d2l.instructorToolsWidgetAction.selectAssignmentsForProcessing();
		d2l.instructorToolsWidgetAction.clickOnDeleteSelectedContentButton();
		d2l.instructorToolsWidgetAction.clickOnOKButtonOnTaskInProgressPopUp();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();


//		d2l.instructorToolsWidgetAction.clickModulesOnCoursePage();
//		d2l.instructorToolsWidgetAction.verifyQuizAssignmentsAreRemovedFromModulesPage(quizTitle1);
//		d2l.instructorToolsWidgetAction.verifyQuizAssignmentsAreRemovedFromModulesPage(quizTitle2);

	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		d2l.closeBrowserSession();
	}
}
