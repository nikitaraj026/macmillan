package com.qait.d2l.sapling.tests;

import java.awt.AWTException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;
import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class StudentRequestFreeTrial extends Parent_Test {
	String quizTitle1, quizTitle2;
	String studentFirstName, studentLastName, registerStudentPassword, stuFirstName, stuLastName;
	String instUserName, instPasswd, firstStudEmail, firstStudUserName;
	String password, answer;
	String courseFullName;
	String fname,lname;

	D2LTestSessionInitiator d2l;
	String baseUrl;

	private void _initVars() {
		baseUrl = getData("baseUrl");
		quizTitle1 = "Auto_Quiz";
		quizTitle2 = "Manual_Quiz";
		studentFirstName = "FirstNameOne";
		studentLastName = "LastNameOne";
		registerStudentPassword = "Password1!";
		stuFirstName = d2l.coursePageAction.readDataFromYaml("studFirstName") + "3";
		stuLastName = d2l.coursePageAction.readDataFromYaml("studLastName") + "3";
		fname = d2l.coursePageAction.readDataFromYaml("studFirstName");
		lname = d2l.coursePageAction.readDataFromYaml("studLastName");
		courseFullName = d2l.coursePageAction.readDataFromYaml("offeringName");
		instUserName = d2l.coursePageAction.readDataFromYaml("instUserName");
		answer = getData("users.sapInst.answer");
		instPasswd = d2l.coursePageAction.readDataFromYaml("instPassword");
		// instUserName = "deepak.daroch.instructor";
		// instPasswd= getData("create.user.instructor.InstructorPassword");;
		firstStudEmail = d2l.coursePageAction.readDataFromYaml("studUserName3") + getData("create.user.emailDomain");
		firstStudUserName = d2l.coursePageAction.readDataFromYaml("studUserName3");
		password = d2l.coursePageAction.readDataFromYaml("studPassword");

	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		d2l.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_As_Student() {
		d2l.loginPage.login(firstStudUserName, password);
		d2l.homePage.handleGotItModalContent();
	}

	@Test(dependsOnMethods = { "Step02_Log_As_Student" })
	public void Step03_Verify_Course_Displays() {
		d2l.homePage.clickOnCourseLink(courseFullName);
	}

	@Test(dependsOnMethods = { "Step03_Verify_Course_Displays" })
	public void Step04_Attempt_Assignments() {
		d2l.studentHomePageAction.clickContentTab();
//		d2l.studentHomePageAction.clickModuleLink();
		d2l.studentHomePageAction.clickSaplingAutoQuiz();
//		d2l.studentHomePageAction.launchQuiz();
	}

	@Test(dependsOnMethods = "Step04_Attempt_Assignments")
	public void Step05_Student_SSO() {
//		d2l.onboardingPageActions.verifyEulaContentDisplayed();
//		d2l.onboardingPageActions.agreeLegalTerms();
//	    d2l.onboardingPageActions.verifyTitle("Register");
//		d2l.onboardingPageActions.fillFirstNameLastNameAndPassword(studentFirstName, studentLastName, registerStudentPassword);
//		d2l.onboardingPageActions.fillConfirmEmailAndPassword(firstStudEmail, registerStudentPassword);
//		d2l.onboardingPageActions.clickRegister();
		d2l.onboardingPageActions.accept_SitePolicy();
	}

	@Test(dependsOnMethods = "Step04_Attempt_Assignments")
	public void Step06_Request_Free_Trial() {

		d2l.studentAccessGrantPageActions.clickRequestFreeTrialForSap("Yes", answer);
//		d2l.studentAccessGrantPageActions.clickContinueToSite();
//		d2l.pxPageActions.userNavigateToPxWindow();

	}
	@Test(dependsOnMethods = "Step06_Request_Free_Trial")
	public void Step07_Verify_LearningDiagnostics() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanDiagnosticsLink();
		d2l.instructorToolsWidgetAction.verifyMacmillanDiagnosticsPage();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = "Step07_Verify_LearningDiagnostics")
	public void Step08_VerifyTechnicalSupport() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanTechnicalSupportLink();
		d2l.instructorToolsWidgetAction.verifyMacmillanTechnicalSupportPage();
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = "Step08_VerifyTechnicalSupport")
	public void Step09_verifyUserProfile() {
		d2l.instructorToolsWidgetAction.clickOnMacmillanUserProfile();
		d2l.instructorToolsWidgetAction.verifyMacmillanUserProfilePage(firstStudEmail);
		d2l.instructorToolsWidgetAction.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = "Step09_verifyUserProfile")
	public void Step10_Attempt_Quiz() {
//		d2l.pxPageActions.userNavigateToPxWindow();
//		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnQuizStartPage();
//		d2l.fandEpageActionsLaunchpad.attemptQuizCorrectly("intuition.");
//		d2l.fandEpageActionsLaunchpad.clickDoneButton();
//		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();	
	}

	@Test(dependsOnMethods = "Step10_Attempt_Quiz")
	public void Step11_Attempt_Second_Quiz() {
//		d2l.fandEpageActionsLaunchpad.clickOnAutoQuiz();
//		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnQuizStartPage();
//		d2l.fandEpageActionsLaunchpad.attemptQuizCorrectly("intuition.");
//		d2l.fandEpageActionsLaunchpad.clickDoneButton();
//		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();
	}

	@Test(dependsOnMethods = "Step11_Attempt_Second_Quiz")
	public void Step12_Attempt_Assign_Chapter_Content() {
//		d2l.fandEpageActionsLaunchpad.clickOnAssignedChapter();
//		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnAssignedChapterPage();
//		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();

	}

	@Test(dependsOnMethods = "Step12_Attempt_Assign_Chapter_Content")
	public void Step13_Student_Logout_LaunchPad() {
//		d2l.pxPageActions.launchPadLogout();
	}

	@Test(dependsOnMethods = "Step13_Student_Logout_LaunchPad")
	public void Step14_Student_Logout_D2L() {
		d2l.loginPage.d2lLogout();
		// d2l.loginPage.verifyLoginPageDisplayed();
	}

	@Test(dependsOnMethods = "Step14_Student_Logout_D2L")
	public void Step15_Login_As_Instructor() {
		d2l.loginPage.login(instUserName, instPasswd);
		d2l.instructorHomePageAction.courseNameDisplaysUsingJS(courseFullName);
//		d2l.instructorHomePageAction.clickCourseTitle(courseFullName);
		d2l.instructorToolsWidgetAction.switchToToolsFrame();

	}

	@Test(dependsOnMethods = "Step15_Login_As_Instructor")
	public void Step16_Verify_Manual_Grade_Sync() {
		d2l.instructorToolsWidgetAction.d2lGradeRefresh();
		d2l.instructorToolsWidgetAction.verifyGradesOfStud(fname, lname);
	}
   
	@AfterClass
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}

}
