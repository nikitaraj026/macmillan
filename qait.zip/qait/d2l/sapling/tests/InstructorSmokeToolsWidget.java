package com.qait.d2l.sapling.tests;

import java.awt.AWTException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.YamlReader.getYamlValues;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class InstructorSmokeToolsWidget extends Parent_Test {

	D2LTestSessionInitiator d2l;
	String baseUrl;
	String InstructorUserName, InstructorPassword;
	String remotePlugin1, remotePlugin2;
	Map<String, Object> remotePlugins;
	List<String> remotePluginNames;
	String courseName;
	String bookIdentifier;
	// String courseName = "CourseOfferingName1_Sep20";
	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	String welcomePageTitle;
	String quizTitle = "Auto_Quiz", quizTitle2 = "Manual_Quiz";
	String chapterName1, chapterName2, chapterNumber, chapterContent,
			chapterIntroduction;
	String courseUrl, schoolName, assignDate, editedSchoolName,
			partialSchoolName;

	String studentUserName, studentName;
	String selectQuestionFrom,testRunEnv;

	private void _initVars() {
		baseUrl = getData("baseUrl");
		courseName = d2l.coursePageAction.readDataFromYaml("offeringName");
		bookIdentifier = "myers";
		InstructorUserName = d2l.coursePageAction
				.readDataFromYaml("instUserName");
		InstructorPassword = d2l.coursePageAction
				.readDataFromYaml("instPassword");
		// InstructorUserName = "deepak.daroch.instructor";
		// InstructorPassword =
		// getData("create.user.instructor.InstructorPassword");
		testRunEnv=PropFileHandler.readProperty("tier");
		remotePlugins = getYamlValues("remotePluginsforsap");
		remotePluginNames = new ArrayList<String>();
		for (Map.Entry<String, Object> entry : remotePlugins.entrySet()) {
			remotePluginNames.add(entry.getValue().toString());
			chapterName1 = getData(bookIdentifier + ".TOC_chapter1");
			chapterName2 = getData(bookIdentifier + ".TOC_chapter2");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			chapterContent = getData(bookIdentifier
					+ ".TOC_chapter2_subcontent1");
			chapterIntroduction = getData(bookIdentifier
					+ ".TOC_chapter1_introduction");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
			getData(bookIdentifier + ".product_name");
			assignDate = "15";
			getData(bookIdentifier + ".author");
		}
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		d2l.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_As_Instructor() {
		d2l.loginPage.login(InstructorUserName, InstructorPassword);
		d2l.homePage.handleGotItModalContent();
	}

	@Test(dependsOnMethods = { "Step02_Log_As_Instructor" })
	public void Step03_Verify_Course_Displays() {
//		d2l.instructorHomePageAction.courseNameDisplays(courseName);
	}

	@Test(dependsOnMethods = { "Step03_Verify_Course_Displays" })
	public void Step04_Course_Home_Page_Displayed() {
//		d2l.instructorHomePageAction.clickCourseTitle(courseName);
		d2l.homePage.clickOnCourseLink(courseName);
//		d2l.homePage.searchAndOpenCourse(courseName);
	}

	@Test(dependsOnMethods = { "Step04_Course_Home_Page_Displayed" })
	public void Step05_Tools_Widget_Name_Displayed() {
		
		d2l.instructorToolsWidgetAction.toolsWidgetName(remotePluginNames
				.get(0));
		d2l.instructorToolsWidgetAction.sectionCourseToolsForSap();
		d2l.instructorToolsWidgetAction.sectionSupportTools();
	}

	@Test(dependsOnMethods = { "Step05_Tools_Widget_Name_Displayed" })
	public void Step06_LaunchPad_Navigation() throws AWTException {
		d2l.instructorToolsWidgetAction.saplingRedirect();
//		 d2l.instructorToolsWidgetAction.handleSecurityAlert();
//		d2l.instructorToolsWidgetAction.handleSecurityAlert(d2l
//				.getSeleniumServer());
//		d2l.launchpadPageactions.verifyPXCourseHomePage();
	}

	@Test(dependsOnMethods = { "Step06_LaunchPad_Navigation" })
	public void Step07_Create_Assignments() {
		d2l.launchpadPageactions.createQuizAssessmentForSapling("Sapling_auto_quiz",testRunEnv);
	}

	@Test(dependsOnMethods = { "Step07_Create_Assignments" })
	public void Step09_LaunchPad_Logout() {
//		d2l.launchpadPageactions.launchPadLogout();
//		d2l.launchpadPageactions.userClosesPXWindowAndGoToPrimaryWindow();
	}

	@AfterClass
	public void Stop_Test_Session() {
		 d2l.closebrowserSession();
	}
}
