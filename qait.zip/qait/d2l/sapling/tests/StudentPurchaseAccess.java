package com.qait.d2l.sapling.tests;

import java.awt.AWTException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;
import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class StudentPurchaseAccess extends Parent_Test 
{ 
	String quizTitle1, quizTitle2;
	String studentFirstName, studentLastName, registerStudentPassword, stuFirstName, stuLastName;
	String instUserName, instPasswd, firstStudEmail, firstStudUserName;
	String password;
	String courseFullName;
	String cardNumber, expiration, cvv;
	D2LTestSessionInitiator d2l;
	String baseUrl;

	private void _initVars() {
		baseUrl = getData("baseUrl");
		quizTitle1 = "Auto_Quiz";
		quizTitle2 = "Manual_Quiz";
		studentFirstName = "FirstNameOne";
		studentLastName = "LastNameOne";
		registerStudentPassword = "Password1!";
		stuFirstName= d2l.coursePageAction.readDataFromYaml("studFirstName")+"2";
		stuLastName= d2l.coursePageAction.readDataFromYaml("studLastName")+"2";
		courseFullName = d2l.coursePageAction.readDataFromYaml("offeringName");
		instUserName = d2l.coursePageAction.readDataFromYaml("instUserName");
		instPasswd = d2l.coursePageAction.readDataFromYaml("instPassword");
		//instUserName = "deepak.daroch.instructor";
		//instPasswd= getData("create.user.instructor.InstructorPassword");;
		firstStudEmail = d2l.coursePageAction.readDataFromYaml("studUserName2") + getData("create.user.emailDomain");
		firstStudUserName = d2l.coursePageAction.readDataFromYaml("studUserName2");
		password = d2l.coursePageAction.readDataFromYaml("studPassword");
		cardNumber = getData("cardNumber");
		expiration = getData("cardExpiration");
		cvv = getData("cardCVV");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}	

	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		d2l.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_As_Student() {
		d2l.loginPage.login(firstStudUserName, password);
		d2l.homePage.handleGotItModalContent();
	}
	
	@Test(dependsOnMethods={"Step02_Log_As_Student"})
	public void Step03_Verify_Course_Displays (){
	d2l.studentHomePageAction.clickCourseTitle(courseFullName);
	}
	
	@Test(dependsOnMethods={"Step03_Verify_Course_Displays"})
	public void Step04_Attempt_Assignments()
	{
		d2l.studentHomePageAction.clickContentTab();
		d2l.studentHomePageAction.clickModuleLink();
		d2l.studentHomePageAction.clickManualQuiz();
		d2l.studentHomePageAction.launchQuiz();
	}
	
	@Test(dependsOnMethods = "Step04_Attempt_Assignments")
	public void Step05_Student_SSO() {
		d2l.onboardingPageActions.verifyEulaContentDisplayed();
		d2l.onboardingPageActions.agreeLegalTerms();
	    d2l.onboardingPageActions.verifyTitle("Register");
		d2l.onboardingPageActions.fillFirstNameLastNameAndPassword(studentFirstName, studentLastName, registerStudentPassword);
		d2l.onboardingPageActions.fillConfirmEmailAndPassword(firstStudEmail, registerStudentPassword);
		d2l.onboardingPageActions.clickRegister();
	}
	
	@Test(dependsOnMethods = "Step04_Attempt_Assignments")
	public void Step06_Pay_Pal_Purchase()
	{
		
		d2l.studentAccessGrantPageActions.clickPurchaseAccess();
		d2l.studentAccessGrantPageActions.verifyUserIsOnPurchaseAccessPage();
		d2l.studentAccessGrantPageActions.select180DaysAccess();
		d2l.studentAccessGrantPageActions.selectCountryAndEnterZipForTaxCalculation();
		d2l.studentAccessGrantPageActions.clickAddToCart();
		d2l.studentAccessGrantPageActions.verifyUserIsOnPaymentDetailsPage();
		d2l.studentAccessGrantPageActions.enterCardNumberOnPaymentDetailsPage(cardNumber);
		d2l.studentAccessGrantPageActions.enterExpirationAndCVVOnPaymentDetailsPage(expiration, cvv);
		//d2l.studentAccessGrantPageActions.clickPaypalOnPaymentDetailsPage();
		//d2l.studentAccessGrantPageActions.handlePaypalSandbox();
		d2l.studentAccessGrantPageActions.clickContinueOnPaymentDetailsPage();
		d2l.studentAccessGrantPageActions.verifyUserIsOnReviewYourOrderPage();
		d2l.studentAccessGrantPageActions.clickConfirmPaymentOnReviewYourOrderPage();
		d2l.studentAccessGrantPageActions.clickContinueOnPurchaseConfirmationPage();
		d2l.studentAccessGrantPageActions.clickContinueToSite();
		d2l.pxPageActions.userNavigateToPxWindow();
	}
	
	@Test(dependsOnMethods = "Step06_Pay_Pal_Purchase")
	public void Step07_Attempt_Quiz() {
		
		d2l.pxPageActions.userNavigateToPxWindow();
		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnQuizStartPage();
		d2l.fandEpageActionsLaunchpad.attemptQuizCorrectly("intuition.");
		d2l.fandEpageActionsLaunchpad.clickDoneButton();
		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();
		
	}
	
	@Test(dependsOnMethods = "Step07_Attempt_Quiz")
	public void Step08_Attempt_Second_Quiz() {
		d2l.fandEpageActionsLaunchpad.clickOnAutoQuiz();
		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnQuizStartPage();
		d2l.fandEpageActionsLaunchpad.attemptQuizCorrectly("intuition.");
		d2l.fandEpageActionsLaunchpad.clickDoneButton();
		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();
	}

	@Test(dependsOnMethods= "Step08_Attempt_Second_Quiz")
	public void Step9_Attempt_Assign_Chapter_Content() {
		d2l.fandEpageActionsLaunchpad.clickOnAssignedChapter();
		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnAssignedChapterPage();
		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();
		
	}
	
	@Test(dependsOnMethods = "Step9_Attempt_Assign_Chapter_Content")
	public void Step10_Student_Logout_LaunchPad() {
		d2l.pxPageActions.launchPadLogout();
	}
	
	@Test(dependsOnMethods = "Step10_Student_Logout_LaunchPad")
	public void Step11_Student_Logout_D2L(){
		d2l.loginPage.logout();
		//d2l.loginPage.verifyLoginPageDisplayed();
	}
	
	@Test(dependsOnMethods = "Step11_Student_Logout_D2L")
	public void Step12_Login_As_Instructor()
	{
		d2l.loginPage.login(instUserName, instPasswd);
		d2l.homePage.handleGotItModalContent();
		d2l.instructorHomePageAction.courseNameDisplays(courseFullName);
		d2l.instructorHomePageAction.clickCourseTitle(courseFullName);
		d2l.instructorToolsWidgetAction.switchToToolsFrame();
			
	}
	
	@Test(dependsOnMethods = "Step12_Login_As_Instructor")
	public void Step13_Verify_Manual_Grade_Sync()
	{
		d2l.instructorToolsWidgetAction.gradeRefresh();
		d2l.instructorToolsWidgetAction.verifyGrades(stuFirstName);
	}
/*	
	@Test(dependsOnMethods = "Step08_Student_Logout_LaunchPad")
	public void Step09_Attempt_Second_Quiz() throws AWTException {
		d2l.studentHomePageAction.clickContentTab();
		d2l.studentHomePageAction.clickModuleLink();
		d2l.studentHomePageAction.clickAutoQuiz();
		d2l.instructorToolsWidgetAction.handleSecurityAlert();
		d2l.studentHomePageAction.changeWindow(1);
		
		d2l.pxPageActions.userNavigateToPxWindow();
		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnQuizStartPage();
		d2l.fandEpageActionsLaunchpad.attemptQuizCorrectly("intuition.");
		d2l.fandEpageActionsLaunchpad.clickDoneButton();
		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();
		//moodle.fandEPageLaunchpad.clickOnPXAssignment(quizTitle2);
		//moodle.fandEPageLaunchpad.verifyStudentIsOnQuizStartPage();
		//moodle.fandEPageLaunchpad.attemptQuizCorrectly("exaggerate their ability to have foreseen an outcome.");
		//moodle.fandEPageLaunchpad.clickDoneButton();
		//moodle.fandEPageLaunchpad.clickOnHomeButton();
	}
	
	@Test (dependsOnMethods= "Step09_Attempt_Second_Quiz")
	public void Step10_Student_Logout_LaunchPad() {		
		d2l.pxPageActions.launchPadLogout();	
	}
	
	@Test(dependsOnMethods= "Step10_Student_Logout_LaunchPad")
	public void Step11_Attempt_Assign_Chapter_Content() throws AWTException {
		d2l.studentHomePageAction.clickContentTab();
		d2l.studentHomePageAction.clickModuleLink();
		d2l.studentHomePageAction.clickOnChapterAssignment();
		d2l.instructorToolsWidgetAction.handleSecurityAlert();
		d2l.studentHomePageAction.changeWindow(1);
		//d2l.studentHomePageAction.launchQuizSSOComplete();
		d2l.pxPageActions.userNavigateToPxWindow();
		
		d2l.fandEpageActionsLaunchpad.verifyStudentIsOnAssignedChapterPage();
		d2l.fandEpageActionsLaunchpad.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step11_Attempt_Assign_Chapter_Content")
	public void Step12_Student_Logout_LaunchPad() {
		d2l.pxPageActions.launchPadLogout();
	}
	
	@Test(dependsOnMethods = "Step12_Student_Logout_LaunchPad")
	public void Step13_Student_Logout_D2L() {
		d2l.loginPage.logout();
		//d2l.loginPage.verifyLoginPageDisplayed();
	}
	
	@Test(dependsOnMethods = "Step13_Student_Logout_D2L")
	public void Step14_Login_As_Instructor()
	{
		d2l.loginPage.login(instUserName, instPasswd);
		d2l.instructorHomePageAction.courseNameDisplays(courseFullName);
		d2l.instructorHomePageAction.clickCourseTitle(courseFullName);
		d2l.instructorToolsWidgetAction.switchToToolsFrame();
			
	}
	
	@Test(dependsOnMethods = "Step14_Login_As_Instructor")
	public void Step15_Verify_Manual_Grade_Sync()
	{
		d2l.instructorToolsWidgetAction.gradeRefresh();
		d2l.instructorToolsWidgetAction.verifyGrades(stuFirstName);
	}
*/	
	@AfterClass
	public void Stop_Test_Session() {
		d2l.closeBrowserSession();
	}

}
