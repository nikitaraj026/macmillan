package com.qait.d2l.sapling.tests;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class AdminSmokeCreateHomePage extends Parent_Test{

	D2LTestSessionInitiator d2l;
	
	String baseUrl;
	String adminUserName, adminPassword, adminFirstName, adminLastName;
	String courseName;
	String homepageName;
	String widgetName;
	
	private void _initVars() {
		baseUrl = getData("baseUrl");
		adminUserName = getData("users.admin.userName");
		adminPassword = getData("users.admin.password");
		adminFirstName = getData("users.admin.firstName");
		adminLastName = getData("users.admin.lastName");
		courseName = d2l.coursePageAction.readDataFromYaml("offeringName");
		homepageName = courseName + "_Homepage";
		widgetName = getData("remotePluginsforsap.plugin1");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}
	
	@BeforeMethod
	public void handleTestMethodName(Method method) {
		d2l.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_As_Admin() {
		d2l.loginPage.login(adminUserName, adminPassword);
		d2l.homePage.handleGotItModalContent();
		d2l.homePage.verifyHomePageDisplayed(adminFirstName, adminLastName);
	}
	
	@Test(dependsOnMethods={"Step02_Log_As_Admin"})
	public void Step03_Search_And_Open_Course() {
		d2l.homePage.searchAndOpenCourse(courseName);
	}	
	
	@Test(dependsOnMethods={"Step03_Search_And_Open_Course"})
	public void Step04_Verify_Course_Opens() {
		d2l.coursePageAction.verifyCoursePageDisplayed(courseName);
	}	
	
	@Test(dependsOnMethods={"Step04_Verify_Course_Opens"})
	public void Step05_Open_Course_Admin_Tab() {
		d2l.coursePageAction.clickNavTab("Course Admin");
	}	
	
	@Test(dependsOnMethods={"Step05_Open_Course_Admin_Tab"})
	public void Step06_Verify_Course_Admin_Tab_Open() {
		d2l.coursePageAction.verifySectionHeading("Course Administration");
	}	
	
	@Test(dependsOnMethods={"Step06_Verify_Course_Admin_Tab_Open"})
	public void Step07_Open_Homepages_From_Course_Administration() {
		d2l.coursePageAction.clickLinkUnderCourseAdministration("Homepages");
	}	
	
	@Test(dependsOnMethods={"Step07_Open_Homepages_From_Course_Administration"})
	public void Step08_Verify_Create_Homepage_Section_Open() {
		d2l.coursePageAction.verifySectionHeading1("Create Homepage");
		d2l.coursePageAction.clickCreateHomepageBtn();
	}	
	
	@Test(dependsOnMethods={"Step08_Verify_Create_Homepage_Section_Open"})
	public void Step09_Fill_New_Homepage_Details() {
		d2l.coursePageAction.fillHomepageName(homepageName);
		d2l.coursePageAction.selectHomepageType("Widget-based");
	}	
	
	@Test(dependsOnMethods={"Step09_Fill_New_Homepage_Details"})
	public void Step10_Add_Widget_To_Homepage() {
		d2l.coursePageAction.addWidgetsToHomepage(widgetName);
	}	
	
	@Test(dependsOnMethods={"Step10_Add_Widget_To_Homepage"})
	public void Step11_Verify_Widget_Added_To_Homepage() {
		d2l.coursePageAction.verifyWidgetAdded(widgetName);
	}	
	
	@Test(dependsOnMethods={"Step11_Verify_Widget_Added_To_Homepage"})
	public void Step12_Submit_Create_Homepage() {
		d2l.coursePageAction.clickSaveAndCloseBtn();
	}	
	
	@Test(dependsOnMethods={"Step12_Submit_Create_Homepage"})
	public void Step13_Verify_Homepage_Created() {
		d2l.coursePageAction.verifyFlashMessage(homepageName + " Saved Successfully");
	}	
	
	@Test(dependsOnMethods={"Step13_Verify_Homepage_Created"})
	public void Step14_Select_New_Homepage_And_Apply() {
		d2l.coursePageAction.selectAndApplyHomepage(homepageName);
	}	
	
	@Test(dependsOnMethods={"Step14_Select_New_Homepage_And_Apply"})
	public void Step15_Verify_Homepage_Successfully_Applied() {
		d2l.coursePageAction.verifyFlashMessage("\"" + homepageName + "\" set as active homepage.");
	}	
	
	@Test(dependsOnMethods={"Step15_Verify_Homepage_Successfully_Applied"})
	public void Step16_Open_Course_Homepage() {
		d2l.coursePageAction.clickNavTab(courseName);
	}	

	@Test(dependsOnMethods={"Step16_Open_Course_Homepage"})
	public void Step17_Verify_Homepage_Displays_Widget() {
		//d2l.coursePageAction.verifySectionHeading1(widgetName);
	}	
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(d2l, result, this.getClass().getName());     
	}
	
	@AfterClass
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}
}