package com.qait.d2l.sapling.tests;

import java.lang.reflect.Method;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.YamlReader.getYamlValues;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;

public class InstructorSmokeCourseAssoication extends Parent_Test {

	D2LTestSessionInitiator d2l;
	String baseUrl;
	String InstructorUserName, InstructorPassword,instFirstName, instLastName, instructorEmail;
	String remotePlugin1, remotePlugin2;
	Map<String, Object> remotePlugins;
	List<String> remotePluginNames;
	String courseName,env;
	String pxCourseName;
	String pxCourseName1;
	private void _initVars() {
		baseUrl = getData("baseUrl");
		InstructorUserName = d2l.coursePageAction.readDataFromYaml("instUserName");
		InstructorPassword = d2l.coursePageAction.readDataFromYaml("instPassword");
		courseName= d2l.coursePageAction.readDataFromYaml("offeringName");
		pxCourseName=getData("users.sapInst.pxcourseName");
		pxCourseName1 = pxCourseName.substring(0, pxCourseName.length() - 2);
		remotePlugins = getYamlValues("remotePluginsforsap");
		remotePluginNames = new ArrayList<String>();
		for (Map.Entry<String, Object> entry : remotePlugins.entrySet()) {
			remotePluginNames.add(entry.getValue().toString());
		}
		
		env=System.getProperty("tier");
		if(env==null) {
		env=ConfigPropertyReader.getProperty("tier");
		}
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}	

	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		d2l.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		//d2l.loginPage.verifyLoginPageDisplayed();
	}

	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_As_Instructor() {
		d2l.loginPage.login(InstructorUserName, InstructorPassword);
		d2l.homePage.handleGotItModalContent();
	}

	@Test(dependsOnMethods={"Step02_Log_As_Instructor"})
	public void Step03_Verify_Course_Displays (){
//		d2l.instructorHomePageAction.courseNameDisplays(courseName);
	}

	@Test(dependsOnMethods={"Step03_Verify_Course_Displays"})
	public void Step04_Course_Home_Page_Displayed (){
//		d2l.instructorHomePageAction.clickCourseTitle(courseName);
		//d2l.homePage.searchAndOpenCourse(courseName,env);
		d2l.homePage.clickOnCourseLink(courseName);

	}

	@Test(dependsOnMethods={"Step04_Course_Home_Page_Displayed"})
	public void Step05_Tools_Widget_Displayed() {
		d2l.instructorHomePageAction.toolsWidgetDisplayed(remotePluginNames.get(0));
	}

	@Test(dependsOnMethods={"Step05_Tools_Widget_Displayed"})
	public void Step06_Instructor_Authentication()
	{
		d2l.instructorToolsWidgetAction.clickGettingStartedLink("Connect with Sapling");
		d2l.instructorCourseAssociationAction.changeWindow(1);
	}
	
	@Test(dependsOnMethods={"Step06_Instructor_Authentication"})
	public void Step07_Authentication() {
		d2l.instructorHomePageAction.acceptSSO();
		d2l.instructorHomePageAction.courseProvisioning(pxCourseName1);
	}
	
	@Test(dependsOnMethods={"Step07_Authentication"})
    public void Step08_Navigate_Back_To_Homepage ()    
    {
		d2l.instructorHomePageAction.changeWindow(0);		
    }

	@AfterClass
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}
}