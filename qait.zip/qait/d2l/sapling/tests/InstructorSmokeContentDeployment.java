package com.qait.d2l.sapling.tests;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.sanselan.formats.tiff.constants.TagInfo.Date;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.YamlReader.getYamlValues;

import com.qait.automation.D2LTestSessionInitiator;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.Parent_Test;

public class InstructorSmokeContentDeployment extends Parent_Test {
	
	D2LTestSessionInitiator d2l;
	String baseUrl;
	String InstructorUserName, InstructorPassword;
	String courseName;
	String timestamp;

	Map<String, Object> remotePlugins;
	List<String> remotePluginNames;
	
	private void _initVars() {
		timestamp = CustomFunctions.getStringWithTimestamp("");
		baseUrl = getData("baseUrl");
		InstructorUserName = d2l.coursePageAction.readDataFromYaml("instUserName");
		InstructorPassword = d2l.coursePageAction.readDataFromYaml("instPassword");
		courseName= d2l.coursePageAction.readDataFromYaml("offeringName");

		remotePlugins = getYamlValues("remotePluginsforsap");
		remotePluginNames = new ArrayList<String>();
		for (Map.Entry<String, Object> entry : remotePlugins.entrySet()) {
			remotePluginNames.add(entry.getValue().toString());
		}
		
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(d2l, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		d2l = new D2LTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        d2l.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		d2l.launchApplication(baseUrl);
		d2l.loginPage.verifyLoginPageDisplayed();
	}

	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_As_Instructor() {
		d2l.loginPage.login(InstructorUserName, InstructorPassword);
		d2l.homePage.handleGotItModalContent();
	}

	@Test(dependsOnMethods={"Step02_Log_As_Instructor"})
	public void Step03_Verify_Course_Displays (){
//		d2l.instructorHomePageAction.courseNameDisplays(courseName);
		d2l.homePage.clickOnCourseLink(courseName);
	}

	@Test(dependsOnMethods={"Step03_Verify_Course_Displays"})
	public void Step04_Course_Home_Page_Displayed (){
		System.out.println(courseName);
//		d2l.instructorHomePageAction.clickCourseTitle(courseName);
	}
	
	@Test(dependsOnMethods={"Step04_Course_Home_Page_Displayed"})
	public void Step05_Launch_TOC(){
		d2l.courseDeploymentPageAction.clickCourseAdmin();
		d2l.courseDeploymentPageAction.clickCourseBuilder();
//		d2l.courseDeploymentPageAction.clickOnStartButton();
		//Remove comment for newly registered instructor
		d2l.courseDeploymentPageAction.clickCreateModule();
		d2l.courseDeploymentPageAction.clickOnCourseOfferingName();
		d2l.courseDeploymentPageAction.enterModuleName("Smoke_Test_" + timestamp);
		d2l.courseDeploymentPageAction.clickOnCreateButton();
	}
	
	@Test(dependsOnMethods={"Step05_Launch_TOC"})
	public void Step06_Deploy_Content ()
	{		
		//d2l.courseDeploymentPageAction.clickOnMacmillanLearningTOC(remotePluginNames.get(1));
		//d2l.courseDeploymentPageAction.selectModule();
		d2l.courseDeploymentPageAction.verifyAllAssignmentsTextIsNotClickable();
		d2l.courseDeploymentPageAction.clickOnAssignmentArrow();
		//d2l.courseDeploymentPageAction.modalWindowCreateModuleDispalys();
		d2l.courseDeploymentPageAction.selectAssignments();
		d2l.courseDeploymentPageAction.verfiySelectedCount();
		d2l.courseDeploymentPageAction.clickOnDeploySelectedCount();
		//d2l.courseDeploymentPageAction.deployContent();
	}
	
	@Test(dependsOnMethods= "Step06_Deploy_Content")
	public void Step07_Verify_Deploy_Content() {
		d2l.courseDeploymentPageAction.clickOnContentNavBar();
		d2l.courseDeploymentPageAction.verifyContentDeployed();
	}
	
	@AfterClass
	public void Stop_Test_Session() {
		d2l.closebrowserSession();
	}


}
