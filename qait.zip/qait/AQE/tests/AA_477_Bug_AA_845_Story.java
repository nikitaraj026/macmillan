package com.qait.AQE.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

/**
 * This Test class is Sprint 37 Automation Candidate
 * 
 * <ol>
 * 
 * <li>
 * <a href="https://macmillanhighered.atlassian.net/browse/AA-477">AA-477</a>
 * 
 * <p> Automation Story: AA-477 - Create automation script of test that Weight 
 *     field in numeric response should accept fractional values as 
 *     well like .5 , .2, etc. 	</p>
 * 
 * </li>
 * 
 * </ol>
 * 
 */
public class AA_477_Bug_AA_845_Story extends Parent_Test{
	
	AQETestSessionInitiator test;	
	
	String courseName = getStringWithTimestamp("TestAutomation-AA-477");
	String baseUrl, instructorUserName, instructorPassword;
	String productName, author;
	String schoolName ,welcomePageTitle, courseUrl;
	String indexPageButtonText = "Sign In";
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("calculus") String book) {
		test = new AQETestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method){
        test.stepStartMessage(method.getName()); 
    }
	
	/**
	 * AA-477 Bug  ----> AA-845 Automation Story  
	 * Book  	   ----> Independent
	 * Environment ----> DEV
	 * Sprint	   ----> 37
	 * 
	 */
	private void initVars(String book) {
		String bookIdentifier = book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		instructorUserName = getData("users.instructor.username");
		instructorPassword = getData("users.instructor.password");
		schoolName = getData("courseDetails.schoolName");
		welcomePageTitle = getData(bookIdentifier + ".welcomePageTitle");
		productName = getData(bookIdentifier + ".product_name");
		author = getData(bookIdentifier + ".author");
	}
	
	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(instructorUserName,instructorPassword);
		test.dashboard.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_A_New_Course() {
		test.dashboard.clickCreateCourseLink(productName, author);
		test.createcoursemodal.verifyCreateCourseOptionsModalWindow();
		test.createcoursemodal.setNewCourseDetails(courseName, schoolName);
		test.createcoursemodal.createNewCourseBasedOnExisting("No");
		test.dashboard.verifyNewCourseIsCreated(courseName);
	}
	
	@Test(dependsOnMethods = "Step02_Instructor_Creates_A_New_Course")
	public void Step03_Instructor_Activates_The_New_Course() {
		test.dashboard.activateCourseFromDashBoard(courseName);
		test.dashboard.verifyCourseIsActivated(courseName);
		courseUrl = test.dashboard.getCourseUrl(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Activates_The_New_Course")
	public void Step04_Instructor_Navigates_To_Course_Home_Page() {
		test.dashboard.instructorOpensCourse(courseName);
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Navigates_To_Course_Home_Page")
	public void Step05_Instructor_Creates_Quiz() {
		test.coursehomepage.startCreatingNewAssignment("Quiz");
		test.fnepage.fillAndSubmitBasicAssignmentInfo(courseName + " - Quiz");
	}
	
	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step06_Instructor_Create_And_Add_Advanced_Questions_To_Quiz() {
		test.fnepage.openFnE_Menu("Questions");
		test.fnepage.createNewQuestionType("Advanced Question");
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.validateHtsEditorLinksContainer();
	    test.questioneditor.clearContentOfQuestionTextarea();
	}
	
	@Test(dependsOnMethods = "Step06_Instructor_Create_And_Add_Advanced_Questions_To_Quiz")
	public void Step07_Instructor_Verifies_Weight_Field_By_Providing_Positive_Set_Of_Values(){
		test.questioneditor.enterTextContentToQuestionTextarea("What is the value of 2+2? ");
		test.questioneditor.addResponseAreaToQuestion("Numeric");
		test.questioneditor.enterAnswerTypeInNumericResponseEditor("Single Value/Expr.","4", "no", ".5");
		test.questioneditor.verifyNumericResponseEditorIsNotDisplayed();	
	}
	
	@Test(dependsOnMethods = "Step07_Instructor_Verifies_Weight_Field_By_Providing_Positive_Set_Of_Values")
	public void Step08_Instructor_Verifies_Weight_Field_By_Providing_Negative_Set_Of_Values(){
		test.questioneditor.enterTextContentToQuestionTextarea("What is the value of 2+2? ");
		test.questioneditor.addResponseAreaToQuestion("Numeric");
		test.questioneditor.enterAnswerTypeInNumericResponseEditor("Single Value/Expr.","4", "no", "-5");
		test.questioneditor.verifyNumericResponseEditorIsStillDisplayingErrorMessage();
		test.questioneditor.verifyNumericResponseEditorIsDisplayed();
		test.questioneditor.clickOnCancelButtonPresentOnDialogBox();
	}
	
	@Test(dependsOnMethods = "Step08_Instructor_Verifies_Weight_Field_By_Providing_Negative_Set_Of_Values")
	public void Step09_Instructor_Navigates_Back_To_CourseHomePage() {
		test.questioneditor.clickOnDoneEditingButton();		
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step09_Instructor_Navigates_Back_To_CourseHomePage")
	public void Step10_Instructor_SignOuts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@AfterClass
	public void stop_test_session() {
		test.closeBrowserSession();
	}
	
}
