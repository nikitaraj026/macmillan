package com.qait.AQE.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

/**	
 * 
 * This Test class covers Sprint 53 Automation Candidate
 * <ol>
 * 
 * <li>
 * 
 * <a href="https://macmillanhighered.atlassian.net/browse/AA-1713">AA-1713</a>
 * 
 * <p> (Automation) As an instructor, I want the Advanced Question Player to obey the quiz review settings 
 * 	   I set, not show the answers no matter what. </p>
 * 
 * </li>
 * 
 * </ol>
 * 
 */
public class AA_452_UserStory_AA_1713_Story extends Parent_Test{
	
	AQETestSessionInitiator test;

	String baseUrl, courseUrl, welcomePageTitle;
	String courseName = getStringWithTimestamp("TestAutomation-AA-452");
	String quizName = getStringWithTimestamp("TestQuiz-AA-452");
	String productName, author, schoolName;
	String instructorUserName, instructorPassword;
	String studentUserName, studentPassword;
	String indexPageButtonText = "Sign In";
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("calculus") String book) {
		test = new AQETestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method){
        test.stepStartMessage(method.getName()); 
    }
	
	/**
	 * AA-452 Story ----> AA-1713 Automation Story
	 * Book    	   ----> Calculuset2e
	 * Sprint	   ----> 53
	 * Environment ----> DEV
	 * 
	 */
	private void initVars(String book) {
		String bookIdentifier = book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		instructorUserName = getData("users.instructor.username");
		instructorPassword = getData("users.instructor.password");
		studentUserName = getData("users.student.username");
		studentPassword = getData("users.student.password");
		schoolName = getData("courseDetails.schoolName");
		welcomePageTitle = getData(bookIdentifier + ".welcomePageTitle");
		productName = getData(bookIdentifier + ".product_name");
		author = getData(bookIdentifier + ".author");
	}
	
	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		test.dashboard.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_A_New_Course() {
		test.dashboard.clickCreateCourseLink(productName, author);
		test.createcoursemodal.verifyCreateCourseOptionsModalWindow();			
		test.createcoursemodal.setNewCourseDetails(courseName, schoolName);
		test.createcoursemodal.createNewCourseBasedOnExisting("No");
		test.dashboard.verifyNewCourseIsCreated(courseName);
	}

	@Test(dependsOnMethods = "Step02_Instructor_Creates_A_New_Course")
	public void Step03_Instructor_Activates_The_New_Course() {
		test.dashboard.activateCourseFromDashBoard(courseName);
		test.dashboard.verifyCourseIsActivated(courseName);
		courseUrl = test.dashboard.getCourseUrl(courseName);
	}
	
	@Test(dependsOnMethods = "Step03_Instructor_Activates_The_New_Course")
	public void Step04_Instructor_Navigates_To_Course_Home_Page() {
		test.dashboard.instructorOpensCourse(courseName);
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Navigates_To_Course_Home_Page")
	public void Step05_Instructor_Creates_Quiz() {	
		test.coursehomepage.startCreatingNewAssignment("Quiz");
		test.fnepage.fillAndSubmitBasicAssignmentInfo(quizName);
	}
	
	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step06_Instructor_Adds_Advanced_Question_To_Quiz() {
		test.fnepage.openFnE_Menu("Questions");
		test.fnepage.selectChapterFromQuestionBank("Chapter 1");
		test.fnepage.selectExerciseFromQuestionBank("Exercises");
		test.fnepage.addSomeQuestionsInQuiz(5);
	}
	
	@Test(dependsOnMethods = "Step06_Instructor_Adds_Advanced_Question_To_Quiz")
	public void Step07_Instructor_Assigns_Newly_Created_Quiz_To_Students () {
		test.fnepage.assignAssignmentToStudents();
	}

	@Test(dependsOnMethods = "Step07_Instructor_Assigns_Newly_Created_Quiz_To_Students")
	public void Step08_Instructor_Sets_Quiz_Settings_To_Show_Solution_After_Every_Attempt() {
		test.fnepage.setQuizAttemptToUnlimited();
		test.fnepage.configureAssessmentSettingsOfQuiz("Show solutions after", "Every attempt");
		test.fnepage.clickSaveButtonOnSettingsPage();
	}
	
	@Test(dependsOnMethods = "Step08_Instructor_Sets_Quiz_Settings_To_Show_Solution_After_Every_Attempt")
	public void Step09_Instructor_Navigates_Back_To_Course_Home_Page() {
		test.fnepage.clickOnDoneEditingButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step09_Instructor_Navigates_Back_To_Course_Home_Page")
	public void Step10_Instructor_Logouts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@Test(dependsOnMethods = "Step10_Instructor_Logouts_Of_The_Application")
	public void Step11_Launch_Application_Login_As_Student() {
		test.launchApplication(courseUrl);
		test.loginPage.loginToTheApplication(studentUserName, studentPassword);
	}

	@Test(dependsOnMethods = "Step11_Launch_Application_Login_As_Student")
	public void Step12_Student_Confirm_And_Join_Course() {
		test.enrollcoursepage.confirmAndJoinCourse(courseUrl);
		test.enrollcoursepage.verifyCongratulationMessage();
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
	}

	@Test(dependsOnMethods = "Step12_Student_Confirm_And_Join_Course")
	public void Step13_Student_Attempts_The_Assigned_Quiz() {
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.verifyStudentNavigatesToFnEPage(quizName);
		test.fnepage.clickOnStartTheQuizButton();
		test.fnepage.clickOnSubmitButton();
		test.fnepage.clickOnYesButtonPresentOnDialogBox();
	}
	
	@Test(dependsOnMethods = "Step13_Student_Attempts_The_Assigned_Quiz")
	public void Step14_Verify_Solution_Of_Questions_Are_Displayed_As_Per_Quiz_Settings() {
		test.fnepage.verifyUserIsOnFnEPageAfterGradingTheQuiz("History for '" + quizName);
		test.fnepage.verifySolutionsOfQuestionsAsPerQuizSettings(true, 5);
	}
	
	@Test(dependsOnMethods = "Step14_Verify_Solution_Of_Questions_Are_Displayed_As_Per_Quiz_Settings")
	public void Step15_Student_Navigates_Back_To_CourseHomePage() {
		test.fnepage.clickOnDoneButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step15_Student_Navigates_Back_To_CourseHomePage")
	public void Step16_Student_SignOuts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@Test(dependsOnMethods = "Step16_Student_SignOuts_Of_The_Application")
	public void Step17_Instructor_Again_Logins_To_The_Application() {
		test.launchApplication(courseUrl);
		test.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
	}

	@Test(dependsOnMethods = "Step17_Instructor_Again_Logins_To_The_Application")
	public void Step18_Instructor_Navigates_To_Course_Home_Page() {
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}
	
	@Test(dependsOnMethods = "Step18_Instructor_Navigates_To_Course_Home_Page")
	public void Step19_Instructor_Edits_Quiz_Settings_Of_Newly_Created_Quiz () {
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.clickOnFneEditActions("Settings");
	}
	
	@Test(dependsOnMethods = "Step19_Instructor_Edits_Quiz_Settings_Of_Newly_Created_Quiz")
	public void Step20_Instructor_Sets_Quiz_Settings_To_Show_Solution_When_Due_Date_Has_Passed() {
		test.fnepage.configureAssessmentSettingsOfQuiz("Show solutions after", "Due Date has passed");
		test.fnepage.clickSaveButtonOnSettingsPage();
	}
	
	@Test(dependsOnMethods = "Step20_Instructor_Sets_Quiz_Settings_To_Show_Solution_When_Due_Date_Has_Passed")
	public void Step21_Instructor_Navigates_Back_To_Course_Home_Page() {
		test.fnepage.clickOnDoneEditingButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step21_Instructor_Navigates_Back_To_Course_Home_Page")
	public void Step22_Instructor_Logouts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@Test(dependsOnMethods = "Step22_Instructor_Logouts_Of_The_Application")
	public void Step23_Student_Again_Login_To_The_Application() {
		test.launchApplication(courseUrl);
		test.loginPage.loginToTheApplication(studentUserName, studentPassword);
	}

	@Test(dependsOnMethods = "Step23_Student_Again_Login_To_The_Application")
	public void Step24_Student_Navigates_From_Welcome_Page_To_Course_Home_Page() {
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
	}

	@Test(dependsOnMethods = "Step24_Student_Navigates_From_Welcome_Page_To_Course_Home_Page")
	public void Step25_Student_Attempts_The_Assigned_Quiz() {
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.verifyStudentNavigatesToFnEPage(quizName);
		test.fnepage.clickOnStartTheQuizButton();
		test.fnepage.clickOnSubmitButton();
		test.fnepage.clickOnYesButtonPresentOnDialogBox();
	}
	
	@Test(dependsOnMethods = "Step25_Student_Attempts_The_Assigned_Quiz")
	public void Step26_Verify_Solution_Of_Questions_Are_Not_Displayed_As_Per_Quiz_Settings() {
		test.fnepage.verifyUserIsOnFnEPageAfterGradingTheQuiz("History for '" + quizName);
		test.fnepage.verifySolutionsOfQuestionsAsPerQuizSettings(false, 0);
	}
	
	@Test(dependsOnMethods = "Step26_Verify_Solution_Of_Questions_Are_Not_Displayed_As_Per_Quiz_Settings")
	public void Step27_Student_Navigates_Back_To_CourseHomePage() {
		test.fnepage.clickOnDoneButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step27_Student_Navigates_Back_To_CourseHomePage")
	public void Step28_Student_SignOuts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@Test(dependsOnMethods = "Step28_Student_SignOuts_Of_The_Application")
	public void Step29_Instructor_Again_Logins_To_The_Application() {
		test.launchApplication(courseUrl);
		test.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
	}

	@Test(dependsOnMethods = "Step29_Instructor_Again_Logins_To_The_Application")
	public void Step30_Instructor_Navigates_To_Course_Home_Page() {
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}
	
	@Test(dependsOnMethods = "Step30_Instructor_Navigates_To_Course_Home_Page")
	public void Step31_Instructor_Edits_Quiz_Settings_Of_Newly_Created_Quiz () {
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.clickOnFneEditActions("Settings");
	}
	
	@Test(dependsOnMethods = "Step31_Instructor_Edits_Quiz_Settings_Of_Newly_Created_Quiz")
	public void Step32_Instructor_Sets_Quiz_Settings_To_Never_Show_Solution_On_Grading_Page() {
		test.fnepage.configureAssessmentSettingsOfQuiz("Show solutions after", "Never");
		test.fnepage.clickSaveButtonOnSettingsPage();
	}
	
	@Test(dependsOnMethods = "Step32_Instructor_Sets_Quiz_Settings_To_Never_Show_Solution_On_Grading_Page")
	public void Step33_Instructor_Navigates_Back_To_Course_Home_Page() {
		test.fnepage.clickOnDoneEditingButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step33_Instructor_Navigates_Back_To_Course_Home_Page")
	public void Step34_Instructor_Logouts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@Test(dependsOnMethods = "Step34_Instructor_Logouts_Of_The_Application")
	public void Step35_Student_Again_Logins_To_The_Application() {
		test.launchApplication(courseUrl);
		test.loginPage.loginToTheApplication(studentUserName, studentPassword);
	}

	@Test(dependsOnMethods = "Step35_Student_Again_Logins_To_The_Application")
	public void Step36_Student_Navigates_From_Welcome_Page_To_Course_Home_Page() {
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
	}

	@Test(dependsOnMethods = "Step36_Student_Navigates_From_Welcome_Page_To_Course_Home_Page")
	public void Step37_Student_Attempts_The_Assigned_Quiz() {
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.verifyStudentNavigatesToFnEPage(quizName);
		test.fnepage.clickOnStartTheQuizButton();
		test.fnepage.clickOnSubmitButton();
		test.fnepage.clickOnYesButtonPresentOnDialogBox();
	}
	
	@Test(dependsOnMethods = "Step37_Student_Attempts_The_Assigned_Quiz")
	public void Step38_Verify_Solution_Of_Questions_Are_Not_Displayed_As_Per_Quiz_Settings() {
		test.fnepage.verifyUserIsOnFnEPageAfterGradingTheQuiz("History for '" + quizName);
		test.fnepage.verifySolutionsOfQuestionsAsPerQuizSettings(false, 0);
	}
	
	@Test(dependsOnMethods = "Step38_Verify_Solution_Of_Questions_Are_Not_Displayed_As_Per_Quiz_Settings")
	public void Step39_Student_Navigates_Back_To_CourseHomePage() {
		test.fnepage.clickOnDoneButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step39_Student_Navigates_Back_To_CourseHomePage")
	public void Step40_Student_SignOuts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@AfterClass
	public void stop_test_session() {
		test.closeBrowserSession();
	}
	
}