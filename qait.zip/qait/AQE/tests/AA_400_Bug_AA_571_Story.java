package com.qait.AQE.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

/**
 * This Test class is Sprint 38 Automation Candidate
 * 
 * <ol>
 * 
 * <li>
 * 
 * <a href="https://macmillanhighered.atlassian.net/browse/AA-400">AA-400</a>
 * 
 * <p> Automation Story: AA-400 - Create script to test copy pasting an answer 
 * 	   response which creates their image in question text that tends to fail the 
 *     'Save' operation and further spoiling the Question xml.  </p>
 * 
 * </li>
 * 
 * </ol>
 * 
 */
public class AA_400_Bug_AA_571_Story extends Parent_Test{
	
	AQETestSessionInitiator test;
	
	String courseName = getStringWithTimestamp("TestAutomation-AA-400");
	String baseUrl, courseUrl;
	String productName, author;
	String schoolName ,welcomePageTitle;
	String instructorUserName, instructorPassword;
	String indexPageButtonText = "Sign In";
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("calculus") String book) {
		test = new AQETestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method){
        test.stepStartMessage(method.getName()); 
    }
	
	/**
	 * AA-400 Bug 	 ----> AA-571 Automation Story
	 * Book			 ----> Book Independent - Script created on Calculus title or any Math Title
	 * Sprint		 ----> 38
	 * Environment	 ----> DEV
	 * 
	 */
	private void initVars(String book) {
		String bookIdentifier = book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		instructorUserName = getData("users.instructor.username");
		instructorPassword = getData("users.instructor.password");
		schoolName = getData("courseDetails.schoolName");
		welcomePageTitle = getData(bookIdentifier + ".welcomePageTitle");
		productName = getData(bookIdentifier + ".product_name");
		author = getData(bookIdentifier + ".author");
	}
	
	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		test.launchApplication("http://dev.macmillanhighered.com/launchpad/calculuset2e/647139");
		//test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		//test.dashboard.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_A_New_Course() {
//		test.dashboard.clickCreateCourseLink(productName, author);
//		test.createcoursemodal.verifyCreateCourseOptionsModalWindow();
//		test.createcoursemodal.setNewCourseDetails(courseName, schoolName);
//		test.createcoursemodal.createNewCourseBasedOnExisting("No");
//		test.dashboard.verifyNewCourseIsCreated(courseName);
	}
	
	@Test(dependsOnMethods = "Step02_Instructor_Creates_A_New_Course")
	public void Step03_Instructor_Activates_The_New_Course() {
//		test.dashboard.activateCourseFromDashBoard(courseName);
//		test.dashboard.verifyCourseIsActivated(courseName);
//		courseUrl = test.dashboard.getCourseUrl(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Activates_The_New_Course")
	public void Step04_Instructor_Navigates_To_Course_Home_Page() {
		//test.dashboard.instructorOpensCourse(courseName);
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Navigates_To_Course_Home_Page")
	public void Step05_Instructor_Creates_Quiz() {
		test.coursehomepage.startCreatingNewAssignment("Quiz");
		test.fnepage.fillAndSubmitBasicAssignmentInfo(courseName + " - Quiz");
	}
	
	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step06_Instructor_Create_And_Add_Advanced_Questions_To_Quiz() {
		test.fnepage.openFnE_Menu("Questions");
		test.fnepage.createNewQuestionType("Advanced Question");
		
		// Note: REMOVE below 2 lines of code after the debugging the ticket
		// test.coursehomepage.clickOnTheAssignedQuiz();
		// test.fnepage.clickEditQuestion();
		
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.validateHtsEditorLinksContainer();
	}
	
	@Test(dependsOnMethods = "Step06_Instructor_Create_And_Add_Advanced_Questions_To_Quiz")
	public void Step07_Instructor_Verify_Alert_Message_While_Copying_And_Paste_Text_Response(){
		test.questioneditor.selectOptionFromResponseArea("Formula");
		test.questioneditor.enterAnswerInFormulaResponseEditor();
		
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.selectOptionFromResponseArea("Text");
		test.questioneditor.textResponseEditor();
		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();
	}
	
	@Test(dependsOnMethods = "Step07_Instructor_Verify_Alert_Message_While_Copying_And_Paste_Text_Response")
	public void Step08_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Numeric_Response(){
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.selectOptionFromResponseArea("Numeric");
		test.questioneditor.createNewNumericResponse("numeric");
		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();
	}
	
	@Test(dependsOnMethods = "Step08_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Numeric_Response")
	public void Step09_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Multiple_Choice_Response(){
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.selectOptionFromResponseArea("Multiple Choice");
		test.questioneditor.multipleChoiceResponse();
		test.questioneditor.saveMultipleChoiceResponseEditor();
		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();
		test.questioneditor.clickOnSaveButtonOfQuestionEditor();
		test.fnepage.clickOnDoneEditingButton();
		test.fnepage.clickOnEditQuestionsButton();
		test.fnepage.clickOnEditLink();
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.validateHtsEditorLinksContainer();
	}
	
	@Test(dependsOnMethods = "Step09_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Multiple_Choice_Response")
	public void Step10_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Numeric_Variable(){
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.clickOnShowVariables();
		test.questioneditor.addNewVariableToTheQuestionInEditorMode("Numeric","Numeric_1");
		test.questioneditor.insertVariableInQuestion("Numeric_1");
		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();
		test.questioneditor.deleteVariable("Numeric_1");
	}
	
	@Test(dependsOnMethods = "Step10_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Numeric_Variable")
	public void Step11_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Text_Variable(){
		test.questioneditor.clickOnSaveButtonOfQuestionEditor();
		test.fnepage.clickOnDoneEditingButton();
		test.fnepage.clickOnEditQuestionsButton();
		test.fnepage.clickOnEditLink();
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.validateHtsEditorLinksContainer();
		test.questioneditor.clearContentOfQuestionTextarea();
		//  adding this line (Remark)
		test.questioneditor.clickOnShowVariables();  
		test.questioneditor.createTextVariable("Text");
		test.questioneditor.insertVariableInQuestion("Text");
		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();
		test.questioneditor.deleteVariable("Text");
	}
	
	@Test(dependsOnMethods = "Step11_Instructor_Verify_Alert_Message_While_Coping_And_Paste_Text_Variable")
	public void Step12_Instructor_Verify_Alert_Message_While_Coping_And_Paste_NumericArray_Variable(){
		// adding this line (Remark)
		 test.questioneditor.clickOnShowVariables();  
		test.questioneditor.createNumericArrayVariable("NumericArray");
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.insertVariableInQuestion("NumericArray");
		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();
		test.questioneditor.deleteVariable("NumericArray");
	}
	
	@Test(dependsOnMethods = "Step12_Instructor_Verify_Alert_Message_While_Coping_And_Paste_NumericArray_Variable")
	public void Step13_Instructor_Verify_Alert_Message_While_Copy_And_Paste_TextArray_Variable(){
		test.questioneditor.createTextArrayVariable("TextArray");
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.insertVariableInQuestion("TextArray");
		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();
		test.questioneditor.deleteVariable("TextArray");
	}
	
	@Test(dependsOnMethods = "Step13_Instructor_Verify_Alert_Message_While_Copy_And_Paste_TextArray_Variable")
	public void Step14_Instructor_Verify_Alert_Message_While_Copy_And_Paste_MathArray_Variable(){
		// Note: Formula Editor is open to add Math Array value to the variable
		test.questioneditor.createMathArrayVariable("MathArray");
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.insertVariableInQuestion("MathArray");
		test.questioneditor.deleteVariable("MathArray");
	}
	
	@Test(dependsOnMethods = "Step14_Instructor_Verify_Alert_Message_While_Copy_And_Paste_MathArray_Variable")
	public void Step15_Instructor_Verify_Response_Dropdown_Disable_While_Adding_Response_To_InCorrectFeedBackSection(){
		// Note: Added below 4 lines of code as to Double click on Multiple Choice Response
		test.refreshPage();
		test.fnepage.verifyUserIsOnQuestionsPage("Questions in this assessment");
		test.fnepage.clickOnEditLink();
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
				
		test.questioneditor.clickOnAddCorrectFeedBackButton();
		test.questioneditor.clickOnTextAreaOfCorrectFeedbackArea();
		test.questioneditor.verifyResponseDropDownIsDisabled();
		test.questioneditor.clickOnTextAreaOfCorrectFeedbackArea();
		
		test.questioneditor.clickOnShowVariables();
		test.questioneditor.addNewVariableToTheQuestionInEditorMode("Numeric","Numeric_1");
		test.questioneditor.clickOnAddInCorrectFeedBackButton();
		test.questioneditor.clickOnTextAreaOfInCorrectFeedbackArea();
		test.questioneditor.windowReturnWindow();
		test.questioneditor.insertVariableInQuestion("Numeric");
//		test.questioneditor.verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse();	
		test.questioneditor.deleteVariable("Numeric");
		test.questioneditor.clickAndClearIncorrectFeedBackArea();
//		test.questioneditor.verifyResponseDropDownIsDisabled();
		
		/*test.questioneditor.selectOptionFromResponseArea("Numeric");
		test.questioneditor.createNewNumericResponse("numeric");*/
	}
	
	@Test(dependsOnMethods = "Step15_Instructor_Verify_Response_Dropdown_Disable_While_Adding_Response_To_InCorrectFeedBackSection")
	public void Step16_Instructor_Navigates_Back_To_CourseHomePage() {
		test.questioneditor.clickOnDoneEditingButton();		
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step16_Instructor_Navigates_Back_To_CourseHomePage")
	public void Step17_Instructor_SignOuts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@AfterClass
	public void stop_test_session() {
		 // test.closeBrowserSession();
	}

}
