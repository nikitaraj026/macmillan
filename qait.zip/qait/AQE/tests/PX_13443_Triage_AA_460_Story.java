package com.qait.AQE.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

/**
 * This Test class is Sprint 35 Automation Candidate
 * 
 * <ol>
 * 
 * <li>
 * <a href="https://macmillanhighered.atlassian.net/browse/PX-13443">PX-13443</a>
 * 
 * <p> Create Automation Story: PX-13443 - Create script to test Advanced Question 
 *     which are not loading neither for Instructor's in Student View nor for 
 *     Students in UCSC course.   </p>
 * 
 * </li>
 * 
 * </ol>
 * 
 */
public class PX_13443_Triage_AA_460_Story extends Parent_Test{
	
	AQETestSessionInitiator test;

	String courseName = getStringWithTimestamp("TestAutomation-PX-13443");
	String quizName = getStringWithTimestamp("TestQuiz-PX-13443");
	String baseUrl, courseUrl, welcomePageTitle;
	String productName, author, schoolName;
	String instructorUserName, instructorPassword;
	String studentUserName, studentPassword;
	
	String indexPageButtonText = "Sign In";

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("ucsc") String book) {
		test = new AQETestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method){
        test.stepStartMessage(method.getName()); 
    }
	
	/**
	 * PX-13443 Triage  ----> AA-460 Automation Story
	 * Book    	  		----> TestingcourseUCSC
	 * Sprint	  		----> 35
	 * Environment		----> DEV
	 * 
	 */
	private void initVars(String book) {
		String bookIdentifier = book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		instructorUserName = getData("users.instructor.username");
		instructorPassword = getData("users.instructor.password");
		studentUserName = getData("users.student.username");
		studentPassword = getData("users.student.password");
		schoolName = getData("courseDetails.schoolName");
		welcomePageTitle = getData(bookIdentifier + ".welcomePageTitle");
		productName = getData(bookIdentifier + ".product_name");
		author = getData(bookIdentifier + ".author");
	}
	
	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(instructorUserName,
				instructorPassword);
		test.dashboard.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_A_New_Course() {
		test.dashboard.clickCreateCourseLink(productName, author);
		test.createcoursemodal.verifyCreateCourseOptionsModalWindow();
		test.createcoursemodal.setNewCourseDetails(courseName, schoolName);
		test.createcoursemodal.createNewCourseBasedOnExisting("No");
		test.dashboard.verifyNewCourseIsCreated(courseName);
	}

	@Test(dependsOnMethods = "Step02_Instructor_Creates_A_New_Course")
	public void Step03_Instructor_Activates_The_New_Course() {
		test.dashboard.activateCourseFromDashBoard(courseName);
		test.dashboard.verifyCourseIsActivated(courseName);
		courseUrl = test.dashboard.getCourseUrl(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Activates_The_New_Course")
	public void Step04_Instructor_Navigates_To_Course_Home_Page() {
		test.dashboard.instructorOpensCourse(courseName);
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Navigates_To_Course_Home_Page")
	public void Step05_Instructor_Creates_Quiz() {
		test.coursehomepage.startCreatingNewAssignment("Quiz");
	}
	
	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step06_Instructor_Adds_Question_To_Quiz() {
		test.fnepage.fillAndSubmitBasicAssignmentInfo(quizName);
		test.fnepage.openFnE_Menu("Questions");
		test.fnepage.selectChapterFromQuestionBank("Chapter 5");
		test.fnepage.selectExerciseFromQuestionBank("UCSC Question");
		test.fnepage.addSomeQuestionsForAA_460Ticket();
	}
	
	@Test(dependsOnMethods = "Step06_Instructor_Adds_Question_To_Quiz")
	public void Step07_Instructor_Assigns_Newly_Created_Quiz_And_Navigates_Back_To_CourseHomePage() {
		test.fnepage.assignAssignmentToStudents();
		test.fnepage.setQuizAttemptToUnlimited();
		test.questioneditor.clickOnDoneEditingButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step07_Instructor_Assigns_Newly_Created_Quiz_And_Navigates_Back_To_CourseHomePage")
	public void Step08_Instructor_Attempts_Assigned_Quiz_In_Student_View(){
		test.coursehomepage.switchToStudentView();
//		test.coursehomepage.verifyAssignedQuizIsVisible(quizName);
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
	}
	
	@Test(dependsOnMethods = "Step08_Instructor_Attempts_Assigned_Quiz_In_Student_View")
	public void Step09_Instructor_Validates_Advanced_Question_Is_Loaded_Completely(){
		test.fnepage.verifyStudentNavigatesToFnEPage(quizName);
		test.fnepage.verifyAdvancedQuestionContentsAreLoadedCompletelyForTicketAA_460();
		test.fnepage.moveBackToCourseHomePageWithoutAttemptingTheQuiz();
	}
	
	@Test(dependsOnMethods = "Step09_Instructor_Validates_Advanced_Question_Is_Loaded_Completely")
	public void Step10_Instructor_SignOuts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}
	
	@Test(dependsOnMethods = "Step10_Instructor_SignOuts_Of_The_Application")
	public void Step11_Launch_Application_Login_As_Student() {
		test.launchApplication(courseUrl);
		test.loginPage.loginToTheApplication(studentUserName, studentPassword);
	}

	@Test(dependsOnMethods = "Step11_Launch_Application_Login_As_Student")
	public void Step12_Student_Confirm_And_Join_Course() {
		test.enrollcoursepage.confirmAndJoinCourse(courseUrl);
		test.enrollcoursepage.verifyCongratulationMessage();
		test.welcomepage.enterCourseFromWelcomePage();
	}

	@Test(dependsOnMethods = "Step12_Student_Confirm_And_Join_Course")
	public void Step13_Student_Attempts_The_Assigned_Quiz() {
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.verifyStudentNavigatesToFnEPage(quizName);
		test.fnepage.verifyAdvancedQuestionContentsAreLoadedCompletelyForTicketAA_460();
		test.fnepage.moveBackToCourseHomePageWithoutAttemptingTheQuiz();
	}
	
	@Test(dependsOnMethods = "Step13_Student_Attempts_The_Assigned_Quiz")
	public void Step14_Student_SignOuts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}

	@AfterClass
	public void stop_test_session() {
		test.closeBrowserSession();
	}
	
}