package com.qait.AQE.tests;

import static com.qait.automation.utils.YamlReader.getData;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qait.automation.AQETestSessionInitiator;

public class CourseCleanUp {

	AQETestSessionInitiator test;
	String baseUrl, instructorPassword;

	@BeforeClass
	public void startTestSession() {
		test = new AQETestSessionInitiator();
		baseUrl = getData("calculus.baseurl");
		instructorPassword = getData("users.instructor.password");
	}

	@Test(dataProvider = "usernames")
	public void Step01_Instructor_Launches_and_Logs_Into_the_Application(String username) {
		test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(username, instructorPassword);
		test.dashboard.verifyDashboardPage();
		test.dashboard.bulkDeleteCourses();
		test.dashboard.logOut();
	}

	@AfterClass(alwaysRun = true)
	public void stop_test_session() {
		test.closeBrowserSession();
	}

	@DataProvider(name = "usernames")
	public Object[][] dataProviderTest() {
		return new Object[][] {
				{ "automation.test1.instructor@macmillan.com" }
		};
	}
}
