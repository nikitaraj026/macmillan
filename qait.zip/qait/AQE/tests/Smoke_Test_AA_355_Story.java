package com.qait.AQE.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

/**
 * This Test class is Sprint 30 Task
 * 
 * SMOKE TESTING - Creating all types of questions from Question Editor
 * 
 */
public class Smoke_Test_AA_355_Story extends Parent_Test{
	
	AQETestSessionInitiator test;

	String courseName = getStringWithTimestamp("AA-355 Smoke Testing");
	String quizName = getStringWithTimestamp("TestQuiz-AA-355 Smoke Testing");
	String baseUrl, courseUrl, welcomePageTitle;
	String productName, author, schoolName;
	String instructorUserName, instructorPassword;

	String indexPageButtonText = "Sign In";
	String previewModalWindowTitle = "Advanced Question Preview";
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("myers") String book) {
		test = new AQETestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method){
        test.stepStartMessage(method.getName()); 
    }
	
	/**
	 * AA-355 Story  ----> SMOKE TESTING 
	 * Book			 ----> Book Independent
	 * Sprint		 ----> 30
	 * Environment	 ----> DEV
	 * 
	 */
	private void initVars(String book) {
		String bookIdentifier = book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		instructorUserName = getData("users.instructor.username");
		instructorPassword = getData("users.instructor.password");
		schoolName = getData("courseDetails.schoolName");
		welcomePageTitle = getData(bookIdentifier + ".welcomePageTitle");
		productName = getData(bookIdentifier + ".product_name");
		author = getData(bookIdentifier + ".author");
	}
	
	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		test.dashboard.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_A_New_Course() {
		test.dashboard.clickCreateCourseLink(productName, author);
		test.createcoursemodal.verifyCreateCourseOptionsModalWindow();
		test.createcoursemodal.setNewCourseDetails(courseName, schoolName);
		test.createcoursemodal.createNewCourseBasedOnExisting("No");
		test.dashboard.verifyNewCourseIsCreated(courseName);
	}

	@Test(dependsOnMethods = "Step02_Instructor_Creates_A_New_Course")
	public void Step03_Instructor_Activates_The_New_Course() {
		test.dashboard.activateCourse(courseName);
		test.dashboard.verifyCourseIsActivated(courseName);
		courseUrl = test.dashboard.getCourseUrl(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Activates_The_New_Course")
	public void Step04_Instructor_Navigates_To_Course_Home_Page() {
		test.dashboard.instructorOpensCourse(courseName);
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}

	@Test(dependsOnMethods = "Step04_Instructor_Navigates_To_Course_Home_Page")
	public void Step05_Instructor_Creates_Quiz() {	
		test.coursehomepage.startCreatingNewAssignment("Quiz");
		test.fnepage.fillAndSubmitBasicAssignmentInfo(quizName);
	}
	
	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step06_Instructor_Adds_Advanced_Question_To_Quiz() {
		test.fnepage.openFnE_Menu("Questions");
		test.fnepage.createNewQuestionType("Advanced Question");
		test.questioneditor.clearContentOfQuestionTextarea();
		test.questioneditor.enterTextContentToQuestionTextarea("Find the value of the integral:");
		test.questioneditor.clickOnInsertFormulaIcon();
		test.questioneditor.createAdvancedQuestionInFormulaEditor();
	}
	
	@Test(dependsOnMethods = "Step06_Instructor_Adds_Advanced_Question_To_Quiz")
	public void Step07_Instructor_Views_And_Validates_Question_In_Editor_Preview() {
		// NOTE: To ByPass ElementNotVisibleException exception i.e., Element is not currently visible 
		//       and so may not be interacted Web-driver sends a sequence of keystrokes to the Question Editor
		//       (Below 4 lines of code MUST BE ADDED)
		test.refreshPage();
		test.fnepage.verifyUserIsOnQuestionsPage("Questions in this assessment");
		test.fnepage.clickOnEditLink();
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
				
		test.questioneditor.clickOnPreviewLink();
		test.questioneditor.verifyPreviewModalWindowIsDisplayed(previewModalWindowTitle);
		test.questioneditor.closePreviewWindow();
	}
	
	@Test(dependsOnMethods = "Step07_Instructor_Views_And_Validates_Question_In_Editor_Preview")
	public void Step08_Instructor_Navigate_Back_To_Course_HomePage(){
		test.fnepage.assignAssignmentToStudents();
		test.questioneditor.clickOnDoneEditingButton();
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step08_Instructor_Navigate_Back_To_Course_HomePage")
	public void Step09_Instructor_Attempts_The_Assigned_Quiz_In_Student_View() {
		test.coursehomepage.switchToStudentView();
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.verifyStudentNavigatesToFnEPage(courseName + " - Quiz");	
		//Student attempts the Quiz for AA-355 Ticket
		test.fnepage.studentAttemptsQuizForAA_311Ticket();
	}
	
	@Test(dependsOnMethods = "Step09_Instructor_Attempts_The_Assigned_Quiz_In_Student_View")
	public void Step10_Instructor_Navigates_Back_To_Course_Home_Page() {
		test.fnepage.clickOnDoneButton();	
		test.fnepage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Step10_Instructor_Navigates_Back_To_Course_Home_Page")
	public void Step11_Instructor_Logouts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}

	@AfterClass
	public void stop_test_session() {
		test.closeBrowserSession();
	}

}
