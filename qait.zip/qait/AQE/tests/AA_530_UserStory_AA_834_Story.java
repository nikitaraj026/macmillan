package com.qait.AQE.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

/**
 * This Test class is Sprint 42 Automation Candidate
 * 
 * <ol>
 * 
 * <li>
 * 
 * <a href="https://macmillanhighered.atlassian.net/browse/AA-530">AA-530</a>
 * 
 * <p> Automation Story: AA-530 - Create automation script to test 'Add' and 'Redo' 
 * 	   							  operations in Editor. 
 * 	     Sub User Story: AA-567 - As an instructor I want to be able to undo my edits to 
 * 								  advanced questions (including edits to formulas, answer
 * 							      options, equations).
 * 	   		        Bug: AA-576 - Undo does not goes back to the previous state in xml and 
 * 								  hence in player, just the answer image is changing.	</p>
 * </li>
 * 
 * </ol>
 * 
 */
public class AA_530_UserStory_AA_834_Story extends Parent_Test{

	AQETestSessionInitiator test;

	String courseName = getStringWithTimestamp("TestAutomation-AA-530");
	String baseUrl, courseUrl;
	String productName, author, welcomePageTitle;
	String instructorUserName, instructorPassword, schoolName;

	String responseValue;
	String editText = "edit text";
	String indexPageButtonText = "Sign In";
	String rawXMLEditorTitle = "Raw XML Editor";
	String textAreaText = "This advance question for test";
	String variableName = "ans";

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("myers") String book) {
		test = new AQETestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method){
		test.stepStartMessage(method.getName()); 
	}

	/**
	 * AA-530 Story ----> AA-834 Automation Story
	 * Book    	    ----> Book Independent
	 * Sprint	    ----> 42
	 * Environment  ----> DEV
	 * 
	 */
	private void initVars(String book) {
		String bookIdentifier = book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		instructorUserName = getData("users.instructor.username");
		instructorPassword = getData("users.instructor.password");
		schoolName = getData("courseDetails.schoolName");
		welcomePageTitle = getData(bookIdentifier + ".welcomePageTitle");
		productName = getData(bookIdentifier + ".product_name");
		author = getData(bookIdentifier + ".author");
	}

	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		test.dashboard.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_A_New_Course() {
		test.dashboard.clickCreateCourseLink(productName , author);
		test.createcoursemodal.verifyCreateCourseOptionsModalWindow();
		test.createcoursemodal.setNewCourseDetails(courseName, schoolName);
		test.createcoursemodal.createNewCourseBasedOnExisting("No");
		test.dashboard.verifyNewCourseIsCreated(courseName);
	}

	@Test(dependsOnMethods = "Step02_Instructor_Creates_A_New_Course")
	public void Step03_Instructor_Activates_The_New_Course() {
		test.dashboard.activateCourseFromDashBoard(courseName);
		test.dashboard.verifyCourseIsActivated(courseName);
		courseUrl = test.dashboard.getCourseUrl(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Activates_The_New_Course")
	public void Step04_Instructor_Navigates_To_Course_Home_Page() {
		test.dashboard.instructorOpensCourse(courseName);
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}

	@Test(dependsOnMethods = "Step04_Instructor_Navigates_To_Course_Home_Page")
	public void Step05_Instructor_Creates_Quiz() {	
		test.coursehomepage.startCreatingNewAssignment("Quiz");
		test.fnepage.fillAndSubmitBasicAssignmentInfo(courseName + " - Quiz");
		test.fnepage.openFnE_Menu("Questions");
	}

	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step06_Instructor_Adds_Question_To_Quiz() {
		test.fnepage.createNewQuestionType("Advanced Question");
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.clearContentOfQuestionTextarea();	
	}

	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step07_Instructor_Creates_Advanced_Question_To_Quiz() {
		test.questioneditor.useXmlToCreateQuestion();
		test.questioneditor.verifyRawXMLEditorFrameIsDisplayed(rawXMLEditorTitle);
		test.questioneditor.fillXmlInTheEditorRawXmlFieldAndSave("AA-530.xml");
		test.questioneditor.clickOnEditorButton();
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
	}

	@Test(dependsOnMethods = "Step07_Instructor_Creates_Advanced_Question_To_Quiz")
	public void Step08_Instructor_Verifies_Undo_Operation_Is_Not_Lost_By_Editing_Text_Of_Question(){
		test.questioneditor.editTextContentOnTextArea(textAreaText, editText);
		test.questioneditor.verifyTextOnTextArea(editText);
		test.questioneditor.undoOperationFromKeyboardOnTextArea();
		test.questioneditor.verifyTextOnTextArea(textAreaText);
		test.questioneditor.clickonRedoButton("1");
	}

	@Test(dependsOnMethods = "Step08_Instructor_Verifies_Undo_Operation_Is_Not_Lost_By_Editing_Text_Of_Question")
	public void Step09_Instructor_Verifies_Undo_Button_Is_Enabled_On_Editing_Text_Of_Question(){
		test.questioneditor.verifyTextOnTextArea(editText);
		test.questioneditor.useXmlToCreateQuestion();
		test.questioneditor.verifyRawXMLEditorFrameIsDisplayed(rawXMLEditorTitle);
		test.questioneditor.verifyTextOnRawXmlAndSave(editText,true);
		test.questioneditor.clickOnEditorButton();	
		test.questioneditor.verifyUndoButtonIsEnableOnTextArea("1",true);
		test.questioneditor.verifyTextOnTextArea(textAreaText);
	}

	@Test(dependsOnMethods = "Step09_Instructor_Verifies_Undo_Button_Is_Enabled_On_Editing_Text_Of_Question")
	public void Step10_Instructor_Verifies_Undo_Operation_On_Editing_Value_Of_Multi_Choice_Response(){
		// Note: Added below 4 lines of code as to Double click on Multiple Choice Response
		test.refreshPage();
		test.fnepage.verifyUserIsOnQuestionsPage("Questions in this assessment");
		test.fnepage.clickOnEditLink();
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		
		test.questioneditor.editMultipleChoiceResponseEditor("multi");
		test.questioneditor.verifyMCQResponseEditorIsDisplayed("Multiple Choice Response Editor");
		responseValue = test.questioneditor.createMultipleChoiceResponseWithActionBuilderClass("99","1");
		test.questioneditor.saveMultipleChoiceResponse();
		test.questioneditor.undoOperationFromKeyboardOnTextArea();
	}

	@Test(dependsOnMethods = "Step10_Instructor_Verifies_Undo_Operation_On_Editing_Value_Of_Multi_Choice_Response")
	public void Step11_Instructor_Verifies_Undo_Operation_On_Editing_Multi_Choice_Response(){
		test.questioneditor.editMultipleChoiceResponseEditor("multi");
		test.questioneditor.verifyMultipleChoiceResponceValue(responseValue, "1");
		test.questioneditor.saveMultipleChoiceResponse();
	}

	@Test(dependsOnMethods = "Step11_Instructor_Verifies_Undo_Operation_On_Editing_Multi_Choice_Response")
	public void Step12_Instructor_Verifies_Undo_Operation_On_Inserting_Variable_In_Advanced_Question(){
		test.questioneditor.insertVariableInQuestion(variableName);
		test.questioneditor.verifyVariableOnTextAreaIsDisplayed(variableName,true);
		test.questioneditor.undoOperationFromKeyboardOnTextArea();
		test.questioneditor.undoOperationFromKeyboardOnTextArea();
		test.questioneditor.verifyVariableOnTextAreaIsDisplayed(variableName, false);
	}

	@Test(dependsOnMethods = "Step12_Instructor_Verifies_Undo_Operation_On_Inserting_Variable_In_Advanced_Question")
	public void Step13_Instructor_Verifies_Undo_Operation_Does_Not_Reverse_The_Change_Of_Text_Variable() {
		test.questioneditor.editTextVariableInQuestionEditor(variableName, "edit");
		test.questioneditor.verifyVariableTextOnVariablesPanel(variableName,"edit",true);
		test.questioneditor.undoOperationFromKeyboardOnTextArea();
		test.questioneditor.verifyVariableTextOnVariablesPanel(variableName,"edit",true); 
	}

	@Test(dependsOnMethods = "Step13_Instructor_Verifies_Undo_Operation_Does_Not_Reverse_The_Change_Of_Text_Variable")
	public void Step14_Instructor_Verifies_Undo_History_Is_Lost_On_Reloading_The_Editor() {
		test.refreshPage();
		test.fnepage.verifyUserIsOnQuestionsPage("Questions in this assessment");
		test.fnepage.clickOnEditLink();
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.verifyUndoButtonIsEnableOnTextArea("1",false);
	}

	@Test(dependsOnMethods = "Step14_Instructor_Verifies_Undo_History_Is_Lost_On_Reloading_The_Editor")
	public void Step15_Instructor_Verifies_Undo_Button_Is_Disabled_On_Drag_And_Drop_Operation() {
		test.questioneditor.dragToReorderStep("1","btn_editorSave");
		test.questioneditor.verifyUndoButtonIsEnableOnTextArea("1",false);
	}

	@Test(dependsOnMethods = "Step15_Instructor_Verifies_Undo_Button_Is_Disabled_On_Drag_And_Drop_Operation")
	public void Step16_Instructor_Verifies_Undo_Button_Is_Disabled_On_Editing_Question_Xml() {
		test.questioneditor.useXmlToCreateQuestion();
		test.questioneditor.verifyRawXMLEditorFrameIsDisplayed(rawXMLEditorTitle);
		test.questioneditor.editRawXmlAtEndOfQuestionXml(" ");
		test.questioneditor.clickOnEditorButton();
	}
	
	/**
	 * AA-576
	 */
	@Test(dependsOnMethods = "Step15_Instructor_Verifies_Undo_Button_Is_Disabled_On_Drag_And_Drop_Operation")
	public void Step17_Instructor_Verifies_Undo_Operation_On_Updating_Response_Of_Question() {
		test.questioneditor.editMultipleChoiceResponseEditor("multi");
		test.questioneditor.verifyMCQResponseEditorIsDisplayed("Multiple Choice Response Editor");
		responseValue = test.questioneditor.createMultipleChoiceResponseWithActionBuilderClass(courseName,"1");
		test.questioneditor.saveMultipleChoiceResponse();
		test.questioneditor.undoOperationFromKeyboardOnTextArea();
	}
	
	@Test(dependsOnMethods = "Step17_Instructor_Verifies_Undo_Operation_On_Updating_Response_Of_Question")
	public void Step18_Instructor_Verifies_Modification_In_Xml_After_Saving_Contents_In_Raw_Xml_Mode() {
		test.questioneditor.useXmlToCreateQuestion();
		test.questioneditor.verifyRawXMLEditorFrameIsDisplayed(rawXMLEditorTitle);
		test.questioneditor.verifyTextOnRawXmlAndSave(courseName, false);
		test.questioneditor.clickOnEditorButton();
	}

	@Test(dependsOnMethods = "Step18_Instructor_Verifies_Modification_In_Xml_After_Saving_Contents_In_Raw_Xml_Mode")
	public void Step19_Instructor_Verifies_Question_Contents_And_Attempts_Quiz_In_Player() {
		test.questioneditor.clickOnPreviewLink();
		test.questioneditor.clickOnRadioButtonUsingTextOnPreview(responseValue);
		test.questioneditor.closePreviewWindow();
	}
	
	@Test(dependsOnMethods = "Step19_Instructor_Verifies_Question_Contents_And_Attempts_Quiz_In_Player")
	public void Step20_Instructor_Navigates_Back_To_Course_Home_Page() {
		test.questioneditor.clickOnDoneEditingButton();
		test.fnepage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = "Step20_Instructor_Navigates_Back_To_Course_Home_Page")
	public void Step21_Instructor_Logouts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}

	@AfterClass
	public void stop_test_session() {
		test.closeBrowserSession();
	}

}