package com.qait.AQE.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.AQETestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

/**
 * This Test class is Sprint 29 Task
 * 
 * SMOKE TESTING - Creating all types of questions from XML
 * 
 */
public class Smoke_Test_AA_311_Story extends Parent_Test{
	
	AQETestSessionInitiator test;
	
	String courseName = getStringWithTimestamp("AA-311 Smoke Testing");
	String quizName = getStringWithTimestamp("TestQuiz-AA-311-Smoke-Test");
	String baseUrl, courseUrl, welcomePageTitle;
	String productName, author, schoolName;
	String instructorUserName, instructorPassword;

	String indexPageButtonText = "Sign In";
	String rawXMLEditorTitle = "Raw XML Editor";
	String previewModalWindowTitle = "Advanced Question Preview";

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("myers") String book) {
		test = new AQETestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method){
        test.stepStartMessage(method.getName()); 
    }
	
	/**
	 * AA-311 Story  ----> SMOKE TESTING 
	 * Book			 ----> Book Independent
	 * Sprint		 ----> 29
	 * Environment	 ----> DEV
	 * 
	 */
	private void initVars(String book) {
		String bookIdentifier = book;
		baseUrl = getData(bookIdentifier + ".baseurl");
		instructorUserName = getData("users.instructor.username");
		instructorPassword = getData("users.instructor.password");
		schoolName = getData("courseDetails.schoolName");
		welcomePageTitle = getData(bookIdentifier + ".welcomePageTitle");
		productName = getData(bookIdentifier + ".product_name");
		author = getData(bookIdentifier + ".author");
	}
	
	@Test
	public void Step01_Launch_Application_Login_As_Instructor() {
		test.launchApplication(baseUrl);
		test.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		test.dashboard.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_Login_As_Instructor")
	public void Step02_Instructor_Creates_A_New_Course() {
		test.dashboard.clickCreateCourseLink(productName, author);
		test.createcoursemodal.verifyCreateCourseOptionsModalWindow();
		test.createcoursemodal.setNewCourseDetails(courseName, schoolName);
		test.createcoursemodal.createNewCourseBasedOnExisting("No");
		test.dashboard.verifyNewCourseIsCreated(courseName);
	}

	@Test(dependsOnMethods = "Step02_Instructor_Creates_A_New_Course")
	public void Step03_Instructor_Activates_The_New_Course() {
		test.dashboard.activateCourse(courseName);
		test.dashboard.verifyCourseIsActivated(courseName);
		courseUrl = test.dashboard.getCourseUrl(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Activates_The_New_Course")
	public void Step04_Instructor_Navigates_To_Course_Home_Page() {
		test.dashboard.instructorOpensCourse(courseName);
		test.welcomepage.verifyUserIsOnWelcomePage(welcomePageTitle);
		test.welcomepage.enterCourseFromWelcomePage();
		test.coursehomepage.verifyUserIsOnCourseHomePage("MENU");
	}

	@Test(dependsOnMethods = "Step04_Instructor_Navigates_To_Course_Home_Page")
	public void Step05_Instructor_Creates_Quiz() {	
		test.coursehomepage.startCreatingNewAssignment("Quiz");
		test.fnepage.fillAndSubmitBasicAssignmentInfo(quizName);
	}

	@Test(dependsOnMethods = "Step05_Instructor_Creates_Quiz")
	public void Step06_Instructor_Adds_Questions_To_Quiz() {
		test.fnepage.openFnE_Menu("Questions");
		test.fnepage.createNewQuestionType("Advanced Question");
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.useXmlToCreateQuestion();
		test.questioneditor.verifyRawXMLEditorFrameIsDisplayed(rawXMLEditorTitle);
		test.questioneditor
				.fillXmlInTheEditorRawXmlFieldAndApply("AA-311 Smoke Test-Advanced Question.xml");
	}

	@Test(dependsOnMethods = "Step06_Instructor_Adds_Questions_To_Quiz")
	public void Step07_Instructor_Verifies_Question_In_Question_Editor() {
		test.questioneditor.waitForQuestionEditorToBeLoadedCompletely();
		test.questioneditor.useXmlToCreateQuestion();
		test.questioneditor.verifyRawXMLEditorFrameIsDisplayed(rawXMLEditorTitle);
		test.questioneditor.fillXmlInTheEditorRawXmlFieldAndApply("AA-311 Ques-4 Question with all possible symbols from eq editor.xml");
		test.questioneditor.clickOnEditorButton();
		test.questioneditor.verifyEditorModeIsDisplayed("Step 1");
		test.questioneditor.verifyHtsVariablesList("AA-311 Ques-4 Question with all possible symbols from eq editor.xml");
	}

	@Test(dependsOnMethods = "Step07_Instructor_Verifies_Question_In_Question_Editor")
	public void Step08_Instructor_Views_And_Validates_Question_In_Editor_Preview() {
		test.questioneditor.clickOnPreviewLink();
		test.questioneditor.verifyPreviewModalWindowIsDisplayed(previewModalWindowTitle);
		test.questioneditor.closePreviewWindow();
		test.fnepage.assignAssignmentToStudents();
	}

	@Test(dependsOnMethods = "Step08_Instructor_Views_And_Validates_Question_In_Editor_Preview")
	public void Step09_Instructor_Navigates_Back_To_Course_HomePage() {
		test.questioneditor.clickOnDoneEditingButton();
		test.fnepage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = "Step09_Instructor_Navigates_Back_To_Course_HomePage")
	public void Step10_Instructor_Attempts_The_Assigned_Quiz_In_Student_View() {
		test.coursehomepage.switchToStudentView();
		test.coursehomepage.clickOnTheAssignedTOCItem(quizName);
		test.fnepage.verifyStudentNavigatesToFnEPage(courseName + " - Quiz");
		test.fnepage.studentAttemptsQuizForAA_311Ticket();
		test.fnepage.verifyStudentAnswer();
	}
	
	@Test(dependsOnMethods = "Step10_Instructor_Attempts_The_Assigned_Quiz_In_Student_View")
	public void Step11_Instructor_Navigates_Back_To_Course_Home_Page() {
		test.fnepage.clickOnDoneButton();	
		test.fnepage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = "Step11_Instructor_Navigates_Back_To_Course_Home_Page")
	public void Step12_Instructor_Logouts_Of_The_Application() {
		test.coursehomepage.clickOnSignOut();
		test.indexPage.verifyUserHasLogoutSuccessfully(indexPageButtonText);
	}

	@AfterClass
	public void stop_test_session() {
		test.closeBrowserSession();
	}

}
