/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.AQE.keywords;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.adobe.genie.executor.Genie;
import com.adobe.genie.executor.LogConfig;
import com.adobe.genie.executor.components.GenieButton;
import com.adobe.genie.executor.components.GenieDisplayObject;
import com.adobe.genie.executor.components.GenieSprite;
import com.adobe.genie.executor.components.GenieTextInput;
import com.adobe.genie.executor.exceptions.StepFailedException;
import com.adobe.genie.executor.exceptions.StepTimedOutException;
import com.adobe.genie.executor.uiEvents.UIKeyBoard;
import com.adobe.genie.genieCom.SWFApp;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.DataReadWrite;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
//import org.sikuli.api.DesktopScreenRegion;
//import org.sikuli.api.ImageTarget;
//import org.sikuli.api.ScreenRegion;
//import org.sikuli.api.Target;
//import org.sikuli.api.robot.Mouse;
//import org.sikuli.api.robot.desktop.DesktopMouse;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

public class QuestionEditorPageAction extends GetPage {

	protected SWFApp app1;
	SoftAssert softAssert = new SoftAssert();

	public QuestionEditorPageAction(WebDriver driver) {
		super(driver, "QuestionEditorPage");
	}

	/**
	 * Verifies whether the Raw XML frame is displayed
	 * 
	 * @param rawXMLEditorTitle
	 *            - Title of Raw XML frame
	 * 
	 */
	public void verifyRawXMLEditorFrameIsDisplayed(String rawXMLEditorTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_rawXMLEditorTitle");

		customAssert.customAssertEquals(element("txt_rawXMLEditorTitle")
				.getText(), rawXMLEditorTitle,
				"Assertion Failed: Raw-XML Editor title is not correct");

		logMessage("Assertion Passed: User is on Question Editor page, Verified Raw-XML "
				+ "Editor title visibility and Title text to be: "
				+ rawXMLEditorTitle);

		switchToDefaultContent();
	}

	/**
	 * Verifies whether the Editor frame is displayed
	 * 
	 * @param editorTitle
	 *            - Title of Editor frame
	 * 
	 */
	public void verifyEditorModeIsDisplayed(String editorTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		waitForElementToBeVisible("txt_editTextvariabeltitle", editorTitle);

		customAssert.customAssertEquals(
				element("txt_editTextvariabeltitle", editorTitle).getText(),
				editorTitle, "Assertion Failed: Editor title is not correct");

		logMessage("Assertion Passed: User is on Question Editor page, Verified Editor title "
				+ "visibility and Title text to be: " + editorTitle);

		switchToDefaultContent();
	}

	/**
	 * Method which uses external XML file to create a New Advanced Question
	 * 
	 */
	public void useXmlToCreateQuestion() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_rawXML").click();
		logMessage("Instructor clicked on 'Raw XML' Mode button");

		// Added hard wait as to wait for the question to load completely in Raw
		// XML mode
		hardWait(1);

		switchToDefaultContent();
	}

	/**
	 * Reads the XML file & writes the content in the provided Text area &
	 * clicks on Apply button. It also verifies the title of AQP in Editor mode.
	 * 
	 * @param xmlName
	 *            - Name of the Xml file
	 * 
	 */
	public void fillXmlInTheEditorRawXmlFieldAndApply(String xmlName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("textarea_rawXMLEditor").clear();
		logMessage("User cleared the contents of TinyMCE");

		String questxmlloc = "";
		if (xmlName.contains("/")) {
			questxmlloc = DataReadWrite.readXmlFromFile(xmlName);
		} else {
			questxmlloc = DataReadWrite
					.readXmlFromFile("./src/test/resources/AA-Artifacts/questions-xmls/"
							+ xmlName);
		}
		element("textarea_rawXMLEditor").sendKeys(questxmlloc);
		logMessage("Entered the contents of XML file in Raw XML field");

		element("btn_editorSave").click();
		logMessage("User clicked on 'Save' button present on dialog box");

		element("btn_editor").click();
		logMessage("Instructor clicked on 'Editor' button");

		// element("btn_applyChangesPopUp").click();
		// logMessage("User clicked on 'Apply' button present on dialog box");

		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();

		switchToDefaultContent();
	}

	/**
	 * Clears the Text area in Raw-XML editor mode, reads the contents of XML
	 * file, keys-in & then Save the contents in Raw XML mode
	 * 
	 * @param xmlName
	 *            - Name of the xml from which data is read & saved in Raw XML
	 *            mode
	 * 
	 */
	public void fillXmlInTheEditorRawXmlFieldAndSave(String xmlName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("textarea_rawXMLEditor").clear();
		logMessage("User cleared the contents of TinyMCE");

		String questxmlloc = "";
		if (xmlName.contains("/")) {
			questxmlloc = DataReadWrite.readXmlFromFile(xmlName);
		} else {
			questxmlloc = DataReadWrite
					.readXmlFromFile("./src/test/resources/AA-Artifacts/questions-xmls/"
							+ xmlName);
			/*
			 * try { questxmlloc = FileUtils.readFileToString(new File(
			 * "./src/test/resources/AA-Artifacts/questions-xmls/" + xmlName),
			 * "UTF-8"); } catch (IOException e) { // TODO Auto-generated catch
			 * block e.printStackTrace(); }
			 */

			// System.out.println("Contents of the XML file: " + questxmlloc);
		}

		element("textarea_rawXMLEditor").sendKeys(questxmlloc);
		logMessage("Keyed-in the contents of XML file in Raw XML field");

		/*
		 * customAssert.customAssertEquals(element("textarea_rawXMLEditor")
		 * .getAttribute("value"), questxmlloc,
		 * "Assertion FAILED: XML contents are not matching!!!");
		 */

		element("btn_editorSave").click();
		logMessage("Saved the contents of the Question");

		// wait.waitForElementToDisappear(element("img_saveDialogBox"));
		switchToDefaultContent();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Method which clicks on 'Apply' button present on Apply Changes Pop-up
	 * while making changes in question Xml
	 * 
	 */
	public void clickOnApplyButtonPresentInApplyChangesPopUp() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_applyChangesPopUp").click();
		logMessage("User clicked on 'Apply' button present on dialog box");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Editor' mode on Question Editor & verifies
	 * whether the mode is switched or not by verifying the title of the same
	 * 
	 */
	public void verifyEditorModeIsDisplayed() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		hardWait(1);
		waitForElementToBeVisible("txt_EditorTitle");
		System.out.println("text: " + element("txt_EditorTitle").getText());
		customAssert.customAssertEquals(element("txt_EditorTitle").getText(),
				"Step 1", "Assertion Failed: Editor title is NOT correct");
		logMessage("Assertion Passed: User is on Question Editor page, Verified Editor title "
				+ "visibility and Title text to be: Step 1");
		switchToDefaultContent();
	}

	/**
	 * Method which clicks on "Save/Discard" button that saves or discard
	 * changes made in editor
	 */
	public void editorChangeOptions(String type) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		waitForElementToBeVisible("btn_editor_changes", type);
		element("btn_editor_changes", type).click();

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on "Save" button that Saves the contents of the
	 * Question & then clicks on "Done Editing" button
	 * 
	 */
	public void saveAdvancedQuestionEditing() {
		waitForMsgToastToDisappear();
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_editorSave").click();
		logMessage("Instructor clicks on 'Save' button of Question Editor");

		switchToDefaultContent();
		waitForMsgToastToDisappear();

		clickOnDoneEditingButton();
	}

	/**
	 * Method which clicks on "Done Editing" button
	 * 
	 */
	public void clickOnDoneEditingButton() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		element("btn_doneEditing").click();
		logMessage("Clicked on 'Done Editing' button");

		waitForLoaderToDisappear();
	}

	/**
	 * Modifying the newly added Question by deleting a HTS variable from Editor
	 * mode in Question editor page
	 * 
	 */
	public void modifyNewlyAddedQuestionInEditorMode() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_showVariables").click();
		logMessage("Instructor clicked on 'Show Variables' button");

		hover(element("elmt_firstHtsVariable"));
		logMessage("Instructor hovered on the Variable panel");

		element("act_deleteHtsVariable").click();
		logMessage("Instructor performed 'Delete' action on the variable");

		/*customAssert.customAssertFalse(verifyHtsVariableIsDeletedFromVariablePanel(),
				"HTS Variable is still present after Deletion in Question Side Panel!!!"); 
		customAssert.customAssertTrue(_verifyHtsVariableIsDeletedFromTheQuestionTextArea(),
				"HTS Variable is still present after Deletion in Question Text Area!!!");*/
		
		switchToDefaultContent();
	}

	/**
	 * Verifying PopUp heading and click on 'OK' button in the Popup
	 * 
	 */
	public void verifyAlertHeadingAndClickOnOkButton(String alertMsg) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert.customAssertEquals(element("txt_variableRefWarning",alertMsg)
				.getText(), alertMsg,
				"Assertion Failed: Title of the PopUp is NOT matching");

		element("btn_warningPopupOk").click();
		logMessage("Instructor clicked on 'Ok' button present on the alert box");

		switchToDefaultContent();
	}

	/**
	 * Verifying whether the HTS variable is deleted from Question Text area
	 * after deleting the variable in Editor mode
	 * 
	 */
	public boolean _verifyHtsVariableIsDeletedFromTheQuestionTextArea() {
		boolean flag = false;
		String questionText = null;

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_editorQuestionFrame"));

		for (int i = 0; i < elements("txt_htsQuestionContentsCount").size(); i++) {
			questionText = element("txt_htsQuestionContents",
					String.valueOf(i + 1)).getText();
			if (questionText.contains("b")) {
				logMessage("HTS variable is still present after deleting it from Question Text area in Editor mode!");
				flag = false;
				return flag;
			} else {
				logMessage("HTS variable is deleted successfully!!!");
				flag = true;
			}
		}
		switchToDefaultContent();
		return flag;
	}

	/**
	 * Verifying whether the HTS variable is deleted from Question Side Panel
	 * after deleting the variable in Editor mode
	 * 
	 */
	public boolean verifyHtsVariableIsDeletedFromVariablePanel(String variable) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		// Added Hard Wait for the element to load in Variable Panel
		hardWait(1);

		List<WebElement> allVariableNames = elements("list_allVariables");
		for (WebElement variableName : allVariableNames) {
			if (variableName.getText().equalsIgnoreCase(variable))
				return false;
		}
		return true;
	}

	public void verifyAddedVariable(String variableName)
	{
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		isElementDisplayed("link_createdVariable", variableName);
		verifyTextOfElementIsCorrect("text_variableDetails", variableName, "[sin(&theta;+&chi;)]");
		hover(element("link_createdVariable", variableName));
		isElementDisplayed("lnk_editCreatedVariable", variableName);
		element("lnk_editCreatedVariable", variableName).click();
		isElementDisplayed("Math_input");
		element("Math_input").click();
		verifyAddedMathVariable();
		waitForElementToBeVisible("btn_formSave");
		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the form");
	}


	/**
	 * Selects a 'Numeric' variable from 'Add Variable' drop down & provides
	 * necessary fields to complete the task. Then 'Save' the changes in
	 * 'Editing Numeric Variable' form. Verifies whether the variable is added
	 * to the list of variables located under the side panel of the question
	 * 
	 */
	public void addNewVariableToTheQuestionInEditorMode( String variableType,String variableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		wait.waitForElementToBeClickable(element("drpdown_addVariable"));

		element("drpdown_addVariable").click();
		logMessage("Instructor clicked on 'Add Variable' button");
		hardWait(1);
		element("opt_htsVaribleType",variableType).click();
		logMessage("Instructor clicked on '"+variableType+"' dropdown value from the list");

		switchToDefaultContent();
//		String id=element("iframe_mainframe").getAttribute("id");
//		hardWait(4);
//		executeJavascript("document.getElementById('"+id+"').contentDocument.getElementsByClassName(\"hts-"+variableName.toLowerCase()+"-variable-dialog hts-side-dialog\")[0].style=\"display:block\";");
		switchToFrame(element("iframe_mainFrame"));					


		if(variableType.equals("Numeric"))
		{
			scroll(element("txtbox_name"));
			element("txtbox_name").sendKeys(variableName);
			logMessage("Instructor entered '" + variableName + "' in Numeric textbox");
			element("radio_list").click();
			element("txtbox_inclusion").sendKeys("1,2,3");
			logMessage("Instructor keys-in necessary values for Numeric response Editor");
		}
		else if(variableType.equals("Text"))
		{
			scroll(element("txtBox_nameForTxtVariable"));
			element("txtBox_nameForTxtVariable").sendKeys(variableName);
			logMessage("Instructor entered '" + variableName + "' in Numeric textbox");
			element("txt_string").click();
			element("txt_string").sendKeys("test string");
			logMessage("Instructor keys-in necessary value for Text Response Editor");
		}
		else if(variableType.equals("Math"))
		{
			scroll(element("txtBox_nameForMathVariable"));			
			element("txtBox_nameForMathVariable").sendKeys(variableName);
			logMessage("Instructor entered '" + variableName + "' in Math textbox");
			element("Math_input").click();
			logMessage("Instructor clicks Math input in Response Editor");
			addMathVariableUsingGenie();
		}


		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the form");
		customAssert.customAssertFalse(verifyHtsVariableIsDeletedFromVariablePanel(variableName),"HTS Variable is NOT present even after Adding a Numeric Variable from Variable Panel!!!");

		switchToDefaultContent();
	}

	public void addMathVariableUsingGenie() {
		String objectType = "[object MainTimeline]";
		initializingGenie(objectType);
		addMathVariable();		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void addMathVariable() {
		try {
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_trig::PX^0::PTR^0::IX^9::ITR^0",app1)).click();
			(new GenieDisplayObject("SP^Stage:::FP^Stage:::SE^MC_trig::PX^-1::PTR^0::IX^2::ITR^0",app1)).click(28,15,136,49,500,271,2,false);
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_greek::PX^0::PTR^0::IX^15::ITR^0",app1)).click();
			(new GenieDisplayObject("SP^Stage:::FP^Stage:::SE^MC_greek::PX^-1::PTR^0::IX^5::ITR^0",app1)).click(41,44,335,78,500,271,2,false);
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_ops::PX^0::PTR^0::IX^10::ITR^0",app1)).click();
			(new GenieDisplayObject("SP^Stage:::FP^Stage:::SE^MC_ops::PX^-1::PTR^0::IX^3::ITR^0",app1)).click(18,15,188,49,500,271,2,false);
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_greek::PX^0::PTR^0::IX^15::ITR^0",app1)).click();
			(new GenieDisplayObject("SP^Stage:::FP^Stage:::SE^MC_greek::PX^-1::PTR^0::IX^5::ITR^0",app1)).click(88,67,382,101,500,271,2,false);
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_submit::PX^0::PTR^0::IX^14::ITR^0",app1)).click();
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}

	public void verifyAddedMathVariable()
	{
		String objectType = "[object MainTimeline]";
		initializingGenie(objectType);
		try {
			(new GenieButton("FP^Stage:::SE^Sprite:::CH^EqEditor::PX^-1::PTR^0::IX^1::ITR^0",app1)).isVisible();
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_cancel::PX^0::PTR^0::IX^13::ITR^0",app1)).click();
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}	
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}
	/**
	 * Edit Variable in Question Editor
	 * 
	 * @param variableName
	 * 
	 */
	public void editVariableInQuestionEditor(String variableName) {
		clickOnShowVariables();
		clickVariableEditButton(variableName);

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		element("txtbox_name").sendKeys(variableName);
		element("radio_list").click();
		element("txtbox_inclusion").sendKeys("1,2,3");
		logMessage("Instructor keys-in necessary values for Numeric response Editor");
		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the form");
	}

	public void clickVariableEditButton(String variableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("btn_addVariable");
		wait.waitForElementToBeVisible(element("list_htsVariable", variableName));

		hover(element("list_htsVariable", variableName));
		element("icon_editHtsVariable", variableName).click();
		logMessage("Instructor clicked on Hts vaiable '" + variableName
				+ "' present in Variable Panel");
		wait.waitForElementToBeVisible(element("txtbox_name"));
	}

	/**
	 * Switches to the frame where action has to be performed & calls the method
	 * which verifies whether the HTS variables are re-ordered automatically
	 * 
	 */
	public void validateVariablesAreReorderedAutomaticallyInRawXmlMode() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert.customAssertTrue(
				_verifyVariablesAreReorderedAutomaticallyInRawXmlMode(),
				"HTS Variables are NOT Re-Ordered automatically!!!!");

		switchToDefaultContent();
	}

	/**
	 * Verifies whether the HTS variables are re-ordered automatically when
	 * changed the variables placing in xml by moving their vardef tags and
	 * content after variables that uses them
	 * 
	 */
	private boolean _verifyVariablesAreReorderedAutomaticallyInRawXmlMode() {
		String contentsText = element("textarea_rawXMLEditor").getAttribute(
				"value");
		int indexOfA = contentsText.indexOf("<vardef name=\"a\"");
		int indexOfB = contentsText.indexOf("<vardef name=\"b\"");

		System.out
		.println("Index of 'a' variable in Raw XML mode: " + indexOfA);
		System.out
		.println("Index of 'b' variable in Raw XML mode: " + indexOfB);

		if (indexOfB > indexOfA) {
			logMessage("Assertion Passed: Variable are Re-Ordered automatically!!!!");
			return true;
		} else {
			return false;
		}
	}

	/**
	 * Method saves the advanced question after editing the advanced question
	 * 
	 */
	public void saveAdvancedQuestionAfterEditing() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		element("btn_editorSave").click();
	}

	public void editAdvanceQuestionAndNavigateToEditor()
	{
		isElementDisplayed("lnk_previewAdvanceQuestionCreated");
		hover(element("lnk_previewAdvanceQuestionCreated"));
		isElementDisplayed("lnk_editAdvanceQuestionCreated");
		element("lnk_editAdvanceQuestionCreated").click();
		waitForLoaderToAppear();
		waitForLoaderToDisappear();
	}

	/**
	 * Method which clicks on the 'Preview' link on the Question editor page
	 * 
	 */
	public void clickOnPreviewLink() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		switchToDefaultContent();
		waitScrollAndClick("link_portalQuestionPreview");
//		element("link_portalQuestionPreview").click();
		logMessage("Instructor clicked on 'Preview' link present on Question Editor modal");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Verify whether the Preview modal window is displayed with its title
	 * 
	 * @param questionEditorTitle
	 */
	public void verifyPreviewModalWindowIsDisplayedAndThenCloseIt(
			String previewModalTitle) {
		isElementDisplayed("txt_previewModalWindowTitle");
		customAssert.customAssertEquals(element("txt_previewModalWindowTitle")
				.getText(), previewModalTitle,
				"Assertion Failed: Preview Modal Window title is not correct.");

		isElementDisplayed("btn_regenerateVariables");
		isElementDisplayed("img_close");

		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		isElementDisplayed("btn_submit");

		switchToDefaultContent();
		element("img_close").click();

		logMessage("Assertion Passed: User is on Preview Modal Window, Verified Page title "
				+ "visibility and Title text to be: " + previewModalTitle);
	}

	/**
	 * Validate the text present in the Question while previewing the question
	 * in Preview Modal window
	 * 
	 */
	public void validateQuestionContents() {
		String quesText = getData("AA-206.txt_validation");
		String count = getData("AA-206.repetition_count");

		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		for (int i = 0; i < Integer.parseInt(count); i++) {
			customAssert.customAssertTrue(element("txt_htsQuestion").getText()
					.contains(quesText), "Question is NOT loaded CORRECTLY!!!");
		}
		switchToDefaultContent();
	}

	/**
	 * This function returns number of images appeared in the question editor
	 * for step 1
	 * 
	 * @String : Number of images
	 */
	public int countNumberofImagesInQuestion() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		List<WebElement> count = elements("img_totalImagesInQuestion");
		switchToDefaultContent();
		return count.size();
	}

	public void verifyCountOfNumberofImagesInQuestion(int expectedCount) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		List<WebElement> count = elements("img_totalImagesInQuestion");
		customAssert.customAssertEquals(count.size(), expectedCount,
				"Assertion Failed : No. of images count is NOT Equal!!!");
		logMessage("Assertion Passed : No. of images in question are equal");

		switchToDefaultContent();
	}

	/**
	 * Closes the Preview Modal window
	 * 
	 */
	public void closePreviewWindow() {
		isElementDisplayed("img_close");

		element("img_close").click();
		logMessage("Instructor clicked on 'X' button present on Preview modal window");
	}

	/**
	 * Method navigates back to "Question" Tab after addition of a question to
	 * Quiz
	 * 
	 */
	public void navigateBackToQuestionTabOnFnEPage() {
		element("btn_doneEditing").click();
		logMessage("Instructor clicked on 'Done Editing' button");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		hover(element("btn_edit"));
		element("opt_question").click();
		logMessage("User clicked on 'Edit' Tab on FandE page");

		waitForLoaderToDisappear();
	}

	/**
	 * Method which creates "Multiple Choice" type question & adds it to Quiz
	 * 
	 */
	public void addMultipleChoiceQuestionToQuiz() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		waitForElementToBeVisible("txtarea_QuestionTextArea");

		element("txtarea_QuestionTextArea").click();
		element("txtarea_QuestionTextArea").sendKeys(
				"The process of removing the deficiencies "
						+ "and loopholes in the data is called as");
		element("txtarea_QuestionTextArea").sendKeys(Keys.RETURN);

		element("input_choice1").sendKeys("Aggregation of data");
		element("input_choice1").sendKeys(Keys.RETURN);

		element("input_choice2").sendKeys("Extracting of data");
		element("input_choice2").sendKeys(Keys.RETURN);

		element("input_choice3").sendKeys("Cleaning up of data");
		element("input_choice3").sendKeys(Keys.RETURN);

		element("input_choice4").sendKeys("Loading of data");
		element("input_choice4").sendKeys(Keys.RETURN);

		element("input_choice5").sendKeys("Compression of data");

		wait.waitForElementToBeVisible(element("input_choice3"));
		element("btn_radioChoice3").click();

		switchToDefaultContent();

		element("btn_questionEditorSave").click();
		logMessage("Instructor clicked on 'Save' button in question editor");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		navigateBackToQuestionTabOnFnEPage();
	}

	/**
	 * Method which creates "Short Answer" type question & adds it to Quiz
	 * 
	 */
	public void addShortAnswerQuestionToQuiz() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("txtarea_QuestionTextArea").click();
		logMessage("Instructor clicked on Question Text of 'Short Answer' question type");

		element("txtarea_QuestionTextArea").sendKeys("What is thrashing?");
		element("txtarea_QuestionTextArea").sendKeys(Keys.RETURN);

		element("txtarea_shortAnswer")
		.sendKeys(
				"It is a phenomenon in virtual memory schemes when the processor "
						+ "spends most of its time swapping pages, rather than executing instructions. "
						+ "This is due to an inordinate number of page faults.");

		switchToDefaultContent();

		element("btn_questionEditorSave").click();
		logMessage("Instructor clicked on 'Save' button present on Question Editor");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		navigateBackToQuestionTabOnFnEPage();
	}

	/**
	 * Method which creates "Essay" type question & adds it to Quiz
	 * 
	 */
	public void addEssayQuestionToQuiz() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("txtarea_QuestionTextArea").click();
		logMessage("Instructor clicked on Question Text of 'Essay' question type");

		element("txtarea_QuestionTextArea").sendKeys(
				"Describe the Buddy system of memory allocation.");

		switchToDefaultContent();

		element("btn_questionEditorSave").click();
		logMessage("Instructor clicked on 'Save' button present on Question Editor");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		navigateBackToQuestionTabOnFnEPage();
	}

	/**
	 * Method which creates "Matching" type question & adds it to Quiz
	 * 
	 */
	public void addMatchingQuestionToQuiz() {
		String[] optionValues = { "Feli",
				"Goblet-shaped drum played by master drummer", "Kora",
				"Harp-lute found in West Africa", "Koning",
				"Triangular frame-zither", "Ghong-kpala", "Musical bow" };

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("txtarea_QuestionTextArea").click();
		logMessage("Instructor clicked on Question Text of 'Matching' question type");

		element("txtarea_QuestionTextArea").sendKeys(
				"Matching: Match the instrument " + "with its description.");
		element("txtarea_QuestionTextArea").sendKeys(Keys.RETURN);

		for (int i = 0; i < optionValues.length; i++) {
			if ((i % 2 == 0) && (i != 0)) {
				element("txtarea_matchingOptions", String.valueOf(i)).sendKeys(
						Keys.RETURN);
			}
			element("txtarea_matchingOptions", String.valueOf(i + 1)).click();
			element("txtarea_matchingOptions", String.valueOf(i + 1)).sendKeys(
					optionValues[i]);
		}

		switchToDefaultContent();

		element("btn_questionEditorSave").click();
		logMessage("Instructor clicked on 'Save' button present on Question Editor");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		navigateBackToQuestionTabOnFnEPage();
	}

	/**
	 * Method which creates "Multiple Answer" type question & adds it to Quiz
	 * 
	 */
	public void addMultipleAnswerQuestion() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("txtarea_QuestionTextArea").click();
		logMessage("Instructor clicked on Question Text of 'Multiple Answer' question type");

		element("txtarea_QuestionTextArea").sendKeys(
				"Which of the following gases are not "
						+ "the Composition of Earth's atmosphere?");
		element("txtarea_QuestionTextArea").sendKeys(Keys.RETURN);

		element("input_choice1").sendKeys("Natural Gas");
		element("input_choice1").sendKeys(Keys.RETURN);

		customAssert.customAssertTrue(
				enterData(element("input_choice2"), "Oxygen"),
				"Assertion Failed: Unable to enter value in text field");
		element("input_choice2").sendKeys(Keys.RETURN);

		element("input_choice3").sendKeys("Propane");
		element("input_choice3").sendKeys(Keys.RETURN);

		element("input_choice4").sendKeys("Nitrogen");

		element("input_chkBoxChoice1").click();
		element("input_chkBoxChoice3").click();
		logMessage("Instructor has selected the answers of Multiple Answer");

		switchToDefaultContent();

		element("btn_questionEditorSave").click();
		logMessage("Instructor clicked on 'Save' button present on Question Editor");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		navigateBackToQuestionTabOnFnEPage();
	}

	/**
	 * Saves the advanced Question & navigates back to FnE page
	 * 
	 */
	public void saveAdvancedQuestion() {
		waitForMsgToastToDisappear();
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_editorSave").click();
		logMessage("Instructor clicked on 'Save' button present on Question Editor");

		switchToDefaultContent();
		waitForMsgToastToDisappear();

		element("btn_backToQuestionBank").click();
		logMessage("Instructor clicked on 'Back To Question Bank' button");
	}

	/**
	 * Method which creates "Essay" type question & adds it to Quiz
	 * 
	 */
	public void addGraphicalExerciseToQuiz() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		String objectType = "[object Main]";
		initializingGenie(objectType);
		drawGraphForGraphicalQuestion();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Method which starts up Genie to connect it with Application
	 * 
	 */
	public void initializingGenie(String object) {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		LogConfig l = new LogConfig();
		Genie g = null;
		try {
			Genie.EXIT_ON_FAILURE = true;
			Genie.CAPTURE_SCREENSHOT_ON_FAILURE = true;
			g = Genie.init(l);
			app1 = g.connectToApp(object);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * Draw graph for graphical question & the question Text
	 * 
	 */
	public void drawGraphForGraphicalQuestion() {
		try {
			(new GenieDisplayObject(
					"SP^root:::FP^toolsBg:::SE^TwoPointLineSkin::PX^6::PTR^0::IX^2::ITR^0",
					app1)).click(17, 15, 32, 114, 1100, 900, 3, true);
			(new GenieSprite(
					"SP^root:::FP^graphParts:::SE^Sprite::PX^1::PTR^0::IX^4::ITR^0",
					app1)).click(77, 85, 195, 137, 1100, 900, 3, true);
			(new GenieSprite(
					"SP^root:::FP^graphParts:::SE^Sprite::PX^1::PTR^0::IX^4::ITR^0",
					app1)).click(183, 255, 301, 307, 1100, 900, 3, true);
			(new GenieTextInput(
					"SP^Stage:::FP^root:::SE^questionInput::PX^0::PTR^0::IX^6::ITR^0",
					app1)).selectText(0, 0);
			(new GenieTextInput(
					"SP^Stage:::FP^root:::SE^questionInput::PX^0::PTR^0::IX^7::ITR^0",
					app1)).input("Find the slope of the line?");
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}
	
	

	/**
	 * Method which clears & renames the Title of the Advanced Question by
	 * clicking on 'Properties' link
	 * 
	 */
	public void renameTitleOfAdvancedQuestion() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("link_properties").click();
		logMessage("Clicked on Properties link");
		element("txtbox_editorTitle").clear();
		element("txtbox_editorTitle").sendKeys("AA-311 Smoke Test");
		logMessage("ReNamed the Title of Advanced Question");

		element("btn_close").click();
		element("btn_editorSave").click();

		wait.waitForElementToDisappear(element("img_saveDialogBox"));
		switchToDefaultContent();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Method which clicks on "Clear" button in Advanced Question Editor
	 * 
	 */
	public void clearQuestionEditor() {
		try {
			(new GenieButton(
					"SP^Stage:::FP^root:::SE^btn_clear::PX^0::PTR^0::IX^1::ITR^0",
					app1)).click();
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method which creates a mathematical expression
	 * 
	 */
	public void createMathematicalExpression() {
		try {
			(new UIKeyBoard()).typeText("y=f(x+1)");
			System.out.println("Via UIKeyBoard");
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method which focuses the cursor on Formula Editor
	 * 
	 */
//	public void focusOnFormulaEditor() {
//		ScreenRegion s = new DesktopScreenRegion();
//		String currentDir = System.getProperty("user.dir");
//		try {
//			URL imageURL = new URL(
//					"file:///"
//							+ currentDir
//							+ "/src/test/resources/AA-Artifacts/questions-images/Cursor_Location.png");
//			Target imageTarget = new ImageTarget(imageURL);
//
//			ScreenRegion r = s.wait(imageTarget, 10000);
//			Mouse mouse = new DesktopMouse();
//			mouse.click(r.getCenter());
//			logMessage("Clicked on Formula Editor to put the cursor on it");
//		} catch (Exception e) {
//			e.printStackTrace();
//			customAssert.customAssertTrue(false,
//					"Unable to click on Formula Editor!!!");
//		}
//	}

	/**
	 * Method which verifies that the Advanced tool bar icons are displayed
	 */

	public void verifyAdvancedToolBarIcons(String blocktype) {
		switchToDefaultContent();
		logMessage("switched to default content");
		switchToFrame(element("iframe_mainFrame"));
		logMessage("switched to mainframe");
		hardWait(3);
		isElementDisplayed("btn_bold", blocktype);
		isElementDisplayed("btn_fullalign", blocktype);
		isElementDisplayed("btn_indent", blocktype);
		logMessage("The advanced tool bar is displayed.");
	}

	/**
	 * instructor enters text in hint section
	 */
	public void enterTextInHintEditor() {
		switchToDefaultContent();
		String id = element("iframe_mainframe").getAttribute("id");
		switchToFrame(element("iframe_mainframe"));
		String id1 = element("iframe_editorHint").getAttribute("id");
		hardWait(2);
		switchToDefaultContent();
		executeJavascript("document.getElementById('"
				+ id
				+ "').contentDocument.getElementById('"
				+ id1
				+ "').contentDocument.getElementsByTagName('p')[0].innerHTML=\"Test Hint\";");
		logMessage("text entered in hint block");
	}

	/**
	 * Instructor deletes the hint section
	 * 
	 */
	@SuppressWarnings("unused")
	public void instructorDeletesHintSection() {
		switchToDefaultContent();
		String id = element("iframe_mainframe").getAttribute("id");
		switchToFrame(element("iframe_mainframe"));

		String id1 = element("iframe_editorHint").getAttribute("id");
		switchToFrame(element("iframe_editorHint"));

		WebElement txtarea = driver.findElement(By
				.xpath(".//*[@id='tinymce']/p"));
		Actions act = new Actions(driver);
		act.doubleClick(txtarea).build().perform();
		switchToDefaultContent();

		hardWait(3);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('"
				+ id
				+ "').contentDocument.querySelectorAll(\"div[data-qe-nodetype='hint']\")[0].children[0].children[1].click();");
		handleAlert();
		logMessage("Hint section deleted");
	}

	/**
	 * Method which modifies the contents of Advanced Question in the Quiz
	 * 
	 */
	public void modifyAdvancedQuestionForAA_311_SmokeTest() {
		String objectName1 = "[object MainTimeline]";

		renameTitleOfAdvancedQuestion();

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("img_ExpressionAA_311").click();
		doubleClick(element("img_ExpressionAA_311"));
		switchToDefaultContent();

		initializingGenie(objectName1);
		clearQuestionEditor();

		//focusOnFormulaEditor();

		createMathematicalExpression();
		clickOnSubmitButtonPresentOnFormulaEditorWindow();
	}

	/**
	 * Method which clicks on "Submit" button in Advanced Question Editor
	 * 
	 */
	public void clickOnSubmitButtonPresentOnFormulaEditorWindow() {
		try {
			(new GenieButton(
					"SP^Stage:::FP^root:::SE^btn_submit::PX^0::PTR^0::IX^14::ITR^0",
					app1)).click();
			logMessage("User clicked on 'Submit' button of Formula Editor");
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method which counts the number of variables in the XML file i.e., count
	 * the no. of <vardef> tags
	 * 
	 */
	public int countNumberOfVariablesInXML(String xmlName, String match) {
		int counter = 0;
		BufferedReader br = null;
		try {
			String xmlLine;
			br = new BufferedReader(new FileReader(
					"./src/test/resources/AA-Artifacts/questions-xmls/"
							+ xmlName));
			while ((xmlLine = br.readLine()) != null) {
				if (xmlLine.contains(match)) {
					counter++;
				}
			}
			logMessage("Total No. of variables in the XML file: " + counter);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return counter;
	}

	/**
	 * Method to verify the list of HTS variables displayed on Variable Panel
	 * 
	 */
	public void verifyHtsVariablesList(String xmlFile) {
		int count = countNumberOfVariablesInXML(xmlFile, "<vardef");

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_showVariables").click();
		logMessage("Instructor clicked on 'Show Variables' button");

		if (elements("list_htsVariables").size() == count) {
			logMessage("Variables are displayed in the Variable Side Panel as DEFINED in XML file!!!");
		} else {
			logMessage("Variables are NOT DISPLAYED in the Variable Side Panel as defined in XML file!!!");
			Assert.fail();
		}
		switchToDefaultContent();
	}

	/**
	 * Method which clears the default content of Question Text area of Question
	 * Editor
	 * 
	 */
	public void clearContentOfQuestionTextarea() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").clear();
		logMessage("Instructor Cleared the default text of Question Text area");

		switchToDefaultContent();
	}

	/**
	 * Method which clears the Question Text area, writes the Question text &
	 * then clicks on Insert formula icon for inserting formula in the question
	 * 
	 */
	public void clickOnInsertFormulaIcon() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("img_insertFormula").click();
		logMessage("Instructor clicked on 'Insert Formula' icon");

		switchToDefaultContent();
	}

	/**
	 * Method which adds Response Area to the Question
	 * 
	 */
	public void addResponseAreaToQuestion(String responseType) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("drpdown_insertResponseArea").click();
		logMessage("Instructor clicked on 'Insert Response Area' Drop down");

		String compare = null;
		for (int i = 0; i < 3; i++) {
			compare = element("txt_responseAreaOption", String.valueOf(i + 1))
					.getText();
			if (compare.equalsIgnoreCase(responseType)) {
				element("txt_responseAreaOption", String.valueOf(i + 1))
				.click();
				logMessage("Clicked on '" + compare + "' response type");
				break;
			}
		}
		switchToDefaultContent();
	}

	/**
	 * Verify whether the Text Response Editor is displayed with its title
	 * 
	 * @param responseEditorTitle
	 * 
	 */
	private void _verifyTextResponseEditorIsDisplayed(String responseEditorTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_responseEditorTitle");
		customAssert.customAssertEquals(element("txt_responseEditorTitle")
				.getText(), responseEditorTitle,
				"Assertion Failed: Text Response Editor Title is NOT Correct");

		switchToFrame(element("iframe_responseEditor"));

		isElementDisplayed("btn_textAddCorrectAnswer");
		isElementDisplayed("btn_textResponseEditorSave");
		isElementDisplayed("btn_textResponseEditorCancel");

		logMessage("Assertion Passed: User is opened Text Response Editor, Verified Page title "
				+ "visibility and Title text to be: " + responseEditorTitle);
		switchToDefaultContent();
	}

	/**
	 * Method which fills the fields in Text Editor to insert 'Text' Response
	 * Area
	 * 
	 */
	public void textResponseEditor() {
		_verifyTextResponseEditorIsDisplayed("Text Response Editor");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_responseEditor");

		element("txtbox_textResponseEditorAnswerInput").sendKeys(" ");

		element("btn_textResponseEditorSave").click();
		logMessage("Instructor clicked on 'Save' button present on 'Text Response Editor'");

		switchToDefaultContent();
	}

	public void clickOnAddCorrectFeedBackButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		waitForElementToBeVisible("btn_addCorrectFeedback");
		element("btn_addCorrectFeedback").click();
		wait.waitForElementToBeVisible(element("txt_correctFeedbackHeader"));
		switchToDefaultContent();
	}

	public void clickOnTextAreaOfCorrectFeedbackArea() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_editorCorrectFeedback"));

		element("txt_questionTextArea").clear();
		element("txt_questionTextArea").click();

		switchToDefaultContent();
	}

	public void clickOnTextAreaOfInCorrectFeedbackArea() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_editorInCorrectFeedback"));

		element("txt_questionTextArea").clear();
		element("txt_questionTextArea").click();

		switchToDefaultContent();
	}

	/**
	 * Method which adds Hint to the Question
	 * 
	 */
	private void _addHintToQuestion(String hint) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_addHint").click();
		logMessage("instructor clicked on 'Add Hint' button");

		wait.waitForElementToBeVisible(element("txt_hintHeader"));

		switchToFrame(element("iframe_editorHint"));

		element("txt_questionTextArea").clear();
		element("txt_questionTextArea").sendKeys(hint);

		switchToDefaultContent();
	}

	/**
	 * Method which adds Correct Feedback to the Question
	 * 
	 */
	private void _addCorrectFeedbackToQuestion(String correctFeedback) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_addCorrectFeedback").click();
		logMessage("Instructor clicked on 'Add Correct Feedback' button");

		wait.waitForElementToBeVisible(element("txt_correctFeedbackHeader"));

		switchToFrame(element("iframe_editorCorrectFeedback"));

		element("txt_questionTextArea").clear();
		element("txt_questionTextArea").sendKeys(correctFeedback);

		switchToDefaultContent();
	}

	/**
	 * Method which adds In-Correct Feedback to the Question
	 * 
	 */
	private void _addInCorrectFeedbackToQuestion(String inCorrectFeedback) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_addIncorrectFeedback").click();
		logMessage("Instructor clicked on 'Add InCorrect Feedback' button");

		wait.waitForElementToBeVisible(element("txt_inCorrectFeedbackHeader"));

		switchToFrame(element("iframe_editorInCorrectFeedback"));

		element("txt_questionTextArea").clear();
		element("txt_questionTextArea").sendKeys(inCorrectFeedback);

		switchToDefaultContent();
	}

	public void clickOnAddInCorrectFeedBackButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		if (elements("btn_addIncorrectFeedback").size() != 0) {
			element("btn_addIncorrectFeedback").click();
			logMessage("Instructor clicked on 'Add InCorrect Feedback' button");
			wait.waitForElementToBeVisible(element("txt_inCorrectFeedbackHeader"));
		} else {
			logMessage("'Add InCorrect Feedback' field already open");
		}
		switchToDefaultContent();
	}

	public void clickAndClearIncorrectFeedBackArea() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_editorInCorrectFeedback"));

		element("txt_questionTextArea").click();
		element("txt_questionTextArea").clear();

		switchToDefaultContent();
	}

	/**
	 * Method which creates an Advanced Question in Formula Editor & also adds
	 * other comments to it such as Hint, Correct Feedback & In-Correct Feedback
	 * 
	 */
	public void createAdvancedQuestionInFormulaEditor() {
		String objectName1 = "[object MainTimeline]";

		initializingGenie(objectName1);
		clearQuestionEditor();
		//focusOnFormulaEditor();

		try {
			(new GenieButton(
					"SP^Stage:::FP^root:::SE^btn_calc::PX^0::PTR^0::IX^8::ITR^0",
					app1)).click();
			logMessage("Instructor clicked on Calc option list");

			(new GenieDisplayObject(
					"SP^Stage:::FP^Stage:::SE^MC_calc_m::PX^-1::PTR^0::IX^6::ITR^0",
					app1)).click(18, 10, 74, 44, 500, 271, 2, false);
			logMessage("Instructor clicked on 'Integral' option");

			(new GenieButton(
					"SP^Stage:::FP^root:::SE^btn_trig::PX^0::PTR^0::IX^9::ITR^0",
					app1)).click();
			logMessage("Instructor clicked on Trignometric option list");

			(new GenieDisplayObject(
					"SP^Stage:::FP^Stage:::SE^MC_trig::PX^-1::PTR^0::IX^2::ITR^0",
					app1)).click(31, 46, 149, 80, 500, 271, 3, false);
			logMessage("Instructor clicked on 'sin' trignometric function");

			(new UIKeyBoard()).typeText("x");
			logMessage("Instructor entered 'x' text in formula editor");

			(new GenieDisplayObject(
					"FP^Stage:::SE^EqEditor:::CH^EqDocument::PX^1::PTR^0::IX^0::ITR^0",
					app1)).performKeyAction("RIGHT", 192);
			logMessage("Instructor performed click operation to change the position of cursor in formula editor");

			(new UIKeyBoard()).typeText("dx = ");
			logMessage("Instructor entered 'dx = ' text in formula editor");

		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}

		
		clickOnSubmitButtonPresentOnFormulaEditorWindow();

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");
		element("txt_questionTextArea").sendKeys(Keys.ENTER);

		// Note: Adding Text response as to answer the question
		addResponseAreaToQuestion("Text");
		textResponseEditor();

		_addHintToQuestion("This is the Hint panel");
		_addCorrectFeedbackToQuestion("Horray !!! Your answer is Correct");
		_addInCorrectFeedbackToQuestion("Oops !!! Your answer is In-Correct");

		waitForMsgToastToDisappear();

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_editorSave").click();
		logMessage("Instructor clicked on 'Save' button");

		switchToDefaultContent();
		waitForMsgToastToDisappear();
	}
	
	public void insertFormulaInQuestionEditor(String objectname)
	{
		initializingGenie(objectname);
		//Turn this on if you want script to exit 
				//when a step fails
//				EXIT_ON_FAILURE = false;

				//Turn this on if you want a screenshot 
				//to be captured on a step failure
//				CAPTURE_SCREENSHOT_ON_FAILURE = false;
			
//				SWFApp app1=connectToApp("[object MainTimeline]");
		try{
				(new GenieButton("SP^Stage:::FP^root:::SE^btn_trig::PX^0::PTR^0::IX^9::ITR^0",app1)).click();
				(new GenieDisplayObject("SP^Stage:::FP^Stage:::SE^MC_trig::PX^-1::PTR^0::IX^2::ITR^0",app1)).click(33,16,151,50,500,271,2,false);
				(new GenieDisplayObject("FP^Stage:::SE^EqEditor:::CH^EqDocument::PX^1::PTR^0::IX^0::ITR^0",app1)).performKeyAction("X",61);
				(new GenieDisplayObject("FP^Stage:::SE^EqEditor:::CH^EqDocument::PX^1::PTR^0::IX^0::ITR^0",app1)).performKeyAction("RIGHT",31);
				(new GenieButton("SP^Stage:::FP^root:::SE^btn_ops::PX^0::PTR^0::IX^10::ITR^0",app1)).click();
				(new GenieDisplayObject("SP^Stage:::FP^Stage:::SE^MC_ops::PX^-1::PTR^0::IX^3::ITR^0",app1)).click(68,7,248,41,500,271,2,false);
				(new GenieButton("SP^Stage:::FP^root:::SE^btn_calc::PX^0::PTR^0::IX^8::ITR^0",app1)).click();
				(new GenieDisplayObject("SP^Stage:::FP^Stage:::SE^MC_calc_m::PX^-1::PTR^0::IX^6::ITR^0",app1)).click(91,13,147,47,500,271,2,false);
				(new GenieDisplayObject("FP^Stage:::SE^EqEditor:::CH^EqDocument::PX^1::PTR^0::IX^0::ITR^0",app1)).performKeyAction("Y",56);
				(new GenieButton("SP^Stage:::FP^root:::SE^btn_submit::PX^0::PTR^0::IX^14::ITR^0",app1)).click();
			
} catch (StepFailedException e) {
	e.printStackTrace();
} catch (StepTimedOutException e) {
	e.printStackTrace();
}
}

	/**
	 * Method which clicks on 'Expand Editor' link
	 * 
	 */
	public void clickOnExpandEditor() {
		element("lnk_expandEditor").click();
		logMessage("Clicked on 'Expand Editor' link");
	}

	/**
	 * Method which verifies the presence of Question Editor Icon on the title
	 * of the page
	 * 
	 * @param flag
	 *            - Visibility status of Question Editor icon
	 * 
	 */
	public void verifyQuestionEditorIcon(boolean flag) {
		waitForElementToBeVisible("label_questionEditor");
		String valueCSS = element("label_questionEditor").getCssValue(
				"background-image");

		if (flag == true && !(valueCSS.contains("brainhoney"))) {
			Assert.fail("Assertion Failed: Question Editor Icon is STILL NOT visible!!!");
		} else if (flag == false && !(valueCSS.contains("brainhoney"))) {
			logMessage("Assertion Passed: Question Editor Icon is NOT visible!!!");
		}

		else if (flag == true && valueCSS.contains("brainhoney")) {
			Assert.fail("Assertion Passed: Question Editor Icon is visible!!!");
		} else if (flag == false && valueCSS.contains("brainhoney")) {
			Assert.fail("Assertion Failed: Question Editor Icon is STILL visible!!!");
		}
	}

	/**
	 * Method which get the location i.e., X coordinates of HTS Editor Panel
	 * link
	 * 
	 * @return locationXOfEditorPanel
	 * 
	 */
	public int getLocationXCoordinateOfHtsEditorPanel() {
		int locationXOfEditorPanel = element("link_htsEditorPanel")
				.getLocation().getX();
		return locationXOfEditorPanel;
	}

	/**
	 * Method which get the location i.e., Y coordinates of HTS Editor Panel
	 * link
	 * 
	 * @return locationYOfEditorPanel
	 * 
	 */
	public int getLocationYCoordinateOfHtsEditorPanel() {
		int locationYOfEditorPanel = element("link_htsEditorPanel")
				.getLocation().getY();
		return locationYOfEditorPanel;
	}

	/**
	 * Method which compares the X & Y coordinates of HTS Editor Panel Links
	 * after clicking on 'Expand Editor' link
	 * 
	 */
	public void clickOnExpandEditorAndValidatesHtsEditorPanel() {
		int locationX = getLocationXCoordinateOfHtsEditorPanel();
		int locationY = getLocationYCoordinateOfHtsEditorPanel();

		clickOnExpandEditor();

		int locationXNew = getLocationXCoordinateOfHtsEditorPanel();
		int locationYNew = getLocationYCoordinateOfHtsEditorPanel();

		System.out.println("Location(X-Coordinates) of HTS Editor Link Panel "
				+ "after clicking on Expand Editor: " + locationXNew);
		System.out
		.println("Location(Y-Coordinates) of HTS Editor Link Panel after "
				+ "clicking on Expand Editor: " + locationYNew);

		if ((locationX > locationXNew) && (locationY > locationYNew)) {
			logMessage("Assertion Passed: HTS Editor Panel is MOVED to the same line as of 'Question Editor' Title!!!");
		} else {
			Assert.fail("Assertion Failed: HTS Editor Panel is NOT moved to the same line as of 'Question Editor' Title!!!");
		}
		logMessage("Question Editor is Expanded successfully!!!");
	}

	/**
	 * Method which compares the X & Y coordinates of HTS Editor Editor Panel
	 * Links after clicking on 'Collapse Editor' link
	 * 
	 */
	public void clickOnCollapseEditorAndValidatesHtsEditorPanel() {
		int locationX = getLocationXCoordinateOfHtsEditorPanel();
		int locationY = getLocationYCoordinateOfHtsEditorPanel();

		clickOnCollapseEditor();

		int locationXNew = getLocationXCoordinateOfHtsEditorPanel();
		int locationYNew = getLocationYCoordinateOfHtsEditorPanel();

		logMessage("Location(X-Coordinates) of HTS Editor Link Panel after "
				+ "clicking on Collapse Editor: " + locationXNew);
		logMessage("Location(Y-Coordinates) of HTS Editor Link Panel after "
				+ "clicking on Collapse Editor: " + locationYNew);

		if ((locationX < locationXNew) && (locationY < locationYNew)) {
			logMessage("HTS Editor Panel is MOVED BACK to the same line as it was Earlier!!!");
		} else {
			Assert.fail("Assertion Failed: HTS Editor Link Panel is NOT moved to the same line as it was Earlier!!!");
		}
		logMessage("Question Editor is Collapsed successfully!!!");
	}

	/**
	 * Method which clicks on 'Collapse Editor' link
	 * 
	 */
	public void clickOnCollapseEditor() {
		element("lnk_collapseEditor").click();
		logMessage("Clicked on 'Collapse Editor' link");
	}

	/**
	 * Method which verifies "Expand Editor" link is clicked by verifying the
	 * text of "Collapse Editor" link
	 * 
	 */
	public void verifyExpandEditorIsClicked() {
		waitForElementToBeVisible("lnk_collapseEditor");

		if (element("lnk_collapseEditor").getText().equalsIgnoreCase(
				"Collapse Editor")) {
			logMessage("Assertion Passed: Collapse Editor' link is displayed after "
					+ "clicking on 'Expand Editor' link!!!");
		} else {
			Assert.fail("'Assertion Failed: Collapse Editor' link is NOT displayed even "
					+ "after clicking on 'Expand Editor' link!!!");
		}
	}

	/**
	 * Method which verifies "Collapse Editor" link is clicked by verifying the
	 * text of "Expand Editor" link
	 * 
	 */
	public void verifyCollapseEditorIsClicked() {
		waitForElementToBeVisible("lnk_expandEditor");

		if (element("lnk_expandEditor").getText().equalsIgnoreCase(
				"Expand Editor")) {
			logMessage("Assertion Passed: 'Collapse Editor' link is clicked & now 'Expand Editor' link is Displayed!!!");
		} else {
			Assert.fail("Assertion Failed: 'Expand Editor' link is NOT Displayed after clicking on "
					+ "'Collapse Editor' link!!!");
		}
	}

	/**
	 * Method which verifies that "Properties" link is moved to the same line as
	 * "Advanced | 1 point | Preview | Properties after clicking either on "
	 * Expand/Collapse Editor" link
	 * 
	 */
	public void verifyPropertiesLinkOnSameLineAsHtsEditorLinkPanel() {
		System.out
		.println("Text of HTS Editor link Panel after clicking on 'Expand Editor' link: "
				+ element("link_htsEditorPanel").getText());

		if (element("link_htsEditorPanel").getText().contains("| Properties")) {
			logMessage("Assertion Passed: Properties Link is on the same line as "
					+ "'Advanced | 1 point | Preview | Properties' !!!");
		} else {
			Assert.fail("Assertion Failed: Properties Link is NOT on the same line as "
					+ "'Advanced | 1 point | Preview | Properties' !!!");
		}
	}

	/**
	 * Method to verify 'Saved/Revert to Saved/Add Step/Add Solution/Show
	 * Variable' Tool bar is aligned with the bottom of the vertical rule
	 * 
	 */
	public void verifySaveToolbarIsAlignedToTheBottomOfTheVerticalRule() {
		int X_CoordinateMainFrame = element("iframe_mainFrame").getLocation()
				.getX();
		int Y_CoordinateMainFrame = element("iframe_mainFrame").getLocation()
				.getY();

		logMessage("Location(X-Coordinates) of Main Frame: "
				+ X_CoordinateMainFrame);
		logMessage("Location(Y-Coordinates) of Main Frame: "
				+ Y_CoordinateMainFrame);

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		int X_CoordinateSaveButton = element("btn_editorSave").getLocation()
				.getX();
		int Y_CoordinateSaveButton = element("btn_editorSave").getLocation()
				.getY();

		logMessage("Location(X-Coordinates) of Save Button: "
				+ X_CoordinateSaveButton);
		logMessage("Location(Y-Coordinates) of Save Button: "
				+ Y_CoordinateSaveButton);

		X_CoordinateSaveButton = X_CoordinateSaveButton + X_CoordinateMainFrame;
		Y_CoordinateSaveButton = Y_CoordinateSaveButton + Y_CoordinateMainFrame;

		logMessage("New X-Coordinate of Save button w.r.t to Top Window: "
				+ X_CoordinateSaveButton);
		logMessage("New Y-Coordinate of Save button w.r.t to Top Window: "
				+ Y_CoordinateSaveButton);

		switchToDefaultContent();
		if (X_CoordinateSaveButton != 0) {
			logMessage("Assertion Passed: 'Saved/Revert to Saved/Add Step/Add Solution/Show Variable' Toolbar "
					+ "is aligned with the bottom of the vertical rule");
		} else {
			Assert.fail("Assertion Failed: 'Saved/Revert to Saved/Add Step/Add Solution/Show Variable' Tool bar "
					+ "is NOT aligned with the bottom of the vertical rule!!!");
		}
	}

	/**
	 * Method to validate Editor link Container is present while Creating New
	 * Question i.e., 'Expand Editor' link, 'User-created question' text ,
	 * 'Advanced | 1 point | Preview' links, & 'Question Editor' icon
	 * 
	 */
	public void validateHtsEditorLinksContainer() {
		customAssert.customAssertEquals(element("lnk_expandEditor").getText(),
				"Expand Editor",
				"Assertion Failed: Expand Editor link title is NOT correct");
		logMessage("Assertion Passed: 'Expand Editor' link is present while creating a New Question");

		customAssert
		.customAssertEquals(element("label_userCreatedQuestion")
				.getText(), "User-created question",
				"Assertion Failed: User-created question link title is NOT correct");
		logMessage("Assertion Passed: 'User-created question' label is present!!!");

		customAssert.customAssertEquals(element("link_htsEditorPanel")
				.getText(), "Advanced | 1 point | Preview",
				"Assertion Failed: HTS Editor Panel title is NOT correct");
		logMessage("Assertion Passed: 'Advanced | 1 point | Preview' links are present!!!");
	}

	/**
	 * Method which clicks on 'Editor' button present in Question Editor
	 * 
	 */
	public void clickOnEditorButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_editor").click();
		logMessage("Instructor clicked on Editor Mode button");

		// NOTE: Added Hard Wait as to wait for the question to load completely
		// in AQE
		hardWait(2);
		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Raw XML' button present in Question Editor
	 * 
	 */
	public void clickOnRawXMLButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_rawXML").click();
		logMessage("Instructor clicked on 'Raw XML' Mode button");

		switchToDefaultContent();
	}

	/**
	 * Method which counts the number of commas in the XML file i.e., to check
	 * comma is not changed into an expression after switching the question in
	 * different modes i.e., Raw XML & Editor
	 * 
	 */
	public int countNumberOfCommasInXML(String xmlName, char match) {
		int counter = 0;
		BufferedReader br = null;
		try {
			int r;
			char comma;
			br = new BufferedReader(new FileReader(
					"./src/test/resources/AA-Artifacts/questions-xmls/"
							+ xmlName));

			while ((r = br.read()) != -1) {
				comma = (char) (r);
				if (comma == match) {
					counter++;
				}
			}
			logMessage("Total No. of Commas in XML file: " + counter);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		return counter;
	}

	/**
	 * Method reads the contents of text area & validates that the numeric
	 * variables values on comma are not split & converted into expression i.e.,
	 * Question in XML format should not be changed in 'Raw XML' mode
	 * 
	 */
	public void validateQuestionContentsInRawXmlMode(int counter) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		String questionContents = element("textarea_rawXMLEditor")
				.getAttribute("value");
		char[] charArray = questionContents.toCharArray();
		int num = 0;

		for (int i = 0; i < questionContents.length(); i++) {
			charArray[i] = questionContents.charAt(i);
			char ch = charArray[i];
			if (ch == ',') {
				num++;
			}
		}
		switchToDefaultContent();

		logMessage("No. of Commas in Question content in Raw XML mode: " + num);

		if (counter == num) {
			logMessage("Question XML is UN-CHANGED in Raw XML mode!!!");
		} else {
			Assert.fail("Question XML have been CHANGED in Raw XML mode i.e., AQE splits Numeric variable "
					+ "value on Comma!!!");
		}
	}

	/**
	 * Method which clicks on 'Show Variable' button present in Question Editor
	 * 
	 */
	public void clickOnShowVariables() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		if (elements("btn_showVariables").size() != 0) {
			element("btn_showVariables").click();
			logMessage("Instructor clicked on 'Show Variable' button");
		} else {
			logMessage("'Show Variable' button already displayed");
		}

		switchToDefaultContent();
	}

	/**
	 * Method which drags Resizeable bar present in Variable Panel till a Toggle
	 * button in Question Editor
	 * 
	 */
	public void dragResizeableBarInVariablePanel() {
		switchToDefaultContent();

		String frameId = element("iframe_mainFrame").getAttribute("id");
		executeJavascript("document.getElementById('"
				+ frameId
				+ "').contentDocument.getElementsByClassName('"
				+ "ui-resizable-handle ui-resizable-e')[0].style='display: block;'");

		switchToFrame(element("iframe_mainFrame"));

		Actions action = new Actions(driver);
		action.clickAndHold(element("handle_resizeableBar"));
		action.moveToElement(element("btn_hintToggle")).build().perform();
		action.moveToElement(element("btn_hintToggle")).build().perform();
		action.release().build().perform();

		switchToDefaultContent();
	}

	/**
	 * Method which validates that full definition of the variable is displayed
	 * in Variable Panel by dragging the left edge of Variable Panel which can't
	 * expanded more than half the size of the Question Editor
	 * 
	 */
	public void validateCompleteDefinitionOfVariableIsDispalyedInVariablePanel() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		int heightRightContentWrapper = element("table_contentWrapperRight")
				.getSize().getHeight();
		int widthRightContentWrapper = element("table_contentWrapperRight")
				.getSize().getWidth();

		logMessage("Width of Rigth Content Wrapper before dragging: "
				+ widthRightContentWrapper);
		logMessage("Height of Rigth Content Wrapper before dragging: "
				+ heightRightContentWrapper);

		clickOnShowVariables();
		dragResizeableBarInVariablePanel();
		verifyResizableBarDraggedToHalfSizeOfQuestionEditor();
	}

	/**
	 * Method which verifies that Resizable bar is dragged to half the size of
	 * Question Editor
	 * 
	 */
	public void verifyResizableBarDraggedToHalfSizeOfQuestionEditor() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		int heightRightContentWrapperAfterDrag = element(
				"table_contentWrapperRight").getSize().getHeight();
		int widthRightContentWrapperAfterDrag = element(
				"table_contentWrapperRight").getSize().getWidth();

		System.out.println("Width of Rigth Content Wrapper after dragging: "
				+ widthRightContentWrapperAfterDrag);
		System.out.println("Height of Rigth Content Wrapper after dragging: "
				+ heightRightContentWrapperAfterDrag);

		System.out.println("Style Attribute of Right Content Wrapper: "
				+ element("table_contentWrapperRight").getAttribute("style"));
		System.out.println("Style Attribute of Left Content Wrapper: "
				+ element("table_contentWrapperLeft").getAttribute("style"));

		if (element("table_contentWrapperLeft").getAttribute("style").contains(
				"width: 50")) {
			logMessage("Variable Panel is exactly half the size of Question Editor!!!");
		} else {
			Assert.fail("Variable Panel is NOT exactly half the size of Question Editor!!!");
		}
		switchToDefaultContent();
	}

	/**
	 * Method which loads for Question Editor to be loaded completely
	 * 
	 */
	public void waitForQuestionEditorToBeLoadedCompletely() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		logMessage("Waiting for the question to Load in Advanced Question Editor...");
		waitForElementToBeVisible("btn_Bold");

		switchToDefaultContent();
	}

	/**
	 * Method which selects an option from Insert Response Area from Question
	 * Editor
	 * 
	 * @param numericResponse
	 *            - Text to be selected for Numeric Response
	 * 
	 */
	public void selectOptionFromResponseArea(String numericResponse) {
		clickOnResponseDropDown();
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		for (WebElement elem : elements("drpdown_optionsResponseArea")) {
			if (elem.getText().equalsIgnoreCase(numericResponse)) {
				elem.click();
				logMessage("Instructor selected '" + numericResponse
						+ "' from Insert Response Area Drop down");
				break;
			}
		}
		switchToDefaultContent();
	}

	public void clickOnResponseDropDown() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("drpdown_insertResponseArea").click();
		logMessage("Instructor clicked on 'Insert Response Area' Drop down");

		switchToDefaultContent();
	}

	public void verifyResponseDropDownIsDisabled() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert.customAssertTrue(element("row_tollbarProperty")
				.getAttribute("style").contains("block"),
				"Assertion Failed : Response dropdown is not disabled");
		logMessage("Assertion Passed : Response dropdown is disabled");

		switchToDefaultContent();
	}

	public void verifyEditorIsDisabled() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert
		.customAssertTrue(
				element("questionEditor").getAttribute("style")
				.contains("block"),
				"Assertion Failed: Question Editor dropdown is NOT disabled!!!");
		logMessage("Assertion Passed: Question Editor is disabled!!!");

		switchToDefaultContent();
	}

	/**
	 * Method which enters an Answer Type value & other required details in
	 * Numeric Response Editor(NRE)
	 * 
	 * @param answerType
	 *            - Text to be selected for Answer Type
	 * @param answerInput
	 *            - Text to be entered in Answer Text box
	 * 
	 */
	public void enterAnswerTypeInNumericResponseEditor(String answerType,
			String answerInput, String Re_edit) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		if (Re_edit.equals("yes"))
			element("act_editRow").click();
		selectProvidedTextFromDropDown(element("drpdown_answerType"),
				answerType);
		logMessage("Instructor selected '" + answerType
				+ "' Answer Type from Drop-down");

		element("txtbox_numericResponseEditorAnswerInput").clear();
		element("txtbox_numericResponseEditorAnswerInput")
		.sendKeys(answerInput);
		logMessage("Instructor entered '" + answerInput
				+ "' value in Answer TextBox");
		hardWait(2);
		element("act_saveRow").click();
		logMessage("Instructor clicked on 'Save' Action button present in the Row");

//		scroll(element("btn_htsDialogSave"));
//		element("btn_htsDialogSave").click();
//		logMessage("added numeric response to question");
//		switchToDefaultContent();
//		waitForLoaderToDisappear();
	}
	
	/**
	 * Method which enters an Answer Type value & other required details in
	 * Numeric Response Editor(NRE)
	 * 
	 * @param answerType
	 *            - Text to be selected for Answer Type
	 * @param answerInput
	 *            - Text to be entered in Answer Text box
	 * 
	 */
	public void enterAnswerTypeInNumericResponseEditor(String answerType,
			String answerInput, String Re_edit, String weightValue) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		if (Re_edit.equals("yes"))
			element("act_editRow").click();
		selectProvidedTextFromDropDown(element("drpdown_answerType"),
				answerType);
		logMessage("Instructor selected '" + answerType
				+ "' Answer Type from Drop-down");

		element("txtbox_numericResponseEditorAnswerInput").clear();
		element("txtbox_numericResponseEditorAnswerInput")
		.sendKeys(answerInput);
		logMessage("Instructor entered '" + answerInput
				+ "' value in Answer TextBox");
		hardWait(2);
		element("act_saveRow").click();
		logMessage("Instructor clicked on 'Save' Action button present in the Row");

		waitForElementToBeVisible("btn_addCorrectAnswer");

		element("txtbox_responseWeighting").clear();
		logMessage("Instructor cleared the default value of Weighting");

		element("txtbox_responseWeighting").sendKeys(weightValue);
		logMessage("Instructor entered '" + weightValue
				+ "' value in Weight field Text box");
		
		scroll(element("btn_htsDialogSave"));
		element("btn_htsDialogSave").click();
		logMessage("added numeric response to question");
		switchToDefaultContent();
		waitForLoaderToDisappear();
	}
	
	/**
	 * Method which double clicks on numeric response in text editor for editing
	 * 
	 **/
	public void clickOnNumericResponseInQuestionForEditing() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_editorQuestionFrame"));

		WebElement numres = driver
				.findElement(By
						.xpath(".//*[@id='tinymce']//p//img[@hts-data-type='numeric']"));
		Actions act = new Actions(driver);
		act.doubleClick(numres).doubleClick().build().perform();
		hardWait(3);
		switchToDefaultContent();
	}

	/**
	 * Method which drags and drop Step 1
	 * 
	 */
	public void dragAndDropStep1() {
		switchToFrame(element("iframe_mainFrame"));
		Actions builder = new Actions(driver);

		builder.clickAndHold(element("lbl_step1"))
		.moveToElement(element("btn_addHint"), 299, 5).release()
		.build().perform();
		builder.click(element("lbl_step1")).build().perform();
		hardWait(5);
		switchToDefaultContent();
	}

	/**
	 * method to verify numeric response in question
	 */
	@SuppressWarnings("static-access")
	public void instructorVerifiesNumericResponse() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_editorQuestionFrame"));
		List<WebElement> numres = driver
				.findElements(By
						.xpath(".//*[@id='tinymce']/p/img[@hts-data-type='numeric' and contains(@response-data,'15')]"));
		customAssert.assertEquals(numres.size(), 1,
				"Numeric Response Changed after moving Step1");
		logMessage("Numeric Response unchanged after moving Step1");
		switchToDefaultContent();
	}

	public void instructorRefreshesThePage() {
		refreshPage();
	}

	/**
	 * Method which enters an Answer Type value & other required details in
	 * Numeric Response Editor(NRE)
	 * 
	 * @param answerType
	 *            - Text to be selected for Answer Type
	 * @param answerInput
	 *            - Text to be entered in Answer Text box
	 * 
	 */
	public void enterAnswerTypeWithWeightValueInNumericResponseEditor(
			String answerType, String answerInput) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		selectProvidedTextFromDropDown(element("drpdown_answerType"),
				answerType);
		logMessage("Instructor selected '" + answerType
				+ "' Answer Type from Drop-down");

		element("txtbox_numericResponseEditorAnswerInput").clear();
		element("txtbox_numericResponseEditorAnswerInput")
		.sendKeys(answerInput);
		logMessage("Instructor entered '" + answerInput
				+ "' value in Answer TextBox");

		element("act_saveRow").click();
		logMessage("Instructor clicked on 'Save' Action button present in the Row");

		switchToDefaultContent();
		waitForLoaderToDisappear();
	}

	/**
	 * Method which clicks on 'Save' button present in Question Editor
	 * 
	 */
	public void clickOnSaveButtonOfQuestionEditor() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_editorSave").click();
		logMessage("Instructor clicked on 'Save' button of Question Editor");

		switchToDefaultContent();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Method which validates the default value of Answer Type Drop down i.e.,
	 * 'Single Value/Expr.'
	 * 
	 * @param defaultValue
	 *            - Default Value present in 'Answer Type' Drop down
	 * 
	 */
	public void validateDefaultValueInAnswerTypeDropDown(String defaultValue) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		waitForElementToBeVisible("txt_defaultValueAnwserTypeDropdown");
		customAssert
		.customAssertEquals(
				element("txt_defaultValueAnwserTypeDropdown").getText(),
				defaultValue,
				"Assertion Failed: 'Single Value/Expr.' is NOT the default value in 'Answer Type' Drop down!!!");

		logMessage("Assertion Passed: 'Single Value/Expr.' is the default value in 'Answer Type' Drop down!!!");
		switchToDefaultContent();
	}

	/**
	 * Method which validates whether an error message is displayed on Hover
	 * after entering Invalid values in 'Answer Input' text box
	 * 
	 * @param errorMessageOnAnswerInputTextbox
	 *            - Error message displayed when an invalid value is entered to it
	 * @param validate - Boolean value which verifies the Error Message
	 * 
	 */
	public void verifyErrorMessageOnAnswerInput(
			String errorMessageOnAnswerInputTextbox, boolean validate) {

//		switchToDefaultContent();
//		String frameIdEasyXDM = element("iframe_mainFrame").getAttribute("id");

//		switchToFrame(element("iframe_mainFrame"));
//		String frameIdMce = element("iframe_mceinlinePopups")
//				.getAttribute("id");
//
//		switchToDefaultContent();
//		executeJavascript("document.getElementById('"
//				+ frameIdEasyXDM
//				+ "').contentDocument.getElementById('"
//				+ frameIdMce
//				+ "').contentDocument.getElementsByClassName('errHint')[0].style='display: inline'");

		executeJavascript("document.getElementsByClassName('errHint')[0].style='display: inline'");
		
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		
		if (validate) {
			customAssert.customAssertEquals(element("txt_errorHint").getText(),
					errorMessageOnAnswerInputTextbox,
					"Assertion Failed: Error message is NOT matching!!!");

			logMessage("Assertion Passed: '" + errorMessageOnAnswerInputTextbox
					+ "' error message is displayed \n");
		} else {
			customAssert.customAssertEquals(element("txt_errorHint").getText(),
					errorMessageOnAnswerInputTextbox,
					"Assertion Failed: Error message is NOT matching!!!");

			logMessage("Assertion Passed: No Error is Displayed!!!");
			element("act_editRow").click();
			logMessage("Instructor clicked on 'Edit' Action button present in the Row"
					+ "\n");
		}

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Cancel' button present on Dialog box
	 * 
	 */
	public void clickOnCancelButtonPresentOnDialogBox() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_htsDialogCancel").click();
		logMessage("Instructor clicked on 'Cancel' button");

		switchToDefaultContent();
	}

	/**
	 * Method which opens the answer response present in QB question
	 * 
	 */
	public void openAnswerResponsePresentInQuestion() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_htsQuestionText").click();
		logMessage("Instructor clicked on 'tinyMCE' content body");

		scrollDown(element("img_numericResponse"));
		logMessage("Scrolled up to the Element in View");

		doubleClick(element("img_numericResponse"));
		logMessage("Instructor double clicked on a Numeric Response present in the question");

		switchToDefaultContent();
	}

	/**
	 * Method in which Weight value is added to question if not present in NRE
	 * 
	 * @param weightValue
	 *            - Value for weight field in NRE
	 * 
	 */
	public void addingWeightValueToQuestionInNumericResponseEditor(
			String weightValue) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		waitForElementToBeVisible("btn_addCorrectAnswer");

		element("txtbox_responseWeighting").clear();
		logMessage("Instructor cleared the default value of Weighting");

		element("txtbox_responseWeighting").sendKeys(weightValue);
		logMessage("Instructor entered '" + weightValue
				+ "' value in Weight field Text box");

		element("btn_htsDialogSave").click();
		logMessage("Instructor clicked on 'Save' button present in Numeric Response Editor(NRE)");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies Numeric Answer Value after adding Weight attribute
	 * in editor i.e., Caption value should NOT be changed to '0' in answer
	 * response of Question
	 * 
	 */
	public void verifyNumericAnswerValueAfterAddingWeightField() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		String valueResponse = element("img_numericResponse").getAttribute(
				"src");
		logMessage("Assertion Passed: Value of src after adding Weight "
				+ "Field in Numeric Response: " + valueResponse);

		if (valueResponse.contains("caption=0")) {
			Assert.fail("Assertion Failed: Numeric Response Value has changed to '0' number!!!");
		}

		String regex = ".+?[\\W](\\d+)[&?]";
		Pattern p = Pattern.compile(regex);
		Matcher m = p.matcher(valueResponse);

		while (m.find()) {
			logMessage("Start index: '" + m.start()
					+ "' character from the string");
			logMessage("End index: '" + m.end()
					+ "' character from the string");
			logMessage("Value of Numeric Response Area: " + m.group(1));
		}

		switchToDefaultContent();
	}

	/**
	 * Method in which verifies whether the Preview Modal Window is displayed
	 * 
	 * @param previewModalTitle
	 */
	public void verifyPreviewModalWindowIsDisplayed(String previewModalTitle) {
		waitForLoaderToDisappear();

		isElementDisplayed("txt_previewModalWindowTitle");
		customAssert.customAssertEquals(element("txt_previewModalWindowTitle")
				.getText(), previewModalTitle,
				"Assertion Failed: Preview Modal Window title is not correct.");

		isElementDisplayed("btn_regenerateVariables");
		isElementDisplayed("img_close");

		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		waitForElementToBeVisible("btn_submit");

		switchToDefaultContent();

		logMessage("Assertion Passed: User is on Preview Modal Window, Verified Page title "
				+ "visibility and Title text to be: " + previewModalTitle);
	}

	/**
	 * Method in which Instructor attempts the QB question for AA-302 ticket
	 * 
	 */
	public void instructorAttemptsQuizInPlayerForAA_302() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");
		System.out.println("Hts Question Text: "
				+ element("txt_htsQuestion").getText());

		element("txtbox_numericResponseAnswer1").sendKeys("62.0");
		logMessage("User entered '62.0' for the 1st Numeric Text-box");

		element("txtbox_numericResponseAnswer2").sendKeys("70.2");
		logMessage("User entered '70.2' for the 2nd Numeric Text-box");

		element("btn_submit").click();
		logMessage("User clicked on 'Submit' button in player");

		element("btn_yesConfirmationBox").click();
		logMessage("User clicked 'Yes' present on the confirmation box");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies whether appropriate marks are given as per the
	 * given answer in AQP (Advanced Question Player)
	 * 
	 */
	public void verifyAppropriateMarksAreGivenForAnswer() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		hover(element("img_anchor1"));
		logMessage("Instructor hovered on the 1st Anchor image present near the Text box");

		switchToDefaultContent();
		String frameIdEasyXDM1 = element("iframe_previewFrame").getAttribute(
				"id");
		switchToFrame(element("iframe_previewFrame"));
		String frameIdContentFrame1 = element("iframe_contentFrame")
				.getAttribute("id");

		switchToDefaultContent();
		executeJavascript("document.getElementById('"
				+ frameIdEasyXDM1
				+ "').contentDocument.getElementById('"
				+ frameIdContentFrame1
				+ "').contentDocument.getElementsByTagName('iframe')[0].contentDocument."
				+ "getElementById('popupdiv0').style='position: absolute; z-index: 100; "
				+ "background-color: rgb(255, 255, 255); left: 749px; top: 21px;'");

		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");
		System.out.println("Text of 1st Answer Hint: "
				+ element("txt_hoverPopUp").getText());

		if (element("txt_hoverPopUp").getText().contains("62")) {
			logMessage("User answered the 1st question Correctly!!!");
		} else {
			logMessage("User answered the 1st question In-Correctly!!!");
		}

		// Verifying the 2nd answer after evaluation

		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");
		hover(element("img_anchor2"));
		logMessage("Instructor hovered on the 2nd Anchor image present near the Text box");

		switchToDefaultContent();
		String frameIdEasyXDM2 = element("iframe_previewFrame").getAttribute(
				"id");
		switchToFrame(element("iframe_previewFrame"));
		String frameIdContentFrame2 = element("iframe_contentFrame")
				.getAttribute("id");

		switchToDefaultContent();
		executeJavascript("document.getElementById('"
				+ frameIdEasyXDM2
				+ "').contentDocument.getElementById('"
				+ frameIdContentFrame2
				+ "').contentDocument.getElementsByTagName('iframe')[0].contentDocument."
				+ "getElementById('popupdiv0').style='position: absolute; z-index: 100; "
				+ "background-color: rgb(255, 255, 255); left: 956px; top: 21px;'");

		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");
		System.out.println("Text of 2nd Answer Hint: "
				+ element("txt_hoverPopUp").getText());

		if (element("txt_hoverPopUp").getText().contains("72")) {
			logMessage("User answered the 2nd question Correctly!!!");
		} else {
			logMessage("User answered the 2nd question In-Correctly!!!");
		}

		switchToDefaultContent();

		element("img_close").click();
		logMessage("Instructor closed the Advanced Question Preview (AQP) window");
	}

	/**
	 * Method which clicks on 'Show Decimal Places' functionality if NOT
	 * selected
	 * 
	 * @param answerInput
	 *            - Answer entered in the text box
	 * @param decimalPlacesvalue
	 *            - Value of Decimal Places
	 * @param toleranceValue
	 *            - Value of Tolerance
	 * 
	 */
	public void selectShowDecimalPlacesFunctionalityToNRE(String answerInput,
			String decimalPlacesValue, String toleranceValue) {

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		waitForElementToBeVisible("btn_addCorrectAnswer");

		String attr = element("txt_showDecimalPlaces").getAttribute("disabled");

		if (attr.equalsIgnoreCase("true")) {
			element("btn_radioShowDecimalPlaces").click();
			logMessage("Instructor clicked on 'Show Decimal Places' radio button");
		} else {
			logMessage("'Show Decimal Places' radio button is already Selected!!!");
		}

		element("txt_showDecimalPlaces").clear();
		logMessage("Instructor clears the input box of 'Show Decimal Places' functionality");

		element("txt_showDecimalPlaces").sendKeys(decimalPlacesValue);
		logMessage("Instructor enters '" + decimalPlacesValue
				+ "' value to 'Show Decimal Places' functionality");

		element("txtbox_numericResponseEditorAnswerInput").clear();
		element("txtbox_numericResponseEditorAnswerInput")
		.sendKeys(answerInput);
		logMessage("Instructor entered '" + answerInput
				+ "' value in Answer TextBox");

		element("txtbox_numericResponseEditorTolerance").clear();
		logMessage("Instructor cleared the default Tolerance value of the Numeric response");

		element("txtbox_numericResponseEditorTolerance").sendKeys(
				toleranceValue);
		logMessage("Instructor entered '" + toleranceValue
				+ "' value as the Tolerance of the Numeric response");

		element("act_saveRow").click();
		logMessage("Instructor clicked on 'Save' Action button present in the Row");

		element("btn_htsDialogSave").click();
		logMessage("Instructor clicked on 'Save' button present in Numeric Response Editor(NRE)");

		switchToDefaultContent();
	}

	/**
	 * Method which enters text content to Question Text area of Question Editor
	 * 
	 * @param textContent
	 *            - Text to be entered in Question Text Area
	 * 
	 */
	public void enterTextContentToQuestionTextarea(String textContent) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").sendKeys(textContent);
		logMessage("Instructor enter '" + textContent
				+ "' text in Question textarea of Question Editor");

		switchToDefaultContent();
	}

	/**
	 * Method in which Instructor attempts the QB question for AA-423 ticket
	 * 
	 * @param value
	 *            - Value to be entered in Numeric Text box in Advanced Question
	 *            Player
	 * 
	 */
	public void instructorAttemptsQuizInPlayerForAA_423(String value) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		System.out.println("Hts Question Text: "
				+ element("txt_htsQuestion").getText());

		element("txtbox_numericResponseAnswer1").sendKeys(value);
		logMessage("User entered '" + value + "' in Numeric Text-box");

		element("btn_submit").click();
		logMessage("User clicked on 'Submit' button in player");

		element("btn_yesConfirmationBox").click();
		logMessage("User clicked 'Yes' present on the confirmation box");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies whether appropriate marks are given as per the
	 * given answer in AQP (Advanced Question Player) for AA-423
	 * 
	 * @param answerValue
	 *            - Answer entered in Numeric Input Text box
	 * 
	 */
	public void verifyAppropriateMarksAreGivenAsPerTheAnswerForAA_423(
			String answerValue) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");
		hover(element("img_anchor1"));
		logMessage("Instructor hovered on the Anchor image present near the Text box");

		// NOTE: Added Hard wait to display the Correct answer after attempting
		// the question
		hardWait(2);

		switchToDefaultContent();
		String frameIdEasyXDM1 = element("iframe_previewFrame").getAttribute(
				"id");
		switchToFrame(element("iframe_previewFrame"));
		String frameIdContentFrame1 = element("iframe_contentFrame")
				.getAttribute("id");

		switchToDefaultContent();
		executeJavascript("document.getElementById('"
				+ frameIdEasyXDM1
				+ "').contentDocument.getElementById('"
				+ frameIdContentFrame1
				+ "').contentDocument.getElementsByTagName('iframe')[0].contentDocument."
				+ "getElementById('popupdiv0').style='position: absolute; z-index: 100; "
				+ "background-color: rgb(255, 255, 255); left: 749px; top: 21px;'");

		// Added hard wait to display the Pop-up of Answer Hint
		hardWait(2);
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");
		System.out.println("Answer Hint: "
				+ element("txt_hoverPopUp").getText());

		System.out.println("Score after Evaluation: "
				+ element("txtbox_score").getAttribute("value"));

		if (element("txtbox_score").getAttribute("value").equalsIgnoreCase("1")) {
			logMessage("User answered the question Correctly!!!");
		} else {
			Assert.fail("User answered the question In-Correctly!!!");
		}

		switchToDefaultContent();

		element("img_close").click();
		logMessage("Instructor closed the Advanced Question Preview (AQP) window");
	}

	public void verifyBlankSpacesInCorrectfeedbackSectionOfQuestionEditor() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		List<WebElement> totalFeedback = elements("txt_headersCorrectFeedback");
		int i = totalFeedback.size();

		switchToDefaultContent();
		for (int j = 2; j <= i; j++) {
			switchToFrame(element("iframe_mainFrame"));
			switchToFrame(element("iframes_correctFeedback",
					Integer.toString(j)));
			waitForElementToBeVisible("txt_questionFirstLine");

			int heightofP1 = element("txt_questionFirstLine").getLocation().y;
			System.out.println("Height of p1(y-point) : " + heightofP1);

			int heightOfTable = element("txt_questionTable").getLocation().y;
			System.out.println("Height of table : " + heightOfTable);

			if ((heightOfTable - heightofP1) > 50) {
				customAssert
				.customAssertTrue(false,
						"Assertion Failed: Additional Line breaks between Feedback lines");
			} else {
				logMessage("Assertion Passed: There is NO gap between Correct Feedback lines");
			}

			switchToDefaultContent();
		}
	}

	public void verifyBlankSpacesInIncorrectfeedbackSectionOfQuestionEditor() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		waitForElementToBeVisible("btn_Bold");

		List<WebElement> totalFeedback = elements("txt_headerInCorrectfeedback");
		int i = totalFeedback.size();
		switchToDefaultContent();

		for (int j = 2; j <= i; j++) {
			switchToFrame(element("iframe_mainFrame"));
			switchToFrame(element("iframes_inCorrectFeedback",
					Integer.toString(j)));
			waitForElementToBeVisible("txt_questionFirstLine");

			System.out.println("Incorrect feedback number : " + j);
			int heightofP1 = element("txt_questionFirstLine").getLocation().y;
			// System.out.println("y height of p1 : "+heightofP1);

			int heightOfTable = element("txt_questionTable").getLocation().y;
			// System.out.println(" height of table : "+heightOfTable);

			if ((heightOfTable - heightofP1) > 50) {
				customAssert
				.customAssertTrue(false,
						"Assertion Failed: Additional Line breaks between Feedback lines");
			} else {
				logMessage("Assertion Passed: There is NO gap between In-Correct Feedback section");
			}

			switchToDefaultContent();
		}
	}

	public void verifyBlankSpacesInfeedbackSectionOfQuestionEditor() {
		verifyBlankSpacesInCorrectfeedbackSectionOfQuestionEditor();
		verifyBlankSpacesInIncorrectfeedbackSectionOfQuestionEditor();
	}

	/**
	 * Click on first radio button of first question in Preview Modal
	 * 
	 */
	public void attemptFirstQuestionOfQuizInPreviewModal() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");
		element("radiobtn_first").click();
		element("btn_submit").click();
		logMessage("User clicked on 'Submit' button in player");

		element("btn_yesConfirmationBox").click();
		logMessage("User clicked 'Yes' present on the confirmation box");

		switchToDefaultContent();
	}

	/**
	 * Verify blank space in incorrect feedback section of preview modal
	 * 
	 */
	public void verifyBlankSpacesfeedbackSectionInPreviewModal() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		List<WebElement> totalStep = elements("totalcountofincorrectfeedbackInPreviwModal");
		int j = totalStep.size();
		System.out.println("j =" + j);

		for (int i = 2; i < j; i++) {
			int heightofP1 = element("txt_incorrectFeedbacksInPreviewModal",
					Integer.toString(i)).getLocation().y;
			int heightofTable = element(
					"table_incorrectFeedbacksInPreviewModal",
					Integer.toString(i)).getLocation().y;

			if ((heightofTable - heightofP1) > 50) {
				customAssert
				.customAssertTrue(false,
						"Assertion Failed: Additional Line breaks between Feedback lines");
			} else {
				logMessage("There is no gap between Incorrect feedback section in preview modal");
			}
		}
		switchToDefaultContent();
	}

	public void deleteRow(String postionOfRow, String postionOfColumn) {
		clickOnRowCell(postionOfRow, postionOfColumn);

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		String getClassAttribute = element("btn_DeleteRow").getAttribute(
				"class");
		System.out.println("Button status: " + getClassAttribute);

		if (getClassAttribute.contains("ButtonEnabled")) {
			logMessage("Assertion Passed: 'Delete Row' icon is Enabled");
		} else {
			Assert.fail("Assertion Failed: 'Delete Row' icon is NOT Enabled");
		}

		element("btn_DeleteRow").click();
		logMessage("Instructor clicked on 'Delete Row' icon from Editor toolbar");
		switchToDefaultContent();
	}

	public void selectTableMenuFromDropdown(String tableValue) {
		waitForElementToBeVisible("tableDropdownOpen");
		element("tableDropdownOpen").click();

		waitForElementToBeVisible("tableMenu", tableValue);
		element("tableMenu", tableValue).click();
		logMessage("User clicked on Table Menu present in tool panel");
	}

	public void selectTableActionToPerfome(String postionOfRow,
			String postionOfColumn, String tableAction) {
		clickOnRowCell(postionOfRow, postionOfColumn);

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		selectTableMenuFromDropdown(tableAction);
		switchToDefaultContent();
	}

	public void clickOnRowCell(String postionOfRow, String postionOfColumn) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		Actions action = new Actions(driver);
		action.moveToElement(
				element("clk_SelectRow", postionOfRow, postionOfColumn))
				.build().perform();
		action.click().build().perform();

		logMessage("Instructor clicked on Row of the table via 'Action Class'");
		switchToDefaultContent();
	}

	public void insertRowBefore(String postionOfRow, String postionOfColumn) {
		clickOnRowCell(postionOfRow, postionOfColumn);

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_InsertRowBefore").click();
		logMessage("Instructor clicked on 'insert row before' icon from Editor toolbar");
		switchToDefaultContent();
	}

	public void insertColumnBefore(String postionOfRow, String postionOfColumn) {
		clickOnRowCell(postionOfRow, postionOfColumn);

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_insertColumnBefore").click();
		logMessage("Instructor clicked on 'insert column before' icon from Editor toolbar");

		switchToDefaultContent();
	}

	public void openNumericField() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		Actions action = new Actions(driver);
		action.doubleClick(element("img_numericType"));
		action.perform();

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		isElementDisplayed("txt_numericResponseEditor");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_htsGridFooterCancel").click();
		logMessage("Instructor clicked on 'Cancel' button");
	}

	public void cancelDailogBox() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("btn_cancelImageDialogBox").click();
		logMessage("Instructor clicked on 'Cancel' icon ");
		switchToDefaultContent();
	}

	public void clickInsertResponseAreaDropDown() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("dropdown_InsertResponseArea").click();
		logMessage("Instructor clicked on 'Response' icon");
		switchToDefaultContent();
	}

	public void insertResponseAreaDropDown(String postionOfRow,
			String postionOfColumn, String responseName) {
		clickOnRowCell(postionOfRow, postionOfColumn);

		clickInsertResponseAreaDropDown();

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("txt_multiResponse", responseName).click();
		logMessage("User clicked on Multiple Response");
		switchToDefaultContent();
	}

	/**
	 * Method which creates Multiple Choice Response in the question and finally
	 * saves all options of response
	 * 
	 */
	public void createNewMCQResponse() {
		for (int i = 1; i <= 4; i++) {
			createMultipleChoiceResponse(String.valueOf(i));

			switchToDefaultContent();
			switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

			if (i != 4) {
				element("radio_correctAnswer").click();
			}
			switchToDefaultContent();
		}
		logMessage("Instructor selected 1st option as answer of Multiple Choice Question");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_mcqResponseEditorSave").click();
		logMessage("Instructor clicked on 'Save' button of Mutiple Choice Response Editor");
		switchToDefaultContent();
	}

	/**
	 * Method which creates Multiple Choice Response in the question
	 * 
	 */
	public void multipleChoiceResponse() {
		for (int i = 1; i <= 2; i++) {
			createMultipleChoiceResponse(String.valueOf(i));
		}

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("radio_correctAnswer").click();
		logMessage("Instructor clicked on radio button for 'Correct Answer' in Multiple Choice Response");
	}

	/**
	 * Method where multiple options are added to MCQ response
	 * 
	 * @param optionText
	 * 
	 */
	public void createMultipleChoiceResponse(String optionText) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		switchToFrame(element("iframes_mcqResponseEditor", optionText));

		element("txt_tinyMceContent").clear();
		logMessage("Instructor cleared the default text present in option field");
		element("txt_tinyMceContent").sendKeys(optionText);

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		logMessage("Instructor entered '" + optionText
				+ "' in the option field");
		element("btn_AddAnswerOption").click();

		logMessage("Instructor clicked on 'Add Answer Option' button under Multiple "
				+ "Choice Response Editor");
		switchToDefaultContent();
	}

	public void createNumericResponse(String optionText) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("txt_tinyMceContent").clear();
		logMessage("Instructor cleared the default text present in option field");
		element("txt_tinyMceContent").sendKeys(optionText);

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		logMessage("Instructor entered '" + optionText + "' in the option field");
		element("btn_AddAnswerOption").click();

		logMessage("Instructor clicked on 'Add Answer Option' button under Multiple "
				+ "Choice Response Editor");
		switchToDefaultContent();
	}


	public void insertColumnAfter(String postionOfRow, String postionOfColumn) {
		clickOnRowCell(postionOfRow, postionOfColumn);

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_insertColumnAfter").click();
		switchToDefaultContent();
	}

	public void saveMultipleChoiceResponseEditor() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_htsDialogSave").click();
		logMessage("clicked on Save button");

		switchToDefaultContent();

	}

	public void clickOnRowCell(String postionOfRow, String postionOfColumn,
			String enterTextOnCell) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		Actions action = new Actions(driver);
		action.moveToElement(
				element("clk_SelectRow", postionOfRow, postionOfColumn))
				.build().perform();
		action.clickAndHold().build().perform();
		action.release().build().perform();
		action.sendKeys(enterTextOnCell).build().perform();

		logMessage("Instructor clicked on Row of the table via 'Action Class'");
		switchToDefaultContent();
	}

	@SuppressWarnings("unused")
	public void tableImageverify(String postionOfRow, String postionOfColumn) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		String imageSRC = "http://fc00.deviantart.net/fs70/i/2013/254/1/6/spirit_wolf_and_tree_of_life_by_calamitymoon-d4s8i5e.jpg";

		String width = element("img_ImageOnTable", imageSRC).getAttribute(
				"width");
		String height = element("img_ImageOnTable", imageSRC).getAttribute(
				"height");
		String data_mce_src = element("img_ImageOnTable", imageSRC)
				.getAttribute("data-mce-src");
		String src = element("img_ImageOnTable", imageSRC).getAttribute("src");
		String onmouseover = element("img_ImageOnTable", imageSRC)
				.getAttribute("onmouseover");

		hoverClick(element("img_ImageOnTable", imageSRC));
		element("img_ImageOnTable", imageSRC).click();
		logMessage("Instructor clicked on the image present in the question");

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_Imageicon").click();
		logMessage("Instructor clicked on 'Insert/Edit' image icon");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		element("img_generalTab", "General").click();
		logMessage("Instructor clicked on 'General' Property Tab of image");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		element("img_generalTab", "Appearance").click();
		logMessage("Instructor clicked on 'Appearance' Property Tab of image");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		element("img_generalTab", "Advanced").click();
		logMessage("Instructor clicked on 'Advanced' Property Tab of image");

		switchToDefaultContent();
		String frameIdEasyXDM = element("iframe_mainFrame").getAttribute("id");
		switchToFrame(element("iframe_mainFrame"));
		String frameIdMce = element("iframe_mceinlinePopups")
				.getAttribute("id");
		switchToDefaultContent();

		String runTimesrc = (String) executeJavascript("return document.getElementById('"
				+ frameIdEasyXDM
				+ "')"
				+ ".contentDocument.getElementById('"
				+ frameIdMce
				+ "')"
				+ ".contentDocument.getElementById('src').value");

		String runTimewidth = (String) executeJavascript("return document.getElementById('"
				+ frameIdEasyXDM
				+ "')"
				+ ".contentDocument.getElementById('"
				+ frameIdMce
				+ "')"
				+ ".contentDocument.getElementById('width').value");

		String runTimeHeight = (String) executeJavascript("return document.getElementById('"
				+ frameIdEasyXDM
				+ "')"
				+ ".contentDocument.getElementById('"
				+ frameIdMce
				+ "')"
				+ ".contentDocument.getElementById('height').value");

		String onmouseoversrc = (String) executeJavascript("return document.getElementById('"
				+ frameIdEasyXDM
				+ "')"
				+ ".contentDocument.getElementById('"
				+ frameIdMce
				+ "')"
				+ ".contentDocument.getElementById('onmouseoversrc').value");

		/*
		 * customAssert.customAssertEquals(width, runTimewidth,
		 * "Assertion Failed: Width attribute of image is NOT matching!!!");
		 * customAssert.customAssertEquals(height, runTimeHeight,
		 * "Assertion Failed: Height attribute of image is NOT matching!!!");
		 * customAssert.customAssertEquals(src, onmouseover,
		 * "Assertion Failed: Src attribute of image is NOT matching!!!");
		 * customAssert.customAssertEquals(runTimesrc, onmouseoversrc,
		 * "Assertion Failed: TimeSrc attribute of image is NOT matching!!!");
		 */

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_CancelInLine").click();
		logMessage("Instructor clicked on 'Cancel' button present on Insert/Edit image modal window");

		switchToDefaultContent();
	}

	/**
	 * Method which enters the value for new Text Response in the question
	 * 
	 * @param txtValue
	 *            - Value of text response
	 * 
	 */
	public void createNewTextResponse(String txtValue) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_responseEditor");

		element("txtbox_textResponseEditorAnswerInput").sendKeys(txtValue);
		logMessage("Instructor entered text response in input textbox");

		element("btn_textResponseEditorSave").click();
		logMessage("Instructor clicked on 'Save' button of Text Response Editor");
		waitForElementToDisappear("btn_textResponseEditorSave");
		switchToDefaultContent();
	}

	/**
	 * Method which creates a new "Text" Response Area and then edits the same
	 * in Question Editor
	 * 
	 */
	public void editNewlyCreatedTextResponseinQuestionEditor() {
		selectOptionFromResponseArea("Text");
		_verifyTextResponseEditorIsDisplayed("Text Response Editor");
		createNewTextResponse("Testing Text Response Area!!!");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		doubleClick(element("img_responseArea"));
		logMessage("Instructor double clicked on newly created Multiple Choice Response");

		_verifyTextResponseEditorIsDisplayed("Text Response Editor");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_responseEditor");

		element("btn_textResponseEditorCancel").click();
		logMessage("Instructor clicked on 'Cancel' button of Text Response Editor");

		switchToDefaultContent();
	}

	/**
	 * Verify whether the Numeric Response Editor is displayed with its title
	 * 
	 * @param responseEditorTitle
	 *            - Title of Numeric Response Editor
	 * 
	 */
	public void verifyNumericResponseEditorIsDisplayed(
			String responseEditorTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_numericResponseEditorTitle");
		customAssert
		.customAssertEquals(element("txt_numericResponseEditorTitle")
				.getText(), responseEditorTitle,
				"Assertion Failed: Numeric Response Editor Title is NOT Correct");

		switchToFrame(element("iframe_responseEditor"));

		isElementDisplayed("btn_numericAddCorrectAnswer");
		isElementDisplayed("btn_numericResponseEditorSave");
		isElementDisplayed("btn_numericResponseEditorCancel");

		logMessage("Assertion Passed: User is opened Numeric Response Editor, Verified Page title "
				+ "visibility and Title text to be: " + responseEditorTitle);
		switchToDefaultContent();
	}

	/**
	 * Verify whether the Numeric Response Editor is NOT displayed with its
	 * title
	 * 
	 * 
	 */
	public void verifyNumericResponseEditorIsNotDisplayed() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert
		.customAssertEquals(
				verifyElementNotDisplayed(
						"txt_numericResponseEditorTitle", ""), true,
				"Assertion Failed: User is still on Numeric Response Editor!!!");
		logMessage("Assertion Passed: User is NOT on Numeric Response Editor!!!");

		switchToDefaultContent();
	}

	/**
	 * Verify whether the Numeric Response Editor is displayed with its title
	 * 
	 * 
	 */
	public void verifyNumericResponseEditorIsDisplayed() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert.customAssertEquals(
				isElementDisplayed("txt_numericResponseEditorTitle"), true,
				"Assertion Failed: User is NOT on Numeric Response Editor!!!");
		logMessage("Assertion Passed: User is on Numeric Response Editor!!!");

		switchToDefaultContent();
	}

	/**
	 * Method which enters the value for new Numeric Response in the question
	 * 
	 * @param txtValue
	 *            - Value of Numeric response
	 */
	public void createNewNumericResponse(String txtValue) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_responseEditor");
		waitForElementToBeVisible("txtbox_numericResponseEditorAnswerInput");

		fillText(element("txtbox_numericResponseEditorAnswerInput"), txtValue);
		logMessage("Instructor entered '" + txtValue
				+ "' Numeric response in input textbox");

		element("btn_numericResponseEditorSave").click();
		logMessage("Instructor clicked on 'Save' button of Text Response Editor");

		switchToDefaultContent();
	}

	/**
	 * Method which creates a new "Numeric" Response Area and then edits the
	 * same in Question Editor
	 * 
	 */
	public void editNewlyCreatedNumericResponseinQuestionEditor() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		doubleClick(element("img_responseArea"));
		logMessage("Instructor double clicked on newly created Numeric Response Area");

		verifyNumericResponseEditorIsDisplayed("Numeric Response Editor");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_responseEditor");

		element("btn_numericResponseEditorCancel").click();
		logMessage("Instructor clicked on 'Cancel' button of Numeric Response Editor");

		switchToDefaultContent();
	}

	/**
	 * Verify whether the MCQ Response Editor is displayed with its title
	 * 
	 * @param responseEditorTitle
	 *            - Title of MCQ Response Editor
	 * 
	 */
	public void verifyMCQResponseEditorIsDisplayed(String responseEditorTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_mcqResponseEditorTitle");
		customAssert.customAssertEquals(element("txt_mcqResponseEditorTitle")
				.getText(), responseEditorTitle,
				"Assertion Failed: MCQ Response Editor Title is NOT Correct");

		switchToFrame(element("iframe_mceinlinePopups"));

		isElementDisplayed("btn_mcqAddCorrectOption");
		isElementDisplayed("btn_mcqResponseEditorSave");
		isElementDisplayed("btn_mcqResponseEditorCancel");

		logMessage("Assertion Passed: User is opened MCQ Response Editor, Verified Page title "
				+ "visibility and Title text to be: " + responseEditorTitle);

		switchToDefaultContent();
	}

	/**
	 * Method which creates a new "MCQ" Response Area and then edits the same in
	 * Question Editor
	 * 
	 */
	public void editNewlyCreatedMCQResponseinQuestionEditor() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		doubleClick(element("img_responseArea"));
		logMessage("Instructor double clicked on newly created Multiple Choice Response Area");

		verifyMCQResponseEditorIsDisplayed("Multiple Choice Response Editor");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_responseEditor");

		element("btn_mcqResponseEditorCancel").click();
		logMessage("Instructor clicked on 'Cancel' button of Mutiple Choice Response Editor");

		switchToDefaultContent();
	}

	public void enterAnswerInFormulaResponseEditor() {
		switchToDefaultContent();
		scrollDown(element("btn_doneEditing"));
		switchToFrame(element("iframe_mainFrame"));

		_verifyFormulaEditorTitle();

		switchToFrame(element("iframe_responseEditor"));
		//scrollToTop();
		executeJavascript("document.getElementsByClassName('hts-formula-input')[0].click();");
		//element("txt_firstAnswerBox").click();
		scrollToTop();

		String objectName1 = "[object MainTimeline]";
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		initializingGenie(objectName1);
		//clearQuestionEditor();
		//focusOnFormulaEditor();
		createMathematicalExpression();
		clickOnSubmitButtonPresentOnFormulaEditorWindow();

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_htsDialogSave").click();
		logMessage("Instructor clicked in 'Save' button");
		switchToDefaultContent();
	}

	public void _verifyFormulaEditorTitle() {
		isElementDisplayed("txt_formulaResponceEditorTitle");
	}

	public void submitButtonOnPreview() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		element("btn_submit").click();
		logMessage("User clicked on 'Submit' button in player");

		element("btn_yesConfirmationBox").click();
		logMessage("User clicked 'Yes' present on the confirmation box");

		switchToDefaultContent();
		waitForMsgToastToDisappear();
	}

	public void clickOnRadioButtonOnPreview(String radioBtn) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		element("radio_radioOnPreview", radioBtn).click();
		logMessage("User clicked on 'Preview' radio button");
		switchToDefaultContent();
	}

	public void verifyAnswerOnPreview() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		isElementDisplayed("img_incorrectRadioImg");
		switchToDefaultContent();
	}

	public void selectCopyAndPasteData() {
		hardWait(1);
		try {
			switchToDefaultContent();
			switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

			element("txt_questionTextArea").sendKeys(
					Keys.chord(Keys.CONTROL, "a"));
			logMessage("User selected all the contents in Question editor");

			element("txt_questionTextArea").sendKeys(
					Keys.chord(Keys.CONTROL, "c"));
			logMessage("User copied all the contents present in Question editor");

			element("txt_questionTextArea").sendKeys(
					Keys.chord(Keys.CONTROL, "v"));
			logMessage("User Pasted all the contents in the Question editor");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void verifyAlertBoxAppearOnPastingResponseDataUnderQuestionAndResponse() {
		selectCopyAndPasteData();

		// Added Hard Wait: To verify the Alert window
		hardWait(1);

		String alertMessage = handleAlert();
		System.out.println("Text of alert message: " + alertMessage);

		// Added Hard Wait: To get the text of the alert window
		hardWait(1);

		if (alertMessage == null) {
			Assert.fail("Assertion Failed: Alert window did NOT Appeared!!!");
		} else {
			logMessage("Assertion Passed : Alert appeared having text \""
					+ alertMessage + "\"");
		}
	}

	/**
	 * Method which adds Numeric Array variable to Advanced question
	 * 
	 * @param variableName
	 *            - Name of the variable
	 * 
	 */
	public void insertVariableInQuestion(String variableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		isElementDisplayed("btn_addVariable");

		hover(element("list_htsVariable", variableName));
		logMessage("Instructor hovered on the list of HTS variables");

		if (!variableName.equalsIgnoreCase("MathArray")) {
			logMessage("Instructor tried to insert 'MathArray' variable to Tiny MCE");
		}

		element("icon_insertHtsvariable", variableName).click();
		logMessage("Instructor clicked on 'Insert HTS variable' icon");

		if (variableName.equalsIgnoreCase("NumericArray")
				|| variableName.equals("TextArray")) {
			switchToFrame(element("iframe_mceinlinePopups"));
			fillText("input_htsVariableIndex", "1");

			element("btn_htsDialogOk").click();
			logMessage("User input a value to index into the Numeric/Text Array variable");
		}

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").sendKeys(Keys.RETURN);
		logMessage("Cursor is moved to New line of question");

		switchToDefaultContent();
	}

	/**
	 * Method which adds Numeric Array variable to Advanced question
	 * 
	 * @param variableType
	 *            - Type of variable
	 * @param variableName
	 *            - Name of the variable that needs to inserted to the question
	 * 
	 */
	public void insertVariableInQuestion(String variableType,
			String variableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		isElementDisplayed("btn_addVariable");

		hover(element("list_htsVariable", variableName));
		logMessage("Instructor hovered on the list of HTS variables");

		// Note: Math array variables can ONLY be inserted into formulas and NOT
		// as individual variables
		if (!variableType.equalsIgnoreCase("MathArray")) {
			element("icon_insertHtsvariable", variableName).click();
			logMessage("Instructor clicked on 'Insert HTS variable' icon");
		}

		if (variableType.toUpperCase().contains("array".toUpperCase())) {
			clickOkOnNumericConfirmationDialogBox();
		}

		verifyVariableInsertedInQuestion(1);
	}

	/**
	 * Method which verifies whether the variable is added to TinyMce after
	 * performing insert action
	 * 
	 * @param count
	 *            - No. of images present in TinyMce
	 * 
	 */
	public void verifyVariableInsertedInQuestion(int count) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		logMessage("Total no. of images in TinyMce: "
				+ elements("img_totalImagesInQuestion").size());

		if (count == elements("img_totalImagesInQuestion").size()) {
			logMessage("Assertion Passed: Variable is inserted successfully to the question!!!");
		} else {
			Assert.fail("Assertion Failed: Variable is NOT inserted to the question!!!");
		}

		switchToDefaultContent();
	}

	public void selectVariableTypeFromAddVariableDropDown(String variableType) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		element("btn_addVariable").click();
		logMessage("Instructor clicked on 'Add Variable' Dropdown button");
		element("opt_htsVaribleType", variableType).click();
		logMessage("Instructor clicked on 'Text' dropdown value from the list");
	}

	/**
	 * Method which creates a Text variable
	 * 
	 * @param variableName
	 *            - Name of Text variable
	 * 
	 */
	public void createTextVariable(String variableName) {
		final String title = "Editing Text Variable";

		selectVariableTypeFromAddVariableDropDown("Text");

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_editTextvariabeltitle", title);

		element("input_htsVariableName").clear();
		element("input_htsVariableName").click();
		element("input_htsVariableName").sendKeys(variableName);

		element("input_variableString").clear();
		element("input_variableString").click();
		element("input_variableString").sendKeys(variableName);

		element("btn_saveTextVariable").click();
		logMessage("User Clicked on Save button in Text Variable Editor");

		switchToDefaultContent();
	}

	/**
	 * Method which deletes the variable from Variable Panel
	 * 
	 * @param variableName
	 *            - Name of Hts variable
	 * 
	 */
	public void deleteVariable(String variableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		hover(element("list_htsVariable", variableName));
		element("icon_deleteHtsvariable", variableName).click();
		logMessage("Instructor clicked on 'Delete' icon after hovering on that Hts variable");

		// NOTE: Added Hard Wait as to wait for Alert Message for deleting the
		// variable
		hardWait(1);

		waitForElementToBeVisible("txt_variableRefWarning", "Are you sure?");
		customAssert
		.customAssertEquals(element("txt_alertMessage").getText()
				.trim(), "Are you sure?",
				"Assertion Failed: Alert message Are you sure? is not present.");
		element("btn_showExistingGraph").click();

		hardWait(1);

		waitForElementToBeVisible("txt_variableRefWarning", "Deleted!");
		customAssert.customAssertEquals(element("txt_alertMessage").getText()
				.trim(), "Deleted!",
				"Assertion Failed: Alert message Deleted! is not present.");
		isElementDisplayed("txt_variableRefWarning", "Deleted!");

		element("btn_showExistingGraph").click();
		logMessage("Instructor clicked on Yes, Delete It button");
		logMessage("Variable '" + variableName + "' has been deleted");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Hide Variable' button on Question Editor
	 * 
	 */
	public void clickOnHideVariable() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_hide_variable").click();
		logMessage("Instructor clicked on 'Hide Variable' button");

		switchToDefaultContent();
	}

	public void clickOnAddSolutionbutton() {
		element("btn_addsolution").click();
		logMessage("user click on Add Solution button");
	}

	public void createNumericArrayVariable(String variableName) {
		selectVariableTypeFromAddVariableDropDown("Numeric Array");

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_tileNumericArrayEditor");
		fillText(element("input_arrayNumericVariableName"), variableName);

		fillText(element("input_txtDecimalVariable"), "1");
		element("btn_addNumericArrayValue").click();

		fillText(element("input_numericArrayValue"), "12");
		element("btn_numericArraySave").click();
		logMessage("User click on save button on Edit Numeric Array Editor");

		switchToDefaultContent();
	}

	public void createTextArrayVariable(String variableName) {
		selectVariableTypeFromAddVariableDropDown("Text Array");

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		isElementDisplayed("txt_tileTextArrayEditor");

		fillText(element("input_textArrayVariableName"), variableName);
		element("btn_addTextArrayValue").click();

		fillText(element("input_textArrayValue"), "12");
		element("btn_textArraySave").click();
		logMessage("User click on save button on Edit Text Array Editor");

		switchToDefaultContent();
	}

	public void createMathArrayVariable(String variableName) {
		selectVariableTypeFromAddVariableDropDown("Math Array");

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		isElementDisplayed("txt_titleMathArrayEditor");

		fillText(element("input_mathArrayVariableName"), variableName);

		element("btn_mathArraySave").click();
		logMessage("User click on save button on Edit Math Array Editor");

		switchToDefaultContent();
	}

	public void clickOkOnNumericConfirmationDialogBox() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_htsDialogSave").click();
		logMessage("User clicked on Ok button on confirmation dialog");

		switchToDefaultContent();
	}

	public void editTextVariableInQuestionEditor(String variableName,
			String stringName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("btn_addVariable");
		waitForElementToBeVisible("list_htsVariable", variableName);

		hover(element("list_htsVariable", variableName));
		element("icon_editHtsVariable", variableName).click();

		element("input_variableString").click();
		element("input_variableString").clear();
		element("input_variableString").sendKeys(stringName);
		logMessage("Instructor keys-in necessary values for Text variable");

		element("btn_saveTextVariable").click();
		logMessage("Instructor clicked on 'Save' button present on the form");

		switchToDefaultContent();
	}

	public void verifyTextOnPreview(String textName, String expectedTagName) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		String tagName = element("text_previewText", textName).getTagName();
		customAssert.customAssertEquals(tagName, expectedTagName,
				"Assertion Failed: Text is NOT matching!!!");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies response code of images in Advanced Question
	 * Player(AQP) i.e., viewing the question in Preview mode
	 * 
	 */
	public void verifyImageIsDisplayOnPreview() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		List<WebElement> img = elements("img_totalImagesInQuestion");
		System.out.println("No. of images in the question: " + img.size());
		for (WebElement i : img) {
			if (i.getSize() != null) {
				try {
					String link = i.getAttribute("src");
					URL u = new URL(link);
					HttpURLConnection h = (HttpURLConnection) u
							.openConnection();
					h.setRequestMethod("GET");
					h.connect();

					int responsecode = h.getResponseCode();
					logMessage("Image Response Code: " + responsecode);
					if (responsecode == 200) {
						logMessage("Assertion Passed: Response Code '"
								+ responsecode + "' for the image: "
								+ i.getAttribute("src"));
					} else {
						Assert.assertTrue(false,
								"Assertion Failed: Response Code is NOT equal to 200 !!!");
					}
				} catch (Exception e) {
					System.out.println("In catch");
					e.printStackTrace();
				}
			}
		}
		switchToDefaultContent();
	}

	/**
	 * Method which edits an existing Multiple Choice Response present in
	 * advanced question
	 * 
	 */
	public void editMultipleChoiceResponseEditorForAA_456() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").click();
		logMessage("Instructor clicked on textarea to keep focus on question editor");

		doubleClick(element("img_multipleChoiceResponse"));
		logMessage("Instructor double clicked on a Multiple Choice Response");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Add Answer Option' button
	 * 
	 */
	public void clickOnAddAnswerOptionInMultipleChoiceResponseEditor() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_AddAnswerOption").click();
		logMessage("Instructor clicked on 'Add Answer Option' button present "
				+ "on Multiple Choice Response Editor");
		switchToDefaultContent();
	}

	public void sendTextOnMultipleChoiceResponseOption(String optionText,
			String optionNo) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		switchToFrame(element("iframes_mcqResponseEditor", optionNo));

		element("txt_tinyMceContent").click();
		logMessage("Instructor clicked on 'Response field' present on MCQ option");

		element("txt_tinyMceContent").clear();
		element("txt_tinyMceContent").sendKeys(optionText);

		logMessage("Instructor entered '" + optionText
				+ "' in answer option of MCQ");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Save' button present on Multiple Choice Response
	 * Editor
	 * 
	 */
	public void clickOnSaveOnMultipleChoiceResponseEditor() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_htsDialogSave").click();
		logMessage("User clicked on 'Save' button present on Multiple Choice Response Editor");

		switchToDefaultContent();
	}

	/**
	 * Method which takes button name as a argument and clicked on 'Add Step',
	 * 'Add Hint', 'Add Correct Feedback' or 'Add Incorrect Feedback' button.
	 * 
	 */
	public void clickOnAddButton(String buttonName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_add", buttonName).click();
		logMessage("Instructor clicked on '" + buttonName + "' button");

		switchToDefaultContent();
	}

	/**
	 * Method which scroll to specific Step of the question
	 * 
	 * @param stepNumber
	 *            - No. of the step
	 * 
	 */
	public void clickOnResponseAreaOfSpecificStep(String stepNumber) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		scroll(element("iframe_editorSpecificQuestionFrame", stepNumber));

		switchToFrame(element("iframe_editorSpecificQuestionFrame", stepNumber));

		element("txt_tinyMceContent").click();
		logMessage("User clicked on Tiny Mce body of step '" + stepNumber
				+ "' of question");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies that Response drop down is visible
	 * 
	 * @param stepNo
	 *            - Step no of the question
	 * 
	 */
	public void verifyResponseDropDown(String stepNo) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("drpdwn_responseTable", stepNo);
		switchToDefaultContent();
	}

	/**
	 * Method to add 'Numeric' variable to the Advanced question
	 * 
	 */
	public void addNumericVariableToTheQuestion(String variableName,
			String variableValue) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_addVariable").click();
		logMessage("Instructor clicked on 'Add Variable' Dropdown button");

		element("opt_htsVaribleType", "Numeric").click();
		logMessage("Instructor clicked on 'Numeric' dropdown value from the list");

		element("txtbox_name").sendKeys(variableName);
		logMessage("Instructor entered '" + variableName
				+ "' in Numeric textbox");

		element("radio_list").click();
		logMessage("Instructor clicked on 'List' radio button");

		element("txtbox_inclusion").sendKeys(variableValue);
		logMessage("Instructor fills '" + variableValue
				+ "' value to Hts Numeric variable");

		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the form");

		switchToDefaultContent();
	}

	/**
	 * Method to add 'Numeric Array' variable to the Advanced question
	 * 
	 */
	public void addNumericArrayVariableToTheQuestion(String variableName,
			String variableValue) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_addVariable").click();
		logMessage("Instructor clicked on 'Add Variable' Dropdown button");

		element("opt_htsVaribleType", "Numeric Array").click();
		logMessage("Instructor clicked on 'Numeric Array' dropdown value from list");

		isElementDisplayed("txt_tileNumericArrayEditor");

		element("input_arrayNumericVariableName").sendKeys(variableName);
		logMessage("Instructor entered '" + variableName
				+ "' in 'Numeric Array' textbox");

		fillText(element("input_txtDecimalVariable"), "0");
		logMessage("Instructor entered '0' value in 'Decimal Places' textbox ");

		element("btn_addNumericArrayValue").click();
		logMessage("Instructor clicked on 'Add Array Value' button");

		fillText(element("input_numericArrayValue"), variableValue);
		logMessage("User entered '" + variableValue
				+ "' value for Numeric Array");

		element("act_htsVariableSave").click();
		logMessage("User clicked on 'Save' action icon");

		element("btn_numericArraySave").click();
		logMessage("User click on 'Save' button on Edit Numeric Array Editor");

		switchToDefaultContent();
	}

	/**
	 * Method to enter the index of Numeric Array variable to insert the that
	 * particular value to the question
	 * 
	 */
	public void enterIndexOfNumericArrayVariable() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		fillText(element("input_htsVariableIndex"), "");

		element("btn_htsDialogOk").click();
		logMessage("Instructor clicked on 'OK' button present on the dialog box");

		switchToDefaultContent();
	}

	/**
	 * Verifies whether the 'Index Numeric Array Variable' Window is displayed
	 * 
	 * @param indexNumericVariableTitle
	 *            - Title of Index Numeric Array Variable
	 * 
	 */
	public void verifyIndexNumericArrayVariableWindowIsDisplayed(
			String indexNumericVariableTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_indexNumericVariableTitle",
				indexNumericVariableTitle);
		logMessage("Assertion Passed: User is on Question Editor page, Verified Index Numeric "
				+ "variable Title visibility and Title text to be: "
				+ indexNumericVariableTitle);

		switchToDefaultContent();
	}

	/**
	 * Method which verifies AA-535 ticket where variable having same name as
	 * the other corrupts the variable also the (Numeric/Text) variable value is
	 * replaced with the array variable (Text/Numeric) values
	 * 
	 * @param arrayVariableValues
	 *            - Value of array variable to check whether other variable's
	 *            value is NOT replaced by this value.
	 * 
	 */
	public void verifyVariableValueIsNotReplacedWithArrayVariableValueForAA_535(
			String arrayVariableValues) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		int count = 0;
		for (WebElement htsContent : elements("txt_listOfHtsQuestionContent")) {
			System.out.println("Value of each line present in Hts Question: "
					+ htsContent.getText());
			if (htsContent.getText().contains(arrayVariableValues)) {
				count++;
			}
		}
		if (count == 2) {
			Assert.fail("Assertion Failed: Value of other variable has been "
					+ "replaced by Array variable's values!!!");
		} else {
			logMessage("Assertion Passed: (Numeric/Text) variable's values were NOT replaced "
					+ "by Array variable's value!!!");
		}
		switchToDefaultContent();
	}

	/**
	 * Method which clicks on Insert Hts Graph icon present in tool panel
	 * 
	 */
	public void clickOnInsertHtsGraphIcon() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("icon_insertHtsGraph").click();
		logMessage("Instructor clicked on 'Insert Graph' button");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies whether the Import Graph window is displayed
	 * 
	 * @param importGraphTitle
	 *            - Title of Import Graph Window
	 * @param windowStatus
	 *            - Verify the window of Import Graph XML
	 * 
	 */
	public void verifyImportGraphWindowIsDisplayed(String importGraphTitle,
			boolean windowStatus) {
		switchToDefaultContent();
		String frameId = element("iframe_mainFrame").getAttribute("id");

		if (windowStatus == true) {
			switchToFrame(element("iframe_mainFrame"));
			String spanId = element("txt_importGraphTitle").getAttribute("id");

			switchToDefaultContent();
			String txtTitle = (String) executeJavascript("return document.getElementById('"
					+ frameId
					+ "').contentDocument.getElementById('"
					+ spanId
					+ "').textContent");

			switchToDefaultContent();
			switchToFrame(element("iframe_mainFrame"));

			waitForElementToBeVisible("txt_importGraphTitle");
			isElementDisplayed("txt_importGraphTitle");
			customAssert.customAssertEquals(txtTitle, importGraphTitle,
					"Assertion Failed: Import Graph title is NOT correct!!!");

			// Verifying the buttons on Import Graph XML / Edit Graph
			switchToFrame(element("iframe_mceinlinePopups"));

			isElementDisplayed("btn_browseFile");
			isElementDisplayed("btn_htsDialogSave");
			isElementDisplayed("btn_htsDialogCancel");

			logMessage("Assertion Passed: User is on Question Editor page, Verified Import "
					+ "Graph title visibility and Title text to be: "
					+ importGraphTitle);
			switchToDefaultContent();
		} else {
			switchToDefaultContent();
			switchToFrame(element("iframe_mainFrame"));

			customAssert
			.customAssertEquals(
					elements("txt_importGraphTitle").size(), 0,
					"Assertion Failed: Import Graph window is still visible!!!");

			logMessage("Assertion Passed: User is on Question Editor page, Verified that Import "
					+ "Graph window is NOT visible!!!");
			switchToDefaultContent();
		}
	}

	/**
	 * Method which verifies that the insert HTS graph image is visible on Text
	 * Editor Tool Bar
	 * 
	 */
	public void verifyInsertHtsGraphIconOnEditorToolBar() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("icon_insertHtsGraph");

		if (element("icon_insertHtsGraph").isDisplayed()) {
			logMessage("Assertion Passed: User is on Question Editor page, "
					+ "Verified Insert Hts graph image is visible on Text Editor Tool Bar!!!");
		} else {
			Assert.fail("Assertion Failed: Hts Graph image is NOT visible on Text Editor Tool Bar!!!");
		}

		switchToDefaultContent();
	}

	/**
	 * Method which browses the file locally and uploads the file to the editor
	 * 
	 * @param xmlName
	 *            - Name of the xml file that needs to be imported
	 * 
	 */
	public void importGraphXMLByUploadingTheFile(String xmlName) {
		String currentDir = System.getProperty("user.dir");

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		System.out.println("Image Path: " + currentDir + File.separator + "src"
				+ File.separator + "test" + File.separator + "resources"
				+ File.separator + "AA-Artifacts" + File.separator
				+ "questions-xmls" + File.separator + xmlName);

		element("btn_browseFile").sendKeys(
				currentDir + File.separator + "src" + File.separator + "test"
						+ File.separator + "resources" + File.separator
						+ "AA-Artifacts" + File.separator + "questions-xmls"
						+ File.separator + xmlName);
		logMessage("Instructor browses the file to upload for graph player");

		element("input_formulaData").sendKeys("x");
		logMessage("Instructor entered formula value to include variable defined in the question");

		element("btn_htsDialogSave").click();
		logMessage("Instructor clicked on 'Save' button");

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		// Note: Wait for Import Graph Window to close after importing the graph
		// with some set of variables
		waitForElementToDisappear("txt_importGraphTitle");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies that graph icon is present in TinyMce content
	 * window
	 * 
	 */
	public void verifyGraphIconIsVisibleOnTheEditor() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		isElementDisplayed("img_graphInTinyMce");

		customAssert.customAssertEquals(elements("img_graphInTinyMce").size(),
				1,
				"Assertion Failed: Graph Icon is NOT included in question!!!");
		logMessage("Assertion Passed: Graph Icon is visible on the editor");

		switchToDefaultContent();
	}

	/**
	 * Method which closes the Advanced Question Preview window
	 * 
	 */
	public void closeQuestionPreviewWindow() {
		element("img_close").click();
		logMessage("Instructor clicked on 'Close' image present on Advanced Question Preview window");
	}

	/**
	 * Method which verifies that graph image is displayed on Advanced Question
	 * Preview window while viewing the question in AQP
	 * 
	 */
	public void verifyGraphImageIsDisplayedInPlayer() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		// Note: In this case, relevant to wait for the graph bcoz it takes time
		// to load the graph
		// in Advanced Question Player (AQP)
		waitForElementToBeVisible("obj_graphPiece");

		customAssert.customAssertEquals(isElementDisplayed("obj_graphPiece"),
				true, "Assertion Failed: Imported Graph is NOT visible in AQP");

		logMessage("Assertion Passed: Imported Graph is visible in Question Player");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies that warning message is displayed while importing
	 * more than one graph in the question i.e., a question can only contain one
	 * graph
	 * 
	 * @param graphImporterWarningTitle
	 *            - Title of Graph Importer Warning
	 */
	public void verifyGraphImporterWarningMessage(
			String graphImporterWarningTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("txt_graphImporterWarningTitle",
				graphImporterWarningTitle);

		isElementDisplayed("btn_cancelWarningDialog");
		isElementDisplayed("btn_showExistingGraph");

		customAssert.customAssertEquals(
				element("txt_graphImporterWarningTitle",
						graphImporterWarningTitle).getText(),
						graphImporterWarningTitle,
				"Assertion Failed: Graph Importer message is NOT displayed!!");

		logMessage("Assertion Passed: Graph Importer Warning is displayed having Title text: "
				+ element("txt_graphImporterWarningTitle",
						graphImporterWarningTitle).getText());

		switchToDefaultContent();
	}

	/**
	 * Method which verifies the Error message for negative set of values in NRE
	 * (Numeric Response Editor) (Weight field)
	 * 
	 */
	public void verifyNumericResponseEditorIsStillDisplayingErrorMessage() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		isElementDisplayed("txt_errorMsgForNegativeWeight");

		customAssert.customAssertEquals(
				element("txt_errorMsgForNegativeWeight").getText(),
				"Invalid field. It has been highlighted", "Assertion Failed!!");

		logMessage("Assertion Passed: Numeric Response Editor is showing error message "
				+ element("txt_errorMsgForNegativeWeight").getText());

		switchToDefaultContent();
	}

	/**
	 * Method which verifies error message after importing invalid xml file in
	 * Import Graph XML / Edit Graph
	 * 
	 * errorMsgForInvalidXml - Error message displayed while uploading invalid
	 * xml file
	 * 
	 */
	public void verifyErrorMessageForInvalidXmlFileImport(
			String errorMsgForInvalidXml) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		verifyTextOfElementIsCorrect("txt_errorMsgForInvalidXml",
				errorMsgForInvalidXml);
		switchToDefaultContent();
	}

	/**
	 * Method that clicks on 'Cancel' button located on Graph Imported Warning
	 * dialog box
	 * 
	 */
	public void clickOnCancelButtonPresentInGraphImporterWarningDialogBox() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_cancelWarningDialog").click();
		logMessage("Instructor clicked on 'Cancel' button present in the Dialog box");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Save' button to save a new variable in question
	 * 
	 */
	public void clickOnSaveVariableButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present while creating a new variable");

		switchToDefaultContent();
	}

	public void editTextContentOnTextArea(String actualText, String editText) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_textOnTextArea", actualText).sendKeys(editText);
		logMessage("Instructor enter '" + editText
				+ "' text in Question textarea of Question Editor");

		switchToDefaultContent();
	}

	public void verifyTextOnTextArea(String editText) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		String expected = element("txt_textOnTextArea", editText).getText();
		customAssert.customAssertEquals(editText, expected,
				"Assertion Failed: Text on Text Area is not matched");

		switchToDefaultContent();
	}

	public void undoOperationFromKeyboardOnTextArea() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").sendKeys(Keys.CONTROL, "z");
		switchToDefaultContent();
	}

	public void redoOperationFromKeyboardOnTextArea() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").sendKeys(Keys.CONTROL, "y");
		switchToDefaultContent();
	}

	public void clickonUndoButton(String stepNumber) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame");

		waitForElementToBeVisible("btn_undoButtonOnTestStep", stepNumber);
		element("btn_undoButtonOnTestStep", stepNumber).click();

		switchToDefaultContent();
	}

	public void verifyUndoButtonIsEnableOnTextArea(String stepNumber,
			Boolean isEnable) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").click();

		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame");

		waitForElementToBeVisible("btn_undoButtonOnTestStep", stepNumber);

		System.out.println("Undo button : "
				+ element("btn_undoButtonOnTestStep", stepNumber).getAttribute(
						"style"));
		System.out.println("Undo button : "
				+ element("btn_undoButtonOnTestStep", stepNumber).getCssValue(
						"opacity"));

		if (isEnable == true) {
			customAssert
			.customAssertEquals(
					element("btn_undoButtonOnTestStep", stepNumber)
					.isEnabled(), isEnable,
					"Assertion Failed: Undo button is NOT Enabled!!!");
		} else {
			customAssert.customAssertEquals(
					element("btn_undoButtonOnTestStep", stepNumber)
					.getCssValue("opacity"), "0.3",
					"Assertion Passed: Undo button is Enabled!!!");
		}

		logMessage("Assertion Passed: Undo Button is enabled in Question Editor i.e., "
				+ element("btn_undoButtonOnTestStep", stepNumber).isEnabled());

		switchToDefaultContent();
	}

	public void clickonRedoButton(String stepNumber) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame");

		waitForElementToBeVisible("btn_redoButtonOnTestStep", stepNumber);

		element("btn_redoButtonOnTestStep", stepNumber).click();
		logMessage("Click on Redo Button");

		switchToDefaultContent();
	}

	public String createMultipleChoiceResponseWithActionBuilderClass(
			String optionText, String optionNumber) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		switchToFrame(element("iframes_mcqResponseEditor", optionNumber));

		String fieldValue = element("txt_tinyMceContent").getText();
		element("txt_tinyMceContent").click();
		element("txt_tinyMceContent").clear();

		Actions actions = new Actions(driver);
		actions.moveToElement(element("txt_tinyMceContent"));
		actions.click();
		actions.sendKeys(optionText);
		actions.build().perform();

		logMessage("Instructor edited an option in Multiple Choice response");
		switchToDefaultContent();

		return fieldValue;
	}

	public void saveMultipleChoiceResponse() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");

		element("btn_mcqResponseEditorSave").click();
		logMessage("Instructor clicked on 'Save' button of Mutiple Choice Response Editor");

		switchToDefaultContent();
	}

	public void verifyMultipleChoiceResponceValue(String expectedValue,
			String optionNumber) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_mceinlinePopups");
		switchToFrame(element("iframes_mcqResponseEditor", optionNumber));

		String actualValue = element("txt_tinyMceContent").getText();
		customAssert.customAssertEquals(actualValue, expectedValue,
				"value is not matched");

		switchToDefaultContent();
	}

	public void verifyTextOnRawXmlAndSave(String searchText, boolean isDisplay) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		String rawXml = element("textarea_rawXMLEditor").getText();
		logMessage("User cleared the contents of TinyMCE");

		if (searchText.contains(rawXml) == isDisplay) {
			logMessage("Assert Passed: Text found in the Row XML");
		} else {
			customAssert.customAssertEquals(false, isDisplay,
					"Assertion Failed: Text is NOT found in the xml");
			logMessage("Assert Passed: Text is not found in the Row XML");
		}
		logMessage("Keyed-in the contents of XML file in Raw XML field");

		element("btn_editorSave").click();
		logMessage("Saved the contents of the Question");

		switchToDefaultContent();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void verifyVariableOnTextAreaIsDisplayed(String variableName,
			Boolean status) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		if (elements("list_htsVariableOnTextArea", variableName).size() != 0) {
			boolean variable = element("list_htsVariableOnTextArea",
					variableName).isDisplayed();
			customAssert.customAssertEquals(variable, status,
					"Assertion Failed: Variable's status: '" + status);
			logMessage("Assertion Passed: Element is displayed on Text Area");
		} else {
			customAssert.customAssertEquals(false, status,
					"Assertion Failed: Variable's status: '" + status);
			logMessage("Assertion Passed: Element is not displayed on Text Area");
		}
		switchToDefaultContent();
	}

	public void verifyVariableTextOnVariablesPanel(String variableName,
			String expectedText, boolean expectedDisplay) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("btn_addVariable");
		waitForElementToBeVisible("list_htsVariable", variableName);

		if (elements("txt_variablePanelDetails", variableName, expectedText)
				.size() != 0) {
			boolean varDisplay = element("txt_variablePanelDetails",
					variableName, expectedText).isDisplayed();
			customAssert.customAssertEquals(varDisplay, expectedDisplay,
					"Assertion Failed: Variable Text is not displayed");
			logMessage("Assertion Passed: Variable text is displayed in the variable panel");
		} else {
			customAssert.customAssertEquals(false, expectedDisplay,
					"Assertion Failed: Variable Text is displayed");
			logMessage("variable text is not displayed in the variable panel");
		}
		switchToDefaultContent();
	}

	public void dragToReorderStep(String stepNumber, String newPositionXpath) {
		Actions act = new Actions(driver);
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		act.moveToElement(element("txt_stepsPanel", stepNumber, stepNumber))
		.build().perform();
		act.clickAndHold().build().perform();

		act.moveToElement(element(newPositionXpath)).build().perform();
		act.release().build().perform();
		switchToDefaultContent();
	}

	public void editRawXmlAtEndOfQuestionXml(String text) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		waitForElementToBeVisible("textarea_rawXMLEditor");
		element("textarea_rawXMLEditor").click();
		element("textarea_rawXMLEditor").sendKeys(Keys.PAGE_DOWN);
		element("textarea_rawXMLEditor").sendKeys(Keys.END);

		element("textarea_rawXMLEditor").sendKeys(text);
		logMessage("Keyed-in the contents of XML file in Raw XML field");

		element("btn_editorSave").click();
		logMessage("Saved the contents of the Question");

		switchToDefaultContent();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void editMultipleChoiceResponseEditor(String dataType) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		doubleClick(element("img_multipleChoiceResponseType", dataType));
		logMessage("Instructor double clicked on a '" + dataType
				+ "ple' Response");

		switchToDefaultContent();
	}

	public void enterTextInTextAreaOfEditor(String textAreaName, String text) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		if (textAreaName.equalsIgnoreCase("Hint"))
			switchToFrame(element("iframe_editorHint"));

		else if (textAreaName.equalsIgnoreCase("Correct Feedback"))
			switchToFrame(element("iframe_editorCorrectFeedback"));

		else if (textAreaName.equalsIgnoreCase("Incorrect Feedback"))
			switchToFrame(element("iframe_editorInCorrectFeedback"));

		else if (textAreaName.equalsIgnoreCase("Question & Response"))
			switchToFrame(element("iframe_editorQuestionFrame"));

		fillText("txt_questionTextArea", text);
		logMessage("Text " + text + " is entered in hint text area.");

		switchToDefaultContent();
	}

	public void verifyInsertResponseEditorDropDownIsNotVisible() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert.customAssertFalse(element("drpdwn_insertResponseEditor")
				.isDisplayed(),
				"Assertion Failed: Insert Response Editor is STILL visible!!!");

		logMessage("Assertion Passed: Insert Response Editor is NOT visible!!!");
		switchToDefaultContent();
	}

	/**
	 * Method which clicks on Text Tag present in Formula Editor
	 * 
	 */
	public void clickOnTextTagInFormulaEditor() {
		try {
			(new GenieDisplayObject(
					"SP^Stage:::FP^root:::SE^btn_T::PX^0::PTR^0::IX^16::ITR^0",
					app1)).click(8, 25, 15, 31, 500, 271, 3, true);
			logMessage("Instructor clicked on Text Tag(T) in Formula Editor");
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Method which clicks on Math expression of the question inside the Text
	 * tag i.e., @Tag in question xml
	 * 
	 */
	public void clickOnMathExpressionInsideTextTag() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		doubleClick(element("img_mathExpInsideTextTag"));
		logMessage("Instructor double clicked on the Math expression inside Text tag");

		initializingGenie("[object MainTimeline]");
		clickOnTextTagInFormulaEditor();
		clickOnSubmitButtonPresentOnFormulaEditorWindow();

		switchToDefaultContent();
	}

	/**
	 * Method which verifies all the mathematical expressions which are inside
	 * Text Tag
	 * 
	 */
	public void verifyAllTheMathematicalExpressionsWhichAreInsideTextTag() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		logMessage("No. of lines in questions: "
				+ elements("txt_eachQuestionLineInPlayer").size());

		for (WebElement elem : elements("txt_eachQuestionLineInPlayer")) {
			if (elem.getText().contains("text{}")) {
				Assert.fail("Assertion Failed: Math Variable values did NOT appear as expected "
						+ "inside Text tag of Question text!!!");
			}
		}
		logMessage("Assertion Passed: Math Variable inside @T tag did NOT break!");

		switchToDefaultContent();
	}

	public void clickOnRadioButtonUsingTextOnPreview(String radioButtonString) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_previewFrame:iframe_contentFrame:iframe_questionFrame");

		element("radio_radioOnpreviewUsingTxt", radioButtonString).click();
		logMessage("User clicked on 'Preview' radio button");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies that Editor takes the entire vertical space while
	 * editing/authoring an advanced question
	 * 
	 */
	public void verifyEditorTakesEntireVerticalSpaceWhileAuthoringAdvancedQuestion() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		System.out.println("Default Width of Textarea(Step 1): "
				+ element("txt_questionTextArea").getSize().getWidth());
		System.out.println(" Default Height of Textarea(Step 1): "
				+ element("txt_questionTextArea").getSize().getHeight());

		if (element("txt_questionTextArea").getSize().getWidth() > 700) {
			logMessage("Assertion Passed: Editor has taken the entire vertical space while authoring "
					+ "an Advanced Question!!!");
		} else {
			Assert.fail("Assertion Failed: Editor has NOT taken the entire vertical space "
					+ "while authoring an Advanced Question!!!");
		}
		switchToDefaultContent();
	}

	/**
	 * Method which adds more section to advanced question
	 * 
	 * @param sectionName
	 *            - Name of the section
	 * 
	 */
	public void addSectionToAdvancedQuestion(String sectionName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_sectionName", sectionName).click();
		logMessage("Instructor clicked on '" + sectionName
				+ "' button present on editor");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies that scrolling is enabled within the text area of
	 * question after adding section to the question
	 * 
	 */
	public void verifyScrollingIsEnabledWithinTheTextAreaOfEditor() {
		switchToDefaultContent();

		String frameId = element("iframe_mainFrame").getAttribute("id");

		// NOTE: Type-casting to long instead of Int to avoid 'ClassCast'
		// Exception i.e.,
		// java.lang.Long cannot be cast to java.lang.Integer
		long scrollHeight = (Long) executeJavascript("return document.getElementById('"
				+ frameId
				+ "').contentDocument.getElementsByClassName('content-left')[0].scrollHeight");

		long clientHeight = (Long) executeJavascript("return document.getElementById('"
				+ frameId
				+ "').contentDocument.getElementsByClassName('content-left')[0].clientHeight");

		System.out
		.println("Value of scrollHeight (ClientHeight + Non-Visible Height): "
				+ scrollHeight);
		System.out
		.println("Value of clientHeight (Visible Height of Content + Visible Padding): "
				+ clientHeight);

		if (scrollHeight > clientHeight) {
			logMessage("Assertion Passed: Scroll is enabled within the text area after addition of new section!!!");
		} else {
			Assert.fail("Assertion Failed: Scroll is NOT enabled within the text area after addition of new section!!!");
		}

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on newly added section of text area
	 * 
	 * @param sectionTitle
	 *            - Title of section
	 * 
	 */
	public void switchToNewlyAddedSectionOfTextarea(String sectionTitle) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		if (sectionTitle.equalsIgnoreCase("Hint")) {
			switchToFrame(element("iframe_editorHint"));
		} else if (sectionTitle.equalsIgnoreCase("Correct Feedback")) {
			switchToFrame(element("iframe_editorCorrectFeedback"));
		} else if (sectionTitle.equalsIgnoreCase("Incorrect Feedback")) {
			switchToFrame(element("iframe_editorInCorrectFeedback"));
		}
	}

	/**
	 * Method which verifies that newly section of Text area is fully
	 * collapsed/expanded on focus
	 * 
	 * @param sectionTitle
	 *            - Title of section
	 * 
	 */
	public void verifyNewlySectionofTextareaIsExpandedOnFocus(
			String sectionTitle) {
		switchToDefaultContent();
		String frameIdEasyXDM = element("iframe_mainFrame").getAttribute("id");

		switchToFrame(element("iframe_mainFrame"));
		String frameId = null;

		if (sectionTitle.equalsIgnoreCase("Hint")) {
			frameId = element("iframe_editorHint").getAttribute("id");
		} else if (sectionTitle.equalsIgnoreCase("Correct Feedback")) {
			frameId = element("iframe_editorCorrectFeedback")
					.getAttribute("id");
		} else if (sectionTitle.equalsIgnoreCase("Incorrect Feedback")) {
			frameId = element("iframe_editorInCorrectFeedback").getAttribute(
					"id");
		}

		switchToDefaultContent();
		boolean textAreaCollapsedStatus = (Boolean) executeJavascript("return document.getElementById('"
				+ frameIdEasyXDM
				+ "').contentDocument.getElementById('"
				+ frameId + "').contentDocument.getSelection().isCollapsed");

		// NOTE: Selection.isCollapsed read-only property returns a Boolean
		// True --> When NO text is Selected
		// False--> When text is Selected

		customAssert
		.customAssertEquals(textAreaCollapsedStatus, true,
				"Assertion Failed: Newly added section has COLLAPSE by Default!!!");
		logMessage("Assertion Passed: Newly added section did NOT collapse by Default!!!");

		switchToDefaultContent();
		switchToNewlyAddedSectionOfTextarea("Hint");

		element("txt_questionTextArea").click();
		logMessage("Instructor clicked on '" + sectionTitle
				+ "' section of text area");

		switchToDefaultContent();
		String frameIdEasyXDMOnFocus = element("iframe_mainFrame")
				.getAttribute("id");

		switchToFrame(element("iframe_mainFrame"));
		String frameIdOnFocus = null;

		if (sectionTitle.equalsIgnoreCase("Hint")) {
			frameIdOnFocus = element("iframe_editorHint").getAttribute("id");
		} else if (sectionTitle.equalsIgnoreCase("Correct Feedback")) {
			frameIdOnFocus = element("iframe_editorCorrectFeedback")
					.getAttribute("id");
		} else if (sectionTitle.equalsIgnoreCase("Incorrect Feedback")) {
			frameIdOnFocus = element("iframe_editorInCorrectFeedback")
					.getAttribute("id");
		}

		switchToDefaultContent();
		boolean textAreaCollapsedStatusOnFocus = (Boolean) executeJavascript("return document.getElementById('"
				+ frameIdEasyXDMOnFocus
				+ "').contentDocument.getElementById('"
				+ frameIdOnFocus
				+ "').contentDocument.getSelection().isCollapsed");

		customAssert.customAssertEquals(textAreaCollapsedStatusOnFocus, false,
				"Assertion Failed: Newly added section did NOT COLLAPSE on "
						+ "focus (By Selection.isCollapsed Property)!!!");
		logMessage("Assertion Passed: Newly added section has FULLY collapsed "
				+ "on focus (By Selection.isCollapsed Property)!!!");

		switchToDefaultContent();

		// ***** ALTERNATIVE METHOD to check the Collapse functionality of Newly
		// Added Text Area *****//

		String sectionFrame = null;

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		if (sectionTitle.equalsIgnoreCase("Hint")) {
			sectionFrame = "iframe_editorHint";
		} else if (sectionTitle.equalsIgnoreCase("Correct Feedback")) {
			sectionFrame = "iframe_editorCorrectFeedback";
		} else if (sectionTitle.equalsIgnoreCase("Incorrect Feedback")) {
			sectionFrame = "iframe_editorInCorrectFeedback";
		}

		int heightOfTextAreaBeforeClick = element(sectionFrame).getSize()
				.getHeight();

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		int widthOfTextAreaOnFocus = element(sectionFrame).getSize().getWidth();
		int heightOfTextAreaOnFocus = element(sectionFrame).getSize()
				.getHeight();

		System.out.println("New Width of Textarea on Expanded Mode: "
				+ widthOfTextAreaOnFocus);
		System.out.println("New Height of Textarea on Expanded Mode: "
				+ heightOfTextAreaOnFocus);

		if (heightOfTextAreaOnFocus >= heightOfTextAreaBeforeClick) {
			logMessage("Assertion Passed: Newly added section is fully collapsed on focus "
					+ "inside text area (By getting th Height of Text Area)!!!");
		} else {
			Assert.fail("Assertion Failed: Newly added section is NOT fully collapsed on "
					+ "focus inside text area (By getting th Height of Text Area)!!!");
		}
		switchToDefaultContent();
	}

	/**
	 * Method which verifies that some portion of each section should be visible
	 * by default until the user chooses to fully collapse that area by clicking
	 * inside it.
	 * 
	 */
	public void verifySomePortionOfEachSectionShouldBeVisibleByDefault(
			String sectionTitle) {
		String sectionFrame = null;

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		if (sectionTitle.equalsIgnoreCase("Hint")) {
			sectionFrame = "iframe_editorHint";
		} else if (sectionTitle.equalsIgnoreCase("Correct Feedback")) {
			sectionFrame = "iframe_editorCorrectFeedback";
		} else if (sectionTitle.equalsIgnoreCase("Incorrect Feedback")) {
			sectionFrame = "iframe_editorInCorrectFeedback";
		}

		int defaultWidthOfTextArea = element(sectionFrame).getSize().getWidth();
		int defaultHeightOfTextArea = element(sectionFrame).getSize()
				.getHeight();

		System.out.println("Default Width of TextArea: "
				+ defaultWidthOfTextArea);
		System.out.println("Default Height of TextArea: "
				+ defaultHeightOfTextArea);

		if ((defaultWidthOfTextArea >= 100) & (defaultHeightOfTextArea >= 100)) {
			logMessage("Assertion Passed: Some portion of the section is visible by default!!!");
		} else {
			Assert.fail("Assertion Failed: Some portion of the section is NOT visible by default!!!");
		}

		switchToDefaultContent();
	}

	/**
	 * Method which verifies that user should be taken to newly added text in
	 * expanded mode when instructor clicks inside the newly added section
	 * 
	 * @param sectionTitle
	 *            - Title of text area section
	 * 
	 */
	public void verifyUserShouldBeTakenToNewlyAddedTextInExpandedMode(
			String sectionTitle) {
		switchToNewlyAddedSectionOfTextarea(sectionTitle);

		element("txt_questionTextArea").click();
		logMessage("Instructor clicked on '" + sectionTitle
				+ "' text area of Question Editor");

		switchToDefaultContent();
		String frameIdEasyXDM = element("iframe_mainFrame").getAttribute("id");

		switchToFrame(element("iframe_mainFrame"));
		String frameId = null;

		if (sectionTitle.equalsIgnoreCase("Hint")) {
			frameId = element("iframe_editorHint").getAttribute("id");
		} else if (sectionTitle.equalsIgnoreCase("Correct Feedback")) {
			frameId = element("iframe_editorCorrectFeedback")
					.getAttribute("id");
		} else if (sectionTitle.equalsIgnoreCase("Incorrect Feedback")) {
			frameId = element("iframe_editorInCorrectFeedback").getAttribute(
					"id");
		}

		switchToDefaultContent();
		String highlighted = (String) executeJavascript("return document.getElementById('"
				+ frameIdEasyXDM
				+ "').contentDocument.getElementById('"
				+ frameId + "').contentDocument.getSelection().toString()");

		customAssert
		.customAssertEquals(
				highlighted,
				"click here and start typing",
				"Assertion Failed: User is NOT taken to newly added text area in Expanded Mode!!!");
		logMessage("Assertion Passed: User is taken to newly added text area in Expanded Mode!!!");

		switchToDefaultContent();
	}

	/**
	 * Method which adds a New Text variable from Variable Panel
	 * 
	 * @param variableName
	 *            - Name of the Text variable
	 * @param variableTxt
	 *            - Value of Text variable
	 * 
	 */
	public void addNewTextVariableInAdvancedQuestion(String variableName,
			String variableTxt) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_addVariable").click();
		logMessage("Instructor clicked on 'Add Variable' Dropdown button");

		element("opt_htsVaribleType", "Text").click();
		logMessage("Instructor clicked on 'Text' dropdown value from the list");

		waitForElementToBeVisible("input_htsVariableName");
		element("input_htsVariableName").sendKeys(variableName);
		logMessage("Instructor entered '" + variableName + "' in input textbox");

		element("input_variableString").click();
		element("input_variableString").sendKeys(variableTxt);
		logMessage("Instructor Default Values Pool in String response Editor");

		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the form");

		customAssert
		.customAssertFalse(
				verifyHtsVariableIsDeletedFromVariablePanel(variableName),
				"HTS Variable is NOT present even after Adding a Numeric Variable from Variable Panel!!!");

		switchToDefaultContent();
	}

	/**
	 * Method which edits the name of the variable in Variable Panel
	 * 
	 * @param variableName
	 *            - Name of the variable to be edited
	 * @param newVariableName
	 *            - New name of the variable
	 * 
	 */
	public void editVariableNameInQuestionEditor(String variableName,
			String newVariableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("btn_addVariable");

		waitForElementToBeVisible("list_htsVariable", variableName);
		hover(element("list_htsVariable", variableName));

		element("icon_editHtsVariable", variableName).click();
		element("input_htsVariableName").click();
		element("input_htsVariableName").clear();

		element("input_htsVariableName").sendKeys(newVariableName);
		logMessage("Instructor keys-in necessary values for Text variable");

		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the form");

		// switchToDefaultContent(); remove due to fail in duplicate variable
		// name
	}

	public void verifyVariableNameIsDisplayedOnVariablePanel(
			String variableName, Boolean isDisplay) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("btn_addVariable");

		if (elements("list_htsVariable", variableName).size() != 0) {
			Boolean actual = element("list_htsVariable", variableName)
					.isDisplayed();
			customAssert.customAssertEquals(actual, isDisplay,
					"Assertion Failed: Variable name '" + variableName
					+ "'is NOT displayed on Variable Panel");
			logMessage("Assertion Passed: Variable is displayed '"
					+ variableName + "' on Variable Panel!!!");
		} else {
			customAssert
			.customAssertEquals(false, isDisplay,
					"Assertion Failed: No Hts variables are displayed on Variable Panel!!!");
		}

		switchToDefaultContent();
	}

	public void addNewVariableToTheQuestionInEditorMode(String variableType, String variableName,
			String numericValue) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_addVariable").click();
		logMessage("Instructor clicked on 'Add Variable' Dropdown button");

		element("opt_htsVaribleType",variableType).click();
		logMessage("Instructor clicked on '"+variableType+"' dropdown value from the list");

		element("txtbox_name").sendKeys(variableName);
		logMessage("Instructor entered '" + variableName
				+ "' in Numeric textbox");

		element("radio_list").click();
		element("txtbox_inclusion").sendKeys(numericValue);
		logMessage("Instructor keys-in necessary values for Numeric response Editor");

		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the Variable Form");

		customAssert
		.customAssertFalse(
				verifyHtsVariableIsDeletedFromVariablePanel(variableName),
				"HTS Variable is NOT present even after Adding a Numeric Variable from Variable Panel!!!");

		switchToDefaultContent();
	}

	public void clickShowVariables() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		waitForElementToBeVisible("btn_showVariables");
		element("btn_showVariables").click();

		logMessage("Instructor clicked on 'Show Variables' button");
		switchToDefaultContent();
	}

	public void verifyAlertBoxText(String alertText) {
		// Added Hard Wait: To verify the Alert window
		hardWait(1);
		String alertMessage = handleAlert();

		System.out.println("Text of alert message: " + alertMessage);
		customAssert.customAssertTrue(alertMessage.contains(alertText),
				"Assertion Failed: alert Text are not matched !!");

		// Added Hard Wait: To get the text of the alert window
		hardWait(1);
		logMessage("Assertion Passed : Alert appeared having text \""
				+ alertMessage + "\"");
	}

	public void clickOnCancelButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		waitForElementToBeVisible("btn_formCancel");
		element("btn_formCancel").click();

		switchToDefaultContent();
	}

	public void windowReturnWindow() {
		Dimension d = new Dimension(500, 500);
		driver.manage().window().setSize(d);

		hardWait(1);

		executeJavascript("window.scrollTo(0,0);");
		driver.manage().window().maximize();

		hardWait(1);
	}

	/**
	 * Method which clears the contents of Advance Question in Raw Xml mode
	 * 
	 */
	public void clearContentsOfAdvancedQuestionInRawMode() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("textarea_rawXMLEditor").clear();
		logMessage("User cleared the contents of TinyMCE");

		switchToDefaultContent();
	}

	/**
	 * Method which deletes variable reference from Advanced question
	 * 
	 * @param variableName
	 *            - Name of the variable that needs to be deleted from the
	 *            question
	 * 
	 */
	public void deleteVariableReferenceFromAdvancedQuestion(String variableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		isElementDisplayed("btn_addVariable");

		hover(element("list_htsVariable", variableName));
		logMessage("Instructor hovered on the list of HTS variables");

		element("act_deleteHtsVariable").click();
		logMessage("Instructor clicked on 'Delete HTS variable' icon for '"
				+ variableName + "' variable reference");
//		hardWait(1);
//		driver.findElement(By.xpath("//button[@class='confirm' and contains(.,'delete')")).click();
//		hardWait(1);
//		driver.findElement(By.xpath("//button[@class='confirm' and contains(.,'ok')")).click();
//		hardWait(2);
		switchToDefaultContent();
	}

	/**
	 * Verify alert window is displayed on deleting variable reference within
	 * the question having titled 'Variable Reference Warning'
	 * 
	 * @param warningMsg
	 *            - Warning message in alert window
	 * @param variableName
	 *            - Variable name due to which the alert window appeared
	 * 
	 */
	public void verifyVariableReferenceWarningAlertWindowIsDisplayed(
			String warningMsg, String variableName) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert
		.customAssertEquals(element("txt_variableRefWarning","Variable Reference Warning").getText(),
				"Variable Reference Warning",
				"[Assertion Failed]: Title of Alert window is NOT matching !!!");
		logMessage("[Assertion Passed]: 'Variable Reference Warning' heading is displayed in Alert window !!!");

		customAssert.customAssertTrue(element("txt_warningMsg").getText()
				.contains(variableName), "[Assertion Failed]: Variable Name '"
						+ variableName
						+ "' is NOT displayed on Warning message of alert window!!!");
		logMessage("[Assertion Passed]: Variable Name '" + variableName
				+ "' is DISPLAYED on the Warning message of alert window!!!");

		isElementDisplayed("btn_warningPopupOk");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'OK' button present on 'Variable Reference
	 * Warning' alert window
	 * 
	 */
	public void clickOnOkButtonPresentOnVariableReferenceWarningAlertWindow() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_warningPopupOk").click();
		logMessage("Clicked on 'OK' button present on 'Variable Reference Warning' alert window");

		switchToDefaultContent();
	}

	/**
	 * Verify HTS variable is deleted from TinyMce editor on deleting the same
	 * from Variable panel
	 * 
	 * @param status
	 *            - Status of Hts variable
	 * @param variableName
	 *            - Name of Hts variable
	 * @param noOfImg
	 *            - No. of images in TinyMce editor
	 * 
	 */
	public void verifyHtsVariableIsDeletedFromTinyMceEditor(boolean status,
			String variableName, int noOfImg) {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		logMessage("Total no. of images in TinyMce: "
				+ elements("img_totalImagesInQuestion").size());

		for (WebElement elem : elements("img_totalImagesInQuestion")) {
			if (status) {
				if ((elements("img_totalImagesInQuestion").size() - 1) == noOfImg) {
					logMessage("[Assertion Passed]: Hts variable has been DELETED successfully !!!");
				} else {
					Assert.fail("[Assertion Failed]: Hts variable could NOT be DELETED !!!");
				}
			} else {
				customAssert.customAssertEquals(
						elem.getAttribute("hts-data-id"), variableName,
						"[Assertion Failed]: Variable's Caption '"
								+ variableName
								+ "' is NOT visible under TinyMce editor");
				logMessage("[Assertion Passed]: Variable's Caption '"
						+ variableName + "' is VISIBLE under TinyMce editor");

				if (elements("img_totalImagesInQuestion").size() == noOfImg) {
					logMessage("[Assertion Passed]: Hts variable was NOT DELETED !!!");
				} else {
					Assert.fail("[Assertion Failed]: Hts variable has been DELETED !!!");
				}
			}
		}
		switchToDefaultContent();
	}

	/**
	 * Verify alert window is displayed on deleting variable reference from
	 * Variable Panel titled 'Are You Sure?'
	 * 
	 * @param warningMsg
	 *            - Warning message in alert window
	 * 
	 */
	public void verifyAreYouSureAlertWindowIsDisplayed(String warningMsg) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert
		.customAssertEquals(element("txt_variableRefWarning","Are you sure?").getText(),
				"Are you sure?",
				"[Assertion Failed]: Title of Alert window is NOT matching !!!");
		logMessage("[Assertion Passed]: 'Are you sure?' heading is DISPLAYED in Alert window !!!");

		customAssert.customAssertEquals(element("txt_warningMsg").getText(),
				warningMsg, "[Assertion Failed]: '" + warningMsg
				+ "' Warning message is NOT displayed !!!");
		logMessage("[Assertion Passed]: '" + warningMsg
				+ "' Warning message is DISPLAYED !!!");

		isElementDisplayed("btn_cancelOnAlertWindow");
		isElementDisplayed("btn_yesDeleteItOnAlertWindow");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'Yes, delete it!' button present on 'Are You
	 * Sure?' alert window
	 * 
	 */
	public void clickOnYesDeleteItButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_yesDeleteItOnAlertWindow").click();
		logMessage("Clicked on 'Yes, delete it!' button present on 'Are You Sure?' Alert window");

		switchToDefaultContent();
	}

	/**
	 * Verify alert window having titled 'Deleted!' is displayed for
	 * confirmation that non-referenced variable is deleted from Variable Panel
	 * 
	 * @param warningMsg
	 *            - Warning message in alert window
	 * 
	 */
	public void verifyDeletedAlertWindowIsDisplayed(String warningMsg) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		customAssert
		.customAssertEquals(element("txt_variableRefWarning","Deleted!").getText(),
				"Deleted!",
				"[Assertion Failed]: Title of Alert window is NOT matching !!!");
		logMessage("[Assertion Passed]: 'Deleted!' heading is DISPLAYED in Alert window !!!");

		customAssert.customAssertEquals(element("txt_warningMsg").getText(),
				warningMsg, "[Assertion Failed]: '" + warningMsg
				+ "' Warning message is NOT displayed !!!");
		logMessage("[Assertion Passed]: '" + warningMsg
				+ "' Warning message is DISPLAYED !!!");

		isElementDisplayed("btn_warningPopupOk");

		switchToDefaultContent();
	}

	/**
	 * Method which clicks on 'OK' button present on 'Deleted!' alert window
	 * 
	 */
	public void clickOnOkButtonPresentOnDeletedAlertWindow() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		element("btn_warningPopupOk").click();
		logMessage("Clicked on 'OK' button present on 'Deleted!' titled alert window");

		switchToDefaultContent();
	}

	/**
	 * Method that retrieves the height of MCE Status Bar in Question Editor
	 * 
	 */
	public int retrieveHeightMceStatusBarQuestionEditor() {
		int heightOfStatusBar = 0;

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		heightOfStatusBar = element("td_mceStatusBar").getSize().getHeight();
		logMessage("Height of Status Bar in Question Editor: "
				+ heightOfStatusBar);

		switchToDefaultContent();
		return heightOfStatusBar;
	}

	/**
	 * Method which clicks/focuses on Step 1 section of Question Editor
	 * 
	 */
	public void focusOnStep1SectionOfQuestionEditor() {
		switchToDefaultContent();
		switchToNestedFrames("iframe_mainFrame:iframe_editorQuestionFrame");

		element("txt_questionTextArea").click();
		logMessage("Instructor focuses on 'Step 1' section of Question Editor");

		switchToDefaultContent();
	}

	/**
	 * Method which verifies extra Gray Spaces have been removed from bottom of
	 * Step 1 section
	 * 
	 */
	public void verifyExtraGraySpacesHaveBeenRemovedFromBottomOfStepSection(
			int heightOfStatusBarBeforeAuthoring, int heightOfStatusBarAfterAuthoring) {
		customAssert.customAssertTrue(
				(heightOfStatusBarBeforeAuthoring > heightOfStatusBarAfterAuthoring),
				"[Assertion Failed]: Extra Gray Spaces have NOT been removed !!!");
		logMessage("[Assertion Passed]: Extra Gray Spaces have been REMOVED !!!");
	}

	public void addFormulaTyperesponseArea(){
		clickOnResponseDropDown();		
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		isElementDisplayed("lnk_FormulaResponse");
		element("lnk_FormulaResponse").click();

		switchToFrame(element("iframe_responseEditor"));
		isElementDisplayed("txt_firstAnswerBox");
		element("txt_firstAnswerBox").click();
		addFormulaTypeUsingGenie();		
		isElementDisplayed("btn_htsDialogSave");
		element("btn_htsDialogSave").click();		
	}

	private void addFormulaTypeUsingGenie() {
		String objectType = "[object MainTimeline]";
		initializingGenie(objectType);
		addMathVariable();		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();		
	}

	public void verifyAddedResponseArea()
	{
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_editorQuestionFrame"));

		isElementDisplayed("img_responseInTinyMce");
		Actions act=new Actions(driver);
		act.doubleClick(element("img_responseInTinyMce")).doubleClick().build().perform();
		hardWait(2);
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		switchToFrame(element("iframe_responseEditor"));		
		waitForElementToBeVisible("act_editRow");
		element("act_editRow").click();	
		isElementDisplayed("lnk_editFirstResponse");
		element("lnk_editFirstResponse").click();
		hardWait(2);
		verifyAddedMathVariable();
		isElementDisplayed("btn_htsDialogSave");
		element("btn_htsDialogSave").click();
	}

	public void renameVariableInEditorMode(String variableName)
	{
		switchToDefaultContent();
		String id=element("iframe_mainframe").getAttribute("id");
		hardWait(4);
		executeJavascript("document.getElementById('"+id+"').contentDocument.getElementsByClassName(\"hts-"+variableName.toLowerCase()+"-variable-dialog hts-side-dialog\")[0].style=\"display:block\";");
		switchToFrame(element("iframe_mainFrame"));
		String varname_new=variableName+"1";
		if(variableName.equals("Numeric"))
		{
			scroll(element("txtbox_name"));
			element("txtbox_name").clear();
			element("txtbox_name").sendKeys(varname_new);
			logMessage("Instructor entered '" + varname_new + "' in Numeric textbox");
		}else if(variableName.equals("Text"))
		{
			scroll(element("txtBox_nameForTxtVariable"));
			element("txtBox_nameForTxtVariable").clear();
			element("txtBox_nameForTxtVariable").sendKeys(varname_new);
			logMessage("Instructor entered '" + varname_new + "' in Text Field");
		}
		element("btn_formSave").click();
		logMessage("Instructor clicked on 'Save' button present on the form");

		customAssert.customAssertFalse(
				_verifyHtsVariableIsDeletedFromQuestionSidePanel(varname_new),
				"HTS Variable is NOT present even after Adding a "+varname_new+" from Variable Panel!!!");

		switchToDefaultContent();
	}

	/**
	 * Verifying whether the HTS variable is deleted from Question Side Panel
	 * after deleting the variable in Editor mode
	 * 
	 */
	private boolean _verifyHtsVariableIsDeletedFromQuestionSidePanel(String variable) {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		// Added Hard Wait for the element to load in Variable Panel
		hardWait(1);

		List<WebElement> allVariableNames = elements("list_allVariables");
		for(WebElement variableName: allVariableNames){
			if(variableName.getText().equalsIgnoreCase(variable))
				return false;
		}
		return true;
	}

	/**
	 * Method which verifies the working of auto expand functionality
	 */
	public void verifyAutoExpandFunctionality()
	{
		switchToDefaultContent();
		switchToFrame(element("iframe_mainframe"));
		Point coord=element("btn_resize").getLocation();
		logMessage(coord.toString());
		switchToFrame(element("iframe_editorQuestionFrame"));
		//WebElement txtarea= driver.findElement(By.xpath(".//*[@id='tinymce']/p"));
		//txtarea.click();
		element("txt_htsQuestionText").click();
		switchToDefaultContent();
		switchToFrame(element("iframe_mainframe"));
		Point coord_new=element("btn_resize").getLocation();
		logMessage(coord_new.toString());
		if(coord_new.y+80>coord.y){logMessage("Auto Expand Functionality is working properly.");}
		else customAssert.customAssertFalse(true, "Auto Expand Functionality not working");
		switchToFrame(element("iframe_editorHint"));
		element("txt_htsQuestionText").click();
		switchToDefaultContent();
	}

	/**
	 * method which clicks on revert to saved button
	 */
	public void clickOnRevertToSavedButton()
	{
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));
		waitForElementToBeVisible("btn_revert");
		element("btn_revert").click();
		hardWait(5);
		switchToDefaultContent();
	}

	/**
	 * Method which adds more spaces to area initially available for Step 1
	 * section by expanding the same vertically using Status bar present at the
	 * bottom of editor
	 * 
	 */
	public void expandStep1SectionVerticallyToShowVariablesButton() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		dragAndDropElement(element("lnk_mceResizeEditor"),
				element("btn_showVariables"));
		logMessage("Expanded Step 1 section to 'Show Variables' button");

		switchToDefaultContent();
	}

	/**
	 * Method that retrieves the height of Step-1 section in Question Editor
	 * 
	 */
	public int retrieveHeightStep1SectionOfQuestionEditor() {
		int heightOfStep1Section = 0;

		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		heightOfStep1Section = element("iframe_editorQuestionFrame").getSize()
				.getHeight();
		logMessage("Height of Step-1 section of Question Editor: "
				+ heightOfStep1Section);

		switchToDefaultContent();
		return heightOfStep1Section;
	}

	/**
	 * Method which verifies Step 1 has taken up the entire vertical space of
	 * editor window when the user initially begins editing/authoring a
	 * question.
	 * 
	 */
	public void verifyStep1SectionHasTakenUpEntireVerticalSpaceOfEditorWindowOnEditingQuestion(
			int heightOfStep1SectionBeforeEditing, int heightOfStep1SectionAfterEditing) {
		customAssert.customAssertTrue(
				(heightOfStep1SectionAfterEditing >= heightOfStep1SectionBeforeEditing),
				"[Assertion Failed]: Step 1 section has NOT TAKEN up the entire vertical "
						+ "space of Editor window on Editing/Authoring question !!!");
		logMessage("[Assertion Passed]: Step 1 section has TAKEN UP the entire vertical space of "
				+ "Editor window on Editing/Authoring question !!!");
	}

	/**
	 * Method which verifies Auto Sizing of Step1 Section has stopped after
	 * entering text in the area
	 * 
	 */
	public void verifyAutoSizingOfStep1SectionHasStoppedAfterEnteringTextInTheArea(
			int heightOfStep1SectionBeforeEditing,
			int heightOfStep1SectionAfterEditing) {
		customAssert
		.customAssertTrue(
				(heightOfStep1SectionAfterEditing == heightOfStep1SectionBeforeEditing),
				"[Assertion Failed]: Auto-Sizing of Step1 Section Has NOT STOPPED after "
						+ "entering text in the area !!!");
		logMessage("[Assertion Passed]: Auto-Sizing of Step1 Section Has STOPPED after "
				+ "entering text in the area !!!");
	}

	/**
	 * Method which re-sized Step 1 section vertically possibly up to Raw XML
	 * button using Status bar
	 * 
	 */
	public void reSizeStep1SectionVerticallyToRawXMLButtonUsingStatusBar() {
		switchToDefaultContent();
		switchToFrame(element("iframe_mainFrame"));

		dragAndDropElement(element("lnk_mceResizeEditor"),
				element("btn_rawXML"));
		logMessage("Re-Sized Step 1 section vertically possibly up to 'Raw XML' button using Status bar");

		switchToDefaultContent();
	}

}
