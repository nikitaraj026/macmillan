package com.qait.AQE.keywords;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;

public class EnrollCoursePageAction extends GetPage{

	public EnrollCoursePageAction(WebDriver driver) {
		super(driver, "EnrollCoursePage");
	}
	
	/**
	 * Method which student clicks on 'Join Course' created by the Instructor
	 * 
	 * @param courseName - Name of the Course created by the Instructor
	 * 
	 */
	public void confirmAndJoinCourse(String courseName){
		switchToDefaultContent();
		switchToFrame(element("frame_widgetFrame"));
		
		element("btn_joinCourse").click();
		logMessage("Student clicked on 'Join Course' button");
		waitForLoaderToAppear();
		switchToDefaultContent();
	}
	
	/**
	 * Method which verifies 'Congratulations' message after the student Joins the course created
	 * by the Instructor
	 * 
	 */
	public void verifyCongratulationMessage(){
		switchToDefaultContent();
		switchToFrame(element("frame_widgetFrame"));
		
        Assert.assertEquals(element("label_congratsMsg").getText(),
        		"Congratulations!",
                "Assertion Failed: Log-In Page button text is not correct.");
        logMessage("Assertion Passed: User is on Enroll Course Page, Verified Title "
        									+ "Text of Enroll Course Page: Congratulations!");
		
        switchToDefaultContent();
        executeJavascript("document.getElementsByTagName('iframe')[0].contentDocument."
								+ "getElementsByClassName('button radius course-continue')[0].click()");
		logMessage("Student clicked on 'Continue' button on Enroll Course Home Page");
		
		switchToDefaultContent();
	}
	
}