package com.qait.AQE.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class IndexPageActions extends GetPage {

	public IndexPageActions(WebDriver driver) {
		super(driver, "IndexPage");
	}

	/**
	 * Method which verifies that user has logged out successfully
	 * 
	 * @return
	 * 
	 */
	public boolean verifyUserHasLoggedOut() {
		waitForElementToBeVisible("btn_Login_Instructor");
		return isElementDisplayed("btn_Login_Instructor");
	}

	public void navigateToUrl(String url) {
		logMessage("Launching the URL:- " + url);
		driver.navigate().to(url);
	}
	
    /**
     * Verify whether the user has logout of the application successfully
     *
     * @param indexPageButtonText - Text of button on Index page
     * 
     */
    public void verifyUserHasLogoutSuccessfully(String indexPageButtonText) {
    	waitForLoaderToDisappear();
    	isElementDisplayed("btn_SignIn");
        customAssert.customAssertEquals(element("btn_SignIn").getText(),
        		indexPageButtonText,
                "Assertion Failed: Log-In Page button text is not correct.");
        logMessage("Assertion Passed: User is on Log-In Page, Verified 'Sign In' Button's visibility and Button has text: "
                + indexPageButtonText);
        
        wait.waitForLoaderToDisappear();
    }
    
}
