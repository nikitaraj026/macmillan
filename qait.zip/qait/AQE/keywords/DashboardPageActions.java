package com.qait.AQE.keywords;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;





//import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertEquals;

public class DashboardPageActions extends GetPage {

	int courseCount;

	public DashboardPageActions(WebDriver driver) {
		super(driver, "DashboardPage");
	}

	public void verifyDashboardPage() {
		isElementDisplayed("txt_myCoursesHeader");
	}

	public void clickCreateCourseLink(String productName, String author) {
		wait.waitForProgressBarToDisappear();
		this.courseCount = elements("link_existingCourses").size();
		
		// Added Hard wait to bypass 'ElementIsNotVisible' exception on 'Create' button
		hardWait(2);
		
		element("link_createCourse").click();
		logMessage("Instructor clicked on 'Create Course' link");
		
		_clickAndVerifyCorrectProduct(productName, author);
	}
	
	private void _clickAndVerifyCorrectProduct(String productName, String author) {
		wait.waitForElementToBeVisible(element("div_confirmProductMessage"));
		/*Assert.assertEquals(element("div_confirmProductMessage").getText()
				.replaceAll("[^\\x00-\\x7F]", "'"), productName + ", " + author);*/
		
		logMessage("Assertion Passed : Product in which course is being created is correct");
		element("btn_NextConfirmCourse").click();
		logMessage("Clicked on 'Next' button to confirm the addition of new course under the correct product");
	}

	public void verifyNewCourseIsCreated(String courseName) {
		isElementDisplayed("link_newCourse", courseName);
		int currentCourseCount = elements("link_existingCourses").size();

		Assert.assertTrue(currentCourseCount > this.courseCount,
				"Assertion FAILED: Starting count of courses: "
						+ this.courseCount + " is <= current count of courses: "
						+ currentCourseCount);	
		
		logMessage("Assertion Passed: Starting course count:- "
				+ this.courseCount + " is less than current course count: "
				+ currentCourseCount);
		logMessage("Assertion Passed: New Course by the Name: '" + courseName
				+ "' has been created");
	}

	public String getCourseUrl(String courseName) {
		String newcourseurl = element("txt_newCourseUrl", courseName).getText();
		logMessage("The Course URL for the new course is:- " + newcourseurl);
		return newcourseurl;
	}

	public void activateCourseFromDashBoard(String courseName) {
		waitAndScrollToElement("link_activateCourse",courseName);
		if (element("link_activateCourse", courseName).getText()
				.equalsIgnoreCase("Deactivate")) {
			logMessage("Course Activation: The course: '" + courseName
					+ "' is already active");
			return;
		}
		
		// Added Hard wait to bypass 'ElementIsNotVisible' exception
		hardWait(2);
		
		element("link_activateCourse", courseName).click();
        logMessage("'Activate' link is clicked which is present besides the Newly created course '"
				+ courseName + "'");
        
		element("button_courseOptionDialog", "Activate").click();
		logMessage("'Activate' button is clicked present on the Dialog box");
		
		element("button_courseOptionDialog", "Done").click();
		logMessage("'Done' button is clicked");
	}
	
	/**
	 * Activates a provided course name 
	 */
	public void activateCourse(String courseName) {
		clickCourseActivateLink(courseName);
		//verifyActivateCourseWidgetDisplayed();
		clickActivateCourseActivateButton();
		clickActivateCourseDoneButton();
	}
	
	/**
	 * Click Course Activate Link
	 */
	public void clickCourseActivateLink(String courseName) {
		waitScrollAndClick("link_activateCourse", courseName);
		logMessage("Clicked Course '" + courseName + "' Activate Link");
	}
	
	/**
	 * Click Activate Course Widget 'Activate' Button
	 */
	public void clickActivateCourseActivateButton() {
		waitForElementToBeVisible("btn_activateActivateCourse");
		element("btn_activateActivateCourse").click();
		logMessage("Clicked Activate Course 'Activate' Button");
		hardWait(1);
	}
	
	/**
	 * Click Activate Course Widget 'Done' Button
	 */
	public void clickActivateCourseDoneButton() {
		waitForLoaderToDisappear();
		hardWait(2);
		waitForElementToBeVisible("button_courseOptionDialog", "Done");
		element("button_courseOptionDialog", "Done").click();
		waitForElementToDisappear("button_courseOptionDialog", "Done");
		logMessage("Clicked Activate Course 'Done' Button");
	}

	
	public void verifyCourseIsActivated(String courseName) {
		isElementDisplayed("link_deactivateCourse", courseName);

		assertEquals(element("link_deactivateCourse", courseName).getText(),
				" Deactivate", "Assertion Failed: course with course name '"
						+ courseName + "' can still be activated");
		
		logMessage("Assertion Passed: The Course with Course Name: '"
				+ courseName + "' is active");
	}

	
	public void instructorOpensCourse(String courseName) {
		element("link_newCourse", courseName).click();
		logMessage("Instructor clicked on '" + courseName
				+ "' course which is newly created");
		wait.waitForLoaderToDisappear();
	}
	
	
	public void deleteCourse(String courseName){
		clickCourseDeleteLink(courseName);
		clickDeleteCourseDeleteButton();
	}
	
	/**
	 * Click Course Delete Link
	 */
	public void clickCourseDeleteLink(String courseName) {
		waitScrollAndClick("link_courseDelete", courseName);
		logMessage("Clicked Course '" + courseName + "' Delete Link");
	}
	
	/**
	 * Click Delete Course Widget 'Delete' Button
	 */
	public void clickDeleteCourseDeleteButton() {
		element("btn_deleteDeleteCourse").click();
		logMessage("Clicked Delete Course 'Delete' Button");
	}
	
	/**
	 * This keyword deletes all but one courses
	 *  from the Dash board Page.
	 */
	public void bulkDeleteCourses() {
		int i = elements("list_courseName").size();
		logMessage("Deleting " + i + " Courses");
		logMessage(" ");
		for (WebElement course : elements("list_courseName")) {
			if (--i < 2) {
				break;
			}
			logMessage(i + ". Course Named " + course.getText()
					+ " is deleted!!!");
			try {
				deleteCourse(course.getText());
			}catch(Exception e){
				continue;
			}
		}
	}
	
	public void logOut() {
		String logoutUrl = getCurrentURL().split("/Dashboard#")[0]
				+ "/Account/Logout";
		driver.navigate().to(logoutUrl);
		handleAlert(); // for content toc and navigation
		wait.waitForPageTitleToBeExact("Index");
		driver.manage().deleteAllCookies();
		logMessage("User Logged Out");
	}
}

