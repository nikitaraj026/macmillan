/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.AQE.keywords;

import static org.testng.Assert.assertEquals;

import com.qait.automation.getpageobjects.GetPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.sikuli.script.FindFailed;
//import org.sikuli.script.Screen;
import org.testng.Assert;

public class AqeStudentPreviewPageActions extends GetPage {

    public AqeStudentPreviewPageActions(WebDriver driver) {
        super(driver, "AqeStudentPreviewPage");
    }
    
    /**
     * This method verifies whether the Instructor is able to view the 'Preview' frame 
     * after clicking on 'Preview' button
     * 
     */
    public void verifyInstructorCanSeeStudentPreviewFrame(String previewFrameTitle) {
		isElementDisplayed("txt_previewFrameTitle");
		
		assertEquals(element("txt_previewFrameTitle").getText(),
				previewFrameTitle,
				"Assertion Failed: Preview frame title is not correct.");
		logMessage("Assertion Passed: User is on FNE page, Verified Preview frame title visibility and Title text to be: "
				+ previewFrameTitle);
		
		assert element("btn_regenrateVariables").isDisplayed();
		assert element("btn_edit").isDisplayed();
	}
    
    
    /**
     * This method goes through all the lines of a paragraph of a text and make sure that current 
     * element is more than 1pixel away from last element on Question Editor Page
     * 
     */
    public void validateLayoutOfVariousQuestionComponents() {
    	switchToNestedFrames("frame_contentWrapper:frame_contentBody:frame_contentContainer");
    	
        int i = 0;
        boolean overlap = true;
        WebElement lastElement = elements("txt_htsQuestionContents").get(0);
        for (WebElement element : elements("txt_htsQuestionContents")) {
            if (i > 0) {
                if (lastElement.getLocation().getY() != element.getLocation().getY()) {
                    logMessage("Line " + i + "'s Location Y-Coordinates: " + lastElement.getLocation().getY());
                    logMessage("Line " + i + "'s Height(in units): " + lastElement.getSize().getHeight());
                    logMessage("Line " + i + "'s Margin(in px): " + lastElement.getCssValue("margin-bottom"));

                    int distance = element.getLocation().getY()
                            + Integer.parseInt(element.getCssValue("margin-bottom").replace("px", ""))
                            - (lastElement.getLocation().getY() + lastElement.getSize().getHeight()
                            + Integer.parseInt(lastElement.getCssValue("margin-bottom").replace("px", "")));
                    overlap = overlap && (distance > 1);
                    logMessage("Line " + i + "'s Vertical distance is " + distance + " px");
                }
                logMessage(" ");
                lastElement = element;
            }
            i++;
        }
        Assert.assertTrue(overlap, "Assertion Failuer: There is overlap between two consecutive elements");
        logMessage("Assertion Passes: There is no over lap between the question componenets");
    }
	
    
    /**
     * This method goes through all the lines of a paragraph of a text and make sure that current 
     * element is more than 1pixel away from last element on FnE Page
     * 
     */
    public void validateLayoutOfVariousQuestionSegment() {
    	switchToDefaultContent();
    	switchToFrame(element("frame_contentWrapperFnE"));
    	
        int i = 0;
        boolean overlap = true;
        WebElement lastElement = elements("txt_questionContents").get(0);
        for (WebElement element : elements("txt_questionContents")) {
            if (i > 0) {
                if (lastElement.getLocation().getY() != element.getLocation().getY()) {
                    logMessage("Line " + i + "'s Location Y-Coordinates: " + lastElement.getLocation().getY());
                    logMessage("Line " + i + "'s Height(in units): " + lastElement.getSize().getHeight());
                    logMessage("Line " + i + "'s Margin(in px): " + lastElement.getCssValue("margin-bottom"));

                    int distance = element.getLocation().getY()
                            + Integer.parseInt(element.getCssValue("margin-bottom").replace("px", ""))
                            - (lastElement.getLocation().getY() + lastElement.getSize().getHeight()
                            + Integer.parseInt(lastElement.getCssValue("margin-bottom").replace("px", "")));
                    overlap = overlap && (distance > 1);
                    logMessage("Line " + i + "'s Vertical distance is " + distance + " px");
                }
                logMessage(" ");
                lastElement = element;
            }
            i++;
        }
        switchToDefaultContent();
        
        Assert.assertTrue(overlap, "Assertion Failure: There is overlap between two consecutive elements");
        logMessage("Assertion Passed: There is NO over lap between the Question Text!!!");
    }
    
	/*public boolean validateLayoutOfQuestionComponent(String imgLoc){
		//Switches to the Frame where the contents of the Questions are located
		switchToFrame(element("frame_contentWrapper"));
		
		//Location of the image
		//imgLoc = "D:\\Automation\\AQE\\PXSelenium-AQE-AA_Branch\\src\\test\\resources\\AA-Artifacts\\questions-images\\"+imgLoc;
		imgLoc = "./src/test//resources/AA-Artifacts/questions-images/" + imgLoc;
		logMessage("Image Location:-" + imgLoc);
		
		//Create an instance of Screen object    
		Screen screen = new Screen();
		
		//Wait for the Question contents to be loaded completely
		wait.waitForElementToBeVisible(element("txt_questionContents"));
		
		try {
			//Finds the image in the question contents
			screen.find(imgLoc);
			return false;
		} catch (FindFailed e) {
			// TODO Auto-generated catch block
			return true;
		}	
	}*/
    
}
