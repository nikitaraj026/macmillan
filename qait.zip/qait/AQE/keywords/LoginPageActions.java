package com.qait.AQE.keywords;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qait.automation.getpageobjects.GetPage;

public class LoginPageActions extends GetPage {

	public LoginPageActions(WebDriver driver) {
		super(driver, "LoginPage");
	}

	/**
	 * This method enters User Name and Password in the respective fields
	 * and Click on login button on the activation page
	 * 
	 * @param userName - User Name provided from the respective yml according to the environment
	 * @param password - Password provided from the respective yml according to the environment
	 * 
	 */
	
	public void loginToTheApplication(String userName, String password) {
		isElementDisplayed("inp_Username");
		element("inp_Username").click();
	//	element("inp_Username").clear();
	
//		if (element("inp_Username").getText().equalsIgnoreCase("")) {
//			logMessage("Username field is cleared successfully!!!");
//		} else {
//			customAssert.Assert.fail("Assertion Failed: 'Username' field is NOT CLEARED successully!!!");
//		}
		element("inp_Username").sendKeys(userName);
		element("inp_Password").click();
		element("inp_Password").clear();
		element("inp_Password").sendKeys(password);
		
		element("btn_SignIn").click();
		logMessage("User entered UserName:- '" + userName + "' and Password:- '" + password + "' on the Login Page");
	}
	
	/**
	 * Verifies User is on Login Page
	 */
	public void verifyUserIsOnLoginPage() {
//		waitForLoaderToDisappear();
		clickElementIfVisible("btn_closeToastMessage");
//		if (elements("link_showDetails").size() == 0) {
//			element("link_hideDetails").click();
//		}
		isElementDisplayed("txt_signIn");
	//	closeSystemCheck();
	}
	
	/**
	 * Login using email and password
	 */
	public void login(String email, String password) {
//		waitForLoaderToDisappear();
//		if (elements("link_showDetails").size() == 0) {
//			element("link_hideDetails").click();
//		}
		fillSignInEmail(email);
		fillSignInPassword(password);
		clickSignIn();
	}
	
	/**
	 * Fill Email in Sign In Section
	 */
	public void fillSignInEmail(String email) {
		fillText("txtinput_email", email);
	}
	
	/**
	 * Fill Password in Sign In Section
	 */
	public void fillSignInPassword(String password) {
		fillText("txtinput_password", password);
	}
	
	/**
	 * Click Sign In Button
	 */
	public void clickSignIn() {
		element("btn_signIn").click();
		
		logMessage("Clicked 'Sign in' Button");
	}
}
