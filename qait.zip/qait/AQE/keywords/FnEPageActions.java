/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.qait.AQE.keywords;

import static com.qait.automation.utils.YamlReader.getData;
import static org.testng.Assert.assertEquals;



import java.awt.AWTException;
//import java.awt.AWTException;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomFunctions;
//import com.qait.automation.utils.Keyboard;

import com.qait.automation.utils.Keyboard;

import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.adobe.genie.executor.Genie;
import com.adobe.genie.executor.LogConfig;
import com.adobe.genie.executor.components.GenieButton;
import com.adobe.genie.executor.exceptions.StepFailedException;
import com.adobe.genie.executor.exceptions.StepTimedOutException;
import com.adobe.genie.executor.uiEvents.UIKeyBoard;
import com.adobe.genie.genieCom.SWFApp;

public class FnEPageActions extends GetPage {

	protected SWFApp app1;
	static int count = 0;
	String answer = null, solution = null;

	/**
	 * Instantiates a new fne page actions.
	 *
	 * @param driver the driver
	 * 
	 */
	public FnEPageActions(WebDriver driver) {
		super(driver, "FnEPage");
	}

	/**
	 * Fill and submit basic assignment info.
	 *
	 * @param assignmentName the assignment name
	 * @param subTitle the sub title
	 * @param directions the directions
	 * 
	 */
	public void fillAndSubmitBasicAssignmentInfo(String assignmentName, String subTitle, String directions) {
		element("inp_assignmentName").clear();
		logMessage("Instructor cleared the default 'Title' of Quiz");

		element("inp_assignmentName").sendKeys(assignmentName);
		logMessage("Instructor entered '" + assignmentName
				+ "' as the New title of Quiz");

		element("button_save").click();
		logMessage("User clicked on 'Save' button");

		// NOTE: Added hard Wait to avoid the Pop-Up having 'Save', 'Don't Save' and 'Cancel' buttons
		hardWait(1);
		
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}

	/**
	 * Fill and submit basic assignment info.
	 *
	 * @param assignmentName the assignment name
	 * 
	 */
	public void fillAndSubmitBasicAssignmentInfo(String assignmentName) {   	
		fillAndSubmitBasicAssignmentInfo(assignmentName, "", "");
	}

	
	/**
	 * Selecting which menu link to click on FnE Page.
	 *
	 * @param contextMenuName name of the menu - basic info, assignment, settings or questions
	 * 
	 */
	public void openFnE_Menu(String contextMenuName) {
		if (contextMenuName.equalsIgnoreCase("Basic Info")) {
			element("link_basicInfo").click();
		} else if (contextMenuName.equalsIgnoreCase("Assignment")) {
			element("link_assignment").click();
		} else if (contextMenuName.equalsIgnoreCase("Settings")) {
			element("link_settings").click();
		} else if (contextMenuName.equalsIgnoreCase("Questions")) {
			element("link_questions").click();
		}
		logMessage("User clicked on '" + contextMenuName + "' Tab");

		// NOTE: Added hard Wait to avoid the Pop-Up having 'Save', 'Don't Save' and 'Cancel' buttons
		hardWait(1);
		
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}


	/**
	 * Method which clicks on 'Save' button on the unwanted pop-up.
	 */
	public void clickOnSaveButtonOnUnwantedPopUp(){
		try {
			for (int i = 0; i < 1; i++) {
				if (element("btn_popSave").isDisplayed()) {
					logMessage("An unwanted popup/dialogue box opens which has Don't Save, Save And Cancel buttons");
					element("btn_popSave").click();
					logMessage("User clicked on 'Save' button for " + (i + 1)
							+ " time");
					hardWait(1);
				} else {
					logMessage("Unwanted pop-up have been removed from the Page!!!");
				}
			}
		} catch (Exception e) {
			logMessage("An unwanted popup/dialogue box DOES NOT APPEAR which has Don't Save, Save And Cancel buttons");
		}
	}


	/**
	 * Method which closes Notification Toast Message.
	 */
	public void closeNotificationMessage(){
		try {
			for (int i = 0; i < 1; i++) {
				if(element("btn_toastClose").isDisplayed()){
					hoverClick(element("btn_toastClose"));
					logMessage("Notification Toast message clicked " + (i+1) + " time");
					hardWait(1);
				}else{
					logMessage("Closed all Notification Toast messages present on FnE page");
				}
			}
		} catch (NoSuchElementException e) {
			logMessage("Notification Toast Message did NOT appear OR have been closed!!!");
		}
	}


	/**
	 * Clicks on the "Create" button & selects a Question of that type which is passed as a parameter.
	 *
	 * @param questionType the question type
	 * 
	 */
	public void createNewQuestionType(String questionType) {
		waitForElementToBeVisible("button_newQuestionMenu");
		waitForElementToBeVisible("txtbox_Search");
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		element("button_newQuestionMenu").click();
		logMessage("Instructor clicked on 'Create' dropdown");

		element("link_questionTypeContext", questionType).click();
		logMessage("Instructor clicked on '" + questionType + "' type from the dropdown");

		waitForLoaderToDisappear();
	}


	/**
	 * Method which hovers on "Expand" link & Clicks on "Preview" link
	 * 
	 */
	public void clickPreviewQuestion() {
		hover(element("btn_expand"));
		logMessage("User hovered on 'Expand' link present below the question");
		
		executeJavascript("document.getElementsByClassName('preview-current-question')[0].click()");
		logMessage("User clicked on 'Preview' link which is displayed after hovering the 'Expand' link");
	}
	

	/**
	 * Method which hovers on "Expand" link & then clicks on "Edit" link to navigate directly 
	 * to Question Editor page.
	 * 
	 */
	public void clickEditQuestion() {
		hover(element("btn_expand"));
		logMessage("User hovered on 'Expand' link present below the question");

		// Note: Using js to remove screens dependency which is due to hover functionality
		// element("lnk_editQuestion").click();
		executeJavascript("document.getElementsByClassName('edit-current-question hidden')[0].click()");
		logMessage("User clicked on 'Edit' link which is displayed after hovering on 'Expand' link");
	}


	/**
	 * Method which adds a specific question to the Quiz.
	 * 
	 */
	public void addQuestionToQuiz() {
		element("txt_courseChapter").click();
		logMessage("Instructor clicked on 'Chapter 6' link");
		waitForLoaderToDisappear();

		element("txt_chapterName").click();
		logMessage("Instructor clicked on 'Algorithmic Questions' link");
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		element("chk_chapterQuestion").click();
		logMessage("Instructor clicked on '(AQ) Chapter 6, Exercise 131' Question Checkbox");
		element("btn_addQuestionWrapper").click();
		waitForLoaderToDisappear();
	}


	/**
	 * Clicks on "Assignment" tab on FnE page & assigns the created Quiz to students
	 * 
	 */
	public void assignAssignmentToStudents() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		element("link_assignment").click();
		logMessage("Clicked on 'Assignment' Tab");
		waitForElementToBeVisible("btn_goNext");
		
		element("btn_goNext").click();
		waitForElementToBeVisible("link_Date");
		element("link_Date").click();

		element("txtbox_points").sendKeys("10");
		waitForElementToBeVisible("btn_assign");
		
		element("btn_assign").click();
		logMessage("Newly Created Quiz is assigned to the Students");

		// NOTE: Added hard Wait to avoid the Pop-Up having 'Save', 'Don't Save' and 'Cancel' buttons
		hardWait(1);
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Verifies whether student has landed to the FnE page.
	 *
	 * @param fnePageTitle the fne page title
	 * 
	 */
	public void verifyStudentNavigatesToFnEPage(String fnePageTitle) {
		isElementDisplayed("txt_fnePageAssignmentName");

		assertEquals(element("txt_fnePageAssignmentName").getText(), fnePageTitle,
				"Assertion Failed: FNE frame title is not correct.");
		logMessage("Assertion Passed: User is on FNE page, Verified FNE frame title "
				+ "visibility and Title text to be: " + fnePageTitle);
	}


	/**
	 * Verifies whether Junk characters are present in question contents.
	 *
	 * @return boolean
	 * 
	 */
	private boolean _verifyQuestionContents() {
		String invalidText = "&";
		String questionText = null;
		boolean flag = false;
		for (int i = 0; i < 4; i++) {
			questionText = element("txt_questionContents",
					String.valueOf(i + 1)).getText().trim();
			if (!questionText.contains(invalidText)) {
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		return flag;
	}


	/**
	 * Method where student attempts the assigned Quiz for AA-215 Ticket
	 * 
	 */
	public void studentAttemptsQuiz() {
		switchToDefaultContent();
		
		element("btn_startQuiz").click();
		logMessage("User click on 'Start the Quiz' button");

		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");
		element("chkbox_answer").click();
		logMessage("User clicked on a checkbox of question!!!");
		
		customAssert.customAssertTrue(_verifyQuestionContents(), "JUNK CHARACTERS FOUND!!!");

		element("btn_Submit").click();
		logMessage("User clicked on 'Submit' button");

		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button present on the Dialog-box");
		switchToDefaultContent();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}


	/**
	 * Method which student attempts the Quiz without answering any question mentioned in the Quiz
	 * 
	 */
	public void studentAttemptsQuizWithoutAnsweringAnyQuestion() {
		element("btn_startQuiz").click();
		logMessage("User click on 'Start the Quiz' button");

		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame"); 
		
		element("btn_Submit").click();
		logMessage("User clicked on 'Submit' button");

		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button present on the Dialog-box");

		switchToDefaultContent();
	}

	/**
	 *  Navigates back to Course page from 'Student View' state by clicking 
	 *  on 'Done' button.
	 * 
	 */
	public void moveBackFromStudentViewToCourseHomePage() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		
		element("btn_done").click();
		logMessage("User clicked on 'Done' button present in Quiz Page");
		
		handleAlert();
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void clickOnDoneBtnOnHomework() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frame_contentFrame:frame_questionFrame");
		
		element("btn_doneOnHomeWork").click();
		logMessage("User clicked on 'Done' button present in Quiz Page");
		
		handleAlert();
		switchToDefaultContent();
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

	}

	/**
	 * Searches & adds a specific question to Quiz in 'BPS6E' book for AA-147 Ticket
	 * 
	 */
	public void addQuestionToQuizForBPS6EBook() {
		element("txtbox_Search").sendKeys("burn"); 
		logMessage("Instructor entered 'burn' on 'Search Questions' input box");

		element("txtbox_Search").sendKeys(Keys.RETURN);

		element("chkbox_questionSearchAA_147").click();
		logMessage("Instructor selected the searched question");

		element("btn_addQuestionWrapper").click();
		logMessage("Instructor clicked on 'Add' button");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	/**
	 * Method where Instructor searches for question via the Heading of the Question
	 *
	 * @param question the question
	 * 
	 */
	public void searchQuestion(String question){
		element("txtbox_Search").sendKeys(question); 
		element("txtbox_Search").sendKeys(Keys.RETURN);
		logMessage("Instructor entered '" + question + "'in the Search box");
	}


	/**
	 * Clicks on "Preview" button on "Questions" tab
	 * 
	 */
	public void clickPreviewLink() {
		element("link_preview").click();
		logMessage("Instructor clicked on 'Preview' link");
		waitForLoaderToDisappear();
	}


	/**
	 * Searches a particular question & previews it for 'Quantlit' book.
	 *
	 * @param searchTerm - search term to locate a particular Question for AA-146 ticket 
	 *  				   on 'Quantlit' book
	 */
	public void previewQuestionForQuantlitBook(String searchTerm) {
		element("txtbox_Search").sendKeys(searchTerm);
		logMessage("Instructor entered '" + searchTerm + "' in Search Text Box");

		element("txtbox_Search").sendKeys(Keys.RETURN);
		
		waitForElementToBeVisible("lnk_showMoreQuestions");
		element("lnk_showMoreQuestions").click();
		logMessage("Instructor clicked on 'Show more Questions' link");
		
		element("chkbox_questionSearchAA_146").click();
		logMessage("Instructor clicked on checkbox of the searched question");
		
		element("link_preview").click();
		logMessage("Instructor clicked on 'Preview' link");
	}


	/**
	 * Gets the pixel(width) of all the images present in Question contents & verifies whether the image is greater than
	 * 10pixel and if not then the image is blank.
	 *
	 * @return true, if successful
	 * 
	 */
	private boolean _verifyImageIsBlank() {
		boolean flag = false;
		
		switchToDefaultContent();
		switchToFrame(element("frame_previewFrame"));
		
		logMessage("No. of images in question: " + elements("list_imagesQuestion").size());
		for (WebElement images : elements("list_imagesQuestion")) {
			logMessage("Value of width attribute: "
					+ images.getAttribute("width") + "(in px)");
			if (Integer.parseInt(images.getAttribute("width")) > 5) {
				flag = true;
			} else {
				return flag;
			}
		}
		switchToDefaultContent();
		
		return flag;
	}


	/**
	 * Validates the image content whether it is broken or not & asserts the condition
	 * 
	 */
	public void validateImageContentOfQuestion() {
		customAssert.customAssertTrue(_verifyImageIsBlank(),
				"Assertion Failed: Blank image is present on the Preview modal for the Question!!!");
	}


	/**
	 * Method which starts up Genie to connect it with Application
	 *
	 * @param swfApp - Name of the swf file which requires to be connected
	 * 
	 */
	public void initializingGenie(String swfApp) {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		}
		LogConfig l = new LogConfig();
		Genie g = null;
		try {
			Genie.EXIT_ON_FAILURE = true;
			g = Genie.init(l);
			app1 = g.connectToApp(swfApp);
			// g.isAppAvailable("App is NOT available");
			// g.waitForAppToConnect("Unable to connect", 20);
			logMessage("Genie is Initialised & Connected to '" + swfApp + "' File");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}


	/**
	 * Formula editor clear button
	 * 
	 */
	public void formulaEditorClearButton() {
		try {
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_clear::PX^0::PTR^0::IX^1::ITR^0", app1)).click();
			logMessage("\nUser clicked on 'Clear' button on Formula Editor");
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}

	
	/**
	 * Formula editor 'Submit' button
	 * 
	 */
	public void formulaEditorSubmitButton() {
		try {
			(new GenieButton("SP^Stage:::FP^root:::SE^btn_submit::PX^0::PTR^0::IX^14::ITR^0", app1)).click();
			logMessage("\nUser clicked on 'Submit' button on Formula Editor");
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Methods which adds a particular question to the Quiz for AA-83 ticket
	 * 
	 */
	public void addQuestionForAA_83Ticket() {
		element("link_chapter5").click();
		logMessage("Instructor clicked on 'Chapter 5' link");
		waitForLoaderToDisappear();

		element("link_exercises").click();
		logMessage("Instructor clicked on 'Exercises' link");
		waitForLoaderToDisappear();

		wait.waitForElementToBeVisible(element("btn_gearbox"));
		element("chkbox_questionSearchAA_83").click();
		logMessage("Instructor clicked on a Question's checkbox");
		
		element("btn_addQuestionWrapper").click();
		logMessage("Instructor clicked on 'Add Question' button");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}


	/**
	 * Methods which navigates back to the Course home page
	 * 
	 */
	public void navigateBackToCourseHomePage() {
		wait.waitForElementToBeClickable(element("btn_doneEditing"));
		element("btn_doneEditing").click();
		logMessage("User clicked on 'Done Editing' button");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();

		wait.waitForElementToBeClickable(element("btn_home"));
		element("btn_home").click();
		logMessage("User clicked on 'Home' button");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}


	/**
	 * Student attempts the Assigned Quiz & Submits the Quiz
	 *
	 * @param correctFlag the correct flag
	 * 
	 */
	public void answerChapter5CQuiz(String correctFlag) {
		String i = null, j = null;
		
		element("btn_resume_start_quiz").click();
		logMessage("User clicked on 'Start Quiz' button");

		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");
		
		waitForElementToBeVisible("txt_numerator_ques");
		waitForElementToBeVisible("txt_denominator_ques");
		
		isElementDisplayed(("txt_numerator_ques"));
		isElementDisplayed(("txt_denominator_ques"));
		
		String numerator = element("txt_numerator_ques").getText();
		String denominator = element("txt_denominator_ques").getText();
		
		String pattern1 = "(\\d+)cos.+?";
		Pattern r1 = Pattern.compile(pattern1);
		Matcher m1 = r1.matcher(numerator);
		
		String pattern2 = "sin.+?(\\d+)x.+?";
		Pattern r2 = Pattern.compile(pattern2);
		Matcher m2 = r2.matcher(denominator);
		
		// NOTE: Added wait as to avoid i & j strings to contain NULL values
		hardWait(2);
		
		System.out.println("Numerator value: " + numerator);
		System.out.println("Denominator value: " + denominator);
		
		while (m1.find() & m2.find()) {
			i = m1.group(1);
			j = m2.group(1);
		}
		
		if (correctFlag == "InCorrectAnswer") {
			answer = "Wrong Answer";
		}
		else if (correctFlag == "CorrectAnswer") {
			answer = i + "/" + j + "ln(|" + denominator + "|)";
			System.out.println("Answer of the question: " + answer);
			
			isElementDisplayed("input_answer");
			element("input_answer").click();
			logMessage("User clicked on the answer field of the question");
			
			initializingGenie("[object MainTimeline]");
			formulaEditorClearButton();

			try {
				Keyboard key = new Keyboard();
				key.type(answer);
				logMessage("Student entered '" + answer + "' as the answer to the question");
			} catch (AWTException e) {
				e.printStackTrace();
			}

			formulaEditorSubmitButton();
		}

		isElementDisplayed("btn_submit");
		element("btn_submit").click();
		logMessage("User clicked on 'Submit' button");
		
		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button\n");
		
		//wait.waitForElementToDisappear(element("txt_submitting"));
		
		switchToDefaultContent();
		
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}


	/**
	 * Verifies whether the student has answered the question correctly or not by validating all
	 * the 'Identifies' are correct as per the question is answered.
	 *
	 * @param quesAnswered - Answer of question
	 * 
	 */
	public void verifyStudentAnswerWithSolution(String quesAnswered) {
		switchToDefaultContent();
		switchToFrame(element("frm_mainFrame"));
		
		isElementDisplayed("txt_score");

		if (quesAnswered.equalsIgnoreCase("CorrectAnswer")) {
			if (element("txt_score").getText().equalsIgnoreCase("Score: 10 of 10")) {
				logMessage("Assertion Passed: '" + element("txt_score").getText() + "' marks are displayed!!!");

				if ((isElementDisplayed("img_correct"))) {
					logMessage("Assertion Passed: Correct Answer anchor image is displayed!!!");

					if (((element("txt_correct").getText().equalsIgnoreCase("Correct")))) {
						logMessage("Assertion Passed: '" + element("txt_correct").getText() + "' feedback is displayed!!!");
					} else {
						Assert.fail("Assertion Failed: Correct text is NOT displayed!!!");
					}
				} else {
					Assert.fail("Assertion Failed: Correct Answer anchor image is NOT displayed!!!");
				}
			} else {
				Assert.fail("Assertion Failed: Correct Score is NOT displayed!!!");
			}
			logMessage("STUDENT has ANSWERED the Question CORRECTLY");
		}

		if (quesAnswered.equalsIgnoreCase("InCorrectAnswer")) {
			if (element("txt_score").getText().equalsIgnoreCase("Score: 0 of 10")) {
				logMessage("Assertion Passed: " + element("txt_score").getText() + " marks are displayed!!!");

				if ((isElementDisplayed("img_incorrect"))) {
					logMessage("Assertion Passed: In-Correct answer image is displayed");

					if ((element("txt_incorrect").getText().equalsIgnoreCase("Incorrect"))) {
						logMessage("Assertion Passed: In-Correct Text is displayed: " + element("txt_incorrect").getText());
					} else {
						Assert.fail("Assertion Failed: Text is NOT displayed correctly!!!");
					}
				} else {
					Assert.fail("Assertion Failed: Image is NOT displayed correctly!!!");
				}
			} else {
				Assert.fail("Assertion Failed: In-Correct Score is NOT displayed!!!");
			}
			logMessage("STUDENT has ANSWERED the Question IN-CORRECTLY");
		}

		element("btn_close").click();
		logMessage("User clicked on 'Close' button");
		
		switchToDefaultContent();
		
		waitForLoaderToDisappear();
	}

	
	/**
	 * Sets the Quiz attempt to 'Unlimited' times for the newly created course & 
	 * 'Saves' the setting for that quiz.
	 * 
	 */
	public void setQuizAttemptToUnlimited() {
		element("link_settings").click();
		logMessage("Instructor clicked on 'Settings' tab");
		
		selectProvidedTextFromDropDown(element("drpdwn_noOfAttempts"), "Unlimited");
		logMessage("Instructor selected 'Unlimited' value from 'No. of Attempts' Dropdown");

		element("btn_saveContent").click();
		logMessage("Instructor clicked on 'Save' button");

		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	
	/**
	 * Iteration to verify the correct & in-correct results for the Assigned 
	 * quiz for AA-83 ticket
	 * 
	 */
	public void verifyResultsOfQuizForAA_83Ticket() {
		String answerType[] = {"CorrectAnswer", "InCorrectAnswer"};
		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 2; j++) {
				logMessage("\nAnswer type: " + answerType[j]);
				answerChapter5CQuiz(answerType[j]);
				verifyStudentAnswerWithSolution(answerType[j]);
			}
		}
	}

	
	/**
	 * Method to preview list of Questions by Instructor & validating the size of the image.
	 * 
	 */
	public void previewListOfQuestionsByInstructor() {
		int count = 0;
		element("link_chapter9").click();
		logMessage("Instructor clicked on 'Chapter 9' link");
		waitForLoaderToDisappear();

		element("link_exercises").click();
		logMessage("Instructor clicked on 'Exercises' link");
		waitForLoaderToDisappear();

		System.out.println("Total no. of Questions in Chapter 9: " + elements("list_questionsChkbox").size());
		
		for (int i = 0; i < elements("list_questionsChkbox").size(); i++) {
			element("list_chapter9QuestionsChkbox", String.valueOf(i + 1)).click();
			
			element("link_preview").click();
			logMessage("User clicked on 'Preview' link");
			count++;

			validateImageContentOfQuestionByPreview(count);

			element("btn_closePreview").click();
			logMessage("User clicked on 'Close' image present on Question Player");
			
			waitForElementToBeVisible("list_chapter9QuestionsChkbox" , String.valueOf(i + 1));
			element("list_chapter9QuestionsChkbox", String.valueOf(i + 1)).click();
		}
	}

	
	/**
	 * Validates the image content whether it is broken or not & asserts the condition.
	 *
	 * @param questCount the quest count
	 * 
	 */
	public void validateImageContentOfQuestionByPreview(int questCount) {
		customAssert.customAssertTrue(_verifyImageIsVisible(questCount),
				"Assertion Failed: A Blank/Invisible image is present on the Preview modal for the Question");
		logMessage("Assertion Passed: Images are visible on Preview modal for the Question");
	}
	

	/**
	 * Gets the pixel(width) of all the images present in Question contents & verifies whether the image is greater than
	 * 10 pixel and if not then the image is blank/not visible.
	 *
	 * @param questionCountNo the question count no
	 * @return true, if successful
	 * 
	 */
	private boolean _verifyImageIsVisible(int questionCountNo) {
		int i = 0;
		boolean flag = false;
		System.out.println("\n********Question No. " + questionCountNo + " Preview********");
		System.out.println("Total No. of Images on Preview of question: " 
							+ elements("list_imagesOnPreviewWindow").size());
		
		if(elements("list_imagesOnPreviewWindow").size() != 0){
			for (WebElement images : elements("list_imagesOnPreviewWindow")) {
				System.out.println("Size of Image No." + (i + 1) + " is: "
						+ images.getAttribute("width") + "(in px)");
				i++;
				
				if (Integer.parseInt(images.getAttribute("width")) > 5) {
					flag = true;
				} else {
					flag = false;
					return false;
				}
			}
		} else{
			logMessage("This question has NO images in it!!!");
			flag = true;
		}
		return flag;
	}

	
	/**
	 * Navigates to the DashBoard of the course
	 * 
	 */
	public void navigateToDashBoard() {
		wait.waitForElementToBeVisible(element("btn_home"));
		element("btn_home").click();
		logMessage("User clicked on 'Home' button");
	}

	
	/**
	 * Student clicks on 'Start Quiz' & attempts the assigned quiz. Whether verifies that 
	 * question's content are loaded correctly.
	 * 
	 */
	public void studentAttemptsQuizForAA_206Ticket() {
		switchToDefaultContent();
		String quesText = getData("AA-206.txt_validation");

		element("btn_startQuiz").click();
		logMessage("User clicked on 'Start the Quiz' button");
		waitForLoaderToDisappear();

		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");
		waitForElementToDisappear("txt_loader");
		wait.waitForElementToBeVisible(element("txt_questionContentsAA_206"));

		logMessage("Question Text contains Text: "
				+ element("txt_questionContentsAA_206").getText());

		if(element("txt_questionContentsAA_206").getText().contains(quesText)){
			logMessage("Question is loaded Properly!");
		}else{
			Assert.fail("Question is NOT loaded CORRECTLY!!!");
		}

		element("btn_Submit").click();
		logMessage("User clicked on 'Submit' button");

		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button present on the Dialog-box");
		switchToDefaultContent();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}


	/**
	 * Goes through all the question of particular type and verifies the preview does not 
	 * contain matcher text provided in the yaml file.
	 *
	 * @param questionType question type to consider for testing
	 */
	public void previewAllExerciseQuestionsOfEachChapter(String questionType) {
		boolean verify = false;
		String quesText = "";

		for (int i = 0; i < elements("link_chapterList").size(); i++) {
			int counter = 0;
			System.out.println("No. of Questions: " + elements("link_chapterList").size());
			elements("link_chapterList").get(i).click();

			waitForElementToBeVisible("link_QuestionType", questionType);
			waitForLoaderToDisappear();

			element("link_QuestionType", questionType).click();
			logMessage("User clicked on '" + questionType + "' question type");

			for (int j = 0; j < elements("list_chkboxes").size(); j++) {
				wait.waitForElementToBeVisible(element("btn_gearbox"));
				element("list_QuestionChkboxes", String.valueOf(j + 1)).click();

				element("link_preview").click();
				logMessage("User clicked on 'Preview' link");

				verify = hasBadXMLErrorMessage(questionType);

				switchToDefaultContent();

				isElementDisplayed("btn_closePreview");
				element("btn_closePreview").click();
				logMessage("User clicked on 'Close' button");

				if (verify) {
					quesText = element("txt_selectedQuestion").getText();
					logMessage("Question Title having Error Message: " + quesText);
					counter++;
				}
				element("list_QuestionChkboxes", String.valueOf(j + 1)).click();
				logMessage("Instructor clicked on the checkbox of another Question!");
			}	
			waitForLoaderToDisappear();
	                
	        /*} catch (NoSuchElementException e) {
	               element("link_questionBank").click();
	               waitForLoaderToDisappear();
	               logMessage("****** " + questionType + " Exercise is NOT present in '"
	                      + elements("link_chapterList").get(i).getText() + "' ******");
	         }   
	         logMessage("No. of Questions in '"
	                  + elements("link_chapterList").get(i).getText()
	                  + "' having Error messages: " + counter);*/

			logMessage("No. of Questions in '" + questionType
					+ "' having error messages: " + counter);
		}
		
		logMessage("Total Count of Questions having Bad XML Error Messages: " + count);
		customAssert.customAssertTrue((count == 0),
				"Questions in Exercises CONTAIN Bad XML Error Message!!!");
	}


	/**
	 * Validates whether the Question displays Bad XML error message after previewing it.
	 *
	 * @param questionType the question type
	 * @return true, if successful
	 * 
	 */
	public boolean hasBadXMLErrorMessage(String questionType) {
		wait.resetImplicitTimeout(1);
		boolean flag = false;
		String matchText = getData("AA-301.previewErrorMsg");

		try {
			flag = element("txt_questionPreviewMain").getText().contains(matchText);
		} catch (NoSuchElementException e) {
			logMessage("Un-able to find text of Question!!!");
		}

		try {
			if(questionType.equalsIgnoreCase("End of Chapter Questions")){
				waitForLoaderToDisappear();
				switchToFrame(element("frame_preview"));
				flag = flag || element("div_questionInner").getText().contains(matchText);
			}
			else if(questionType.equalsIgnoreCase("Graphing Questions")){
				waitForLoaderToDisappear();
				flag = flag || element("txt_innerQuestionText").getText().contains(matchText);
			}
			else if(questionType.equalsIgnoreCase("Self-Test")){
				waitForLoaderToDisappear();
				flag = flag || element("txt_innerQuestionText").getText().contains(matchText);
			}
			else if(questionType.equalsIgnoreCase("Practice Questions")){
				waitForLoaderToDisappear();
				flag = flag || element("txt_innerQuestionText").getText().contains(matchText);
			}
			else if(questionType.equalsIgnoreCase("Self-Test Quizzes")){
				waitForLoaderToDisappear();
				flag = flag || element("txt_innerQuestionText").getText().contains(matchText);
			}

		} catch (NoSuchElementException e) {
			if(questionType.equalsIgnoreCase("End of Chapter Questions")){
				flag = flag || element("div_questionErrorInner").getText().contains(matchText);
				logMessage("Bad XML Error Message Found!!!");
			}
			else if(questionType.equalsIgnoreCase("Graphing Questions")){
				waitForLoaderToDisappear();
				flag = flag || element("div_questionErrorInner").getText().contains(matchText);
				logMessage("Bad XML Error Message Found!!!");
			}
			else if(questionType.equalsIgnoreCase("Self-Test")){
				waitForLoaderToDisappear();
				flag = flag || element("div_questionErrorInner").getText().contains(matchText);
				logMessage("Bad XML Error Message Found!!!");
			}
			else if(questionType.equalsIgnoreCase("Practice Questions")){
				waitForLoaderToDisappear();
				flag = flag || element("div_questionErrorInner").getText().contains(matchText);
				logMessage("Bad XML Error Message Found!!!");
			}
			else if(questionType.equalsIgnoreCase("Self-Test Quizzes")){
				waitForLoaderToDisappear();
				flag = flag || element("div_questionErrorInner").getText().contains(matchText);
				logMessage("Bad XML Error Message Found!!!");
			}
		}

		if (flag) {
			CustomFunctions.takeScreenshot(".", getData("econ.bookTitle"));
			count++;
		}
		wait.resetImplicitTimeout(wait.getTimeout());
		return flag;
	}


	/**
	 * Method which create "Question Pool" type question & adds it to Quiz.
	 * 
	 */
	public void addQuestionPoolToQuiz() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		
		for (int i = 0; i < 2; i++) {
			wait.waitForElementToBeVisible(element("btn_gearbox"));
			element("list_QuestionChkboxes", String.valueOf(i + 1)).click();
		}
		
		element("btn_wrapperAddToPool").click();
		logMessage("Instructor clicked on 'Add to Pool' button");
		
		element("link_addToNewPool").click();
		logMessage("Instructor clicked on 'Add to New Pool' link");
		
		element("txtBox_poolTitle").sendKeys("Smoke Testing - Pool Title");
		
		element("txtBox_poolCount").click();
		element("txtBox_poolCount").sendKeys("2");
		
		element("btn_create").click();
		logMessage("Instructor clicked on 'Create' button");
		
		element("link_hideQuestions").click();
		logMessage("Instructor clicked on 'Hide Questions' link");
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}


	/**
	 * Method where the student attempts the Quiz having DIVERSE type of questions.
	 * 
	 */
	public void studentAttemptsQuizHavingDiverseQuestions() {
		element("btn_startQuiz").click();
		logMessage("User clicked on 'Start the Quiz' button");
		
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		element("radio_answer1").click();
		logMessage("User selected Choice 1 for the 1st question");
		
		element("radio_answer2").click();
		logMessage("User selected Choice 2 for the 2nd question");
		
		element("radio_answer3").click();
		logMessage("User selected Choice 3 for the 3rd question");
		
		element("input_answer4").sendKeys("Thrashing");
		logMessage("User entered the answer for 4th question");

		for(WebElement elDrop : elements("list_matchDropdown")){
			selectProvidedTextFromDropDown(elDrop, "c");
		}
		logMessage("User selected the appropriate answers for matching question");

		element("chkbox_answer7Option1").click();
		element("chkbox_answer7Option2").click();
		logMessage("User selected 2 answers for Multiple Answer question");

		element("radio_answer9").click();
		logMessage("User selected a radio button for last question");
		
		element("btn_Submit").click();
		logMessage("User clicked on 'Submit' button");
		
		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button present on pop-up box");
		
		waitForMsgToastToDisappear();
		switchToDefaultContent();
	}


	/**
	 * Imports question & adds it to Quiz
	 * 
	 */
	public void importQuestionToQuiz() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		element("btn_importQuestion").click();
		logMessage("Instructor clicked on 'Import Question' option");
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}


	/**
	 * Method where the student attempts the Quiz for AA-311 Ticket.
	 */
	public void studentAttemptsQuizForAA_311Ticket() {
		element("btn_startQuiz").click();
		logMessage("Student clicks on 'Start Quiz' button");
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		element("btn_Submit").click();
		logMessage("Student clicks on 'Submit' button");
		
		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button");

		waitForMsgToastToDisappear();
		switchToDefaultContent();
	}

	/**
	 * Method which verifies all the indicators are appropriate as student as 
	 * answered the question.
	 * 
	 */
	public void verifyStudentAnswer(){
		switchToDefaultContent();
		
		switchToFrame(element("frm_mainFrame"));
		isElementDisplayed("txt_score");

		if (element("txt_score").getText().equalsIgnoreCase("Score: 0 of 1")) {
			logMessage("Assertion Passed: " + element("txt_score").getText() + " marks are displayed!!!");

			if ((isElementDisplayed("img_incorrectGradeLabel"))) {
				logMessage("Assertion Passed: Correct answer image is displayed");

				if ((element("txt_incorrect").getText().contains("Incorrect"))) {
					logMessage("Assertion Passed: In-Correct Text is displayed: " + element("txt_incorrect").getText());	
				} else {
					Assert.fail("Assertion Failed: Text is NOT displayed correctly!!!");
				}
			} else {
				Assert.fail("Assertion Failed: Image is NOT displayed correctly!!!");
			}
		} else {
			Assert.fail("Assertion Failed: In-Correct Score text is NOT displayed!!!");
		}
		logMessage("STUDENT has ANSWERED the Question IN-CORRECTLY");
		
		switchToDefaultContent();
	}


	/**
	 * Method which verifies user is on 'Setting' Tab.
	 *
	 * @param settingsPageTitle the settings page title
	 * 
	 */
	public void verifyUserIsOnSettingsPage(String settingsPageTitle) {		
		isElementDisplayed("txt_settingsPageTitle");
		assertEquals(element("txt_settingsPageTitle").getText(),
				settingsPageTitle,
				"Assertion Failed: Settings Page Title is not correct!!!");
		logMessage("Assertion Passed: User is on Settings Page, Verified Page title visibility and Title text to be: "
				+ settingsPageTitle);

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}


	/**
	 * Method which verifies user is on 'Questions' Tab.
	 *
	 * @param questionsPageTitle the questions page title
	 */
	public void verifyUserIsOnQuestionsPage(String questionsPageTitle) {
		waitForLoaderToDisappear();

		isElementDisplayed("txt_questionsPageTitle");
		assertEquals(element("txt_questionsPageTitle").getText(),
				questionsPageTitle,
				"Assertion Failed: Questions Page Title is not correct!!!");
		logMessage("Assertion Passed: User is on Questions Page, Verified Page title visibility and Title text to be: "
				+ questionsPageTitle);

		waitForLoaderToDisappear();
	}


	/**
	 * Method which edit the newly created Question by hovering on 'Preview'
	 * link & then clicking on 'Edit' link.
	 * 
	 */
	public void editNewlyCreatedQuestion() {
		hover(element("link_previewQuestion"));
		logMessage("Hovered on 'Expand' question editor option");
		
		element("link_edit").click();
		logMessage("Clicked on 'Edit' link");
		
		waitForLoaderToDisappear();
	}

	/**
	 * Methods which clicks on "Done Editing" button.
	 */
	public void clickOnDoneEditingButton() {
		switchToDefaultContent();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();		
		
		element("btn_doneEditing").click();
		logMessage("User clicked on 'Done Editing' button");
		waitForLoaderToDisappear();
	}

	
	/**
	 * Method which clicks on 'Home' button
	 * 
	 */
	public void clickOnHomeButton() {
		isElementDisplayed("btn_home");
		element("btn_home").click();
		logMessage("User clicked on 'Home' button");
		waitForLoaderToDisappear();
	}

	/**
	 * Method which selects a specific 'Chapter' from Question Bank.
	 *
	 * @param chapterName - Chapter Name present in Question Bank
	 * 
	 */
	public void selectChapterFromQuestionBank(String chapterName){
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		waitScrollAndClick("link_chapterFromQuestionBank", chapterName);
		logMessage("Instructor clicks on '" + chapterName + "' from the list of Chapters");
		waitForLoaderToDisappear();
	}  

	/**
	 * Method which select a specific 'Exercise' from Question Bank.
	 *
	 * @param exerciseName - Exercise Name present in Question Bank
	 * 
	 */
	public void selectExerciseFromQuestionBank(String exerciseName){
		scrollDown(element("link_exerciseFromQuestionBank", exerciseName));
		element("link_exerciseFromQuestionBank", exerciseName).click();
		logMessage("Instructor clicks on '" + exerciseName + "' from the list of Exercises");
		waitForLoaderToDisappear();
	}

	
	/**
	 * Method which select a specific 'Question' from Question Bank.
	 *
	 * @param questionTitle - Title of Question
	 * 
	 */
	public void selectQuestionFromQuestionBank(String questionTitle){
		waitForElementToBeVisible("btn_gearbox");
		waitForElementToBeVisible("chkbox_question", questionTitle);
		
		hardWait(1);
		
		element("chkbox_question", questionTitle).click();
		logMessage("Instructor selects '" + questionTitle + "' from Question Bank \n");

		if(element("chkbox_question", questionTitle).isSelected()){
			logMessage("Assertion Passed: Question with Title '" 
					+ questionTitle  + "' is selected!!!");
		} else{
			Assert.fail("Assertion Failed: Question with Title '" 
					+ questionTitle  + "' is NOT selected!!!");
		}
		waitForLoaderToDisappear();
	}
	
	
	/**
	 * Method which select a specific 'Question' from Question Bank.
	 *
	 * @param questionTitle - Un-bold title of Question
	 * 
	 */
	public void selectUnBoldQuestionFromQuestionBank(String questionTitle){
		waitForElementToBeVisible("btn_gearbox");
		element("chkbox_questionUnBold", questionTitle).click();
		logMessage("Instructor selects unbold '" + questionTitle + "' from Question Bank \n");

		if(element("chkbox_questionUnBold", questionTitle).isSelected()){
			logMessage("Assertion Passed: UnBold Question with Title '" 
							+ questionTitle  + "' is selected!!!");
		} else{
			Assert.fail("Assertion Failed: UnBold Question with Title '" 
								+ questionTitle  + "' is NOT selected!!!");
		}
		waitForLoaderToDisappear();
	}

	
	/**
	 * Method which adds Question to Quiz
	 * 
	 */
	public void clickOnAddQuestion(){
		element("btn_addQuestionWrapper").click();
		logMessage("Instructor adds the Question to Quiz");

		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}


	/**
	 * Method which validates that answer is NOT provided near Answer input box 
	 * of HTS Matching question
	 * 
	 */
	public void validatesAnswersAreNotPreProvidedWithTheQuestion(){
		String quesText;

		element("btn_startQuiz").click();
		logMessage("User clicked on 'Start Quiz' button");

		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		for (WebElement elems : elements("list_htsMatchingQuestions")){
			quesText = elems.getText();
			System.out.println("Text of the Question in Quiz: " + quesText);

			String pattern = "(.*)(\\d+)(:?)";
			Pattern p = Pattern.compile(pattern);

			Matcher mh = p.matcher(quesText);
			if (mh.find()) {
				System.out.println("Found value: " + mh.group(0));
				System.out.print("Start index: " + mh.start() + "\n");
				System.out.print("End index: " + mh.end() + "\n");
			} else {
				System.out.println("Assertion Passed: No Answer is pre-provided with HTS Matching Question!!!");
			}
		}
		
		element("btn_Submit").click();
		logMessage("User clicked on 'Submit' button");

		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button present on the Dialog-box");
		
		switchToDefaultContent();
	}

	
	/**
	 * Method which clicks on 'Save' button when the Dialog box appears
	 * 
	 */
	public void clickOnSaveDialogBox() {
		waitForElementToDisappear("dialog_saveDialogBox");
		logMessage("Save Dialog Box message Appears!!!");
		
		element("btn_saveOnDialogBox").click();
		logMessage("User clicked on 'Save' button");
		
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}


	/**
	 * Method which verifies for duplicate answer options in question .
	 *
	 * @param value the value
	 * 
	 */
	public void verifyForDuplicateAnswerOptions(String value) {
		switchToDefaultContent();
		switchToFrame(element("frame_preview"));

		int count = elements("txt_answerForAA_146", value).size();
		logMessage("No. of specfic Answer options found: " + count);

		if (count == 1) {
			logMessage("Assertion Passed: No duplicate options found!!!");
		} else {
			Assert.fail("Assertion Failed: Duplicate options FOUND!!!");
		}
		switchToDefaultContent();
	}


	/**
	 * Method which closes the Preview window on FnE page
	 * 
	 */
	public void closePreviewWindow() {
		element("btn_closePreviewWindow").click();
		logMessage("User closed the Preview Window!!!");
	}	


	/**
	 * Method which clicks on 'Done' button on FnE page while the user is 
	 * attempting the quiz
	 * 
	 */
	public void clickOnDoneButton(){
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		
		element("btn_done").click();
		logMessage("User clicked on 'Done' button on Quiz page!!!");
		
		handleAlert();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	
	/**
	 * Method which adds some questions to Quiz for AA-460 Ticket
	 * 
	 */
	public void addSomeQuestionsForAA_460Ticket() {
		String[] questions = 
			{	"(EX) Chapter 05, Section 02, Exercise 55",
				"(EX) Chapter 05, Section 06, Exercise 33",
			"(EX) Chapter 05, Section 03, Exercise 10" };

		for (int i = 0; i < questions.length; i++) {
			waitForElementToBeVisible("btn_gearbox");

			element("ckhbox_listQuestions", questions[i]).click();
			logMessage("Instrucor selected '" + questions[i] + "' from Question Bank");
		}
		element("btn_addQuestionWrapper").click();
		logMessage("Instructor clicked on 'Add' button");
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	
	/**
	 * Method where student attempts the Quiz which contains specific questions
	 * for AA-460 ticket.
	 *
	 * @return true, if successful
	 * 
	 */
	public boolean verifyAdvancedQuestionContentsAreLoadedCompletelyForTicketAA_460() {
		element("btn_startQuiz").click();
		logMessage("Student clicked on 'Start Quiz' button");

		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		boolean flag = false;
		int count = elements("list_questionsForAA_460").size();
		System.out.println("No. of questions in Quiz: " + count);
		
		if(count != 0){
			for (WebElement elem : elements("list_questionsForAA_460")) {
				if (elem.getText().contains("notation")) {
					logMessage("Assertion Passed: Advanced Question has loaded successfully!!!");
					flag = true;
				} else {
					Assert.fail("Assertion Failed: Advanced Question has NOT loaded completely!!!");
					return flag;
				}
			}
		}else{
			Assert.fail("Assertion Failed: Questions in the quiz are NOT visible!!!");
		}
		
		switchToDefaultContent();
		return flag;
	}

	
	/**
	 * Method which moves back to course home page without attempting the Quiz
	 * 
	 */
	public void moveBackToCourseHomePageWithoutAttemptingTheQuiz() {  
		element("btn_done").click();
		logMessage("While attempting the Quiz User clicked on 'Done' button ");
		handleAlert();

		element("btn_done").click();
		logMessage("User clicked on 'Done' button!!!");
		waitForLoaderToDisappear();

		element("btn_home").click();
		logMessage("Instructor clicks on 'Home' button");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	
	/**
	 * Method which student attempts Quiz for Ticket AA-460
	 * 
	 */
	public void studentAttemptsQuizForTicketAA_461() {
		verifyValueOfQuestion1stTextboxAfterAttempting();
		verifyValueOfQuestion3rdTextboxAfterAttempting();

		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		element("btn_Submit").click();
		logMessage("User clicked on 'Submit' button");
		
		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button");
		switchToDefaultContent();
		
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}
	

	/**
	 * Method which answers the questions in the Quiz for AA-461 Story.
	 *
	 * @param answerValue the answer value
	 * 
	 */
	private void _answerQuestionForTicketAA_461(String answerValue) {
		try {            
			(new UIKeyBoard()).typeText(answerValue);
			logMessage("\nStudent entered '" + answerValue + "' answer for the question via Genie");
		} catch (StepFailedException e) {
			e.printStackTrace();
		} catch (StepTimedOutException e) {
			e.printStackTrace();
		}
	}


	/**
	 * Method in which student attempts the 1st Question in the Quiz for AA-461 Story
	 * and verifies the value of the text box after attempting it.
	 * 
	 */
	private void verifyValueOfQuestion1stTextboxAfterAttempting() {
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		isElementDisplayed("input_answer1");
		element("input_answer1").click();
		logMessage("User clicked on 1st question's answer text box");

		// Method which examines the loading time of Equation editor by checking the DIV tag is enable or not 
		// wait.waitForElementToDisappear(element("window_eqEditor1"));

		waitForElementToBeVisible("txt_titleBar");
		System.out.println("Title of Editor: " + element("txt_titleBar").getText());
		
		int i = 1;
		while(!element("txt_titleBar").getText().equalsIgnoreCase("Equation Editor")){
			hardWait(1);
			System.out.print(i + "... ");
			i++;
		}
		
		logMessage("\nEquation Editor took '"
				+ (i - 1)
				+ "' second(s) to appear without the flash content!!!");

		initializingGenie("[object MainTimeline]");
		_answerQuestionForTicketAA_461("y+5");
		formulaEditorSubmitButton();

		System.out.println("Answer of 1st answer: " + element("input_answer1").getText());
		int j = 1;
		while (!element("input_answer1").getText().equalsIgnoreCase("y+5")) {
			hardWait(1);
			System.out.print(j + "... ");
			j++;
		}
		logMessage("\nEquation Editor took '"
				+ (j - 1)
				+ "' second(s) to reflect the answer of 1st question in the Text box");
		Assert.assertEquals(element("input_answer1").getText(), "y+5",
				"Answer is NOT reflected for Answer 1 Text box");

		switchToDefaultContent();
	}


	/**
	 * Method in which student attempts the 3rd Question in the Quiz for AA-461 Story
	 * and verifies the value of the text box after attempting it.
	 */
	private void verifyValueOfQuestion3rdTextboxAfterAttempting(){
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		isElementDisplayed("input_answer3");
		element("input_answer3").click();
		logMessage("User clicked on 3rd question's answer to attempt the question");
		
		waitForElementToBeVisible("txt_titleBar");
		System.out.println("Title of Editor: " + element("txt_titleBar").getText());
		
		int i = 1;
		while(!element("txt_titleBar").getText().equalsIgnoreCase("Equation Editor")){
			hardWait(1);
			System.out.print(i + "... ");
			i++;
		}
		logMessage("\nEquation Editor took '"
				+ (i - 1)
				+ "' second(s) to appear without the flash content!!!");

		initializingGenie("[object MainTimeline]");
		_answerQuestionForTicketAA_461("14");
		formulaEditorSubmitButton();

		System.out.println("Value of 3rd answer of question: " + element("input_answer3").getText());
		int j = 1;
		while (!element("input_answer3").getText().equalsIgnoreCase("14")) {
			hardWait(1);
			System.out.print(j + "... ");
			j++;
		}
		
		logMessage("\nEquation Editor took '"
				+ (j - 1)
				+ "' second(s) to reflect the answer of 3rd question in the Text box");
		Assert.assertEquals(element("input_answer3").getText(), "14",
				"Answer is NOT reflected for Answer 3 Text box");

		switchToDefaultContent();
	}


	/**
	 * Method which verifies buttons on Quiz page such as 'Check Syntax', etc.
	 * 
	 */
	public void verifyButtonsOnQuizPageForTicketAA_461(){
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame");

		isElementDisplayed("btn_checkSyntax");
		element("btn_checkSyntax").click();
		logMessage("Student clicked on 'Check Syntax' button");

		if (element("input_answer2").getCssValue("border-color").equalsIgnoreCase("LightGreen")
				&& element("txt_checkSyntaxResult").getText().equalsIgnoreCase("Syntax OK")) {
			logMessage("Assertion Passed: 'Check Syntax' button is clicked successfully!!!");
		} else {
			Assert.fail("Assertion Failed: 'Check Syntax' button is NOT clickable at this time!!!");
		}

		switchToDefaultContent();
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}
	
	
	/**
	 * Select question from quiz from number
	 * 
	 */
	public void addSingleQuestionsForQuiz(String num) {
		waitForElementToBeVisible("btn_gearbox");
		
		element("chkbox_questionSingleSelect" , num).click();
		logMessage("Instructor selected '" + num + "' question from the Exercise");
		
		element("btn_addQuestionWrapper").click();
		logMessage("Instructor clicked on 'Add' button to add the question to the Quiz");
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}
	

	/**
	 * Removes the questions from assessment
	 *
	 * @param numOfcheckBox - the number of check box
	 * 
	 */
	public void removeQuestionsFromAssessment(String numOfcheckBox) {
		wait.waitForElementToBeVisible(element("btn_gearbox"));
		int count = elements("chkbox_questionOnAssessment",numOfcheckBox).size();
		System.out.println("No. of questions in the Assessment: " + count);
		element("chkbox_questionOnAssessment" , String.valueOf(numOfcheckBox)).click();
		logMessage("Instructor selected '" + (numOfcheckBox) + "' question from the Exercise");
		waitForElementToBeVisible("btn_removeQuestionFromAssessment");
		element("btn_removeQuestionFromAssessment").click();
		logMessage("Instructor clicked on 'Remove' button to Remove the question to the Assessment");
//		removeSelectedQuestionwidget();
		verifyWorkStartedWindow();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}
	
	
	public void removeSelectedQuestionwidget() {
		waitForElementToBeVisible("btn_removeBtnOnWidget");
		element("btn_removeBtnOnWidget").click();
	}

	public void verifyWorkStartedWindow()
	{
		waitForElementToBeVisible("lnk_workstarted");
		waitForElementToBeVisible("btn_workstarted_ok");
		element("btn_workstarted_ok").click();
	}
	
	/**
	 * Method which clicks on 'Edit' link on the question which is newly 
	 * added to the Quiz.
	 * 
	 */
	public void clickOnEditLink() {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();

		// hover(element("link_previewCurrentQuestion" , "1"));
		executeJavascript("document.getElementsByClassName('edit-current-question hidden')[0]"
																		+ ".style='display: block;'");
		logMessage("User hovered on 'Preview' link to view other available options");

		element("link_editCurrentQuestion").click();
		logMessage("Instructor clicked on 'Edit' link on FnE Page");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	
	/**
	 * Method which adds specific questions to Quiz .
	 */
	public void clickOnAddQuestionButton() {
		waitForElementToBeVisible("btn_addQuestionWrapper");
		element("btn_addQuestionWrapper").click();
		logMessage("Instructor clicked on 'Add' button to add the question to the Quiz");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}


	/**
	 * Method in which verifies whether the Preview Modal Window is displayed .
	 *
	 * @param previewModalTitle the preview modal title
	 * 
	 */
	public void verifyPreviewModalWindowIsDisplayed(String previewModalTitle) {
		waitForLoaderToDisappear();
		isElementDisplayed("txt_previewModalWindowTitle");
		assertEquals(element("txt_previewModalWindowTitle").getText(),
				previewModalTitle,
				"Assertion Failed: Preview Modal Window title is not correct.");

		assert element("btn_regenrateVariables").isDisplayed();
		assert element("img_close").isDisplayed();

		logMessage("Assertion Passed: User is on Preview Modal Window, Verified Page title "
				+ "visibility and Title text to be: " + previewModalTitle);
	}


	/**
	 * Method which views all the questions in Preview Mode to verify the Greek Symbol PI in the
	 * contents of the questions.
	 * 
	 */
	public void viewAllQuestionsInPreviewMode(){
		String[] txtTitle = { "(EX) Chapter 01, Section 04, Exercise 10",
				"(EX) Chapter 01, Section 04, Exercise 11",
				"(EX) Chapter 01, Section 04, Exercise 12",
				"(EX) Chapter 01, Section 04, Exercise 13",
		"(EX) Chapter 01, Section 04, Exercise 09" };

		int count = elements("list_questionInQuiz").size();
		System.out.println("No. of Questions present in Quiz: " + count);

		for (int i = 1; i <= count; i++) {
			hover(element("lnk_expandList", String.valueOf(i)));
			logMessage("Instructor hovered on '" + i + "' 'Expand' link");

			hoverClick(element("link_previewCurrentQuestion", String.valueOf(i)));
			logMessage("Instructor clicked on 'Preview' link");

			verifyPreviewModalWindowIsDisplayed(txtTitle[i - 1]);

			switchToDefaultContent();
			switchToFrame(element("frame_previewFrame"));

			waitForLoaderToDisappear();
			System.out.println("Question No. " + i + "'s components which contain PI symbol: "
					+ elements("txt_piSymbolAA_465").size());


			int y = element("txt_piSymbolAA_465").getLocation().getX();
			System.out.println("No. of symbols containing PI symbol:" + y);

			for (WebElement elem : elements("txt_piSymbolAA_465")) {
				switchToDefaultContent();
				switchToFrame(element("frame_previewFrame"));

				String mathJaxElementId = elem.getAttribute("id");
				System.out.println("Value of Math Jax Element: "
						+ mathJaxElementId);

				switchToDefaultContent();
				String frameClass = element("frame_previewFrame").getAttribute(
						"class");

				String content = executeJavascript("return document.getElementsByClassName('"
						+ frameClass
						+ "')[0].contentDocument.getElementById('"
						+ mathJaxElementId + "').innerHTML").toString();

				if (content.contains("\\pi")) {
					logMessage("Assertion Passed: Question Details contain Greek Symbol 'Pi' in it!!! \n");
				} else {
					Assert.fail("Assertion Failed: Greek Symbol is NOT present!!! \n");
				}

			}
			switchToDefaultContent();
			element("img_close").click();
			logMessage("Instructor clicked on 'X' button");
		}
	}
	

	/**
	 * Verify blank spaces feedback section after submit quiz.
	 * 
	 */
	public void verifyBlankSpacesfeedbackSectionAfterSubmitQuiz() {
		waitForLoaderToDisappear();
		waitForLoaderToDisappear();

		switchToDefaultContent();
		switchToFrame(element("frm_mainFrame"));
		waitForElementToBeVisible("btn_close");
		
		List<WebElement> totalStep = elements("totalcountofincorrectfeedback");
		int j = totalStep.size();
		System.out.println("j =" + j);

		for (int i = 2; i < j; i++) {
			int heightofP1 = element("txt_incorrectFeedbacksInPreviewModal",
					Integer.toString(i)).getLocation().y;
			int heightofTable = element(
					"table_incorrectFeedbacksInPreviewModal",
					Integer.toString(i)).getLocation().y;
			if ((heightofTable - heightofP1) > 50) {
				customAssert.customAssertTrue(false,
						"Assertion Failed : There is gap between  feedback lines");
			} else {
				logMessage("There is no gap between Incorrect feedback section after submit quiz");
			}
		}
		switchToDefaultContent();
	}

	
	/**
	 * Method which verifies the Tool tip of the Correct answer in Review Mode
	 * 
	 */
	public void verifyToolTipPositionofCorrectAnswerInReviewMode(){
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		
		switchToDefaultContent();
		
		// Selecting a frame by index which is equivalent to JavaScript(JS)
		// Note: Using this method to select a frame by WebElement
		driver.switchTo().frame(1);

		logMessage("Waiting for the complete Question to be visible...");
		waitForElementToBeVisible("txt_completeHtsQuestionStep");

		List<WebElement> totalToolTipImage = elements("total_tooltipImage");
		logMessage("Total no. of Tooltip Images: " + totalToolTipImage.size());

		if(elements("total_tooltipImage").size() == 0){
			Assert.fail("Assertion Failed: ToolTip images did NOT load after submitting the Quiz!!!");
		}

		for (WebElement tooltip : totalToolTipImage) {
			hover(tooltip);
			logMessage("\nHovered on the Tool Tip of Correct answer");
			waitForElementToBeVisible("txt_toolTipMsg");

			customAssert.customAssertTrue(element("txt_toolTipMsg").getAttribute("style").contains("left"), 
					"Assertion Failed : ToolTip didn't appear on the left side of the Correct Answer");
			logMessage("Assertion Passed : ToolTip appeares on left side of the Correct Answer");
		}
		
		switchToDefaultContent();
	}


	/**
	 * Click on 'Edit Questions' button
	 * 
	 */
	public void clickOnEditQuestionsButton(){
		element("btn_editQuestions").click();
		logMessage("User click on 'Edit Questions' button");
		waitForLoaderToDisappear();
	}


	/**
	 * Method which clicks on 'Close' image present on Question Preview window.
	 * 
	 */
	public void clickOnCloseImagePresentOnQuestionPreviewWindow() {
		element("img_close").click();
		logMessage("Instructor clicked on 'X' button");
	}

	
	/**
	 * Click on 'Start Homework' button
	 * 
	 */
	public void clickOnStartTheHomework() {
		element("btn_StartHomework").click();
		logMessage("Click on 'Start the Homework' button");
	}


	/**
	 * Click on 'Submit' button on completion of assigned Quiz
	 * 
	 */
	public void clickOnSubmitButton() {
		driver.navigate().refresh();
		
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frame_contentFrame:frame_questionFrame");
		
		element("btn_Submit").click();
		logMessage("Student clicked on 'Submit' button");
		
		switchToDefaultContent();
	}


	public void clickOnSubmitBtnOnHomeWork() {
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frame_contentFrame:frame_questionFrame");
		
		clickOnSubmitButton();
	}


	/**
	 * Click on 'Details' button
	 * 
	 */
	public void clickOnDetails() {
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frame_contentFrame:frame_questionFrame");
		
		waitForElementToBeVisible("btn_details");
		element("btn_details").click();
		switchToDefaultContent();
	}

	/**
	 * Verify text on detail for Homework
	 *
	 * @param expectedAnswer - Expected answer of question
	 * 
	 */
	public void verifyTextOnDetailForHomeWork(String expectedAnswer) {	
		switchToDefaultContent();
		switchToFrame(element("frm_mainFrame"));
		
		waitForElementToBeVisible("txt_DetailsHomework");
		customAssert.customAssertEquals(element("txt_DetailsHomework").getText(), 
				"Details for 'Homework'", "Detail of Question heading is not matched in Homework question");
		
		String currentAnswer = element("txt_DetailAnswer").getText().replace("\n", " ");	
		System.out.println("Current Answer from UI: "+currentAnswer);
		System.out.println("Expected Answer: "+expectedAnswer);
		customAssert.customAssertTrue(currentAnswer.contains(expectedAnswer),
											"Assertion Failed: Text is NOT matching!!!");
		switchToDefaultContent();
	}

	
	/**
	 * Click on 'Details Close' button
	 * 
	 */
	public void clickOnDetailsClose() {
		switchToDefaultContent();
		switchToFrame(element("frm_mainFrame")); 
		waitForElementToBeVisible("btn_closeDetailWindow");
		element("btn_closeDetailWindow").click();
		switchToDefaultContent();
	}

	
	/**
	 * Method which clicks on the No. of attempts for Homework Quiz
	 * 
	 * @param attemptquestionNumber - No. of the question to be attempted
	 * 
	 */
	public void clickOnAttemptsForHomeworkQuiz(String attemptquestionNumber) {	
		waitForElementToBeVisible("btn_attemptQuestion",attemptquestionNumber);
		
		element("btn_attemptQuestion",attemptquestionNumber).click();
		logMessage("User clicked on 'Attempt Question' button");
	}

	
	/**
	 * Method which verifies that user is on FnE page after grading the Quiz
	 * 
	 * @param mainGradingPageTitle - Title of Main Grading page
	 * 
	 */
	public void verifyUserIsOnFnEPageAfterGradingTheQuiz(String mainGradingPageTitle) {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		
		switchToDefaultContent();
		switchToFrame(element("frame_mainFrame"));
		
		isElementDisplayed("txt_mainGradingPageTitle");

		customAssert.customAssertEquals(element("txt_mainGradingPageTitle").getText(), mainGradingPageTitle,
				"Assertion Failed: FNE Main Grading title is NOT correct");
		logMessage("Assertion Passed: User is on FNE Grading page, Verified FNE Main Grading title "
				+ "visibility and Title text to be: " + mainGradingPageTitle);
		
		switchToDefaultContent();
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}

	
	/**
	 * Method which verifies whether error message is displayed for newly added question
	 * in Homework activity when the student has attempted the activity once
	 * 
	 */
	public void verifyErrorMessageIsNotDisplayedForNewlyAddedQuestionInHomeworkActivity() {
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frame_contentFrame:frame_questionFrame");
		
		customAssert.customAssertEquals(isElementDisplayed("txt_errorMsgOnHomework"), false,
						"Assertion Failed: 'Unable to find homework group' Error message is getting "
								+ "displayed while attempting newly added question to Homework activity");
		
		logMessage("Assertion Passed: NO error message is displayed while attempting newly "
												+ "added question present in Homework activity!!!");
		switchToDefaultContent();
	}
	

	public void clickOnRetakeBtnOnQuiz() {
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frame_contentFrame:frame_questionFrame");
		
		waitForElementToBeVisible("btn_retakeBtnOnQuiz");
		element("btn_retakeBtnOnQuiz").click();
		logMessage("User clicked on 'Retake' button");
		
		switchToDefaultContent();
	}

	public void verifyQuestionIsDisplayed(String questionText, Boolean isDisplayed) {
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frame_contentFrame:frame_questionFrame");		
		String currentQuestion = element("txt_DetailAnswer").getText().replace("\n", " ");	
		customAssert.customAssertTrue(currentQuestion.contains(questionText),
				"Assertion Failed: Question text is not displayed");
		logMessage("Assertion Passed : Question text is displayed");
	}
	
	
	/**
	 * Method which adds questions to Quiz
	 *
	 * @param num - No. of questions to be added to Quiz
	 * 
	 */
	public void addSomeQuestionsInQuiz(int num) {
		int count = elements("chkbox_listQuestions").size();

		logMessage("No. of questions in the Exercise: " + count);

		if (num <= count) {
			logMessage("Adding " + num + " questions from Exercise to Quiz");
		} else {
			Assert.fail("Out of Questions: " + num + " questions are NOT available in the current Exercise!!!");
		}

		for (int i = 1; i <= num; i++) {
			element("chkbox_questionSelect" , String.valueOf(i)).click();
			logMessage("Instructor selected '" + (i) + "' question from the Exercise");
		}

		waitForElementToBeVisible("btn_gearbox");
		element("btn_addQuestionWrapper").click();
		logMessage("Instructor clicked on 'Add' button to add questions to the Quiz");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	
	/**
	 * Method which configures Assessment Settings of Quiz
	 * 
	 * @param assessmentSetting - Name of Assessment Setting
	 * @param radioOption - Radio option to be selected
	 * 
	 */
	public void configureAssessmentSettingsOfQuiz(String assessmentSetting, String radioOption) {
		int num = 0;
			
		if(radioOption.equalsIgnoreCase("Every attempt")) {
			num = 1;
		} else if(radioOption.equalsIgnoreCase("Due Date has passed")) {
			num = 2;
		} else if(radioOption.equalsIgnoreCase("Never")) {
			num = 3;
		}
		
		if(element("radio_optionOfAssessmentSetting", assessmentSetting, String.valueOf(num)).isSelected()) {
			logMessage("'" + radioOption + "' option for '" + assessmentSetting
					+ "' Assessment setting is ALREADY selected");
		} else {
			element("radio_optionOfAssessmentSetting", assessmentSetting, String.valueOf(num)).click();
			logMessage("User selected '" + radioOption + "' option for '"
					+ assessmentSetting + "' Assessment setting");
		}
	}
	
	
	/**
	 * Method which clicks on 'Save' button present on 'Settings' page
	 * 
	 */
	public void clickSaveButtonOnSettingsPage() {
		element("btn_saveContent").click();
		logMessage("Instructor clicked on 'Save' button");

		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}
	
	
	/**
	 * Method where student attempts the assigned Quiz for AA-215 Ticket
	 * 
	 */
	public void clickOnStartTheQuizButton() {		
		element("btn_startQuiz").click();
		logMessage("User click on 'Start the Quiz' button");

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}
	
	
	/**
	 * Method which clicks on 'Yes' button present on dialog box
	 * 
	 */
	public void clickOnYesButtonPresentOnDialogBox() {
		switchToDefaultContent();
		switchToNestedFrames("frm_mainFrame:frm_contentBody:frm_questionFrame"); 
		
		element("btn_YES").click();
		logMessage("User clicked on 'Yes' button present on the Dialog-box");

		switchToDefaultContent();
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}

	
	/**
	 * Method which verifies solution of questions as per Quiz Settings made by Instructor
	 * 
	 * @param status - Availability of solutions on Main Grading page
	 * @param count - No. of Solutions depending on the count of questions
	 * 
	 */
	public void verifySolutionsOfQuestionsAsPerQuizSettings(boolean status, int count) {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
		
		switchToDefaultContent();
		switchToFrame(element("frame_mainFrame"));
		
		logMessage("No. of Solutions on Grading page: " + elements("list_htsSolution").size());
		
		if (status) {
			customAssert.customAssertEquals(
					elements("list_htsSolution").size(), count,
							"[Assertion Failed]: Solution for all questions are NOT displayed !!!");
			logMessage("[Assertion Passed]: Solution for all questions are DISPLAYED as per Quiz Settings !!!");
		} else {
			
			logMessage("[Assertion Passed]: Solution for all questions are NOT DISPLAYED as per Quiz Settings !!!");
		}
		switchToDefaultContent();
	}

	
	/**
	 * Method which clicks on FnE 'Edit' action button
	 * 
	 * @param editOption - Edit action to be performed
	 * 
	 */
	public void clickOnFneEditActions(String editOption) {
		hover(element("lnk_fneEditActions"));
		logMessage("Hovered on FnE 'Edit' button");
		
		logMessage("No. of FnE Menu Options: " + elements("list_fneMenuTabs").size());
		
		for(WebElement elem : elements("list_fneMenuTabs")) {
			if(elem.getText().equalsIgnoreCase(editOption)) {
				logMessage("Clicked on '" + elem.getText() + "' menu Tab");
				elem.click();
				break;
			} else {
				 continue;
			}
		}
	}
	
	/**
	 * Fills Title Field(in Basic Info Tab)
	 *
	 * @param newTitle
	 */
	public void fillTitleOnBasicInfo(String newTitle) {
		waitForLoaderToDisappear();
		hardWait(1);
		waitForElementToBeVisible("inp_title");
		element("inp_title").clear();
		element("inp_title").sendKeys(newTitle);
		hardWait(1);
	}
	
	/**
	 * Fills SubTitle Field(in Basic Info Tab)
	 *
	 * @param newTitle
	 */
	public void fillSubTitleOnBasicInfo(String newTitle) {
		waitForLoaderToDisappear();
		hardWait(1);
		waitForElementToBeVisible("inp_title");
		element("inp_title").clear();
		element("inp_title").sendKeys(newTitle);
		hardWait(1);
	}

	
	/**
	 * Clicks 'Save' Button(in Basic Info Tab) and verifies Message Toast after
	 * Save.
	 */
	public void clickOnSaveButtonOnBasicInfo() {
		isElementDisplayed("btn_saveBasicInfo");
		waitAndClick("btn_saveBasicInfo");
		hardWait(2);
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		hardWait(2);
		logMessage("Successfully Saved");
	}
	
	// Clicks 'Questions' Tab(for Quiz type of Assignments)
	public void clickQuestionsTab() {
		isElementDisplayed("btn_questionsTab");
		clickUsingJavaScript("btn_questionsTab");
		hardWait(2);
		waitForLoaderToDisappear();
		logMessage("User clicked on Questions Tab");
	}
	
	// Get score in header of Homework Activity Page
	public String getScoreInHeader() {
		String points=element("getScoreInHeader").getText().trim();
		return points;
	}	
}
