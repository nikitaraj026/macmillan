package com.qait.AQE.keywords;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class CourseHomePageActions extends GetPage {

    public CourseHomePageActions(WebDriver driver) {
        super(driver, "CourseHomePage");
    }

    public void verifyUserIsOnCourseHomePage() {
        verifyUserIsOnCourseHomePage("LaunchPad");
    }

    /**
     * Method which verifies that user is on Course Home Page
     * 
     * @param courseName - Name of Course
     * @param courseHomePageTitle - Title of Course Home Page
     * 
     */
    public void verifyUserIsOnCourseHomePage(String courseName, String courseHomePageTitle) {
		isElementDisplayed("txt_courseHomePageTitle");
        assertEquals(element("txt_courseHomePageTitle").getText(),
        		courseName,
                "Assertion Failed: Course Home title is not correct.");
        logMessage("Assertion Passed: User is on Course Home Page, Verified Page title visibility and Title text to be: "
                + courseHomePageTitle);
    }
    
    /**
    * Method which verifies that user is on Course Home Page
    * 
    * @param courseHomePageTitle - Title of Course Home Page
    * 
    */
   public void verifyUserIsOnCourseHomePage(String courseHomePageTitle) {
       isElementDisplayed("txt_courseHomePageTitle");
       assertEquals(element("txt_courseHomePageTitle").getText(),
               courseHomePageTitle,
               "Assertion Failed: Course Home Title is not correct.");
       logMessage("Assertion Passed: User is on Course Home Page, Verified Page title visibility and Title text to be: "
               + courseHomePageTitle);
   }

    /**
     * Method which clicks on 'Add New' link & creates an Assignment of Type Quiz
     * 
     * @param assignmentType
     *  
     */
    public void startCreatingNewAssignment(String assignmentType) {
        element("button_addAssignment").click();
		logMessage("Instructor clicked on 'Add New' button");

        element("link_newAssignmentType", assignmentType).click();
        logMessage("Instructor created New Assignment of Type: " + assignmentType);
        
        waitForLoaderToDisappear();
        waitForMsgToastToDisappear();
    }
    
    /**
     * Method which instructor switches to student view on Course Home Page
     * 
     */
	public void switchToStudentView() {
		/*System.out.println(element("link_previewAsStudent").getText());
		assertEquals(element("link_previewAsStudent").getText(),
						"Preview as Student",
							"Assertion Failed: 'Preview as Student' link text is not correct.");
		scrollUpToElement(element("link_previewAsStudent"));*/
		
		scrollDown(element("link_previewAsStudent"));
		element("link_previewAsStudent").click();
		logMessage("Instructor clicked on 'Preview as Student' link");
		
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
	}
		
	/**
	 * Method which User clicks on the Assigned Quiz
	 * 
	 */
//    public void clickOnTheAssignedQuiz() {
//		waitForLoaderToDisappear();
//		waitForMsgToastToDisappear();
//		
//		isElementDisplayed("link_assignedQuiz");
//		
//		element("link_assignedQuiz").click();
//		logMessage("User clicked on Assigned Quiz");
//		
//		waitForLoaderToDisappear();
//		waitForMsgToastToDisappear();
//    }
    
    public void clickOnTheAssignedTOCItem(String itemName) {
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		scrollToTop();
		waitScrollAndClick("link_assignedItemTOC", itemName);
		logMessage("Clicked TOC Item '" + itemName + "'");
		waitForLoaderToDisappear();
    }


    /**
     * User Signs Out of the application
     * 
     */
    public void clickOnSignOut() {
    	waitForLoaderToDisappear();
    	waitForMsgToastToDisappear();
    	
    	scrollDown(element("drpdown_userLoggedIn"));
    	executeJavascript("document.getElementsByClassName('hidden-menu profileMenu')[0].style='display: block;'");
    	hover(element("drpdown_userLoggedIn"));
    	
    	element("drpdown_optionSelect", "Sign Out").click();
		logMessage("User clicked in 'Sign Out' button");
		
		waitForMsgToastToDisappear();
		waitForLoaderToDisappear();
    }
    
    /**
	 * Selects specific option from Account Action Drop down
	 * 
	 * @param text
	 * 
	 */
	public void selectOptionFromAccountActionDropdown(String accountAction) {
		waitForLoaderToDisappear();
		wait.waitForProgressBarToDisappear();
		waitForLoaderToDisappear();
		
		hover(element("drpdown_userLoggedIn"));
		element("drpdown_optionSelect", accountAction).click();

		waitForLoaderToDisappear();
		wait.waitForProgressBarToDisappear();
		waitForLoaderToDisappear();
	}
	
	/**
     * Method which closes Notification Toast Message
     * 
     */
    public void closeNotificationMessage(){
    	try {
			for (int i = 0; i < 2; i++) {
				if(element("btn_toastClose").isDisplayed()){
					hoverClick(element("btn_toastClose"));
					logMessage("Notification Toast message clicked " + (i+1) + " time");
					hardWait(1);
				}else{
					logMessage("Closed all Notification Toast messages present on FnE page");
				}
			}
		} catch (NoSuchElementException e) {
			logMessage("Notification Toast Message did NOT appear OR have been closed!!!");
		}
    }
    
    /**
     * Method which verifies Assigned Quiz is available to the student
     * 
     * @param txtQuiz - Name of the Quiz
     * 
     */
	public void verifyAssignedQuizIsVisible(String txtQuiz) {
		isElementDisplayed("link_assignedQuiz");
		
		assertEquals(element("link_assignedQuiz").getText(),
				txtQuiz,
                "Assertion Failed: Assigned Quiz Name is not correct.");
		
		logMessage("Assertion Passed: User is on Course HomePage, Verified Quiz Title text to be: "
                + txtQuiz);
	}
	
	/**
	 * Click 'Add New' Link
	 */
	public void clickAddNewLink() {
		isElementDisplayed("link_addNew");
		clickUsingJavaScript("link_addNew");
		logMessage("Clicked 'Add New' Link");
	}
	
	/***************************************************
	 * 1. CREATE NEW ASSIGNMENT MODAL : BASIC OPERATIONS
	 * a. Click
	 ***************************************************/

	/**
	 * Click specified Assignment Type from 'Create a New Assignment' Modal
	 */
	public void clickAssignmentType(String assignmentType) {
		waitAndClick("link_assignmentType", assignmentType);
	}

	
}
