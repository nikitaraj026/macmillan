package com.qait.AQE.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

import static org.testng.Assert.assertEquals;

public class CreateCourseModalActions extends GetPage {

	String courseName = "testAutomation";
	String schoolName = "Baruch College CUNY";
	String academicTerm = "";

	public CreateCourseModalActions(WebDriver driver) {
		super(driver, "CreateCourseModalPage");
	}

	public void verifyCreateCourseOptionsModalWindow() {
		isElementDisplayed("txt_courseOptionHeader");
		
		assertEquals(element("txt_courseOptionHeader").getText(),
				"Create Course",
				"ASSERTION FAILED: Create Course Header not present");
		logMessage("Assertion Passed: Checked 'Create Course' option heading visibilty and text");
	}

	public void selectCreateCourseOnExitingCourse(String option) {
		waitAndClick("radiobutton_createCourseOption", option.toLowerCase());
		/*wait.waitForElementToBeVisible(
				element("radiobutton_createCourseOption", option.toLowerCase()))
				.click();*/
		logMessage("Instructor clicked on 'No' radio button present on Create Course "
				+ "window to wish NOT to copy an existing course");
	}

	public void clickModalButton(String buttonText) {
		wait.waitForElementToBeClickable(
				element("button_courseOptionDialog", buttonText)).click();
		wait.waitForElementToBeInVisible(getLocator(
				"button_courseOptionDialog", buttonText));
	}

	public void createNewCourseBasedOnExisting(String option) {
		selectCreateCourseOnExitingCourse(option);
		clickModalButton("Next");
		
		element("inp_newCourseTitle").clear();
		logMessage("Instructor cleared the DEFAULT value of Course Title");
		element("inp_newCourseTitle").sendKeys(this.courseName);
		logMessage("Instructor entered '" + this.courseName + "' Title for new course");
		
		element("inp_newCourseSchoolName").clear();
		logMessage("Instructor cleared the DEFAULT value of School Name");
		
		fillText(element("inp_newCourseSchoolName"), this.schoolName);
		//sendKeys(wait.waitForElementToBeVisible(element("inp_newCourseSchoolName")), this.schoolName);
		logMessage("Instructor entered '" + this.schoolName + "' School name from the dropdown");
		
		//scrollDown(element("btn_courseSaveCancel", "Create"));
		element("btn_courseSaveCancel", "Create").click();
		logMessage("Instructor clicked on 'Create' button");
		waitForLoaderToDisappear();
	}

	public void setNewCourseDetails(String courseName, String schoolName) {
		setNewCourseDetails(courseName, schoolName, null);
	}

	public void setNewCourseDetails(String courseName, String schoolName,
			String academicTerm) {
		this.courseName = courseName;
		this.schoolName = schoolName;
	}
	
}
