package com.qait.AQE.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

import static org.testng.Assert.assertEquals;

public class WelcomePageActions extends GetPage {
	
	public WelcomePageActions(WebDriver driver) {
		super(driver, "WelcomePage");
	}

	public void verifyUserIsOnWelcomePage(){
		verifyUserIsOnWelcomePage("Welcome to LaunchPad!");
	}
	
	public void verifyUserIsOnWelcomePage(String welcomePageTitle) {
		isElementDisplayed("txt_welcomePageTitle");
		assertEquals(element("txt_welcomePageTitle").getText(),
				welcomePageTitle,
				"Assertion Failed: Welcome Page title is not correct.");
		logMessage("Assertion Passed: User is on Welcome Page, Verified Page title visibility and text to be: "
				+ welcomePageTitle);
	}
	
	public void enterCourseFromWelcomePage(){
		isElementDisplayed("button_enterCourse");
		executeJavascript("document.getElementsByClassName('EnterCourse')[0].click()");
		logMessage("User clicked on 'Enter Course' button");
		waitForLoaderToDisappear();
	}
	
}
