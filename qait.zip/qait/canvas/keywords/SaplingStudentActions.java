package com.qait.canvas.keywords;

import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.gdata.data.dublincore.Date;
import com.qait.automation.getpageobjects.GetPage;

public class SaplingStudentActions extends GetPage {

	public SaplingStudentActions(WebDriver driver) {
		super(driver, "SaplingStudentAction");
	}

	public void studentAttemptFlowUptoQuestion(String value, String answer) {
		hardWait(4);
		waitForElementToBeVisible("btn_submit");
//		isElementDisplayed("btn_submit",value);
//		waitAndClick("btn_submit", value);
		executeJavascript("document.querySelector('.singlebutton input[value=\"Yes\"]').click()");
		waitAndClick("bnt_freeTrial");
		waitAndClick("btn_continueEnroll");
//		sendKeys(element("input_InstitutionName"), "Sapling Learn");
//		wait.hardWait(3);
		element("input_InstitutionName").click();
		sendKeys(element("input_InstitutionName"), "Sapling Learn");
		//element("input_InstitutionName").click();
		hardWait(2);
		element("input_InstitutionName").sendKeys("i");
		hardWait(3);
		//element("input_InstitutionName").click();
		waitAndClick("dropdown_textSaplingLearning");
		waitAndClick("btn_OK");
		hardWait(6);
		waitAndClick("link_question");
		switchToFrame("iframe_question");
		List<WebElement> list = elements("list_question");
		for (int i = 0; i < list.size(); i++) {
			wait.hardWait(4);
			String labelValue = (String) executeJavascript(
					"return document.querySelectorAll('label.sl-list-label')[" + i + "].textContent");
			if (labelValue.equals(answer)) {
				wait.hardWait(4);
				list.get(i).click();
				break;
			}
		}
		waitAndClick("btn_checkAnswer");
		closeWindow();
		changeWindow(0);
		logMessage("Clicked on " + value + " button");
	}
}