package com.qait.canvas.keywords;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Window;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.github.scribejava.apis.VkontakteApi;
import com.google.gdata.data.dublincore.Date;
import com.qait.automation.getpageobjects.GetPage;

public class AchieveAdminActions extends GetPage {

	AchieveInstructorActions achieveinstraction = new AchieveInstructorActions(driver);

	public AchieveAdminActions(WebDriver driver) {
		super(driver, "AchieveAdminAction");
	}

	ToolsPageAction toolspageaction = new ToolsPageAction(driver);

	public void login_TO_Achieve(String username, String password) {
		waitForElementToBeVisible("btn_signIn");
		waitAndClick("btn_signIn");
		waitForElementToBeVisible("input_username");
		element("input_username").sendKeys(username);
		waitForElementToBeVisible("input_password");
		element("input_password").sendKeys(password);
		waitAndClick("btn_logIn");
		logMessage("Successfully logged into Achieve");
	}

	public String copy_Course(String tempName, String tempCode) {
		waitAndClick("start_Copy_Course");
		waitAndClick("copy_Of_Course");
		hardWait(3);
		// choose_Option_from_CourseType("Course");
		// choose_Option_From_ProductModel("Read & Practice");
//		String courseNameRP = "R&PCourse" + CustomFunctions.generateUniqueString(2);
		element("input_copycourseName").clear();
		hardWait(2);
		element("input_copycourseName").sendKeys(tempName);
		hardWait(2);
		element("input_copycode").clear();
		hardWait(2);
		element("input_copycode").sendKeys(tempCode);

		// waitAndClick("chkbox_Sunday");
		waitAndClick("chkbox_Monday");
		waitAndClick("drpdwn_copyCourse");
		Select dropdown1 = new Select(element("drpdwn_copyCourse"));
		/*
		 * dropdown1.selectByVisibleText("Spring");
		 * 
		 * waitAndClick("drpdwn_copycourseyear"); Select dropdown2 = new
		 * Select(element("drpdwn_copycourseyear"));
		 * dropdown2.selectByVisibleText("2019"); waitAndClick("copy_courseStatus");
		 * Select dropdown = new Select(element("copy_courseStatus"));
		 */
		dropdown1.selectByVisibleText("Active On Date");
		click(element("btn_forDate"));
		logMessage("Clicked on btn_forDate");
		hardWait(4);
		waitAndClick("btn_endDate");
		selecting_CourseEndDate();
		hardWait(3);
		waitAndClick("btn_saveCourse");
		hardWait(4);
		logMessage("Course -> " + tempName + "With Course Code ->" + tempCode + "Created Successfully");
		waitAndClick("click_on_course");
		return tempName;
	}

	public void Admin_Create_Course(String courseName, String courseCode) {
		waitAndClick("btn_addCourseAndTemplate");
		choose_Option_from_CourseType("Course");
		choose_Option_From_ProductModel("Read & Practice");
//		String courseNameRP = "R&PCourse" + CustomFunctions.generateUniqueString(2);
		element("input_courseName").sendKeys(courseName);
		element("input_courseCode").sendKeys(courseCode);
		waitAndClick("chkbox_Sunday");
		waitAndClick("chkbox_Monday");
		waitAndClick("drpdwn_courseTerm");
		Select dropdown1 = new Select(element("drpdwn_courseTerm"));
		dropdown1.selectByVisibleText("Spring");

		waitAndClick("drpdwn_courseYear");
		Select dropdown2 = new Select(element("drpdwn_courseYear"));
		dropdown2.selectByVisibleText("2018");
		waitAndClick("drpdown_courseStatus");
		Select dropdown = new Select(element("drpdown_courseStatus"));
		dropdown.selectByVisibleText("Active On Date");
		click(element("btn_forDate"));
		logMessage("Clicked on btn_forDate");
		hardWait(4);
		waitAndClick("btn_endDate");
		selecting_CourseEndDate();
		hardWait(3);
		waitAndClick("btn_saveCourse");
		hardWait(4);
		logMessage("Course -> " + courseName + "With Course Code ->" + courseCode + "Created Successfully");
	}

	public void find_TestCourse(String courseName) {
		search_By_TemplateName(courseName);
		hardWait(3);
		System.out.println(courseName + "++++++++++============");
		String inputSearch = "document.querySelector(\"input[placeholder='Search for Course']\").value=" + "\""
				+ courseName + "\"";
		executeJavascript(inputSearch);
		assertTrue(is_MoreBtn_Visible(), "ReadAndPractice Course Found");
		logMessage("Course ->" + courseName + "  Successfully Found");

	}

	public void create_template(String tempName, String tempCode, String tempisbn) {
		waitAndClick("clickon_course_temp");
		hardWait(2);
		waitAndClick("btn_addCourseAndTemplate");
		choose_Option_from_CourseType("Template");
		choose_Option_From_ProductModel("Read & Practice");
		hardWait(3);
		element("input_courseName").sendKeys(tempName);
		element("input_courseCode").sendKeys(tempCode);
		element("input-isbn").sendKeys(tempisbn);
		hardWait(3);
		Select dropdown = new Select(element("drpdown_courseStatus"));
		dropdown.selectByVisibleText("Active On Date");
		click(element("btn_forDate"));
		logMessage("Clicked on btn_forDate");
		hardWait(3);
		waitAndClick("btn_saveCourse");

	}

	public void input_Content(String tempName) {
		assertTrue(element("click_On_Found1", tempName).isDisplayed(), "course name is not displayed");
		hardWait(4);
		waitAndClick("click_On_Found1", tempName);
		hardWait(3);
		element("clickOnProdcution").click();
		element("contentType").click();

		assertTrue(element("Learning_Curve").isDisplayed(), "Learning_Curve is not displayed");
		hardWait(2);
		waitAndClick("Learning_Curve");
		waitAndClick("keyboard_Search");
		element("search_input").sendKeys("apostrophes");
		element("search_input").sendKeys(Keys.ENTER);
		hardWait(2);
		hoverClick(elements("add_to_Library").get(0));

		assertTrue(element("added_to_library").isDisplayed(), "apostrophie is not added into library");
		logMessage("click on add to library");
		hardWait(3);
		element("unclick_on_Learning").click();
		hardWait(2);
		waitAndClick("Reading");
		hardWait(3);
		waitAndClick("button_Apply");
		hoverClick(elements("add_to_Library").get(0));

		waitAndClick("backtoCourse");
		waitAndClick("img_Achieve_Logo");
		waitAndClick("clickon_course_temp");
		find_TestCourse(tempName);

	}

	public void create_Content(String courseName) {
		hardWait(3);
//		element("input_searchField").sendKeys(courseName);
		// System.out.println(courseName);
		// String inputSearch = "document.querySelector(\"input[placeholder='Search for
		// Course']\").value="+"\""+courseName+"\"";
		// executeJavascript(inputSearch);
		assertTrue(element("click_On_Found", courseName).isDisplayed(), "course name is not displayed");
		waitAndClick("click_On_Found", courseName);
		assertTrue(element("img_Achieve_Logo").isDisplayed(), "achieve logo is not displayed");
		waitAndClick("click_On_browse");
		waitAndClick("Learning_Curve");

		assertTrue(element("btn_Addcontent").isDisplayed(), "added button is not displayed");
		hoverClick(elements("btn_Addcontent").get(0));
		hardWait(3);
		waitAndClick("Reading");
		assertTrue(element("btn_Addcontent").isDisplayed(), "added button is not displayed");
		hardWait(4);
		hoverClick(elements("btn_Addcontent").get(0));
		hardWait(3);
		element("my_Course").click();
		;

		// clickUsingJavaScript("btn_Addcontent");
	}

	public void assignAssigments() {

		List<WebElement> coursePlan = elements("course_Plan", "COURSE PLAN");
		if (coursePlan.size() == 0) {
			toolspageaction.addContentToCourse();
		} else {
			achieveinstraction.removeAllPreviousAssignments();
			toolspageaction.addContentToCourse();
		}
		waitForElementToBeVisible("course_Plan", "COURSE PLAN");
		isElementDisplayed("course_Plan", "COURSE PLAN");
		hardWait(4);
		click(element("course_Plan"));
		List<WebElement> Assignments = elements("both_Assign");
		System.out.println(Assignments + "+============");
		for (int i = 0; i < Assignments.size(); i++) {
			waitForElementToBeClickable((Assignments.get(i)));
			click(Assignments.get(i));
			hardWait(3);
			useAssignToStudents();
			waitForElementToBeVisible("inpt_Points");
			isElementDisplayed("inpt_Points");
			fillText("inpt_Points", "30");
			hardWait(6);
			clickSaveBtn();
			hardWait(12);
		}
		waitAndClick("img_Achieve_Logo");
	}

	public void useAssignToStudents() {
		waitForElementToBeVisible("radio_Assign");
		isElementDisplayed("radio_Assign");
		waitAndClick("radio_Assign");
	}

	public Boolean is_MoreBtn_Visible() {
		return element("btn_moreOnTemplate").isDisplayed();
	}

	public void search_By_TemplateName(String name) {

		element("input_searchField").sendKeys(name);
		hardWait(3);

	}

	public void selecting_CourseEndDate() {
		WebElement calender = element("btn_endDate");
//		int tomorrowdate = getCurrentDay() + 1;
//		String tomorrowdateinString = Integer.toString(tomorrowdate);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("var first = {" + "  second: function myFunc7(){"
				+ "document.getElementsByClassName('_85v4 _3Fin').item(0).click();"
				+ "document.getElementsByClassName('_2oPS  ').item(9).click();" + "}};" + "   first.second();");

	}

	public void choose_Option_from_CourseType(String myoption) {
		waitAndClick("drpdown_courseType");
		Select dropdown = new Select(element("drpdown_courseType"));
		dropdown.selectByVisibleText(myoption);
	}

	public void choose_Option_From_ProductModel(String myoption) {
		waitAndClick("drpdown_productModel");
		Select dropdown = new Select(element("drpdown_productModel"));
		dropdown.selectByVisibleText(myoption);
	}

	public void editTestCourseDetails() {
		waitAndClick("btn_moreOnTemplate");
		waitAndClick("option_edit_Course");
		hardWait(5);
		element("edit_courseName").sendKeys("_Edited");
		element("edit_courseCode").sendKeys("_Edited");
		waitAndClick("btn_saveCourse");

	}

	public void click_On_Course() {
		waitAndClick("active_course");
	}

	public void add_Activity() throws InterruptedException, AWTException {
		hardWait(3);
		click_On_Course();
		waitForPageToLoadCompletely("Macmillan Learning Achieve");
		waitAndClick("link_resources");
		hardWait(3);
		waitAndClick("btn_addActivity");
		search_Data("d");
		hardWait(3);
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_ENTER);
		hardWait(3);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollTo(1400,0);", "");

		// scroll(element("btn_plusActivity"));
		hardWait(4);
		waitForElementToBeVisible("btn_plusActivity");
		waitAndClick("btn_plusActivity");

		hardWait(6);
		waitForElementToBeVisible("btn_Addedvisible");
		waitAndClick("btn_close");

		hardWait(6);
		assertTrue(is_AddedActivityVisible());
		hardWait(2);
		waitAndClick("img_Achieve_Logo");
		hardWait(5);
	}

	public boolean is_AddedActivityVisible() {
		return element("added_table_row").isDisplayed();
	}

	public void search_Data(String mydata) {
		element("searchTab_activity").sendKeys(mydata);
	}

	public void delete_Course() {
		hardWait(5);
		waitAndClick("btn_moreOnTemplate");
		waitAndClick("option_delete_Course");
		hardWait(2);
		click(element("btn_confirmDelete"));
		logMessage("Clicked on btn Yes Delete ");
	}

	public void verify_Enroll_Instructor_Modal_Window() {
		waitAndClick("btn_moreOnTemplate");
		waitAndClick("option_from_More", "Manage Instructors");
		hardWait(3);
		isElementDisplayed("txt_Add_Inst_By_Email");
		isElementDisplayed("inpt_instructor_Email");
		isElementDisplayed("btn_Add");
		isElementDisplayed("btn_close_Modal_Window");
//		waitAndClick("btn_close_Modal_Window");

	}

	public void add_Instructor_Email(String email) {
		fillText("inpt_instructor_Email", email);
		waitAndClick("btn_Add");
		hardWait(4);

	}

	public void remove_Instructor(String email) {
		hardWait(3);
		waitAndClick("btn_delete_Instructor", email);
		hardWait(3);
		waitAndClick("btn_close_Modal_Window");
	}

	public void clickSaveBtn() {
		waitForElementToBeVisible("btn_Save");
		waitAndClick("btn_Save");
		logMessage("Clicked on Save Button");
	}

	public void click_On_FoundCourse(String courseName) {
		assertTrue(element("click_On_Found", courseName).isDisplayed(), "course name is not displayed");
		waitAndClick("click_On_Found", courseName);
	}
}
