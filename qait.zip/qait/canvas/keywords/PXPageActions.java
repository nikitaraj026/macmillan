package com.qait.canvas.keywords;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.canvas.keywords.FandEPageActions;
import com.qait.automation.getpageobjects.GetPage;

public class PXPageActions extends GetPage {

	public FandEPageActions fnePage;

	public PXPageActions(WebDriver driver) {
		super(driver, "PXPage");
		fnePage = new FandEPageActions(driver);
	}

	public void verifyPxFnePageOpens() {
		handleAlert();
		isElementDisplayed("button_Home");
		logMessage("[Assertion Passed]: User is on the PX FNE Page");
	}

	public void userClosesPXWindow() {
		closeWindow();
		changeWindow(1);
	}

	public void userClosesPXWindowAndGoToPrimaryWindow() {
		closeWindow();
		changeWindow(0);
	}

	public void verifyPXCourseHomePage() {
		isElementDisplayed("label_LaunchPad");
		logMessage("User verifies that he is on a launchpad course home page");
	}

	/**
	 * Verifies that Course Home page is displayed by checking Title of page is as
	 * specified as argument
	 * 
	 * @param courseHomePageTitle
	 */
	public void verifyUserIsOnCourseHomePage(String courseHomePageTitle) {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("txt_courseHomePageTitle");
		System.out.println(element("txt_courseHomePageTitle").getText());
		customAssert.customAssertEquals(element("txt_courseHomePageTitle").getText(), courseHomePageTitle,
				"Assertion Failed: Course Home Page title is not correct.");
		logMessage("Assertion Passed: User is on Course HomePage, Verified Page title visibility and Title text to be: "
				+ courseHomePageTitle);
	}

	public void verifyEbookSectionIsOpen() {
		hardWait(3);
		isElementDisplayed("list_ebook");
		logMessage("User verfies that he is navigated to the ebook section");
	}

	public void verifyGradeBookPageOpens() {
		switchToFrame(element("iframe_easyXDMDefault"));
		isElementDisplayed("breadCrumb_Gradebook");
		switchToDefaultContent();
		logMessage("User is on the Gradebook page");
	}

	public void assignPXContent(String points) {
		clickOnEditButton();
		clickAssignmentTab();
		selectDateInDatePicker();
		fillGradePointsForAssignment(points);
		clickAssignButtonFromAssignmentTab();
		clickOnDoneEditingButton();
	}

	public void selectDateInDatePicker() {
		waitForElementToBeVisible("datePicker_goNext");
		element("datePicker_goNext").click();
		waitForElementToBeVisible("datePicker_date");
		element("datePicker_date").click();
	}

	public void fillGradePointsForAssignment(String points) {
		waitForElementToBeVisible("txtinput_gradePoints");
		element("txtinput_gradePoints").click();
		element("txtinput_gradePoints").clear();
		element("txtinput_gradePoints").sendKeys(points);
	}

	public void clickAssignButtonFromAssignmentTab() {
		if (elements("btn_assignInAssignmentTab").size() == 1) {
			waitForElementToBeVisible("btn_assignInAssignmentTab");
			element("btn_assignInAssignmentTab").click();
			hardWait(5);
			handleAlert();

			waitForElementToBeVisible("btn_unassignInAssignmentTab");
			waitForMsgToastToDisappear();
		} else {
			element("btn_saveChanges").click();
			hardWait(5);
			waitForLoaderToDisappear();
			waitForMsgToastToDisappear();
		}
	}

	public void clickOnDoneEditingButton() {
		waitForMsgToastToDisappear();
		element("btn_done").click();
		handleAlert();
		logMessage("User Clicked on Done button");
		waitForLoaderToDisappear();
	}

	public void clickOnHomeButton() {
		waitForElementToBeVisible("btn_quiz_home");
		element("btn_quiz_home").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void quizcreationDoneEditingButton() {
		waitForMsgToastToDisappear();
		element("btn_doneEditing").click();
		handleAlert();
		logMessage("User Clicked on Done button");
		waitForLoaderToDisappear();
	}

	public void clickOnEditButton() {
		waitForLoaderToDisappear();
		scrollDown(element("dropdown_edit"));
		element("dropdown_edit").click();
		logMessage("User clicked Edit button");
		waitForLoaderToDisappear();
	}

	public void clickAssignmentTab() {
		hardWait(3);
		waitForElementToBeVisible("btn_assignmentTab");
		element("btn_assignmentTab").click();
		waitForLoaderToDisappear();

		logMessage("User clicked on Assignment Tab");
		waitForElementToBeVisible("txt_dueDateAndTime");
	}

	public void deleteContent(String contentName) {
		waitForElementToBeVisible("link_chapterContentName", contentName);
		scrollDown(element("link_chapterContentName", contentName));

		waitForLoaderToAppear();
		hover(element("link_chapterContentName", contentName));
		hover(element("link_contentGearbox", contentName));

		element("link_contentGearbox", contentName).click();
		scrollDown(element("link_removeInGearbox"));
		element("link_removeInGearbox").click();
		waitForElementToBeVisible("btn_removeOnRemoveActivityDialog");
		element("btn_removeOnRemoveActivityDialog").click();
	}

	public void verifyBrokenLinkErrorMessage() {
		isElementDisplayed("txt_brokenLinkTopErrorMessage");
		customAssert.customAssertTrue(element("txt_brokenLinkTopErrorMessage").getText()
				.contains("We could not initialize your launch request"), "Broken link message is incorrect");
		isElementDisplayed("txt_brokenLinkErrorMessage");
	}

	public void addNewQuiz(String chapterName) {
		waitForLoaderToDisappear();
		scrollDown(element("button_addAssignment", chapterName));
		element("button_addAssignment", chapterName).click();
		// scrollDown(element("link_createNewAssignment"));
		element("link_createNewAssignment").click();
		element("link_newAssignmentType", "Quiz").click();
		waitForLoaderToDisappear();
	}

	public String changeTitleAndAddQuestions() {
		waitForElementToBeVisible("inp_title");
		element("inp_title").clear();
		String quizTitle = "Quiz" + System.currentTimeMillis();
		element("inp_title").sendKeys(quizTitle);
		element("btn_saveBasicInfo").click();
		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
		logMessage("Title of Assignment changed");
		return quizTitle;
	}

	public void addQuestion() {
		waitForElementToBeVisible("btn_questionsTab");
		element("btn_questionsTab").click();
		waitForLoaderToDisappear();

		waitForElementToBeVisible("btn_chapter1QuestionBank");
		element("btn_chapter1QuestionBank").click();
		waitForLoaderToDisappear();

		waitForElementToBeVisible("btn_testBank1Chapter1");
		element("btn_testBank1Chapter1").click();
		waitForLoaderToDisappear();

		waitForElementToBeVisible("drpdown_selectMenu");
		waitForElementToBeVisible("questionCheckBox");
		element("questionCheckBox").click();

		waitForElementToBeVisible("btn_add");
		element("btn_add").click();

		waitForLoaderToDisappear();
		waitForMsgToastToDisappear();
	}

	public void attemptQuizAndClickSubmit() {
		switchToDefaultContent();
		_clickStartTheQuizButton();
		switchToCourseContentFrame();
		selectOptionOneForQuestion();
		clickSubmit();
		submitYesInConfirmDialogBox();
		switchToDefaultContent();
		waitTillSuccessullySubmitted();
		logMessage("Attempted Quiz Assignment");
		waitForElementToBeVisible("btn_doneEditing");
		waitAndClick("btn_doneEditing");
		waitForLoaderToDisappear();
	}

	private void _clickStartTheQuizButton() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("btn_home");
		waitForElementToBeVisible("btn_startTheQuiz");
		element("btn_startTheQuiz").click();
		logMessage("User Clicked on 'Start the Quiz' button");
		waitForLoaderToDisappear();
	}

	/**
	 * Switches to easyXDMDefault Frame then to Content Body Frame and then to
	 * Course Content Frame
	 * 
	 */
	public void switchToCourseContentFrame() {
		switchToDefaultContent();
		hardWait(5);
		switchToFrame(element("iframe_easyXDMDefault"));
		switchToFrame(element("iframe_contentBody"));
		switchToFrame(element("iframe_courseContentFrame"));
	}

	// Selects Option 1 radio button for Quiz/Homework Question's Answer
	public void selectOptionOneForQuestion() {
		waitForElementToBeVisible("radio_option1");
		element("radio_option1").click();
	}

	// Submits the Quiz/Homework
	public void clickSubmit() {
		waitForElementToBeVisible("btn_submitQuiz");
		element("btn_submitQuiz").click();
	}

	// Clicks Yes in Confirm Dialog Box
	public void submitYesInConfirmDialogBox() {
		waitForElementToBeVisible("confirmDialogTitle");
		element("btn_yesConfirmDialog").click();
		waitForLoaderToDisappear();
	}

	// Waits till Quiz/Homework is successfully submitted
	public void waitTillSuccessullySubmitted() {
		waitForMsgToastToDisappear();
		logMessage("Quiz or Homework was successfully submitted");
		waitForLoaderToDisappear();
	}

	public String getGrade() {
		return element("txt_achievedPoints").getText();
	}

	public void expandPXChapter(String chaptername) {
		waitForElementToBeVisible("link_itemTOC", chaptername);
		// scrollIntoView(element("link_itemTOC",chaptername));
		element("link_itemTOC", chaptername).click();
	}

	public void requestInstructorAccess(String email, String firstname, String lastname, String zipcode, String school,
			String repUsername, String repPassword) {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("txtBox_email");
		element("txtBox_email").sendKeys(email + Keys.RETURN);
		switchToFrame(element("iframe_mars"));
		waitAndClick("radiobtn_salesRep");
		fillText(element("input_rep_username"), repUsername);
		fillText(element("input_rep_password"), repPassword);
		fillText(element("input_instructor_email"), email);
		waitAndClick("btn_next_navigate_to_next_page");
		waitForJqueryToFinish();
		fillText(element("input_inst_firstname"), firstname);
		fillText(element("input_inst_lastname"), lastname);
		fillText(element("input_password"), "123456");
		fillText(element("input_comfirmPassword"), "123456");

		fillText(element("input_txtZipCode"), zipcode);
		waitAndClick("btn_searchNow");
		hardWait(5);
		waitForJqueryToFinish();
		selectProvidedTextFromDropDown(element("list_institution"), school);
		hardWait(2);
		waitForJqueryToFinish();
		waitAndClick("option1");
		hardWait(2);
		selectProvidedTextFromDropDown(element("list_position"), "Instructor");
		waitAndClick("chkbox_IAccept");
		waitAndClick("btn_submit");
		waitForJqueryToFinish();
		waitForElementToBeVisible("btn_proceedToWebsite");
		hardWait(3);
		waitForJqueryToFinish();
		// isElementDisplayed("btn_proceedToWebsite");

		element("btn_proceedToWebsite").click();
		switchToDefaultContent();
		logMessage("Instructor with email id" + " " + email + " " + "request instructor access");
	}

	public void createCourse() {
		waitForLoaderToAppearAndDisappear();
		waitForElementToBeVisible("link_createCourse");
		scrollDown(element("link_createCourse"));
		element("link_createCourse").click();
		logMessage("Clicked Create Course Link");
		element("btn_nextCreateCourse").click();
		logMessage("Clicked Create Course 'Next' Button");
		fillText("txtbox_school", "TEST University - Roscoe, MT");
		// element("select_school").click();
		element("btn_createCreateCourse").click();
		logMessage("Clicked Create Course 'Next' Button");
		waitForLoaderToDisappear();
		hardWait(5);
		waitForElementToBeVisible("activate_course");
		element("activate_course").click();
		waitForElementToBeVisible("btn_activate");
		element("btn_activate").click();
		waitForElementToBeVisible("btn_done");
		element("btn_act_done").click();
	}

	public void pxLogin(String email, String user, String password, String px_pwd, String zip, String school) {
		fillText(element("rqst_inst_access"), email);
		element("btn_go").click();
		isElementDisplayed("verify_RIA_page");
		// driver.getPageSource().contains("Request Instructor Access");
		element("radiobtn_mac_emp").click();
		fillText(element("mac_emp_username"), user);
		fillText(element("mac_emp_pwd"), password);
		element("btn_next_navigate_to_next_page").click();

		isElementDisplayed("verify_IR_page");
		fillText(element("input_inst_firstname"), "FIName");
		fillText(element("input_inst_lastname"), "LIName");
		fillText(element("input_password"), px_pwd);
		fillText(element("input_comfirmPassword"), px_pwd);
		fillText(element("input_txtZipCode"), zip);
		element("btn_searchNow").click();
		hardWait(5);
		waitForJqueryToFinish();
		selectProvidedTextFromDropDown(element("list_institution"), school);
		hardWait(2);
		waitForJqueryToFinish();
		waitAndClick("option1");
		hardWait(2);
		selectProvidedTextFromDropDown(element("list_position"), "Instructor");
		waitAndClick("chkbox_IAccept");
		waitAndClick("btn_submit");
		waitForJqueryToFinish();
		waitForElementToBeVisible("btn_proceedToWebsite");
		hardWait(3);
		waitForJqueryToFinish();
		// isElementDisplayed("btn_proceedToWebsite");

		element("btn_proceedToWebsite").click();
		switchToDefaultContent();
		logMessage("Instructor with email id" + " " + email + " " + "request instructor access");
	}

	public void courseAssociation(String email, String px_pwd) {
		element("txt_inst_email").getText().contains(email);
		fillText(element("ent_px_pwd"), px_pwd);
		element("pwd_go").click();

		isElementDisplayed("token_reg");
		element("canvas_authenticate").click();

		isElementDisplayed("canvas_authorize");
		element("btn_authorize").click();

		isElementDisplayed("token_reg");
		element("btn_continue").click();

		isElementDisplayed("btn_view_prtl_cls");
		isElementDisplayed("btn_view_lp_courses");
		isElementDisplayed("btn_refresh");
		isElementDisplayed("btn_create_course");
		element("btn_associate").click();
		element("btn_yes_associate").click();
		element("btn_ok_associate").click();

	}

	public void createAssignment(String Quiz) {
		waitForElementToBeVisible("btn_create_quiz");
		element("btn_create_quiz").click();
		element("select_quiz_assignment").click();
		waitForElementToBeVisible("quiz_title");
		fillText("quiz_title", Quiz);
		isElementDisplayed("btn_save_basic_info");
		element("btn_save_basic_info").click();
		hardWait(5);
		element("lnk_quiz_questions").click();
		hardWait(5);
	}

	/**
	 * Click 'Add New' Link
	 */
	public void clickAddNewLink() {
		wait.waitForPageToLoadCompletely();
		wait.waitForFullLoaderToDisappear();
		waitForElementToBeClickable(element("link_addNew"));
		hardWait(10);
		clickUsingJavaScript("link_addNew");
		hardWait(10);
		logMessage("Clicked 'Add New' Link");
	}

	/**
	 * Click 'Add New Content' Link Writer's Help
	 */
	public void clickAddNewContentLink() {
		waitScrollAndClick("lnk_addNewContent");
		logMessage("Clicked 'Add New Content' Link");
	}

	/**
	 * Verifies that title of Modal/Window is correct
	 */
	public void verifyModalWindowTitle(String expectedTitle) {
		// waitForElementToBeVisible("txt_titleModal",expectedTitle);
		isElementDisplayed("txt_titleModal", expectedTitle);
	}

	/**
	 * Click specified Assignment Type from 'Create a New Assignment' Modal
	 */
	public void clickAssignmentType(String assignmentType) {
		waitAndClick("link_assignmentType", assignmentType);
	}

	/**
	 * Clicks 'Add New' Button and selects specified Assignment from 'Create a New
	 * Assignment' Modal
	 * 
	 * @param assignMentType Name of Assignment Type as specified in 'Create a New
	 *                       Assignment' Modal
	 */
	public void createNewAssignment(String assignmentType) {
		clickAddNewLink();
		// handleGuideModalWindow();
		verifyModalWindowTitle("Add a new assignment");
		verifyModalWindowContent();
		clickAssignmentType(assignmentType);
	}

	public void verifyModalWindowContent() {
		isElementDisplayed("link_assignmentType", "Unit");
		isElementDisplayed("link_assignmentType", "Discussion Board");
		isElementDisplayed("link_assignmentType", "Document Collection");
		isElementDisplayed("link_assignmentType", "Link");
		isElementDisplayed("link_assignmentType", "HTML Page");
		isElementDisplayed("link_assignmentType", "Offline Assignment");
		isElementDisplayed("link_assignmentType", "Link Collection");
		isElementDisplayed("link_assignmentType", "Quiz");
		isElementDisplayed("link_assignmentType", "Video Assignment");
		isElementDisplayed("link_assignmentType", "iClicker Reef Course Link");
		isElementDisplayed("link_assignmentType", "Dropbox");
		logMessage("Verified all the contents of modal popup");
	}

	public void handleGuideModalWindow() {
		if (getElementCount("lnk_nextGuide") > 0) {
			waitScrollAndClick("lnk_nextGuide");
			logMessage("Guide modal window handled");
		} else {
			logMessage("Guide modal window does not appear");
		}
	}

	/**
	 * Click Add New Content and select Create New - Writer's Help
	 */
	public void createNewAssignmentWritersHelp(String assignmentType) {
		clickAddNewContentLink();
		clickOnCreateNewLink();
		verifyModalWindowTitle("Add a new assignment");
		clickAssignmentType(assignmentType);
	}

	private void clickOnCreateNewLink() {
		waitAndClick("lnk_createNew");
		logMessage("Clicked 'Create New' link");
	}

	/**
	 * Create an Assignment of Type : Dropbox, HTML Page, Discussion Board,
	 */
	public void createAssignmentCategory1(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate) {
		createNewAssignment(assignmentType);
		fnePage.verifyHeadingOfPage(assignmentType);
		fnePage.fillTitleOnBasicInfo(assignmentName);
		fnePage.clickOnSaveButtonOnBasicInfo();
		// fnePage.verifyMsgToast("Title cannot be blank");
		fnePage.clickSettingsTab();
		fnePage.enterNumberOfAttemptsOnSettingsTab("Unlimited");
		fnePage.clickSaveButtonOnSettingsTab();
		if (assign)
			fnePage.assignAssignment(assignmentScore, dueDate);
	}

	/**
	 * Create an Assignment - Writer's Help
	 */
	public void createAssignmentCategory2(String assignmentType, String quizName) {
		createNewAssignmentWritersHelp(assignmentType);
		fnePage.verifyHeadingOfPage(assignmentType);
		fnePage.fillTitleOnBasicInfo(quizName);
		fnePage.clickOnSaveButtonOnBasicInfo();
		fnePage.clickSettingsTab();
		fnePage.enterNumberOfAttemptsOnSettingsTab("Unlimited");
		fnePage.clickSaveButtonOnSettingsTab();
		fnePage.clickQuestionsTab();
	}

	/**
	 * Create a Quiz Assignment
	 */
	public void createQuizAssignment(String assignmentType, String assignmentName, boolean assign,
			String assignmentScore, String dueDate, boolean addQuestions, String chapterName, String questionBank) {
		createAssignmentCategory1(assignmentType, assignmentName, assign, assignmentScore, dueDate);
		if (addQuestions)
			fnePage.addQuestions(chapterName, questionBank);
		fnePage.clickDoneEditingAndHomeButton();
	}

	public String getNextDate() {
		Date today = new Date();
		SimpleDateFormat formattedDate = new SimpleDateFormat("MMM dd, YYYY");
		Calendar c = Calendar.getInstance();
		c.add(Calendar.DATE, 1); // number of days to add
		return (String) (formattedDate.format(c.getTime()));
	}

	public void createQuizAssessmentForSapling(String assignmentName, String testRunEnvironment) {

		removePreviousAssessment(assignmentName);
		selectTextFromDropDown("drpDown_AddActivity", "Assessment");
		fillText("assessmentName", assignmentName);
		List<WebElement> list = elements("checkbox_date");
		scroll(list.get(0));
		scrollDownWithGivenDimension(-300);
		list.get(0).click();
		list.get(1).click();
		wait.hardWait(4);
		executeJavascript("document.querySelectorAll('.datePicker-date.availableDate.hasDatepicker')[1].value='"
				+ getNextDate() + "'");
		scroll(element("btn_saveNContinue"));
		waitAndClick("btn_saveNContinue");
		switchToFrame("iframe_description");
//		wait.hardWait(15);
		wait.hardWait(4);
		waitAndClick("btn_QuestionBank");
		wait.hardWait(4);
		switchToFrame("iframe_QuestionList");
		if (testRunEnvironment.equalsIgnoreCase("prod"))
			element("input_filter").sendKeys(
					"Determine whether a verbal representation of a relation is a function why and explain .");
		hardWait(5);
		waitAndClick("questionList");
		waitForElementToBeVisible("btn_addQuestion");
		isElementDisplayed("btn_addQuestion");
		waitAndClick("btn_addQuestion");
		closeWindow();
		changeWindow(0);
	}

	public void selecting_CourseEndDate() {
		isElementDisplayed("due_CalenderDate");
		waitAndClick("due_CalenderDate");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("var first = {" + "  second: function myFunc7(){"
				+ "document.getElementsByClassName('_2eGJ wbLx').item(0).click();"
				+ "document.getElementsByClassName('_2XMC ').item(9).click();" + "}};" + "   first.second();");

	}

	public void removePreviousAssessment(String assessName) {
		List<WebElement> assessList = elements("btn_assessment", assessName);
//		for(int i=0;i<assessList.size();i++)
//		{
//			assessList.get(i).click();
//			wait.hardWait(2);
//		    waitAndClick("link_delete", assessName);
//		}
		List<WebElement> deleteLinkList = elements("link_delete", assessName);
		while (assessList.size() > 0) {
			assessList.get(0).click();
			wait.hardWait(2);
			deleteLinkList.get(0).click();
//		    waitAndClick("link_delete", assessName);
			refreshPage();
			assessList = elements("btn_assessment", assessName);
			waitAndClick("btn_yes");
			deleteLinkList = elements("link_delete", assessName);
		}

		logMessage("Remove all the assessment");
	}

	public void clickUserMenuItem(String itemName) {
		waitForElementToBeVisible("link_usernameMenuItem", itemName);
		hardWait(2);
		element("link_usernameMenuItem", itemName).click();
		logMessage("Clicked User Name Menu Item '" + itemName + "'");
	}

	public void hoverUserNameMenu() {
		hardWait(2);
		// hover(element("link_usernameMenu"));
		executeJavascript("document.getElementsByClassName('hidden-menu profileMenu')[1].style.display='block';");
	}

	public void logout() {
		clickElementIfVisible("btn_closeToastMessage");
		hoverUserNameMenu();
		// element("link_usernameMenu").click();
		clickUserMenuItem("Sign Out");
		waitForElementToBeVisible("link_helpMenu");
//		try{
//			hoverUserNameMenu();
//			clickUserMenuItem("Sign Out");
//		}catch (Exception e) {
//			System.out.println("User already signed out");
//		}
	}

	public void verifyStudenEula() {
		isElementDisplayed("eula_page_title");
		logMessage("Student is on EULA page");
		element("chkbox_eulaAgreement").click();
		element("btn_eulaAgreement").click();
	}

	public void studentRegistration(String studentEmail, String px_pwd) {
		isElementDisplayed("register_page_title");
		logMessage("User is on Student Registration page");
		fillText("txtbox_first_name", "FSName");
		fillText("txtbox_last_name", "SLName");
		fillText("txtbox_password", px_pwd);
		fillText("txtbox_confirmEmail", studentEmail);
		fillText("txtbox_confirmPwd", px_pwd);
		element("btn_register").click();
	}

	public void completeStudent_Registration(String email, String password) {
		waitForElementToBeVisible("inpt_FName");
		fillText(element("inpt_FName"), "fname");
		waitForElementToBeVisible("inpt_LName");
		fillText(element("inpt_LName"), "fname");
		waitForElementToBeVisible("E_Email");
		fillText(element("E_Email"), email);
		logMessage("student entered in email field " + email);
		waitForElementToBeVisible("confirm_Email");
		fillText(element("confirm_Email"), email);
		logMessage("student entered in confirm email field ");
		waitForElementToBeVisible("Password");
		fillText(element("Password"), password);
		logMessage("student entered in password " + password);
		waitForElementToBeVisible("confirmPassword");
		fillText(element("confirmPassword"), password);
		logMessage("student confirm password");
		isElementDisplayed("termCheckBox");
		waitAndClick("termCheckBox");
		logMessage("clicked on checkbox");
		isElementDisplayed("submit_button");
		waitAndClick("submit_button");
		logMessage("student registerd successfully");
		waitForLoaderToDisappear();
		executeJavascript("document.getElementsByClassName('EnterCourse px-button right').item(0).click()");
		hardWait(3);
		logMessage("student click on enter your course button");
	}

	public void studentAccessUsingCodes() {
		isElementDisplayed("verify_checkAccesspage");
		logMessage("User is on Check Student Access page");
		element("btn_access_code").click();

	}

	public void enterAccessCode(String accessCode) {
		fillText("txtbox_access_code", accessCode);
		element("btn_submit_access_code").click();
		isElementDisplayed("verify_accesspage");
		isElementDisplayed("btn_continueToSite");
		element("btn_continueToSite").click();
		hardWait(2);
	}

	public void attemptAssignment() throws AWTException {
		Robot continue_button = new Robot();
		continue_button.keyPress(KeyEvent.VK_ENTER);
		waitForElementToBeVisible("btn_start_quiz");
		element("btn_start_quiz").click();
	}

	/**
	 * Click TOC Item
	 */
	public void clickUnassignedTOCItem(String linkName) {
		hardWait(4);
		isElementDisplayed("link_itemTOC", linkName);
		// click(element("link_itemTOC",linkName));
		scrollToElementUsingJavaScriptForLP("link_itemTOC", linkName);
		waitAndClick("link_itemTOC", linkName);
		logMessage("Clicked TOC Item '" + linkName + "'");
		waitForLoaderToDisappear();
	}

	/**
	 * Click assigned TOC item
	 */
	public void clickAssignedTOCItem(String linkName) {
		scrollToTop();
		hardWait(1);
		waitScrollAndClick("link_assignedItemTOC", linkName);
		// waitScrollAndClick("link_itemTOC", linkName);
		logMessage("Clicked TOC Item '" + linkName + "'");
		waitForLoaderToDisappear();
	}

	/**
	 * Click TOC Item 'Assign' Button
	 */
	public void clickTOCItemAssignButton(String linkName) {
		waitAndScrollToElement("link_itemTOC", linkName);
		hardWait(4);
		@SuppressWarnings("unused")
		int i = -1;
		for (WebElement el : elements("list_contentTOC")) {
			if (el.getText().contains(linkName)) {
				i++;
				break;
			}
		}
		hover(element("link_itemTOC", linkName));
		hardWait(2);
		isElementDisplayed("link_assignItemTOC", linkName);
		waitAndClick("link_assignItemTOC", linkName);
		hardWait(3);
		logMessage("Clicked Assign Button for TOC Item '" + linkName + "'");
	}

	/**
	 * Click Next Month Button from Date Picker in 'Manage Assignment' Widget
	 */
	public void clickNextMonthButtonFromDatePicker() {
		hardWait(3);
		click(element("datePicker_goNext"));
	}

	/**
	 * Click specified Date from Date Picker in 'Manage Assignment' Widget
	 */
	public void clickDateFromDatePicker(String date) {
		element("datePicker_date", date).click();
	}

	/**
	 * Fill Grade Points field in 'Manage Assignment' Widget
	 */
	public void fillGradePointsManageAssignmentWidget(String points) {
		waitForElementToBeVisible("txtinput_gradePointsManageAssignment");
		fillText("txtinput_gradePointsManageAssignment", points);
	}

	/**
	 * Click 'Assign' Button in 'Manage Assignment' Widget
	 */
	public void clickManageAssignmentAssignButtonNew() {
		waitForElementToBeVisible("btn_assignManageAssignment");
		executeJavascript(
				"return document.evaluate(\"//input[contains(@class,'assign-showCalendar-close')]\", document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue.click();");
		logMessage("Clicked Assign Button.");
	}

	/**
	 * Assigns the specified TOC Item to next month's specified date
	 */
	public void assignTOCItem(String linkName, String nextMonthDate, boolean fillGradePoints, String gradePoints) {
		clickTOCItemAssignButton(linkName);
		waitForElementToBeVisible("assignWindow");
		clickNextMonthButtonFromDatePicker();
		clickDateFromDatePicker(nextMonthDate);
		if (fillGradePoints)
			fillGradePointsManageAssignmentWidget(gradePoints);
		clickManageAssignmentAssignButtonNew();
	}

	/**
	 * Assigns the specified TOC Item to next month's specified date Writer's Help
	 */
	public void assignTOCItemWritersHelp(String chapterName, String assignmentName, String gradePoints) {
		openManagementCard(chapterName);
		verifyMessageOnManagementCard();
		selectAssignment(assignmentName);
		assignDueDate(gradePoints);
	}

	public void clickTOCItemAssignButtonForAssignedContent(String linkName) {
		waitAndScrollToElement("link_assignedItemTOC", linkName);
		hardWait(4);
		@SuppressWarnings("unused")
		int i = -1;
		for (WebElement el : elements("list_contentTOC")) {
			if (el.getText().contains(linkName)) {
				i++;
				break;
			}
		}
		hover(element("link_assignedItemTOC", linkName));
		hardWait(2);
		isElementDisplayed("link_assignItemTOC", linkName);
		clickUsingJavaScript("link_assignItemTOC", linkName);
		hardWait(5);
		logMessage("Clicked Assign Button for TOC Item '" + linkName + "'");
	}

	public void updateGradeValueOfAssignedTOCItem(String linkName, boolean fillGradePoints, String gradePoints) {
		clickTOCItemAssignButtonForAssignedContent(linkName);
		waitForElementToBeVisible("assignWindow");
		if (fillGradePoints)
			fillGradePointsManageAssignmentWidget(gradePoints);
		clickManageAssignmentAssignButtonNew();
	}

	public void launchPadLogout() {
		clickElementIfVisible("btn_closeToastMessage");
		hoverUserNameMenu();
		hardWait(2);
		clickUserMenuItem("Sign Out");
		waitForPageToLoadCompletely("Macmillan Launchpad: Login");
		waitForElementToBeVisible("link_helpMenu");
		closeWindow();
		changeWindow(0);

		logMessage("User has successfully logged out from LaunchPad application");
	}

	public void handleSecurityAlert() {
		hardWait(3);
		try {
			Robot robot;
			robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			e.printStackTrace();
		}
	}

	public void verifyUserIsOnEbookPage() {
		isElementDisplayed("lbl_eBook");
		logMessage("User is on eBook page in LaunchPad");
	}

	public void userNavigateToPxWindow() {
		handleAlert();
	}

	public void clickOnLPHomeLink() {
		isElementDisplayed("btn_LPHome");
		hoverClick(element("btn_LPHome"));
		logMessage("User has clicked on LaunchPad homepage");
	}

	public void verify_freeTrialMessageIsDisplayed() {
		assertTrue(element("txt_freeTrial").isDisplayed(),
				"The free Trial text is not displayed on" + " Launchpad homepage");
		System.out.println("Free Trial message has been Verified");

		assertTrue(element("purchase_Acess").isDisplayed(), "purchase Acess is not dispalyed on launchpad homepage");
		System.out.println("purchase acess verified");

		assertTrue(element("enter_Acess_Code").isDisplayed(),
				"enter acess code is not dispalyed on launchpad home page");
		System.out.println("enter acess code is verified");
	}

	public void verify_freeTrialMessageIsNotDisplayed() {
		List<WebElement> freetrialmessage = elements("txt_freeTrial");
		assertEquals(freetrialmessage.size(), 0, "Free Trial Message is still displayed");
		System.out.println("Free Trial Message is not displayed");
	}

	public void useAccessCodeFromFreeTrialMessage() {
		element("enter_Acess_Code").isDisplayed();
		click(element("enter_Acess_Code"));
		logMessage("Clicked on Enter Access Code Button");
		verifyStudentIsOnEnterAccessCodePage();
	}

	public void purchaseAccessFromFreeTrialMessage() {
		element("purchase_Acess").isDisplayed();
		click(element("purchase_Acess"));
		logMessage("Clicked on purchase_Acess Button");
	}

	public void verifyStudentIsOnEnterAccessCodePage() {
		waitForElementToBeVisible("accessCodeHeading");
		isElementDisplayed("accessCodeHeading");
		logMessage("User is on enter Access Code page");
	}

	public void verifyStudentIsOnPurchaseAccessPage() {
		waitForElementToBeVisible("purchaseAccessHeding");
		isElementDisplayed("purchaseAccessHeding");
		logMessage("User is on purchase Access page");

	}

	public void clickOnAssignmentsTab() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("link_assignment");
		waitScrollAndClick("link_assignment");
		logMessage("Clicked on Assignment Tab");
	}

	public void clickOnHomeButtonTab() {
		waitForLoaderToDisappear();
		waitForElementToBeVisible("link_home");
		waitScrollAndClick("link_home");
		logMessage("Clicked on Home Tab");
	}

	public void createQuizAssignmentWritershelp(String assignmentType, String quizName, boolean addQuestions,
			String assignmentName, String points) {
		createAssignmentCategory2(assignmentType, quizName);
		if (addQuestions)
			fnePage.addQuestionsWritersHelp("Multiple Choice");
		;
		fnePage.clickDoneEditingAndHomeButton();
		openManagementCard(quizName);
		verifyMessageOnManagementCard();
		selectAssignment(assignmentName);
		assignDueDate(points);
	}

	public void openManagementCard(String title) {
		hardWait(2);
		waitForLoaderToDisappear();
		int i = 0;
		WebElement contentInToc = null;
		hardWait(2);
		int tocSize = elements("list_itemsInToc").size();
		for (WebElement content : elements("list_itemsInToc")) {
			contentInToc = content;
			scrollDown(contentInToc);
			if (contentInToc.getText().contains(title)) {
				break;
			} else
				i++;
		}
		waitForLoaderToDisappear();
		if (i < tocSize) {
			executeJavascript("document.getElementsByClassName('item-options-button')[" + i + "].click()");
		} else {
			executeJavascript("document.getElementsByClassName('item-options-button')[0].click()");
		}
		scrollDown(element("link_assign", title));
		waitForElementToBeVisible("link_assign", title);
		element("link_assign", title).click();
		logMessage("Management card opened for " + title);
	}

	public void verifyMessageOnManagementCard() {
		wait.waitForElementToBeVisible(element("lbl_message"));
		customAssert.customAssertEquals(element("lbl_message").getText(),
				"To assign an item, select an assignment unit from the menu below or create a new one.",
				"Assertion Failed : Message on management card is correct");
	}

	public void selectAssignment(String assignmentName) {
		waitForLoaderToDisappear();
		selectProvidedTextFromDropDown(element("drpdown_assignment"), assignmentName);
	}

	public void assignDueDate(String points) {
		waitForElementToBeVisible("btn_datePickerGoNext");
		element("btn_datePickerGoNext").click();
		waitScrollAndClick("btn_setDate");
		element("input_points").clear();
		element("input_points").sendKeys(points);
		executeJavascript(
				"document.getElementsByClassName('collapse-menu assign-showCalendar-close px-button medium primary')[0].click()");
		logMessage("Due date assigned from management card");
		handleAlert();
		waitForLoaderToDisappear();
	}

	public void verifyCreatedQuizNameAtTopOfTOC(String quizTitle1, String quizTitle2) {
		String firstQuizName = (String) executeJavascript("return $('a.faux-tree-link')[0].textContent");
		String secondQuizName = (String) executeJavascript("return $('a.faux-tree-link')[1].textContent");
		customAssert.customAssertEquals(firstQuizName, quizTitle1, quizTitle1 + " Quiz is not created");
		customAssert.customAssertEquals(firstQuizName, quizTitle2, quizTitle2 + " Quiz is not created");
		logMessage("Verified created quiz at top of TOC");
	}

	public void verifyMoreOptionsButton() {
		hardWait(3);
		isElementDisplayed("link_moreOptionExceptMoveOrCopy", "Edit");
		isElementDisplayed("link_moreOptionExceptMoveOrCopy", "Remove");
		isElementDisplayed("link_moreOptionExceptMoveOrCopy", "Close Menu");
		isElementDisplayed("link_MoveOrCopy");
		logMessage("Verified all options of More Option Button");
	}

	public void clickOnMoreOptionLink(String linkName) {
		clickUsingJavaScript("link_moreOptionExceptMoveOrCopy", linkName);
	}

	public void verifyDoneEditingPageContent() {
		isElementDisplayed("lnk_tabOnDoneEditingPage", "Basic Info");
		isElementDisplayed("lnk_tabOnDoneEditingPage", "Assignment");
		isElementDisplayed("lnk_tabOnDoneEditingPage", "Settings");
		isElementDisplayed("lnk_tabOnDoneEditingPage", "Questions");
		logMessage("Verified Done Editing Page Content");
	}

	public void verifyOptionAfterHoveringOnQuiz() {
		String assignBtn = (String) executeJavascript(
				"return $('.item-options button.faceplate-item-assign ')[0].textContent");
		String moreOptionsBtn = (String) executeJavascript("return $('.item-options-button')[0].textContent");
		customAssert.customAssertEquals(assignBtn.contains("Assign"), true, "Assign btn not found");
		customAssert.customAssertEquals(moreOptionsBtn.contains("More Options"), true, "More Options btn not found");
		logMessage("Verified Option after hovering On Quiz");
	}

	public void clickOnCreatedQuiz(String createdQuizame) {
		List<WebElement> quizName = elements("createdQuiz");
		for (WebElement quiz : quizName) {
			if (quiz.getText().contains(createdQuizame)) {
				quiz.click();
				break;
			}
		}
	}

}