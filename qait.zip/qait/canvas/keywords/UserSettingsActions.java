package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.SeleniumWait;

public class UserSettingsActions extends GetPage{
	WebDriver driver;
	SeleniumWait wait;

	public UserSettingsActions(WebDriver driver) {
		super(driver, "UserSettings");
		this.driver = driver;
	}
	
	public void verifyUserSettingsPage() {
		isElementDisplayed("icon_courseMenuToggle");
		isElementDisplayed("link_leftNavigatoinMenu", "Notifications");
		isElementDisplayed("link_leftNavigatoinMenu", "Files");
		isElementDisplayed("link_leftNavigatoinMenu", "Settings");
		isElementDisplayed("link_leftNavigatoinMenu", "ePortfolios");
		isElementDisplayed("link_instEmail");
		isElementDisplayed("link_addEmailAddress");
		isElementDisplayed("link_addContactMethod");
		isElementDisplayed("btn_accountSettings", "Edit Settings");
		isElementDisplayed("btn_accountSettings", "Download Submissions");
		isElementDisplayed("btn_accountSettings", "Delete My Account");
		logMessage("User is on User Settings page");
	}

	public void clickOnNotifications() {
		waitAndClick("link_leftNavigatoinMenu", "Notifications");
		logMessage("User clicked on Notifications link");
	}

	public void verifyNotificationsPreferencesPage() {
		verifyPageTitleContains("Notification Preferences");
		isStringMatching(element("txt_breadcrumb", "Notification Preferences").getText(), "Notification Preferences");
		logMessage("User is on Notification Preferences");
	}

	public void clickOnFiles() {
		waitAndClick("link_leftNavigatoinMenu", "Files");
		logMessage("User clicked on Files link");
	}

	public void verifyFilesPage() {
		verifyPageTitleContains("Files");
		isStringMatching(element("txt_breadcrumb", "Files").getText(), "Files");
		logMessage("User is on Files page");
	}

	public void clickOnMyEPortfolios() {
		waitAndClick("link_leftNavigatoinMenu", "ePortfolios");
		logMessage("User clicked on My ePortfolios link");
	}

	public void verifyMyEPortfolios() {
		verifyPageTitleContains("My ePortfolios");
		isStringMatching(element("txt_breadcrumb", "ePortfolios").getText(), "ePortfolios");
		logMessage("User is on ePortfolios page");
	}

	public void clickOnUserEmail() {
		waitAndClick("link_instEmail");
		logMessage("User clicked on instructor mail address");
	}

	public void verifyConfirmEmailAddressDialogBox() {
		isElementDisplayed("txt_confirmEmailAddress");
		isElementDisplayed("link_resendConfirmation");
		isElementDisplayed("btn_okThanks");
		logMessage("Confirm Email Address modal window verified");
	}

	public void clickOnReSendConfirmation() {
		waitAndClick("link_resendConfirmation");
		logMessage("User clicked on re-send confirmation link");
	}

	public void verifyReSendConfirmationToastMessage() {
		String toastMessage=element("txt_flashMessage").getText();
		logMessage("Toast Message displayed: " + toastMessage);
		isStringMatching(element("link_resendConfirmation").getText(), "Done! Message may take a few minutes.");
	}

	public void clickOnOKThanks() {
		waitAndClick("btn_okThanks");
		logMessage("User clicked on Ok Thanks button");
	}

	public void verifyConfirmEmailAddressDialogBoxClosed() {
		
	}
	
}
