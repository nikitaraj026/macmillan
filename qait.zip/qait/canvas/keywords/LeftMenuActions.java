package com.qait.canvas.keywords;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.UselessFileDetector;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.SeleniumWait;

public class LeftMenuActions extends GetPage {
	WebDriver driver;
	SeleniumWait wait;
	static int count;
	public static String courseName;

	public LeftMenuActions(WebDriver driver) {
		super(driver, "LeftMenu");
		this.driver = driver;
	}

	// Left Menu Actions
	public void clickLeftMenu(String leftMenu) {
		waitScrollAndClick("link_leftMenu", leftMenu);
		// waitAndScrollToElement("link_leftMenu", leftMenu);
		// waitAndClick("link_leftMenu", leftMenu);
		logMessage("Clicked on " + leftMenu);
	}

	public void clickLeftSubmenu(String leftSubmenu) {
		hardWait(4);
		waitAndClick("link_leftSubmenu", leftSubmenu);
		logMessage("Clicked on " + leftSubmenu);
	}

	public void clickOnAccountLeftMenu() {
		// executeJavascript("document.getElementById('global_nav_profile_link').click();");
		// clickLeftMenu("Account");
		clickAccountLogo();
		logMessage("User has clicked on 'Account' in left Menu");
	}

	public void clickAccountLogo() {
		hardWait(3);
		waitAndClick("img_accountLogo");
		logMessage("User has clicked on 'Account' in left Menu");
	}

	public void clickOnAdminLeftMenu() {
		clickLeftMenu("Admin");
	}

	public void clickOnDashboardLeftMenu() {
		clickLeftMenu("Dashboard");
	}

	public void clickOnCoursesLeftMenu() {
		// executeJavascript("document.getElementById('global_nav_courses_link').click();");
		clickLeftMenu("Courses");
	}

	public void clickOnCalendarLeftMenu() {
		clickLeftMenu("Calendar");
	}

	public void clickOnInboxLeftMenu() {
		clickLeftMenu("Inbox");
	}

	public void clickOnHelpLeftMenu() {
		clickLeftMenu("Help");
	}

	// Inside Account Menu Links
	private void clickLogout() {
		hardWait(2);
		waitForElementToBeClickable(element("btn_logout"));
		waitAndClick("btn_logout");
		// executeJavascript("document.getElementsByClassName('Button
		// Button--small')[0].click();");
		logMessage("Clicked on Logout button.");
	}

	// Inside Admin Menu Link
	public void clickMacmillan2() {
		hardWait(3);
		clickLeftSubmenu("Macmillan2");
		logMessage("Clicked on 'Macmillan2'.");
	}

	// Inside Courses Link
	public void clickOnUserCourse(String courseName) {
		clickLeftSubmenu(courseName);
		logMessage("Clicked on '" + courseName + "'.");
	}

	public void clickOnHelpLeftOption(String courseName) {
		clickLeftSubmenu(courseName);
		logMessage("Clicked on '" + courseName + "'.");
	}

	public void clickOnAllCourses() {
		clickLeftSubmenu("All Courses");
		logMessage("Clicked on 'All Courses'.");
	}

	// Compound Methods
	public void logout() {
		clickOnAccountLeftMenu();
		clickLogout();
		logMessage("User has successfully logged out from Canvas.");
	}

	public void goToUserCourse(String courseName) {
		clickOnCoursesLeftMenu();
		clickOnUserCourse(courseName);
		logMessage("User succesfully navigated to " + courseName + ".");
	}

	// public void clickOnAccountFromLeftPanel() {
	// isElementDisplayed("lnk_leftNavAccount");
	// element("lnk_leftNavAccount").click();
	// logMessage("User clicked on Account from left panel");
	// }

	public void verifyAccountPanel() {
		isElementDisplayed("lnk_leftNavAccountPanel", "Settings");
		isElementDisplayed("lnk_leftNavAccountPanel", "Notifications");
		isElementDisplayed("lnk_leftNavAccountPanel", "Files");
		isElementDisplayed("lnk_leftNavAccountPanel", "ePortfolios");
		isElementDisplayed("btn_logout");
	}

	public void clickOnSettingsFromAccountPanel() {
		isElementDisplayed("lnk_leftNavAccountPanel", "Settings");
		element("lnk_leftNavAccountPanel", "Settings").click();
		logMessage("User clicked on Settings from account panel");
	}

	public void verifyAdminOverlay() {
		isElementDisplayed("link_leftSubmenu", "Macmillan2");
		isElementDisplayed("link_leftSubmenu", "All Accounts");
		logMessage("All links are present on Admin Overlay");
	}

	public void verifyAllAccountsPage() {
		customAssert.customAssertEquals(getPageTitle(), "Accounts",
				"[Assertion Failed]: Page title does not match");
		isElementDisplayed("txt_accountName", "Macmillan2");
	}

	public void verifyCoursesOverlay() {
		isElementDisplayed("link_leftSubmenu", "All Courses");
		isElementDisplayed("btn_crossIcon");
		isElementDisplayed("paragraph_courseOverlay");
		customAssert
				.customAssertEquals(
						element("paragraph_courseOverlay")
								.getText()
								.contains(
										"Welcome to your courses! To customize the list of courses"),
						true, "Assertion Failed: Paragraph not found");

	}

	public void verfiyAllCoursesPage() {
		isElementDisplayed("btn_addCourse");
		customAssert.customAssertEquals(getPageTitle(), "Courses",
				"[Assertion Failed]: Page title does not match");
		logMessage("[Assertion Passed]: Page title match");
	}

	public void verifyCalendarPage() {
		customAssert.customAssertEquals(getPageTitle(), "Calendar",
				"[Assertion Failed]: Page title does not match");
		logMessage("[Assertion Passed]: Page title match");
	}

	public void verifyInboxPage(String courseName) {
		customAssert.customAssertEquals(getPageTitle(), "Conversations",
				"[Assertion Failed]: Page title does not match");
		isElementDisplayed("drpDwn_allCourses", "All Courses");
		isElementDisplayed("drpDwn_allCourses", courseName);
		List<WebElement> mailBox = elements("drpDwn_ListOfMailBox");
		customAssert
				.customAssertEquals(mailBox.get(0).getText(), "Inbox",
						"Assertion Failed: Inbox option is not matched from dropdown as expected");
		customAssert
				.customAssertEquals(mailBox.get(1).getText(), "Unread",
						"Assertion Failed: Unread option is not matched from dropdown as expected");
		customAssert
				.customAssertEquals(mailBox.get(2).getText(), "Starred",
						"Assertion Failed: Starred option is not matched from dropdown as expected");
		customAssert
				.customAssertEquals(mailBox.get(3).getText(), "Sent",
						"Assertion Failed: Sent option is not matched from dropdown as expected");
		customAssert
				.customAssertEquals(mailBox.get(4).getText(), "Archived",
						"Assertion Failed: Archivedoption is not matched from dropdown as expected");
		customAssert
				.customAssertEquals(
						mailBox.get(5).getText(),
						"Submission Comments",
						"Assertion Failed: Submission Comments option is not matched from dropdown as expected");
		isElementDisplayed("btn_compose");
		isElementDisplayed("btn_reply");
		isElementDisplayed("btn_replyAll");
		isElementDisplayed("btn_download");
		isElementDisplayed("btn_deleteMail");
		isElementDisplayed("btn_setting");
		isElementDisplayed("input_recipients");
		isElementDisplayed("btn_recipientFinder");
		logMessage("[Assertion Passed]: Inbox Page");
	}
	public void verifyInboxPage() {
		customAssert.customAssertEquals(getPageTitle(), "Conversations",
				"[Assertion Failed]: Page title does not match");
		isElementDisplayed("drpDwn_allCourses", "All Courses");
	}
	public void verifyHelpOverlay() {
		isElementDisplayed("link_leftSubmenu", "Ask the Community");
		isElementDisplayed("link_leftSubmenu", "Search the Canvas Guides");
		isElementDisplayed("link_leftSubmenu", "Report a Problem");
		isElementDisplayed("link_leftSubmenu", "Submit a Feature Idea");
		logMessage("Assertion Passed: Verified all link of Help Overlay    xxx");
	}

	public void verifyNavigationMenuLeftPanel() {
		isElementDisplayed("logo_canvas");
		isElementDisplayed("link_leftMenu", "Account");
		isElementDisplayed("link_leftMenu", "Dashboard");
		isElementDisplayed("link_leftMenu", "Courses");
		isElementDisplayed("link_leftMenu", "Calendar");
		isElementDisplayed("link_leftMenu", "Inbox");
		isElementDisplayed("link_leftMenu", "Help");
		isElementDisplayed("btn_toggle");
		logMessage("Navigation menu on left panel verified");
	}

	public void clickOnCanvasLogo() {
		waitAndClick("logo_canvas");
		logMessage("User has clicked on Canvas logo");
	}

	public boolean menuIsPresentOrNotAtLeftSide(String external_Tool) {
		boolean value = verifyElementNotDisplayed("lnk_leftNavAccountPanel",
				external_Tool);
		return value;
	}

	public void verifyFieldsOfAskYourInstQuestion() {
		List<WebElement> txt=elements("txt_askQuestion");
		customAssert.customAssertEquals(txt.get(0).getText(),"Which course is this question about?","Assertion Failed: text not matched as expected");
		customAssert.customAssertEquals(txt.get(1).getText(),"Messsage","Assertion Failed: Message not matched as expected");
        isElementDisplayed("textarea_message");
        isElementDisplayed("btn_sendMessage");
        isElementDisplayed("btn_cancel");
        waitAndClick("btn_cancel");
        logMessage("Assertion Passed: Verified Fields Of Ask Your A Instructor Questions");
	}

	public void verifyFieldsOfSearchTheCanvasGuides() {

	}
	public void verifyFieldsOfReportAProblem() {
		isElementDisplayed("txt_reportAProblem");
		isElementDisplayed("paragraph_reportAProblem");
		isElementDisplayed("input_subject");
		isElementDisplayed("textarea_description");
		isElementDisplayed("btn_submitTicket");
		isElementDisplayed("btn_cancel");
		waitAndClick("btn_cancel");
		logMessage("Assertion Passed: Verified all the fields of Report A Problem");
	}
	public void verifyFieldsOfSubmitAFeatureIdea() {

	}
	
}
