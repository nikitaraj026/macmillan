package com.qait.canvas.keywords;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class GradeRefreshAction extends GetPage{
	public GradeRefreshAction(WebDriver driver) {
		super(driver, "GradeRefreshPage");
	}
	
	public void refreshGrades(String contentName){
		waitForElementToBeVisible("radio_selectedContent");
		element("radio_selectedContent").click();
		waitForElementToBeVisible("checkbox_contentToc", contentName);
		element("checkbox_contentToc", contentName).click();
		hardWait(1);
		element("btn_refreshGrades").click();
		hardWait(2);
		waitForElementToBeVisible("btn_OkRefreshGrade");
		scrollDown(element("btn_OkRefreshGrade"));
		element("btn_OkRefreshGrade").click();
	}
	
	public void verifyGrades(String grades,String quizname){
		List<WebElement> quizzes = elements("list_quizes");
		int size = quizzes.size();
		System.out.println("Size of quizzes: " + quizzes.size());
		String actualGrades = (String) executeJavascript("return document.getElementsByClassName('grade')["+(size-1)+"].childNodes[2].textContent.trim()");
		System.out.println("actualGrades : "  + actualGrades);
		customAssert.customAssertEquals(actualGrades, grades, "Grades are not updated when refreshed manually.");
	}
}
