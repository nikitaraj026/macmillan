package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;

public class LoginPageAction extends GetPage {

	public LoginPageAction(WebDriver driver) {
		super(driver, "LoginPage");
	}

	/*
	 * Methods used in Smoke Test
	 */
	public void verifyLoginPage() {
		isElementDisplayed("logo_banner_canvas");
		isElementDisplayed("txt_labelName", "Email");
		isElementDisplayed("inp_Username");
		isElementDisplayed("txt_labelName", "Email");
		isElementDisplayed("inp_Password");
//		isElementDisplayed("checkbox_RememberMe");
//		isElementDisplayed("txt_labelName", "Stay signed in");
//		isElementDisplayed("link_DontKnowYourPassword");
		isElementDisplayed("btn_login");
		// isElementDisplayed("link_footer", "User Research");
		isElementDisplayed("link_footer", "Help");
		// isElementDisplayed("link_footer", "Privacy policy");
		// isElementDisplayed("link_footer", "Terms of Service");
		isElementDisplayed("link_footer", "Facebook");
		isElementDisplayed("link_footer", "Twitter");
		logMessage("User is successfully navigated to Login Page");
	}

	public void loginToTheApplication(String userName, String password) {
		fillText(element("inp_Username"), userName);
		fillText(element("inp_Password"), password);
		waitAndClick("btn_Login");
		logMessage("User " + userName + " logins to the application.");
	}

	/*
	 * Methods for Exhaustive testing
	 */

	public void verifyAllFieldsOnLoginPage() {
		isElementDisplayed("logo_banner_canvas");
		isElementDisplayed("inp_Username");
		isElementDisplayed("inp_Password");
		isElementDisplayed("checkbox_RememberMe");
		isElementDisplayed("label_StaySignedIn");
		isElementDisplayed("link_DontKnowYourPassword");
		isElementDisplayed("btn_Login");
		// isElementDisplayed("link_Footer", "User Research");
		isElementDisplayed("link_Footer", "Help");
		isElementDisplayed("link_Footer", "Privacy policy");
//		isElementDisplayed("link_Footer", "Terms of Service");
		isElementDisplayed("link_Footer", "Facebook");
		isElementDisplayed("link_Footer", "Twitter");
		isElementDisplayed("link_footerInstructure");
		logMessage("User is successfully navigated to Login Page");
	}

	/*
	 * User Research
	 */

	public void clickOnUserResearchLink() {
		waitAndClick("link_Footer", "User Research");
		logMessage("User has clicked on 'User Research' footer link");
		changeWindow(1);
	}

	public void verifyUserIsRedirectedToCanvasUsersPoolPage() {
		verifyPageTitleContains("Canvas Users Pool");
		logMessage("User is on 'Canvas Users Pool' page");
	}

	public void userClosesSecondaryWindowAndGoesBackToCanvasLoginWindow() {
		closeWindow();
		changeWindow(0);
		verifyPageTitleContains("Log In to Canvas");
		logMessage("User is on 'Log In to Canvas' page");
	}

	/*
	 * Privacy policy
	 */

	public void clickOnPrivacyPolicyLink() {
		waitAndClick("link_Footer", "Privacy policy");
		logMessage("User has clicked on 'Privacy policy' link");
	}

	public void verifyUserIsOnPrivacyPolicyPage() {
		verifyPageTitleContains("Privacy");
		logMessage("User is on 'Privacy' page");
	}

	public void goBackToCanvasLoginPage(String URL) {
		navigateToURL(URL);
		verifyPageTitleContains("Log In to Canvas");
		logMessage("User is redirected back to Canvas Login page");
	}

	/*
	 * Terms of service
	 */

	public void clickOnTermsOfUseLink() {
		waitAndClick("link_Footer", "Terms of Service");
		logMessage("User has clicked on 'Terms of service' link");
	}

	public void verifyUserIsOnTermsOfUsePage() {
		verifyPageTitleContains("Terms of Use");
		logMessage("User is on 'Terms of Use' page");
	}

	/*
	 * Facebook
	 */

	public void clickOnFacebookLink() {
		waitAndClick("link_Footer", "Facebook");
		logMessage("User has clicked on 'Facebook' link");

	}

	public void verifyUserIsOnFacebookPage() {
		verifyPageTitleContains("Instructure");
		logMessage("User is on Facebook page on Canvas");
	}

	/*
	 * Twitter
	 */

	public void clickOnTwitterLink() {
		waitAndClick("link_Footer", "Twitter");
		logMessage("User has clicked on 'Twitter' link");

	}

	public void verifyUserIsOnTwitterPage() {
		verifyPageTitleContains("Instructure");
		logMessage("User is on Twitter page on Canvas");
	}

	/*
	 * Help
	 */

	public void clickOnHelpLink() {
		waitAndClick("link_Footer", "Help");
		logMessage("User has clicked on 'Help' footer link");
	}

	public void verifyHelpPopUp() {
		isElementDisplayed("txt_HelpWidgetOptions", "Help");
		isElementDisplayed("txt_HelpWidgetOptions", "Search the Canvas Guides");
		isElementDisplayed("txt_HelpWidgetOptions", "Find answers to common questions");
		isElementDisplayed("txt_HelpWidgetOptions", "Report a Problem");
		isElementDisplayed("txt_HelpWidgetOptions", "If Canvas misbehaves, tell us about it");
		isElementDisplayed("txt_HelpWidgetOptions", "Submit a Feature Idea");
		isElementDisplayed("txt_HelpWidgetOptions", "Have an idea to improve Canvas?");
		isElementDisplayed("btn_close");
		logMessage("Help Pop Up has opened");
	}

	public void clickOnCanvasGuidesLink() {
		waitAndClick("txt_HelpWidgetOptions", "Search the Canvas Guides");
		logMessage("User has clicked on 'Canvas Guides' link from Help PopUp");
		changeWindow(1);
	}

	public void verifyUserIsOnCanvasGuidesPage() {
		verifyPageTitleContains("Guides");
		logMessage("User is on Canvas Guides page on Canvas");
	}

	public void clickOnCanvasFeatureIdeasLink() {
		clickUsingJavaScript("txt_HelpWidgetOptions", "Submit a Feature Idea");
		// waitAndClick("txt_HelpWidgetOptions", "Submit a Feature Idea");
		logMessage("User has clicked on 'Canvas Feature Ideas' link from Help PopUp");
		changeWindow(1);
	}

	public void verifyUserIsOnCanvasFeatureIdeasPage() {
		verifyPageTitleContains("Canvas Studio");
		logMessage("User is on Canvas Features Ideas page on Canvas");
	}

	public void clickOnReportAProblemLink() {
		waitAndClick("txt_HelpWidgetOptions", "Report a Problem");
		logMessage("User has clicked on 'Report A Problem' link from Help PopUp");
	}

	public void verifyReportAProblemPopUp() {
		isElementDisplayed("btn_navigateBack");
		isElementDisplayed("txt_SubjectField");
		isElementDisplayed("txt_DescriptionField");
		isElementDisplayed("txt_EmailField");
		isElementDisplayed("btn_SubmitTicket");
		verifyOptionsInHowIsThisAffectingYouDropDown();
		logMessage("Report A problem PopUp is Opened");
	}

	private void verifyOptionsInHowIsThisAffectingYouDropDown() {
		isElementDisplayed("option_HowIsThisAffectingYouDropDown", "Just a casual question, comment, idea, suggestion");
		isElementDisplayed("option_HowIsThisAffectingYouDropDown", "I need some help but it's not urgent");
		isElementDisplayed("option_HowIsThisAffectingYouDropDown",
				"Something's broken but I can work around it for now");
		isElementDisplayed("option_HowIsThisAffectingYouDropDown",
				"I can't get things done until I hear back from you");
		isElementDisplayed("option_HowIsThisAffectingYouDropDown", "EXTREME CRITICAL EMERGENCY!!");
		logMessage("Drop Down options available");
	}

	public void navigateToHelpPopUp() {
		waitAndClick("btn_navigateBack");
		verifyHelpPopUp();
	}

	public void closeHelpPopUp() {
		waitAndClick("btn_close");
		verifyLoginPage();
		logMessage("Help Pop Up is closed");
	}

	/*
	 * LogIn Message
	 */
	public void verifyErrorMessageForInvalidLogIn() {
		waitForMsgToastToAppear("Invalid username or password");
		// isElementDisplayed("txt_errorMessage");
		logMessage("Error Message is Displayed");
	}

	public void invalidLogin(String uname, String pwd) {
		for (int i = 0; i < 2; i++) {
			loginToTheApplication(uname + "1", pwd + "1");
		}
		verifyErrorMessageForInvalidLogIn();
	}
}