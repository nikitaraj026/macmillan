package com.qait.canvas.keywords;

import java.util.Calendar;

import org.openqa.selenium.WebDriver;

import com.google.gdata.data.dublincore.Date;
import com.qait.automation.getpageobjects.GetPage;

public class SaplingAdminAction extends GetPage {

	public SaplingAdminAction(WebDriver driver) {
		super(driver, "SaplingAdminAction");
	}
	public void navigateFromLoginToHome(String username,String password)
	{
		fillText("inp_username", username);
		fillText("inp_password", password);
		waitAndClick("btn_login");
		logMessage("Navigated from login to home page");
	}
	Calendar calendar = Calendar.getInstance();
	int date= calendar.get(Calendar.DATE);
	public void createCourse(String category,String fullName,String shortName,String instituteName,String subject)
	{
		waitAndClick("btn_addNewCourse");
		selectTextFromDropDown("drpdwn_category", category);
		fillText("inp_fullName", fullName);
		fillText("inp_shortName", shortName+"_"+System.currentTimeMillis());
		fillText("inp_instituteName",instituteName);
		selectTextFromDropDown("drpdwn_subject",subject);
		selectTextFromDropDown("drpdwn_startDate",""+date);
		waitAndClick("chk_disable");
		selectTextFromDropDown("drpdwn_endDate","2023");
//		scroll(element("radio_deepInteg"));
		clickUsingJavaScript("radio_deepInteg");
		scroll(element("inp_cost"));
		scrollBy("-200");
		fillText("inp_cost","500");
		scroll(element("inp_cost"));
		scrollBy("-200");
		waitAndClick("btn_saveChanges");
		logMessage("Created a course");
	}
	String instructor;
	public void userCreation(String fName,String lName,String lmsEmail)
	{
		instructor=lmsEmail;//"canvassapling_automayion"+System.currentTimeMillis()+"@fake123.com";
		waitAndClick("lnk_forUserCreation","Users");
		waitAndClick("lnk_forUserCreation","Accounts");
		waitAndClick("lnk_forUserCreation","Add a new user");
		fillText("inp_newPass", "123456789");
		scroll(element("inp_fname"));
		scrollBy("-200");
		fillText("inp_fname", fName);
		fillText("inp_lname", lName);
		fillText("inp_email", instructor);
		scroll(element("inp_institutionUser"));
		scrollBy("-200");
		fillText("inp_institutionUser","Sapling Learning");
		waitAndClick("lnk_selInst");
		hardWait(3);
		scroll(element("btn_updateProfile"));
		scrollBy("-200");
		hardWait(20);
		waitAndClick("btn_updateProfile");
		waitAndClick("lnk_saplingLearning");
		logMessage("Created a new user");
		
	}
	public void enrollUser()
	{
		waitAndClick("lnk_instructor");
		scroll(element("inp_searchText"));
		scrollBy("-200");
		fillText("inp_searchText", instructor);
		waitAndClick("btn_search");
		scroll(element("inp_searchText"));
		scrollBy("-200");
		waitAndClick("btn_add");
		scroll(element("inp_searchText"));
		scrollBy("-200");
		waitAndClick("btn_assignRoles");
		logMessage("Instructor successfully enrolled");
	}
}
