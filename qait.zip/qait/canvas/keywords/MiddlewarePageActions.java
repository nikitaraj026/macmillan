package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;
import com.qait.automation.getpageobjects.GetPage;

public class MiddlewarePageActions extends GetPage {

	public MiddlewarePageActions(WebDriver driver) {
		super(driver, "MiddlewarePage");
	}

	public void verifyMiddlewareErrorPage() {
		isElementDisplayed("logo_macmillanEducation");
		isElementDisplayed("txt_errorMessage");
		isElementDisplayed("input_email");
		isElementDisplayed("input_firstName");
		isElementDisplayed("input_lastName");
		isElementDisplayed("drpdwn_role");
		isElementDisplayed("btn_browse");
		isElementDisplayed("btn_submit");

		logMessage("User is successfully redirected to Middleware error page");
	}

	public void select_Checkbox_And_Accept() {
		switchToDefaultContent();
		switchToFrame(element("frame_toolContent"));
		System.out.println("Switched to frame tool content ");
		isElementDisplayed("btn_agree_checkBox");
		element("btn_agree_checkBox").click();
		logMessage("Selected the terms checkbox");
		isElementDisplayed("btn_accept");
		element("btn_accept").click();
		logMessage("Clicked on Accept button");
	}
	
	public void willo_SSO() {
		switchToDefaultContent();
		switchToFrame(element("frame_toolContent"));
		System.out.println("Switched to frame tool content ");
		isElementDisplayed("btn_agree_checkBox");
		element("btn_agree_checkBox").click();
		logMessage("Selected the terms checkbox");
		isElementDisplayed("btn_accept");
		element("btn_accept").click();
		logMessage("Clicked on Accept button");
	}

}