package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class ProfilePageActions extends GetPage {

	public ProfilePageActions(WebDriver driver) {
		super(driver, "MacmillanHigherEducationInstructorProfilePage");
	}

	public boolean softverifyInstructorIsOnInstructorProfilePage(){
		boolean isPresent = false;
		waitForElementToBeVisible("logo_macmillan");
		int count = getElementCount("lbl_pageHeader");
		if(count == 1){
			logMessage("Instructor is on 'Macmillan Higher Education Instructor Profile' page");
			isPresent = true;
		}
		else if(count < 1){
			logMessage("Instructor is not on 'Macmillan Higher Education Instructor Profile' page");
			isPresent = false;
		}
		return isPresent;
	}

	public void verifyInstructorIsOnInstructorProfilePage(){
		verifyPageTitleContains("Macmillan Higher Education Instructor Profile");
		waitForElementToBeVisible("logo_macmillan");
		isElementDisplayed("lbl_pageHeader");
		logMessage("Instructor is on 'Macmillan Higher Education Instructor Profile' page");
	}

	public void instructorClicksOnSubmitButton(){
		isElementDisplayed("btn_submit");
		element("btn_submit").click();
		logMessage("Instructor has clicked on 'Submit' button on 'Macmillan Higher Education Instructor Profile' page");
	}

	public void fillInstructorInformationAndSubmit(String firstName, String lastName, String email){
		if(element("input_firstName").getText().equals(firstName) && element("input_lastName").getText().equals(lastName) && element(email).getText().equals(""))
		{
			logMessage("All input fields on the page has values auto-populated");
			instructorClicksOnSubmitButton();

		}else{
			fillText("input_firstName", firstName);
			fillText("input_lastName", lastName);
			fillText("input_email", email);
			logMessage("Instructor has entered values in all the input fields");
			instructorClicksOnSubmitButton();
		}
	}

	public void verifyEmailIsMandatoryOnProfilePage(){
		if(element("input_firstName").getText()!=null && element("input_lastName").getText()!=null && element("input_email").getText()!=null)
		{
			element("input_firstName").clear();
			element("input_lastName").clear();
			element("input_email").clear();

			logMessage("Instructor clear values from all the text fields on Profile page");
			instructorClicksOnSubmitButton();
			handleAlert();
		}else{
			instructorClicksOnSubmitButton();
		}
	}

	public void verifyProfilePageAfterInstructorIsNotRecognized(){
		waitForElementToBeVisible("lnk_findYourTitle");
		logMessage("Instructor account is either not sampled or instructor does not exist in LaunchPad");
	}

	public void userClosesCurrentPageAndNavigatesToBasePage(){
		closeWindow();
		changeWindow(0);
		switchToDefaultContent();
	}

	public void closeProfilePage(){
		closeWindow();
		changeWindow(0);
	}
	
	public void clickOnDisconnectThisAccount() {
		verifyPageTitleContains("User Profile");
		element("lnk_disconnectAccount").isDisplayed();
//		click(element("lnk_disconnectAccount"));
//		clickUsingJavaScript("lnk_disconnectAccount");
//clickUsingJS(element("lnk_disconnectAccount"));
	//	clickusingmyjs("document.getElementById('disconnectAccountLink').click();");
		element("lnk_disconnectAccount").click();
		logMessage("Clicked on Disconnect this Account");
		hardWait(3);
	}
	public boolean softVerifyProfileIsLinked() {
		boolean isPresent = false;

		if (element("txt_profileNotFound").getText().contains("Profile not found.")) {
			logMessage("Profile is already unlinked");
			isPresent = false;
		} else {
			logMessage("Profile is linked");
			isPresent = true;
		}
		return isPresent;
	}
	public void clickBtnConfirmDisconnect() {
     element("btn_disconnectConfirm").isDisplayed();
     click(element("btn_disconnectConfirm"));
     logMessage("Clicked on yes Disconnect this account");
		
	}
}