package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;
import com.qait.automation.getpageobjects.GetPage;

public class MarsEulaRegistrationPageActions extends GetPage {

	public MarsEulaRegistrationPageActions(WebDriver driver) {
		super(driver, "OnboardingPage");
	}
	
	public void verifyEulaPageOpens() {
		verifyPageTitleExact("Eula");
		isElementDisplayed("checkbox_readLegalTerms");
		isElementDisplayed("btn_agree");
		isElementDisplayed("btn_doNotAgree");
		logMessage("Eula Page is displayed successfully");
	}

	public void passEULAPage() {
		verifyEulaPageOpens();
		waitAndClick("checkbox_readLegalTerms");
		waitAndClick("btn_agree");
		logMessage("User navigates from EULA Page to Registeration Page");
	}

	public void passRegistrationPage(String firstName, String lastName, String password) {
		String email = element("txt_registerEmail").getText();
		fillText("input_FirstName",firstName);
		fillText("input_LastName",lastName);
		fillText("input_Password",password);
		fillText("input_ConfirmEmail",email);
		fillText("input_ConfirmPassword",password);
		waitAndClick("btn_register");
		logMessage("Instructor succesfully registered.");
		waitForLoaderToDisappear();
	}

	public void enterAccessCode(String accessCode){
		waitAndClick("btn_EnterAccessCode");
		fillText(element("input_code"), accessCode);
		waitAndClick("btn_Go");
		waitAndClick("btn_ContinueSite");
		logMessage("User is able to successfully enter the access code and navigated to Product Site");
	}

	public void passMarsPageByClickingRegisterLink(){
		waitAndClick("lnk_register");
		logMessage("User is successfully able to pass the Mars Page");
	}


	public void checkEmail(String email){
		if (elements("text_MarsEmail").size() == 1) {
			logMessage("Text: " + elements("text_MarsEmail").get(0).getAttribute("type"));

			if (!elements("text_MarsEmail").get(0).getAttribute("type")
					.contains("hidden")) {
				fillText(element("text_MarsEmail"), email);

				waitAndClick("btn_GoAndCheck");
				logMessage("Clicked on 'Go and Check' button present on Mars page");
				logMessage("System checks email id of the user");
			}
		} 
		else {
			verifyEulaPageOpens();
			passEULAPage();
			logMessage("User is not asked to verify his email...");
		}
	}

	public void verify_Message() {
		isElementDisplayed("lbl_Message");
		logMessage("User verifies the message - You do not currently have access to the requested premium resource.");
	}

	public void userClosesCurrentWindowAndGoToBaseWindow(){
		closeWindow();
		changeWindow(0);
	}

	public void goToPurchaseAccessSection() {
		waitAndClick("btn_purchaseAccess");
		isElementDisplayed("iframe_purchaseAccess");
		switchToFrame(element("iframe_purchaseAccess"));
		logMessage("User goes to Purchase Access Section");
	}

	public void addToCart() {
		waitAndClick("btn_AddToCart");
		isElementDisplayed("btn_Remove");
		logMessage("Item is added to cart");
	}

	public void checkOutNow() {
		waitAndClick("btn_CheckOutNow");
		isElementDisplayed("btn_backToMyShoppingCart");
		waitAndClick("btn_CheckOutNow");
		switchToDefaultContent();
		changeWindow(2);
		waitForElementToBeVisible("btn_Paypal");
		hardWait(3);
		isElementDisplayed("btn_Paypal");
		logMessage("User is checking out the cart");
	}

	public void verifyAndClickTemporaryAccessButton(){
		waitAndClick("btn_temporaryAccess");		
	}

	public void verifyFreeTrialTextDisplayed(){
		isElementDisplayed("txt_freeTrial");
		isElementDisplayed("btn_continueToSite");		
	}

	public void verifyTrialEndedMessage(){
		isElementDisplayed("txt_trialEnded");
		verifyElementNotDisplayed("btn_temporaryAccess", "");
	}

	public void changeEmail(String emailStudent2){
		isElementDisplayed("lnk_clickHere");
		element("lnk_clickHere").click();
		waitAndClick("txtArear_email");
		element("txtArear_email").clear();
		element("txtArear_email").sendKeys(emailStudent2);
		waitAndClick("btn_GoAndCheck");
		element("textbox_password").click();
		element("textbox_password").sendKeys("123456");
		waitAndClick("btn_GoAndCheck");

	}

	public void provideDetailsInTheFormAndContinue(String email, String password) {
		scrollDown(element("btn_Paypal"));
		waitAndClick("btn_Paypal");
		scrollDown(element("textbox_paypalemailid"));
		element("textbox_paypalemailid").click();
		fillText(element("textbox_paypalemailid"), email);
		fillText(element("textbox_payPalPassword"), password);
		waitAndClick("btn_submit");
		waitAndClick("btn_continue1");
		hardWait(5);
		changeWindow(1);
		hardWait(4);
		switchToFrame(element("iframe_purchaseAccess"));
		hardWait(3);
		waitForElementToBeVisible("btn_Continue2");
		scrollDown(element("btn_Continue2"));
		waitAndClick("btn_Continue2");
		switchToDefaultContent();
		isElementDisplayed("label_PremiumStudent");
		waitAndClick("btn_ContinueSite");
		logMessage("User provides the info in the form and proceeds to px");
	}

//	public void providePassword(String password) {
//		if (elements("button_register").size() != 1) {
//			fillText(element("textbox_password"), password);
//			waitAndClick("button_Mars_Login");
//			logMessage("User provides password for an existing RA User and now system will check the user role");
//		}
//		else {
//			verifyRegistrationPageOpens();
//			passRegistrationPage();
//			logMessage("User is not asked to Re-Verify his password..");
//		}
//	}

}