package com.qait.canvas.keywords;

import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.ConfigPropertyReader;

public class ToolsPageAction extends GetPage {
	LeftMenuActions leftMenuActions = new LeftMenuActions(driver);
	ProvisioningPageActions provisioningPageActions = new ProvisioningPageActions(driver);

	public ToolsPageAction(WebDriver driver) {
		super(driver, "ToolsPage");
	}

	public void switchToDefaulFrame() {
		waitForElementToBeVisible("iframe_ToolContent");
		switchToFrame("iframe_ToolContent");
	}

	public void verifyToolsPage() {
		switchToDefaulFrame();
		isElementDisplayed("text_macmillanLearningTools");
//		isElementDisplayed("lnk_macLearningToolsPage","Getting Started...");
//		isElementDisplayed("lnk_macLearningToolsPage","Macmillan Learning Diagnostics");
//		isElementDisplayed("lnk_macLearningToolsPage","Macmillan Technical Support");
//		isElementDisplayed("lnk_macLearningToolsPage","Macmillan User Profile");
		logMessage("User is on the Tools Page");
	}

	public void verifyToolsPageForWillo() {
		switchToFrame("iframe_ToolContent");
		hardWait(3);
		isElementDisplayed("text_Diagnostics", "Diagnostics");
//		isElementDisplayed("btn_ContinueToWilloMacLT");
		isElementDisplayed("text_toolsConfig", "Tool Configuration");
		isElementDisplayed("content_ToolsConfig");
		isElementDisplayed("text_LaunchParameters", "Launch Parameters");
		isElementDisplayed("text_recievedFromTestWillo", "Received from Test Willo LT Conf");
		isElementDisplayed("text_sentToToolsWidget", "Sent to Tools Widget LT");
	}

	public void click_BtnContinueToWilloMacmillanLTNew() {
		hardWait(3);
		switchToFrame("iframe_ToolContent");
		hardWait(2);
		isElementDisplayed("btn_ContinueToWilloMacLT");
		waitAndClick("btn_ContinueToWilloMacLT");
		logMessage("Clicked at Continue to Willo Macmillan Button");
	}

	public void click_BtnContinueToWilloMacmillan() {
		hardWait(3);
		String env;
		env = System.getProperty("env");
		if (env == null)
			env = ConfigPropertyReader.getProperty("tier");
		switchToFrame("iframe_ToolContent");
		hardWait(2);
		if (env.equalsIgnoreCase("prod")) {
			isElementDisplayed("btn_ContinueToWilloMacProd");
			waitAndClick("btn_ContinueToWilloMacProd");
		} else {
			isElementDisplayed("btn_ContinueToWilloMacLT");
			waitAndClick("btn_ContinueToWilloMacLT");
			wait.hardWait(2);
		}
		logMessage("Clicked at Continue to Willo Macmillan Button");
	
	}

	public void click_BtnContinueToQuiz(String quizName) {
		hardWait(3);
		switchToFrame("iframe_instructorAjax");
		switchToFrame("iframe_ToolContent");
		isElementDisplayed("bt_continueToQuiz", quizName);
		clickUsingJavaScript("bt_continueToQuiz", "Manual_Quiz");
		logMessage("Clicked at Continue to Quiz Button");
	}

	public void click_BtnCreateCourse() {
		element("btn_createCourseWillo").click();
	}

	public void verifyToolsPageAfterCousreAssociation() {
		switchToDefaulFrame();
		isElementDisplayed("lnk_LaunchPad");
		isElementDisplayed("lnk_macmillanTools", "E-book");
		isElementDisplayed("lnk_macmillanTools", "Gradebook");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Learning Diagnostics");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Roster Information");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Refresh");
		isElementDisplayed("lnk_macmillanTools", "Unlink Macmillan Course");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Technical Support");
		isElementDisplayed("lnk_macmillanTools", "Macmillan User Profile");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content Refresh");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Missing Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Background Updates");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Sync Token Registration");
		logMessage("All tools are displayed after course is associated");
	}

	public void verifyToolsPageAfterCousreAssociationForWillo() {
		switchToDefaulFrame();
		isElementDisplayed("lnk_LaunchPad");
		isElementDisplayed("lnk_macmillanTools", "E-book");
		isElementDisplayed("lnk_macmillanTools", "Gradebook");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Learning Diagnostics");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Roster Information");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Refresh");
		isElementDisplayed("lnk_macmillanTools", "Unlink Macmillan Course");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Technical Support");
		isElementDisplayed("lnk_macmillanTools", "Macmillan User Profile");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content Refresh");
		// isElementDisplayed("lnk_macmillanTools", "Macmillan Missing Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Background Updates");
//		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Sync Token Registration");
		logMessage("All tools are displayed after course is associated");
	}

	public void verifyToolsPageAfterCousreAssociationForSapling() {
		switchToDefaulFrame();
		isElementDisplayed("imglnk_launchpad");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Learning Diagnostics");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Roster Information");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Refresh");
		isElementDisplayed("lnk_macmillanTools", "Unlink Macmillan Course");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Technical Support");
		isElementDisplayed("lnk_macmillanTools", "Macmillan User Profile");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content Refresh");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Missing Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Background Updates");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Sync Token Registration");
		logMessage("All tools are displayed after course is associated");
	}

	public void verifyToolsPageAfterCousreAssociationForAchieve() {
		switchToDefaulFrame();
		isElementDisplayed("lnk_achieve");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Learning Diagnostics");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Roster Information");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Refresh");
		isElementDisplayed("lnk_macmillanTools", "Unlink Macmillan Course");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Technical Support");
		isElementDisplayed("lnk_macmillanTools", "Macmillan User Profile");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Content Refresh");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Missing Content");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Background Updates");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Grade Sync Token Registration");
		logMessage("All tools are displayed after course is associated");
	}

	public void clickToolLink(String link) {
		waitAndClick(link);
		// isElementDisplayed("box_pleasewait");
		// waitForElementToDisappear("box_pleasewait");
		switchToDefaultContent();
		handleAlert();
		changeWindow(1);
		handleAlert();
		logMessage("User clicks " + link + " in the Tools");
	}

	public void clickLaunchPad() {
		switchToDefaultContent();
		switchToDefaulFrame();
		hardWait(4);
		scroll(element("lnk_LaunchPad"));
		element("lnk_LaunchPad").click();
		switchToDefaultContent();
		logMessage("Clicked on Launchpad on ToolsPage.");
	}

	public void clickAchieve() {
		switchToDefaultContent();
		switchToDefaulFrame();
		hardWait(3);
		scroll(element("lnk_achieve"));
		element("lnk_achieve").click();
		changeWindow(1);
	}

	public void verifyUserIsOnAchieve() {
		switchToDefaultContent();
		logMessage("Clicked on Achieve on ToolsPage.");
		assertTrue(element("img_Achieve_Logo").isDisplayed(), "achieve logo is not displayed");
	}

	public void addContentToCourse() {
		waitAndClick("click_On_browse");
		waitAndClick("Learning_Curve");
		assertTrue(element("btn_Addcontent").isDisplayed(), "added button is not displayed");
		hoverClick(elements("btn_Addcontent").get(0));
		hardWait(3);
		waitAndClick("Reading");
		assertTrue(element("btn_Addcontent").isDisplayed(), "added button is not displayed");
		hardWait(4);
		hoverClick(elements("btn_Addcontent").get(0));
		hardWait(3);
		element("my_Course").click();
	}

	public void clickonAchieveStudFlow() {
		switchToDefaultContent();
		switchToDefaulFrame();
		hardWait(3);
		scroll(element("lnk_achieve"));
		element("lnk_achieve").click();
		changeWindow(1);
		switchToDefaultContent();
		logMessage("Clicked on Achieve on ToolsPage.");
	}

	public void clickWritesHelp() {
		switchToDefaultContent();
		switchToDefaulFrame();
		waitAndClick("lnk_macmillanTools", "Writer's Help");
		switchToDefaultContent();
		logMessage("Clicked on Writer's Help on ToolsPage.");
	}

	public void clickEbook() {
		switchToDefaultContent();
		switchToDefaulFrame();

		waitAndClick("lnk_Ebook");
		switchToDefaultContent();
		logMessage("Clicked on Ebook on ToolsPage.");
	}

	public void clickGradebook() {
		switchToDefaultContent();
		switchToDefaulFrame();
		waitAndClick("lnk_macmillanTools", "Gradebook");
		switchToDefaultContent();
		logMessage("Clicked on Gradebook on ToolsPage.");
	}

	public void clickMacmillanContent() {
		changeWindow(0);
		switchToDefaultContent();
		switchToDefaulFrame();
		waitAndClick("lnk_macmillanTools", "Macmillan Content");
		switchToDefaultContent();
		changeWindow(1);
		logMessage("Clicked on Macmillan Content on ToolsPage.");
	}

	public void verifyMacmillanContentPage() {
		isStringMatching(element("txt_macmillanContent").getText(), "Macmillan Learning Content");
		verifyPageTitleContains("Macmillan Learning TOC");
		isElementDisplayed("label_SelectedItems");
		isElementDisplayed("labelbox_ItemsCount");
		isElementDisplayed("lnk_ShowCart");
		isElementDisplayed("button_AddSelectedContent");
		customAssert.customAssertEquals(
				element("button_AddSelectedContent").getAttribute("class").contains("not-enabled"), true,
				"button is enabled");
		isElementDisplayed("button_Reset");
		isElementDisplayed("button_refresh");
		logMessage("Instructor is on Macmillan Learning TOC page");
	}

	public void clickOnRefreshAndVerify() {
		waitAndClick("button_refresh");
		verifyPageTitleContains("Macmillan Learning TOC");
		logMessage("Clicked on refresh button and verified as well");
	}

	public void verifyAndUpdateAssociatedUser() {
		if (elements("lnk_MacmillanGradeRefresh").size() == 1) {
			leftMenuActions.logout();
		} else {
			isElementDisplayed("lnk_GettingStarted");
			waitAndClick("lnk_GettingStarted");
			switchToDefaultContent();
			changeWindow(1);
			provisioningPageActions.authenticateToken();
			provisioningPageActions.associateFirstCourseFromTheList();
			isElementDisplayed("lnk_MacmillanGradeRefresh");
		}
	}

	public void verifyAndUpdateNonAssociatedUser() {
		if (elements("lnk_MacmillanGradeRefresh").size() == 1) {
			waitAndClick("lnk_Unlink_Macmillan_Course");

			switchToDefaultContent();
			changeWindow(1);
			isElementDisplayed("btn_Yes_DisassociateThisCourse");

			waitAndClick("btn_Yes_DisassociateThisCourse");
			waitForElementToBeVisible("link_recoonectCourse");
			logMessage("User ends the Course Association");

			closeWindow();
			changeWindow(0);

			switchToFrame(element("iframe_ToolContent"));
			isElementDisplayed("lnk_GettingStarted");
			switchToDefaultContent();
		} else {
			switchToDefaultContent();
			switchToFrame(element("iframe_ToolContent"));

			isElementDisplayed("lnk_GettingStarted");
			switchToDefaultContent();
		}
	}

	public void clickGettingStartedLink(String integerationType) {
		if (elements("lnk_GettingStarted", integerationType).size() == 1) {
			hardWait(3);
			scroll(element("lnk_GettingStarted", integerationType));
			hardWait(3);
			waitAndClick("lnk_GettingStarted", integerationType);
			hardWait(5);
			switchToDefaultContent();
			changeWindow(1);
		} else {
			waitAndClick("lnk_Unlink_Macmillan_Course");
			switchToDefaultContent();
			changeWindow(1);
			isElementDisplayed("checkbox_removeDeployedContent");
			waitAndClick("checkbox_removeDeployedContent");
			isElementDisplayed("btn_Yes_DisassociateThisCourse");
			waitAndClick("btn_Yes_DisassociateThisCourse");
			hardWait(5);
			verifyEndCourseAssociationPageAfterCourseIsDisassociated();
//			waitForElementToBeVisible("link_recoonectCourse");
			logMessage("User ends the Course Association");
			hardWait(5);
			closeWindow();
			changeWindow(0);
			switchToFrame(element("iframe_ToolContent"));
			waitAndClick("lnk_GettingStarted", integerationType);
			switchToDefaultContent();
			changeWindow(1);
		}
	}

	public void clickGettingStartedLinkForWillo(String integerationType) {
		if (elements("lnk_GettingStarted", integerationType).size() == 1) {
			scroll(element("lnk_GettingStarted", integerationType));
			waitAndClick("lnk_GettingStarted", integerationType);
			switchToDefaultContent();
			changeWindow(1);
		} else {
			waitAndClick("lnk_Unlink_Macmillan_Course");
			switchToDefaultContent();
			changeWindow(1);
			isElementDisplayed("btn_Yes_DisassociateThisCourse");
			waitAndClick("btn_Yes_DisassociateThisCourse");
			waitForElementToBeVisible("link_recoonectCourse");
			logMessage("User ends the Course Association");
			hardWait(3);
			closeWindow();
			changeWindow(0);
			switchToFrame(element("iframe_ToolContent"));
			waitAndClick("lnk_GettingStarted", integerationType);
			switchToDefaultContent();
			changeWindow(1);
		}
	}

	public void clickOnGettingStarted() {
		if (elements("lnk_GettingStarted").size() == 1) {
			waitAndClick("lnk_GettingStarted");
			switchToDefaultContent();
			changeWindow(1);
		} else {
			waitAndClick("lnk_Unlink_Macmillan_Course");
			switchToDefaultContent();
			changeWindow(1);
			isElementDisplayed("btn_Yes_DisassociateThisCourse");
			waitAndClick("btn_Yes_DisassociateThisCourse");
			waitForElementToBeVisible("link_recoonectCourse");
			logMessage("User ends the Course Association");
			hardWait(3);
			closeWindow();
			changeWindow(0);
			switchToFrame(element("iframe_ToolContent"));
			waitAndClick("lnk_GettingStarted");
			switchToDefaultContent();
			changeWindow(1);
		}
	}

	public void verifyDignosticsLink() {
		isElementDisplayed("heading_Diagnostics");
		logMessage("User verifies diagnostic page");
	}

	public void verifyMacmillanTechSupportLink() {
		isElementDisplayed("heading_Contact_Tech_Support");
		logMessage("User verifies the Support Page");
	}

	public void closeSecondryWindowAndComeBacktoMainWindow() {
		closeWindow();
		logMessage("Closed newly opened window");
		changeWindow(0);
	}

	public void closeThirdWindowAndComeBacktoSecondWindow() {
		closeWindow();
		logMessage("Closed newly opened window");
		changeWindow(1);
	}

	public void switchToWindowHavingTitle(String windowTitle) {
		for (String window : driver.getWindowHandles()) {
			driver.switchTo().defaultContent();
			driver.switchTo().window(window);
			if (driver.getTitle().contains(windowTitle)) {
				logMessage("Switched to window having '" + windowTitle + "' title");
				return;
			}
		}
		driver.switchTo().defaultContent();
	}

	public void verifyUserProfileLinkPage() {
		isElementDisplayed("heading_Macmillan_User_Profile");
		isElementDisplayed("lnk_DisconnectThisAccount");
		waitAndClick("lnk_DisconnectThisAccount");
		scrollDown(element("lnk_CancelButton"));
		waitAndClick("lnk_CancelButton");
		logMessage("User verifies the User Profile Page");
	}

	public void verifySeverThisCourseAssociation() {
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		waitAndClick("btn_Yes_DisassociateThisCourse");

		waitAndClick("lnk_ReconnectThisCourse");
		logMessage("User verifies the Sever This Course Page");
	}

	public void verifyBrokenLinks() {
		isElementDisplayed("txt_Macmillan_Higher_Education_Broken_Conten_Links");
		isElementDisplayed("btn_Delete_Selected_Links");
		isElementDisplayed("row_list_Broken_Link");
		logMessage("User verifies broken link page");
	}

	public void launchpadRedirect() {
		element("imglnk_launchpad").click();

		// handleAlert();

	}

	public void clickonSapling() {
		switchToDefaultContent();
		switchToDefaulFrame();
		hardWait(4);
		scroll(element("click_On_Sapling"));
		clickUsingJavaScript("click_On_Sapling");
		switchToDefaultContent();
		
//		switchToDefaultContent();
//		switchToDefaulFrame();
//		hoverClick(element("click_On_Sapling"));
//		element("click_On_Sapling").click();
	}

	public void tools_Macmillan_Content() {
		waitForElementToBeVisible("lnk_deploy_content");
		element("lnk_deploy_content").click();
	}

	public void deployContent(String TestModule) {
		waitForElementToBeVisible("lnk_expand_assignment");
		element("lnk_expand_assignment").click();
		element("chkbox_select_auto_assignment").click();
		element("chkbox_select_manual_assignment").click();
		;
		element("btn_choose_location").click();
		element("drpdn_mod_loc").click();
		fillText("txtbox_create_module", TestModule);
		element("btn_create_module").click();
		waitForElementToBeVisible("btn_cm_ok");
		element("btn_cm_ok").click();
		hardWait(2);
		selectTextFromDropDown("dropdown_module", TestModule);
		element("btn_deploy_content").click();

	}

	public void clickOnMacmillanGradeRefreshLink() {
		hardWait(4);
	//	switchToFrame(element("iframe_ToolContent"));
//		switchToFrame2(element("iframe_ToolContent"));
		hardWait(3);
		waitAndClick("lnk_MacmillanGradeRefresh");
		changeWindow(1);
	}

	public void verifyGradeRefreshPage() {
		verifyPageTitleContains("Macmillan Learning Grade Refresh");
		isElementDisplayed("btn_gradeRefresh");

		logMessage("User is on Macmillan Learning Grade Refresh page");
	}

	public void clickSelectedButtonOnMacmillanHigherEducationGradeSyncRefresh() {
		waitAndClick("radiobtn_selectedButton");
		logMessage("Radio Button: 'Selected Content' has been clicked");
	}

	public void selectContentOnMacmillanHigherEducationGradeSyncRefresh(String content) {
		waitAndClick("input_contentGradeRefresh", content);
		logMessage(content + " has been selected.");
	}

	public void clickSubmitOnMacmillanHigherEducationGradeSyncRefresh() {
		waitAndScrollToElement("btn_gradeRefresh");
		waitAndClick("btn_gradeRefresh");
		clickUsingJavaScript("btn_gradeRefreshOK");
		logMessage("Clicked 'Submit' and 'OK' button on Macmillan Learning Grade Sync Refresh");
		closeWindow();
		changeWindow(0);
		switchToDefaultContent();
	}

	public void clickOnMacmillanDiagnosticsLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		waitAndClick("lnk_MacmillanHigherEducationDiagnostics");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Learning Diagnostics page");

	}

	public void verifyMacmillanDiagnosticsPage() {
		verifyPageTitleContains("Macmillan Learning Integration Diagnostics");
//		isElementDisplayed("logo_macmillan");
		List<WebElement> textHeader = elements("txt_MacDiagnostic");
		customAssert.customAssertEquals(textHeader.get(0).getText(), "Institution Information",
				"Localization Information not matched");
		customAssert.customAssertEquals(textHeader.get(1).getText(), "User Information",
				"User Information not matched");
		customAssert.customAssertEquals(textHeader.get(2).getText(), "Course Information",
				"Course Information not matched");
		customAssert.customAssertEquals(textHeader.get(3).getText(), "Enrollment Information",
				"Enrollment Information not matched");
		customAssert.customAssertEquals(textHeader.get(4).getText(), "Integration and Web Service Information",
				"Integration and Web Service Information not matched");
		customAssert.customAssertEquals(textHeader.get(5).getText(), "Technical Support",
				"Technical Support not matched");
		logMessage("User is on Diagnostics page");
	}

	/*
	 * Disassociate Course
	 */

	public void clickOnUnlinkMacmillanToolLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		hardWait(5);
		waitAndClick("lnk_Unlink_Macmillan_Course");
		hardWait(5);
		changeWindow(1);
	}

	public void verifyEndCourseAssociationPage() {
		verifyPageTitleContains("End Course Association");
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		isElementDisplayed("checkbox_removeDeployedContent");
		logMessage("Instructor is on 'End Course Association' page");

	}

	public void verifyEndCourseAssociationPageforWillo() {
		verifyPageTitleContains("End Course Association");
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		logMessage("Instructor is on 'End Course Association' page");

	}

	public void verifyEndCourseAssociationPageUoP() {
		verifyPageTitleContains("End Course Association");
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		logMessage("Instructor is on 'End Course Association' page");
	}

	public void clickOnRemoveMacmillanContent() {
		waitAndClick("checkbox_removeDeployedContent");
		logMessage("User clicked on Remove Macmillan Content checkbox");
	}

	public void disassociateCourse() {
		element("btn_Yes_DisassociateThisCourse").click();
		logMessage("Instructor clicked on 'Yes, Disassociate This Course' button");
	}

	public void clearBrowserCache() {
		driver.manage().deleteAllCookies();
	}

	public void verifyCourseUnlinkMessageIsDisplayed(String message) {
		waitForElementToBeVisible("txt_UnlinkMessage");
		isElementDisplayed("txt_UnlinkMessage");
		wait.hardWait(2);
		customAssert.assertEquals(message, element("txt_UnlinkMessage").getText(),
				"Message is not displayed as expected");
		logMessage("Verified the message after unlinkg of a Course");
	}

	public void verifyEndCourseAssociationPageAfterCourseIsDisassociated() {
		isElementDisplayed("txt_courseLinkSevered");
		verifyCourseUnlinkMessageIsDisplayed(
				"Your course has been unlinked, you may return to the Tools Page to link to a new course.");
		logMessage("Course has been successfully disassociated");
	}

	public void verifyNonAssociatedToolsPage(String integerationType) {
		refreshPage();
		switchToDefaultContent();
		switchToDefaulFrame();
		isElementDisplayed("lnk_GettingStarted", integerationType);
		logMessage("User is on Macmillan Tools page of a non-associated course");
		// switchToDefaultContent();
	}

	/**
	 * Macmillan Roster Information functionality
	 */
	public void clickOnMacmillanRosterLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		waitAndClick("lnk_macmillanRoster");
		changeWindow(1);
		logMessage("User has clicked on 'Macmillan Roster Information' link");
	}

	public void verifyMacmillanRosterPage(String userEmail) {
		verifyPageTitleContains("Macmillan Learning Roster");
		isElementDisplayed("txt_macmillanRoster");
		isElementDisplayed("txt_userEmail", userEmail);

		logMessage("Instructor is on 'Macmillan Higher Education Roster' page");
	}

	/*
	 * Macmillan Roster Information functionality
	 */

	public void clickOnMacmillanTechnicalSupportLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		waitAndClick("lnk_MacTechSupport");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Technical Support' link");
	}

	public void verifyMacmillanTechnicalSupportPage() {
//		isElementDisplayed("txt_supportCenter");
		// isElementDisplayed("logo_macmillanLearning");
//		verifyPageTitleContains("Support Community Home | The Macmillan Community");

		logMessage("User is on Technical Support page");
	}

	/*
	 * Macmillan User Profile functionality
	 */

	public void clickOnMacmillanUserProfile() throws InterruptedException {
		switchToDefaultContent();
		switchToDefaulFrame();
		click(element("lnk_MacmillanUserProfile"));
		changeWindow(1);
		logMessage("User has clicked on 'Macmillan User Profile' link");
		Thread.sleep(4000);
	}

	public void verifyMacmillanUserProfilePage(String emailUser) {
		verifyPageTitleContains("User Profile");
		isElementDisplayed("lnk_disconnectAccount");
		isElementDisplayed("txt_emailUser", emailUser);
		logMessage("User is on 'User Profile' page");
	}

	public void verifyMacmillanUserProfilePageWhenConnected(String emailUser) {
		verifyPageTitleContains("User Profile");
		isElementDisplayed("lnk_disconnectAccount");
//		isElementDisplayed("txt_emailUser", emailUser);
		logMessage("User is on 'User Profile' page");
	}

	/*
	 * Macmillan User Profile functionality
	 */

	public void clickOnMacmillanContentRefreshLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		scroll(element("lnk_MacmillanContentRefresh"));
		element("lnk_MacmillanContentRefresh").click();
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Content Refresh' link");
	}

	public void verifyContentRefreshPage() {
		verifyPageTitleContains("Macmillan Learning Content Refresh");
		isElementDisplayed("btn_refreshContent");

		logMessage("User is on 'Macmillan Learning Content Refresh page");
	}

	public void clickOnRefreshContentButton() {
		isElementDisplayed("btn_refreshContent");
		waitAndClick("btn_refreshContent");
		logMessage("User has clicked on 'Refresh Content Links' button");
	}

	public void selectAssignmentsForProcessing() {
		if (element("radiobtn_allContent").isSelected()) {
			logMessage("'All Content' link is already chechked");
		} else {
			element("radiobtn_allContent").click();
			logMessage("User has selected 'All Content' radio button");
		}
	}

	public void clickOnOKButtonOnTaskInProgressPopUp() {
		clickUsingJavaScript("btn_ok");
		logMessage("User clicked on 'OK' button in the pop-up");
	}

	/*
	 * Macmillan User Profile functionality
	 */

	public void clickOnMacmillanBackgroundUpdatesLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		scroll(element("lnk_macmillanBackgroundUpdates"));
		element("lnk_macmillanBackgroundUpdates").click();
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Background Updates' link");
	}

	public void verifyMacmillanBackgroundUpdatesPage() {
		verifyPageTitleContains("Macmillan Learning Background Updates");
		isElementDisplayed("txt_backgroundUpdates");

		logMessage("User is on 'Macmillan Learning Background Updates' page");
	}

	/*
	 * Macmillan User Profile functionality
	 */

	public void clickOnTokenRegistrationLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		scroll(element("lnk_macmillanBackgroundUpdates"));
		element("lnk_macmillanTokenRegistration").click();
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Grade Sync Token Registration' link");
	}

	public void verifyTokenRegistrationPage() {
		verifyPageTitleContains("Macmillan Learning Integration Token Registration");
		isElementDisplayed("btn_autheticate");

		logMessage("User is on 'Macmillan Learning Integration Token Registration' page");
	}

	public void clickOnAutheticateButtonOnTokenRegistrationPage() {
		scroll(element("btn_autheticate"));
		waitAndClick("btn_autheticate");
		logMessage("User has clicked on 'Autheticate' button on Token Registration page");
	}

	public void verifyMacmillanLMSIntegrationPage() {
		verifyPageTitleContains("App login");
		isElementDisplayed("btn_cancel");
		isElementDisplayed("btn_accept");

		logMessage("User is on 'Macmillan Higher Education LMS Integration' page");
	}

	public void verifyMacmillanAchieveIntegrationPage() {
		verifyPageTitleContains("App login");
		isElementDisplayed("btn_cancel");
		isElementDisplayed("btn_acceptForAchieve");

		logMessage("User is on 'Macmillan Higher Education LMS Integration' page");
	}

	public void clickOnAuthorizeButtonOnLMSIntegrationPage() {
		waitAndClick("btn_accept");
		logMessage("User has clicked on 'Authorize' button on 'Macmillan Higher Education LMS Integration' page");
	}

	public void clickOnAuthorizeButtonOnAchieveIntegrationPage() {
		waitAndClick("btn_acceptForAchieve");
		logMessage("User has clicked on 'Authorize' button on 'Macmillan Higher Education LMS Integration' page");
	}

	public void verifySuccessfulTokenRegistration() {
		verifyPageTitleContains("Macmillan Learning Integration Token Registration");
		isElementDisplayed("txt_registrationSuccess");
		logMessage("Canvas token registration has completed successfully");
	}

	/*
	 * Disassociate Course
	 */

	public void clickOnMacmillanMissingContentLink() {
		switchToDefaultContent();
		switchToDefaulFrame();
		scroll(element("lnk_Macmillan_Broken_Links"));
		hardWait(4);
		waitAndClick("lnk_Macmillan_Broken_Links");
		changeWindow(1);

		logMessage("User has clicked on 'Macmillan Missing Content' link");
	}

	public void verifyMacmillanMissingContentPage() {
		verifyPageTitleContains("Macmillan Learning Missing Content");
		isElementDisplayed("txt_Macmillan_Higher_Education_Broken_Conten_Links");
		isElementDisplayed("btn_Delete_Selected_Links");

		logMessage("User is on 'Macmillan Higher Education Missing Content' page");
	}

	public void clickOnDeleteSelectedContentButton() {
		waitAndClick("btn_Delete_Selected_Links");
		logMessage(
				"User has clicked on 'Delete Selected Content' button on 'Macmillan Higher Education Missing Content' page");
	}

	public boolean softVerifyCourseIsAssociated(String integerationType) {
		boolean isPresent = false;

		if (!verifyElementNotDisplayed("lnk_GettingStarted", integerationType)) {
			logMessage("Course is already dissociated");
			isPresent = false;
		} else {
			logMessage("Course is associated");
			isPresent = true;
		}
		return isPresent;
	}

	public void runHandleSecurityExe() {
		try {
			Runtime.getRuntime().exec("D:\\Mozilla Security Warning Handle.exe");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * University of Phoenix
	 */

//	public void clickOnMacmillanLearningToolsWidget(String tool)
//	{
//		waitAndClick("left_tab_menu_Tools", tool);
//		logMessage("Instructor has clicked on Tools widget customized for UoP");
//	}

//	public void verifyIfCourseIsAssociated()
//	{
//		switchToDefaulFrame();
//		if(getElementCount("lnk_macmillanTools", "E-book") > 0)
//		{
//			logMessage("Canvas course is associated with LaunchPad course. Starting with course dissociation...");
//			waitAndClick("lnk_Unlink_Macmillan_Course");
//			switchToDefaultContent();
//			changeWindow(1);
//			isElementDisplayed("btn_Yes_DisassociateThisCourse");
//			waitAndClick("btn_Yes_DisassociateThisCourse");
//			waitForElementToBeVisible("link_recoonectCourse");
//			logMessage("User ends the Course Association");
//			hardWait(3);
//			closeWindow();
//			changeWindow(0);
//		}
//		else{
//			logMessage("Canvas course is not associated with LaunchPad course");
//		}
//		isElementDisplayed("lnk_macmillanTools", "E-book");
//		isElementDisplayed("lnk_macmillanTools", "Gradebook");
//		isElementDisplayed("lnk_macmillanTools", "Unlink Macmillan Course");
//		isElementDisplayed("lnk_macmillanTools", "Macmillan Technical Support");
//		isElementDisplayed("lnk_macmillanTools", "Macmillan User Profile");
//		
//		logMessage("Canvas course is associated with LaunchPad course");
//	}

	public void verifyInstructorAccountIsNotSetupForAutoProvisioning() {
		switchToDefaulFrame();
		String provisioningText = element("txt_noAutoProvisioning").getText();
		isStringMatching(provisioningText,
				"Sorry for the inconvenience, but to auto-provision your Macmillan Learning course, an instructor first must be setup in our system. Please contact your sales representative.");
		logMessage("Application displays a message about instructor account not setup in the system");
		switchToDefaultContent();
	}

	public void verifyStudentAccountIsNotSetupForAutoProvisioning() {
		switchToDefaulFrame();
		String provisioningText = element("txt_noAutoProvisioning").getText();
		isStringMatching(provisioningText,
				"Sorry for the inconvenience, but to auto-enroll in your Macmillan Learning course, your instructor first needs to pair the course.  Please try again later.");
		logMessage("Application displays a message about instructor account not setup in the system");
		switchToDefaultContent();
	}

	public void verifyUoPToolsPageForAssociatedCourse() {
		switchToDefaulFrame();
		isElementDisplayed("lnk_macmillanTools", "E-book");
		isElementDisplayed("lnk_macmillanTools", "Gradebook");
		isElementDisplayed("lnk_macmillanTools", "Unlink Macmillan Course");
		isElementDisplayed("lnk_macmillanTools", "Macmillan Technical Support");
		isElementDisplayed("lnk_macmillanTools", "Macmillan User Profile");
		switchToDefaultContent();
		logMessage("Instructor is on tools page for associated UoP course");
	}

	public void verifyLaunchPadContent() {
		List<WebElement> list = elements("leftMenuOption");
		customAssert.customAssertEquals(list.get(0).getText(), "Home", "Home not found");
		customAssert.customAssertEquals(list.get(1).getText(), "eBook", "eBook not found");
		customAssert.customAssertEquals(list.get(2).getText(), "Gradebook", "Gradebook not found");
		customAssert.customAssertEquals(list.get(3).getText(), "Calendar", "Calendar not found");
		customAssert.customAssertEquals(list.get(4).getText(), "Resources", "Resources not found");
		customAssert.customAssertEquals(list.get(5).getText(), "Instructor Console", "Instructor Console not found");
		customAssert.customAssertEquals(list.get(6).getText(), "Welcome Page", "Welcome Page not found");
		customAssert.customAssertEquals(list.get(7).getText(), "Preview as Student", "Preview as Student not found");
		// customAssert.customAssertEquals(element("header_courseName").getText().contains("Canvas"),true,"Course
		// Name Not found");
		hover(elements("lnk_userProfile").get(1));
		customAssert.customAssertEquals(element("drpDwnText", "Manage Profile").isDisplayed(), true,
				"Manage Profile not displayed in drop down");
		customAssert.customAssertEquals(element("drpDwnText", "Switch/Create Courses").isDisplayed(), true,
				"Switch/Create Courses not displayed in drop down");
		customAssert.customAssertEquals(element("drpDwnText", "Sign Out").isDisplayed(), true,
				"Sign Out not displayed in drop down");

	}

	public void verifyDifferentFieldAfterClickingOnMacTools() {
		switchToDefaulFrame();
		isElementDisplayed("lnk_macLearningToolsPage", "Getting Started...");
		isElementDisplayed("lnk_macLearningToolsPage", "Macmillan Learning Diagnostics");
		isElementDisplayed("lnk_macLearningToolsPage", "Macmillan Technical Support");
		logMessage("Verified links After Clicking On Mac learning Tools");
	}

	public void clickOnLinkOfMaclearningLearningTools(String lnkName) {
		switchToDefaulFrame();
		waitAndClick("lnk_macLearningToolsPage", lnkName);
	}

	public void verifyMacmillanLearningDiagnosticsPageContent() {
		verifyPageTitleContains("Macmillan Learning Integration Diagnostics");
		isElementDisplayed("logo_macmillan");
		isElementDisplayed("txt_header_mac_diag");
	}

	public void verifyMacmillanTechnicalSupportPageContent() {
		verifyPageTitleContains("Support Community Home | The Macmillan Community");
		isElementDisplayed("txt_supportCenter");
	}

	public void reConnectCourseForSapling() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(5);
		waitAndClick("lnk_ReconnectThisCourse");
		logMessage("User verifies the Sever This Course Page");

		closeWindowAndSwitchBackToOriginalWindow(0);
		refreshPage();

	}

	public void viewAvailableCourses() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(3);
		waitAndClick("lnk_viewAvailableCourses");

	}

	public void reConnectCourseForLP() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(5);
		waitAndClick("lnk_ReconnectThisCourse");
		logMessage("User verifies the Sever This Course Page");

		closeWindowAndSwitchBackToOriginalWindow(0);
		refreshPage();
	}

	public void viewAvailableCoursesForLP() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(3);
		waitAndClick("lnk_viewAvailableCourses");
	}

	public void reConnectCourseForAchieve() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(5);
		waitAndClick("lnk_ReconnectThisCourse");
		logMessage("User verifies the Sever This Course Page");

		closeWindowAndSwitchBackToOriginalWindow(0);
		refreshPage();
	}

	public void viewAvailableCoursesForAchieve() {
		clickOnUnlinkMacmillanToolLink();
		verifyEndCourseAssociationPage();
		disassociateCourse();
		hardWait(3);
		waitAndClick("lnk_viewAvailableCourses");
	}
}