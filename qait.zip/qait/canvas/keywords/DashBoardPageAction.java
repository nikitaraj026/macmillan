package com.qait.canvas.keywords;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.SeleniumWait;

public class DashBoardPageAction extends GetPage {

	WebDriver driver;
	SeleniumWait wait;
	static int count;
	boolean checkAgreementTerm = false;
	public static String courseName;

	public DashBoardPageAction(WebDriver driver) {
		super(driver, "DashBoardPage");
		this.driver = driver;
	}

	public DashBoardPageAction() {
		super();
	}

	public void verifyFirstUserDisplayed() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		isElementDisplayed("user_id");
		waitAndClick("user_id");
	}

	public void verifyAndClickDeleteUser() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		isElementDisplayed("delete_user");
		waitAndClick("delete_user");
	}

	public void verifyAndClickConfirmDeleteUser() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		isElementDisplayed("confirm_delete_user");
		waitAndClick("confirm_delete_user");
	}

	public void verifyIsElementDisplayed(String ElementName) {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		isElementDisplayed(ElementName);
	}

	public void verifyTermspage() {
		driver.getPageSource().contains("Updated Terms of Use");
		logMessage("User is on Terms of Use page");
		waitForElementToBeVisible("checkbox_terms_use");
		element("checkbox_terms_use").click();
		// driver.findElement(By.xpath("checkbox_terms_use")).click();
		// driver.findElement(By.xpath("btn_submit_terms_use")).click();
		element("btn_submit_terms_use").click();
	}

	public void verifyUserIsOnDashboardPage() {
		isElementDisplayed("lnk_createCourse");
		logMessage("User is on 'Dashboard' page.");
	}

	public void useCourseOnDashboard(String courseName) {
		isElementDisplayed("txt_courseName", courseName);
		waitAndClick("txt_courseName", courseName);
		logMessage("Used courseName " + courseName + " from the dashboard page");
	}

	public void verifyDashboardPage() {
		verifyPageTitleContains("Dashboard");
//		isElementDisplayed("btn_accept");
//		isElementDisplayed("btn_decline");
		// isElementDisplayed("btn_notificationPreferences");
		isElementDisplayed("txt_dashboard");
//		isElementDisplayed("txt_comingUp");
//		isElementDisplayed("lnk_viewCalender");
		// isElementDisplayed("start_new_course");
		isElementDisplayed("btn_viewGrades");
//		isElementDisplayed("txt_courseName");
		logMessage("Dashboard page for new User verified");
	}

	public void verifyDashBoardPage(String courseName) {
		verifyPageTitleContains("Dashboard");
		isElementDisplayed("txt_dashboard");
		isElementDisplayed("btn_viewGrades");
		isElementDisplayed("txt_courseName", courseName);
		logMessage("CourseName is displayed on Dashboard");
		logMessage("Dashboard page for new User verified");
	}

	public void verifyDashboardPageNewInstructor() {
		isElementDisplayed("btn_accept");
		isElementDisplayed("btn_decline");
		isElementDisplayed("btn_notificationPreferences");
		isElementDisplayed("txt_dashboard");
		isElementDisplayed("txt_comingUp");
		isElementDisplayed("lnk_viewCalender");
		isElementDisplayed("start_new_course");
		isElementDisplayed("btn_viewGrades");
		logMessage("Dashboard page for new Instructor verified");
	}

	public void verifyAdminDashBoard() {
		isElementDisplayed("lnk_leftNavAccount");
		isElementDisplayed("lnk_leftNavAdmin");
		isElementDisplayed("lnk_leftNavDashboard");
		isElementDisplayed("lnk_leftNavCalendar");
		isElementDisplayed("lnk_leftNavInbox");
		isElementDisplayed("lnk_leftNavHelp");
		isElementDisplayed("lnk_leftNavCourse");
		// isElementDisplayed("txt_welcomeMessage");
		isElementDisplayed("txt_dashboardHeading");
		// isElementDisplayed("btn_recentActivityToggle");
		isElementDisplayed("btn_viewGrades");
		isElementDisplayed("txt_comingUp");
		isElementDisplayed("lnk_viewCalendar");
		isElementDisplayed("start_new_course");
		isElementDisplayed("btn_ToggleNavMenuView");
		isElementDisplayed("lnk_canvasLogo");
		logMessage("Admin Dashboard has loaded successfully");
	}

	public void verifyInstructorEULApage() {
		logMessage("Instructor EULA page opens");
		element("checkbox_inst_eula").click();
		element("eula_accept_terms").click();

	}

	public void instructorSSO(String px_pwd, String email_inst) {
		fillText("txtbox_firstname", "FIName");
		fillText("txtbox_lastname", "LIName");
		fillText("txtbox_password", px_pwd);
		fillText("txtbox_confirm_email", email_inst);
		fillText("txtbox_confirm_password", px_pwd);
		element("btn_register").click();
		driver.getPageSource().contains("Macmillan LMSLink Canvas Token Registration");
		element("btn_authenticate").click();
		driver.getPageSource().contains("Macmillan Higher Education LMS Integration");
		element("btn_authorize").click();
		driver.getPageSource().contains("Macmillan LMSLink Canvas Token Registration");
		element("btn_authenticate").click();

	}

	public void refreshIfErrorOccured() {
		if (elements("lnk_errorMessage").size() > 0)
			refreshPage();
	}

	public void AddNewCourse(String courseName) {
		waitAndClick("btn_AddNewCourse");
		isElementDisplayed("textbox_CourseName");

		fillText(element("textbox_CourseName"), courseName);
		fillText(element("textbox_refCode"), getUniqueName("AutoCode"));

		waitAndClick("btn_addCourse");
		logMessage("Clicked on 'Add Course' button");

		refreshPage();
		logMessage("User creates a new Course");
		logMessage("Name of the created course is " + courseName);
	}

	public void acceptInvite() {
		wait.resetImplicitTimeout(5);
		if (elements("btn_Accept").size() == 1) {
			waitAndClick("btn_Accept");
			logMessage("User accepts the invitation");
		} else {
			logMessage("User is not asked to accept the Updated Terms of Use");
		}
		wait.resetImplicitTimeout(wait.timeout);
	}

	public void acceptInvite(String courseName) {
		waitAndClick("btn_AcceptForCourse", courseName);
		logMessage("User accepts the invite for " + courseName + ".");
	}

	public void clickOnIAgreeTerm() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		if (elements("checkbox_acceptTermsOfUse").size() == 1) {
			element("checkbox_acceptTermsOfUse").click();
			checkAgreementTerm = true;
			logMessage("User has check the term of user");
		} else {
			logMessage("User is not asked to accept the Updated Terms of Use");
			checkAgreementTerm = false;
		}
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}

	public void clickOnCancelButton() {
		if (checkAgreementTerm) {
			waitAndClick("btn_cancel");
			logMessage("User clicked on the Cancel button");
		}
	}

	public void acceptTermsOfUse() {
		//wait.resetImplicitTimeout(5);
		if (elements("btn_Accept").size() == 1) {
			element("btn_Accept").click();
			waitForElementToBeVisible("btn_Accept");
		} else {
			logMessage("User is not asked to accept the Updated Terms of Use");
		}
		wait.resetImplicitTimeout(wait.timeout);
	}

	public void clickOnCanvasLogo() {
		isElementDisplayed("lnk_canvasLogo");
		element("lnk_canvasLogo").click();
		logMessage("User clicked on canvas logo");
	}

	public void verifyMessageSuccessFullMessageAfterMergeUserAccounts() {
		customAssert.customAssertEquals(element("txt_successfulMessage").isDisplayed(), true,
				"Message is not found on page");
		logMessage("succeessfully merge user accounts");
	}

	public void verifyExistingInstDashboardPage() {
		isElementDisplayed("txt_dashboard");
		isElementDisplayed("txt_comingUp");
		isElementDisplayed("lnk_viewCalender");
		isElementDisplayed("start_new_course");
		isElementDisplayed("btn_viewGrades");
		logMessage("Dashboard page for existing Instructor verified");
	}

	public void clickOnCalendarLink() {
		waitAndClick("lnk_viewCalender");
		logMessage("Clicked On Calendar Link");
	}

	public void verifyCalendarLinkFields() {
		isElementDisplayed("btn_today");
		isElementDisplayed("btn_prev");
		isElementDisplayed("btn_next");
		isElementDisplayed("btn_week");
		isElementDisplayed("btn_month");
		isElementDisplayed("btn_agenda");
		isElementDisplayed("calendar_right");
		isElementDisplayed("calendar_right");
		isElementDisplayed("lnk_calendarFeed");
		logMessage("Verified all fields of Calendar Page");
	}

	public void clickOnPlusIcon() {
		waitAndClick("btn_plusIcon");
		logMessage("Clicked On Plus Icon Of Calendar");
	}

	public void verifyPlusIconModalContent() {
		isElementDisplayed("txt_editEvent");
		isElementDisplayed("input_title");
		isElementDisplayed("input_location");
		isElementDisplayed("btn_close");
		// waitAndClick("btn_close");
		logMessage("Verified Plus Icon Modal Content");
	}

	public void verifyCreateNewEvent(String eventName) {
		fillText("input_title", eventName);
		// String eventDate=(String) executeJavascript("return
		// document.getElementById('calendar_event_date').value");
		waitAndClick("btn_submit");
		isElementDisplayed("txt_eventName");
		clickUsingJavaScript("txt_eventName");
		waitAndClick("btn_delete");
		waitAndClick("btn_cnfDelete");
		logMessage("Verified Create New Event");
	}

	public void clickOnMoreOptions() {
		waitAndClick("lnk_moreOptions");
		logMessage("Clicked On More Options link");
	}

	public void verifyMoreOPtionsFieldOfEditEvent(String eventTitle) {
		verifyPageTitleContains("New Calendar Event");
		fillText("input_eventTitleOfMoreOptions", eventTitle);
		isElementDisplayed("input_locationOfMoreOptions");
		isElementDisplayed("input_address");
		waitAndClick("btn_createEvent");
		isElementDisplayed("txt_eventName");
		clickUsingJavaScript("txt_eventName");
		waitAndClick("btn_delete");
		waitAndClick("btn_cnfDelete");
		logMessage("Verified More Options oF Create New Event");
	}
	/**
	 * This method is used to click on submit button
	 */
	public void clickSubmitTermsBtn() {
		element("btn_submitOfTerms").click();
		logMessage("User clicked on Submit terms and conditions button");
	}
}