package com.qait.canvas.keywords;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.SeleniumWait;

public class EnrollUsersAndCreateLoginAction extends GetPage {
	WebDriver driver;
	SeleniumWait wait;

	public EnrollUsersAndCreateLoginAction(WebDriver driver) {
		super(driver, "EnrollUsers");
		this.driver = driver;
	}

	public void verifyAddPeoplePopUpContent() {
		isElementDisplayed("txt_header_popup", "Add People");
		isElementDisplayed("txt_header_popup", "Add user(s) by");
		isElementDisplayed("radioButton_addUsers", "Email Address");
		isElementDisplayed("radioButton_addUsers", "Login ID");
		isElementDisplayed("radioButton_addUsers", "SIS ID");
		isElementDisplayed("textarea_email");
		isElementDisplayed("drpDwn_role");
		isElementDisplayed("drpDwn_section");
		isElementDisplayed("btn_close");
		isElementDisplayed("btn_cancel");
		isElementDisplayed("btn_next");
		logMessage("verified all contents of add people popup");
	}

	public void verifyRoleDropDownOption() {
		List<WebElement> optionValues = elements("drpdwn_optionValue");
		customAssert.customAssertEquals(optionValues.get(0).getText(), "Student",
				optionValues.get(0).getText() + " not found in dropdown");
		customAssert.customAssertEquals(optionValues.get(1).getText(), "Teacher",
				optionValues.get(1).getText() + " not found in dropdown");
		customAssert.customAssertEquals(optionValues.get(2).getText(), "TA",
				optionValues.get(2).getText() + " not found in dropdown");
		customAssert.customAssertEquals(optionValues.get(3).getText(), "Designer",
				optionValues.get(3).getText() + " not found in dropdown");
		customAssert.customAssertEquals(optionValues.get(4).getText(), "Observer",
				optionValues.get(4).getText() + " not found in dropdown");
		logMessage("verifed all drop down option for role");
	}

	String emailAdd;

	public void EmailAddressEntryintoTextBox(String emailAddress) {
		emailAdd = emailAddress;
		element("textarea_email").clear();
		fillText("textarea_email", emailAddress);
		String verifyEmailValue = (String) executeJavascript("return $('[id*=\"TextArea\"]')[0].value");
		customAssert.customAssertEquals(verifyEmailValue, emailAddress, "value is not matched");
		logMessage("verified email address value from textbox");
	}

	public void clickNextButton() {
		waitAndClick("btn_next");
		logMessage("Clicked on next button");
	}

	public void selectDropDownValue(String option) {
		List<WebElement> optionValue = elements("drpdwn_optionValue");
		for (WebElement drpValue : optionValue) {
			if (drpValue.equals(option)) {
				drpValue.click();
				break;
			}
		}

	}

	public void verifyNextAddPeoplePopUpContents() {
		isElementDisplayed("txt_header_popup", "Add People");
		List<WebElement> tableColumnHeader = elements("txt_tableTitle");
		customAssert.customAssertEquals(tableColumnHeader.get(0).getText(), "Name",
				tableColumnHeader.get(0).getText() + " not found");
		customAssert.customAssertEquals(tableColumnHeader.get(1).getText(), "Email Address",
				tableColumnHeader.get(1).getText() + " not found");
		customAssert.customAssertEquals(tableColumnHeader.get(2).getText(), "Login ID",
				tableColumnHeader.get(2).getText() + " not found");
		customAssert.customAssertEquals(tableColumnHeader.get(3).getText(), "SIS ID",
				tableColumnHeader.get(3).getText() + " not found");
		customAssert.customAssertEquals(tableColumnHeader.get(4).getText(), "Institution",
				tableColumnHeader.get(4).getText() + " not found");
		isElementDisplayed("txt_header_popup", "Start Over");
		isElementDisplayed("txt_header_popup", "Add Users");
		logMessage("Verified Add People PopUp Contents");
	}

	public void clickButtonOverPopUP(String buttonName) {
		waitAndClick("txt_header_popup", buttonName);
		logMessage("Clicked the " + buttonName + " button");
	}

	String username;

	public void clickOnAddedUser(String addedUserName) {
		username = addedUserName;
		List<WebElement> userNames = elements("txt_AddedUser");
		for (WebElement uname : userNames) {
			System.out.println("name :" + uname);
			if (uname.getText().equals(addedUserName)) {
				uname.click();
				break;
			}
		}
		logMessage("Clicked at selected user : " + addedUserName);
	}

	public void verifyUserProfileAfterClickingSelectedUser() {
		customAssert.customAssertEquals(element("txt_userName").getText(), username, username + " not found");
		isElementDisplayed("nameAndEmail");
		customAssert.customAssertEquals(element("txt_profileTxt", "Full Name").getText(), username,
				"Full Name not found");
		customAssert.customAssertEquals(element("txt_profileTxt", "Display Name").getText(), username,
				"Display Name not found");
		String[] sortedUserNameValue = username.split(" ");
		Arrays.sort(sortedUserNameValue);
		String sortableName = element("txt_profileTxt", "Sortable Name").getText();
		String sortableArray[] = sortableName.split(",");
		customAssert.customAssertEquals(sortableArray[0].equals(sortedUserNameValue[0]), true,
				"Sortable Name not found");
		customAssert.customAssertEquals(element("txt_profileTxt", "Default Email").getText(), emailAdd,
				"Default Email not found");
		customAssert.customAssertEquals(element("txt_profileTxt", "Time Zone").getText(), "Eastern Time (US & Canada)",
				"time not found");
		isElementDisplayed("lnk_adminLink", "Edit");
		isElementDisplayed("lnk_adminLink", "Act as User");
		isElementDisplayed("lnk_adminLink", "Merge with Another User");
		isElementDisplayed("lnk_adminLink", "more user details...");
		logMessage("verified content of user profile pages");
	}

	public void verifyRightContentOfUserProfilePage() {
		ArrayList subHeader = new ArrayList();
		List<WebElement> headers = elements("txt_rightHeaders");
		long length = (Long) executeJavascript("return $('.page-action-list a').length");
		customAssert.customAssertEquals(headers.get(0).getText(), "More About This User",
				headers.get(0).getText() + " Name not found");
		customAssert.customAssertEquals(headers.get(1).getText(), "Registered Web Services",
				headers.get(1).getText() + " Name not found");
		for (int i = 0; i < length; i++) {
			hardWait(3);
			subHeader
					.add(((String) executeJavascript("return $('.page-action-list a')[" + i + "].textContent")).trim());
		}
		System.out.println(subHeader);
		customAssert.customAssertEquals(subHeader.get(0).toString(), "Grades", subHeader.get(0) + " not found");
		customAssert.customAssertEquals(subHeader.get(1).toString(), "Send Message", subHeader.get(1) + " not found");
		customAssert.customAssertEquals(subHeader.get(2).toString(), "Access Report", subHeader.get(2) + " not found");
		customAssert.customAssertEquals(subHeader.get(3).toString(), "User Account Details",
				subHeader.get(3) + " not found");
		logMessage("verified right content of user profile pages");
	}

	public void clickOnlink(String linkName) {
		hardWait(5);
		waitAndClick("lnk_adminLink", linkName);
		logMessage("Clicked at " + linkName + " link");
	}

	public void verifyEditLinkPopUpContents() {
		isElementDisplayed("txt_header_edit");
		isElementDisplayed("labelWithInput", "Full Name");
		isElementDisplayed("labelWithInput", "Display Name");
		isElementDisplayed("labelWithInput", "Sortable Name");
		isElementDisplayed("labelWithInput", "Time Zone");
		isElementDisplayed("labelWithInput", "Default Email");
		isElementDisplayed("btn_cancel_edit", "3");
		isElementDisplayed("btn_updateDetails_edit");
		logMessage("verified all the popup contents");
	}

	public void verifyUpdateDetailsFunctionality() {
		element("labelWithInput", "Full Name").click();
		element("labelWithInput", "Full Name").clear();
		fillText("labelWithInput", "Full Name", "UpdateFullName");
		logMessage("verified Update Details Functionality");
	}

	public void verifyMergeUserAccountsContents() {
		customAssert.customAssertEquals(element("txt_userName").getText(), "Merge User Accounts",
				"Merge User Accounts not found");
		isElementDisplayed("label_name");
		isElementDisplayed("label_userID");
		isElementDisplayed("btn_go_mergewithuser");
		logMessage("verified Merge User Account contents");
	}

	public void clickOnCancelButtons(String index) {
		waitAndClick("btn_cancel_edit", index);
		logMessage("Clicked at cancel button");
	}

	public void verifyListOfUsersAfterEnteringValidName() {
		fillText("input_name", "Deepak");
		hardWait(10);
		List<WebElement> nameList = elements("list_name");
		for (WebElement list : nameList) {
			customAssert.customAssertEquals(list.isDisplayed(), true, "name is not displayed");
		}

	}

	String selectedName;

	public void selectNameFromNameList(String name) {
		selectedName = name;
		List<WebElement> nameList = elements("list_name");
		for (WebElement list : nameList) {
			if (list.getText().equals(name)) {
				list.click();
				break;
			}
		}
	}

	public void verifySelectedNameFromNameList() {
		customAssert.customAssertEquals(element("txt_selectedName").getText(), selectedName,
				selectedName + " Not Found");
		logMessage("verified Selected Name From NameList");
	}

	public void clickOnSelectButton() {
		waitAndClick("btn_select_name");
		logMessage("Clicked on select button");
	}

	public void verifyMergeWithUserAccountsPageContents() {
		customAssert.customAssertEquals(element("txt_userName").getText(), "Merge User Accounts",
				"Merge User Accounts not found");
		customAssert.customAssertEquals(element("lnk_prepareMergeUsers").getText(), "Prepare to Merge Users",
				element("lnk_prepareMergeUsers").getText() + " not found");
		customAssert.customAssertEquals(element("lnk_switchUserPositions").getText(), "Switch User Positions",
				element("lnk_switchUserPositions") + " not found");
		customAssert.customAssertEquals(elements("lnk_mergeUsers").get(0).getText().contains(username), true,
				elements("lnk_mergeUsers").get(0).getText() + " link not matched");
		customAssert.customAssertEquals(elements("lnk_mergeUsers").get(1).getText().contains(selectedName), true,
				elements("lnk_mergeUsers").get(1).getText() + " link not matched");
		logMessage("verified Merge With User Accounts Page Contents after selecting name from list");
	}

	public void clickOnSwitchUserPositions() {
		waitAndClick("lnk_switchUserPositions");
		logMessage("Clicked on switch user positions");
	}
   
	public void verifySwitchUserPositions() {
		String userNameBeforeSwitching=element("userPositions").getText();
		waitAndClick("lnk_switchUserPositions");
		String userNameAfterSwitching=element("userPositions").getText();
		customAssert.customAssertEquals(userNameBeforeSwitching.equals(userNameAfterSwitching), false, "username are not switched");
		logMessage("Verifed Switch User Positions");
	}

	public void clickOnMergeSomeoneElseWithUserName(String userName) {
		List<WebElement> mergeuserNameWithSomeOne=elements("lnk_mergeUsers");
		for(WebElement name:mergeuserNameWithSomeOne)
		{
			if(name.getText().contains(userName))
			{
				name.click();
				break;
			}
		}
		logMessage("Clicked on merge username with someone");
	}
	public void clickOnPrepareToMergeUsersLink()
	{
		waitAndClick("lnk_prepareMergeUsers");
		logMessage("Clicked on Prepare To Merge Users Link");
	}

	public void verifyPrepareToMergeUserContents() {
		customAssert.customAssertEquals(element("txt_userName").getText(), "Really Merge User Accounts?",
				"Merge User Accounts not found");
		isElementDisplayed("txt_meregUserAccounts");
		isElementDisplayed("btn_cancel_edit","1");
		logMessage("Verifed Prepare To Merge User Contents");
	}

	public void clickOnMergeUserAccountsButton() {
		waitAndClick("txt_meregUserAccounts");
		logMessage("Clicked at Merge User Accounts Button");
	}
}
