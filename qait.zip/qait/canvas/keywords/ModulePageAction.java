package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
import static com.qait.automation.utils.YamlReader.getData;

import java.util.List;

public class ModulePageAction extends GetPage {

	public ModulePageAction(WebDriver driver) {
		super(driver, "ModulePage");
	}

	public void verifyModulePageOpens() {
//		verifyPageTitleContains();
		logMessage("Module Page Opens");
	}

//	public void clickOnContentPresentInTheModule() {
//		waitAndClick("dev_content_lnk");
//		logMessage("User is navigated to Load TOC Page");
//	}
//	
//	public void openButtonToLoadContentInANewWindow(){
//		scrollDown(element("button_TOC_In_A_New_Window"));
//		waitAndClick("button_TOC_In_A_New_Window");
//		changeWindow(1);
//		logMessage("User waitAndClicks on Button Load TOC In A New Window");
//	}
//
//	public void clickOnGearIconToAddContent(){
//		waitAndClick("icon_gear");
//		isElementDisplayed("link_AddContent");
//		logMessage("User clicks on gear icon");
//	}

	public void clickOnAddContent() {
		// Added Hard Wait as for wait for page to load completely
		hardWait(2);
		waitAndClick("link_AddContent");
		executeJavascript("document.getElementsByClassName('add_module_item_link btn')[0].click();");
		logMessage("User wait And clicks on 'Add Content and Add Item' button to open Module Window");
	}

	public void selectExternalToolAndNavigateToContentToc(String external_tool) {
		selectProvidedTextFromDropDown(element("dropdown_AddModule"), "External Tool");
		logMessage("User selected 'External Tool' from 'Add Module Item Select' drop down");

		element(("externalTool"), external_tool).click();
		logMessage("Clicks on 'External Tool' on Add Item to Auto Module dialog box");

		isElementDisplayed("heading_contentToc");
		switchToFrame(element("frame_resourceSelection"));
		logMessage("User selects external tool and navigate to content toc");
	}

//	public void clickOnAddItemAndDeployContent(){
//		switchToDefaultContent();
//		isElementDisplayed("textbox_url");
//		isElementDisplayed("textbox_itemTitle");
//		scrollDown(element("checkbox_LoadInNewTab"));
//		waitAndClick("checkbox_LoadInNewTab");
//		waitAndClick("button_AddItem");
//		hardWait(1);
//		isElementDisplayed("dev_content_lnk");
//		String contentText=element("dev_content_lnk").getText();
//		customAssert.customAssertTrue(contentText!="LaunchPad", "Item Name is not LaunchPad");
//		customAssert.customAssertTrue(contentText.contains(getData("contentName")), "Item Name is not PROLOGUE INTRODUCTION");
//		logMessage("User verifies that content has been deployed");
//	}
//	
//	public void deleteContent(){
//		hover(element("lnk_chain"));
//		waitAndClick("link_deleteContent");
//		handleAlert();
//		logMessage("User deletes content");
//	}
//	
//	public void openContentInANewWindow(){
//		waitAndClick("dev_content_lnk");
//		isElementDisplayed("button_TOC_In_A_New_Window");
//		logMessage("User goes on opening the content and load content in a new button is verified");
//	}
//	
//	public void clickOnAddItemAndDeployContentLoadContentInIframe(){
//		switchToDefaultContent();
//		isElementDisplayed("textbox_url");
//		isElementDisplayed("textbox_itemTitle");
//		scrollDown(element("button_AddItem"));
//		waitAndClick("button_AddItem");
//
//		isElementDisplayed("dev_content_lnk");
//		String contentText = element("dev_content_lnk").getText();
//		customAssert.customAssertTrue(contentText != "LaunchPad", "Item Name is not LaunchPad");
//		customAssert.customAssertTrue(contentText.contains(getData("contentName")),
//				"Item Name is not " + getData("contentName"));
//		logMessage("User verifies that content has been deployed");
//	}
//	
//	public void openContentInTheSameWindow(){
//		waitAndClick("dev_content_lnk");
//		handleAlert();
//		changeWindow(1);
//		logMessage("User goes on opening the content");
//	}
//
//	public void createAModule(){
//		isElementDisplayed("text_Module_Page");
//		isElementDisplayed("btn_CreateAModule");
//		hardWait(2);
//		executeJavascript("document.getElementsByClassName('btn btn-primary add_module_link')[0].click();");
//		fillText(element("textbox_ContextModuleName"),"autoModule");
//		waitAndClick("btn_AddModule");
//		logMessage("User creates a module");
//	}
//
//	public void publishDeployedContent(String contentName){
//		scroll(element("icon_publishCloud", contentName));
//		waitForElementToBeVisible("icon_publishCloud", contentName);
//		element("icon_publishCloud", contentName).click();
//	}
//	
//	public void openTheContentInModule(String contentName){
//		waitForElementToBeVisible("lnk_contentInModule", contentName);
//		scrollDown(element("lnk_contentInModule", contentName));
//		hardWait(2);
//		element("lnk_contentInModule", contentName).click();
//	}
//	
//	public void openTheLastContentInModule(){
//		waitForElementToBeVisible("lnk_lastContentItem");
//		scrollDown(element("lnk_lastContentItem"));
//		hardWait(2);
//		element("lnk_lastContentItem").click();
//	}
//	
//	public void publishAllDeployedContent(){
//		waitForElementToBeVisible("icon_publishAllContentCloud");
//		element("icon_publishAllContentCloud").click();
//		refreshPage();
//	}
	public void verifyViewProgress(String courseName) {
		isElementDisplayed("btn_viewProgress");
		waitAndClick("btn_viewProgress");
		verifyPageTitleContains("Module Progression by Student: " + courseName);
	}

	public void publishDeployedModule(String moduleName) {
//		waitForElementToBeVisible("publishModule", moduleName);
//		isElementDisplayed("publishModule", moduleName);
//		hoverClick(element("publishModule", moduleName));
		hardWait(5);
		clickUsingJavaScript("publishModule", moduleName);
//		executeJavascript("document.querySelector('.publish-icon.module.unpublished.publish-icon-publish i').click()");
		hardWait(5);
		logMessage("Clicked on publish Module");
		waitForJqueryToFinish();
		if (getElementCount("unpublished_assignments") > 0) {
			for (WebElement unPublishedItems : elements("unpublished_assignments")) {
//				unPublishedItems.click();
//				clickUsingJS(unPublishedItems);
				hoverClick(unPublishedItems);
				logMessage("Instructor has published all the items");
			}
		}
		logMessage(moduleName + " and all items under the module have been published.");
	}

//	public void clickOnAddButtonModule(String moduleName){
//		element("btn_add", moduleName).click();
//		
//		logMessage("User has clicked on + button");
//	}
//	
//	public void selectExternalToolFromDropdownAndCheckLoadInNewWindowCheckbox(){
//		selectProvidedTextFromDropDown(element("dropdown_AddModule"), "External Tool");
//		logMessage("User selected 'External Tool' from 'Add Module Item Select' drop down");
//		scrollDown(element("checkbox_LoadInNewTab"));
//		waitAndClick("checkbox_LoadInNewTab");
//		
//	}
//	
//	public void clickOnMacmillanHigherEdTool(){
//		isElementDisplayed("lnk_macmillanTool");
//		element("lnk_macmillanTool").click();
//		
//		switchToFrame("iframe");
//		waitForElementToBeVisible("lbl_launchPad");
//		waitForElementToBeVisible("lbl_eBook");
//		
//		logMessage("User is on 'Link Resource from External Tool' page");
//	}
//	
//	public void selectItemToDeploy(){
//		element("radiobtn_eBook").click();
//		verifyRadioButtonSelected("radiobtn_eBook");
//		waitAndScrollToElement("btn_deployContent");
//		element("btn_deployContent").click();
//		switchToDefaultContent();
//		element("btn_addItem").click();
//	}
//	
//	public void verifyDeployedExternalLink(){
//		isElementDisplayed("lnk_eBookHome");
//		logMessage("Item has been deployed successfully");
//	}
//	
//	public void launchEbookAssignment(){
//		element("lnk_eBookHome").click();
//		waitForElementToBeVisible("lnk_ltiEbook");
//		element("lnk_ltiEbook").click();
//		changeWindow(1);
//	}

	public void verifyGradesOnModulesPage(String expectedPoints) {
		// String actualPoints;
		isElementDisplayed("txt_pointsPossible", expectedPoints);
		// actualPoints = element("txt_pointsPossible").getText();
		// logMessage(actualPoints);
		// isStringMatching(actualPoints, expectedPoints);
		logMessage("Grades have been successfully updated on 'Modules' page");
	}
	public void verifyGradesForApostrophes(String expectedPoints) {
		// String actualPoints;
		isElementDisplayed("txt_ApostrophesPoints", expectedPoints);
		// actualPoints = element("txt_pointsPossible").getText();
		// logMessage(actualPoints);
		// isStringMatching(actualPoints, expectedPoints);
		logMessage("Grades have been successfully updated on 'Modules' page");
	}

	public void verifyQuizAssignmentsAreRemovedFromModulesPage(String quiz) {
		wait.resetImplicitTimeout(3);
		if (getElementCount("lnk_quizAssignment", quiz) == 0) {
			logMessage("Assignment has been successfully removed from 'Modules' page");
		}
		wait.resetImplicitTimeout(wait.getTimeout());
	}

	public void clickAddModuleLink() {
		hardWait(4);
		executeJavascript("$('.btn.btn-primary.add_module_link')[0].click()");
		logMessage("Clicked On Add Module Icon");
	}

	public void verifyAddModuleLink() {
		isElementDisplayed("header_addModule");
		isElementDisplayed("input_moduleName");
		isElementDisplayed("label_lockUntil");
		isElementDisplayed("txt_preRequisite");
		isElementDisplayed("link_AddPreRequisite");
		isElementDisplayed("btn_AddModule");
		waitAndClick("btn_AddModule");
		isElementDisplayed("errorText");
		isElementDisplayed("btn_cancel");
		logMessage("Verified all text of Add Module Link Popup");
	}

	public void clickOnLockUntilCheckBox() {
		waitForElementToBeVisible("label_lockUntil");
		// waitAndClick("label_lockUntil");
		executeJavascript("$('#unlock_module_at')[0].click()");
		logMessage("Clicked On Lock Until CheckBox");
	}

	public void verifyLockUntilAfterCheck(String date) {
		isElementDisplayed("input_unlockAt");
		isElementDisplayed("btn_datePicker");
		waitAndClick("btn_datePicker");
		waitAndClick("field_calender", date);
		waitAndClick("field_calender", "Done");
		String dateValue = (String) executeJavascript("return $('#context_module_unlock_at')[0].value");
		customAssert.customAssertTrue(dateValue.contains(date + ","), "Date value is not matched");
		logMessage("Verified Lock Until After Clicking Checkbox");
	}

	public void clickOnAddPreRequisite() {
		waitAndClick("link_AddPreRequisite");
		logMessage("Clicked On AddPreRequisite Link");
	}

	public void verifyAddPreRequisiteLink() {
		isElementDisplayed("drpDwn_SelectModule");
		isElementDisplayed("btn_CancelIcon");
		waitAndClick("btn_CancelIcon");
		clickOnAddPreRequisite();
		selectTextFromDropDown("drpDwn_SelectModule", "Test Module");
		element("input_moduleName").click();
		fillText("input_moduleName", "Test Add Pre");
		waitAndClick("btn_AddModule");
		logMessage("Verified Add Pre Requisite And Created Module");
	}

	public void clickOnPlusIconButton(String moduleName) {
		waitAndClick("btn_PlusIcon", moduleName);
		logMessage("Clicked On Plus Icon For " + moduleName);
	}

	public void verifyPulsIconModalWindow() {
		isElementDisplayed("header_PlusIconModalPopup");
		List<WebElement> drpDwnList = elements("drpDwn_Addoption");
		customAssert.customAssertEquals(drpDwnList.get(0).getText(), "Assignment", "Assignment is not mathced");
		customAssert.customAssertEquals(drpDwnList.get(1).getText(), "Quiz", "Quiz is not matched");
		customAssert.customAssertEquals(drpDwnList.get(2).getText(), "File", "File is not matched");
		customAssert.customAssertEquals(drpDwnList.get(3).getText(), "Content Page", "Content Page is not mathced");
		customAssert.customAssertEquals(drpDwnList.get(4).getText(), "Discussion", "Discussion is not mathced");
		customAssert.customAssertEquals(drpDwnList.get(5).getText(), "Text Header", "Text Header is not mathced");
		customAssert.customAssertEquals(drpDwnList.get(6).getText(), "External URL", "External URL is not mathced");
		customAssert.customAssertEquals(drpDwnList.get(7).getText(), "External Tool", "External Tool is not mathced");

		List<WebElement> drpDwnIndentation = elements("drpDwn_Indentation");
		customAssert.customAssertEquals(drpDwnIndentation.get(0).getText(), "Don't Indent",
				"Don't Indent is not mathced");
		customAssert.customAssertEquals(drpDwnIndentation.get(1).getText(), "Indent 1 Level",
				"Indent 1 Level is not matched");
		customAssert.customAssertEquals(drpDwnIndentation.get(2).getText(), "Indent 2 levels",
				"Indent 2 levels is not matched");
		customAssert.customAssertEquals(drpDwnIndentation.get(3).getText(), "Indent 3 levels",
				"Indent 3 levels is not mathced");
		isElementDisplayed("icon_close", "3");
		isElementDisplayed("btn_addItem");
		logMessage("Verified Puls Icon Modal Window Content");
	}

	public void selectDropDownOption(String drpDwnOption) {
		selectTextFromDropDown("drpDwn_Addoption", drpDwnOption);
	}

	public void verifyExternalToolContentAfterSelectingFromDropDown() {
		isElementDisplayed("input_url");
		isElementDisplayed("input_pageName");
		isElementDisplayed("chkBox_LoadInNewTab");
		isElementDisplayed("icon_close", "3");
		isElementDisplayed("btn_addItem");
		logMessage("Verified External Tool Content After Selecting Form Drop Down option");
	}

	public void clickOnMacLearningToolFromExternalToolDropDownOption(String envToolName) {
		List<WebElement> list = elements("name_tool");
		for (WebElement toolName : list) {
			if (toolName.getText().equals(envToolName)) {
				toolName.click();
			}
		}
	}

	public void verifyAutoFilledOfUrlAndPageName(String tocName) {
		String pageName = (String) executeJavascript("return $('#external_tool_create_title')[0].value");
		customAssert.customAssertEquals(pageName, tocName, "Expected message is not mathced");
		waitAndClick("btn_addItem");
		isElementDisplayed("lnk_tocName", tocName);
	}

	public void clickOnCancelAndVerify() {
		waitAndClick("btn_cancel");
		verifyElementNotDisplayed("header_editModule");
		logMessage("Verified Cancel Button Functionality");
	}

	public void verifyAddRequirementButton() {
		waitAndClick("lnk_addRequirement");
		Boolean checkedValue = (Boolean) executeJavascript("return $('#context_module_requirement_count_')[0].checked");
		customAssert.customAssertEquals(checkedValue, true, "By default radion button not checked");
		List<WebElement> txtString = elements("txt_afterClickingAddRequirements");
		customAssert.customAssertEquals(txtString.get(0).getText(), "Requirements", "Requirements not matched");
		customAssert.customAssertEquals(txtString.get(1).getText(), "Students must complete all of these requirements",
				"expected text not matched");
		customAssert.customAssertEquals(txtString.get(2).getText(),
				"Students must move through requirements in sequential order", "expected text not matched");
		customAssert.customAssertEquals(txtString.get(3).getText(), "Student must complete one of these requirements",
				"expected text not matched");
		logMessage("Verified Text After Clicking Add Requirements");
	}

	public void verifyEditModuleName(String moduleName, String updatedModuleName) {
		element("input_moduleName").click();
		fillText("input_moduleName", updatedModuleName);
		waitAndClick("btn_AddModule");
		customAssert.customAssertEquals(moduleName.equals(updatedModuleName), true, "Module name is not updated");
	}

	public void verifyMoveModuleModalPopUp() {

	}

}