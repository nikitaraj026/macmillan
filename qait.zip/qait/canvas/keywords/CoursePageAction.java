package com.qait.canvas.keywords;

import static org.testng.Assert.assertTrue;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.yaml.snakeyaml.Yaml;
import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.ConfigPropertyReader;

public class CoursePageAction extends GetPage {

	public CoursePageAction(WebDriver driver) {
		super(driver, "CoursePage");
	}

	// *******************************************
	// Dynamic Yaml Functions for canvas

	public void writeDataToYaml(Map<String, Object> data) {
		Yaml yaml = new Yaml();
		FileWriter writer = null;
		try {
			writer = new FileWriter("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "CANVAS" + File.separator + "DynamicTestData.yml");
			yaml.dump(data, writer);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void writeDataToYamlforUoP(Map<String, Object> data) {
		Yaml yaml = new Yaml();
		FileWriter writer = null;
		try {
			writer = new FileWriter("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "CANVAS" + File.separator + "UoP.yml");
			yaml.dump(data, writer);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (writer != null) {
				try {
					writer.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	private static String getMapValue(Map<String, Object> object, String token) {
		// TODO: check for proper yaml token string based on presence of '.'
		// Adding unnecessarily comment
		String[] st = token.split("\\.");
		return parseMap(object, token).get(st[st.length - 1]).toString();
	}

	private static Map<String, Object> parseMap(Map<String, Object> object, String token) {
		if (token.contains(".")) {
			String[] st = token.split("\\.");
			object = parseMap((Map<String, Object>) object.get(st[0]), token.replace(st[0] + ".", ""));
		}
		return object;
	}

	public String readDataFromYaml(String token) {
		Reader doc = null;
		try {
			doc = new FileReader("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "CANVAS" + File.separator + "DynamicTestData.yml");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		Yaml yaml = new Yaml();
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);
		return getMapValue(object, token);
	}

	public String readDataFromYamlforUoP(String token) {
		Reader doc = null;
		try {
			doc = new FileReader("src" + File.separator + "test" + File.separator + "resources" + File.separator
					+ "testdata" + File.separator + "CANVAS" + File.separator + "UoP.yml");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		Yaml yaml = new Yaml();
		Map<String, Object> object = (Map<String, Object>) yaml.load(doc);
		return getMapValue(object, token);
	}

	/**
	 * Method to verify that user is on course home page
	 * 
	 * @param courseName
	 */
	public void verifyUserIsOnCoursePage(String courseName) {
		System.out.println(getPageTitle() + "page title is+=============");
		if (getPageTitle().equals(courseName)) {
			logMessage("User is on " + courseName + " page.");
		} else {
			logMessage("User is not on course homepage");
		}
	}

	/**
	 * Method to navigate to PX (Launchpad) page
	 */
	public void userNavigateToPxWindow() {
		hardWait(3);
		changeWindow(1);
	}

	/**
	 * Method to click on left tab on course page
	 * 
	 * @param tabMenu
	 */
	public void clickLeftTabOnCoursePage(String tabMenu) {
//		waitAndScrollToElement("lnk_leftTabMenu", tabMenu);
//		waitAndClick("lnk_leftTabMenu", tabMenu);
		clickUsingJavaScript("lnk_leftTabMenu", tabMenu);
		logMessage("\"" + tabMenu + "\" has been clicked on left tab menu.");
	}

	/**
	 * Method to click 'Assignments'
	 */
	public void clickAssignmentsOnCoursePage() {
		hardWait(5);
		clickLeftTabOnCoursePage("Assignments");
		hardWait(5);
	}

	public void useCourseOnDashboard(String courseName) {
		waitForElementToBeVisible("lnk_courseName", courseName);
		isElementDisplayed("lnk_courseName", courseName);
		waitAndClick("lnk_courseName", courseName);
		logMessage("Selected course from Dashboard" + courseName);
	}

	public void verifyAssignmentOnCoursePage() {
		isElementDisplayed("link_assignmentName", "Auto_Quiz");
		isElementDisplayed("link_assignmentName", "Manual_Quiz");
		isElementDisplayed("link_assignmentName", "Chapter 5 Introduction");
		logMessage("Assignment are displayed to students");
	}

	public void verifyAssignmentOnCoursePageForSapling() {
		isElementDisplayed("link_assignmentName", "Sapling_auto_quiz");
		logMessage("Assignment are displayed to students");
	}

	public void verifyAssignmentForAchieve() {
		isElementDisplayed("link_assignmentName", "Apostrophes");
		logMessage("Assignment are displayed to students");
	}

	/**
	 * Method to click 'Discussions'
	 */
	public void clickDiscussionsOnCoursePage() {
		clickLeftTabOnCoursePage("Discussions");
	}

	/**
	 * Method to click 'Grades'
	 */
	public void clickGradesOnCoursePage() {
		clickLeftTabOnCoursePage("Grades");
	}

	/**
	 * Method to click 'People'
	 */
	public void clickPeopleOnCoursePage() {
		clickLeftTabOnCoursePage("People");
	}

	/**
	 * Method to click 'Modules'
	 */
	public void clickModulesOnCoursePage() {
		clickLeftTabOnCoursePage("Modules");
		logMessage("User is navigated to Module Page");
		hardWait(5);
	}

	/**
	 * Method to click 'Settings'
	 */
	public void clickSettingsOnCoursePage() {
		clickLeftTabOnCoursePage("Settings");
	}

	/**
	 * Method to click Macmillan Tool for Create Course functionality for UoP
	 */

	public void clickMacmillanLearningCreateCourseToolUoP() {
		clickLeftTabOnCoursePage("Macmillan Learning Load Testing - Create");
	}

	/**
	 * Click on Macmillan tool to create master copy for UoP
	 */

	public void clickMacmillanLearningMasterCopyTool() {
		clickLeftTabOnCoursePage("Macmillan Learning Load Testing - Master Copy");
	}

	/**
	 * Click on Macmillan Tool to create Static copy for UoP
	 */

	public void clickMacmillanLearningStaticPairingTool() {
		clickLeftTabOnCoursePage("Macmillan Learning Load Testing - Static Pairing");
	}

	/**
	 * Click on Macmillan Learning Tools Widget
	 */

	public void clickMacmillanLearningToolsWidget() {
		clickLeftTabOnCoursePage("Macmillan Learning Load Testing - Tools Widget");
	}

	public void verifyCourseDetailsPage(String courseName) {
		verifyPageTitleContains("Course details: " + courseName);
		isStringMatching(element("breadcrumb_settings").getText(), "Settings");
		logMessage("User is on Course Details page");
	}

	public void verifyNavigationTab() {
		isElementDisplayed("txt_home");
		logMessage("User is on Navigation tab");
	}

	// Inside Home
	/**
	 * Method to publish a course
	 */
	public void publishCourse() {
		// waitAndClick("lnk_published");
		if (getElementCount("lnk_PublishCourse") == 1) {
			logMessage("Course is already published");
		} else {
			waitAndClick("lnk_published");
			logMessage("Instructor clicked on 'Publish' link");
			waitForElementToBeVisible("btn_unpublish");
			logMessage("Course has been successfully published");
		}
	}

	// Inside Assignments
	/**
	 * Method to click on given assignments
	 * 
	 * @param assignment
	 */
	public void clickOnAssignmentLink(String assignment) {
		wait.waitForPageToLoadCompletely();
		waitForElementToBeVisible("lnk_attemptAssignment", assignment);
		hardWait(4);
		waitAndClick("lnk_attemptAssignment", assignment);
		wait.waitForPageToLoadCompletely();
		logMessage("Student has clicked on " + assignment + "assignment");
		waitForElementToBeVisible("lnk_loadQuiz");
		element("lnk_loadQuiz").click();
		logMessage("Student has clicked on load quiz button");
		changeWindow(1);
	}

	public void clickOnAssignmentLinkWillo(String assignment) {
		wait.waitForPageToLoadCompletely();
		waitForElementToBeVisible("lnk_attemptAssignment", assignment);
		hardWait(4);
		waitAndClick("lnk_attemptAssignment", assignment);
		wait.waitForPageToLoadCompletely();
		logMessage("Student has clicked on " + assignment + "assignment");

	}

	// Inside Grades
	/**
	 * Method to verify deployed content in gradebook
	 * 
	 * @param quiz1
	 * @param quiz2
	 * @param chapterContent
	 */
	public void verifyContentDeployedInGradebook(String quiz1, String quiz2, String chapterContent) {
		verifyPageTitleContains("Gradebook");
		isElementDisplayed("lnk_assignment", quiz1);
		isElementDisplayed("lnk_assignment", quiz2);
		isElementDisplayed("lnk_assignment", chapterContent);

		logMessage("Gradebook entries are created for all the deployed gradable assignments");
	}

	/**
	 * Method to get row of student name
	 * 
	 * @param studentName
	 * @return
	 */
	private int getStudentNameRow(String studentName) {
		int studentNameRow = 0;
		int rowCount = getElementCount("lnk_studentNameList");
		for (int i = 1; i <= rowCount; i++) {
			System.out.println("Following are the names of student in lit:--------->"
					+ getTextFirstElementOfList("lnk_studentName", String.valueOf(i)));
			if (studentName.contains(getTextFirstElementOfList("lnk_studentName", String.valueOf(i)))) {
				studentNameRow = i;
				break;
			}
		}
		return studentNameRow;
	}

	private int getStudentNameRowforSap(String studentName) {
		int studentNameRow = 0;
		int rowCount = getElementCount("lnk_studentNameList");
		for (int i = 1; i <= rowCount; i++) {
			if (getTextFirstElementOfList("lnk_studentName", String.valueOf(i)).equals(studentName)) {
				studentNameRow = i;
				break;
			}
		}
		return studentNameRow;
	}

	/**
	 * Method to get column of assignment
	 * 
	 * @param
	 * @return
	 */
	private int getAssignmentColumn(String assignmentName) {
		int assignmentNameColumn = 0;
		int rowCount = getElementCount("lnk_assignmentNameList");
		for (int i = 1; i <= rowCount; i++) {
			if (getTextFirstElementOfList("lnk_assignmentName", String.valueOf(i)).equals(assignmentName)) {
				assignmentNameColumn = i;
				break;
			}
		}
		return assignmentNameColumn;
	}

	/**
	 * Method to verify grades in gradebook
	 * 
	 * @param
	 */
	public void verifyGradesInCanvasGradebook(String studentName, String assignmentName, String expectedGrades) {
		/*
		 * List<String> students = null; for (int i = 1; i < 10; i++) { try {
		 * isElementDisplayed("lnk_allStudentsindex", Integer.toString(i));
		 * students.add(element("lnk_allStudentsindex", Integer.toString(i)).getText());
		 * Iterator<String> iter = students.listIterator(); for (int index = 0; index <
		 * students.size(); index++) { if (iter.next().equals(userName)) { if
		 * (element("txt_grades", Integer.toString(index)).getText().equals(10)) {
		 * logMessage("Grades have been updated successfully"); } else {
		 * logMessage("No grades found"); } } } } catch (NullPointerException e) {
		 * break; } catch (Exception e){ e.printStackTrace(); } }
		 */
		System.out.println("Student Name is-----------------> " + studentName);
		int row = getStudentNameRow(studentName);
		int column = getAssignmentColumn(assignmentName);

//		String actualGrades = getTextFirstElementOfList("txt_grades",String.valueOf(row),String.valueOf(column));
//		customAssert.assertEquals(actualGrades, expectedGrades, "<span><b><font color=red>No grades found</font></b></span>");
		System.out.println("The row and column number for the student is " + row + "and" + column);
		verifyTextOfElementIsCorrect("txt_grades", String.valueOf(row), String.valueOf(column), expectedGrades);
		logMessage(assignmentName + " grades for student " + studentName + " have been verified");
		/*
		 * int count = getElementCount("lnk_studentNameList"); for(int
		 * i=1;i<=count;i++){ String strr = element("lnk_studentName",
		 * Integer.toString(i)).getText(); if(strr.equals(studentName)){ if
		 * (element("txt_grades2", Integer.toString(i)).getText().equals(10)) {
		 * logMessage("Grades have been updated successfully"); } else {
		 * logMessage("<span><b><font color=red>No grades found</font></b></span>"); } }
		 * }
		 */
	}

	/*
	 * Create User Logins
	 */

	public void createLoginForUser(String userName, String password) {
		clickOnPeopleNavigationLink();
		clickOnUserNameLink(userName);
		verifyUserDetailPage(userName);
		clickOnMoreUserDetails();
		verifyMembershipLoginInformationSection();
		clickOnAddLoginLink();
		verifyAddLoginModalWindow();
		enterLoginDetails(userName, password);
		clickOnAddLoginButton();
		verifyUserLogin(userName);
	}

	/**
	 * Method to navigate to People Page
	 */
	public void clickOnPeopleNavigationLink() {
		hardWait(3);
		clickLeftTabOnCoursePage("People");
		logMessage("Admin clicked on People navigation link from left panel");
	}

	/**
	 * Method to verify admin is on People page
	 */
	public void verifyUserIsOnPeoplePage() {
		isElementDisplayed("breadcrumb_people");
		logMessage("Admin is on People page");
	}

	/**
	 * Admin click on +People button
	 */
	public void clickOnPeopleButton() {
		refreshPage();
		waitScrollAndClick("btn_AddPeople");
		logMessage("Admin has clicked on +People button");
	}

	/**
	 * Verify the fields on Add People Modal Window
	 */
	public void verifyAddPeopleModalWindow() {
//		isElementDisplayed("radiobutton_addUser", "Email Address");
//		isElementDisplayed("radiobutton_addUser", "Login ID");
//		isElementDisplayed("radiobutton_addUser", "SIS ID");
		isElementDisplayed("textbox_AddUsers");
		isElementDisplayed("dropdown_role");
		isElementDisplayed("dropdown_enrollmentType");
		isElementDisplayed("btn_addPeopleCancel");
		logMessage("Admin is on Add People modal window");
	}

	// Inside People
	/**
	 * Method to add people inside course
	 * 
	 * @param role
	 * @param email
	 */
	public void enterUserDetails(String role, String email) {
		scrollToElementUsingJavaScript("textbox_AddUsers");
		element("textbox_AddUsers").sendKeys(email);
		// fillText(element("textbox_AddUsers"), email);
		// scrollToElementUsingJavaScript("dropdown_enrollmentType");
		hardWait(4);
		// executeJavascript(String.format("document.getElementById('peoplesearch_select_role').value=%d"
		// ,role));

		// selectProvidedTextFromDropDown(element("dropdown_enrollmentType"), role);

		if (role.equalsIgnoreCase("teacher")) {
			waitAndClick("dropdown_enrollmentType");
			element("dropdown_enrollmentType").sendKeys(Keys.DOWN);
			element("dropdown_enrollmentType").sendKeys(Keys.RETURN);
		}
		waitAndClick("btn_Next");
		logMessage("Admin has entered the user details and clicked on Next button");
	}

	public void verifyUserDetails(String email) {
		isElementDisplayed("txt_emailADdress", email);
		logMessage("User details verified");
	}

	public void clickOnAddUserButton() {
		waitForElementToBeVisible("btn_Next");
		waitAndClick("btn_Next");
		logMessage("Admin clicked on Add User button");
	}

	public void verifyUserIsAddedToCourse(String UserName) {
		// isElementDisplayed("txt_loginId", email);
//		isElementDisplayed("txt_userName", UserName);
		logMessage(UserName + " added in the course");
	}

	/**
	 * Method to verify that students enrollment
	 */
	public void verifyStudentEnrollment() {
		int studentCount = getElementCount("txt_studentLoginId");
		if (studentCount > 0) {
			List<WebElement> studName = new ArrayList<WebElement>(elements("txt_studentLoginId"));
			for (WebElement studentName : studName) {
				hardWait(2);
				logMessage("Enrolled User Email:" + studentName.getText().replaceAll("\\s+", ""));
			}
		} else {
			customAssert.customAssertEquals(studentCount, 3, "Error in enrolling student");
		}
	}

	/**
	 * Method to click on user name link
	 * 
	 * @param name
	 */
	public void clickOnUserNameLink(String name) {
		reloadPageUsingJs();
		clickLeftTabOnCoursePage("People");
		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page scrolled to maximum Y-cooridnate");
		waitForElementToBeVisible("txtbox_searchPeople");

		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page again scrolled to maximum Y-cooridnate");
		waitForElementToBeVisible("txt_userName", name);

		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page scrolled to maximum Y-cooridnate to find newly added user");

		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page again scrolled to maximum Y-cooridnate to find newly added user");
		scrollToBottom();
		hardWait(3);
		waitScrollAndClick("txt_userName", name);
		logMessage("Admin clicked on user name link");
		clickUsingJavaScript("card_userName",name);
		logMessage("Admin clicked on user name card displayed on the right side");
	}

	public void verifyUserDetailPage(String name) {
		waitForElementToBeVisible("breadcrumb_userName",name);
		isElementDisplayed("breadcrumb_userName",name);
		logMessage("Admin is on user details page");
	}

	public void verifyPageTitle(String pageTitle) {
		waitForPageToLoadCompletely(pageTitle);
	}

	/**
	 * Method to click on more user details and verify membership and login
	 * information section are displayed
	 */

	public void clickOnMoreUserDetails() {
		scrollDown(element("lnk_moreDetails"));
		waitAndClick("lnk_moreDetails");
		hardWait(3);
		logMessage("Clicked on 'More Details' link for newly created user");
	}

	public void verifyMembershipLoginInformationSection() {
		isStringMatching(element("txt_membership").getText(), "Membership(s)");
		logMessage("Membership and Login information section are displayed");
	}

	public void clickOnAddLoginLink() {
		// scrollDown(element("lnk_AddLogin"));
		// waitAndClick("lnk_AddLogin");
		scroll(element("lnk_AddLogin"));
		clickUsingJavaScript("lnk_AddLogin");
		logMessage("Clicked on 'Add Login' link to provide User credentials for Canvas Learning System");
	}

	public void verifyAddLoginModalWindow() {
		isElementDisplayed("textbox_email");
		isElementDisplayed("textbox_password");
		isElementDisplayed("textbox_passwordConfirmation");
		logMessage("Add Login Modal window verified");
	}

	/**
	 * Method to add logins for users
	 * 
	 * @param name
	 * @param password
	 */

	public void enterLoginDetails(String name, String password) {
		fillText(element("textbox_email"), name);
		fillText(element("textbox_password"), password);
		fillText(element("textbox_passwordConfirmation"), password);
		logMessage("Admin has entered user login details");
	}

	public void clickOnAddLoginButton() {
		waitAndClick("btn_AddLogin");
		logMessage("Clicked on 'Add Login' button");
	}

	public void verifyUserLogin(String name) {
		isStringMatching(element("txt_userLoginId").getText(), name);
	}

	/**
	 * Remove this code
	 * 
	 * @param name
	 * @param password
	 */
	public void createLoginInfoForUser(String name, String password) {
		reloadPageUsingJs();
		clickLeftTabOnCoursePage("People");
		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page scrolled to maximum Y-cooridnate");
		waitForElementToBeVisible("txtbox_searchPeople");

		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page again scrolled to maximum Y-cooridnate");
		waitForElementToBeVisible("txt_userName", name);

		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page scrolled to maximum Y-cooridnate to find newly added user");

		executeJavascript("window.scrollBy(0,window.scrollMaxY)");
		logMessage("Page again scrolled to maximum Y-cooridnate to find newly added user");
		waitAndClick("txt_userName", name);

		scrollDown(element("lnk_moreDetails"));
		waitAndClick("lnk_moreDetails");
		logMessage("Clicked on 'More Details' link for newly created user");

		scrollDown(element("lnk_AddLogin"));
		waitAndClick("lnk_AddLogin");
		logMessage("Clicked on 'Add Login' link to provide User credentials for Canvas Learning System");

		fillText(element("textbox_email"), name);
		fillText(element("textbox_password"), password);
		fillText(element("textbox_passwordConfirmation"), password);

		waitAndClick("btn_AddLogin");
		logMessage("Clicked on 'Add Login' button");
		clickLeftTabOnCoursePage("People");
		logMessage("User provides the login information to the user");
	}

	// Inside Settings
	/**
	 * Method to click navigation tab inside settings
	 */
	public void clickNavigationTab() {
		waitForElementToBeVisible("lnk_navigationTab");
		waitAndClick("lnk_navigationTab");
		logMessage("Clicked on 'Navigation' link");
	}

	/**
	 * Method to enable Macmillan tools inside settings
	 * 
	 * @param macmillanTools
	 */
	public void enableMacmillanTools(String macmillanTools) {
		if (elements("lnk_hiddenMacmillanTool").size() > 0) {
			clickUsingJavaScript("lnk_settingIcon", macmillanTools);
			hardWait(3);
			executeJavascript(
					"document.getElementsByClassName('icon-plus enable_nav_item_link ui-corner-all')[0].click();");
			scrollToElementUsingJavaScript("btn_Save");
			hardWait(5);
			clickUsingJavaScript("btn_Save");
			waitForJqueryToFinish();
		} else {
			logMessage("Tools link already visible");
		}
	}

	/**
	 * Method to enter into given tool
	 * 
	 * @param tools
	 */
	public void enterIntoToolsSection(String tools) {
		hardWait(4);
		isElementDisplayed("left_tab_menu_Tools", tools);
		clickUsingJavaScript("left_tab_menu_Tools", tools);
		logMessage("User is navigated to Tools Page");
		hardWait(4);
	}

	public String getCourseCode() {

		String mycode = "";
		String currentUrl = getCurrentURL();
		System.out.println("The current Url is " + currentUrl);
//		String beforHome= StringUtils.substringBefore(currentUrl, "/Home#");
//		mycode=StringUtils.substringAfter(beforHome, "11e/");
		String parts[] = currentUrl.split("/");
		System.out.println("Course Code is " + parts[5]);
		return parts[5];
	}

	public void verifyAppropriateCourseLaunches() {
		waitAndClick("lnk_writersHelp");
		logMessage("User is navigated to Writer's Help");
		waitForLoaderToDisappear();
		hardWait(140);
		switchToDefaultContent();
		changeWindow(1);
		hardWait(100);
		waitForLoaderToDisappear();
		isElementDisplayed("txt_writersHelpTitle");
		closeWindow();
		changeWindow(0);
		switchToDefaultContent();
	}

	public void goToGradesPage() {
		waitAndClick("left_tab_menu_Grades");
		logMessage("User is navigated to Grades Page");
	}

	public void goToAssignmentsPage() {
		switchToDefaultContent();
		waitAndClick("left_tab_menu_Assignments");
		logMessage("User is naviagted to Assignments folder");
	}

	public void verifyGradesInCanvasGradebook(String userName) {
		/*
		 * List<String> students = null; for (int i = 1; i < 10; i++) { try {
		 * isElementDisplayed("lnk_allStudentsindex", Integer.toString(i));
		 * students.add(element("lnk_allStudentsindex", Integer.toString(i)).getText());
		 * Iterator<String> iter = students.listIterator();
		 * 
		 * for (int index = 0; index < students.size(); index++) { if
		 * (iter.next().equals(userName)) { if (element("txt_grades",
		 * Integer.toString(index)).getText().equals(10)) {
		 * logMessage("Grades have been updated successfully"); } else {
		 * logMessage("No grades found"); } } } } catch (NullPointerException e) {
		 * break; } catch (Exception e){ e.printStackTrace();
		 * 
		 * } }
		 */

		int count = getElementCount("lnk_studentNameList");
		for (int i = 1; i <= count; i++) {
			String strr = element("lnk_studentName", Integer.toString(i)).getText();
			if (strr.equals(userName)) {
				if (element("txt_grades", Integer.toString(i)).getText().equals(10)) {
					logMessage("Grades have been updated successfully");
				} else {
					logMessage("<span><b><font color=red>No grades found</font></b></span>");
				}
			}
		}

	}

	public void disableExternalTool(String macmillanTools) {

		if (getElementCount("link_externalToolEnabled") > 0) {
			// waitAndClick("lnk_settingIcon", macmillanTools);
			scroll(element("lnk_settingIcon", macmillanTools));
			// scrollToElementUsingJavaScript("lnk_settingIcon", macmillanTools);
			clickUsingJavaScript("lnk_settingIcon", macmillanTools);
			hardWait(3);
			hoverClick(element("link_disableItem"));
			waitForElementToBeVisible("btn_Save");
			clickUsingJavaScript("btn_Save");
			logMessage("Macmillan Tool is disabled");
		} else {
			logMessage("MacmillanTool is already removed");
		}
	}

	public void deleteAssignmentsIfPresent(String option) {
		if (!(verifyElementNotDisplayed("btn_assignmentName"))) {
			List<WebElement> list = elements("btn_assignmentName");
			System.out.println("Number of Assignments->" + list.size());
			while (list.size() > 0) {
				int i = 0;
				hardWait(4);
				hardWait(2);
				executeJavascript("document.getElementsByClassName('ig-title').item(" + i + ").click()");
				wait.hardWait(3);
				waitAndClick("link_edit_AssignmentSettings");
				hardWait(2);
				waitAndClick("btn_moreSettings");
				hardWait(2);
				hoverClick(element("link_menuItemOnSettings"));
				handleAlert();
				hardWait(2);
				refreshPage();
				logMessage("Assignment has been delete");
				hardWait(3);
				refreshPage();
				clickAssignmentsOnCoursePage();
				list = elements("btn_assignmentName");
			}
		}
	}

	public void verifyModulePresentAndSelectOptionFromSetting(String option) {
		List<WebElement> list = elements("btn_moduleSettingIcon");
		int i = 0;
		while (list.size() > 0) {
			list.get(0).click();
			wait.hardWait(3);
			waitAndScrollToElement("lnk_menuItem", option);
			hardWait(2);
			hoverClick(element("lnk_menuItem", option));
			handleAlert();
			hardWait(2);
			refreshPage();
			logMessage("Module has been delete");
			hardWait(3);
			list = elements("btn_moduleSettingIcon");
		}
	}

	public void createLoginForUserUoP(String userName, String password) {
		clickOnPeopleNavigationLink();
		clickOnUoPStudentUserName();
		// verifyUserDetailPage(userName);
		clickOnMoreUserDetails();
		verifyMembershipLoginInformationSection();
		clickOnAddLoginLink();
		verifyAddLoginModalWindow();
		enterLoginDetails(userName, password);
		clickOnAddLoginButton();
		verifyUserLogin(userName);
	}

	public void clickOnUoPStudentUserName() {
		waitScrollAndClick("lnk_studUsername");
	}

	public void verifyDeployedQuizName(String quizTitle1) {
		isElementDisplayed("text_quizName", quizTitle1);
		logMessage("Verified Deployed Quiz Name");
	}

	public void createModule(String moduleName) {
		assertTrue(element("btn_module").isDisplayed(), "button module is not displayed on");
		waitAndClick("btn_module");
		clickUsingJavaScript("btn_module");
		fillText("input_module", moduleName);
		waitAndClick("btn_addModule");
		logMessage("Created Module");
		hardWait(3);
	}

	public void deleteAssignmentOnProdEnvForWillo() {
		List<WebElement> settingsIconList = elements("btn_Settings");
//		int i =1;
		while (settingsIconList.size() > 0) {
			settingsIconList.get(0).click();
			waitForElementToBeVisible("optionDelete");
			waitAndClick("optionDelete");
			driver.switchTo().alert().accept();
			hardWait(3);
			settingsIconList = elements("btn_Settings");
		}

	}

	public void verifyMacmillanGradeRefreshPresentOnMacmillanHigherEducationToolsPage() {
		isElementDisplayed("link_macmillanGradeRefresh");
		logMessage("Macmillan Grade Refresh is displayed on Macmillan Higher Education Tools Page.");
	}

	public void verifyUserIsOnMacmillanHigherEducationGradeSyncRefreshPage() {
		isElementDisplayed("txt_PageTitle", "Macmillan Learning Grade Sync Refresh");
		logMessage("User is on 'Macmillan Learning Grade Sync Refresh' page.");
	}
//		waitForElementToBeVisible("assignment_Settings");
//		waitAndClick("assignment_Settings");
//		waitForElementToBeVisible("optionDelete");
//		waitAndClick("optionDelete");
//        

	public void deleteAssignments() {
		String tier = ConfigPropertyReader.getProperty("tier");
		if (tier.equalsIgnoreCase("prod")) {
			deleteAssignmentOnProdEnvForWillo();
		} else {
			deleteAssignmentsIfPresent("Delete");
		}
		refreshPage();
	}

}