package com.qait.canvas.keywords;

import static org.junit.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.qait.automation.getpageobjects.GetPage;

public class ContentTocPageActions extends GetPage {

	public ContentTocPageActions(WebDriver driver) {
		super(driver, "ContentTocPage");
	}

	public void userClosesCurrentPageAndNavigatesToBasePage() {
		closeWindow();
		changeWindow(0);
		switchToDefaultContent();
		logMessage("User closes current page and navigates to base page");
	}

	public void userClosesPXWindow() {
		closeWindow();
		changeWindow(1);
		switchToDefaultContent();
		logMessage("User closes current page and navigates to Content page");
	}

	public void verifyContentTocPageOpens() {
		isElementDisplayed("firstLevelCheckBox");
		isElementDisplayed("label_SelectedItems");
		isElementDisplayed("labelbox_ItemsCount");
		isElementDisplayed("lnk_ShowCart");
		isElementDisplayed("button_AddSelectedContent");
		isElementDisplayed("button_Reset");
		logMessage("User verifies that content toc page has opened");
	}

	public void selectFirstLevelContent() {
		scrollDown(element("firstLevelCheckBox"));
		waitAndClick("firstLevelCheckBox");
		logMessage("User selects first level checkbox ");
	}

	public void verifyCartFunctionalityWhenContentIsnotSelected() {
		waitAndClick("lnk_ShowCart");
		isElementDisplayed("text_NoContentSelected");
		isElementDisplayed("button_RemoveSelectedContent");
		isElementDisplayed("button_Done");
		isElementDisplayed("label_ShowingItemCount");
		isElementDisplayed("icon_Cross_Cart");

		waitAndClick("button_Done");
		logMessage("User verifies cart when no content is selected");
	}

	public void verifyCartFunctionalityWhenContentIsSelected() {
		waitAndClick("lnk_ShowCart");
		isElementDisplayed("checkbox_cartContent");
		isElementDisplayed("button_RemoveSelectedContent");
		isElementDisplayed("button_Done");
		isElementDisplayed("label_ShowingItemCount");
		isElementDisplayed("icon_Cross_Cart");
		waitAndClick("checkbox_cartContent");
		waitAndClick("button_RemoveSelectedContent");
		waitAndClick("button_Done");
		logMessage("User verifies cart when content is selected");
	}

	public void ExpandFirstContentOfToc() {
		hardWait(2);
		scrollDown(element("first_arrow_right_from_top"));
		waitAndClick("first_arrow_right_from_top");
		hardWait(1);
		isElementDisplayed("first_arrow_down_from_top");
		isElementDisplayed("firstcheckbox_secondlevelchapter");
		logMessage("Content is expanded");
	}

	public void clickOnChapterIntroduction() {
		scrollDown(element("link_ChapterIntroduction"));
		waitAndClick("link_ChapterIntroduction");
		isElementDisplayed("button_dismiss");
		logMessage("User clicks on the chapter");
	}

	public void DismissPopup() {
		isElementDisplayed("checkbox_dontShowMessage");
		isElementDisplayed("paragraph_message");
		isElementDisplayed("icon_Cross_Message");
		hardWait(2);
		waitAndClick("button_dismiss");
		logMessage("User dismisses popup");
	}

	public void UserNavigateToPxWindow() {
		handleAlert();
		changeWindow(1);
		handleAlert();
	}

	public void UserNavigateToPxSecondWindow() {
		hardWait(4);
		changeWindow(2);
		handleAlert();
	}

	public void selectThirdLevelContent(String contentName) {
		waitAndClick("firstcheckbox_thirdlevelchapter", contentName);
		logMessage("User selects third level checkbox");
	}

	public void clicksOnAddSelectedContent() {
		isElementDisplayed("button_AddSelectedContent");
		customAssert.customAssertEquals(
				element("button_AddSelectedContent").getAttribute("class").contains("not-enabled"), false,
				"button is disabled after selection of quiz");
		scrollToElementUsingJavaScript("button_AddSelectedContent");
		waitAndClick("button_AddSelectedContent");
		logMessage("User clicks Add Selected Button");
	}

	public void closeContentToc() {
		switchToDefaultContent();
		waitAndClick("icon_close");
		hardWait(2);
		logMessage("User closes the content toc window");
	}

	public void closeExternalToolWidget() {
		waitForElementToBeVisible("icon_closeExternalTool");
		element("icon_closeExternalTool").click();
	}

	public void selectThirdLevelQuizContent(String contentName) {
		hardWait(2);
		scrollDown(element("secondcheckbox_thirdlevelchapter", contentName));
		waitAndClick("secondcheckbox_thirdlevelchapter", contentName);
		logMessage("User selects third level quiz checkbox");
	}

	public void selectModuleAndDeploy(String modulename) {
		isElementDisplayed("dropdownbox_ChooseModule", modulename);
		selectProvidedTextFromDropDown(element("dropdownbox_ChooseModule"), modulename);
		scroll(element("btn_DeploySelectedContent"));
		waitAndClick("btn_DeploySelectedContent");
		hardWait(3);
		switchToDefaultContent();

		logMessage("User deploys the content through the tools window");
	}

	public void cancelCreateNewModule() {
		selectProvidedTextFromDropDown(element("dropdownbox_ChooseModule"), "Create New Module");
		waitForElementToBeVisible("cancel_createModule");
		hardWait(3);
		waitAndClick("cancel_createModule");
		logMessage("Cancelled the creation of Module");
	}

	public void createNewModule(String moduleName) {
		selectProvidedTextFromDropDown(element("dropdownbox_ChooseModule"), "Create New Module");
		fillText("inp_moduleTitle", moduleName);
		isElementDisplayed("btn_createNewModule");
		hardWait(2);
		waitAndClick("btn_createNewModule");
		waitForElementToBeVisible("btn_moduleOK");
		hardWait(3);
		clickUsingJavaScript("btn_moduleOK");
		logMessage("New Module: " + moduleName + " has been created.");
	}

	public void openChapterSubcontent(String subContent) {
		waitForElementToBeVisible("link_ChapterSummativeQuiz", subContent);
		element("link_ChapterSummativeQuiz", subContent).click();
	}

	public void clickOnInformationIconOfChapter(String contentName) {
		waitForElementToBeVisible("icon_informationOfChapterContent", contentName);
		element("icon_informationOfChapterContent", contentName).click();
	}

	public void verifyGradeAssignImportedStatus(String points, String contentName) {
		customAssert.customAssertTrue(
				(element("icon_informationOfChapterContent", contentName).getAttribute("class").contains("active")),
				"Information icon is not highlighted after deploying and assigning the content");
		customAssert.customAssertEquals(element("icon_AssignedPoints", contentName).getText(), points,
				"Assigned points doesn't match with the points appearing in information of chapter content");
		List<WebElement> infoList = elements("txt_InformationAssignedAndImported");
		customAssert.customAssertEquals(infoList.get(0).getText().trim(), "Imported",
				"After deploying content, it's info is not changed to Imported");
		customAssert.customAssertEquals(infoList.get(1).getText().trim(), "Assigned",
				"After assigning content, it's info is not changed to Assigned");
		logMessage("All the 3 information- Imported, Assigned and Points are verified");
	}

	public void ExpandToc(String chapterName) {
		waitForElementToBeVisible("arrow_expand_TOC", chapterName);
		element("arrow_expand_TOC", chapterName).click();
		logMessage("Content " + chapterName + " is expanded");
	}

	public void openChapterOfTOC(String chapterName) {
		element("link_chapterName", chapterName).click();
		logMessage("Chapter '" + element("link_chapterName", chapterName).getText() + "' is opened in PX window");
	}

	public void selectContentTOC(String contentName) {
		waitForElementToBeVisible("checkbox_contentTOC", contentName);
		hardWait(3);
		scrollDown(element("checkbox_contentTOC", contentName));
		element("checkbox_contentTOC", contentName).click();

	}

	public void selectContentTOCFORAchieve(String contentName) {

		waitForElementToBeVisible("checkbox_contentTOC", contentName);
		hardWait(3);
		scrollDown(element("checkbox_contentTOC", contentName));
		element("checkbox_contentTOC", contentName).click();
		
	}
	public void selectContentTOCFORAchieve1(String contentName) {
		waitForElementToBeVisible("checkbox_contentTOC", contentName);
		hardWait(3);
		scrollDown(element("checkbox_contentTOC", contentName));
		element("checkbox_contentTOC", contentName).click();
	}

	public void verifyAllAssignmentsTextIsNotClickable() {
		hardWait(2);
		waitForElementToBeVisible("txt_assignments");
		isElementDisplayed("txt_assignments");
		assertTrue(element("txt_assignments").getAttribute("class").contains("inactive"));
		logMessage("Verified that the text Select All Assignments is not clickable");
	}

	public void VerifyAllAssignmentsAreSelected() {
		hardWait(4);
		executeJavascript("document.getElementsByClassName('checkbox-third-level').item(0).click()");
		List<WebElement> list = elements("chkbox_assignments");
		for (int i = 1; i < list.size(); i++) {
			hardWait(2);
			System.out.println("Entering into For Loop");
			assertTrue(list.get(i).isSelected());
			logMessage("Verified that the assignments can be selected");
		}
	}

	public void verifyAllAssignmentsAreUnselected() {
		hardWait(4);
		executeJavascript("document.getElementsByClassName('checkbox-third-level').item(0).click()");
		List<WebElement> list = elements("chkbox_assignments");
		for (int i = 1; i < list.size(); i++) {
			hardWait(2);
			System.out.println("Entering into For Loop");
			assertFalse(list.get(i).isSelected());
			logMessage("Verified that the assignments can be unselected");
		}
	}

	public void verifyAssignmentsCheckboxDisabled() {
		hardWait(4);

		System.out.println(executeJavascriptAndReturnBooleanValue(
				"document.getElementsByClassName('item-third-level').item(1).getElementsByTagName('input').item(0).disabled"));
		assertTrue(executeJavascriptAndReturnBooleanValue(
				"document.getElementsByClassName('item-third-level').item(1).getElementsByTagName('input').item(0).disabled"));
		assertTrue(executeJavascriptAndReturnBooleanValue(
				"document.getElementsByClassName('item-third-level').item(2).getElementsByTagName('input').item(0).disabled"));
		assertTrue(executeJavascriptAndReturnBooleanValue(
				"document.getElementsByClassName('item-third-level').item(3).getElementsByTagName('input').item(0).disabled"));

	}

	public void verify_checkbox_Is_Disabled(String contentName) {
		waitForElementToBeVisible("checkbox_disabled", contentName);
		hardWait(3);
		scrollDown(element("checkbox_disabled", contentName));
	}

	public void verifySelectedItemCount() {
		hardWait(3);
		String count = (String) executeJavascript("return $('#toc-items-count')[0].textContent");
		customAssert.customAssertEquals(count, "1", "count is not increased after selection of quiz");
	}

	public void clickOnRefreshAndVerify() {
		waitAndClick("button_refresh");
		verifyPageTitleContains("Macmillan Learning TOC");
		logMessage("Clicked on refresh button and verified as well");
	}

	public void clickOnShowCart() {
		waitAndClick("lnk_ShowCart");
		logMessage("Clicked on show cart link");
	}

	public void verifyShowCartLinkPage() {
		isElementDisplayed("text_NoContentSelected");
		isElementDisplayed("button_RemoveSelectedContent");
		isElementDisplayed("button_Done");
		isElementDisplayed("label_ShowingItemCount");
		isElementDisplayed("icon_Cross_Cart");
		wait.hardWait(3);
		waitAndClick("icon_Cross_Cart");
	}

	public void verifyDoneButtonFunctionality() {
		waitForElementToBeClickable(element("button_Done"));
		waitAndClick("button_Done");
		verifyElementNotDisplayed("button_Done");
	}

	public void verifyResetFunctionality() {
		waitAndClick("button_Reset");
		isElementDisplayed("button_AddSelectedContent");
		customAssert.customAssertEquals(
				element("button_AddSelectedContent").getAttribute("class").contains("not-enabled"), true,
				"button is enabled");
	}

	public void verifyRemoveChapterFromShowLinkModalPopup(String quizName) {
		waitAndClick("lnk_ShowCart");
		waitForElementToBeClickable(element("checkBox_modalPopup", quizName));
		waitAndClick("checkBox_modalPopup", quizName);
		hardWait(4);
		waitAndClick("button_RemoveSelectedContent");
		verifyElementNotDisplayed("checkBox_modalPopup", quizName);
	}

	public void clickOnButton(String buttonName) {
		hardWait(3);
		waitAndClick("btn_overDeployPage", buttonName);
		logMessage("Clicked on Back button");
	}

	public void verifyBackButtonFunctionality() {
		verifyElementNotDisplayed("btn_overDeployPage", "Back");
		verifyElementNotDisplayed("btn_DeploySelectedContent");
		verifyElementNotDisplayed("btn_overDeployPage", "Cancel");
		logMessage("Verified Back button functionalty");
	}

	public void verifyCancelButtonFunctionalityOverCreateModuleModalPopup() {
		isElementDisplayed("btn_overDeployPage", "Back");
		isElementDisplayed("btn_DeploySelectedContent");
		isElementDisplayed("btn_overDeployPage", "Cancel");
		logMessage("Verified Cancel button functionalty over create module modal popup");
	}

	public void clickonDeploySelectedContent() {
		waitAndClick("btn_deploySelectedContent");
		logMessage("Clicked on Deploy Selected Content");
	}
}