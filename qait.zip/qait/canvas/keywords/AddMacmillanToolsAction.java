package com.qait.canvas.keywords;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.SeleniumWait;
import com.qait.automation.utils.YamlReader;

public class AddMacmillanToolsAction extends GetPage {
	WebDriver driver;
	SeleniumWait wait;

	public AddMacmillanToolsAction(WebDriver driver) {
		super(driver, "AddMacTools");
		this.driver = driver;
	}

	public void clickOnRightLink(String linkName) {
		Long length = (Long) executeJavascript("return $('a.button-sidebar-wide').length");
		for (int i = 0; i < length; i++) {
			String link = (String) executeJavascript("return $('a.button-sidebar-wide')[" + i + "].textContent");
			System.out.println(link);
			if (link.contains(linkName)) {
				executeJavascript("return $('a.button-sidebar-wide')[" + i + "].click()");
				break;
			}
		}
	}

	public void verifyStudentViewPageContent() {
		isElementDisplayed("link_leftMenu", "Home");
		isElementDisplayed("link_leftMenu", "Discussions");
		isElementDisplayed("link_leftMenu", "Grades");
		isElementDisplayed("link_leftMenu", "People");
		isElementDisplayed("link_leftMenu", "Syllabus");
		isElementDisplayed("link_leftMenu", "Conferences");
		isElementDisplayed("link_leftMenu", "Collaborations");
		customAssert.customAssertEquals(element("toastMessage").getText(), "You are currently logged into Student View",
				"toast message is not matched with web page content");
		isElementDisplayed("bottom_linkButton", "Reset Student");
		isElementDisplayed("bottom_linkButton", "Leave Student View");
		logMessage("Verified Student View Page Content");
	}

	public void clickBottomLinkButton(String linkName) {
		waitAndClick("bottom_linkButton", linkName);
		logMessage("Clicked at bottom link " + linkName);
	}

	public void verifyToastMessageAfterResetStudent() {
		isElementDisplayed("toastMessage_resetStudent");
		logMessage("Verified toast message after reset student");
	}

	public void verifyCourseDetailsPage() {
		customAssert.customAssertEquals(element("tab_courseDetails").getAttribute("class").contains("ui-tabs-active"),
				true, "tab is not active");
		logMessage("Verified course details is active");
	}

	public void clickOnRightLinkOfCourseDetails(String linkName) {
		Long length = (Long) executeJavascript("return $('a.Button--course-settings').length");
		for (int i = 0; i < length; i++) {
			String link = (String) executeJavascript("return $('a.Button--course-settings')[" + i + "].textContent");
			System.out.println(link);
			if (link.contains(linkName)) {
				executeJavascript("$('a.Button--course-settings')[" + i + "].click()");
				break;
			}
		}
	}

	public void verifyCourseStatisticsContent() {
		List<WebElement> tabList = elements("tab_courseDetailsLink");
		customAssert.customAssertEquals(tabList.get(0).getText(), "Totals", "Totals tab is not matched");
		customAssert.customAssertEquals(tabList.get(1).getText(), "Assignments", "Assignments tab is not matched");
		customAssert.customAssertEquals(tabList.get(2).getText(), "Students", "Students tab is not matched");
		customAssert.customAssertEquals(tabList.get(3).getText(), "File Storage", "File Storage tab is not matched");
		logMessage("Verified course statistics content with all tab");
	}

	public void clickOnCourseStatisticsTab(String tabName) {
		Long length = (Long) executeJavascript("return $('.ui-tabs-anchor').length");
		for (int i = 0; i < length; i++) {
			hardWait(2);
			String tabName1 = (String) executeJavascript("return $('.ui-tabs-anchor')[" + i + "].textContent");
			if (tabName1.equals(tabName)) {
				executeJavascript("$('.ui-tabs-anchor')[" + i + "].click()");
				break;
			}
		}
		logMessage("Clicked at given tab name " + tabName);
	}

	public void verifyAssignmentsTabOfCourseStatistics(String headerText) {
		isElementDisplayed("txt_AssignmentsTabHeader", headerText);
	}

	public void verifyCourseCalenderContentPage() {
		verifyPageTitleContains("Calendar");
		customAssert.customAssertEquals(elements("btn_today").get(0).getText(), "Today",
				"Today button not found on web page");
		customAssert.customAssertEquals(elements("btn_prev").get(0).isDisplayed(), true,
				"Prev button not found on web page");
		customAssert.customAssertEquals(elements("btn_next").get(0).isDisplayed(), true,
				"Next button not found on web page");
		isElementDisplayed("btn_name", "week");
		isElementDisplayed("btn_name", "month");
		isElementDisplayed("btn_name", "agenda");
		logMessage("Verified all the calendar contents");
	}

	public void clickNavMenuItem(String courseName) {
		waitAndClick("txt_navMenuList", courseName);
		logMessage("Clicked at given course " + courseName);
	}

	public void verifyDeleteTheCoursePage() {
		customAssert.customAssertEquals(element("txt_header").getText(), "Confirm Course Deletion",
				"Header not matched");
		isElementDisplayed("genericTxt", "Cancel");
		isElementDisplayed("genericTxt", "Delete Course");
		logMessage("Verified Delete The Course Page");
	}

	public void clickOnGivenText(String textName) {
		waitAndClick("genericTxt", textName);
		logMessage("Clicked at given text " + textName);
	}

	public void verifyCopyCoursePageContent() {
		customAssert.customAssertEquals(element("txt_header").getText(), "Copy Testing Purpose", "Header not matched");
		isElementDisplayed("labelAndInput", "Name");
		isElementDisplayed("labelAndInput", "Course Code");
		isElementDisplayed("labelAndDateBox", "Start Date");
		isElementDisplayed("labelAndDateBox", "End Date");
		isElementDisplayed("genericTxt", "Cancel");
		isElementDisplayed("genericTxt", "Create Course");
		logMessage("Verified Copy Course Page Content");
	}

	public void verifyImportCourseContentPageContent() {
		hardWait(5);
		customAssert.customAssertEquals(element("txt_header").getText(), "Import Content", "Header not matched");
		isElementDisplayed("drpDwn_ImportContent");
		logMessage("Verified Import Course Content Page");
	}

	public void verifyExportCourseContentPageContent() {
		customAssert.customAssertEquals(element("txt_header").getText(), "Content Exports", "Header not matched");
		isElementDisplayed("txt_subHeader");
		isElementDisplayed("labelAndRadioButton", "Course");
		isElementDisplayed("labelAndRadioButton", "Quiz");
		isElementDisplayed("genericTxt", "Create Export");
		logMessage("Verified Export Content Page");
	}

	public void verifyResetCourseContentPage() {
		customAssert.customAssertEquals(element("btn_cancelOverPopUp").getText().contains("Cancel"), true,
				"Header not matched");
		customAssert.customAssertEquals(element("btn_resetCourseContent").getText().contains("Reset Course Content"),
				true, "Header not matched");
		logMessage("Verified Reset Course Content Page");
	}

	public void clickOnCancelButtonOverPopUp() {
		waitAndClick("btn_cancelOverPopUp");
		logMessage("Clicked Cancel Button");
	}

	public void verifyValidateLinksinContentPage() {
		customAssert.customAssertEquals(element("txt_headerValidationLink").getText().contains("Course Link Validator"),
				true, "Header not matched");
		isElementDisplayed("btn_startValidationLink");
		logMessage("Verified Validate Links Content Page");
	}

	public void verifySectionTabContent() {
		customAssert.customAssertEquals(element("header_section").getText().contains("Course Sections"), true,
				"Header not matched");
		logMessage("Verified Section Tab Content");
	}

	public void verifyNavigationTabContent() {
		ArrayList<String> ele = new ArrayList<String>();
		for (int i = 1; i <= 16; i++) {
			ele.add(YamlReader.getData("sectionTab.sectionEle" + i));
		}
		List<WebElement> list = elements("list_navigation");
		for (int i = 0; i < list.size(); i++) {
			customAssert.customAssertEquals(list.get(i).getText().contains((String) ele.get(i)), true,
					"element not matched");
		}
		List<WebElement> iconMore = elements("settingIcon");
		iconMore.get(0).click();
		customAssert.customAssertEquals(element("iconMoreOption", "Disable", "1").isDisplayed(), true,
				"Disable option not found on the web page ");
		customAssert.customAssertEquals(element("iconMoreOption", "Move", "1").isDisplayed(), true,
				"Move option not found on the web page ");
		logMessage("Verified Navigation Tab Content");
	}

	public void verifyAppsTabContent() {
		customAssert.customAssertEquals(element("header_apps").getText().contains("External Apps"), true,
				"Apps Header not matched");
		isElementDisplayed("link_viewAppConf");
		List<WebElement> list = elements("link_AppInfo");
		customAssert.customAssertEquals(list.get(0).getText(), "All", "All link is not present");
		customAssert.customAssertEquals(list.get(1).getText(), "Not Installed", "Not Installed link is not present");
		customAssert.customAssertEquals(list.get(2).getText(), "Installed", "Installed link is not present");
		logMessage("Verified Apps Tab Content");
	}

	public void verifyFeatureOptionsTabContent() {
		List<WebElement> featureOptionList = elements("txt_featureOptions");
		customAssert.customAssertEquals(featureOptionList.get(0).getText(), "Learning Mastery Gradebook",
				"expected ink is not present");
		customAssert.customAssertEquals(featureOptionList.get(1).getText(), "Student Learning Mastery Gradebook",
				"expected ink is not present");
		customAssert.customAssertEquals(featureOptionList.get(2).getText(),
				"Gradebook - List Students by Sortable Name", "expected ink is not present");
		customAssert.customAssertEquals(featureOptionList.get(3).getText(), "Anonymous Grading",
				"expected ink is not present");
		customAssert.customAssertEquals(featureOptionList.get(4).getText(), "Quiz Log Auditing",
				"expected ink is not present");
		logMessage("Verified Feature Options Tab Content");
	}

	public void clickOnIconMoreOptions(String option) {
		List<WebElement> iconMore = elements("settingIcon");
		iconMore.get(0).click();
		hardWait(4);
		executeJavascript("$('.icon-updown.move_nav_item_link')[0].click()");
		logMessage("Clicked at Move icon " + option);
	}

	public void verifyMoveModalPopupContent() {
		customAssert.customAssertEquals(element("header_moveModalPopup").getText(), "Move Navigation Item",
				"Header not mathced with modal popup");
		List<WebElement> drpOption = elements("drpDwnOption");
		customAssert.customAssertEquals(drpOption.get(0).getText(), "At the Top", "At the Top drp option not matched");
		customAssert.customAssertEquals(drpOption.get(1).getText(), "Before..", "Before drp option not matched");
		customAssert.customAssertEquals(drpOption.get(2).getText(), "After..", "After drp option not matched");
		customAssert.customAssertEquals(drpOption.get(3).getText(), "At the Bottom",
				"At the Bottom drp option not matched");
		isElementDisplayed("btn_moveOverModalPopup");
		logMessage("Verified Move Modal Pop Up Content");
	}

	public void verifyCancelButtonFunctionalityOfMoveModalPopup() {

		executeJavascript("$('._922amOO._16-3B-L._3Gg19qR').click()");
		List<WebElement> drpOption = elements("drpDwnOption");
		hardWait(4);
		//customAssert.customAssertEquals(drpOption.size(), 0, "Cancel Button not working");  //see later
		logMessage("Verified Cancel Button Functionality Of Move Modal Popup");
	}

	public void verifyAfterOptionFunctionalityFromDropDown() {
		ArrayList<String> ele = new ArrayList<String>();
		for (int i = 1; i <= 16; i++) {
			ele.add(YamlReader.getData("sectionTab.sectionEle" + i));
		}
		List<WebElement> list = elements("list_navigation");
			customAssert.customAssertEquals(list.get(0).getText().contains((String) ele.get(0)), false,
					"element not matched");
	}

	public void selectDropDownOption(String optionValue) {
		List<WebElement> drpOption = elements("drpDwnOption");
		for(WebElement option:drpOption)
		{
			if(option.getText().contains(optionValue))
			{
				option.click();
				break;
			}
		}
	}
	public void clickMoveButtonOption()
	{
		waitAndClick("btn_moveOverModalPopup");
		logMessage("Clicked at Move button");
	}

	public void clickEnableButton(String toolName) {
		waitAndClick("btn_enableSetting",toolName);
		waitAndClick("lnk_enable",toolName);
		logMessage("Clicked at enable button for index "+toolName);
	}
	public void clickDisableButton(String toolName) {
		waitAndClick("btn_enableSetting",toolName);
		waitAndClick("lnk_disable",toolName);
		logMessage("Clicked at disable button from enabled tool "+toolName);
	}
	public int countOfEnabledMenu() {
		return elements("list_enabledMenu").size();
	}
	
	public void verifyEnableFunctionalityOFIconMoreSettingsButton(int beforeEnableSize) {
		int afterEnableSize=countOfEnabledMenu();
		customAssert.customAssertEquals(afterEnableSize-beforeEnableSize,1,"Not Moved to Enabled list");
	}

	public void clickOnResetContentButtonOverPopup() {
		hardWait(4);
		executeJavascript("$('.btn-danger.submit_button')[0].click()");		
	}
}