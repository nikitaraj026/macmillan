package com.qait.canvas.keywords;

import org.apache.commons.lang.RandomStringUtils;
import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class RequestFormActions extends GetPage {

	String fname = RandomStringUtils.randomAlphabetic(5);
	String lname = RandomStringUtils.randomAlphabetic(5);
	String mobile = RandomStringUtils.randomNumeric(10);
	String jobTitle = "JobNewTit" + RandomStringUtils.randomAlphabetic(5);

	public RequestFormActions(WebDriver driver) {
		super(driver, "RequestForm");
	}

	public void verifyUserOnFormPage() {
		isElementDisplayed("logo_macmillan");
		logMessage("Macmillan logo is displayed successfully");

		isElementDisplayed("request_Heading");
		logMessage("Request Heading is displayed Successfully");
	}

	public void fillBasicDetails(String emailAdd) {
		fillText("txt_field", "firstName", fname);
		fillText("txt_field", "lastName", lname);
		fillText("txt_field", "phoneNumber", mobile);
		fillText("txt_field", "emailAddress", emailAdd);
		fillText("txt_field", "jobTitle", jobTitle);
		logMessage("Filled all basic Details");
	}

	public void enterInstallationDetails(String instName, String instUrl) {
		fillText("txt_field", "institutionName", instName);
		fillText("txt_field", "institutionBaseURL", instUrl);
		logMessage("Filled Installation Details");
	}

	public void selectRadioButtons(String lmsType) {
		waitForElementToBeVisible("btn_tier", "Staging");
		click(element("btn_tier", "Staging"));
		waitForElementToBeVisible("btn_LMStype", lmsType);
		click(element("btn_LMStype", lmsType));
		waitForElementToBeVisible("chkbox_SingleSchool");
		click(element("chkbox_SingleSchool"));
		waitForElementToBeVisible("chkbox_City");
		click(element("chkbox_City"));

	}

	public void enterCitySelectStateAndCountry(String cityName) {
		fillText("txt_field", "city", cityName);
		scrollBy("600");
		selectByValueFromDropDown(element("select_dropdown", "stateSelect"), "NY");
		selectByValueFromDropDown(element("select_dropdown", "countrySelect"), "us");
	}

	public void searchFromInstitutions() {
		hardWait(5);
		click(element("searchInst"));
		waitForLoaderToDisappear();
		selectByValueFromDropDown(element("select_dropdown", "institutions"), "24005835");
//		selectTextFromDropDown("select_dropdown", "institutions", "Kedar Nath MIET");
		logMessage("Selected institution from dropdown");
	}

	public void clickOnCaptcha() {
//		waitAndClick("captchabtn");
		
		switchToFrame("frameCaptcha");
		executeJavascript("document.getElementById('recaptcha-anchor').click()");

	}

}
