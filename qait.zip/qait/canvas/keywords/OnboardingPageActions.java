package com.qait.canvas.keywords;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;


public class OnboardingPageActions extends GetPage {
	public OnboardingPageActions(WebDriver driver) {
		super(driver, "OnboardingPage");
	}
	
	/**
	 * General Methods
	 */
	public void verifyUrlSecured() {
		String url = getCurrentURL();
		customAssert.customAssertTrue(url.startsWith("https"), "[Assertion Failed] : Request Instructor Access Page URL is not secured");
		logMessage("[Assertion Passed] : Request Instructor Page Url is secured");
	}
	
	/**
	 * Header
	 */
	public void logout() {
		clickElementIfVisible("btn_closeToastMessage");	
		hoverUserNameMenu();
		//element("link_usernameMenu").click();
		clickUserMenuItem("Sign Out");
		waitForElementToBeVisible("link_helpMenu");
		hardWait(2);
		waitForLoaderToDisappear();
//		try{
//			hoverUserNameMenu();
//			clickUserMenuItem("Sign Out");
//		}catch (Exception e) {
//			System.out.println("User already signed out");
//		}
	}
	
	public void hoverUserNameMenu() {
		hardWait(2);
		//hover(element("link_usernameMenu"));
		executeJavascript("document.getElementsByClassName('hidden-menu profileMenu')[0].style.display='block';");
	}
	
	public void clickUserMenuItem(String itemName) {
		waitForElementToBeVisible("link_usernameMenuItem", itemName);
		hardWait(2);
		element("link_usernameMenuItem", itemName).click();
		logMessage("Clicked User Name Menu Item '" + itemName + "'");
	}
	
	/**
	 * Request Instructor Access Page
	 */
	public void verifyTitle(String expectedTitle) {		
		isElementDisplayed("txt_title");
		verifyTextOfElementIsCorrect("txt_title", expectedTitle);
		verifyUrlSecured();
	}
	
	public void verifyErrorMessageOnRequestInstructorAccessPage(String errorNum, String email) {
		if (errorNum.equals("1"))
			verifyTextOfElementIsCorrect("txt_errorMessage", "No Macmillan account exists for " + email + ". Click [Next] to register, or try a different email address.");
		else if (errorNum.equals("2"))
			verifyTextOfElementIsCorrect("txt_errorMessage", "A Macmillan account already exists with that address. Please enter your password to continue.");
	}
	
	public void verifyWantToSignUpRadioBtnChecked() {
		customAssert.customAssertEquals(element("radiobtn_wantToSignUp").getAttribute("checked"), "true", 
				"[Assertion Failed] : I want to Sign Up Radio Button is not checked");
	}
	
	public void submitMacmillanRepresentative(String username, String password, String email) {
		element("radiobtn_representative").click();
		fillText("txtinput_macmillanUserName", username);
		fillText("txtinput_passwordRepresentative", password);
		customAssert.customAssertEquals(element("txtinput_emailRepresentative").getAttribute("value").trim(), 
				email, "[Assertion Failed] : Email is not filled correctly");
		clickNext();
	}
	
	public void clickNext() {
		element("btn_next").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}
	
	/**
	 * Instructor Registration Page
	 */
	public void fillInstructorFirstAndLastName(String fName, String lName) {
		waitAndScrollToElement("txtinput_firstName");
		fillText("txtinput_firstName", fName);
		waitAndScrollToElement("txtinput_lastName");
		fillText("txtinput_lastName", lName);
	}
	
	public void fillInstructorPasswordAndConfirmPassword(String password) {
		fillText("txtinput_password", password);
		fillText("txtinput_confirmPassword", password);
	}
	
	public void verifyInstructorEmailCorrect(String email) {
		verifyTextOfElementIsCorrect("txt_emailLabel", email);
	}
	
	public void findYourSchoolByZipCode(String zipCode, String searchRange, String schoolType) {
		scrollToTop();
		element("radiobtn_zipCode").click();
		hardWait(1);
		fillText("txtinput_zipCode", zipCode);
		selectTextFromDropDown("dropdown_searchRange", searchRange);
		selectTextFromDropDown("dropdown_schoolType", schoolType);
		clickSearchBtn();
	}
	
	public void clickSearchBtn() {
		element("btn_search").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}
	
	public void selectSchoolDepartmentAndPosition(String school, String department, String position) {
		element("option_school", school).click();
		hardWait(2);
		waitForLoaderToDisappear();
		element("option_department", department).click();
		selectTextFromDropDown("select_position", position);
	}
	
	public void acceptCompanyPrivacyPolicy() {
		element("checkbox_accept").click();
	}
	
	public void clickSubmit() {
		element("btn_submit").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}
	
	/**
	 * Instructor Access Granted Page
	 */
	public void verifyInstructorAccessGrantedTitle(String expectedTitle) {
		isElementDisplayed("txt_instructorAccessGrantedIitle");
		verifyTextOfElementIsCorrect("txt_instructorAccessGrantedIitle", expectedTitle);
	}
	
	public void clickProceedToWebsiteBtn() {
		element("btn_proceedToTheWebsite").click();	
	}
	
	/**
	 * Privacy Notice Page
	 */
	public void verifyEulaContentDisplayed() {
		isElementDisplayed("iframe_terms");
		switchToFrame(element("iframe_terms"));
		isElementDisplayed("txt_titlePrivacyNotice");
		isElementDisplayed("txt_titleTermsOfUse");
		switchToDefaultContent();
	}
	
	public void agreeLegalTerms() {
		scroll(element("checkbox_readLegalTerms"));
		element("checkbox_readLegalTerms").click();
		element("btn_agree").click();
		waitForLoaderToDisappear();
	}
	
	public void fillFirstNameLastNameAndPassword(String fName, String lName, String password) {
		fillText("input_FirstName", fName);
		fillText("input_LastName", lName);
		fillText("input_Password", password);
	}
	
	public void fillConfirmEmailAndPassword(String email, String password) {
		fillText("input_ConfirmEmail", email);
		fillText("input_ConfirmPassword", password);
	}
	
	public void clickRegister() {
		element("btn_register").click();
		hardWait(1);
		waitForLoaderToDisappear();
	}
	
	public void newMWStudent(String email) {
		hardWait(2);
		if(getPageTitle().contains("Email Verification"))
		{
			fillText("input_Email", email);
			element("btn_emailSubmit").click();
		}
		
		logMessage("Student email:  " + email + " entered on Email Check page");
	}

	public void studentAttemptFlowUptoQuestion(String value,String answer) {
		hardWait(4);
//		isElementDisplayed("btn_submit",value);
//		waitAndClick("btn_submit", value);
		executeJavascript("document.querySelector('.singlebutton input[value=\"Yes\"]').click()");
		waitAndClick("bnt_freeTrial");
		waitAndClick("btn_continueEnroll");
//		sendKeys(element("input_InstitutionName"), "Sapling Learn");
//		wait.hardWait(3);
		element("input_InstitutionName").click();
		sendKeys(element("input_InstitutionName"), "Sapling Learn");
		element("input_InstitutionName").click();
		hardWait(2);
		element("input_InstitutionName").sendKeys("i");
		hardWait(3);
		element("input_InstitutionName").click();
		waitAndClick("dropdown_textSaplingLearning");
		waitAndClick("btn_OK");
		hardWait(6);
		waitAndClick("link_question");
		switchToFrame("iframe_question");
		List<WebElement> list=elements("list_question");
		for(int i=0;i<list.size();i++)
		{
			wait.hardWait(4);
			String labelValue=(String) executeJavascript("return document.querySelectorAll('label.sl-list-label')["+i+"].textContent");
			if(labelValue.equals(answer))
			{
				wait.hardWait(4);
				list.get(i).click();
				break;
			}
		}
		waitAndClick("btn_checkAnswer");
		closeWindow();
		changeWindow(0);
		logMessage("Clicked on "+value+" button");
	}
}
