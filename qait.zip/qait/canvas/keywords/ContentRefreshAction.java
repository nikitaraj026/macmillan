package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;
import com.qait.automation.getpageobjects.GetPage;

public class ContentRefreshAction extends GetPage{

	public ContentRefreshAction(WebDriver driver) {
		super(driver, "ContentRefreshPage");
	}

//	public void verifyContentRefreshPage(){
//		isElementDisplayed("btn_refreshContentLink");
//		isElementDisplayed("txt_contentRefreshed");
//		logMessage("User is on Macmillan Content Refresh Page");
//	}
//	
//	public void verifyPointsOfContent(String contentName, String expectedPoints){
//		waitForElementToBeVisible("txt_pointsOfContentTOC", contentName);
//		String actualPoints = element("txt_pointsOfContentTOC", contentName).getText();
//		customAssert.customAssertEquals(actualPoints, expectedPoints, "Points of the content TOC is not refreshed after changing it on PX side");
//	}
}
