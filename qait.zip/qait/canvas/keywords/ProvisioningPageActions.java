package com.qait.canvas.keywords;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import com.qait.automation.getpageobjects.GetPage;

public class ProvisioningPageActions extends GetPage {

	public ProvisioningPageActions(WebDriver driver) {
		super(driver, "ProvisioningPage");
	}

	public void associateFirstCourseFromTheList() {
		waitAndClick("btn_Associate");
		isElementDisplayed("btn_confirmCourseAssociation");
		hardWait(3);
		waitAndClick("btn_confirmCourseAssociation");
		hardWait(4);
		waitForElementToDisappear("img_pleaseWait");
		isElementDisplayed("btn_Ok");

		waitAndClick("btn_Ok");
		changeWindow(0);
		logMessage("Course got associcated successfully");
	}

	public void disAssociateCourse() {
		isElementDisplayed("btn_Yes_DisassociateThisCourse");
		waitAndClick("btn_Yes_DisassociateThisCourse");
		logMessage("User ends the Course Association");
	}

	public void clickCreateNewCourseButton(String bookTitle) {
		waitForLoaderToDisappear();
		waitAndScrollToElement("btn_createNewCourse", bookTitle);
		waitAndClick("btn_createNewCourse", bookTitle);
		logMessage("Clicked Create New Course button.");
	}

	public void createNewCourse(String bookTitle, String courseTitle, String courseNumber, String sectionNumber,
			String instructorName, String academicTerm, Boolean isTimeZonePresent, String timeZone, String school) {
		clickCreateNewCourseButton(bookTitle);
		waitForLoaderToDisappear();
		waitAndScrollToElement("inp_courseTitle", courseTitle);
		fillText("inp_courseTitle", courseTitle);
		hardWait(5);
		logMessage("Filled Course Title: " + courseTitle);
		waitAndScrollToElement("inp_CourseNumber");
		fillText("inp_CourseNumber", courseNumber);
		logMessage("Filled Course Number: " + courseNumber);
		waitAndScrollToElement("inp_SectionNumber");
		fillText("inp_SectionNumber", sectionNumber);
		logMessage("Filled Section Number: " + sectionNumber);
		waitAndScrollToElement("inp_InstructorNames");
		fillText("inp_InstructorNames", instructorName);
		logMessage("Filled Instructor Name: " + instructorName);
		List<WebElement> dropdownSchool = elements("drodDown_school");
 		if (dropdownSchool.size()==1) {
			waitForElementToBeClickable(element("drodDown_school"));
			selectTextFromDropDown("drodDown_school", school);
		}
		scroll(element("dropDown_academicTerm", academicTerm));
		hardWait(5);
		selectTextFromDropDown("dropDown_academicTerm", academicTerm);
		hardWait(5);
		logMessage("Selected Academic Term: " + academicTerm);
		scrollToElementUsingJavaScript("btn_confirmCourseCreation");
		hardWait(3);
		waitAndClick("btn_confirmCourseCreation");
		logMessage("Clicked 'Create New Course'");
	}

	public void createNewCourseSYSIN3947(String bookTitle, String courseTitle, String courseNumber,
			String sectionNumber, String instructorName, String academicTerm, Boolean isTimeZonePresent,
			String timeZone, String school, String envrionment) {
		clickCreateNewCourseButton(bookTitle);
		waitForLoaderToDisappear();
		waitAndScrollToElement("inp_courseTitle");
		System.out.println("courseTitle:" + courseTitle);
		fillText("inp_courseTitle", courseTitle);
		logMessage("Filled Course Title: " + courseTitle);
		waitAndScrollToElement("inp_CourseNumber");
		fillText("inp_CourseNumber", courseNumber);
		logMessage("Filled Course Number: " + courseNumber);
		waitAndScrollToElement("inp_SectionNumber");
		fillText("inp_SectionNumber", sectionNumber);
		logMessage("Filled Section Number: " + sectionNumber);
		waitAndScrollToElement("inp_InstructorNames");
		fillText("inp_InstructorNames", instructorName);
		logMessage("Filled Instructor Name: " + instructorName);
		logMessage("Environement: " + envrionment);
		if (envrionment.equalsIgnoreCase("dev")) {
			waitAndScrollToElement("drodDown_school");
			selectTextFromDropDown("drodDown_school", school);
			logMessage("Selected school " + school + " from the School dropdown");
		}
		// scroll(element("dropDown_academicTerm"));
//		scrollBy("-200");

		selectTextFromDropDown("dropDown_academicTerm", academicTerm);
		hardWait(4);
		logMessage("Selected Academic Term: " + academicTerm);
		if (isTimeZonePresent) {
			waitAndScrollToElement("dropDown_timeZone");
			selectTextFromDropDown("dropDown_timeZone", timeZone);
			logMessage("Selected timezone: " + timeZone);
		}
		waitAndScrollToElement("btn_confirmCourseCreation");
		waitAndClick("btn_confirmCourseCreation");
		logMessage("Clicked 'Create New Course'");
	}

	public void verifyCourseCreated(String courseName) {
		
		waitForLoaderToDisappear();
		waitAndScrollToElement("txt_newlyCreatedCourse", courseName);
		isElementDisplayed("txt_newlyCreatedCourse", courseName);
		logMessage(courseName + " has been verified.");
	}

	public String associateCourse(String CourseName) {
		hardWait(4);
		waitScrollAndClick("btn_associateWithCourseName", CourseName);
		waitAndScrollToElement("txt_associateCourseModalTitle");
		isElementDisplayed("txt_associateCourseModalTitle");
		waitAndScrollToElement("button_yesAssociateCourseModal");
		waitAndClick("button_yesAssociateCourseModal");
		waitForLoaderToDisappear();
		String courseId = element("txt_courseIDSuccessModal").getText();
		hardWait(3);
		clickUsingJavaScript("btn_Ok");
		changeWindow(0);
		switchToDefaultContent();
		return courseId;
	}

	public void createNewCourse(String linkName, String nameOfCourse, String school, String academicTerm) {
		String courseName = generateUniqueCourseName(nameOfCourse);
		scrollDown(element("btn_createNewCourse", linkName));
		waitForElementToBeVisible("btn_createNewCourse", linkName);
		element("btn_createNewCourse", linkName).click();

		isElementDisplayed("label_createCopyCourseModalTitle");
		isElementDisplayed("label_pxCourseFormTitle");
		isElementDisplayed("label_pxCourseFormAuthor");
		isElementDisplayed("label_CourseTitle");
		isElementDisplayed("inp_courseTitle");
		isElementDisplayed("label_CourseNumber");
		isElementDisplayed("inp_CourseNumber");
		isElementDisplayed("label_SectionNumber");
		isElementDisplayed("inp_SectionNumber");
		isElementDisplayed("label_InstructorName");
		isElementDisplayed("inp_InstructorNames");
		isElementDisplayed("label_AcademicTerm");
		isElementDisplayed("sel_academicTerm");
		isElementDisplayed("label_TimeZone");
		isElementDisplayed("dropdown_TimeZone");
		isElementDisplayed("label_Requiredfield");
		isElementDisplayed("btn_confirmCourseCreation");
		isElementDisplayed("btn_CancelCourseCreation");
		scrollDown(element("inp_courseTitle", courseName));
		fillText(element("inp_courseTitle"), courseName);
		selectProvidedTextFromDropDown(element("sel_academicTerm"), academicTerm);
		waitAndClick("btn_confirmCourseCreation");

		waitForElementToBeVisible("txt_newlyCreatedCourse", courseName);
		customAssert.customAssertTrue(element("txt_newlyCreatedCourse", courseName).isDisplayed(),
				"Newly created course did not appear in the course list on provisioning page");
		Reporter.log("New course was successfully created and verified it's presence on the course list", true);
	}

	public void copyCourse(String copyLinkName, String newName, String academicTerm) {
		/*
		 * NOTE: LMS 1.16 has been deployed on QA/STG where 'Copy Course' has been
		 * removed from Provisioning Page i.e., SYSIN-3161
		 * https://macmillanhighered.atlassian.net/browse/SYSIN-3161
		 * 
		 * waitForElementToBeVisible("lnk_CopyCourse", copyLinkName);
		 * element("lnk_CopyCourse", copyLinkName).click();
		 * isElementDisplayed("label_CopyCourse");
		 */

		isElementDisplayed("label_pxCourseFormCopyNote");
		isElementDisplayed("label_pxCourseFormTitle");
		isElementDisplayed("label_pxCourseFormAuthor");
		isElementDisplayed("label_CourseTitle");
		isElementDisplayed("inp_courseTitle");
		isElementDisplayed("label_CourseNumber");
		isElementDisplayed("inp_CourseNumber");
		isElementDisplayed("label_SectionNumber");
		isElementDisplayed("inp_SectionNumber");
		isElementDisplayed("label_InstructorName");
		isElementDisplayed("inp_InstructorNames");
		isElementDisplayed("label_AcademicTerm");
		isElementDisplayed("sel_academicTerm");
		isElementDisplayed("label_TimeZone");
		isElementDisplayed("dropdown_TimeZone");
		isElementDisplayed("label_Requiredfield");
		isElementDisplayed("btn_copyCourse_on_Modal");
		isElementDisplayed("btn_CancelCourseCreation");
		isElementDisplayed("icon_Cross_Draggable_Window");

		/*
		 * NOTE: Below functionality has been removed since LMS 1.16 has been deployed
		 * 
		 * String newCourseName = generateUniqueCourseName(newName); String
		 * existingCourseName = element("inp_courseTitle").getAttribute("value");
		 * customAssert.customAssertTrue(existingCourseName != null,
		 * "Existing name of the course did not appear in the corresponding text field"
		 * );
		 * 
		 * scrollDown(element("inp_courseTitle", newCourseName));
		 * fillText(element("inp_courseTitle"), newCourseName);
		 * 
		 * selectProvidedTextFromDropDown(element("sel_academicTerm"), academicTerm);
		 * waitAndClick("btn_copyCourse_on_Modal");
		 * 
		 * waitForElementToBeVisible("txt_newlyCreatedCourse", newCourseName);
		 * customAssert.customAssertTrue( element("txt_newlyCreatedCourse",
		 * newCourseName).isDisplayed(),
		 * "Copied Course did not appear in the coruse list");
		 * 
		 * Reporter.log(
		 * "An existing course was successfully copied and verified the derived course's presence on the course list"
		 * , true);
		 */
	}

	public String generateUniqueCourseName(String name) {
		return getUniqueName(name);
	}

	public void verifyProvisionPageOpens() {
		isElementDisplayed("logo_macmillan");
		isElementDisplayed("btn_refresh");
//		isElementDisplayed("btn_ViewLaunchPadCourse");
		isElementDisplayed("btn_createNewCourse");
		isElementDisplayed("lnk_ViewMacmillanCatalog");
		isElementDisplayed("inp_courseKey");
		isElementDisplayed("btn_courseKey_Associate");
		logMessage("User is navigated to Provision Page successfully");
	}

	public void verifyProvisionPageOpensForSapling() {
		isElementDisplayed("logo_macmillan");
		isElementDisplayed("btn_refresh");
		isElementDisplayed("lnk_ViewMacmillanCatalog");
		isElementDisplayed("inp_courseKey");
		isElementDisplayed("btn_courseKey_Associate");
		logMessage("User is navigated to Provision Page successfully");
	}

	public void verifyProvisionPageLinksandElements() {
		isElementDisplayed("inp_courseKey");
		isElementDisplayed("btn_courseKey_Associate");
		isElementDisplayed("first_button_Create_New_Course");
		isElementDisplayed("first_lnk_CopyCourse");
		isElementDisplayed("btn_viewPortalAndClass");
		isElementDisplayed("btn_ViewLaunchPadCourse");
		isElementDisplayed("lnk_ViewMacmillanCatalog");
		isElementDisplayed("course_box");
		isElementDisplayed("course_Key_Box");
		isElementDisplayed("logo_Header");
		logMessage("User is navigated to Provision Page successfully");
	}

	public void verifyNoCourseMessage() {
		isElementDisplayed("label_NoCourse");
		logMessage("User verifies the message that no courses on record for him");
	}

	public void verifyInstructorHasNotSetupCourseMessage() {
		isElementDisplayed("txt_instructorHasNotSetupCourseMessageBox");
		logMessage(
				"User verifies the message that Sorry, your instructor has not set up your course integration. Please try again after your instructor has set up your course integration.");
	}

	public void userClosesCurrentPageAndNavigatesToBasePage() {
		closeWindow();
		changeWindow(0);
		switchToDefaultContent();
	}

	public void associateCourseWithKey(String courseKey) {
		fillText(element("inp_courseKey"), courseKey);
		waitAndClick("btn_courseKey_Associate");
		waitAndClick("btn_confirmCourseAssociation");
		waitAndClick("btn_Ok");
	}

	public void verifyViewPortalAndClasses() {
		scroll(element("btn_viewPortalAndClass"));
		waitAndClick("btn_viewPortalAndClass");
		isElementDisplayed("heading_Browse_Our_Disciplines_ViewPortalAndClass");
		isElementDisplayed("dropdownbox_BrowseDiscipline_ViewPortalAndClass");
		isElementDisplayed("btn_BrowseTitlesForThisDisciPline_ViewPortalAndClass");
		isElementDisplayed("btn_Cancel_ViewPortalAndClass");
		isElementDisplayed("icon_cross_ViewPortalAndClasses");
		hardWait(2);
		waitAndClick("icon_cross_ViewPortalAndClasses");
		logMessage("User verifies View Portal and Courses");
	}

	public void verifyViewLaunchpadCourses() {
		scrollDown(element("btn_ViewLaunchPadCourse"));
		waitAndClick("btn_ViewLaunchPadCourse");
		isElementDisplayed("heading_Browse_Our_Disciplines_ViewLaunchpadCourse");
		isElementDisplayed("dropdownbox_BrowseDiscipline_ViewLaunchpadCourse");
		isElementDisplayed("btn_BrowseTitlesForThisDisciPline_ViewLaunchpadCourse");
		isElementDisplayed("btn_Cancel_ViewLaunchpadCourse");
		isElementDisplayed("icon_cross_ViewLaunchpadCourse");
		waitAndClick("icon_cross_ViewLaunchpadCourse");
		logMessage("User verifies View launchpad Course");
	}

	public void verifyMacmillanCatalogue() {
		scrollDown(element("lnk_ViewMacmillanCatalog"));
		waitAndClick("lnk_ViewMacmillanCatalog");
		switchToDefaultContent();
		changeWindow(2);
		verifyPageTitleContains("College & High School Publisher | Macmillan Learning");
		// isElementDisplayed("logo_CataloguePage");
//		changeWindow(0);
//		switchToFrame(element("frame_resourceSelection"));
//		isElementDisplayed("lnk_ViewMacmillanCatalog");
//		switchToDefaultContent();
//		logMessage("User verifies View Macmillan Catalog");
	}

	public void verifyRefreshButtonAndItsFunctionality() {
		isElementDisplayed("btn_refresh");
		waitAndClick("btn_refresh");
		isElementDisplayed("course_box");
		logMessage("User clicks on refresh button and verify Refresh functionality");
	}

	public void verifyCourseKey(String CourseKey) {
		hardWait(3);
		waitForElementToBeVisible("inp_courseKey");
		fillText(element("inp_courseKey"), "abcd");
		waitAndClick("btn_courseKey_Associate");
		isElementDisplayed("message_Course_Key_invalid");
		waitForElementToBeVisible("icon_Cross_InvalidCOurseKeyRelay");
		hardWait(2);
		waitAndClick("icon_Cross_InvalidCOurseKeyRelay");
		logMessage("User verifies message on passing invalid course key");

//		enterText(element("inp_courseKey"), CourseKey);
//		waitAndClick("btn_courseKey_Associate");
//		isElementDisplayed("message_Course_key_valid");
//		waitAndClick("lnk_crossIcon");
//		logMessage("User verifies message on passing valid course key");
	}

	public void closeContentTOCFrame() {
		switchToDefaultContent();
		waitForElementToBeVisible("icon_close");
		scrollDown(element("icon_close"));
		waitAndClick("icon_close");
		logMessage("User closes the provision page window");
	}

	public void closeProvisonPageForNonAssociatedUser() {
		switchToDefaultContent();
		waitAndClick("icon_close_provison");
		logMessage("User closes the provision page Frame");
	}

	public void closeProvisionPageFrame() {
		switchToDefaultContent();
		waitAndClick("icon_close_provison_window");
		logMessage("User closes the provision page Frame");
	}

	public void submit_SSOPageAndContinue() {
		isElementDisplayed("btn_submit");
		scroll(element("btn_submit"));
		waitAndClick("btn_submit");
		logMessage("User clicked on 'Submit' button");
		hardWait(2);
		waitForElementToBeVisible("btn_continueProvisioning");
		isElementDisplayed("btn_continueProvisioning");
		element("btn_continueProvisioning").click();
		logMessage("User clicked on 'Continue' button");
	}

	public void authenticateToken() {
		isElementDisplayed("btn_authenticate");
		scroll(element("btn_authenticate"));
		waitAndClick("btn_authenticate");
		logMessage("User clicked on 'Authenticate' button");
//		waitAndClick("lnk_userName","Inst Load");
//		changeWindow(2);
//		verifyPageTitleContains("User Settings: Inst Load");
//		closeWindow();
//		isElementDisplayed("btn_cancel");
		isElementDisplayed("btn_loginTokenRegistration");
		element("btn_loginTokenRegistration").click();
		logMessage("User clicked on 'Authorize' button");

		waitForElementToBeVisible("btn_continueTokenRegistration");
		isElementDisplayed("btn_continueTokenRegistration");
		element("btn_continueTokenRegistration").click();
		logMessage("User clicked on 'Continue' button");
	}

	public void verifyTokenRegistrationPage() {
		isStringMatching(element("txt_canvasTokenRegistration").getText(),
				"Macmillan Learning LMSLink Canvas Token Registration");
		// isStringMatching(element("txt_authenticateCanvas").getText(), "Authenticate
		// with your Canvas installation");
		isElementDisplayed("txt_fieldSetBox");
		isElementDisplayed("btn_authenticate");
		List<WebElement> footer = elements("txt_footer");
		customAssert.customAssertEquals(footer.get(0).getText(), "Privacy Policy", "Privacy Policy text not matched");
		customAssert.customAssertEquals(footer.get(1).getText(), "Terms of Use", "Terms of Use text not matched");
		customAssert.customAssertEquals(footer.get(2).getText(), "Accessibility", "Accessibility text not matched");
		customAssert.customAssertEquals(footer.get(3).getText(), "Refund Policy", "Refund Policy text not matched");
		customAssert.customAssertEquals(footer.get(4).getText(), "Customer Service/Support",
				"Customer Service/Support text not matched");
		logMessage("User is on Macmillan Learning LMSLink Canvas Token Registration page");
	}

	public void verifySSOPageForAchieve() {
		isElementDisplayed("btn_submit");
		List<WebElement> footer = elements("txt_footer");
		customAssert.customAssertEquals(footer.get(0).getText(), "Privacy Policy", "Privacy Policy text not matched");
		customAssert.customAssertEquals(footer.get(1).getText(), "Terms of Use", "Terms of Use text not matched");
		customAssert.customAssertEquals(footer.get(2).getText(), "Accessibility", "Accessibility text not matched");
		customAssert.customAssertEquals(footer.get(3).getText(), "Refund Policy", "Refund Policy text not matched");
		customAssert.customAssertEquals(footer.get(4).getText(), "Customer Service/Support",
				"Customer Service/Support text not matched");
		logMessage("User is on Macmillan Learning LMSLink Canvas Token Registration page");
	}

	public void newMWUserEmailCheck(String email, String password) {
		String pageTitle = getPageTitle();
		if ((pageTitle).equals("EmailCheck")) {
			fillText("input_Email", email);
			element("btn_GO").click();
			waitForPageToLoadCompletely("Found E-Mail Address");
			fillText("input_pxPassword", password);
			element("btn_passwordGo").click();

		} else if ((pageTitle).equals("Found E-Mail Address")) {
			fillText("input_pxPassword", password);
			element("btn_passwordGo").click();
		}
	}

	public void fillNewInstructorDetails(String fName, String lName, String emailId) {
		
		fillText(elements("input_instDetails").get(0), fName);
		fillText(elements("input_instDetails").get(1), lName);
		fillText(elements("input_instDetails").get(2), emailId);
	}
	
	public void fillNewInstructorDetailsForAchieve(String fName, String lName, String emailId) {
		fillText(element("inpt_firstName"), fName);
		fillText(element("inpt_lastName"), lName);
		fillText(element("inpt_eMail"), emailId);
	}
	public void fillNewInstructorDetailsForSapling(String fName, String lName, String emailId) {
		fillText(element("inpt_firstName"), fName);
		fillText(element("inpt_lastName"), lName);
		fillText(element("inpt_eMail"), emailId);
	}
	public void fillNewStudentDetails(String fName,String lName,String emailId) {
		
		fillText(element("inpt_firstName"),fName);
		fillText(element("inpt_lastName"),lName);
		fillText(element("inpt_eMail"),emailId);
		
	}

	public void clickOnFooterLink(String footerName) {
		List<WebElement> footer = elements("txt_footer");
		for (WebElement footerLink : footer) {
			System.out.println("link: " + footerLink.getText());
			if (footerLink.getText().equals(footerName)) {
				footerLink.click();
				break;
			}
		}
	}

	public void verifyPrivacyPolicyPage() {
		verifyPageTitleContains("Privacy Notice | Macmillan Learning Student Store");
	}

	public void verifyTermsOfUsePage() {
		verifyPageTitleContains("Terms of Use | Macmillan Learning Student Store");
	}

	public void verifyAccessibilityPage() {
		verifyPageTitleContains("Bedford, Freeman, & Worth Accessibility and Usability Statement");
	}

	public void clickOnViewLaunchPadCourses() {
		waitAndClick("btn_ViewLaunchPadCourse");
	}

	public void ClickCancelButton() {
		waitAndClick("btn_Cancel_ViewLaunchpadCourse");
	}

	public void verifyMacmillanElearningPage() {
		selectTextFromDropDown("dropdownbox_BrowseDiscipline_ViewLaunchpadCourse", "Biochemistry");
		waitAndClick("btn_BrowseTitlesForThisDisciPline_ViewLaunchpadCourse");
		changeWindow(2);
		verifyPageTitleContains("Macmillan Learning :: eLearning");
		isElementDisplayed("logo_CataloguePage");
	}

	public void clickOnRefreshButton() {
		waitAndClick("btn_refresh");
	}

	public void clickOnSignInBtn() {
		waitAndClick("btn_signIn");
	}

	public void clickOnContinueProvisioning() {
		waitAndClick("btn_continueProvisioning");
	}

	public void clickOnAuthenticate() {
		waitAndClick("btn_authenticate");
	}

}
