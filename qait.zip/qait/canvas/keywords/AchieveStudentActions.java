package com.qait.canvas.keywords;

import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.google.gdata.data.dublincore.Date;
import com.qait.automation.getpageobjects.GetPage;

public class AchieveStudentActions extends GetPage {

	public AchieveStudentActions(WebDriver driver) {
		super(driver, "AchieveStudentAction");
	}

	public String attempt_AchieveQuiz() {
		String points = "";
//		wait.waitForPageToLoadCompletely();
		waitForLoaderToDisappear();
		hardWait(6);
		switchToFrame("iframeAchieveQuiz");
		waitForElementToBeVisible("btn_beginQuiz");
		isElementDisplayed("btn_beginQuiz");
		waitAndClick("btn_beginQuiz");
		wait.waitForPageToLoadCompletely();
		List<WebElement> list = elements("underline_words");
		for (int i = 0; i < list.size(); i++) {
//			list = elements("underline_words");
			String grades = (String) executeJavascriptAndReturnValue(
					"(document.getElementsByClassName('Activity__value__3HwBy').item(0).textContent.split(\"/\"))[0];");
			hardWait(10);
			list.get(i).click();
			wait.hardWait(5);
			List<WebElement> wrongAnswer = elements("btnCloseWrongModalWindow");
			if (wrongAnswer.size() == 1) {
				waitForElementToBeVisible("btnCloseWrongModalWindow");
				element("btnCloseWrongModalWindow").click();
				logMessage("Closed Wrong Answer Modal Window");
			}
			if (i == 3) {
				waitAndClick("btn_nextQues");
				i = -1;
				list = elements("underline_words");
			}
			if (element("status_answer").getText() == "Correct" && grades != "0"
					|| element("status_answer").getText().contains("pts") && grades != "0") {
				System.out.println("The text displayed is -------------->" + element("status_answer").getText());
				break;
			}
		}
		
		waitForElementToBeVisible("back_toStudy");
		isElementDisplayed("back_toStudy");
		waitAndClick("back_toStudy");
		wait.waitForPageToLoadCompletely();
		waitForElementToBeVisible("points_fromAchieve");
		points = element("points_fromAchieve").getText();
		points = StringUtils.substringBefore(points, "pts").trim();
		System.out.println("Points from Achieve is -------------->" + points);
		closeWindowAndSwitchBackToOriginalWindow(0);
		return points;
	}
    public void attemptSecondQuizAch() {
    	switchToDefaultContent();
		switchToDefaulFrame();
		hardWait(3);
		scroll(element("lnk_achieve"));
		element("lnk_achieve").click();
		changeWindow(1);
		switchToDefaultContent();
		logMessage("Clicked on Achieve on ToolsPage.");
    	hardWait(3);
		waitAndClick("btn_MyCourseTab", "COURSE PLAN");
		waitAndClick("link_quiz1");
		closeWindowAndSwitchBackToOriginalWindow(0);
    }
    public void switchToDefaulFrame() {
		waitForElementToBeVisible("iframe_ToolContent");
		switchToFrame("iframe_ToolContent");
	}
	public void verifyEnrollmentOptionsModalWindow() {
		wait.waitForPageToLoadCompletely();
		waitForElementToBeVisible("modal_EnrollOptions");
		isElementDisplayed("modal_EnrollOptions");
		logMessage("Modal window for Enrollment options is displaying successfully");
		//waitForElementToBeVisible("btn_gracePeriod");
		//isElementDisplayed("btn_gracePeriod");
		isElementDisplayed("btn_PurchaseAccess");
		isElementDisplayed("inpt_AccessCode");
		logMessage("Also verified all three enrollment options on the modal window");
	}

	public void useGracePeriodAsEnrollmentOption(String courseHeading) {
		waitAndClick("btn_gracePeriod");
		waitForElementToBeVisible("chkbox_agree");
		waitAndClick("chkbox_agree");
		waitAndClick("btn_finishEnroll");
		waitForLoaderToDisappear();
		// Needs to take locator from instructor action
		waitForElementToBeVisible("heading_courseName", courseHeading);
		isElementDisplayed("heading_courseName", courseHeading);
		logMessage("Successfully navigated to Achieve Course Page");
		waitAndClick("btn_MyCourseTab", "COURSE PLAN");
		waitAndClick("link_quiz");
		attempt_AchieveQuiz();
		attemptSecondQuizAch();

	}

	public void useAccessCodedAsEnrollmentOption(String accCode,String courseName) {
		waitForElementToBeVisible("inpt_AccessCode");
		fillText("inpt_AccessCode", accCode);
		waitAndClick("btn_Enter");
		waitAndClick("btn_finishEnroll");
		waitForLoaderToDisappear();
		// Needs to take locator from instructor action
		waitForElementToBeVisible("heading_courseName", courseName);
		isElementDisplayed("heading_courseName", courseName);
		logMessage("Successfully navigated to Achieve Course Page");
		waitAndClick("btn_MyCourseTab", "COURSE PLAN");
		waitAndClick("link_quiz");
		attempt_AchieveQuiz();

	}

}