package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;
import com.qait.automation.getpageobjects.GetPage;

public class DiscussPageAction extends GetPage {

	public DiscussPageAction(WebDriver driver) {
		super(driver, "DiscussionsPage");
	}

	public void verifyDiscussionPageOpens() {
		isElementDisplayed("button_Discussion");
		logMessage("Discussion Page Opens");
	}
	
	public void clickOnAddDiscussionButton(){
		waitAndClick("button_Discussion");
		waitForElementToBeVisible("icon_MoreExternalTools");
		isElementDisplayed("icon_MoreExternalTools");
		logMessage("User clicks on Add Discussion Button");
	}

	public void clickOnIconMoreExternalTools(){
		waitAndClick("icon_MoreExternalTools");
		hardWait(5);
		switchToFrame(element("frame_ExternalTool"));
		logMessage("User clicks on Macmillan Flag for Launching content");
	}
	
	public void clickOnLinkTextMHE(){
		waitAndClick("linkTextMHE");
		isElementDisplayed("heading_MHEContentToc");
		switchToFrame(element("frame_ExternalTool"));
		logMessage("User clicks on linkText MHE and content TOC Window opens");
	}
	
	public void closeContentToc(){
		switchToDefaultContent();
		waitAndScrollToElement("icon_close");
		waitAndClick("icon_close");
		handleAlert();
		logMessage("User closes the content toc window");
	}
	
	public void clickHere(){
		waitAndClick("lnk_Here");
		changeWindow(1);
		logMessage("User clicks on the Here link and new window opens");
	}	
}