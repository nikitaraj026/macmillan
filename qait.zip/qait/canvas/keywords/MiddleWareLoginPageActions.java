package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class MiddleWareLoginPageActions extends GetPage {

	public MiddleWareLoginPageActions(WebDriver driver) {
		super(driver, "MiddlewareLoginPage");
	}

	public void verifyUserIsOnMWLoginPage(){
		isElementDisplayed("lbl_mwAdminLogin");
		isElementDisplayed("input_username");
		isElementDisplayed("input_password");

		logMessage("User is on 'Middleware Admin Login' page");
	}

	public void userClicksOnSubmitButtonToLoginIntoMW(){
		waitAndClick("btn_submit");
		logMessage("User has clicked on 'Submit' button on 'Middleware Admin Login' page");
	}

	public void enterAdminLoginDetailsOnLoginPage(String userName, String password){
		fillText("input_username", userName);
		fillText("input_password", password);
	}

	public void verifyMWDashboardPage(){
		verifyPageTitleContains("QA MW Admin Dashboard");
		isElementDisplayed("btn_dashboard");
		isElementDisplayed("btn_adminTools");
		isElementDisplayed("btn_config");
		isElementDisplayed("btn_logoff");

		logMessage("Admin is on Middleware Dashboard page");
	}

	public void clickOnAdminToolsButton(){
		waitAndClick("btn_adminTools");
		logMessage("Admin has clicked on 'Admin tools' button on Dashboard page");
	}

	public void verifyAdminToolsHomepage(){
		isElementDisplayed("lbl_installtionPage");
		isElementDisplayed("lbl_databaseTable");

		logMessage("Admin is on Installation listing page in Middleware");
	}

	public void selectDatabaseTable(String tableName){
		selectTextFromDropDown("drpdwn_databaseTable", tableName);

		logMessage("Admin has selected " + tableName + "from the dropdown");
	}

	public void verifyUserMappingListingPage(){
		isElementDisplayed("lbl_userMappingListing");
		isElementDisplayed("input_lmsUserID");
		isElementDisplayed("input_raUserID");
		isElementDisplayed("input_lmsInstallationID");

		logMessage("Admin is on 'User Mapping listing' page");
	}

	public void searchUserMappingTableByRAUserID(String raUserID){
		fillText("input_raUserID", raUserID);
		element("btn_go").click();

		logMessage("Admin has searched for user mapping record using RA User ID: " + raUserID);
	}

	public void verifySearchResultsAreDisplayed(String raUserID){
		isElementDisplayed("txt_raUserID", raUserID);
		logMessage("Verify that search results are displayed on 'User Mapping Listing' page");
	}

	public void verifyUserMappingSetupPage(){
		isElementDisplayed("lbl_userMappingSetup");
		isElementDisplayed("btn_submit");
		isElementDisplayed("btn_delete");
		logMessage("Admin is on 'User Mapping Setup' Page");
	}

	public void clickOnDeleteButtonOnUserMappingSetupPage(){
		element("btn_delete").click();
		handleAlert();
		verifyUserMappingListingPage();
	}

	public void deleteUserMapping(String raUserID){
		fillText("input_raUserID", raUserID);
		element("btn_go").click();
		if(getElementCount("txt_raUserID", raUserID)!=0){
			waitAndScrollToElement("lnk_editDelete");
			waitAndClick("lnk_editDelete");
			verifyUserMappingSetupPage();
			clickOnDeleteButtonOnUserMappingSetupPage();
		}
		logMessage("Admin has clicked on 'Edit/Delete' button");
	}

	public void closeMiddlewareWindow(){
		closeWindow();
		logMessage("Admin has successfully closed Middleware window");
	}
}