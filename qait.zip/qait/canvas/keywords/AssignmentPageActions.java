package com.qait.canvas.keywords;

import org.openqa.selenium.WebDriver;

import com.qait.automation.getpageobjects.GetPage;

public class AssignmentPageActions extends GetPage{
	public AssignmentPageActions(WebDriver driver, WebDriver driverToUploadImage){
		super(driver, driverToUploadImage, "AssignmentPage");
	}

	public void clickOnAddNewAssignmentLink() {
		waitForLoaderToDisappear();
		waitScrollAndClick("btn_createAssignment");
		logMessage("Clicked on Create Assignment button");
		waitForElementToBeVisible("input_title");
	}

	public void embedImage(String imageUrl) {
		waitForElementToBeVisible("btn_insertImage");
		hardWait(2);
		waitAndClick("btn_insertImage");
		logMessage("Clicked on Insert image button");
		switchToFrame(element("frame_preview"));
		fillText("input_imageUrl", imageUrl);
		waitAndClick("txtInp_description");
		fillText("txtInp_description", "test");
		_verifyImageInPreview(imageUrl);
		waitAndClick("btn_insert");
		logMessage("clicked on insert image");
		switchToDefaultContent();
		_verifyImageInMceEditor();
	}
	
	private void _verifyImageInPreview(String imageUrl) {
		isElementDisplayed("image_in_preview");
		element("image_in_preview").getAttribute("src").contains(imageUrl);
		logMessage("Image diaplayed in preview window");
	}
	
	private void _verifyImageInMceEditor() {
		switchToFrame(element("frame_mce"));
		isElementDisplayed("img_in_MCE");
		logMessage("Image dispaled in MC editor");
		switchToDefaultContent();
	}

	public String provideTitle() {
		element("input_title").clear();
		String assignmentName = "Assignment"+System.currentTimeMillis();
		element("input_title").sendKeys(assignmentName);		
		logMessage(assignmentName+" filled in assignment title");
		waitForElementToBeVisible("btn_save");
		waitAndClick("btn_save");
		return assignmentName;
	}

	public void expandAssignment(String assignmentName) {
		waitForLoaderToDisappear();
		waitForLoaderToDisappear();
	
		waitScrollAndClick("link_assignment",assignmentName);
		waitForLoaderToDisappear();
		hardWait(2);
		waitForLoaderToDisappear();
		
		waitForElementToBeVisible("btn_addToUnit",assignmentName);
		isElementDisplayed("btn_addToUnit",assignmentName);
		logMessage("Assignment Unit expanded");		
	}
	
}
