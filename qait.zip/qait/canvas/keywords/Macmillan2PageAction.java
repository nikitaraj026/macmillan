package com.qait.canvas.keywords;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertFalse;

import java.util.List;

import org.apache.poi.util.SystemOutLogger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import org.testng.asserts.SoftAssert;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.CustomAssert;

public class Macmillan2PageAction extends GetPage {
	SoftAssert softassertion ;
	public Macmillan2PageAction(WebDriver driver) {
		super(driver, "Macmillan2Page");
		this.driver = driver;
	 softassertion = new SoftAssert();
	
	}

	/**
	 * 
	 * Verify the title of Page
	 */
	public void verfiyMacmillan2PageTitle() {
		customAssert.customAssertEquals(getPageTitle(), "Courses: Macmillan2",
				"[Assertion Failed]: Page title does not match");
		logMessage("[Assertion Passed]: Page title matches");
	}

	// Left Tab
	/**
	 * Method to click left tabs
	 * 
	 * @param leftTab
	 */
	public void clickLeftTab(String leftTab) {
		clickUsingJavaScript("link_leftSubmenu", leftTab);
		logMessage("Clicked on leftTab: " + leftTab);
	}

	/**
	 * Method to click 'Courses' on left tab
	 */
	public void clickCoursesOnLeftTab() {
		clickLeftTab("Courses");
	}

	/**
	 * Method to click 'Users' on left tab
	 */
	public void clickUsersOnLeftTab() {
		clickLeftTab("People");
		logMessage("Clicked on People link on left tab");
	}

	/**
	 * Method to click 'Sub-Accounts' on left tab
	 */
	public void clickSubAccountsOnLeftTab() {
		clickLeftTab("Sub-Accounts");
	}

	/**
	 * User click on 'Add New Course' button
	 */
	public void clickOnAddNewCourse() {
		wait.hardWait(2);
		waitAndClick("btn_AddNewCourse");
		logMessage("Clicked on '+ New Course'");
	}

	public void clickSubAccount() {
		waitForElementToBeVisible("link_SubAccount");
		waitAndClick("link_SubAccount");
		logMessage("Clicked on SubAccounts Option");
	}
	
	public void verifyAddNewCourseModalWindow() {
		hardWait(4);
        softassertion.assertTrue(isElementDisplayed("textbox_CourseName"));
		softassertion.assertTrue(isElementDisplayed("textbox_refCode"));
		softassertion.assertTrue(isElementDisplayed("dropdownSubaccount"));
		// isElementDisplayed("btn_addUserNCancel","1", "Cancel");
		// isElementDisplayed("btn_addUserNCancel","1", "Add Course");
		softassertion.assertAll();
		logMessage("Add a New Course Modal window verified");
	}

	public void delete_Course(String courseName) {
		fillText("textbox_CourseName", courseName);
		fillText("textbox_refCode", "201");
		hardWait(2);
		executeJavascript(
				"document.getElementsByClassName('_16dxlnN _2A82x0p _3-BAZTP _1-Y3qxx _3v81sUu _3PmbyiE').item(1).click()");
		hardWait(4);
		fillText("txtinput_findACourse", courseName);
		hardWait(5);
		waitForElementToBeVisible("lnk_course", courseName);
		hardWait(3);
		executeJavascript(
				"document.getElementsByTagName('td').item(6).getElementsByTagName('span').item(4).getElementsByTagName('a').item(0).click()");
		hardWait(5);
		waitForElementToBeVisible("delete_course");
		waitAndClick("delete_course");
		hardWait(4);
		waitForElementToBeVisible("btn_confirmDelete");
		waitAndClick("btn_confirmDelete");
	}

	// Courses Tab
	/**
	 * Method to add new course inside Courses tab
	 * 
	 * @param courseName
	 */
	public void AddNewCourse(String courseName, String subAccount) {

		fillText(element("textbox_CourseName"), courseName);
		fillText(element("textbox_refCode"), courseName);
		hardWait(4);
		isElementDisplayed("dropdownSubaccount");
		selectTextFromDropDown("dropdownSubaccount", subAccount);
		waitAndClick("btn_addCourse");
		logMessage("Clicked on 'Add Course' button");
		// String flashMessage= element("txt_flashMessage").getText();
		// logMessage(flashMessage);
		// refreshPage();
		logMessage("Admin has created a new Course");
		logMessage("Name of the created course is " + courseName);
		hardWait(5);
	}

	public void AddNewCourse2(String courseName, String subAccount) {

		fillText(element("textbox_CourseName"), courseName);
		fillText(element("textbox_refCode"), courseName);
		hardWait(4);
		isElementDisplayed("dropdownSubaccount");
		List<WebElement> list = elements("drpDwn_SubAccountOption");
		System.out.println("Size is" + list.size());
		int i = 0;
		element("dropdownSubaccount").click();
		for (i = 0; i < list.size(); i++) {
			System.out.println("Entering into loop");
			if (list.get(i).getText().trim().equals(subAccount)) {
				hardWait(2);
				System.out.println(list.get(i).getText());
				list.get(i).click();
				break;
			}
		}
		hardWait(4);
		clickUsingJavaScript("btn_addCourse");
		logMessage("Clicked on 'Add Course' button");
		// String flashMessage= element("txt_flashMessage").getText();
		// logMessage(flashMessage);
		// refreshPage();
		logMessage("Admin has created a new Course");
		logMessage("Name of the created course is " + courseName);
		hardWait(5);
	}

	/**
	 * Admin click on Add new user button
	 */
	public void clickOnAddNewUser() {
		hardWait(5);
		scroll(element("btn_addNewUser"));
		click(element("btn_addNewUser"));
		logMessage("Clicked on 'Add A New User' button");
	}

	public void verifyAddNewUserModalWindow() {
		wait.hardWait(3);
		waitForElementToBeVisible("textbox_username");
		isElementDisplayed("textbox_username");
		isElementDisplayed("textbox_displayName");
		isElementDisplayed("textbox_sortableName");
		isElementDisplayed("textbox_email");
		isElementDisplayed("textbox_ssid");
		// isElementDisplayed("checkbox_sendConfirmation");
		// isElementDisplayed("btn_addUserNCancel", "2", "Cancel");
		// isElementDisplayed("btn_addUserNCancel", "2", "Add User");
		logMessage("Add a New User Modal window verified");
	}

	/**
	 * Method to create new users inside Courses tab
	 * 
	 * @param user
	 * @param email
	 */
	public void createUser(String user, String email) {
		waitForElementToBeVisible("textbox_username", user);
		fillText(element("textbox_username"), user);
		fillText(element("textbox_email"), email);
		waitForElementToBeVisible("btn_addUser", "Add User");
		waitAndClick("btn_addUser", "Add User");
		hardWait(10);
		logMessage("User created -> " + user);
		hardWait(4);
	}

	/**
	 * Method to enter into a course
	 * 
	 * @param courseName
	 */
	public void enterIntoCourse(String courseName) {
		waitForElementToBeVisible("txtinput_findACourse");
		hardWait(10);
		fillText("txtinput_findACourse", courseName);
//		waitAndClick("txtinput_findACourse");
		hardWait(5);
		waitForElementToBeVisible("lnk_course", courseName);
		waitAndClick("lnk_course", courseName);
		logMessage("User enters into '" + courseName + "' course");
	}
    
	public void enterIntoCourseName(String courseName) {
		waitForElementToBeVisible("txtinput_findACourse");
		hardWait(10);
		fillText("txtinput_findACourse", courseName);
		waitAndClick("txtinput_findACourse");
//		edit_CourseDetails();
		hardWait(5);
		waitForElementToBeVisible("lnk_course", courseName);
		waitAndClick("lnk_course", courseName);
		logMessage("User enters into '" + courseName + "' course");
	}

	public void edit_CourseDetails() {
		hardWait(4);
		waitForElementToBeVisible("course_settings");
		waitAndClick("course_settings");
		hardWait(3);
		waitForElementToBeVisible("tab_courseDetails");
		hardWait(3);
		assertEquals(executeJavascriptAndReturnValue(
				"document.getElementsByClassName(\"course_form\").item(0).getAttribute('type')"), "text");

		assertEquals(
				executeJavascriptAndReturnValue("document.getElementById('course_course_code').getAttribute('type')"),
				"text");

		assertEquals(
				executeJavascriptAndReturnValue("document.getElementById('course_sis_source_id').getAttribute('type')"),
				"text");
//		String disabled = executeJavascriptAndReturnValue(
//				"document.getElementsByClassName('btn btn-primary').item(0).disabled");
//		Boolean isDisabled = Boolean.parseBoolean(disabled);
//		assertFalse(isDisabled,"The button UpdateCourseDetails is Disabled");
		hardWait(4);
		navigateBack();

	}

	/**
	 * Method to find a user
	 * 
	 * @param userName
	 */
	public void clickonPeople() {
		isElementDisplayed("btn_people");
		waitAndClick("btn_people");
	}

	public void findAUser(String userName) {
		fillText("input_findAUser", userName);
		waitAndClick("btn_goForUser");
		// inside users tab, selecting top result
		waitAndClick("link_firstUserBySearch");
	}

	/**
	 * Method to verify user is on profile page
	 */
	public void verifyUserIsOnprofilePage() {
		isElementDisplayed("txt_breadcrumb");
		logMessage("User is on profile page.");
	}

	/**
	 * Method to unenroll given user from given course
	 * 
	 * @param userName
	 * @param courseName
	 */
	public void unenrollUserFromCourse(String userName, String courseName) {
		findAUser(userName);
		verifyUserIsOnprofilePage();
		waitAndClick("link_unenrollGivenUserFromCourse", courseName);
		handleAlert();
		logMessage(userName + " is unerolled from " + courseName + ".");
	}

	/**
	 * Method to unenroll user from all course
	 * 
	 * @param userName
	 * @param courseName
	 */
	public void unenrollUserFromAllCourses(String userName) {
		findAUser(userName);
		verifyUserIsOnprofilePage();
		int enrolledCourseCount = getElementCount("link_unenrollUserFromAllCourse");
		for (int i = 1; i <= enrolledCourseCount; i++) {
			waitAndClick("link_unenrollUserFromFirstCourse");
			handleAlert();
			hardWait(4);
		}
		logMessage(userName + " is unenrolled from all course.");
	}

	// User Tab

	/**
	 * Method to click first user
	 */
	public void clickOnFirstUser() {
		isElementDisplayed("lnk_firstUser");
		element("lnk_firstUser").click();
		logMessage("User clicked first user.");
	}

	/**
	 * Method to delete user
	 */
	public void deleteUser() {
		waitForElementToBeVisible("lnk_delete");
		element("lnk_delete").click();
		waitForElementToBeVisible("lnk_deleteIntegration");
		element("lnk_deleteIntegration").click();
		logMessage("User deleted..");
	}

	/**
	 * Method to delete all users
	 */
	public void deleteAllUsers() {
		// int count_1 = elements("lnk_allusers").size();
		// int count_2 =
		// Integer.valueOf(element("lnk_userpagecount").getText());
		// int limit = count_1 * count_2;

		// System.out.println("Total Number of Pages: " + limit);
		while (getElementCount("lnk_firstUser") != 0) {
			try {
				clickOnFirstUser();
				refreshPage();
				refreshPage();
				refreshPage();
				refreshPage();
				// refreshIfErrorOccured();
				// while(!verifyElementNotDisplayed("lnk_errorMessage", ""))
				// {
				// waitForElementToBeVisible("lnk_errorMessage");
				// element("lnk_errorMessage").click();
				// waitForLoaderToDisappear();
				// }
				deleteUser();
			} catch (Exception e) {
				logMessage("All Users Deleted.");
				break;
			}
		}
	}

	// Inside Sub-Accounts

	public void clickSubAccount(String subAccount) {
		waitAndClick("lnk_subAccount", subAccount);
	}

	public void goToEnvSubAccount(String env) {
		logMessage("Environment: " + env);

		isElementDisplayed("lnk_DevSubAccount");
		if (env.contains("Dev")) {
			clickSubAccount("Dev");
		} else if (env.contains("Pristine")) {
			clickSubAccount("Pristine");
		} else if (env.contains("QA/STG")) {
			clickSubAccount("QA");
		} else if (env.contains("Smoke Test")) {
			clickSubAccount("Smoke Test");
		}
		isElementDisplayed("btn_AddNewCourse");
		logMessage("User is navigated to Sub Account Page");
	}

	public void verifyActiveTab(String tabName) {
		isElementDisplayed("link_leftMenu", tabName);
		customAssert.customAssertEquals(element("link_leftMenu", tabName).getAttribute("class").contains("active"),
				true, "[Assertion Failed]: Tab is Not Active");
		logMessage("[Assertion PAssed]: " + tabName + " is currently active");
	}

	public void verifyUserIsOnMacmillan2Page() {
		isElementDisplayed("btn_toggleMenu");
		isElementDisplayed("link_leftMenu", "Courses");
		isElementDisplayed("link_leftMenu", "People");
		isElementDisplayed("link_leftMenu", "Statistics");
		isElementDisplayed("link_leftMenu", "Permissions");
		isElementDisplayed("link_leftMenu", "Outcomes");
		isElementDisplayed("link_leftMenu", "Rubrics");
		isElementDisplayed("link_leftMenu", "Grading");
		isElementDisplayed("link_leftMenu", "Question Banks");
		isElementDisplayed("link_leftMenu", "Sub-Accounts");
		isElementDisplayed("link_leftMenu", "Terms");
		isElementDisplayed("link_leftMenu", "Authentication");
		isElementDisplayed("link_leftMenu", "SIS Import");
		isElementDisplayed("link_leftMenu", "Themes");
		isElementDisplayed("link_leftMenu", "Developer Keys");
		isElementDisplayed("link_leftMenu", "Admin Tools");
		isElementDisplayed("link_leftMenu", "Settings");
		isElementDisplayed("txtinput_findACourse");
		// isElementDisplayed("input_findAUser");
		// isElementDisplayed("btn_addNewUser");
		isElementDisplayed("btn_addNewCourse");
		/*
		 * customAssert.customAssertEquals(elements("lst_coursesInThisAccount") .size()
		 * > 0, true, "[Assertion Failed]: Courses are not dispalyed");
		 * logMessage("[Assertion Passed]: Courses are displayed");
		 */
		logMessage("User is on Macmillan2 Page");
	}

	public void verifyEnrollmentlessCoursesAreAvailable() {
		customAssert.customAssertEquals(elements("lnk_enrollmentLessCourses").size() > 0, true,
				"[Assertion Failed]: Enrollmentless courses are not available");
		logMessage("[Assertion Passed]: Enrollmentless courses are available");
	}

	public void verifyLeftMenuHidden() {
		isElementDisplayed("btn_toggleMenu");
		element("btn_toggleMenu").click();
		logMessage("User clicked on Toggle button");
		customAssert.customAssertEquals(element("block_leftMenuVisibility").getAttribute("style").contains("none"),
				true, "[Assertion Passed]: Left Menu is Hidden");
	}

	public void verifyLeftMenuVisible() {
		isElementDisplayed("btn_toggleMenu");
		element("btn_toggleMenu").click();
		logMessage("User clicked on Toggle button");
		customAssert.customAssertEquals(element("block_leftMenuVisibility").getAttribute("style").contains("block"),
				true, "[Assertion Passed]: Left Menu is Visible");
	}

	public void verifyCourseListIsAutoPopulated() {

		element("txtinput_findACourse").sendKeys("Cole");
		waitForElementToBeVisible("lst_findCourseAutoComplete_New");
		// isElementDisplayed("lst_findCourseAutoComplete_New");
		logMessage("Auto Complete list is available");
	}

	public void findACourse(String courseName) {
		element("txtinput_findACourse").click();
		element("txtinput_findACourse").clear();
		element("txtinput_findACourse").sendKeys(courseName);
		logMessage("Entered " + courseName + " in Find a course text field");
		element("courselink").click();
		logMessage("Clicked on Go Button for find a course");
	}

	public void verifyCoursesSearchResults(String SearchTerm) {
		for (WebElement e : (List<WebElement>) elements("lst_courseSearchResults")) {
			System.out.println(e.getText().toLowerCase());
			System.out.println(SearchTerm.toLowerCase());
			customAssert.customAssertEquals(e.getText().toLowerCase().contains(SearchTerm.toLowerCase()), true,
					"[Assertion Failed]: Search term is not contained in the results");
		}
		logMessage("Appropriate results are displayed for the search Term");
	}

	public void verifyUserSearchResults(String SearchTerm) {
		for (WebElement e : (List<WebElement>) elements("lst_userSearchResultsSearchresult")) {
			System.out.println(e.getText().toLowerCase());
			System.out.println(SearchTerm.toLowerCase());
			customAssert.customAssertEquals(e.getText().toLowerCase().contains(SearchTerm.toLowerCase()), true,
					"[Assertion Failed]: Search term is not contained in the results");
		}
		logMessage("Appropriate results are displayed for the search Term");
	}

	public void removeAllUser() {
		List<WebElement> list = elements("icon_setting");
		int i = 0;
		while (list.size() > 0) {
			list.get(0).click();
			hoverClick(elements("link_removeFromCourse").get(0));
			wait.hardWait(3);
			handleAlert();
			refreshPage();
			list = elements("icon_setting");
		}
//			logMessage("Admin has removed all the users from the course");

	}

	public void clickStatisticsOnLeftTab() {
		clickLeftTab("Statistics");
		logMessage("User clicked on Statics menu on left panel");
	}

	public void verifyStatisticsPage() {
		verifyPageTitleContains("Statistics");
		isElementDisplayed("txt_heading", "General Numbers");
		isElementDisplayed("txt_heading", "Recently Started Courses");
		isElementDisplayed("txt_heading", "Recently Ended Courses");
		isElementDisplayed("txt_heading", "Recently Logged-In Users");
		logMessage("User is on Statistics page");
	}

	public void verifyStatisticsPageForSubAccountQA() {
		verifyPageTitleContains("Statistics");
		isElementDisplayed("txt_heading", "Recently Started Courses");
		isElementDisplayed("txt_heading", "Recently Ended Courses");
		isElementDisplayed("txt_heading", "Recently Logged-In Users");
		logMessage("User is on Statistics page");
	}

	public void clickPermissionOnLeftTab() {
		clickLeftTab("Permissions");
		logMessage("User clicked on Permissions menu on left panel");
	}

	public void verifyManagePermissionPage() {
		verifyPageTitleContains("Manage Permissions");
		isElementDisplayed("lnk_courseRoles");
		isElementDisplayed("lnk_accountRoles");
		isElementDisplayed("btn_addRole");
		logMessage("User is on Manage Permission page");
	}

	public void clickOutcomesOnLeftTab() {
		clickLeftTab("Outcomes");
		logMessage("User clicked on Outcomes menu on left panel");
	}

	public void verifyLearningOutcomesPage() {
		verifyPageTitleContains("Outcomes");
		isElementDisplayed("btn_outcome");
		isElementDisplayed("btn_group");
		isElementDisplayed("btn_find");
		logMessage("User is on Learning Outcome page");
	}

	public void clickRubricsOnLeftTab() {
		clickLeftTab("Rubrics");
		logMessage("User clicked on Rubrics menu on left panel");
	}

	public void verifyRubricsPage() {
		verifyPageTitleContains("Rubrics");
		isElementDisplayed("txt_accountRubrics");
		isElementDisplayed("btn_addRubric");
		logMessage("User is on Rubrics page");
	}

	public void clickGradingOnLeftTab() {
		clickLeftTab("Grading");
		logMessage("User clicked on Grading menu on left panel");
	}

	public void verifyGradingStandardsPage() {
		verifyPageTitleContains("Grading");
		isElementDisplayed("lnk_gradingPeriods");
		isElementDisplayed("lnk_gradingSchemes");
		isElementDisplayed("btn_setOfGradingPeriods");
		logMessage("User is on Grading Standards page");
	}

	public void verifyGradingStandardsPageForSubAccountQA() {
		verifyPageTitleContains("Grading");
		isElementDisplayed("lnk_gradingPeriods");
		isElementDisplayed("lnk_gradingSchemes");
		logMessage("User is on Grading Standards page");
	}

	public void verifyQuestionBanksPage() {
		verifyPageTitleContains("Question Banks");
		isElementDisplayed("lnk_addQuestionBank");
		isElementDisplayed("lnk_viewBookmarkBanks");
		logMessage("User is on Question Banks page");
	}

	public void verifySubAccountPage() {
		verifyPageTitleContains("Sub-Accounts");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(0).getText().contains("Macmillan2"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(1).getText().contains("AWS Smoke Test"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(2).getText().contains("Dev"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(3).getText().contains("Load Test"), true,
				"element not found");
		customAssert.customAssertEquals(
				elements("lnk_SubAccount").get(4).getText().contains("Manually-Created Courses"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(5).getText().contains("Phoenix LT"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(6).getText().contains("Phoenix Pretend DEV"),
				true, "element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(7).getText().contains("Phoenix PROD Smoke"),
				true, "element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(8).getText().contains("Pristine"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(9).getText().contains("QA"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(10).getText().contains("Scott Prod Test"), true,
				"element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(11).getText().contains("Scott's Local Dev"),
				true, "element not found");
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(12).getText().contains("Smoke Test"), true,
				"element not found");
		logMessage("User is on sub account list");
	}

	public void verifyRedirectionOfMacmillan2Page() {
		waitAndClick("lnk_macmillan2");
		verifyPageTitleContains("Macmillan2");
	}

	public void verifyLeftMenuOption() {
		isElementDisplayed("link_leftMenu", "Courses");
		isElementDisplayed("link_leftMenu", "People");
		isElementDisplayed("link_leftMenu", "Statistics");
		isElementDisplayed("link_leftMenu", "Permissions");
		isElementDisplayed("link_leftMenu", "Outcomes");
		isElementDisplayed("link_leftMenu", "Rubrics");
		isElementDisplayed("link_leftMenu", "Grading");
		isElementDisplayed("link_leftMenu", "Question Banks");
		isElementDisplayed("link_leftMenu", "Sub-Accounts");
		isElementDisplayed("link_leftMenu", "Admin Tools");
		isElementDisplayed("link_leftMenu", "Settings");
		logMessage("verified all the left content menu option");
	}

	public void verifySubAccountQAContent() {
		isElementDisplayed("chkbox_hideEnrollmentLess");
		isElementDisplayed("btn_filter");
		waitForElementToBeVisible("input_findCourse");
		// isElementDisplayed("input_findCourse");
		waitForElementToBeVisible("input_findUser");
		// isElementDisplayed("input_findUser");
		int i = 0;
		for (WebElement goBtn : elements("btn_go")) {
			i++;
			customAssert.customAssertEquals(goBtn.getText(), "Go", "Go button not found" + i);
		}
		isElementDisplayed("lnk_newCourseCreate");
		logMessage("User is on sub account QA page");
	}

	public void clickOnSubAccountLink(String subAccountName) {
		waitForElementToBeVisible("lnk_SubAccount");
		for (WebElement subAccountName1 : elements("lnk_SubAccount")) {
			System.out.println(subAccountName1.getText());
			if (subAccountName1.getText().equals(subAccountName)) {
				subAccountName1.click();
				break;
			}
		}
	}

	public void verifyQALink() {
		customAssert.customAssertEquals(elements("lnk_SubAccount").get(0).getText().contains("QA"), true,
				"element not found");
		logMessage("User is on sub account QA of QA link page");
	}

	public void verifyAdminToolsPageContent() {
		String className = element("tab_restoreCourses", "Restore Courses").getAttribute("class");
		customAssert.customAssertEquals(className.contains("active"), true, "its not an active tab");
		isElementDisplayed("tab_restoreCourses", "Logging");
		isElementDisplayed("searchBox_deletedCourse");
		isElementDisplayed("btn_find1");
		logMessage("User is on Admin Tools Page");
	}

	public void clickOnTab(String tabName) {
		element("tab_restoreCourses", tabName).click();
		logMessage("Clicked at " + tabName);
	}

	public void verifyloggingTabContent() {
		List<WebElement> drpDownOption = elements("drpDwn_logSearch");
		customAssert.customAssertEquals(drpDownOption.get(0).getText(), "Select a Log type",
				"dropdown value is not matched");
		customAssert.customAssertEquals(drpDownOption.get(1).getText().trim().contains("Login / Logout Activity"), true,
				"dropdown value is not matched");
		customAssert.customAssertEquals(drpDownOption.get(2).getText().trim().contains("Grade Change Activity"), true,
				"dropdown value is not matched");
		customAssert.customAssertEquals(drpDownOption.get(3).getText().trim().contains("Course Activity"), true,
				"dropdown value is not matched");
		logMessage("verified the logging tab content");
	}

	public void verifySettingsContentOfQASubAccount() {
		List<WebElement> tabList = elements("tab_settings");
		customAssert.customAssertEquals(tabList.get(0).getText(), "Settings", "settings not found");
		customAssert.customAssertEquals(tabList.get(1).getText(), "Quotas", "quotas not found");
		customAssert.customAssertEquals(tabList.get(2).getText(), "Admins", "admins not found");
		customAssert.customAssertEquals(tabList.get(3).getText(), "Announcements", "announcements not found");
		customAssert.customAssertEquals(tabList.get(4).getText(), "Reports", "reports not found");
		customAssert.customAssertEquals(tabList.get(5).getText(), "Apps", "apps not found");
		customAssert.customAssertEquals(tabList.get(6).getText(), "Feature Options", "feature options not found");
		logMessage("verified the setting content on QA subaccount");
	}

	public void verifyTermsContentPage() {
		isElementDisplayed("btn_edit");
		isElementDisplayed("btn_delete");
		isElementDisplayed("lnk_addNewTerm");
		logMessage("verified terms content page");
	}

	public void verifyAuthenticationContentPage() {
		isElementDisplayed("txt_headers");
		List<WebElement> txt = elements("txt_SSonCurrProvider");
		customAssert.customAssertEquals(txt.get(0).getText(), "SSO Settings", "SSO Settings text not found");
		customAssert.customAssertEquals(txt.get(1).getText(), "Current Provider", "Current Provider text not found");
		isElementDisplayed("input_AuthPage", "Login Label");
		isElementDisplayed("input_AuthPage", "Forgot Password URL");
		isElementDisplayed("input_AuthPage", "Discovery URL");
		String saveButton = element("btn_save").getText();
		customAssert.customAssertEquals(saveButton, "Save", "save button not found");
		customAssert.customAssertEquals(element("txt_desc_canvas").getText(),
				"You can log in directly with this provider by going to /login/canvas", "message not found");
		customAssert.customAssertEquals(element("txt_selfReg").getText(), "Self Registration",
				"Self Registration text not found");
		logMessage("verified Authentication content page");
	}

	public void verifySISImportContentPage() {
		customAssert.customAssertEquals(element("txt_headers").getText(), "SIS Import", "SIS Import text not found");
		isElementDisplayed("browseButton");
		isElementDisplayed("drpDwn_importType");
		isElementDisplayed("txt_chkboxWithMessage", "This is a full batch update");
		isElementDisplayed("txt_chkboxWithMessage", "Override UI changes");
		isElementDisplayed("txt_chkboxWithMessage", "Clear UI-changed state");
		isElementDisplayed("txt_chkboxWithMessage", "Process as UI changes");
		isElementDisplayed("btn_processData");
		logMessage("verified SIS Import content page");
	}

	public void verifyThemesContentPage() {
		isElementDisplayed("txt_headers");
		customAssert.customAssertEquals(element("btn_theme").getText(), "Theme", "theme add button not found");
		List<WebElement> template = elements("template_theme");
		customAssert.customAssertEquals(template.size(), 4, "count is not natched");
		customAssert.customAssertEquals(template.get(0).isDisplayed(), true, "template 0 index is not displayed");
		customAssert.customAssertEquals(template.get(1).isDisplayed(), true, "template 1 index is not displayed");
		customAssert.customAssertEquals(template.get(2).isDisplayed(), true, "template 2 index is not displayed");
		customAssert.customAssertEquals(template.get(3).isDisplayed(), true, "template 3 index is not displayed");
		logMessage("verified Themes content page");
	}

	public void verifyDeveloperKeysContentPage() {
		customAssert.customAssertEquals(element("txt_SSonCurrProvider").getText(), "Developer Keys",
				"[Assertion Failed] : Developer keys header not found");
		isElementDisplayed("btn_developerKeys");
		logMessage("verified Developer Keys content page");
	}

	public void closeModelPopUp() {
		element("btn_close").click();
		logMessage("Model Popup closed");
	}

	public void verifyNewCourseSubAccountDropDownOptionAndSelectedValue(String selectOption) {
		element("dropdownSubaccount").click();
		List<WebElement> listOfOptions = elements("drpDwn_SubAccountOption");
		String drpDownOption[] = { "Macmillan2", "AWS Smoke Test", "Dev", "Load Test", "Manually-Created Courses",
				"Phoenix LT", "Phoenix Pretend DEV", "Phoenix PROD Smoke", "Pristine", "QA", "Scott Prod Test",
				"Scott's Local Dev", "Smoke Test" };
		int i = 0;
		for (WebElement optionValue : listOfOptions) {
			customAssert.customAssertEquals(optionValue.getText().contains(drpDownOption[i]), true, "");
			i++;
		}
		for (WebElement optionValue : listOfOptions) {
			if (optionValue.getText().contains(selectOption)) {
				optionValue.click();
				break;
			}
		}
		// customAssert.customAssertEquals("","QA", "");
	}

	public void verifyNewCourseEnrollmentDropDownOption() {
		element("dropdown_enrollmentTerm").click();
		List<WebElement> listOfOptions = elements("drpDwn_enrollmentTermOption");
		String drpDownOption[] = { "Default Term" };
		int i = 0;
		for (WebElement optionValue : listOfOptions) {
			customAssert.customAssertEquals(optionValue.getText().contains(drpDownOption[i]), true,
					"Not matched with dropdown option");
			i++;
		}
	}

	public void clickOnButtonOFModalPopUp(String index, String buttonName) {
		hardWait(3);
		waitAndClick("btn_addUserNCancel", index, buttonName);
	}

	public void verifyRequiredMessageField() {
		customAssert.customAssertEquals(element("txt_requiredField", "10").getText(), "Required field: Course Name:",
				"Required fields not found");
		customAssert.customAssertEquals(element("txt_requiredField", "11").getText(), "Required field: Reference Code:",
				"Required fields not found");
		logMessage("verified Required text field appear on the Modal Popup");
	}

	public void verifyCancelButton() {
		verifyElementNotDisplayed("textbox_CourseName");
		verifyElementNotDisplayed("textbox_refCode");
		verifyElementNotDisplayed("dropdownSubaccount");
		verifyElementNotDisplayed("dropdown_enrollmentTerm");
		verifyElementNotDisplayed("btn_cancel", "Cancel");
		verifyElementNotDisplayed("btn_addCourse", "Add Course");
		logMessage("verified Cancel button functionality");
	}

	public void verifyCancelButtonForNewUserModalPopUp() {
		isElementDisplayed("textbox_username");
		isElementDisplayed("textbox_displayName");
		isElementDisplayed("textbox_sortableName");
		isElementDisplayed("textbox_email");
		isElementDisplayed("textbox_ssid");
		isElementDisplayed("checkbox_sendConfirmation");
		isElementDisplayed("btn_addUserNCancel", "Cancel");
		isElementDisplayed("btn_addUserNCancel", "Add User");
		logMessage("verified cancel button is not on the Modal Popup");
	}

	String userFullName;

	public void enterFullName(String fullName) {
		userFullName = fullName;
		isElementDisplayed("textbox_username");
		fillText("textbox_username", fullName);
	}

	public void verifyDisplayAndSortableName() {
		isElementDisplayed("textbox_displayName");
		isElementDisplayed("textbox_sortableName");
		customAssert.customAssertEquals(element("textbox_displayName").getAttribute("value"), userFullName,
				"display name not matched");
		String sortName[] = userFullName.split(" ");
		String getSortedValue[] = element("textbox_sortableName").getAttribute("value").split(",");
		customAssert.customAssertEquals(getSortedValue[0], sortName[1], "sortable name not matched");
	}

	public void enterEmailAddress(String emailId) {
		fillText("textbox_email", emailId);
	}

	public void verifyInvalidEmailAddress() {
		isElementDisplayed("txt_invalidMessage");
	}

	public void verifyHomePageOfSelectedCourse(String courseName1) {
		verifyPageTitleContains(courseName1);
		logMessage("verified home page of selected course");
	}

	public void verifyLeftTabOfSelectedCourse() {
		isElementDisplayed("link_leftMenu", "Home");
		isElementDisplayed("link_leftMenu", "Announcements");
		isElementDisplayed("link_leftMenu", "Assignments");
		isElementDisplayed("link_leftMenu", "Discussions");
		isElementDisplayed("link_leftMenu", "Grades");
		isElementDisplayed("link_leftMenu", "People");
		isElementDisplayed("link_leftMenu", "Pages");
		isElementDisplayed("link_leftMenu", "Files");
		isElementDisplayed("link_leftMenu", "Syllabus");
		isElementDisplayed("link_leftMenu", "Outcomes");
		isElementDisplayed("link_leftMenu", "Quizzes");
		isElementDisplayed("link_leftMenu", "Modules");
		isElementDisplayed("link_leftMenu", "Conferences");
		isElementDisplayed("link_leftMenu", "Collaborations");
		isElementDisplayed("link_leftMenu", "Settings");
		logMessage("verified left tab of home page of selected course");
	}

	public void verifyRightSideContentOfSelectedCourse() {
		List<WebElement> btn = elements("btn_publishNunpublish");
		customAssert.customAssertEquals(btn.get(0).isDisplayed(), true, btn.get(0).getText() + " not found");
		customAssert.customAssertEquals(btn.get(0).isDisplayed(), true, btn.get(0).getText() + " not found");
		isElementDisplayed("btn_chooseHomePage");
		List<WebElement> listSidebar = elements("lnk_btnSideBar");
		customAssert.customAssertEquals(listSidebar.get(0).isDisplayed(), true,
				listSidebar.get(0).getText() + " not found");
		customAssert.customAssertEquals(listSidebar.get(1).isDisplayed(), true,
				listSidebar.get(1).getText() + " not found");
		customAssert.customAssertEquals(listSidebar.get(2).isDisplayed(), true,
				listSidebar.get(2).getText() + " not found");
		isElementDisplayed("lnk_viewCalendar");
		logMessage("verified right side content of home page of selected course");
	}

	public void verifyAnnouncementsContentPage(String courseName) {
		verifyPageTitleContains("Announcements: " + courseName);
		hardWait(3);
		List<WebElement> filerList = elements("drpDwn_filter");
		customAssert.customAssertEquals(filerList.get(0).getText(), "All", "Filter name 'All' not found");
		customAssert.customAssertEquals(filerList.get(1).getText(), "Unread", "Filter name 'Unread' not found");
		isElementDisplayed("input_announcementSearch");
		isElementDisplayed("addBtn_announcements");
		isElementDisplayed("lnk_addExtrnlLink");
		logMessage("verified Announcement contents page");
	}

	public void verifyAssignmentsContentPage(String courseName1) {
		verifyPageTitleContains("Assignments: " + courseName1);
		isElementDisplayed("input_searchTerm");
		customAssert.customAssertEquals(element("btnn_addGroup").getText().contains("Group"), true, "Group not found");
		customAssert.customAssertEquals(element("lnk_assignment").getText().contains("Assignment"), true,
				"Assignment not found");
		isElementDisplayed("btn_toggle");
		isElementDisplayed("btn_setting");
		isElementDisplayed("btn_assntoAssign");
		isElementDisplayed("lnk_trigger");
		logMessage("verified Assignment contents page");
	}

	public void verifyDiscussionsContentPage(String courseName1) {
		verifyPageTitleContains("Discussions: " + courseName1);
		isElementDisplayed("input_searchTermDisc");
		customAssert.customAssertEquals(element("txt_unread").getText().contains("Unread"), true, "Unread not found");
		customAssert.customAssertEquals(element("lnk_discussion").getText(), "Discussion", "Discussion not found");
		isElementDisplayed("btn_editSettings");
		//
		//
		//
		logMessage("verified Discussions content page");
	}

	public void verifyGradesContentPage(String courseName1) {
		verifyPageTitleContains("Gradebook - " + courseName1);
		isElementDisplayed("input_searchQuery");
		isElementDisplayed("btn_keyboardShortcuts");
		customAssert.customAssertEquals(element("btn_indivisualView").getText(), "Individual View",
				"Individual View not found");
		hardWait(5);
		String importLnk = (String) executeJavascript("return $('.ui-button')[0].textContent");
		String exportLnk = (String) executeJavascript("return $('.ui-button')[1].textContent");
		String gradeBookSetting = (String) executeJavascript("return $('.ui-button')[2].textContent");
		customAssert.customAssertEquals(importLnk.contains("Import"), true, "Import link not found");
		customAssert.customAssertEquals(exportLnk.contains("Export"), true, "Export link not found");
		customAssert.customAssertEquals(gradeBookSetting.contains("Gradebook Settings"), true,
				"Gradebook Settings button not found");
		List<WebElement> tabName = elements("tab_onPage");
		customAssert.customAssertEquals(tabName.get(0).getText(), "Student Name",
				tabName.get(0).getText() + " tab not found");
		customAssert.customAssertEquals(tabName.get(1).getText(), "Secondary ID",
				tabName.get(1).getText() + " tab not found");
		customAssert.customAssertEquals(tabName.get(2).getText(), "Assignments",
				tabName.get(2).getText() + " tab not found");
		customAssert.customAssertEquals(tabName.get(3).getText(), "Total", tabName.get(3).getText() + " tab not found");
		logMessage("verified Grade Contents Page");
	}

	public void redirectionAtHomePage() {
		waitAndClick("lnk_redirect");
		logMessage("redirected at home page");
	}

	public void verifyPeopleLeftTabContentOfCourse(String courseName1) {
		verifyPageTitleContains("Course Roster: " + courseName1);
		isElementDisplayed("tab_restoreCourses", "Everyone");
		isElementDisplayed("tab_restoreCourses", "Groups");
		String groupSetLink = (String) executeJavascript("return $('.btn.btn-primary')[0].textContent");
		String peopleLink = (String) executeJavascript("return $('.btn.btn-primary')[1].textContent");
		customAssert.customAssertEquals(groupSetLink.contains("Group Set"), true, groupSetLink + " tab not found");
		customAssert.customAssertEquals(peopleLink, "People", peopleLink + " tab not found");
		isElementDisplayed("drpDwn_allRoles");
		List<WebElement> paragraph = elements("txt_alertParagraph");
		customAssert.customAssertEquals(paragraph.get(0).getText(), "No people found",
				paragraph.get(0).getText() + " Not found");
		customAssert.customAssertEquals(paragraph.get(1).getText(), "You can search by:",
				paragraph.get(1).getText() + " Not found");
		logMessage("verified People Contents Page");
	}

	public void verifyPageContentBeforeAddingUserAccounts() {
		List<WebElement> list = elements("txt_alertList");
		customAssert.customAssertEquals(list.get(0).getText(), "Name", list.get(0).getText() + " Not found");
		customAssert.customAssertEquals(list.get(1).getText(), "Login ID", list.get(1).getText() + " Not found");
		customAssert.customAssertEquals(list.get(2).getText(), "SIS ID", list.get(2).getText() + " Not found");
		customAssert.customAssertEquals(list.get(3).getText(), "Canvas User ID", list.get(3).getText() + " Not found");
	}

	public void removeUserFromCourse() {
		if (!verifyElementNotDisplayed("txt_AddedUser")) {
			waitAndClick("btn_adminLink");
			waitAndClick("lnk_removeFromCourse");
			handleAlert();
			refreshPage();
		}
	}

	public void verifyPageContentOfCoursePage(String courseName1) {
		verifyPageTitleContains(courseName1 + ": Pages");
		isElementDisplayed("text_columnHeaderForPages", "Page title");
		isElementDisplayed("text_columnHeaderForPages", "Creation date");
		isElementDisplayed("text_columnHeaderForPages", "Last edit");
		logMessage("verified Page Contents");
	}

	public void verifyFilesContentOfCoursePage() {
		isElementDisplayed("btn_searchIcon");
		isElementDisplayed("btn_addFolder");
		isElementDisplayed("btn_uplaod");
		isElementDisplayed("iconFolder");
		isElementDisplayed("text_columnHeader", "Name");
		isElementDisplayed("text_columnHeader", "Date Created");
		isElementDisplayed("text_columnHeader", "Date Modified");
		isElementDisplayed("text_columnHeader", "Modified By");
		isElementDisplayed("text_columnHeader", "Size");
		logMessage("verified File Contents Page");
	}

	public void verifySyllabusContentOfCoursePage(String courseName1) {
		verifyPageTitleContains("Syllabus for " + courseName1);
		isElementDisplayed("txt_courseSummary");
		isElementDisplayed("jump_to_today_link");
		isElementDisplayed("btn_edit_syllabus_link");
		isElementDisplayed("calander");
		logMessage("verified Syllabu Contents Page");
	}

	public void verifyOutcomesContentOfCoursePage() {
		verifyPageTitleContains("Learning Outcomes");
		isElementDisplayed("txt_outcome");
		isElementDisplayed("txt_group");
		isElementDisplayed("txt_import");
		isElementDisplayed("txt_find");
		customAssert.customAssertEquals(element("wrapper_title").getText().trim(), "Setting up Outcomes",
				"Setting up Outcomes text is not matched");
		logMessage("verified Outcome Contents Page");
	}

	public void verifyQuizzesContentOfCoursePage() {
		verifyPageTitleContains("Quizzes");
		isElementDisplayed("input_searchTermDisc");
		isElementDisplayed("btn_addQuizz");
		isElementDisplayed("btn_iconMore");
		customAssert.customAssertEquals(element("txt_header").getText().contains("Course Quizzes"), true,
				"Course Quizzes not found");
		logMessage("verified Quizze Contents Page");
	}

	public void verifyModulesContentOfCoursePage(String courseName1) {
		verifyPageTitleContains("Course Modules: " + courseName1);
		isElementDisplayed("btn_viewProgress");
		isElementDisplayed("btn_addModule");
		logMessage("verified Module Contents Page");
	}

	public void verifyConferencesContentOfCoursePage(String courseName1) {
		verifyPageTitleContains("Web Conferences: " + courseName1);
		List<WebElement> toggler = elements("btn_toggler");
		customAssert.customAssertEquals(toggler.get(0).isDisplayed(), true, "New Conferences toggle button not found");
		customAssert.customAssertEquals(toggler.get(1).isDisplayed(), true,
				"Concluded Conferences toggle button not found");
		String txt_newConferences = (String) executeJavascript("return $('.accessible-toggler')[0].textContent");
		String txt_ConcludedConferences = (String) executeJavascript("return $('.accessible-toggler')[1].textContent");
		customAssert.customAssertEquals(txt_newConferences.contains("New Conferences"), true,
				"New Conferences text not found");
		customAssert.customAssertEquals(txt_ConcludedConferences.contains("Concluded Conferences"), true,
				"Concluded Conferences text not found");
		logMessage("verified Conference Contents Page");
	}

	public void verifyCollaborationsContentOfCoursePage(String courseName1) {
		verifyPageTitleContains("Collaboration: " + courseName1);
		isElementDisplayed("txt_headers");
		isElementDisplayed("label_drpDwnLabel");
		isElementDisplayed("lnk_googleDocs");
		isElementDisplayed("txt_authorizeGoogleDrive");
		isElementDisplayed("btn_cancel");
		logMessage("verified Collaboration Contents Page");
	}

	public void verifySettingsContentOfCoursePage(String courseName1) {
		verifyPageTitleContains("Course Details: " + courseName1);
		isElementDisplayed("lnk_tabname", "Course Details");
		isElementDisplayed("lnk_tabname", "Sections");
		isElementDisplayed("lnk_tabname", "Navigation");
		isElementDisplayed("lnk_tabname", "Apps");
		isElementDisplayed("lnk_tabname", "Feature Options");
		logMessage("verified tab name of setting content of course page");
	}

	public void clickOnPublishButton() {
		element("btn_publish").click();
		logMessage("Clicked on publish button");
	}

	public void clickOnUnPublishButton() {
		element("btn_unpublish").click();
		logMessage("Clicked on unPublish button");
	}

	public void verifyPublishCourseMessages() {
	}

	public void clickOnButtonOfPage(String textName) {
		waitAndClick("text_columnHeaderForPages", textName);
	}

	public void clickOnButtonOverPopupSuingJsWithIndex(String index) {
		hardWait(4);
		executeJavascript("$('.ui-dialog-buttonset button')[" + index + "].click()");
	}

	public void clickOnCancelButtonOverAddCourse() {
		waitForElementToBeClickable(element("btn_cancel_add_course"));
		hardWait(3);
		clickUsingJavaScript("btn_cancel_add_course");
	}
}
