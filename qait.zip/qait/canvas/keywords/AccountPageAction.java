package com.qait.canvas.keywords;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qait.automation.getpageobjects.GetPage;
import com.qait.automation.utils.SeleniumWait;

public class AccountPageAction extends GetPage {
	WebDriver driver;
	SeleniumWait wait;
	static int count;
	public static String courseName;

	public AccountPageAction(WebDriver driver) {
		super(driver, "Account");
		this.driver = driver;
	}

	public void verifyUserIsOnAccountPage() {
		isElementDisplayed("txt_AdminSettingsSubHeading");
		isElementDisplayed("txt_AccountInfoLabel", "Ways to Log In");
		isElementDisplayed("txt_AccountInfoLabel", "Web Services");
		isElementDisplayed("txt_AccountInfoLabel", "Approved Integrations:");
		isElementDisplayed("txt_AccountInfoLabel", "Feature Options");
		/*isElementDisplayed("lnk_leftNavPanel", "1", "Notifications");
		isElementDisplayed("lnk_leftNavPanel", "1", "Files");
		isElementDisplayed("lnk_leftNavPanel", "1", "Settings");
		isElementDisplayed("lnk_leftNavPanel", "1", "ePortfolios");*/
		isElementDisplayed("lnk_leftNavPanel", "Notifications");
		isElementDisplayed("lnk_leftNavPanel", "Files");
		isElementDisplayed("lnk_leftNavPanel", "Settings");
		isElementDisplayed("lnk_leftNavPanel", "ePortfolios");
		isElementDisplayed("lnk_rightContactDetails", "Email Address");
		isElementDisplayed("lnk_rightContactDetails", "Contact Method");
		isElementDisplayed("lnk_rightPanelButton", "Edit Settings");
		isElementDisplayed("lnk_rightPanelButton", "Download Submissions");
		// isElementDisplayed("lnk_rightPanelButton", "Delete My Account");
		// Removed
		logMessage("User is on Account Settings page");
	}

	public void verifySettingTabTitle() {
		customAssert.customAssertEquals(getPageTitle(),
				"User Settings: Admin Jones",
				"[Assertion Failed]: Page title does not match");
		logMessage("[Assertion Passed]: Page title match");
	}

	public void clickNotificationsFromLeftPanel() {
		isElementDisplayed("lnk_leftNavPanel", "Notifications");
		element("lnk_leftNavPanel", "Notifications").click();
		logMessage("User clicked on Notifications Link");
	}

	public void verfiyNotificationPageTitle() {
		customAssert.customAssertEquals(getPageTitle(),
				"Notification Preferences",
				"[Assertion Failed]: Page title does not match");
		logMessage("[Assertion Passed]: Page title match");

	}

	public void clickFilesFromLeftPanel() {
		isElementDisplayed("lnk_leftNavPanel", "Files");
		element("lnk_leftNavPanel", "Files").click();
		logMessage("User clicked on Files Link");
	}

	public void verfiyFilesPageTitle() {
		customAssert.customAssertEquals(getPageTitle(), "Files",
				"[Assertion Failed]: Page title does not match");
		logMessage("[Assertion Passed]: Page title match");

	}

	public void clickePortfoliosFromLeftPanel() {
		isElementDisplayed("lnk_leftNavPanel", "ePortfolios");
		element("lnk_leftNavPanel", "ePortfolios").click();
		logMessage("User clicked on ePortfolios Link");
	}

	public void verfiyePortfoliosPageTitle() {
		customAssert.customAssertEquals(getPageTitle(), "My ePortfolios",
				"[Assertion Failed]: Page title does not match");
		logMessage("[Assertion Passed]: Page title match");

	}

	public void verifyAccountTabContent() {
		isElementDisplayed("btn_logout");
		isElementDisplayed("btn_crossIcon");
		isElementDisplayed("lnk_leftNavPanel", "2", "Notifications");
		isElementDisplayed("lnk_leftNavPanel", "2", "Files");
		isElementDisplayed("lnk_leftNavPanel", "2", "Settings");
		isElementDisplayed("lnk_leftNavPanel", "2", "ePortfolios");
		logMessage("Verified Account tab page content");
	}

	public void clickOnCrossIcon() {
		waitAndClick("btn_crossIcon");
		logMessage("Clicked on cross icon");
	}

	public void verifyAccountTabContentNotDisplayed() {
		verifyElementNotDisplayed("btn_logout");
		verifyElementNotDisplayed("btn_crossIcon");
		verifyElementNotDisplayed("lnk_leftNavPanel", "2", "Notifications");
		verifyElementNotDisplayed("lnk_leftNavPanel", "2", "Files");
		verifyElementNotDisplayed("lnk_leftNavPanel", "2", "Settings");
		verifyElementNotDisplayed("lnk_leftNavPanel", "2", "ePortfolios");
		logMessage("Verified Cross Icon Functionality");
	}

	public void clickOnEmailLinkFromSettingsPanel() {
		waitAndClick("link_emailFromSettings");
		logMessage("Clicked at email link from setting page");
	}

	public void verifyConfirmEmailAddressPopup(String userName) {
		isElementDisplayed("txtHeader_popUp");
		customAssert.customAssertEquals(element("txtHeader_popUp").getText(),
				"Confirm Email Address",
				"Assertion Failed: popUp txt header not mathced as expected");
		String popUpMessage = (String) executeJavascript("return document.getElementById('confirm_email_channel').textContent");
		customAssert.customAssertEquals(popUpMessage.contains(userName), true,
				"Assertion Failed: " + userName
						+ " not matched from popup message body");
		isElementDisplayed("link_resendConfirmation");
		customAssert
				.customAssertEquals(element("link_resendConfirmation")
						.getText(), "Re-Send Confirmation",
						"Assertion Failed: Re-send confirmation link not mathced as expected");
		isElementDisplayed("btn_OkThanks");
		waitAndClick("btn_deleteAddedCellNo", userName);
		_alertAccept();
		logMessage("Verified Confirmation Email Popup Content");
	}

	public void clickOnReSendConfirmationLink() {
		waitAndClick("link_resendConfirmation");
		logMessage("Clicked on Re-send Confirmation Link");
	}

	public void clickOnOkThanksButton() {
		waitAndClick("btn_OkThanks");
		logMessage("Clicked on Ok, Thanks Button");
	}

	public void verifyOkThanksButtonFunctionality() {
		verifyElementNotDisplayed("txtHeader_popUp");
		verifyElementNotDisplayed("link_resendConfirmation");
		verifyElementNotDisplayed("btn_OkThanks");
		logMessage("Verified Ok,Thanks button Functionality");
	}

	public void clickOnAddEmailAddressButton() {
		waitAndClick("btn_AddEmailAddress");
		logMessage("Clicked on Add Email Address button");
	}

	public void verifyAddEmailAddressModalPopup(String alternateEmailAddress) {
		isElementDisplayed("txtHeader_AddEmailAddress");
		List<WebElement> tabName = elements("tab_AddEmailAddress");
		customAssert.customAssertEquals(tabName.get(0).getText(), "Email",
				"Assertion Failed: Email tab not found as expected");
		customAssert.customAssertEquals(tabName.get(1).getText(), "Text (SMS)",
				"Assertion Failed: Text (SMS) tab not found as expected");
		isElementDisplayed("input_emailAddress");
		isElementDisplayed("btn_registerEmail");
		waitAndClick("btn_registerEmail");
		verifyToastMessageAppearsOrNot("Email is required");
		fillText("input_emailAddress", alternateEmailAddress);
		waitAndClick("btn_registerEmail");
		verifyConfirmEmailAddressPopup(alternateEmailAddress);
		clickOnOkThanksButton();
	}

	public void verifyTextSmsTabOfAddEmailAddress(String mobileNo) {
		List<WebElement> tabName = elements("tab_AddEmailAddress");
		tabName.get(1).click();
		isElementDisplayed("input_textSMS", "Cell Number");
		isElementDisplayed("input_textSMS", "SMS Email");
		customAssert.customAssertEquals(elements("drpDwn_carrier").get(0)
				.getText(), "[Select Carrier]",
				"Assertin Failed: [Select Carrier] is not matched as expected");
		isElementDisplayed("btn_registerSMS");
		waitAndClick("btn_registerSMS");
		verifyToastMessageAppearsOrNot("Email is required");
		fillText(element("input_textSMS", "Cell Number"), mobileNo);
		selectTextFromDropDown("drpDwn_carrier", "Alltel");
		fillText(element("input_textSMS", "SMS Email"), "test@fake123.com");
		waitAndClick("btn_registerSMS");
		verifyConfirmSMSNumber(mobileNo);
		logMessage("verified all text and label of TEXT (SMS) tab of Add Email Address");
	}

	public void verifyConfirmSMSNumber(String mobileNo) {
		isElementDisplayed("txtHeader_ConfirmSMSModal");
		String confirmSMS = (String) executeJavascript("return document.getElementById('sms_confirmation_instructions').textContent");
		customAssert.customAssertEquals(confirmSMS.contains(mobileNo), true,
				"Assertion Failed :" + mobileNo + " number not found");
		isElementDisplayed("btn_confirm");
		isElementDisplayed("btn_close");
		waitAndClick("btn_close");
		waitAndClick("btn_deleteAddedCellNo", mobileNo);
		_alertAccept();
		logMessage("Verified Confirm SMS Number modal popup");
	}

	public void clickOnContactLink() {
		waitAndClick("link_contact");
		logMessage("Clicked on contact link");
	}

	public void clickOnEditSettingsButton() {
		isElementDisplayed("btn_editSettings");
		element("btn_editSettings").click();
		logMessage("Edit Settings Button Clicked");
	}

	public void verifyFieldsOnStudentSettingsPage() {
		customAssert
				.customAssertTrue(
						isElementDisplayed("txt_genericFields", "Full Name:"),
						"Assertion Failed:: Full Name Field not present on page layout");
		customAssert
				.customAssertTrue(
						isElementDisplayed("txt_genericFields", "Display Name:"),
						"Assertion Failed:: Display Name Field not present on page layout");
		customAssert
				.customAssertTrue(
						isElementDisplayed("txt_genericFields",
								"Sortable Name:"),
						"Assertion Failed:: Sortable Name Field not present on page layout");
		customAssert
				.customAssertTrue(
						isElementDisplayed("dd_genericFields", "Language:"),
						"Assertion Failed:: Language dropdown field not present on page layout");
		customAssert
				.customAssertTrue(
						isElementDisplayed("dd_genericFields", "Time Zone:"),
						"Assertion Failed:: Time Zone dropdown field not present on page layout");
		customAssert
				.customAssertTrue(isElementDisplayed("chkbx_changePassword"),
						"Assertion Failed:: Change Password checkbox not visible on layout");
		customAssert.customAssertTrue(
				isElementDisplayed("btn_genericField", "Cancel"),
				"Assertion Failed:: Cancel Button not visible on layout");
		customAssert.customAssertTrue(
				isElementDisplayed("btn_genericField", "Update Settings"),
				"Assertion Failed:: Cancel Button not visible on layout");
		logMessage("Assertion Passed:: All the fields present on the Page Layout");
	}

	public void verifyCancelButtonFunctionalityOfStudentSettingsPage() {
		verifyElementNotDisplayed("txt_genericFields", "Full Name:");
		verifyElementNotDisplayed("txt_genericFields", "Display Name:");
		verifyElementNotDisplayed("txt_genericFields", "Sortable Name:");
		logMessage("Verified Cancel Button Functionality");
	}

	public void clickOnCancelButtonOfEditSettings() {
		waitAndClick("btn_cancelEditSettings");
		logMessage("Clicked on cancel Button of Edit Settings");
	}

	public void verifyEditFieldOFSettingPage(String userName,
			String oldPassword, String newPassword) {
		fillText("txt_genericFields", userName + "A");
		waitAndClick("checkBox_changePassword");
		fillText("input_oldPassowrd", oldPassword);
		fillText("input_newPassword", newPassword);
		fillText("input_confirmPassword", newPassword);
		waitAndClick("btn_genericField", "Update Settings");
		customAssert.customAssertEquals(element("txt_fullName").getText(),
				userName + "A",
				"Assertion Failed: Updated details not matched as expected");
		logMessage("Verified Edit Fields are reflected on Setting Page");
	}

	public void verifyDownloadSubmissionPage() {
		waitAndClick("lnk_downloadSubmissions");
		verifyPageTitleContains("Download Submissions");
		logMessage("Verified Download Submission Page");
	}

	public void verifyDeleteMyAccountPage() {
		waitAndClick("lnk_deleteMyAccount");
		isElementDisplayed("img_logo");
		isElementDisplayed("doc_pdfViewer");
		logMessage("Verified Delete My Account Page");
	}

	public void verifyAllCourses(String courseName) {
		isElementDisplayed("block_activateCourses");
		isElementDisplayed("text_courseName",courseName);
		logMessage("Verified User is on All Courses Page");
	}
}
