package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1992 extends Parent_Test{
	/*
	CanvasTestSessionInitiator canvas;
	private String external_Tool="";
	private String contentName;
	@SuppressWarnings("unused")
	private String chaptername = "Chapter 1. Introduction and Research Methods"; 

	private void initVars(){
		contentName = getData("contentName");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.non_associated"),
				getData("users.instructor.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = { "Step02_Log_In_As_Instructor" })
	public void Step03_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Course_Page" })
	public void Step04_Go_To_Tools_Tab() {
		external_Tool   = getData("external_tool");
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
	}
			
	@Test(dependsOnMethods = { "Step04_Go_To_Tools_Tab" })
	public void Step05_Getting_Started() {
		canvas.toolsPage.clickOnGettingStarted();
	}
	
	@Test(dependsOnMethods = { "Step05_Getting_Started" })
	public void Step06_CreateNewCourseAndAssociation() {
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.createNewCourse(getData("createCourse.linkText"),getData("createCourse.courseName"), getData("createCourse.school"), getData("createCourse.academicTerm"));
		canvas.provisionPage.associateFirstCourseFromTheList();
	}
	
	@Test(dependsOnMethods = { "Step06_CreateNewCourseAndAssociation" })
	public void Step07_AddAndDeployContent() {
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickToolLink("lnk_MacmillanContent");
		canvas.contentTocPage.ExpandFirstContentOfToc();
		canvas.contentTocPage.selectThirdLevelQuizContent(contentName);
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.selectModuleAndDeploy("autoModule");
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	
	@Test(dependsOnMethods = { "Step07_AddAndDeployContent" })
	public void Step08_Go_To_Module_Page() {
		canvas.coursePage.goToModulePage();
		canvas.modulePage.verifyModulePageOpens();
	}
	
	@Test(dependsOnMethods = { "Step08_Go_To_Module_Page" })
	public void Step09_Open_Deployed_Content_And_Delete_That_Content_In_PX_Side() {
		canvas.modulePage.openContentInANewWindow();
		canvas.modulePage.openButtonToLoadContentInANewWindow();
		canvas.pxPage.verifyPxFnePageOpens();
		//canvas.pxPage.expandPXChapter(chaptername);
		canvas.pxPage.deleteContent(contentName);
		canvas.pxPage.userClosesPXWindowAndGoToPrimaryWindow();
	}
	
	@Test(dependsOnMethods = "Step09_Open_Deployed_Content_And_Delete_That_Content_In_PX_Side")
	public void Step10_Open_Deleted_Content_And_Verify_Broken_Link_Error_Message(){
		canvas.coursePage.goToModulePage();
		canvas.modulePage.verifyModulePageOpens();
		canvas.modulePage.clickOnContentPresentInTheModule();
		canvas.modulePage.openButtonToLoadContentInANewWindow();
		canvas.pxPage.verifyBrokenLinkErrorMessage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	
	@Test(dependsOnMethods = { "Step10_Open_Deleted_Content_And_Verify_Broken_Link_Error_Message" })
	public void Step11_Dissociate_Course() {
		external_Tool   = getData("external_tool");
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickToolLink("lnk_Unlink_Macmillan_Course");
		canvas.provisionPage.disAssociateCourse();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	
	@Test(dependsOnMethods = "Step11_Dissociate_Course")
	public void Step12_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() throws IOException {
		canvas.closeBrowserSession();
	}
*/}
