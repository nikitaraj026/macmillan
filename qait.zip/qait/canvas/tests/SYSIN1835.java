package com.qait.canvas.tests;

//The Instructor gets mapped (via rich content editor flow) within the 
//Macmillan Middle ware (RA ID, LMS ID and LMS Installation course association
//Info) if necessary, in order to be presented with the Course Listing page.

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1835 extends Parent_Test {
/*
	CanvasTestSessionInitiator canvas;
	
	private Long timeStamp = System.currentTimeMillis();
	private String nonAssociatedCourseName;
	private String adminUserName, adminPassword;
	private String instructor;
	private String emailInstructor;
	private String firstName, lastName, registerPassword;

	private void _initVars() {
		adminUserName = getData("users.admin.user_name"); 
		adminPassword = getData("users.admin.password");
		nonAssociatedCourseName = getData("course.nonAssociated1");
		instructor = "AutoInst_" + timeStamp;
		emailInstructor = instructor + "@fake123.com";
		firstName = "FName";
		lastName = "LName";
		registerPassword = getData("users.instructor.registerPassword");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(adminUserName, adminPassword);
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step02_Log_In_As_Admin"})
	public void Step03_Navigate_To_Account_Create_A_New_Instructor_And_Enroll_Into_Course() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
		canvas.dashboardPage.createUser(instructor, emailInstructor);
		canvas.dashboardPage.enterIntoCourse(nonAssociatedCourseName);
		canvas.dashboardPage.addPeople("Teacher", emailInstructor);
		canvas.dashboardPage.createLoginInfoForUser(instructor, "123456");
	}
	
	@Test(dependsOnMethods={"Step03_Navigate_To_Account_Create_A_New_Instructor_And_Enroll_Into_Course"})
	public void Step04_User_Log_Out() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step04_User_Log_Out"})
	public void Step05_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor,
				getData("users.instructor.password"));
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
		canvas.dashboardPage.acceptInvite();
	}

	@Test(dependsOnMethods = { "Step05_Log_In_As_Instructor" })
	public void Step06_Go_To_Course_Page() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(nonAssociatedCourseName);
		canvas.coursePage.verifyUserIsOnCoursePage(nonAssociatedCourseName);
	}

	@Test(dependsOnMethods = { "Step06_Go_To_Course_Page" })
	public void Step07_Go_To_Discussion_Page(){
		canvas.coursePage.goToDiscussionsPage();
		canvas.discussionPage.verifyDiscussionPageOpens();
	}

	@Test(dependsOnMethods = { "Step07_Go_To_Discussion_Page" })
	public void Step08_Go_To_ProvisionOrCourseIntegrationViaRichContentEditorPage() {
		canvas.discussionPage.clickOnAddDiscussionButton();
		canvas.discussionPage.clickOnIconMoreExternalTools();
		canvas.discussionPage.clickHere();
	}
	
	@Test(dependsOnMethods = { "Step08_Go_To_ProvisionOrCourseIntegrationViaRichContentEditorPage" })
	public void Step09_Pass_Mars_And_Eula_Page() {
		canvas.raPage.passEULAPage();
	}
	
	@Test(dependsOnMethods = { "Step09_Pass_Mars_And_Eula_Page"})
	public void Step10_Pass_Registration_Page() {
		canvas.raPage.passRegistrationPage(firstName, lastName, registerPassword);
	}
	
	@Test(dependsOnMethods = { "Step10_Pass_Registration_Page"})
	public void Step11_Verify_User_lands_On_Provision_Page() {
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.userClosesCurrentPageAndNavigatesToBasePage();
		canvas.discussionPage.closeContentToc();
	}

	@Test(dependsOnMethods = {"Step11_Verify_User_lands_On_Provision_Page"})
	public void Step12_User_Log_Out() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
	*/
}