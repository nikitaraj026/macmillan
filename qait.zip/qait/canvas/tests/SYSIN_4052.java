package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class SYSIN_4052 extends Parent_Test{

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();
	
	private String courseName;
	private String instructor, emailInstructor, instructorName;
	private String studentLogin, emailStudent;
	private String password, inst_password, px_password;
	private String quizTitle2;

	private void _initVars() {
		Long timeStamp = System.currentTimeMillis();
		instructorName = "test";
		
		//LT Details
		instructor = "test.instructor1.feb2017";
		emailInstructor = instructor + "@fake123.com";
		courseName = "SYSIN_4052";
		
		//DEV Details
//		instructor = "canvas.inst1.dev.220118";
//		emailInstructor = instructor + "@fake123.com";
//		courseName = "SYSIN4052_DEV";
		
		//QA Details
//		instructor = "sanityqainst_canvas";
//		emailInstructor = instructor + "@fake123.com";
//		courseName = "SYSIN4052_QA";
		
		studentLogin = "teststud" + timeStamp;
		emailStudent = studentLogin + "@fake123.com";
		inst_password = "12345678";
		password = "12345678";
		px_password = "Password1!";
		quizTitle2 = "Manual_Quiz";
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Launch_Application"})
	public void Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		canvas.dashboardPage.verifyDashboardPage();
	}
	
	@Test(dependsOnMethods={"Log_In_As_Admin"})
	public void Go_To_Macmillan2_Courses() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
	}

	@Test (dependsOnMethods={"Go_To_Macmillan2_Courses"})
	public void Verify_Add_New_User_Modal_Window() {
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.verifyAddNewUserModalWindow();
	}
	
	@Test(dependsOnMethods={"Verify_Add_New_User_Modal_Window"})
	public void Admin_Create_Student() {
		
		canvas.macmillan2Page.createUser(studentLogin, emailStudent);
	}
	
	@Test(dependsOnMethods={"Admin_Create_Student"})
	public void Admin_Redirects_To_Newly_Created_Course() {
		
		canvas.macmillan2Page.enterIntoCourse(courseName);
	}
	
	@Test(dependsOnMethods={"Admin_Redirects_To_Newly_Created_Course"})
	public void Publish_Course() {
		
		//canvas.coursePage.publishCourse();
	}
	
	@Test(dependsOnMethods={"Publish_Course"})
	public void Admin_Redirects_To_People_Page() {
		
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
	}
	
	@Test(dependsOnMethods= {"Admin_Redirects_To_People_Page"})
	public void Verify_Add_People_Modal_Window() {
		
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.verifyAddPeopleModalWindow();
	}
	
	@Test(dependsOnMethods= {"Verify_Add_People_Modal_Window"})
	public void Verify_User_Information() {
		
		canvas.coursePage.enterUserDetails("Student", emailStudent);
		canvas.coursePage.clickOnAddUserButton();
	}
	
	@Test(dependsOnMethods={"Verify_User_Information"})
	public void Admin_Add_Login_For_Student() {
		
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnUserNameLink(studentLogin);
		canvas.coursePage.verifyUserDetailPage(studentLogin);
		canvas.coursePage.clickOnMoreUserDetails();
		canvas.coursePage.verifyMembershipLoginInformationSection();
		canvas.coursePage.clickOnAddLoginLink();
		canvas.coursePage.verifyAddLoginModalWindow();
		canvas.coursePage.enterLoginDetails(studentLogin, password);
		canvas.coursePage.clickOnAddLoginButton();
		canvas.coursePage.verifyUserLogin(studentLogin);
	}
	
	@Test(dependsOnMethods={"Admin_Add_Login_For_Student"})
	public void Admin_Log_Out_Canvas_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Admin_Log_Out_Canvas_Application"})
	public void Log_In_As_Student() {
		
		canvas.loginPage.loginToTheApplication(studentLogin, password);
	}
	
	@Test(dependsOnMethods= "Log_In_As_Student")
	public void Student_Logout_Of_Application() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}
	
	@Test(dependsOnMethods="Student_Logout_Of_Application")
	public void Student_Go_To_Dashboard_Page() {
		canvas.loginPage.loginToTheApplication(studentLogin, password);
		canvas.dashboardPage.acceptTermsOfUse(); 
		canvas.dashboardPage.verifyDashboardPage();
	}
	
	@Test(dependsOnMethods= "Student_Go_To_Dashboard_Page")
	public void Student_Go_To_Course_Page() {
		canvas.dashboardPage.acceptInvite();
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}
	
	@Test(dependsOnMethods= "Student_Go_To_Course_Page")
	public void Student_Attempt_Assignment() {
		canvas.toolsPage.runHandleSecurityExe();
		canvas.coursePage.clickAssignmentsOnCoursePage();
		canvas.coursePage.clickOnAssignmentLink(quizTitle2);
	}
	
	
	@Test(dependsOnMethods={"Student_Attempt_Assignment"})
	public void Verify_Student_Complete_SSO() {
		canvas.onboardingPage.newMWStudent(emailStudent);
		canvas.onboardingPage.verifyEulaContentDisplayed();
		canvas.onboardingPage.agreeLegalTerms();
		canvas.onboardingPage.verifyTitle("Register");
		canvas.onboardingPage.fillFirstNameLastNameAndPassword("fname", "lname", px_password);
		canvas.onboardingPage.fillConfirmEmailAndPassword(emailStudent, px_password);
		canvas.onboardingPage.clickRegister();
		canvas.studentAccessGrantPage.clickRequestFreeTrial();
		canvas.studentAccessGrantPage.clickContinueToSite();
		canvas.pxPage.userNavigateToPxWindow();
	}
	
	
	@Test(dependsOnMethods={"Verify_Student_Complete_SSO"})
	public void Student_Attempt_Manual_Quiz(){
		
		canvas.fnePage.verifyStudentIsOnQuizStartPage();
		canvas.fnePage.attemptQuizCorrectly("intuition.");
		canvas.fnePage.clickDoneButton();
		canvas.fnePage.clickOnHomeButton();
	}
	
	@Test(dependsOnMethods = "Student_Attempt_Manual_Quiz")
	public void Student_Logout_LaunchPad(){
		
		canvas.pxPage.launchPadLogout();
	}
	
	@Test(dependsOnMethods = "Student_Logout_LaunchPad")
	public void Student_Logout_Canvas(){
		
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}