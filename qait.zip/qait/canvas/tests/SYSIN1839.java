package com.qait.canvas.tests;

//The middle ware verifies the Instructor's Role and their RA privileges during single sign on content launch (rich content editor flow) in order to pass them through to the product, redirect them to RA or redirect them to iLogin.

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1839 extends Parent_Test{
/*
	CanvasTestSessionInitiator canvas;
	
	private Long timeStamp = System.currentTimeMillis();
	private String subAccountEnv = "";
	private String courseName = "";
	private String emailRAPassedUser = "";
	private String instructor = "Auto" + "Inst" + timeStamp;
	private String emailInstructor = instructor + "@fake123.com";

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step02_Log_In_As_Admin"})
	public void Step03_Navigate_To_Account_Create_A_New_Instructor_And_Enroll_Into_Course() {
		subAccountEnv = getData("SubAccountEnv");
		courseName = getData("notassociated_courseName");
		
		canvas.dashboardPage.goToAccounts();
		canvas.dashboardPage.goToSubAccount();
		canvas.dashboardPage.goToEnvSubAccount(subAccountEnv);
		
		canvas.dashboardPage.createUser(instructor, emailInstructor);
		canvas.dashboardPage.enterIntoCourse(courseName);
		
		canvas.dashboardPage.addPeople("Teacher", emailInstructor);
		canvas.dashboardPage.createLoginInfoForUser(instructor, "123456");
	}	
	
	@Test(dependsOnMethods={"Step03_Navigate_To_Account_Create_A_New_Instructor_And_Enroll_Into_Course"})
	public void Step04_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step04_User_Log_Out"})
	public void Step05_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor,
				getData("users.instructor.password"));
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
		canvas.dashboardPage.acceptInvite();
	}

	@Test(dependsOnMethods = { "Step05_Log_In_As_Instructor" })
	public void Step06_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step06_Go_To_Course_Page" })
	public void Step07_Go_To_Discussion_Page(){
		canvas.coursePage.goToDiscussionsPage();
		canvas.discussionPage.verifyDiscussionPageOpens();
	}

	@Test(dependsOnMethods = { "Step07_Go_To_Discussion_Page" })
	public void Step08_Go_To_ProvisionOrCourseIntegrationViaRichContentEditorPage() {
		canvas.discussionPage.clickOnAddDiscussionButton();
		canvas.discussionPage.clickOnIconMoreExternalTools();
		canvas.discussionPage.clickHere();
	}
	
	@Test(dependsOnMethods = { "Step08_Go_To_ProvisionOrCourseIntegrationViaRichContentEditorPage" })
	public void Step09_Pass_Mars_Page() {
		emailRAPassedUser = getData("users.instructor.non_associated")+"@fake123.com";
		canvas.raPage.checkEmail(emailRAPassedUser);
	}
	
	@Test(dependsOnMethods = { "Step09_Pass_Mars_Page" })
	public void Step10_Provide_Password_So_That_System_Checks_Your_USer_Role() {
		canvas.raPage.providePassword(getData("users.instructor.password"));
	}
	
	@Test(dependsOnMethods = { "Step10_Provide_Password_So_That_System_Checks_Your_USer_Role"})
	public void Step11_Verify_User_lands_On_Provision_Page() {
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.userClosesCurrentPageAndNavigatesToBasePage();
		canvas.discussionPage.closeContentToc();
	}

	@Test(dependsOnMethods = {"Step11_Verify_User_lands_On_Provision_Page"})
	public void Step12_User_Log_Out_Of_The_Application() {
		canvas.discussionPage.LogOut();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
	*/
}