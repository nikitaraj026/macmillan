package com.qait.canvas.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Smoke_Student_Attempt_Assignments extends Parent_Test{
	CanvasTestSessionInitiator canvas;
	long timeStamp = System.currentTimeMillis();
	String courseName, pxPassword;
	String bookTitle;
	String firstStudentUserName;
	
	private void initVars() {
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		firstStudentUserName = canvas.coursePage.readDataFromYaml("FirstStudentLogin");
		
		bookTitle = getData("bookTitle");
		
		String bookIdentifier = "myers";
		pxPassword = canvas.coursePage.readDataFromYaml("PX_Password");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();//		timeStamp = System.currentTimeMillis();
		initVars();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}
	
	
}
