package com.qait.canvas.tests;

import com.qait.automation.utils.Parent_Test;

public class SJSU_Instructorless_Access_To_WritersHelp extends Parent_Test{
/*	
	CanvasTestSessionInitiator canvas;
	
	private String subAccountEnv = "";
	private String courseName="";
	private String student="";
	private String student1="";
	private String student2="";
	private String emailStudent="";
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step02_Log_In_As_Admin"})
	public void Step03_Navigate_To_Account_Create_A_New_Student_And_Enroll_Into_Course() {
		subAccountEnv= getData("SubAccountEnv");
		courseName = getData("notassociated_courseName");
		student1 = canvas.dashboardPage.generateRandomString();
		student2 = canvas.dashboardPage.generateRandomString();
		student = student1+" "+student2;
		emailStudent=student1+student2+"@macmillan.com";
		canvas.dashboardPage.goToAccounts();
		canvas.dashboardPage.goToSubAccount();
		canvas.dashboardPage.goToEnvSubAccount(subAccountEnv);
		canvas.dashboardPage.createUser(student,emailStudent);
		canvas.dashboardPage.enterIntoCourse(courseName);
		canvas.dashboardPage.addPeople("Student", emailStudent);
		canvas.dashboardPage.createLoginInfoForUser(student1, "123456");
	}
	
	@Test(dependsOnMethods={"Step03_Navigate_To_Account_Create_A_New_Student_And_Enrol_Into_Course"})
	public void Step04_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods={"Step04_User_Log_Out"})
	public void Step05_Student_Logs_In() {
		canvas.loginPage.loginToTheApplication(student1, getData("users.student.password"));
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
		canvas.dashboardPage.acceptInvite();
	}
	
	@Test(dependsOnMethods={"Step05_Student_Logs_In"})
	public void Step06_Verify_WritersHelp_Appropriate_Navigation() {
		canvas.coursePage.verifyAppropriateCourseLaunches();
	}
	
	@Test(dependsOnMethods={"Step06_Verify_WritersHelp_Appropriate_Navigation"})
	public void Step07_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}
	*/
}
