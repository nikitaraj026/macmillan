package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class WorkFlow_EnrollUsers_Create_Login extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;
	String courseName = "Cole";
	String exactCourseName = "Canvas Demo Course (NicoleS)";

	private void _initVars() {
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {

		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_User_Navigated_To_Macmillan2_Page() {
		canvas.dashboardPage.verifyAdminDashBoard();
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.verifyAdminOverlay();
		canvas.leftMenu.clickMacmillan2();
		canvas.macmillan2Page.verfiyMacmillan2PageTitle();
	}

	@Test(dependsOnMethods = "Step02_Verify_User_Navigated_To_Macmillan2_Page")
	public void Step03_VerifyFieldsOnMacmillan2Page() {
		canvas.macmillan2Page.verifyUserIsOnMacmillan2Page();
		canvas.macmillan2Page.verifyActiveTab("Courses");
	}

	@Test(dependsOnMethods = "Step03_VerifyFieldsOnMacmillan2Page")
	public void Step04_VerifyHomePageOfSelectedCourse() {
		canvas.macmillan2Page.enterIntoCourse("abcd2");
		canvas.macmillan2Page.verifyHomePageOfSelectedCourse("abcd2");
		canvas.macmillan2Page.verifyLeftTabOfSelectedCourse();
		canvas.macmillan2Page.verifyRightSideContentOfSelectedCourse();
	}

	@Test(dependsOnMethods = "Step04_VerifyHomePageOfSelectedCourse")
	public void Step05_VerifyPeopleLeftTabContentOfCourse() {
		canvas.macmillan2Page.clickLeftTab("People");
		canvas.macmillan2Page.removeUserFromCourse();
		canvas.macmillan2Page.verifyPeopleLeftTabContentOfCourse("abcd2");
		canvas.macmillan2Page.verifyPageContentBeforeAddingUserAccounts();
	}

	@Test(dependsOnMethods = "Step05_VerifyPeopleLeftTabContentOfCourse")
	public void Step06_VerifyAddPeoplePopUpContent() {
		canvas.macmillan2Page.clickOnButtonOfPage("Add People");
		canvas.enrollUsers.verifyAddPeoplePopUpContent();
		canvas.enrollUsers.verifyRoleDropDownOption();
	}

	@Test(dependsOnMethods = "Step06_VerifyAddPeoplePopUpContent")
	public void Step07_VerifyEmailAddressEntryintoTextBox() {
		canvas.enrollUsers.EmailAddressEntryintoTextBox("text@fake.com");
	}

	@Test(dependsOnMethods = "Step06_VerifyAddPeoplePopUpContent")
	public void Step08_VerifyNextAddPeoplePopUpContents() {
		canvas.enrollUsers.EmailAddressEntryintoTextBox("test.isnt1.canav.lt@fake123.com");
		canvas.enrollUsers.selectDropDownValue("Teacher");
		canvas.enrollUsers.clickNextButton();
		canvas.enrollUsers.verifyNextAddPeoplePopUpContents();
	}

	@Test(dependsOnMethods = "Step08_VerifyNextAddPeoplePopUpContents")
	public void Step09_VerifyAddPeoplePopUpAfterClickingStartOver() {
		canvas.enrollUsers.clickButtonOverPopUP("Start Over");
		canvas.enrollUsers.verifyAddPeoplePopUpContent();
	}

	@Test(dependsOnMethods = "Step09_VerifyAddPeoplePopUpAfterClickingStartOver")
	public void Step10_VerifyAddPeoplePopUpAfterClickingStartOver() {
		canvas.enrollUsers.EmailAddressEntryintoTextBox("test.isnt1.canav.lt@fake123.com");
		canvas.enrollUsers.selectDropDownValue("Teacher");
		canvas.enrollUsers.clickNextButton();
		canvas.enrollUsers.verifyNextAddPeoplePopUpContents();
		canvas.enrollUsers.clickButtonOverPopUP("Add Users");
		canvas.macmillan2Page.verifyPeopleLeftTabContentOfCourse("abcd2");
	}

	@Test(dependsOnMethods = "Step10_VerifyAddPeoplePopUpAfterClickingStartOver")
	public void Step11_VerifyUserProfileAfterClickingSelectedUser() {
		canvas.enrollUsers.clickOnAddedUser("Test User Abhinay");
		canvas.enrollUsers.verifyUserProfileAfterClickingSelectedUser();
		canvas.enrollUsers.verifyRightContentOfUserProfilePage();
	}

	@Test(dependsOnMethods = "Step11_VerifyUserProfileAfterClickingSelectedUser")
	public void Step12_VerifyEditLinkPopUpContents() {
		canvas.enrollUsers.clickOnlink("Edit");
		canvas.enrollUsers.verifyEditLinkPopUpContents();
	}

	@Test(dependsOnMethods = "Step12_VerifyEditLinkPopUpContents")
	public void Step13_VerifyUpdateDetailsFunctionality() {
		// canvas.enrollUsers.verifyUpdateDetailsFunctionality();
		canvas.enrollUsers.clickOnCancelButtons("3");
	}

	@Test(dependsOnMethods = "Step13_VerifyUpdateDetailsFunctionality")
	public void Step14_VerifyMergeUserAccountsContents() {
		canvas.enrollUsers.clickOnlink("Merge with Another User");
		canvas.enrollUsers.verifyMergeUserAccountsContents();
	}

	@Test(dependsOnMethods = "Step14_VerifyMergeUserAccountsContents")
	public void Step15_VerifyListOfUsersAfterEnteringValidName() {
		canvas.enrollUsers.verifyListOfUsersAfterEnteringValidName();
		canvas.enrollUsers.selectNameFromNameList("Deepak Daroch");
		canvas.enrollUsers.verifySelectedNameFromNameList();
	}

	@Test(dependsOnMethods = "Step15_VerifyListOfUsersAfterEnteringValidName")
	public void Step16_VerifyMergeWithUserAccountPageContentsAfterClickingSelect() {
		canvas.enrollUsers.clickOnSelectButton();
		canvas.enrollUsers.verifyMergeWithUserAccountsPageContents();
	}

	//@Test(dependsOnMethods = "Step16_VerifyMergeWithUserAccountPageContentsAfterClickingSelect")
	public void Step17_VerifySwitchUsePositions() {
		canvas.enrollUsers.verifySwitchUserPositions();

	}

	@Test(dependsOnMethods = "Step16_VerifyMergeWithUserAccountPageContentsAfterClickingSelect")
	public void Step18_VerifyMergeSomeoneElseWithUserName() {
		canvas.enrollUsers.clickOnMergeSomeoneElseWithUserName("Test User Abhinay");
		canvas.enrollUsers.verifyMergeUserAccountsContents();
	}

	@Test(dependsOnMethods = "Step18_VerifyMergeSomeoneElseWithUserName")
	public void Step19_VerifyPrepareToMergeUserContents() {
		canvas.enrollUsers.goBackToPreviousPage();
		canvas.enrollUsers.clickOnPrepareToMergeUsersLink();
		canvas.enrollUsers.verifyPrepareToMergeUserContents();
	}
	@Test(dependsOnMethods = "Step19_VerifyPrepareToMergeUserContents")
	public void Step20_VerifyCancelButtonFunctionalityOnPrepareToMergeUserContents() {
		canvas.enrollUsers.clickOnCancelButtons("1");
		canvas.dashboardPage.verifyDashboardPage();
	}
	@Test(dependsOnMethods = "Step20_VerifyCancelButtonFunctionalityOnPrepareToMergeUserContents")
	public void Step21_VerifySuccessFullMessageAfterMergeUserAccounts() {
		canvas.enrollUsers.goBackToPreviousPage();
		canvas.enrollUsers.clickOnMergeUserAccountsButton();
		canvas.dashboardPage.verifyMessageSuccessFullMessageAfterMergeUserAccounts();
	}
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}
