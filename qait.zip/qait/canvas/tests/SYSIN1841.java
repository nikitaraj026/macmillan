package com.qait.canvas.tests;

//The student user is mapped (via Getting Started flow) with the Macmillan Middle ware (RA ID, LMS ID and LMS Installation course assoc Info) if necessary, in order to validate the user within Macmillan's RA system and show the correct confirm message.

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1841 extends Parent_Test{
/*
	CanvasTestSessionInitiator canvas;
	
	private Long timeStamp = System.currentTimeMillis();
	private String subAccountEnv = "";
	private String courseName = "";
	private String external_Tool = "";
	private String student = "Auto" + "S" + timeStamp;
	private String emailStudent = student + "@fake123.com";

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step02_Log_In_As_Admin"})
	public void Step03_Navigate_To_Account_Create_A_New_Student_And_Enrol_Into_Course() {
		subAccountEnv = getData("SubAccountEnv");
		courseName = getData("notassociated_courseName");
		canvas.dashboardPage.goToAccounts();
		canvas.dashboardPage.goToSubAccount();
		canvas.dashboardPage.goToEnvSubAccount(subAccountEnv);

		canvas.dashboardPage.createUser(student,emailStudent);
		canvas.dashboardPage.enterIntoCourse(courseName);

		canvas.dashboardPage.addPeople("Student", emailStudent);
		canvas.dashboardPage.createLoginInfoForUser(student, "123456");
	}
	
	@Test(dependsOnMethods={"Step03_Navigate_To_Account_Create_A_New_Student_And_Enrol_Into_Course"})
	public void Step04_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step04_User_Log_Out"})
	public void Step05_Student_Logs_In() {
		canvas.loginPage.loginToTheApplication(student, getData("users.student.password"));
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step05_Student_Logs_In"})
	public void Step06_Accept_Invitation() {
		canvas.dashboardPage.acceptInvite();
	}
	
	@Test(dependsOnMethods = { "Step06_Accept_Invitation" })
	public void Step07_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step07_Go_To_Course_Page" })
	public void Step08_Go_To_Tools_Tab() {
		external_Tool   = getData("external_tool");
		canvas.coursePage.enterIntoToolsSection(external_Tool);
	}
	
	@Test(dependsOnMethods = { "Step08_Go_To_Tools_Tab" })
	public void Step09_Getting_Started() {
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickToolLink("lnk_GettingStarted");
	}
	
	@Test(dependsOnMethods = { "Step09_Getting_Started" })
	public void Step10_Pass_Mars_And_Eula_Page() {
		canvas.raPage.checkEmail(emailStudent);
	}
	
	@Test(dependsOnMethods = { "Step10_Pass_Mars_And_Eula_Page"})
	public void Step11_Pass_Registration_Page() {
		canvas.raPage.verifyRegistrationPageOpens();
		canvas.raPage.passRegistrationPage();
	}
	
	@Test(dependsOnMethods = { "Step11_Pass_Registration_Page"})
	public void Step12_Verify_Message() {
		canvas.raPage.userClosesCurrentWindowAndGoToBaseWindow();
	}
	
	@Test(dependsOnMethods = { "Step12_Verify_Message" })
	public void Step13_User_Log_Out_Of_The_Application() {
		canvas.modulePage.logOut();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
*/	
}