package com.qait.canvas.tests;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.qait.automation.utils.YamlReader.getData;

/**
 * Created by vijaykumar on 7/21/2017.
 */
public class Sanity_Student_Flow extends Parent_Test{
    CanvasTestSessionInitiator canvas;
    Map<String, Object> data = new HashMap<String, Object>();

    private String courseName = "";
    private String instructorUserName;
    private String secondStudent, emailSecondStudent;
    private String studentFirstName, studentLastName;
    private String external_Tool;
    private String password, px_password, inst_password;
    private String quizTitle1, quizTitle2, quiz1CorrectAnswer1, quiz2CorrectAnswer1, quiz1Grade, quiz2Grade;;
    private String accessCode;
    private String chapterName, chapterIntroduction;

    @BeforeClass
    public void Start_Test_Session() {
        canvas = new CanvasTestSessionInitiator();
        _initVars();
        String bookIdentifier = "myers";
        getData(bookIdentifier + ".author");
        studentFirstName = "FirstNameTwo";
        studentLastName = "LastNameTwo";
        px_password = "Password1!";
    }

    private void _initVars() {
        courseName = canvas.coursePage.readDataFromYaml("CourseName");
        instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
        secondStudent = canvas.coursePage.readDataFromYaml("FirstStudent");
        emailSecondStudent = canvas.coursePage.readDataFromYaml("EmailFirstStudent");
        password = canvas.coursePage.readDataFromYaml("Password");
        inst_password = canvas.coursePage.readDataFromYaml("inst_password");
        external_Tool = getData("external_tool");
        px_password = "Password1!";
        String bookIdentifier = "myers";
        quizTitle1 = getData(bookIdentifier + ".quiz1.name");
        quiz1CorrectAnswer1 = getData(bookIdentifier + ".quiz1.correctAnswer1");
        quiz1Grade = getData(bookIdentifier + ".quiz1.grade");
        quizTitle2 = getData(bookIdentifier + ".quiz2.name");
        quiz2CorrectAnswer1 = getData(bookIdentifier + ".quiz2.correctAnswer1");
        quiz2Grade = getData(bookIdentifier + ".quiz2.grade");
        chapterName = getData(bookIdentifier + ".TOC_chapter5");
        chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
        getData(bookIdentifier + ".TOC_chapter5_content1");
        getData(bookIdentifier + ".TOC_chapter5_subcontent1");
        accessCode = getData("accessCode");
    }

    @BeforeSuite
    public void deleteExecutionFile() {
        beforeSuiteMethod();
    }

    @BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName());
    }

    @AfterMethod
    public void onFailure(ITestResult result) {
        afterMethod(canvas, result, this.getClass().getName());
    }

    @Test
    public void Launch_Application() {
        canvas.launchApplication();
        canvas.loginPage.verifyLoginPage();
    }

    @Test(dependsOnMethods={"Launch_Application"})
    public void Log_In_As_Student() {
        canvas.loginPage.loginToTheApplication(secondStudent, password);
        canvas.dashboardPage.acceptTermsOfUse();
        canvas.dashboardPage.verifyDashboardPage();
    }

    @Test(dependsOnMethods = "Log_In_As_Student")
    public void Verify_Student_Register_In_LP() {
        canvas.dashboardPage.acceptInvite();
        canvas.coursePage.verifyUserIsOnCoursePage(courseName);
        canvas.toolsPage.runHandleSecurityExe();
        canvas.coursePage.clickAssignmentsOnCoursePage();
        canvas.coursePage.clickOnAssignmentLink(quizTitle1);

        canvas.onboardingPage.newMWStudent(emailSecondStudent);
        canvas.onboardingPage.verifyEulaContentDisplayed();
        canvas.onboardingPage.agreeLegalTerms();
        canvas.onboardingPage.verifyTitle("Register");
        canvas.onboardingPage.fillFirstNameLastNameAndPassword(studentFirstName, studentLastName, px_password);
        canvas.onboardingPage.fillConfirmEmailAndPassword(emailSecondStudent, px_password);
        canvas.onboardingPage.clickRegister();
    }

    @Test(dependsOnMethods = "Verify_Student_Register_In_LP")
    public void Verify_Student_Complete_SSO_And_Select_Option_Request_Free_Trail() {
        canvas.studentAccessGrantPage.clickRequestFreeTrial();
        canvas.studentAccessGrantPage.clickContinueToSite();
        canvas.pxPage.userNavigateToPxWindow();
    }


    @Test(dependsOnMethods = "Verify_Student_Complete_SSO_And_Select_Option_Request_Free_Trail")
    public void Verify_Student_Attemp_Assignment_And_Grades_Reflect_In_LMS() {
        canvas.fnePage.verifyStudentIsOnQuizStartPage();
        canvas.fnePage.attemptQuizCorrectly(quiz1CorrectAnswer1);
        canvas.fnePage.clickDoneButton();
        canvas.fnePage.clickOnHomeButton();

        canvas.pxPage.clickAssignedTOCItem(chapterName);
        canvas.pxPage.clickAssignedTOCItem(chapterIntroduction);
        canvas.fnePage.clickOnHomeButton();

        canvas.pxPage.launchPadLogout();

        canvas.leftMenu.logout();
        canvas.loginPage.verifyLoginPage();

        canvas.loginPage.loginToTheApplication(instructorUserName, inst_password);
        canvas.dashboardPage.verifyDashboardPage();

        canvas.leftMenu.goToUserCourse(courseName);
        canvas.coursePage.verifyUserIsOnCoursePage(courseName);

        canvas.leftMenu.goToUserCourse(courseName);
        canvas.coursePage.verifyUserIsOnCoursePage(courseName);
        canvas.coursePage.enterIntoToolsSection(external_Tool);
        canvas.toolsPage.clickOnMacmillanGradeRefreshLink();
        canvas.toolsPage.verifyGradeRefreshPage();
        canvas.toolsPage.clickSelectedButtonOnMacmillanHigherEducationGradeSyncRefresh();
        canvas.toolsPage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle1);
        canvas.toolsPage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(chapterIntroduction);
        canvas.toolsPage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
        canvas.coursePage.clickGradesOnCoursePage();
        canvas.coursePage.verifyGradesInCanvasGradebook(secondStudent, quizTitle1, quiz1Grade);
        canvas.leftMenu.logout();
        canvas.loginPage.verifyLoginPage();
    }

    @AfterClass(alwaysRun = true)
    public void Stop_Test_Session() {
        canvas.closeBrowserSession();
    }

}
