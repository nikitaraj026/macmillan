package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Workflow_Admin_Dashboard_Test extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;

	private void _initVars() {
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {
		
		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		//canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_Admin_Is_On_Dashboard(){
		canvas.dashboardPage.verifyAdminDashBoard();
	}

	@Test(dependsOnMethods = "Step02_Verify_Admin_Is_On_Dashboard")
	public void Step03_Verify_Admin_Is_On_Dashboard(){
		canvas.dashboardPage.clickOnCanvasLogo();
		canvas.dashboardPage.verifyAdminDashBoard();
	}
	
	@Test(dependsOnMethods = "Step03_Verify_Admin_Is_On_Dashboard")
	public void Step04_Verify_Left_Menu_AccountPanel(){
		canvas.leftMenu.clickOnAccountLeftMenu();
		canvas.leftMenu.verifyAccountPanel();
	}
	
	@Test(dependsOnMethods = "Step04_Verify_Left_Menu_AccountPanel")
	public void Step05_VerifyAccountPage(){
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
		canvas.accountPage.verifySettingTabTitle();
		canvas.accountPage.verifyUserIsOnAccountPage();
	}
	
	@Test(dependsOnMethods = "Step05_VerifyAccountPage")
	public void Step06_VerifyUserIsNavigatedToNotificationPreferencesPage(){
		canvas.accountPage.clickNotificationsFromLeftPanel();
		canvas.accountPage.verfiyNotificationPageTitle();
	}
	
	@Test(dependsOnMethods = "Step06_VerifyUserIsNavigatedToNotificationPreferencesPage")
	public void Step07_VerifyUserIsNavigatedToFilesPage(){
		canvas.accountPage.clickFilesFromLeftPanel();
		canvas.accountPage.verfiyFilesPageTitle();
	}
	
	@Test(dependsOnMethods = "Step07_VerifyUserIsNavigatedToFilesPage")
	public void Step08_VerifyUserIsNavigatedBackToSettingsTab(){
		canvas.leftMenu.clickOnAccountLeftMenu();
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
		canvas.accountPage.verifySettingTabTitle();
	}
	
	@Test(dependsOnMethods = "Step08_VerifyUserIsNavigatedBackToSettingsTab")
	public void Step09_VerifyUserIsNavigatedToEportfoliosPage(){
		canvas.accountPage.clickFilesFromLeftPanel();
		canvas.accountPage.verfiyFilesPageTitle();
	}
	
	@Test(dependsOnMethods = "Step09_VerifyUserIsNavigatedToEportfoliosPage")
	public void Step10_VerifyUserIsNavigatedToDashboard(){
		canvas.leftMenu.clickLeftMenu("Dashboard");
		canvas.dashboardPage.verifyAdminDashBoard();
	}

	@Test(dependsOnMethods = "Step10_VerifyUserIsNavigatedToDashboard")
	public void Step11_VerifyAdminOverlay(){
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.verifyAdminOverlay();
	}
	
	@Test(dependsOnMethods = "Step11_VerifyAdminOverlay")
	public void Step12_VerifyUserNavigatedToMacmillan2Page(){
		canvas.leftMenu.clickMacmillan2();
		canvas.macmillan2Page.verfiyMacmillan2PageTitle();
	}
	
	@Test(dependsOnMethods = "Step12_VerifyUserNavigatedToMacmillan2Page")
	public void Step13_VerifyFieldsOnMacmillan2Page(){
		canvas.macmillan2Page.verifyUserIsOnMacmillan2Page();
		canvas.macmillan2Page.verifyActiveTab("Courses");
	}
	
	@Test(dependsOnMethods = "Step13_VerifyFieldsOnMacmillan2Page")
	public void Step14_VerifyUserNavigatedToAccountPage(){
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.clickLeftSubmenu("All Accounts");
		canvas.leftMenu.verifyAllAccountsPage();
	}
	
	@Test(dependsOnMethods = "Step14_VerifyUserNavigatedToAccountPage")
	public void Step15_VerifyCoursesOverlay(){
		canvas.leftMenu.clickLeftMenu("Courses");
		canvas.leftMenu.verifyCoursesOverlay();
	}
	
	@Test(dependsOnMethods = "Step15_VerifyCoursesOverlay")
	public void Step16_VerifyAll_Courses_Page(){
		canvas.leftMenu.clickLeftSubmenu("All Courses");
		canvas.leftMenu.verfiyAllCoursesPage();
	}
	
	@Test(dependsOnMethods = "Step16_VerifyAll_Courses_Page")
	public void Step17_VerifyCalendarMenuItem(){
		canvas.leftMenu.clickLeftMenu("Calendar");
		canvas.leftMenu.verifyCalendarPage();
	}
	
	@Test(dependsOnMethods = "Step17_VerifyCalendarMenuItem")
	public void Step18_VerifyInboxMenuItem(){
		canvas.leftMenu.clickLeftMenu("Inbox");
		canvas.leftMenu.verifyInboxPage();
	}
	
	@Test(dependsOnMethods = "Step18_VerifyInboxMenuItem")
	public void Step19_VerifyHelpMenuItem(){
		canvas.leftMenu.clickLeftMenu("Help");
		canvas.leftMenu.verifyHelpOverlay();
	}
	
	@Test(dependsOnMethods={"Step19_VerifyHelpMenuItem"})
	public void Step20_User_Log_Out() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}

}
