package com.qait.canvas.tests;
import static com.qait.automation.utils.YamlReader.getData;
import static com.qait.automation.utils.YamlReader.getYamlValue;
import com.qait.automation.getpageobjects.GetPage;
import static com.qait.automation.utils.SeleniumWait.*;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Wait;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.jayway.restassured.response.Header;
import com.jayway.restassured.response.Headers;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import static com.jayway.restassured.RestAssured.given;
import com.qait.automation.getpageobjects.ObjectFileReader;



public class AllFeaturesApiKeywords {
	RequestSpecification resSpec ,reqSpec;
	static Map<String, String> allCookies;
	static String refID,jsonPayload;
	static String activityId,studentForm,Studtitle;
	Headers headers;
	Header header1, header2, header3, header4, header5, header6, header7, header8;
	static String activityID,CourseKEY;
	Response response ;
	
	@Test
	public void getAuthenticityTokenFromGetCall() {
		Response response = given().contentType("application/x-www-form-urlencoded").when()
				.get("https://macmillan2.instructure.com/login/canvas").then().log().all().extract().response();
		System.out.println(response.getCookie("log_session_id"));
	}
	@Test
	public void loginProcessIntoCanvas() {
		Response response = given().contentType("application/x-www-form-urlencoded").when().body("")
				.post("https://macmillan2.instructure.com/login/canvas").then().statusCode(302).log().all().extract().response();
		System.out.println(response.getCookie("log_session_id"));
	}
	@Test
	public void login()
	{
		String taskName;String desc;String startDate;String endDate;
		taskName="Fixing of Canvas";
		desc="continued the fixing";
		startDate="2018-07-10";
		endDate="2018-07-10";
		Response response = given().contentType("application/x-www-form-urlencoded").when().body("txtUserName=ajitsingh&txtPassword=Mansha%404026&Submit=Sign+In&actionID=chkAuthentication")
				.post("https://hris.qainfotech.com/login.php").then().statusCode(302).log().all().extract().response();
		System.out.println(response);
		String taskString="{\"title\":\"\",\"description\":\"\",\"assign_to\":[\"2759\"],\"task_type_id\":\"1\",\"task_form_id\":\"4\",\"state_id\":\"1\",\"project_id\":\"3566\",\"fields\":[null,null,null,null,[{\"field_id\":\"13\",\"field_value\":\""+taskName+"\"},{\"field_id\":\"14\",\"field_value\":\""+desc+"\"},{\"field_id\":\"15\",\"field_value\":\"11\"},{\"field_id\":\"16\",\"field_value\":\""+startDate+"T18:30:00.000Z\"},{\"field_id\":\"17\",\"field_value\":\""+endDate+"T18:30:00.000Z\"},{\"field_id\":\"18\",\"field_value\":\"1\"}]]}";
		response = given().contentType("application/json").when().body(taskString)
			.post("https://hris.qainfotech.com:8086/api/task").then().statusCode(302).log().all().extract().response();
	    System.out.println(response);
	}
}