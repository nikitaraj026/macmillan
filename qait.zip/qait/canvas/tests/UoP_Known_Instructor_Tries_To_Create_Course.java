package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class UoP_Known_Instructor_Tries_To_Create_Course extends Parent_Test{

	CanvasTestSessionInitiator canvas;
	
	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor;
	private String password;

	private void _initVars() {
		Long timeStamp = System.currentTimeMillis();
		//courseName = "TestCourse_" + timeStamp;
		courseName = getData("UoP.courseName");
		subAccount = getData("subAccount");
		instructor = "inst_uoplt";
		emailInstructor = "inst_uoplt@fake123.com";
		password = "12345678";
		
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Launch_Application"})
	public void Log_In_As_Instructor() {
		
		canvas.loginPage.loginToTheApplication(instructor, password);
		//canvas.dashboardPage.verifyDashboardPage();	
	}
	
	@Test(dependsOnMethods={"Log_In_As_Instructor"})
	public void Accept_Terms_And_Course_Invitation() {
		
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyDashboardPage();
		canvas.dashboardPage.acceptInvite();
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}
	
	@Test(dependsOnMethods={"Accept_Terms_And_Course_Invitation"})
	public void Click_On_Macmillan_Tool_Widget_To_Create_Course_And_Verify_Auto_Course_Provisioning() {
		
		canvas.coursePage.clickMacmillanLearningCreateCourseToolUoP();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.verifyPXCourseHomePage();
		
	}
	
	@Test(dependsOnMethods={"Click_On_Macmillan_Tool_Widget_To_Create_Course_And_Verify_Auto_Course_Provisioning"})
	public void Instructor_Logout_From_LaunchPad_Application() {
		
		canvas.pxPage.launchPadLogout();
	}
		
	@Test(dependsOnMethods={"Instructor_Logout_From_LaunchPad_Application"})
	public void Click_On_Macmillan_Learning_Tools_Widget() {
	
		canvas.coursePage.clickMacmillanLearningToolsWidget();
		canvas.toolsPage.verifyUoPToolsPageForAssociatedCourse();
	}
	
	@Test(dependsOnMethods={"Click_On_Macmillan_Learning_Tools_Widget"})
	public void Verify_Macmillan_Tools() throws InterruptedException {
		
		canvas.toolsPage.clickEbook();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.verifyEbookSectionIsOpen();
		canvas.pxPage.clickOnLPHomeLink();
		canvas.pxPage.launchPadLogout();
		
		canvas.toolsPage.clickGradebook();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.handleGuideModalWindow();
		canvas.pxPage.verifyGradeBookPageOpens();
		canvas.pxPage.clickOnHomeButton();
		canvas.pxPage.launchPadLogout();
		
		canvas.toolsPage.clickOnMacmillanUserProfile();
		canvas.toolsPage.verifyMacmillanUserProfilePage(emailInstructor);
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		
		canvas.toolsPage.clickOnMacmillanTechnicalSupportLink();
		canvas.toolsPage.verifyMacmillanTechnicalSupportPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		
		canvas.toolsPage.clickOnUnlinkMacmillanToolLink();
		canvas.toolsPage.verifyEndCourseAssociationPageUoP();
		canvas.toolsPage.disassociateCourse();
		canvas.toolsPage.verifyEndCourseAssociationPageAfterCourseIsDisassociated();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.verifyNonAssociatedToolsPage("Connect with LaunchPad");
	}

	@Test(dependsOnMethods={"Verify_Macmillan_Tools"})
	public void Admin_Log_Out_Canvas_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}