package com.qait.canvas.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class WorkFlow_Instructor_Tool_Page extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;
	String courseName = "Cole";
	String exactCourseName = "Canvas Demo Course (NicoleS)";
	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	private String pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, school;
	String assignmentName;
	String chapterName, chapterIntroduction, chapterContent;
	String quizTitle1, quizTitle2;
	String chapterNumber, selectQuestionFrom;
	String bookTitle;
    String external_Tool;
    String moduleName;
	 String instructorUserName;
	
	private void _initVars(String book) {
		System.currentTimeMillis();
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
		instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
		instructorEmail = canvas.coursePage.readDataFromYaml("EmailInst");
		instructorName = getData("users.instructor.name1");
		instructorPassword = canvas.coursePage.readDataFromYaml("inst_password");
		instructorPasswordLaunchpad = canvas.coursePage.readDataFromYaml("PX_Password");
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		academicTerm = "Fall 2016";
		external_Tool = getData("external_tool");
		school = "TEST University (New York, NY)";
		String bookIdentifier = null;
		if (book.contains("myers11e")) {
			bookTitle = getData("bookTitleLP");
			bookIdentifier = "myers";
		} else {
			bookTitle = getData("bookTitleWriterHelp");
			bookIdentifier = "lunsford";
		}
		if (bookIdentifier.contains("myers")) {
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
			chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		} else {
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		}
		moduleName = getData("moduleName");
	}
	
	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		_initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {
		
		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.user_name1"),
				getData("users.instructor.password"));
		//canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_Admin_Is_On_Dashboard(){
		canvas.dashboardPage.verifyExistingInstDashboardPage();
	}
	@Test(dependsOnMethods = "Step02_Verify_Admin_Is_On_Dashboard")
	public void Step03_Verify_User_Navigated_To_Macmillan2_Page(){
		canvas.leftMenu.clickLeftMenu("Courses");
		canvas.leftMenu.clickOnUserCourse("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step03_Verify_User_Navigated_To_Macmillan2_Page")
	public void Step04_Verify_AllLinksAfterClickingMacmillanLearningTool(){
		boolean value=canvas.leftMenu.menuIsPresentOrNotAtLeftSide(external_Tool);
		if(value)
		{
		canvas.macmillan2Page.clickLeftTab("Settings");
		canvas.addMacTools.clickOnCourseStatisticsTab("Navigation");
		canvas.coursePage.enableMacmillanTools(external_Tool);
		}
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.runHandleSecurityExe();
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.toolsPage.changeWindow(1);
		canvas.provisionPage.verifyTokenRegistrationPage();
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.createNewCourse(bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName,
				academicTerm, false, "", school);
		canvas.provisionPage.verifyCourseCreated(pxCourseName);
		canvas.provisionPage.associateCourse(pxCourseName);
		canvas.toolsPage.verifyToolsPageAfterCousreAssociation();
		if (bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.toolsPage.clickLaunchPad();
		} else {
			canvas.toolsPage.clickWritesHelp();
		}
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.verifyUserIsOnCourseHomePage(pxCourseName);
		canvas.pxPage.createQuizAssignment("Quiz", quizTitle1, true, "10", "15", true, chapterNumber,
				selectQuestionFrom);
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.clickMacmillanContent();
		canvas.toolsPage.verifyMacmillanContentPage();
        canvas.contentTocPage.ExpandToc("Assignments");
		canvas.contentTocPage.selectContentTOC(quizTitle1);
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.createNewModule(moduleName);
		canvas.contentTocPage.selectModuleAndDeploy(moduleName);
		canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.coursePage.verifyDeployedQuizName("Auto_Quiz");
		canvas.coursePage.verifyModulePresentAndSelectOptionFromSetting("Delete");
	}
	@Test(dependsOnMethods = { "Step04_Verify_AllLinksAfterClickingMacmillanLearningTool" })
	public void Step05_Verify_Ebook_Link() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.clickEbook();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.verifyEbookSectionIsOpen();
		canvas.pxPage.clickOnLPHomeLink();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = { "Step05_Verify_Ebook_Link" })
	public void Step06_Verify_Gradebook_Link() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.clickGradebook();
		canvas.coursePage.userNavigateToPxWindow();
		//canvas.pxPage.handleGuideModalWindow();
		canvas.pxPage.verifyGradeBookPageOpens();
		canvas.pxPage.clickOnHomeButton();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = { "Step06_Verify_Gradebook_Link" })
	public void Step07_Verify_Diagnostics_Page() {
		canvas.toolsPage.clickOnMacmillanDiagnosticsLink();
		canvas.toolsPage.verifyMacmillanDiagnosticsPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = { "Step07_Verify_Diagnostics_Page" })
	public void Step08_Verify_Roster_Page() {
		canvas.toolsPage.clickOnMacmillanRosterLink();
		canvas.toolsPage.verifyMacmillanRosterPage(instructorEmail);
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = { "Step08_Verify_Roster_Page" })
	public void Step09_Verify_Macmillan_Content_Refresh_Page() {
		canvas.toolsPage.clickLaunchPad();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.updateGradeValueOfAssignedTOCItem(quizTitle1, true, "12");
		canvas.pxPage.launchPadLogout();
		canvas.toolsPage.clickOnMacmillanContentRefreshLink();
		canvas.toolsPage.verifyContentRefreshPage(); 
		canvas.toolsPage.selectAssignmentsForProcessing();
		canvas.toolsPage.clickOnRefreshContentButton();
		canvas.toolsPage.clickOnOKButtonOnTaskInProgressPopUp();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.coursePage.clickModulesOnCoursePage();
//		canvas.modulePage.verifyGradesOnModulesPage("12");
		canvas.coursePage.enterIntoToolsSection(external_Tool);
	}
	@Test(dependsOnMethods = { "Step09_Verify_Macmillan_Content_Refresh_Page" })
	public void Step10_Verify_Macmillan_Grade_Refresh_Page() {
		canvas.toolsPage.clickOnMacmillanGradeRefreshLink();
		canvas.toolsPage.verifyGradeRefreshPage();
		canvas.toolsPage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();

	}
	@Test(dependsOnMethods = { "Step10_Verify_Macmillan_Grade_Refresh_Page" })
	public void Step11_Verify_Technical_Support_Page() {
		canvas.toolsPage.clickOnMacmillanTechnicalSupportLink();
		canvas.toolsPage.verifyMacmillanTechnicalSupportPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();

	}
	@Test(dependsOnMethods = { "Step11_Verify_Technical_Support_Page" })
	public void Step12_Verify_User_Profile_Page() throws InterruptedException {
		canvas.toolsPage.clickOnMacmillanUserProfile();
		canvas.toolsPage.verifyMacmillanUserProfilePage(instructorEmail);
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}
