package com.qait.canvas.tests;

//The Instructor gets mapped (via rich content editor flow) within the Macmillan Middle ware (RA ID, LMS ID and LMS Installation course association Info) if necessary, in order to be presented with the Course Listing page.

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN_3714 extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	
	private String subAccountEnv, external_Tool;
	private String courseName, pxCourseName;
	private String instructor, emailInstructor;
	private String password;

	private void _initVars(){
		courseName = "TestCourse_SYSIN_3714";
		pxCourseName = "SYSIN_3714";
		instructor = "smokeinstcanvas_05sep";
		emailInstructor = instructor+"@fake123.com";
		password = "123456";
		external_Tool = getData("external_tool");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods = {"Step01_Launch_Application"})
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor, password);
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods = {"Step02_Log_In_As_Instructor"})
	public void Step03_Navigate_To_Course_Homepage() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
	}
	
	@Test(dependsOnMethods = {"Step03_Navigate_To_Course_Homepage"})
	public void Step04_Instructor_Clicks_On_Getting_Started() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
	}

	@Test(dependsOnMethods = { "Step04_Instructor_Clicks_On_Getting_Started"})
	public void Step05_Instructor_Associates_Existing_Course() {
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.associateCourse(pxCourseName);
		canvas.toolsPage.verifyToolsPage();
	}
	
	@Test(dependsOnMethods = { "Step05_Instructor_Associates_Existing_Course"})
	public void Step05_Disassociate_Course() {
		canvas.toolsPage.clickOnUnlinkMacmillanToolLink();
		canvas.toolsPage.verifyEndCourseAssociationPage();
		canvas.toolsPage.disassociateCourse();
		canvas.toolsPage.verifyEndCourseAssociationPageAfterCourseIsDisassociated();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.verifyNonAssociatedToolsPage("Connect with LaunchPad");
	}
	
	@Test(dependsOnMethods = { "Step05_Disassociate_Course"})
	public void Step05_Instructor_Logout() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
	
}