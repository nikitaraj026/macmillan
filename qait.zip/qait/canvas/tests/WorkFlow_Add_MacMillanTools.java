package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class WorkFlow_Add_MacMillanTools extends Parent_Test{
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;
	String courseName = "Cole";
	String exactCourseName = "Canvas Demo Course (NicoleS)";

	private void _initVars() {
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {
		
		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.user_name1"),
				getData("users.instructor.password"));
		//canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_Admin_Is_On_Dashboard(){
		canvas.dashboardPage.verifyExistingInstDashboardPage();
	}
	@Test(dependsOnMethods = "Step02_Verify_Admin_Is_On_Dashboard")
	public void Step03_Verify_User_Navigated_To_Macmillan2_Page(){
		canvas.leftMenu.clickLeftMenu("Courses");
		canvas.leftMenu.clickOnUserCourse("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step03_Verify_User_Navigated_To_Macmillan2_Page")
	public void Step04_VerifyAnnouncementsContentPage() {
		canvas.macmillan2Page.clickLeftTab("Announcements");
		canvas.macmillan2Page.verifyAnnouncementsContentPage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step04_VerifyAnnouncementsContentPage")
	public void Step05_VerifyAssignmentsContentPage() {
		canvas.macmillan2Page.clickLeftTab("Assignments");
		canvas.macmillan2Page.verifyAssignmentsContentPage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step05_VerifyAssignmentsContentPage")
	public void Step06_VerifyDiscussionsContentPage() {
		canvas.macmillan2Page.clickLeftTab("Discussions");
		canvas.macmillan2Page.verifyDiscussionsContentPage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step06_VerifyDiscussionsContentPage")
	public void Step07_VerifyGradesContentPage() {
		canvas.macmillan2Page.clickLeftTab("Grades");
		canvas.macmillan2Page.verifyGradesContentPage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step07_VerifyGradesContentPage")
	public void Step08_VerifyRedirectCourseHomePage() {
		canvas.macmillan2Page.redirectionAtHomePage();
		canvas.macmillan2Page.verifyRightSideContentOfSelectedCourse();
	}
	//@Test(dependsOnMethods = "Step08_VerifyRedirectCourseHomePage")
	public void Step09_VerifyPeopleLeftTabContentOfCourse() {
		canvas.leftMenu.logout();
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		canvas.dashboardPage.verifyAdminDashBoard();
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.verifyAdminOverlay();
		canvas.leftMenu.clickMacmillan2();
		canvas.macmillan2Page.verfiyMacmillan2PageTitle();
		canvas.leftMenu.clickLeftMenu("Courses");
		canvas.macmillan2Page.enterIntoCourse("Testing Purpose");
		canvas.macmillan2Page.clickLeftTab("People");
		canvas.macmillan2Page.removeUserFromCourse();
		canvas.macmillan2Page.verifyPeopleLeftTabContentOfCourse("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step08_VerifyRedirectCourseHomePage")
	public void Step10_VerifyPageLeftTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Pages");
		canvas.macmillan2Page.verifyPageContentOfCoursePage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step10_VerifyPageLeftTabContentsOfCourse")
	public void Step11_VerifyFileTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Files");
		canvas.macmillan2Page.verifyFilesContentOfCoursePage();
	}
	@Test(dependsOnMethods = "Step11_VerifyFileTabContentsOfCourse")
	public void Step12_VerifySyllabusTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Syllabus");
		canvas.macmillan2Page.verifySyllabusContentOfCoursePage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step12_VerifySyllabusTabContentsOfCourse")
	public void Step13_VerifyOutcomesTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Outcomes");
		canvas.macmillan2Page.verifyOutcomesContentOfCoursePage();
	}
	@Test(dependsOnMethods = "Step13_VerifyOutcomesTabContentsOfCourse")
	public void Step14_VerifyQuizzTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Quizzes");
		canvas.macmillan2Page.verifyQuizzesContentOfCoursePage();
	}
	@Test(dependsOnMethods = "Step14_VerifyQuizzTabContentsOfCourse")
	public void Step15_VerifyModuleTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Modules");
		canvas.macmillan2Page.verifyModulesContentOfCoursePage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step15_VerifyModuleTabContentsOfCourse")
	public void Step16_VerifyConferenceTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Conferences");
		canvas.macmillan2Page.verifyConferencesContentOfCoursePage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step16_VerifyConferenceTabContentsOfCourse")
	public void Step17_VerifyCollaborationTabContentsOfCourse() {	
		canvas.macmillan2Page.clickLeftTab("Collaborations");
		canvas.macmillan2Page.verifyCollaborationsContentOfCoursePage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step17_VerifyCollaborationTabContentsOfCourse")
	public void Step18_VerifySettingTabContentsOfCourse() {	
		canvas.macmillan2Page.clickLeftTab("Settings");
		canvas.macmillan2Page.verifySettingsContentOfCoursePage("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step18_VerifySettingTabContentsOfCourse")
	public void Step19_VerifyStudentViewPageContent() {	
		canvas.macmillan2Page.clickLeftTab("Home");
		canvas.addMacTools.clickOnRightLink("Student View");
		canvas.addMacTools.verifyStudentViewPageContent();
	}
	@Test(dependsOnMethods = "Step19_VerifyStudentViewPageContent")
	public void Step20_VerifyToastMessageAfterClickingResetStudent() {	
//		canvas.addMacTools.clickBottomLinkButton("Reset Student");
//        canvas.addMacTools.verifyToastMessageAfterResetStudent();
	}
	@Test(dependsOnMethods = "Step20_VerifyToastMessageAfterClickingResetStudent")
	public void Step21_VerifyLeaveStudentView() {	
		canvas.addMacTools.clickBottomLinkButton("Leave Student View");
        canvas.macmillan2Page.verifyLeftTabOfSelectedCourse();
	}
	@Test(dependsOnMethods = "Step21_VerifyLeaveStudentView")
	public void Step22_VerifyRedirectionOnCourseDetailsPageAfterClickingSettingTab() {	
		canvas.macmillan2Page.clickLeftTab("Settings");
        canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step22_VerifyRedirectionOnCourseDetailsPageAfterClickingSettingTab")
	public void Step23_VerifyCourseStatisticsContentPage() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Course Statistics");
		canvas.addMacTools.verifyCourseStatisticsContent();
	}
	@Test(dependsOnMethods = "Step23_VerifyCourseStatisticsContentPage")
	public void Step24_VerifyAssignmentsTabOfCourseStatistics() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("Assignments");
		canvas.addMacTools.verifyAssignmentsTabOfCourseStatistics("Assignments Usage Report");
	}
	@Test(dependsOnMethods = "Step24_VerifyAssignmentsTabOfCourseStatistics")
	public void Step25_VerifyStudentsTabOfCourseStatistics() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("Students");
		canvas.addMacTools.verifyAssignmentsTabOfCourseStatistics("Recently Logged-In Users");
	}
	@Test(dependsOnMethods = "Step25_VerifyStudentsTabOfCourseStatistics")
	public void Step26_VerifyFileStorageTabOfCourseStatistics() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("File Storage");
		canvas.addMacTools.verifyAssignmentsTabOfCourseStatistics("File Storage");
	}
	@Test(dependsOnMethods = "Step26_VerifyFileStorageTabOfCourseStatistics")
	public void Step27_VerifyRedirectionOnCourseDetailsPageAfterClickingSettingTab() {	
		canvas.macmillan2Page.clickLeftTab("Settings");
        canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step27_VerifyRedirectionOnCourseDetailsPageAfterClickingSettingTab")
	public void Step28_VerifyCourseCalenderContentPage() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Course Calendar");
        canvas.addMacTools.verifyCourseCalenderContentPage();
	}
	@Test(dependsOnMethods = "Step28_VerifyCourseCalenderContentPage")
	public void Step29_VerifyRedirectionOnCourseDetailsPage() {	
		canvas.leftMenu.clickLeftMenu("Courses");
		canvas.addMacTools.clickNavMenuItem("Testing Purpose");
		canvas.macmillan2Page.clickLeftTab("Settings");
        canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step29_VerifyRedirectionOnCourseDetailsPage")
	public void Step30_VerifyDeleteTheCoursePage() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Delete this Course");
        canvas.addMacTools.verifyDeleteTheCoursePage();
	}
	@Test(dependsOnMethods = "Step30_VerifyDeleteTheCoursePage")
	public void Step31_VerifyCancelButtonFunctionality() {	
		canvas.addMacTools.clickOnGivenText("Cancel");
		canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step31_VerifyCancelButtonFunctionality")
	public void Step32_VerifyCopyCoursePageContent() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Copy this Course");
		canvas.addMacTools.verifyCopyCoursePageContent();
	}
	@Test(dependsOnMethods = "Step32_VerifyCopyCoursePageContent")
	public void Step33_VerifyCancelButtonFunctionality() {	
		canvas.addMacTools.clickOnGivenText("Cancel");
		canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step33_VerifyCancelButtonFunctionality")
	public void Step34_VerifyImportCourseContentPageContent() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Import Course Content");
		canvas.addMacTools.verifyImportCourseContentPageContent();
	}
	@Test(dependsOnMethods = "Step34_VerifyImportCourseContentPageContent")
	public void Step35_VerifyRedirectionOnCourseDetailsPage() {	
		canvas.macmillan2Page.clickLeftTab("Settings");
        canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step35_VerifyRedirectionOnCourseDetailsPage")
	public void Step36_VerifyExportCourseContentPageContent() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Export Course Content");
		canvas.addMacTools.verifyExportCourseContentPageContent();
	}
	@Test(dependsOnMethods = "Step36_VerifyExportCourseContentPageContent")
	public void Step37_VerifyRedirectionOnCourseDetailsPage() {	
		canvas.macmillan2Page.clickLeftTab("Settings");
        canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step37_VerifyRedirectionOnCourseDetailsPage")
	public void Step38_VerifyResetCourseContentPage() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Reset Course Content");
		canvas.addMacTools.verifyResetCourseContentPage();
	}
	@Test(dependsOnMethods = "Step38_VerifyResetCourseContentPage")
	public void Step39_VerifyCancelButtonFunctionality() {	
		canvas.addMacTools.clickOnCancelButtonOverPopUp();
	    canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step39_VerifyCancelButtonFunctionality")
	public void Step40_VerifyValidateLinksinContentPage() {	
		canvas.addMacTools.clickOnRightLinkOfCourseDetails("Validate Links in Content");
	    canvas.addMacTools.verifyValidateLinksinContentPage();
	}
	@Test(dependsOnMethods = "Step40_VerifyValidateLinksinContentPage")
	public void Step41_VerifyRedirectionOnCourseDetailsPage() {	
		canvas.macmillan2Page.clickLeftTab("Settings");
        canvas.addMacTools.verifyCourseDetailsPage();
	}
	@Test(dependsOnMethods = "Step41_VerifyRedirectionOnCourseDetailsPage")
	public void Step42_VerifySectionTabContent() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("Sections");
        canvas.addMacTools.verifySectionTabContent();
	}
	@Test(dependsOnMethods = "Step42_VerifySectionTabContent")
	public void Step43_VerifyAppsTabContent() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("Apps");
        canvas.addMacTools.verifyAppsTabContent();
	}
	@Test(dependsOnMethods = "Step43_VerifyAppsTabContent")
	public void Step44_VerifyFeatureOptionsTabContent() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("Feature Options");
        canvas.addMacTools.verifyFeatureOptionsTabContent();
	}
	@Test(dependsOnMethods = "Step44_VerifyFeatureOptionsTabContent")
	public void Step45_VerifyNavigationTabContent() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("Navigation");
        canvas.addMacTools.verifyNavigationTabContent();
	}
	@Test(dependsOnMethods = "Step45_VerifyNavigationTabContent")
	public void Step46_VerifyMoveModalPopupContent() {	
		canvas.addMacTools.clickOnCourseStatisticsTab("Section");
        canvas.addMacTools.clickOnIconMoreOptions("Move");
        canvas.addMacTools.verifyMoveModalPopupContent();
	}
	//@Test(dependsOnMethods = "Step46_VerifyMoveModalPopupContent")
	public void Step47_VerifyAfterOptionFunctionalityFromDropDown() {	
		canvas.addMacTools.selectDropDownOption("After");
		canvas.addMacTools.selectDropDownOption("Announcements");
		canvas.addMacTools.clickMoveButtonOption();
		canvas.addMacTools.verifyAfterOptionFunctionalityFromDropDown();
	}
	@Test(dependsOnMethods = "Step46_VerifyMoveModalPopupContent")
	public void Step48_VerifyCancelButtonFunctionalityOfMoveModalPopup() {	
		canvas.addMacTools.verifyCancelButtonFunctionalityOfMoveModalPopup();
	}
	@Test(dependsOnMethods = "Step48_VerifyCancelButtonFunctionalityOfMoveModalPopup")
	public void Step49_VerifyEnableFunctionalityOFIconMoreSettingsButton() {	
		int size=canvas.addMacTools.countOfEnabledMenu();
		System.out.println("size : "+size);
		canvas.addMacTools.clickEnableButton("Macmillan Learning");
		canvas.addMacTools.verifyEnableFunctionalityOFIconMoreSettingsButton(size);
	}
	@Test(dependsOnMethods = "Step49_VerifyEnableFunctionalityOFIconMoreSettingsButton")
	public void Step50_DisableTools() {	
		canvas.addMacTools.clickDisableButton("Macmillan Learning");
	}
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		//canvas.closeBrowserSession();
	}
}

