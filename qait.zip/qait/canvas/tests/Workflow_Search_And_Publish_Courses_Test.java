package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Workflow_Search_And_Publish_Courses_Test extends Parent_Test{
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;
	String courseName = "Cole";
	String exactCourseName = "Canvas Demo Course (NicoleS)";

	private void _initVars() {
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {

		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_User_Navigated_To_Macmillan2_Page() {
		canvas.dashboardPage.verifyAdminDashBoard();
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.verifyAdminOverlay();
		canvas.leftMenu.clickMacmillan2();
		canvas.macmillan2Page.verfiyMacmillan2PageTitle();
	}

	@Test(dependsOnMethods = "Step02_Verify_User_Navigated_To_Macmillan2_Page")
	public void Step03_VerifyFieldsOnMacmillan2Page() {
		canvas.macmillan2Page.verifyUserIsOnMacmillan2Page();
		canvas.macmillan2Page.verifyActiveTab("Courses");
	}
	@Test(dependsOnMethods = "Step03_VerifyFieldsOnMacmillan2Page")
	public void Step04_VerifyHomePageOfSelectedCourse() {
		canvas.macmillan2Page.enterIntoCourse("abcd2");
		canvas.macmillan2Page.verifyHomePageOfSelectedCourse("abcd2");
		canvas.macmillan2Page.verifyLeftTabOfSelectedCourse();
		canvas.macmillan2Page.verifyRightSideContentOfSelectedCourse();
	}
	@Test(dependsOnMethods = "Step04_VerifyHomePageOfSelectedCourse")
	public void Step05_VerifyAnnouncementsContentPage() {
		canvas.macmillan2Page.clickLeftTab("Announcements");
		canvas.macmillan2Page.verifyAnnouncementsContentPage("abcd2");
	}
	@Test(dependsOnMethods = "Step05_VerifyAnnouncementsContentPage")
	public void Step06_VerifyAssignmentsContentPage() {
		canvas.macmillan2Page.clickLeftTab("Assignments");
		canvas.macmillan2Page.verifyAssignmentsContentPage("abcd2");
	}
	@Test(dependsOnMethods = "Step06_VerifyAssignmentsContentPage")
	public void Step07_VerifyDiscussionsContentPage() {
		canvas.macmillan2Page.clickLeftTab("Discussions");
		canvas.macmillan2Page.verifyDiscussionsContentPage("abcd2");
	}
	@Test(dependsOnMethods = "Step07_VerifyDiscussionsContentPage")
	public void Step08_VerifyGradesContentPage() {
		canvas.macmillan2Page.clickLeftTab("Grades");
		canvas.macmillan2Page.verifyGradesContentPage("abcd2");
	}
	@Test(dependsOnMethods = "Step08_VerifyGradesContentPage")
	public void Step09_VerifyRedirectCourseHomePage() {
		canvas.macmillan2Page.redirectionAtHomePage();
		canvas.macmillan2Page.verifyRightSideContentOfSelectedCourse();
	}
	@Test(dependsOnMethods = "Step09_VerifyRedirectCourseHomePage")
	public void Step10_VerifyPeopleLeftTabContentOfCourse() {
		canvas.macmillan2Page.clickLeftTab("People");
		canvas.macmillan2Page.removeUserFromCourse();
		canvas.macmillan2Page.verifyPeopleLeftTabContentOfCourse("abcd2");
	}
	@Test(dependsOnMethods = "Step10_VerifyPeopleLeftTabContentOfCourse")
	public void Step11_VerifyPageLeftTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Pages");
		canvas.macmillan2Page.verifyPageContentOfCoursePage("abcd2");
	}
	@Test(dependsOnMethods = "Step11_VerifyPageLeftTabContentsOfCourse")
	public void Step12_VerifyFileTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Files");
		canvas.macmillan2Page.verifyFilesContentOfCoursePage();
	}
	@Test(dependsOnMethods = "Step12_VerifyFileTabContentsOfCourse")
	public void Step13_VerifySyllabusTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Syllabus");
		canvas.macmillan2Page.verifySyllabusContentOfCoursePage("abcd2");
	}
	@Test(dependsOnMethods = "Step13_VerifySyllabusTabContentsOfCourse")
	public void Step14_VerifyOutcomesTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Outcomes");
		canvas.macmillan2Page.verifyOutcomesContentOfCoursePage();
	}
	@Test(dependsOnMethods = "Step14_VerifyOutcomesTabContentsOfCourse")
	public void Step15_VerifyQuizzTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Quizzes");
		canvas.macmillan2Page.verifyQuizzesContentOfCoursePage();
	}
	@Test(dependsOnMethods = "Step15_VerifyQuizzTabContentsOfCourse")
	public void Step16_VerifyModuleTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Modules");
		canvas.macmillan2Page.verifyModulesContentOfCoursePage("abcd2");
	}
	@Test(dependsOnMethods = "Step16_VerifyModuleTabContentsOfCourse")
	public void Step17_VerifyConferenceTabContentsOfCourse() {
		canvas.macmillan2Page.clickLeftTab("Conferences");
		canvas.macmillan2Page.verifyConferencesContentOfCoursePage("abcd2");
	}
	@Test(dependsOnMethods = "Step17_VerifyConferenceTabContentsOfCourse")
	public void Step18_VerifyCollaborationTabContentsOfCourse() {	
		canvas.macmillan2Page.clickLeftTab("Collaborations");
		canvas.macmillan2Page.verifyCollaborationsContentOfCoursePage("abcd2");
	}
	@Test(dependsOnMethods = "Step18_VerifyCollaborationTabContentsOfCourse")
	public void Step19_VerifySettingTabContentsOfCourse() {	
		canvas.macmillan2Page.clickLeftTab("Settings");
		canvas.macmillan2Page.verifySettingsContentOfCoursePage("abcd2");
	}
	@Test(dependsOnMethods = "Step19_VerifySettingTabContentsOfCourse")
	public void Step20_VerifyCourseHomePageAfterClickingHome() {	
		canvas.macmillan2Page.clickLeftTab("Home");
		canvas.macmillan2Page.verifyHomePageOfSelectedCourse("abcd2");
		canvas.macmillan2Page.verifyLeftTabOfSelectedCourse();
		canvas.macmillan2Page.verifyRightSideContentOfSelectedCourse();
	}
	@Test(dependsOnMethods = "Step20_VerifyCourseHomePageAfterClickingHome")
	public void Step21_VerifyCourseHomePageAfterClickingHome() {	
		canvas.macmillan2Page.clickLeftTab("Home");
		canvas.macmillan2Page.verifyHomePageOfSelectedCourse("abcd2");
		canvas.macmillan2Page.verifyLeftTabOfSelectedCourse();
		canvas.macmillan2Page.verifyRightSideContentOfSelectedCourse();
	}
	//@Test(dependsOnMethods = "Step21_VerifyCourseHomePageAfterClickingHome")
	public void Step22_VerifyPublishCourseMessages() {	
		canvas.macmillan2Page.clickOnPublishButton();
		canvas.macmillan2Page.verifyPublishCourseMessages();
	}
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}
