package com.qait.canvas.tests;

import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Sanity_Instructor_Flow extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	
	private String courseName;
	private String instructorUserName;

	private String external_Tool;
	String bookTitle;
	
	String instructorEmail, instructorPassword;
	private String pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, school;
	String assignmentName;
	String chapterName, chapterIntroduction, chapterContent;
	String quizTitle1, quizTitle2;
	String chapterNumber, selectQuestionFrom;
	String imgURL = "http://www.joomlaworks.net/images/demos/galleries/abstract/7.jpg";
	String moduleName;
	
	private void initVars(String book) {
		System.currentTimeMillis();
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";
		
		
		instructorUserName = getData("users.instructor.user_name2");
		instructorEmail = getData("users.instructor.user_email2");
		instructorName = getData("users.instructor.name2");
		instructorPassword = getData("users.instructor.password");
		courseName = getData("course.name2");
		academicTerm = "Summer 2017";
		external_Tool = getData("external_tool");
		school = "TEST University (New York, NY)";
		

		String bookIdentifier = null;
		if(book.contains("myers11e")) {
			bookTitle = getData("bookTitleLP");
			bookIdentifier = "myers";
		}
		else {
			bookTitle = getData("bookTitleWriterHelp");
			bookIdentifier = "lunsford";
		}
		
		if(bookIdentifier.contains("myers")) {
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
			chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		}
		else {
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		}
		moduleName = getData("moduleName");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		initVars(book);
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Launch_Application_And_Login() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
		canvas.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods="Launch_Application_And_Login")
	public void Find_Course_And_Associate_LP_Course() {
		
		canvas.leftMenu.goToUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		//canvas.toolsPage.runHandleSecurityExe();
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.toolsPage.changeWindow(1);
		canvas.provisionPage.verifyTokenRegistrationPage();
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.createNewCourse(bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, false, "", school);
		//courseTitle must be short enough so that <br> tag not added in course name in table
		canvas.provisionPage.verifyCourseCreated(pxCourseName);
		canvas.provisionPage.associateCourse(pxCourseName);
		canvas.toolsPage.verifyToolsPageAfterCousreAssociation();
	}
	
	@Test(dependsOnMethods= "Find_Course_And_Associate_LP_Course")
	public void Instructor_Create_Assignments_In_LP() {
		
		if(bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.toolsPage.clickLaunchPad();
		}
		else {
			canvas.toolsPage.clickWritesHelp();
		}
		canvas.coursePage.userNavigateToPxWindow();
		if(bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.pxPage.verifyUserIsOnCourseHomePage(pxCourseName);
			canvas.pxPage.createQuizAssignment("Quiz", quizTitle1, true, "10", "15", true, chapterNumber, selectQuestionFrom);
		}
		else {
			canvas.pxPage.clickOnAssignmentsTab();
			canvas.assignmentPage.clickOnAddNewAssignmentLink();
			//canvas.assignmentPage.embedImage(imgURL);
			assignmentName = canvas.assignmentPage.provideTitle();
			canvas.assignmentPage.expandAssignment(assignmentName);
			canvas.pxPage.clickOnHomeButtonTab();
			canvas.pxPage.createQuizAssignmentWritershelp("Quiz", quizTitle1, true, assignmentName, "10");
		}
		if(bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.pxPage.clickUnassignedTOCItem(chapterName);
			canvas.pxPage.assignTOCItem(chapterIntroduction, "15", true, "10");
			canvas.pxPage.launchPadLogout();
		}
		else {
			canvas.pxPage.clickUnassignedTOCItem(chapterName);
			canvas.pxPage.assignTOCItemWritersHelp(chapterIntroduction, assignmentName, "10");
			canvas.pxPage.launchPadLogout();
		}
		
	}
	
	@Test(dependsOnMethods= "Instructor_Create_Assignments_In_LP")
	public void Verify_Instructor_Successfully_Able_To_Deploy_And_Publish_Assignment() {
		canvas.toolsPage.clickMacmillanContent();
		canvas.toolsPage.verifyMacmillanContentPage();
		canvas.contentTocPage.ExpandToc("Assignments");
		canvas.contentTocPage.selectContentTOC(chapterIntroduction);
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.createNewModule(moduleName);
		canvas.contentTocPage.selectModuleAndDeploy(moduleName);
		canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.modulePage.publishDeployedModule(moduleName);
		canvas.coursePage.clickAssignmentsOnCoursePage();
		canvas.coursePage.verifyAssignmentOnCoursePage();
		canvas.coursePage.clickGradesOnCoursePage();
		canvas.coursePage.verifyContentDeployedInGradebook(quizTitle1, quizTitle2, chapterIntroduction);
		canvas.leftMenu.logout();

	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}