package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class Workflow_Login extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;

	private void _initVars() {
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Launch_Application_And_Verify_Login_Page_Step_01() {
		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
	}

	@Test(dependsOnMethods = { "Launch_Application_And_Verify_Login_Page_Step_01" })
	public void Click_On_Privacy_Policy_Link_And_Verify_Step_02() {
		canvas.loginPage.clickOnPrivacyPolicyLink();
		canvas.loginPage.verifyUserIsOnPrivacyPolicyPage();
		canvas.loginPage.goBackToCanvasLoginPage(canvasURL);
	}

	@Test(dependsOnMethods = { "Click_On_Privacy_Policy_Link_And_Verify_Step_02" })
	public void Click_On_Help_Link_And_Verify_Step_03() {

		canvas.loginPage.clickOnHelpLink();
		canvas.loginPage.verifyHelpPopUp();
		canvas.loginPage.clickOnCanvasGuidesLink();
		canvas.loginPage.verifyUserIsOnCanvasGuidesPage();
		canvas.loginPage.userClosesSecondaryWindowAndGoesBackToCanvasLoginWindow();
		canvas.loginPage.clickOnCanvasFeatureIdeasLink();
		canvas.loginPage.verifyUserIsOnCanvasFeatureIdeasPage();
		canvas.loginPage.userClosesSecondaryWindowAndGoesBackToCanvasLoginWindow();
		canvas.loginPage.clickOnReportAProblemLink();
		canvas.loginPage.verifyReportAProblemPopUp();
		canvas.loginPage.navigateToHelpPopUp();
		canvas.loginPage.closeHelpPopUp();
	}

	// @Test(dependsOnMethods={"Click_On_Help_Link_And_Verify_Step_03"})
	// public void Click_On_Terms_Of_Service_Link_And_Verify_Step04() {
	// canvas.loginPage.clickOnTermsOfUseLink();
	// canvas.loginPage.verifyUserIsOnTermsOfUsePage();
	// canvas.loginPage.goBackToCanvasLoginPage(canvasURL);
	// }

	// @Test(dependsOnMethods={"Click_On_Terms_Of_Service_Link_And_Verify_Step04"})
	// public void Click_On_Facebook_Link_And_Verify_Step_05() {
	// canvas.loginPage.clickOnFacebookLink();
	// canvas.loginPage.verifyUserIsOnFacebookPage();
	// canvas.loginPage.goBackToCanvasLoginPage(canvasURL);
	// }
	//
	// @Test(dependsOnMethods={"Click_On_Facebook_Link_And_Verify_Step_05"})
	// public void Click_On_Twitter_Link_And_Verify_Step06() {
	//
	// canvas.loginPage.clickOnTwitterLink();
	// canvas.loginPage.verifyUserIsOnTwitterPage();
	// canvas.loginPage.goBackToCanvasLoginPage(canvasURL);
	// }

	@Test(dependsOnMethods = { "Click_On_Help_Link_And_Verify_Step_03" })
	public void Log_In_With_Invalid_Credntials_Step_07() {
		canvas.loginPage.loginToTheApplication("UserName", "Password");

		canvas.loginPage.verifyErrorMessageForInvalidLogIn();
	}

	@Test(dependsOnMethods = { "Log_In_With_Invalid_Credntials_Step_07" })
	public void Log_In_Valid_UserName_Invalid_Passsword_Step_08() {
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), "Password");
		canvas.loginPage.verifyErrorMessageForInvalidLogIn();
	}

	@Test(dependsOnMethods = { "Log_In_Valid_UserName_Invalid_Passsword_Step_08" })
	public void Log_In_Invalid_UserName_Valid_Passsword_Step09() {
		canvas.loginPage.loginToTheApplication("UserName", getData("users.admin.password"));
		canvas.loginPage.verifyErrorMessageForInvalidLogIn();
	}

	@Test(dependsOnMethods = { "Log_In_Invalid_UserName_Valid_Passsword_Step09" })
	public void Log_In_Valid_Credentials_Step10() {
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
		//canvas.dashboardPage.verifyUserIsOnDashboardPage();
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = { "Log_In_Valid_Credentials_Step10" })
	public void User_Log_Out() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	
	  @AfterClass(alwaysRun = true) public void Stop_Test_Session() {
	  canvas.closeBrowserSession(); }
	 
}