package com.qait.canvas.tests;

import java.io.IOException;
import java.lang.reflect.Method;

import org.openqa.selenium.StaleElementReferenceException;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class NewTestData extends Parent_Test{
/*
	CanvasTestSessionInitiator canvas;
	
	private Long timeStamp = System.currentTimeMillis();
	private String subAccountEnv = "";
	private String courseName="AutoCourse"+timeStamp;
	private String instructor= "Auto"+"I"+timeStamp;
	private String emailInstructor=instructor+"@fake123.com";
	private String student="Auto"+"S"+timeStamp;
	private String emailStudent=student+"@fake123.com";
	private String firstName = "firstuser";
	private String lastName = "lastuser";
	private String external_Tool,contentName;
	private String repUsername, repPassword;
	
	private void initVars(){
		contentName = getData("contentName");
		external_Tool=getData("external_tool");
		repUsername = getData("users.salesRepresentative.username");
		repPassword = getData("users.salesRepresentative.password");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step02_Log_In_As_Admin"})
	public void Step03_Navigate_To_Account_And_Create_Course_Instructor_Student() {
		subAccountEnv= getData("SubAccountEnv");
		canvas.dashboardPage.goToAccounts();
		canvas.dashboardPage.goToSubAccount();
		canvas.dashboardPage.goToEnvSubAccount(subAccountEnv);
		canvas.dashboardPage.AddNewCourse(courseName);
		canvas.dashboardPage.createUser(instructor,emailInstructor);
		canvas.dashboardPage.createUser(student,emailStudent);
		canvas.dashboardPage.enterIntoCourse(courseName);
		canvas.dashboardPage.publishCourse();
		canvas.dashboardPage.addPeople("Teacher",emailInstructor);
		canvas.dashboardPage.createLoginInfoForUser(instructor, "123456");
		canvas.dashboardPage.addPeople("Student", emailStudent);
		canvas.dashboardPage.createLoginInfoForUser(student, "123456");
	}
	
	@Test(dependsOnMethods={"Step03_Navigate_To_Account_And_Create_Course_Instructor_Student"})
	public void Step04_Admin_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step04_Admin_User_Log_Out"})
	public void Step05_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor, getData("users.instructor.password"));
		canvas.dashboardPage.acceptInvite();
	}
	
	@Test(dependsOnMethods={"Step05_Log_In_As_Instructor"})
	public void Step06_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
		canvas.dashboardPage.clickOnSettingsLink();
		canvas.dashboardPage.clickNavigationTab();
		canvas.dashboardPage.enableMacmillanTools(external_Tool);
	}
	
	@Test(dependsOnMethods={"Step06_Go_To_Course_Page"})
	public void Step07_Go_To_Module_Page() {
		canvas.coursePage.goToModulePage();
		//canvas.modulePage.verifyModulePageOpens();
		canvas.modulePage.createAModule();
	}
	
	@Test(dependsOnMethods={"Step07_Go_To_Module_Page"})
	public void Step08_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods = {"Step08_User_Log_Out"},expectedExceptions = StaleElementReferenceException.class)
	public void Step09_Request_Instructor_Access() throws IOException{
		canvas.launchApplication(getData("px_url"));
	canvas.pxPage.requestInstructorAccess(emailInstructor, firstName, lastName, getData("zipcode"), getData("university"), repUsername, repPassword);
		canvas.pxPage.createCourse();
		canvas.closeBrowserSession();
	}
	
	@Test(dependsOnMethods = {"Step09_Request_Instructor_Access"})
	public void Step10_Associate_Instructor(){
		canvas = new CanvasTestSessionInitiator();
		canvas.launchApplication();
		canvas.loginPage.loginToTheApplication(instructor, getData("users.instructor.password"));
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickToolLink("lnk_GettingStarted");
		canvas.raPage.checkEmail(emailInstructor);
		canvas.raPage.providePassword(getData("users.instructor.password"));
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.createNewCourse(getData("createCourse.linkText"),getData("createCourse.courseName"), getData("createCourse.school"), getData("createCourse.academicTerm"));
		canvas.provisionPage.associateFirstCourseFromTheList();
		//canvas.provisionPage.userClosesCurrentPageAndNavigatesToBasePage();
		canvas.coursePage.goToModulePage();
		canvas.modulePage.verifyModulePageOpens();
		canvas.modulePage.clickOnAddContent();
		canvas.modulePage.selectExternalToolAndNavigateToContentToc(external_Tool);
		canvas.contentTocPage.ExpandFirstContentOfToc();
		canvas.contentTocPage.selectThirdLevelContent(contentName);
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.modulePage.clickOnAddItemAndDeployContent();
		canvas.modulePage.publishAllDeployedContent();
		canvas.modulePage.logOut();
	}

	@AfterClass(alwaysRun=true)
	public void Stop_Test_Session() throws IOException{
		canvas.closeBrowserSession();
	}
	*/
}