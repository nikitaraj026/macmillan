package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.CustomFunctions;
import com.qait.automation.utils.Parent_Test;

public class Request_Instructor_Access_Representative_Test extends Parent_Test{
	CanvasTestSessionInitiator test;
	String appUrl;
	String instructorEmail, password, fName, lName;
	String macmillanUsername, macmillanPassword;
	String zipCode, searchRange, schoolType, schoolName, department, position;
	
	private void initVars(String book) {
		String bookIdentifier = book;
		appUrl = getData(bookIdentifier + ".app_url");
		instructorEmail = test.coursePage.readDataFromYamlforUoP("EmailInst");
		password = getData("newUser.password");
		fName = getData("newUser.instructor.fName");
		lName = getData("newUser.instructor.lName");
		macmillanUsername = getData("iLogin.representative.username");
		macmillanPassword = getData("iLogin.representative.password");
		zipCode = getData("iLogin.findSchool.zipCode");
		searchRange = getData("iLogin.findSchool.searchRange.fiveMiles");
		schoolType = getData("iLogin.findSchool.schoolType.college");
		schoolName = getData("iLogin.findSchool.schoolName");
		department = getData("iLogin.findSchool.department");
		position = getData("iLogin.findSchool.position");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@BeforeClass
	@Parameters("book")
	public void start_test_Session(@Optional("myers") String book) {
		test = new CanvasTestSessionInitiator();
		initVars(book);
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        test.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		test.launchApplication(appUrl);
		test.loginPageLaunchpad.verifyUserIsOnLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Instructor_Fills_Email_And_Requests_Access_Sees_Request_Instructor_Access_Page() {
		test.loginPageLaunchpad.requestInstructorAccess(instructorEmail);
		test.onboardingPage.verifyTitle(getData("pageNames.requestInstructorAccess"));
	}
	
	@Test(dependsOnMethods = "Step02_Instructor_Fills_Email_And_Requests_Access_Sees_Request_Instructor_Access_Page")
	public void Step03_Instructor_Verifies_Request_Instructor_Access_Page() {
		test.onboardingPage.verifyErrorMessageOnRequestInstructorAccessPage("1", instructorEmail);
		test.onboardingPage.verifyWantToSignUpRadioBtnChecked();
	}
	
	@Test(dependsOnMethods = "Step02_Instructor_Fills_Email_And_Requests_Access_Sees_Request_Instructor_Access_Page")
	public void Step04_Instructor_Chooses_Macmillan_Representative_And_Submits_Sees_Instructor_Registration_Page() {
		test.onboardingPage.submitMacmillanRepresentative(macmillanUsername, macmillanPassword, instructorEmail);
		test.onboardingPage.verifyTitle(getData("pageNames.instructorRegistration"));
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Chooses_Macmillan_Representative_And_Submits_Sees_Instructor_Registration_Page")
	public void Step05_Instructor_Fills_Instructor_Information() {
		test.onboardingPage.fillInstructorFirstAndLastName(fName, lName);
		test.onboardingPage.fillInstructorPasswordAndConfirmPassword(password);
		test.onboardingPage.verifyInstructorEmailCorrect(instructorEmail);
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Chooses_Macmillan_Representative_And_Submits_Sees_Instructor_Registration_Page")
	public void Step06_Instructor_Fills_Zipcode_Details() {
		test.onboardingPage.findYourSchoolByZipCode(zipCode, searchRange, schoolType);
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Chooses_Macmillan_Representative_And_Submits_Sees_Instructor_Registration_Page")
	public void Step07_Instructor_Fills_School_Details_And_Accepts_Policy() {
		test.onboardingPage.selectSchoolDepartmentAndPosition(schoolName, department, position);
		test.onboardingPage.acceptCompanyPrivacyPolicy();
	}
	
	@Test(dependsOnMethods = "Step04_Instructor_Chooses_Macmillan_Representative_And_Submits_Sees_Instructor_Registration_Page")
	public void Step08_Instructor_Submits_Registration_Sees_Access_Granted_Page() {
		test.onboardingPage.clickSubmit();
		test.onboardingPage.verifyTitle(getData("pageNames.instructorAccessGranted"));
	}
	
	@Test(dependsOnMethods = "Step08_Instructor_Submits_Registration_Sees_Access_Granted_Page")
	public void Step09_Instructor_Proceeds_To_Website_Sees_Dashboard() {
		test.onboardingPage.clickProceedToWebsiteBtn();
		test.dashBoardPageLaunchpad.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods = "Step09_Instructor_Proceeds_To_Website_Sees_Dashboard")
	public void Step10_Instructor_Logout() {
		test.onboardingPage.logout();
		test.loginPageLaunchpad.verifyUserIsOnLoginPage();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(test, result, this.getClass().getName());     
	}
	
	@AfterClass
	public void stop_test_session() {
		 test.closeBrowserSession();
	}
	
}
