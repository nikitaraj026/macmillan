package com.qait.canvas.tests;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1849 extends Parent_Test{
/*
	CanvasTestSessionInitiator canvas;
	private String external_Tool;

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	*//**
	 * An Instructor can copy an existing PX course for any existing PX title on the Course 
	 * Listing Page in order to initiate and complete the PX course copy creation process.
	 * 
	 *//*
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.non_associated"),
				getData("users.instructor.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = { "Step02_Log_In_As_Instructor" })
	public void Step03_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Course_Page" })
	public void Step04_Go_To_Module_Page() {
		external_Tool = getData("external_tool");
		canvas.coursePage.goToModulePage();
		canvas.modulePage.verifyModulePageOpens();
		canvas.modulePage.clickOnAddContent();
		canvas.modulePage.selectExternalToolAndNavigateToContentToc(external_Tool);
	}

	@Test(dependsOnMethods = { "Step04_Go_To_Module_Page" })
	public void Step05_VerifyProvisionPage() {
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
	}

	@Test(dependsOnMethods = { "Step05_VerifyProvisionPage" })
	public void Step06_VerifyContentUnderLinkResourceModalWindow() {
		canvas.provisionPage.copyCourse(
				getData("copyCourse.linkText"), 
				getData("copyCourse.courseName"),
				getData("copyCourse.academicTerm"));
		canvas.provisionPage.closeProvisionPageFrame();
		canvas.contentTocPage.closeContentToc();
	}

	@Test(dependsOnMethods = { "Step06_VerifyContentUnderLinkResourceModalWindow" })
	public void Step07_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}

*/}