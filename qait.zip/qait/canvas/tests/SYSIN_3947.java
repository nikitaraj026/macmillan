package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

public class SYSIN_3947 extends Parent_Test{

	CanvasTestSessionInitiator canvas;
	
	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor;
	private String password;
	private String externalTool;
	private String bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm;
	private String book;
	private String moduleName;
	private String school;

	private void _initVars() {
		Long timeStamp = System.currentTimeMillis();
		//courseName = "TestCourse_" + timeStamp;
		book = "myers";
		courseName = getData("SYSIN3947.courseName");
		subAccount = getData("subAccount");
		instructor = getData("SYSIN3947.instructor");
		emailInstructor = instructor + "@fake123.com";
		password = "12345678";
		externalTool = getData("external_tool");
		academicTerm = "Winter 2017";
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";
		instructorName = getData("users.instructor.name3");
		school = "TEST University (New York, NY)";
		
		String bookIdentifier = null;
		bookTitle = getData("bookTitleLP");
		bookIdentifier = "myers";

		moduleName = "Test" + "Module" + timeStamp;
		
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Launch_Application"})
	public void Log_In_As_Instructor() {
		
		canvas.loginPage.loginToTheApplication(instructor, password);
		canvas.dashboardPage.verifyDashboardPage();
	}
	
	@Test(dependsOnMethods={"Log_In_As_Instructor"})
	public void Go_To_Course_Homepage() {
		
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}
	
	@Test(dependsOnMethods={"Go_To_Course_Homepage"})
	public void Remove_Existing_Modules_And_Unlink_Course_If_Associated() {
		
		//canvas.coursePage.clickModulesOnCoursePage();
		//canvas.coursePage.verifyModulePresentAndDelete();
		//canvas.coursePage.verifyModuleIsDeleted();
		
		canvas.coursePage.enterIntoToolsSection(externalTool);
		canvas.toolsPage.verifyToolsPage();
		
		
		if (!canvas.toolsPage.softVerifyCourseIsAssociated("Connect with LaunchPad")) {
			throw new SkipException("Content already removed");
		}
		canvas.toolsPage.clickOnUnlinkMacmillanToolLink();
		canvas.toolsPage.verifyEndCourseAssociationPage();
		canvas.toolsPage.clickOnRemoveMacmillanContent();
		canvas.toolsPage.disassociateCourse();
		canvas.toolsPage.verifyEndCourseAssociationPageAfterCourseIsDisassociated();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.refreshPage();
		canvas.toolsPage.verifyNonAssociatedToolsPage("Connect with LaunchPad");
	}
	
	@Test(dependsOnMethods={"Remove_Existing_Modules_And_Unlink_Course_If_Associated"}, alwaysRun = true)
	public void Create_New_Course_On_Provisioning_Page() {
		
		canvas.toolsPage.switchToDefaulFrame();
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.toolsPage.changeWindow(1);
		canvas.provisionPage.verifyTokenRegistrationPage();
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.createNewCourseSYSIN3947(bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, false, "", school, canvas.getEnv());
		
		//courseTitle must be short enough so that <br> tag not added in course name in table
		canvas.provisionPage.verifyCourseCreated(pxCourseName);
		
	}
	
	@Test(dependsOnMethods={"Create_New_Course_On_Provisioning_Page"})
	public void Associate_Course() {
		
		canvas.provisionPage.associateCourse(pxCourseName);
		canvas.toolsPage.verifyToolsPageAfterCousreAssociation();
		canvas.toolsPage.switchToDefaultContent();
	}

	@Test(dependsOnMethods={"Associate_Course"})
	public void Admin_Log_Out_Canvas_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}