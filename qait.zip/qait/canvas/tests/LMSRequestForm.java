package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class LMSRequestForm extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	String nameOfInstallation = "";
	String urlOfInst = "";
	String email = RandomStringUtils.randomAlphanumeric(7) + "@yopmail.com";
	String lmsType="";
	String cityName="New York";

	
	private void _initVars() {
		nameOfInstallation = getData("Installation.name");
		urlOfInst = getData("Installation.baseurl");
		lmsType = getData("Installation.lmstype");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchLMSRequestForm();
		canvas.requestpage.verifyUserOnFormPage();
	}

	@Test
	public void Step02_FillNecessaryDetails() {
		canvas.requestpage.fillBasicDetails(email);
		canvas.requestpage.enterInstallationDetails(nameOfInstallation,urlOfInst);
		canvas.requestpage.selectRadioButtons(lmsType);
		canvas.requestpage.enterCitySelectStateAndCountry(cityName);
		canvas.requestpage.searchFromInstitutions();
		canvas.requestpage.clickOnCaptcha();

	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
//		canvas.closebrowserSession();
	}
}
