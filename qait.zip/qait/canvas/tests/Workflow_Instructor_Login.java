package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Workflow_Instructor_Login extends Parent_Test{
	CanvasTestSessionInitiator canvas;
	private String instUsername, password;
	private String canvasURL;

	private void _initVars() {
		instUsername = getData("users.instructor.user_name3");
		password = getData("users.instructor.password");
		canvasURL = getData("app_url");
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {
		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application_And_Verify_Login_Page"})
	public void Step02_Instructor_Log_In_Canvas_Application() {
		canvas.loginPage.loginToTheApplication(instUsername, password);
		//canvas.dashboardPage.verifyUserIsOnDashboardPage();
		
	}
	
	@Test(dependsOnMethods="Step02_Instructor_Log_In_Canvas_Application")
	public void Step03_Verify_Instructor_Logout_Of_Application() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}
	
	@Test(dependsOnMethods="Step03_Verify_Instructor_Logout_Of_Application")
	public void Step04_Instructor_Go_To_Dashboard_Page() {
		canvas.loginPage.loginToTheApplication(instUsername, password);
		canvas.dashboardPage.acceptTermsOfUse(); 
		canvas.dashboardPage.verifyDashboardPageNewInstructor();
		canvas.leftMenu.verifyNavigationMenuLeftPanel();
	}
	
	@Test(dependsOnMethods="Step04_Instructor_Go_To_Dashboard_Page")
	public void Step05_Verify_Instructor_Redirected_To_Dashboard() {
		canvas.leftMenu.clickOnCanvasLogo();
		canvas.leftMenu.verifyNavigationMenuLeftPanel();
		canvas.dashboardPage.verifyDashboardPageNewInstructor();
	}
	
	@Test(dependsOnMethods="Step04_Instructor_Go_To_Dashboard_Page")
	public void Step06_Verify_Account_Overlay_Submenu() {
		canvas.leftMenu.clickOnAccountLeftMenu();
		canvas.leftMenu.verifyAccountPanel();
	}
	
	@Test(dependsOnMethods="Step06_Verify_Account_Overlay_Submenu")
	public void Step07_Verify_User_Settings_Page() {
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
		canvas.userSettings.verifyUserSettingsPage();
	}
	
	@Test(dependsOnMethods="Step07_Verify_User_Settings_Page")
	public void Step08_Verify_Notifications_Preferences_Page() {
		canvas.userSettings.clickOnNotifications();
		canvas.userSettings.verifyNotificationsPreferencesPage();
	}
	
	@Test(dependsOnMethods="Step07_Verify_User_Settings_Page")
	public void Step09_Verify_Files_Page() {
		canvas.userSettings.clickOnFiles();
		canvas.userSettings.verifyFilesPage();
	}
	
	@Test(dependsOnMethods="Step07_Verify_User_Settings_Page")
	public void Step10_User_Redirects_To_User_Settings_Page() {
		canvas.leftMenu.clickOnAccountLeftMenu();
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
		canvas.userSettings.verifyUserSettingsPage();
	}
	
	@Test(dependsOnMethods="Step10_User_Redirects_To_User_Settings_Page")
	public void Step11_Verify_My_EPortfolios_Page() {
		canvas.userSettings.clickOnMyEPortfolios();
		canvas.userSettings.verifyMyEPortfolios();
	}
	
	@Test(dependsOnMethods="Step07_Verify_User_Settings_Page")
	public void Step12_Verify_Confirm_Email_Address_Dialog_Box() {
		canvas.leftMenu.clickOnAccountLeftMenu();
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
		canvas.userSettings.verifyUserSettingsPage();
		canvas.userSettings.clickOnUserEmail();
		canvas.userSettings.verifyConfirmEmailAddressDialogBox();
	}
	
	@Test(dependsOnMethods="Step12_Verify_Confirm_Email_Address_Dialog_Box")
	public void Step13_Verify_Toast_Message() {
		canvas.userSettings.clickOnReSendConfirmation();
		canvas.userSettings.verifyReSendConfirmationToastMessage();
	}
	
	@Test(dependsOnMethods="Step12_Verify_Confirm_Email_Address_Dialog_Box")
	public void Step14_Verify_Confirm_Email_Address_Dialog_box_close() {
		canvas.userSettings.clickOnOKThanks();
		canvas.userSettings.verifyConfirmEmailAddressDialogBoxClosed();
	}
	
	@Test(dependsOnMethods="Step14_Verify_Confirm_Email_Address_Dialog_box_close")	
	public void Step15_User_Log_Out() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}
