package com.qait.canvas.tests;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Smoke_Instructor_Flow extends Parent_Test {

	CanvasTestSessionInitiator canvas;

	private String courseName;
	private String instructorUserName;

	private String external_Tool;
	String bookTitle;

	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	private String pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, school;
	String assignmentName;
	String chapterName, chapterIntroduction, chapterContent;
	String quizTitle1, quizTitle2;
	String chapterNumber, selectQuestionFrom;
	String imgURL = "http://www.joomlaworks.net/images/demos/galleries/abstract/7.jpg";
	String moduleName, tier, pxCourseNameAcc;

	private void initVars(String book) {
		System.currentTimeMillis();
		pxCourseName = getStringWithTimestamp("CANVAS");
		pxCourseNameAcc = pxCourseName.substring(0, pxCourseName.length() - 2);
		courseNumber = "";
		sectionNumber = "";

		instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
		instructorEmail = canvas.coursePage.readDataFromYaml("EmailInst");
		instructorName = getData("users.instructor.name1");
		instructorPassword = canvas.coursePage.readDataFromYaml("inst_password");
		instructorPasswordLaunchpad = canvas.coursePage.readDataFromYaml("PX_Password");
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		academicTerm = "Fall 2016";
		external_Tool = getData("external_tool");
		school = "TEST University (New York, NY)";

		String bookIdentifier = null;
		if (book.contains("myers11e")) {
			bookTitle = getData("bookTitleLP");
			bookIdentifier = "myers";
		} else {
			bookTitle = getData("bookTitleWriterHelp");
			bookIdentifier = "lunsford";
		}

		if (bookIdentifier.contains("myers")) {
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
			chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		} else {
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		}
		moduleName = getData("moduleName");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.toolsPage.clearBrowserCache();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		canvas.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Instructor_Accepts_AgreeTerm() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}

	@Test(dependsOnMethods = "Step03_Instructor_Accepts_AgreeTerm")
	public void Step04_Instructor_Go_To_Dashboard_Page() {
		canvas.dashboardPage.verifyDashBoardPage(courseName);
	}

	@Test(dependsOnMethods = "Step04_Instructor_Go_To_Dashboard_Page")
	public void Step05_Instructor_Go_To_Course_Page() {
//		canvas.dashboardPage.acceptInvite();
//		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step05_Instructor_Go_To_Course_Page")
	public void Step06_Instructor_Go_To_Course_Details_Page() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
		canvas.coursePage.clickSettingsOnCoursePage();
		canvas.coursePage.verifyCourseDetailsPage(courseName);
	}

	@Test(dependsOnMethods = "Step06_Instructor_Go_To_Course_Details_Page")
	public void Step07_Instructor_Go_To_Navigation_Tab() {
		canvas.coursePage.clickNavigationTab();
		canvas.coursePage.verifyNavigationTab();
	}

	@Test(dependsOnMethods = "Step07_Instructor_Go_To_Navigation_Tab")
	public void Step08_Instructor_Add_Macmillan_Tool() {
		boolean value = canvas.leftMenu.menuIsPresentOrNotAtLeftSide(external_Tool);
		if (value) {
			canvas.macmillan2Page.clickLeftTab("Settings");
			canvas.addMacTools.clickOnCourseStatisticsTab("Navigation");
			canvas.coursePage.enableMacmillanTools(external_Tool);
		}
	}

	@Test(dependsOnMethods = "Step08_Instructor_Add_Macmillan_Tool")
	public void Step09_Instructor_Navigate_To_Macmillan_Tool_Page() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.runHandleSecurityExe();
	}

	@Test(dependsOnMethods = "Step09_Instructor_Navigate_To_Macmillan_Tool_Page")
	public void Step10_Instructor_Navigates_To_Token_Registration_page() {
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.provisionPage.fillNewInstructorDetails("autoInst", "canvas", instructorEmail);
		canvas.provisionPage.clickOnSignInBtn();
		canvas.provisionPage.clickOnContinueProvisioning();
		canvas.provisionPage.verifyTokenRegistrationPage();
	}

	@Test(dependsOnMethods = "Step10_Instructor_Navigates_To_Token_Registration_page")
	public void Step11_Intructor_Navigate_To_Course_Integration_Page() {
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
	}

	@Test(dependsOnMethods = "Step11_Intructor_Navigate_To_Course_Integration_Page")
	public void Step12_Instructor_Create_Course() {
		canvas.provisionPage.createNewCourse(bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName,
				academicTerm, false, "", school);
		canvas.provisionPage.verifyCourseCreated(pxCourseNameAcc);
	}

	@Test(dependsOnMethods = "Step12_Instructor_Create_Course")
	public void Step13_Instructor_Associate_Course_And_Verify_Course_Association() {
		canvas.provisionPage.associateCourse(pxCourseNameAcc);
		canvas.toolsPage.verifyToolsPageAfterCousreAssociation();
	}

	@Test(dependsOnMethods = "Step13_Instructor_Associate_Course_And_Verify_Course_Association")
	public void Step14_Verify_Instructor_Navigate_To_Launchpad() {
		if (bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.toolsPage.clickLaunchPad();
		} else {
			canvas.toolsPage.clickWritesHelp();
		}
		canvas.coursePage.userNavigateToPxWindow();
	}

	@Test(dependsOnMethods = "Step14_Verify_Instructor_Navigate_To_Launchpad")
	public void Step15_Verify_That_Instructor_Is_Able_To_Create_And_Assign_Assignment() {
		if (bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.pxPage.verifyUserIsOnCourseHomePage(pxCourseName);
			canvas.pxPage.createQuizAssignment("Quiz", quizTitle1, true, "10", "15", true, chapterNumber,
					selectQuestionFrom);
			canvas.pxPage.createQuizAssignment("Quiz", quizTitle2, true, "10", "15", true, chapterNumber,
					selectQuestionFrom);
		} else {
			canvas.pxPage.clickOnAssignmentsTab();
			canvas.assignmentPage.clickOnAddNewAssignmentLink();
			assignmentName = canvas.assignmentPage.provideTitle();
			canvas.assignmentPage.expandAssignment(assignmentName);
			canvas.pxPage.clickOnHomeButtonTab();
			canvas.pxPage.createQuizAssignmentWritershelp("Quiz", quizTitle1, true, assignmentName, "10");
			canvas.pxPage.createQuizAssignmentWritershelp("Quiz", quizTitle2, true, assignmentName, "10");
		}
	}

	@Test(dependsOnMethods = "Step15_Verify_That_Instructor_Is_Able_To_Create_And_Assign_Assignment")
	public void Step16_Verify_That_Instructor_Is_Able_To_Assign_TOC_EBook() {
		if (bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.pxPage.clickUnassignedTOCItem(chapterName);
			canvas.pxPage.assignTOCItem(chapterIntroduction, "15", true, "10");
			canvas.pxPage.launchPadLogout();
		} else {
			canvas.pxPage.clickUnassignedTOCItem(chapterName);
			canvas.pxPage.assignTOCItemWritersHelp(chapterIntroduction, assignmentName, "10");
			canvas.pxPage.launchPadLogout();
		}
	}

	@Test(dependsOnMethods = "Step16_Verify_That_Instructor_Is_Able_To_Assign_TOC_EBook")
	public void Step17_Instructor_Navigates_To_Macmillan_Content_Page() {
		canvas.toolsPage.clickMacmillanContent();
		canvas.toolsPage.verifyMacmillanContentPage();
	}

	@Test(dependsOnMethods = "Step17_Instructor_Navigates_To_Macmillan_Content_Page")
	public void Step18_Verify_Instructor_Successfully_Able_To_Deploy_Assignment() {
		canvas.contentTocPage.ExpandToc("Assignments");
		canvas.contentTocPage.verifyAllAssignmentsTextIsNotClickable();
		canvas.contentTocPage.VerifyAllAssignmentsAreSelected();
		canvas.contentTocPage.verifyAllAssignmentsAreUnselected();
		canvas.contentTocPage.selectContentTOC(quizTitle1);
		canvas.contentTocPage.selectContentTOC(quizTitle2);
		canvas.contentTocPage.selectContentTOC(chapterIntroduction);
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.createNewModule(moduleName);
		canvas.contentTocPage.selectModuleAndDeploy(moduleName);
		canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
	}

	@Test(dependsOnMethods = "Step18_Verify_Instructor_Successfully_Able_To_Deploy_Assignment")
	public void Step19_Verify_That_Instructor_VerifiesMultipleDep_And_Publish_Module() {
		canvas.toolsPage.clickMacmillanContent();
		canvas.toolsPage.verifyMacmillanContentPage();
		canvas.contentTocPage.ExpandToc("Assignments");
		canvas.contentTocPage.verifyAssignmentsCheckboxDisabled();
		canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.modulePage.publishDeployedModule(moduleName);
	}

	@Test(dependsOnMethods = "Step19_Verify_That_Instructor_VerifiesMultipleDep_And_Publish_Module")
	public void Step20_Verify_That_Assignment_Are_Published() {
		canvas.coursePage.clickAssignmentsOnCoursePage();
		canvas.coursePage.verifyAssignmentOnCoursePage();
	}

	@Test(dependsOnMethods = "Step20_Verify_That_Assignment_Are_Published")
	public void Step21_Verify_Gradebook_Entry_Of_Deployed_Content() {
		canvas.coursePage.clickGradesOnCoursePage();
		canvas.coursePage.verifyContentDeployedInGradebook(quizTitle1, quizTitle2, chapterIntroduction);

	}

	@Test(dependsOnMethods = "Step21_Verify_Gradebook_Entry_Of_Deployed_Content")
	public void Step22_Instructor_Logout() {
		canvas.leftMenu.logout();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}
}