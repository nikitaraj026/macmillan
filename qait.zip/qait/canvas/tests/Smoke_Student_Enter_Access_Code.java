package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Student_Enter_Access_Code extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String courseName = "";
	private String instructorUserName;
	private String secondStudent, emailSecondStudent;
	private String studentFirstName, studentLastName;
	private String external_Tool;
	private String password, px_password, inst_password;
	private String quizTitle1, quizTitle2, quiz1CorrectAnswer1, quiz2CorrectAnswer1, quiz1Grade, quiz2Grade;;
	private String accessCode;
	private String chapterName, chapterIntroduction;

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
		String bookIdentifier = "myers";
		getData(bookIdentifier + ".author");
		studentFirstName = "FirstNameTwo";
		studentLastName = "LastNameTwo";
		px_password = "Password1!";
	}

	private void _initVars() {
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
		canvas.coursePage.readDataFromYaml("EmailInst");
		secondStudent = canvas.coursePage.readDataFromYaml("SecondStudentLogin");
		emailSecondStudent = canvas.coursePage.readDataFromYaml("EmailSecondStudent");
		password = canvas.coursePage.readDataFromYaml("Password");
		inst_password = canvas.coursePage.readDataFromYaml("inst_password");
		external_Tool = getData("external_tool");
		px_password = "Password1!";
		String bookIdentifier = "myers";
		quizTitle1 = getData(bookIdentifier + ".quiz1.name");
		quiz1CorrectAnswer1 = getData(bookIdentifier + ".quiz1.correctAnswer1");
		quiz1Grade = getData(bookIdentifier + ".quiz1.grade");
		quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		quiz2CorrectAnswer1 = getData(bookIdentifier + ".quiz2.correctAnswer1");
		quiz2Grade = getData(bookIdentifier + ".quiz2.grade");
		chapterName = getData(bookIdentifier + ".TOC_chapter5");
		chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
		getData(bookIdentifier + ".TOC_chapter5_content1");
		getData(bookIdentifier + ".TOC_chapter5_subcontent1");
		accessCode = getData("accessCode");
	}

//	@BeforeSuite
//	public void deleteExecutionFile() {
//		beforeSuiteMethod();
//	}
	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Student() {
		canvas.loginPage.loginToTheApplication(secondStudent, password);
//		canvas.leftMenu.goToUserCourse(courseName);
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Student")
	public void Step03_Student_Accept_Agree_Term_ForCourse() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}

	@Test(dependsOnMethods = "Step03_Student_Accept_Agree_Term_ForCourse")
	public void Step04_Student_Go_To_Dashboard_Page() {
		canvas.loginPage.loginToTheApplication(secondStudent, password);
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step04_Student_Go_To_Dashboard_Page")
	public void Step05_Student_Go_To_Course_Page() {
		canvas.dashboardPage.acceptInvite();
		canvas.coursePage.useCourseOnDashboard(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step05_Student_Go_To_Course_Page")
	public void Step06_Student_Attempt_Assignment() {
		canvas.toolsPage.runHandleSecurityExe();
//		canvas.coursePage.clickAssignmentsOnCoursePage();
//		canvas.coursePage.clickOnAssignmentLink(quizTitle2);
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.clickLaunchPad();
		canvas.toolsPage.changeWindow(1);

	}

	@Test(dependsOnMethods = { "Step06_Student_Attempt_Assignment" })
	public void Step07_Verify_Student_Complete_SSO_And_Choose_AccessCode() {
		canvas.pxPage.completeStudent_Registration(emailSecondStudent, px_password);
		canvas.pxPage.userNavigateToPxWindow();
		canvas.pxPage.verify_freeTrialMessageIsDisplayed();
		canvas.pxPage.useAccessCodeFromFreeTrialMessage();
		canvas.studentAccessGrantPage.fillAccessCodeOnEnterStudentAccessCode(accessCode);
		canvas.studentAccessGrantPage.clickSubmitOnEnterStudentAccessCode();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.verify_freeTrialMessageIsNotDisplayed();
	}

	@Test(dependsOnMethods = { "Step07_Verify_Student_Complete_SSO_And_Choose_AccessCode" })
	public void Step08_Student_Attempt_Manual_Quiz() {
		canvas.pxPage.clickAssignedTOCItem(quizTitle2);
		canvas.fnePage.verifyStudentIsOnQuizStartPage();
		canvas.fnePage.attemptQuizCorrectly(quiz2CorrectAnswer1);
		canvas.fnePage.clickDoneButton();
		canvas.fnePage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = { "Step08_Student_Attempt_Manual_Quiz" })
	public void Step09_Student_Attempt_Auto_Quiz() {
		canvas.pxPage.clickAssignedTOCItem(quizTitle1);
		canvas.fnePage.verifyStudentIsOnQuizStartPage();
		canvas.fnePage.attemptQuizCorrectly(quiz1CorrectAnswer1);
		canvas.fnePage.clickDoneButton();
		canvas.fnePage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = { "Step09_Student_Attempt_Auto_Quiz" })
	public void Step10_Student_Attemp_TOC_EBook() {
		canvas.pxPage.clickAssignedTOCItem(chapterName);
		canvas.pxPage.clickAssignedTOCItem(chapterIntroduction);
		canvas.fnePage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = "Step10_Student_Attemp_TOC_EBook")
	public void Step11_Student_Logout_LaunchPad_Enter() {
		canvas.pxPage.launchPadLogout();
	}

	@Test(dependsOnMethods = "Step11_Student_Logout_LaunchPad_Enter")
	public void Step12_Student_Logout_Canvas_Enter() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step12_Student_Logout_Canvas_Enter")
	public void Step13_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructorUserName, inst_password);
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step13_Log_In_As_Instructor")
	public void Step14_Go_To_Course_Homepage() {
		canvas.leftMenu.goToUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step14_Go_To_Course_Homepage")
	public void Step15_Go_To_Macmillan_Tools_Page_And_Refresh_Grades_Enter() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.clickOnMacmillanGradeRefreshLink();
		canvas.toolsPage.verifyGradeRefreshPage();
		canvas.toolsPage.clickSelectedButtonOnMacmillanHigherEducationGradeSyncRefresh();
		canvas.toolsPage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle2);
		canvas.toolsPage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(chapterIntroduction);
		canvas.toolsPage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
	}

	@Test(dependsOnMethods = "Step15_Go_To_Macmillan_Tools_Page_And_Refresh_Grades_Enter")
	public void Step16_Verify_Grades_In_Gradebook_Enter() {
		canvas.coursePage.clickGradesOnCoursePage();
		canvas.coursePage.verifyGradesInCanvasGradebook(secondStudent, quizTitle2, quiz2Grade);
	}

	@Test(dependsOnMethods = "Step16_Verify_Grades_In_Gradebook_Enter")
	public void Step17_Instructor_Logout() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}

}