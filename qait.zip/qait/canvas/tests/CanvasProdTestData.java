package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;
//import utills.CustomFunctions;

import static com.qait.automation.utils.YamlReader.getData;

public class CanvasProdTestData extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor, instructorName;
	private String firstStudent, firstStudentLogin, emailFirstStudent;
	private String secondStudent, secondStudentLogin, emailSecondStudent;
	private String thirdStudent, thirdStudentLogin, emailThirdStudent;
	private String password, inst_password, px_password;

	private void _initVars() {
		String dateWithTime = canvas.getCurrentDateWithTime();
		courseName = "CanvasProdTestCourse" + RandomStringUtils.random(4, true, true);
		subAccount = "Smoke Test";
		instructorName = getData("users.instructor.name1");
		instructor = "InstructorProd " + RandomStringUtils.random(4, true, true);
		emailInstructor = "InstructorProd" + dateWithTime + "@fake123.com";
		firstStudent = "StudFirst Prod";
		firstStudentLogin = "StudFirstProd" + dateWithTime;
		emailFirstStudent = firstStudentLogin + "@fake123.com";
		dateWithTime = canvas.getCurrentDateWithTime();
		secondStudent = "StudSecond LT";
		secondStudentLogin = "StudSecondLT" + dateWithTime;
		emailSecondStudent = secondStudentLogin + "@fake123.com";
		dateWithTime = canvas.getCurrentDateWithTime();
		thirdStudent = "StudThird LT";
		thirdStudentLogin = "StudThirdLT" + dateWithTime;
		emailThirdStudent = thirdStudentLogin + "@fake123.com";
		inst_password = getData("users.instructor.password");
		password = getData("users.student.password");
		DashBoardPageAction.courseName = courseName;
		px_password = "Password1!";
		data.put("InstUserName", instructor);
		data.put("EmailInst", emailInstructor);
		data.put("FirstStudent", firstStudent);
		data.put("FirstStudentLogin", firstStudentLogin);
		data.put("EmailFirstStudent", emailFirstStudent);
		data.put("SecondStudent", secondStudent);
		data.put("SecondStudentLogin", secondStudentLogin);
		data.put("EmailSecondStudent", emailSecondStudent);
		data.put("ThirdStudent", thirdStudent);
		data.put("ThirdStudentLogin", thirdStudentLogin);
		data.put("EmailThirdStudent", emailThirdStudent);
		data.put("Password", password);
		data.put("inst_password", inst_password);
		data.put("PX_Password", px_password);
		data.put("CourseName", courseName);
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
		canvas.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
		canvas.macmillan2Page.clickOnAddNewCourse();
		canvas.macmillan2Page.AddNewCourse2(courseName, subAccount);
		canvas.macmillan2Page.clickLeftTab("People");
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.createUser(instructor, emailInstructor);
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.createUser(firstStudent, emailFirstStudent);
		canvas.macmillan2Page.clickLeftTab("Courses");
		canvas.macmillan2Page.enterIntoCourse(courseName);
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.enterUserDetails("Teacher", emailInstructor);
		canvas.coursePage.clickOnAddUserButton();
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.enterUserDetails("Student", emailFirstStudent);
		canvas.coursePage.clickOnAddUserButton();
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnUserNameLink(firstStudent);
		canvas.coursePage.clickOnMoreUserDetails();
		canvas.coursePage.clickOnAddLoginLink();
		canvas.coursePage.enterLoginDetails(firstStudentLogin, password);
		canvas.coursePage.clickOnAddLoginButton();
		System.out.println("*********************************************************\n");
		System.out.println("Newly created Test Data for Canvas on Prod Envronment is as follows :\n" + "Instructor email:"
				+ emailInstructor + "\n" + "Student email:" + emailFirstStudent + "\n" + "Course Name:" + courseName);
		System.out.println("*********************************************************\n");
		canvas.leftMenu.logout();
	}
}