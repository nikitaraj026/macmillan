package com.qait.canvas.tests;

//Instructor can expand/collapse, and import the contents of the PX Launch Pad course (chapters and resources) in order to import the selected Macmillan within either a Canvas Assignment or Module via the Macmillan Deployment Tool.

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN2150 extends Parent_Test{
/*
	CanvasTestSessionInitiator canvas;
	private String external_Tool;
	private String contentName;
	private String courseName;

	private void _initVars() {
		external_Tool = getData("external_tool");
		contentName ="PROLOGUE INTRODUCTION";
		courseName = getData("courseName");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.user_name2"),
				getData("users.instructor.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = { "Step02_Log_In_As_Instructor" })
	public void Step03_Go_To_Course_Page() {
		canvas.dashboardPage.searchCourseFromCoursesMenu(courseName);
		//canvas.coursePage.verifyCoursePageOpens();
		//canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Course_Page" })
	public void Step04_Go_To_Tools_Tab() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
	}
	
	@Test(dependsOnMethods = { "Step04_Go_To_Tools_Tab" })
	public void Step05_Open_Macmillan_Content() {
		canvas.toolsPage.clickToolLink("lnk_MacmillanContent");
	}

	@Test(dependsOnMethods = { "Step05_Open_Macmillan_Content" })
	public void Step06_Add_And_Deploy_Content() {
		canvas.contentTocPage.ExpandFirstContentOfToc();
		canvas.contentTocPage.selectThirdLevelQuizContent(contentName);
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.selectModuleAndDeploy("autoModule");
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	
	@Test(dependsOnMethods = {"Step06_Add_And_Deploy_Content"})
	public void Step07_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() throws IOException {
		canvas.closeBrowserSession();
	}
*/}