package com.qait.canvas.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Workflow_DeployAndPublish_Assignments extends Parent_Test{
	CanvasTestSessionInitiator canvas;

	private String courseName;
	private String instructorUserName;

	private String external_Tool;
	String bookTitle;

	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	private String pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, school;
	String assignmentName;
	String chapterName, chapterIntroduction, chapterContent;
	String quizTitle1, quizTitle2;
	String chapterNumber, selectQuestionFrom;
	String imgURL = "http://www.joomlaworks.net/images/demos/galleries/abstract/7.jpg";
	String moduleName;

	private void initVars(String book) {
		System.currentTimeMillis();
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";

		instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
		instructorEmail = canvas.coursePage.readDataFromYaml("EmailInst");
		instructorName = getData("users.instructor.name1");
		instructorPassword = canvas.coursePage.readDataFromYaml("inst_password");
		instructorPasswordLaunchpad = canvas.coursePage.readDataFromYaml("PX_Password");
		courseName = "Testing Purpose";//canvas.coursePage.readDataFromYaml("CourseName");
		academicTerm = "Fall 2016";
		external_Tool = getData("external_tool");
		school = "TEST University (New York, NY)";

		String bookIdentifier = null;
		if (book.contains("myers11e")) {
			bookTitle = getData("bookTitleLP");
			bookIdentifier = "myers";
		} else {
			bookTitle = getData("bookTitleWriterHelp");
			bookIdentifier = "lunsford";
		}

		if (bookIdentifier.contains("myers")) {
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
			chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		} else {
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		}
		moduleName = getData("moduleName");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Instructor_Go_To_Dashboard_Page() {
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step03_Instructor_Go_To_Dashboard_Page")
	public void Step04_Instructor_Go_To_MacmillanTool() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
		canvas.coursePage.clickSettingsOnCoursePage();
		canvas.coursePage.verifyCourseDetailsPage(courseName);
		canvas.coursePage.clickNavigationTab();
		canvas.coursePage.verifyNavigationTab();
		boolean value=canvas.leftMenu.menuIsPresentOrNotAtLeftSide(external_Tool);
		if(value)
		{
		canvas.macmillan2Page.clickLeftTab("Settings");
		canvas.addMacTools.clickOnCourseStatisticsTab("Navigation");
		canvas.coursePage.enableMacmillanTools(external_Tool);
		}
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.runHandleSecurityExe();
	}

	@Test(dependsOnMethods = "Step04_Instructor_Go_To_MacmillanTool")
	public void Step05_Instructor_Navigates_To_MacmillanContent_Page() {
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.toolsPage.changeWindow(1);
		// canvas.provisionPage.fillNewInstructorDetails("autoInst","canvas","autoloadinst_canvas@fake123.com");
		canvas.provisionPage.verifyTokenRegistrationPage();
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.createNewCourse(bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName,
				academicTerm, false, "", school);
		// courseTitle must be short enough so that <br> tag not added in course
		// name in table
		canvas.provisionPage.verifyCourseCreated(pxCourseName);
		canvas.provisionPage.associateCourse(pxCourseName);
		canvas.toolsPage.verifyToolsPageAfterCousreAssociation();
		if (bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.toolsPage.clickLaunchPad();
		} else {
			canvas.toolsPage.clickWritesHelp();
		}
		canvas.coursePage.userNavigateToPxWindow();
		if (bookTitle.contains("CM LaunchPad for Psychology")) {
			canvas.pxPage.verifyUserIsOnCourseHomePage(pxCourseName);
			canvas.pxPage.createQuizAssignment("Quiz", quizTitle1, true, "10", "15", true, chapterNumber,
					selectQuestionFrom);
			canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
		} else {
			canvas.pxPage.clickOnAssignmentsTab();
			canvas.assignmentPage.clickOnAddNewAssignmentLink();
			// canvas.assignmentPage.embedImage(imgURL);
			assignmentName = canvas.assignmentPage.provideTitle();
			canvas.assignmentPage.expandAssignment(assignmentName);
			canvas.pxPage.clickOnHomeButtonTab();
			canvas.pxPage.createQuizAssignmentWritershelp("Quiz", quizTitle1, true, assignmentName, "10");
			canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
		}
		canvas.toolsPage.clickMacmillanContent();
		canvas.toolsPage.verifyMacmillanContentPage();
	}
	String quizName = "Prologue: The Story of Psychology";
	@Test(dependsOnMethods = "Step05_Instructor_Navigates_To_MacmillanContent_Page")
	public void Step06_Verify_Macmillan_TOC_Page() {
		canvas.contentTocPage.clickOnRefreshAndVerify();
		canvas.contentTocPage.clickOnShowCart();
		canvas.contentTocPage.verifyShowCartLinkPage();
		canvas.contentTocPage.clickOnShowCart();
		canvas.contentTocPage.verifyDoneButtonFunctionality();
		canvas.toolsPage.selectCheckbox("selectCheckBox",quizName);
		canvas.contentTocPage.verifyResetFunctionality();
		canvas.toolsPage.selectCheckbox("selectCheckBox",quizName);
		canvas.contentTocPage.verifyRemoveChapterFromShowLinkModalPopup(quizName);
		canvas.contentTocPage.verifyDoneButtonFunctionality();
	}
	@Test(dependsOnMethods = "Step06_Verify_Macmillan_TOC_Page")
	public void Step07_Verify_Instructor_Successfully_Able_To_Deploy_Assignment() {
		canvas.contentTocPage.ExpandToc("Assignments");
		canvas.contentTocPage.selectContentTOC(quizTitle1);
		canvas.contentTocPage.verifySelectedItemCount();
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.clickOnButton("Back");
		canvas.contentTocPage.verifyBackButtonFunctionality();
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.clickOnButton("Cancel");
		canvas.contentTocPage.verifyBackButtonFunctionality();
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.cancelCreateNewModule();
		canvas.contentTocPage.verifyCancelButtonFunctionalityOverCreateModuleModalPopup();
		canvas.contentTocPage.createNewModule(moduleName);
		canvas.contentTocPage.selectModuleAndDeploy(moduleName);
		canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
	}

	@Test(dependsOnMethods = "Step07_Verify_Instructor_Successfully_Able_To_Deploy_Assignment")
	public void Step08_Verify_That_Instructor_All_ModulePage_Buttons() {
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.modulePage.verifyViewProgress(courseName);
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.modulePage.clickAddModuleLink();
		canvas.modulePage.verifyAddModuleLink();
		canvas.modulePage.clickOnLockUntilCheckBox();
		canvas.modulePage.verifyLockUntilAfterCheck("12");
		canvas.modulePage.clickOnAddPreRequisite();
		canvas.modulePage.verifyAddPreRequisiteLink();
		canvas.modulePage.clickOnPlusIconButton("Test Add Pre");
		canvas.modulePage.verifyPulsIconModalWindow();
		canvas.modulePage.selectDropDownOption("External Tool");
		canvas.modulePage.verifyExternalToolContentAfterSelectingFromDropDown();
		canvas.modulePage.clickOnMacLearningToolFromExternalToolDropDownOption(external_Tool);
		canvas.toolsPage.verifyMacmillanContentPage();
		//canvas.coursePage.verifyModulePresentAndDelete();
		canvas.contentTocPage.ExpandToc("Assignments");
		String toc1="Prologue: The Story of Psychology";
		canvas.contentTocPage.selectContentTOC(toc1);
		canvas.contentTocPage.clickonDeploySelectedContent();
		canvas.modulePage.verifyAutoFilledOfUrlAndPageName(toc1);
		
	}
	@Test(dependsOnMethods = "Step08_Verify_That_Instructor_All_ModulePage_Buttons")
	public void Step09_Verify_Instructor_Edit_ModuleOfCreatedModule() {
		canvas.coursePage.verifyModulePresentAndSelectOptionFromSetting("Edit");
		canvas.modulePage.clickOnCancelAndVerify();
		canvas.coursePage.verifyModulePresentAndSelectOptionFromSetting("Edit");
		canvas.modulePage.verifyAddRequirementButton();
		canvas.modulePage.verifyEditModuleName("Test Add Pre","Test Module Updated");
	}
	@Test(dependsOnMethods = "Step09_Verify_Instructor_Edit_ModuleOfCreatedModule")
	public void Step10_Verify_Instructor_MoveToModueFromSettingIcon() {
		canvas.coursePage.verifyModulePresentAndSelectOptionFromSetting("Move Module...");
		canvas.modulePage.verifyMoveModuleModalPopUp();
		
	}
	@Test(dependsOnMethods = "Step10_Verify_Instructor_MoveToModueFromSettingIcon")
	public void Step11_Verify_That_Instructor_Publish_Module() {
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.modulePage.publishDeployedModule(moduleName);
	}

	@Test(dependsOnMethods = "Step11_Verify_That_Instructor_Publish_Module")
	public void Step12_Instructor_Logout() {
		canvas.leftMenu.logout();
	}
}
