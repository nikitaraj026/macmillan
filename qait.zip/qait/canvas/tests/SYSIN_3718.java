package com.qait.canvas.tests;

//The Instructor gets mapped (via rich content editor flow) within 
//the Macmillan Middle ware (RA ID, LMS ID and LMS Installation course association Info) 
//if necessary, in order to be presented with the Course Listing page.

/*SYSIN-3718
 * As an instructor I need to complete SSO and link my LaunchPad course with my LMS course.
 * I have never used a Macmillan integration but I do have a Macmillan account.
 * I have not been sampled access to LaunchPad though.
 */

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN_3718 extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	
	private String external_Tool, appURL;
	private String mwUserName, mwPassword;
	private String raUserID;
	private String courseName;
	private String instructor, emailInstructor;
	private String password;

	private void _initVars(){
		courseName = "TestCourse_SYSIN_3718";
		instructor = "smokeinst_sysin_3718";
		emailInstructor = "smokeinst_sysin_3718@fake123.com";
		raUserID = "11899936";
		password = "123456";
		external_Tool = getData("external_tool");
		
		appURL = getData("mw_url");
		mwUserName = getData("users.middleware.username");
		mwPassword = getData("users.middleware.password");
		courseName = "TestCourse_SYSIN_3718";
		instructor = "smokeinst3_moodle_nov23";
		emailInstructor = "smokeinst3_moodle_nov23@fake123.com";
		raUserID = "11899936";
		password = "123456";
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Middleware_Application() {
		canvas.launchApplication(appURL);
		canvas.MiddlewareLoginPage.verifyUserIsOnMWLoginPage();
	}
	
	@Test(dependsOnMethods = {"Step01_Launch_Middleware_Application"})
	public void Step02_Login_Into_Middleware_As_Admin() {
		canvas.MiddlewareLoginPage.enterAdminLoginDetailsOnLoginPage(mwUserName, mwPassword);
		canvas.MiddlewareLoginPage.userClicksOnSubmitButtonToLoginIntoMW();
		canvas.MiddlewareLoginPage.verifyMWDashboardPage();
	}
	
	@Test(dependsOnMethods = {"Step02_Login_Into_Middleware_As_Admin"})
	public void Step03_Go_To_User_Mapping_Table() {
		canvas.MiddlewareLoginPage.clickOnAdminToolsButton();
		canvas.MiddlewareLoginPage.verifyAdminToolsHomepage();
		canvas.MiddlewareLoginPage.selectDatabaseTable("User Mapping Listing");
	}
	
	@Test(dependsOnMethods = {"Step03_Go_To_User_Mapping_Table"})
	public void Step04_Admin_Searches_And_Deletes_User_Mapping_Record() {
		canvas.MiddlewareLoginPage.deleteUserMapping(raUserID);
		canvas.MiddlewareLoginPage.closeMiddlewareWindow();
	}
	
	@Test(dependsOnMethods = {"Step04_Admin_Searches_And_Deletes_User_Mapping_Record"})
	public void Step05_Instructor_Launches_Canvas_URL() {
		canvas = new CanvasTestSessionInitiator();
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods = {"Step05_Instructor_Launches_Canvas_URL"})
	public void Step06_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor, password);
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods = {"Step06_Log_In_As_Instructor"})
	public void Step07_Navigate_To_Course_Homepage() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
	}
	
	@Test(dependsOnMethods = {"Step07_Navigate_To_Course_Homepage"})
	public void Step08_Instructor_Clicks_On_Getting_Started() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickGettingStartedLink("LaunchPad");
	}

	@Test(dependsOnMethods = { "Step08_Instructor_Clicks_On_Getting_Started"})
	public void Step09_Instructor_Verifies_Profile_Page() {
		canvas.profilePage.verifyInstructorIsOnInstructorProfilePage();
		canvas.profilePage.fillInstructorInformationAndSubmit("FName", "LName", emailInstructor);
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
	}
	
	@Test(dependsOnMethods = { "Step09_Instructor_Verifies_Profile_Page"})
	public void Step10_Close_Profile_Window_And_Logout() {
		canvas.provisionPage.userClosesCurrentPageAndNavigatesToBasePage();
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}