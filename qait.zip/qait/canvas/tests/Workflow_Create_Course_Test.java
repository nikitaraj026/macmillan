package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Workflow_Create_Course_Test extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;
	String courseName = "Cole";
	String exactCourseName = "Canvas Demo Course (NicoleS)";

	private void _initVars() {
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {
		
		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		//canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_Admin_Is_On_Dashboard(){
		canvas.dashboardPage.verifyAdminDashBoard();
	}

	@Test(dependsOnMethods = "Step02_Verify_Admin_Is_On_Dashboard")
	public void Step03_Verify_User_Navigated_To_Macmillan2_Page(){
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.verifyAdminOverlay();
		canvas.leftMenu.clickMacmillan2();
		canvas.macmillan2Page.verfiyMacmillan2PageTitle();
	}
	
	@Test(dependsOnMethods="Step03_Verify_User_Navigated_To_Macmillan2_Page")
	public void Step04_VerifyFieldsOnMacmillan2Page(){
		canvas.macmillan2Page.verifyUserIsOnMacmillan2Page();
		canvas.macmillan2Page.verifyActiveTab("Courses");
	}
	
	@Test(dependsOnMethods = "Step04_VerifyFieldsOnMacmillan2Page")
	public void Step05_Verify_Menu_Item_Hidden(){
		canvas.macmillan2Page.verifyLeftMenuHidden();
	}
	
	@Test(dependsOnMethods = "Step05_Verify_Menu_Item_Hidden")
	public void Step06_Verify_Menu_Item_Visible(){
		canvas.macmillan2Page.verifyLeftMenuVisible();
	}
	
/*	@Test(dependsOnMethods = "Step06_Verify_Menu_Item_Visible")
	public void Step07_Verify_Enrollmentless_courses_are_Available(){
		canvas.macmillan2Page.verifyEnrollmentlessCoursesAreAvailable();
	}*/
	
	@Test(dependsOnMethods = "Step06_Verify_Menu_Item_Visible")
	public void Step08_Verify_Find_A_Course_Autocomplete(){
		canvas.macmillan2Page.verifyCourseListIsAutoPopulated();
	}
	
	/*@Test(dependsOnMethods = "Step08_Verify_Find_A_Course_Autocomplete")
	public void Step09_Verify_Search_Results_For_Find_A_Course(){
		canvas.macmillan2Page.findACourse(courseName);
		canvas.macmillan2Page.verifyCoursesSearchResults(courseName);
	}*/
	
	@Test(dependsOnMethods = "Step08_Verify_Find_A_Course_Autocomplete")
	public void Step10_Verify_User_Navigated_Course_home_Page_On_Entering_Exact_Course_Name(){
		canvas.macmillan2Page.findACourse(exactCourseName);
		canvas.coursePage.verifyUserIsOnCoursePage(exactCourseName);
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.clickMacmillan2();
	}

	@Test(dependsOnMethods = "Step10_Verify_User_Navigated_Course_home_Page_On_Entering_Exact_Course_Name")
	public void Step11_Verify_Search_Results_For_Find_A_User(){
		canvas.macmillan2Page.clickonPeople();
		canvas.macmillan2Page.findAUser("Kevin Aaron");
		canvas.macmillan2Page.verifyUserSearchResults("Kevin Aaron");
	}
	
	@Test(dependsOnMethods = "Step11_Verify_Search_Results_For_Find_A_User")
	public void Step12_Verify_User_Navigated_All_Users_Page_On_Clicking_Users(){
		canvas.macmillan2Page.clickUsersOnLeftTab();
		canvas.macmillan2Page.verifyActiveTab("People");
	}

	@Test(dependsOnMethods="Step12_Verify_User_Navigated_All_Users_Page_On_Clicking_Users")
	public void Step13_Verify_User_Navigates_To_Statistics_page() {
		canvas.macmillan2Page.clickStatisticsOnLeftTab();
		canvas.macmillan2Page.verifyStatisticsPage();
	}
	
	@Test(dependsOnMethods="Step13_Verify_User_Navigates_To_Statistics_page")
	public void Step14_Verify_Manage_Permission_Page() {
		canvas.macmillan2Page.clickPermissionOnLeftTab();
		canvas.macmillan2Page.verifyManagePermissionPage();
	}
	
	@Test(dependsOnMethods="Step14_Verify_Manage_Permission_Page")
	public void Step15_Verify_Learning_Outcomes_Page() {
		canvas.macmillan2Page.clickOutcomesOnLeftTab();
		canvas.macmillan2Page.verifyLearningOutcomesPage();
	}
	
	@Test(dependsOnMethods="Step15_Verify_Learning_Outcomes_Page")
	public void Step16_Verify_Rubrics_Page() {
		canvas.macmillan2Page.clickRubricsOnLeftTab();
		canvas.macmillan2Page.verifyRubricsPage();
	}
	
	@Test(dependsOnMethods="Step16_Verify_Rubrics_Page")
	public void Step17_Verify_Grading_Standard_Page() {
		canvas.macmillan2Page.clickGradingOnLeftTab();
		canvas.macmillan2Page.verifyGradingStandardsPage();
	}
	
    @Test(dependsOnMethods="Step17_Verify_Grading_Standard_Page")
    public void Step18_Verify_Question_Banks_Page() {
		canvas.macmillan2Page.clickLeftTab("Question Banks");
		canvas.macmillan2Page.verifyQuestionBanksPage();
	}
	
    @Test(dependsOnMethods="Step18_Verify_Question_Banks_Page")
    public void Step19_Verify_Sub_Account_Page() {
		canvas.macmillan2Page.clickLeftTab("Sub-Accounts");
		canvas.macmillan2Page.verifySubAccountPage();
		canvas.macmillan2Page.verifyRedirectionOfMacmillan2Page();
    }
    @Test(dependsOnMethods="Step19_Verify_Sub_Account_Page")
    public void Step20_Verify_Sub_Account__QA_Page() {
		canvas.macmillan2Page.clickLeftTab("Sub-Accounts");
		canvas.macmillan2Page.verifyLeftMenuOption();
		canvas.macmillan2Page.clickOnSubAccountLink("QA");
		canvas.macmillan2Page.verifySubAccountQAContent();
    }
	@Test(dependsOnMethods = "Step20_Verify_Sub_Account__QA_Page")
	public void Step21_Verify_User_Navigated_All_Users_Page_On_Clicking_SubAccount_QA_People(){
		canvas.macmillan2Page.clickUsersOnLeftTab();
		canvas.macmillan2Page.verifyActiveTab("People");
	}

	@Test(dependsOnMethods="Step21_Verify_User_Navigated_All_Users_Page_On_Clicking_SubAccount_QA_People")
	public void Step22_Verify_User_Navigates_To_Statistics_page_Of_SubAccount_QA() {
		canvas.macmillan2Page.clickStatisticsOnLeftTab();
		canvas.macmillan2Page.verifyStatisticsPageForSubAccountQA();
	}
	
	@Test(dependsOnMethods="Step22_Verify_User_Navigates_To_Statistics_page_Of_SubAccount_QA")
	public void Step23_Verify_Manage_Permission_Page_Of_SubAccount_QA() {
		canvas.macmillan2Page.clickPermissionOnLeftTab();
		canvas.macmillan2Page.verifyManagePermissionPage();
	}
	
	@Test(dependsOnMethods="Step23_Verify_Manage_Permission_Page_Of_SubAccount_QA")
	public void Step24_Verify_Learning_Outcomes_Page_Of_SubAccount_QA() {
		canvas.macmillan2Page.clickOutcomesOnLeftTab();
		canvas.macmillan2Page.verifyLearningOutcomesPage();
	}
	
	@Test(dependsOnMethods="Step24_Verify_Learning_Outcomes_Page_Of_SubAccount_QA")
	public void Step25_Verify_Rubrics_Page_Of_SubAccount_QA() {
		canvas.macmillan2Page.clickRubricsOnLeftTab();
		canvas.macmillan2Page.verifyRubricsPage();
	}
	
	@Test(dependsOnMethods="Step25_Verify_Rubrics_Page_Of_SubAccount_QA")
	public void Step26_Verify_Grading_Standard_Page_Of_SubAccount_QA() {
		canvas.macmillan2Page.clickGradingOnLeftTab();
		canvas.macmillan2Page.verifyGradingStandardsPageForSubAccountQA();
	}
	
    @Test(dependsOnMethods="Step26_Verify_Grading_Standard_Page_Of_SubAccount_QA")
    public void Step27_Verify_Question_Banks_Page_Of_SubAccount_QA() {
		canvas.macmillan2Page.clickLeftTab("Question Banks");
		canvas.macmillan2Page.verifyQuestionBanksPage();
	}
    @Test(dependsOnMethods="Step27_Verify_Question_Banks_Page_Of_SubAccount_QA")
    public void Step28_Verify_QA_Link_AfterClicking_SubAccount_When_On_QA_SubAccount() {
		canvas.macmillan2Page.clickLeftTab("Sub-Accounts");
		canvas.macmillan2Page.verifyQALink();
		canvas.macmillan2Page.clickOnSubAccountLink("QA");
		canvas.macmillan2Page.verifySubAccountQAContent();
	}
    @Test(dependsOnMethods="Step28_Verify_QA_Link_AfterClicking_SubAccount_When_On_QA_SubAccount")
    public void Step29_Verify_Admin_Tools_PAge_Content() {
		canvas.macmillan2Page.clickLeftTab("Admin Tools");
		canvas.macmillan2Page.verifyAdminToolsPageContent();
	}
    @Test(dependsOnMethods="Step29_Verify_Admin_Tools_PAge_Content")
    public void Step30_Verify_Admin_Tools_Logging_Tab_Content() {
		canvas.macmillan2Page.clickOnTab("Logging");
		canvas.macmillan2Page.verifyloggingTabContent();
	}
    @Test(dependsOnMethods="Step30_Verify_Admin_Tools_Logging_Tab_Content")
    public void Step31_Verify_Admin_Tools_Logging_Tab_Content() {
		canvas.macmillan2Page.clickOnTab("Logging");
		canvas.macmillan2Page.verifyloggingTabContent();
	}
    @Test(dependsOnMethods="Step31_Verify_Admin_Tools_Logging_Tab_Content")
    public void Step32_Verify_Admin_Tools_Logging_Tab_Content() {
    	canvas.macmillan2Page.clickLeftTab("Settings");
		canvas.macmillan2Page.verifySettingsContentOfQASubAccount();
		canvas.macmillan2Page.verifyRedirectionOfMacmillan2Page();
	}
    @Test(dependsOnMethods="Step32_Verify_Admin_Tools_Logging_Tab_Content")
    public void Step33_Verify_Terms_Content_Of_Macmillan2_Page() {
    	canvas.macmillan2Page.clickLeftTab("Terms");
		canvas.macmillan2Page.verifyTermsContentPage();
	}
    @Test(dependsOnMethods="Step33_Verify_Terms_Content_Of_Macmillan2_Page")
    public void Step34_Verify_Authentication_Content_Of_Macmillan2_Page() {
    	canvas.macmillan2Page.clickLeftTab("Authentication");
		canvas.macmillan2Page.verifyAuthenticationContentPage();
	}
    @Test(dependsOnMethods="Step34_Verify_Authentication_Content_Of_Macmillan2_Page")
    public void Step35_Verify_SIS_Import_Content_Of_Macmillan2_Page() {
    	canvas.macmillan2Page.clickLeftTab("SIS Import");
		canvas.macmillan2Page.verifySISImportContentPage();
	}
    @Test(dependsOnMethods="Step35_Verify_SIS_Import_Content_Of_Macmillan2_Page")
    public void Step36_Verify_Themes_Link_Content_Of_Macmillan2_Page() {
    	canvas.macmillan2Page.clickLeftTab("Themes");
		canvas.macmillan2Page.verifyThemesContentPage();
	}
    @Test(dependsOnMethods="Step36_Verify_Themes_Link_Content_Of_Macmillan2_Page")
    public void Step37_Verify_Developer_Keys_Content_Of_Macmillan2_Page() {
    	canvas.macmillan2Page.clickLeftTab("Developer Keys");
		canvas.macmillan2Page.verifyDeveloperKeysContentPage();
	}
    @Test(dependsOnMethods="Step37_Verify_Developer_Keys_Content_Of_Macmillan2_Page")
    public void Step38_Verify_New_Course_Content_Of_Macmillan2_Page() {
    	canvas.macmillan2Page.verifyRedirectionOfMacmillan2Page();
		canvas.macmillan2Page.clickOnAddNewCourse();
		canvas.macmillan2Page.verifyAddNewCourseModalWindow();
	}
    @Test(dependsOnMethods="Step38_Verify_New_Course_Content_Of_Macmillan2_Page")
    public void Step39_Verify_New_Course_SubAccount_DropDown_option() {
    	canvas.macmillan2Page.verifyNewCourseSubAccountDropDownOptionAndSelectedValue("QA");
	}
    @Test(dependsOnMethods="Step39_Verify_New_Course_SubAccount_DropDown_option")
    public void Step40_Verify_New_Course_Enrollment_DropDown_option() {
    	canvas.macmillan2Page.verifyNewCourseEnrollmentDropDownOption();
	}
    //@Test(dependsOnMethods="Step40_Verify_New_Course_Enrollment_DropDown_option")
    public void Step41_Verify_New_Course_AddCourseButton_Functionality() {
    	canvas.macmillan2Page.clickOnButtonOFModalPopUp("2","Add Course");
    	canvas.macmillan2Page.verifyRequiredMessageField();
	}
  
    //@Test(dependsOnMethods="Step41_Verify_New_Course_AddCourseButton_Functionality")
    public void Step42_Verify_New_Course_CancelButton_Functionality() {
    	canvas.macmillan2Page.clickOnButtonOFModalPopUp("2","Cancel");
    	canvas.macmillan2Page.verifyCancelButton();
	}
/*	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}*/
}
