package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Workflow_Create_User_Test extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;
	String courseName = "Cole";
	String exactCourseName = "Canvas Demo Course (NicoleS)";

	private void _initVars() {
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {

		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
		// canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_User_Navigated_To_Macmillan2_Page() {
		canvas.dashboardPage.verifyAdminDashBoard();
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.verifyAdminOverlay();
		canvas.leftMenu.clickMacmillan2();
		canvas.macmillan2Page.verfiyMacmillan2PageTitle();
	}

	@Test(dependsOnMethods = "Step02_Verify_User_Navigated_To_Macmillan2_Page")
	public void Step03_VerifyFieldsOnMacmillan2Page() {
		canvas.macmillan2Page.verifyUserIsOnMacmillan2Page();
		canvas.macmillan2Page.verifyActiveTab("Courses");
	}

	@Test(dependsOnMethods = "Step03_VerifyFieldsOnMacmillan2Page")
	public void Step04_Verify_New_User_Content_Of_Macmillan2_Page() {
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.verifyAddNewUserModalWindow();
	}

	@Test(dependsOnMethods = "Step04_Verify_New_User_Content_Of_Macmillan2_Page")
	public void Step05_Verify_Sortable_And_Dispaly_Name() {
		canvas.macmillan2Page.enterFullName("Test Sort");
		canvas.macmillan2Page.verifyDisplayAndSortableName();
	}

	@Test(dependsOnMethods = "Step05_Verify_Sortable_And_Dispaly_Name",alwaysRun=true)
	public void Step06_Verify_Invalid_Email_Address() {
		canvas.macmillan2Page.enterEmailAddress("Test Sort #$$$%%^#%$");
		canvas.macmillan2Page.clickOnButtonOFModalPopUp("1","Add User");
		canvas.macmillan2Page.verifyInvalidEmailAddress();
	}

	@Test(dependsOnMethods = "Step06_Verify_Invalid_Email_Address")
	public void Step07_Verify_New_Course_CancelButton_Functionality() {
		canvas.macmillan2Page.clickOnButtonOFModalPopUp("1","Cancel");
		canvas.macmillan2Page.verifyCancelButton();
	}
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}
