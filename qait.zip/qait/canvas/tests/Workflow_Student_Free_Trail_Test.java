package com.qait.canvas.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

public class Workflow_Student_Free_Trail_Test extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String external_Tool;
	private String bookTitle;;
	private String courseName;
	private String instructor, emailInstructor, instructorName,
			studentFirstName, studentLastName;
	private String firstStudentLogin, emailFirstStudent, quiz2CorrectAnswer1,
			quiz1CorrectAnswer1, quiz2Grade;
	private String password, inst_password, px_password;
	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	private String pxCourseName, courseNumber, sectionNumber, academicTerm,
			school;
	String assignmentName;
	String chapterName, chapterIntroduction, chapterContent;
	String quizTitle1, quizTitle2, bookIdentifier;
	String chapterNumber, selectQuestionFrom;
	String imgURL = "http://www.joomlaworks.net/images/demos/galleries/abstract/7.jpg";
	String moduleName;

	private void _initVars(String book) {
		Long timeStamp = System.currentTimeMillis();
		// courseName = "TestCourse_" + timeStamp;
		studentFirstName = "FSName";
		studentLastName = "LSName";
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";
		instructorEmail = canvas.coursePage.readDataFromYaml("EmailInst");
		instructorName = getData("users.instructor.name1");
		instructorPassword = canvas.coursePage
				.readDataFromYaml("inst_password");
		instructorPasswordLaunchpad = canvas.coursePage
				.readDataFromYaml("PX_Password");
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		academicTerm = "Fall 2016";
		external_Tool = getData("external_tool");
		school = "TEST University (New York, NY)";
		courseName = getData("courseName");
		instructorName = getData("users.instructor.name1");
		instructor = getData("users.instructor.user_name1");
		// instructor = "Autoinst_"+timeStamp;
		// emailInstructor = instructor + "@fake123.com";
		emailInstructor = getData("users.instructor.user_email1");
		// firstStudentLogin = "StudFirst" + timeStamp;
		firstStudentLogin = canvas.coursePage
				.readDataFromYaml("FirstStudentLogin");
		// emailFirstStudent = firstStudentLogin + "@fake123.com";
		emailFirstStudent = canvas.coursePage
				.readDataFromYaml("EmailFirstStudent");
		inst_password = getData("users.instructor.password");
		password = getData("users.student.password");
		DashBoardPageAction.courseName = courseName;
		px_password = "Password1!";

		// data.put("InstUserName", instructor);
		// data.put("EmailInst", emailInstructor);
		// data.put("FirstStudentLogin", firstStudentLogin);
		// data.put("EmailFirstStudent", emailFirstStudent);
		// data.put("Password", password);
		// data.put("inst_password", inst_password);
		// data.put("PX_Password", px_password);
		// data.put("CourseName", courseName);
		String bookIdentifier = null;
		if (book.contains("myers11e")) {
			bookTitle = getData("bookTitleLP");
			bookIdentifier = "myers";
			quiz2CorrectAnswer1 = getData(bookIdentifier
					+ ".quiz2.correctAnswer1");
			quiz1CorrectAnswer1 = getData(bookIdentifier
					+ ".quiz1.correctAnswer1");
			quiz2Grade = getData(bookIdentifier + ".quiz2.grade");
		} else {
			bookTitle = getData("bookTitleWriterHelp");
			bookIdentifier = "lunsford";
		}

		if (bookIdentifier.contains("myers")) {
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier
					+ ".TOC_chapter5_introduction");
			chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		} else {
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		}
		moduleName = getData("moduleName");
	}

	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		_initVars(book);
		// canvas.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	// @Test
	// public void Step01_Launch_Application() {
	// canvas.launchApplication();
	// canvas.loginPage.verifyLoginPage();
	// }
	//
	// @Test(dependsOnMethods = { "Step01_Launch_Application" })
	// public void Step02_Log_In_As_Admin() {
	// canvas.loginPage.loginToTheApplication(
	// getData("users.admin.user_name"),
	// getData("users.admin.password"));
	// canvas.dashboardPage.verifyDashboardPage();
	//
	// }
	//
	// @Test(dependsOnMethods = { "Step02_Log_In_As_Admin" })
	// public void Step03_Go_To_Macmillan2_Courses() {
	// canvas.leftMenu.clickOnAdminLeftMenu();
	// canvas.leftMenu.clickMacmillan2();
	// }
	//
	// @Test(dependsOnMethods = { "Step03_Go_To_Macmillan2_Courses" })
	// public void Step04_Verify_Add_New_Course_Modal_Window() {
	// canvas.macmillan2Page.clickOnAddNewCourse();
	// canvas.macmillan2Page.verifyAddNewCourseModalWindow();
	// }
	//
	// @Test(dependsOnMethods = { "Step04_Verify_Add_New_Course_Modal_Window" })
	// public void Step05_Create_Course() {
	// // canvas.macmillan2Page.AddNewCourse(courseName, " "+subAccount);
	// canvas.macmillan2Page.clickOnButtonOverPopupSuingJsWithIndex("0");// For
	// // add
	// // course
	// // cancel=0,add
	// // course=1,For
	// // add
	// // user
	// // cancel=2,add
	// // user=3,
	// }
	//
	// @Test(dependsOnMethods = { "Step05_Create_Course" })
	// public void Step06_Verify_Add_New_User_Modal_Window() {
	// canvas.macmillan2Page.clickOnAddNewUser();
	// canvas.macmillan2Page.verifyAddNewUserModalWindow();
	// }
	//
	// @Test(dependsOnMethods = { "Step06_Verify_Add_New_User_Modal_Window" })
	// public void Step07_Admin_Create_1_Users_Student() {
	// canvas.macmillan2Page.createUser(firstStudentLogin, emailFirstStudent);
	// }
	//
	// @Test(dependsOnMethods = { "Step07_Admin_Create_1_Users_Student" })
	// public void Step08_Admin_Redirects_To_Newly_Created_Course() {
	// canvas.macmillan2Page.enterIntoCourse(courseName);
	// }
	//
	// @Test(dependsOnMethods = {
	// "Step08_Admin_Redirects_To_Newly_Created_Course" })
	// public void Step09_Publish_Course() {
	// canvas.coursePage.publishCourse();
	// }
	//
	// @Test(dependsOnMethods = { "Step09_Publish_Course" })
	// public void Step10_Admin_Redirects_To_People_Page() {
	// canvas.coursePage.clickOnPeopleNavigationLink();
	// canvas.coursePage.verifyUserIsOnPeoplePage();
	// canvas.macmillan2Page.removeAllUser();
	// }
	//
	// @Test(dependsOnMethods = { "Step10_Admin_Redirects_To_People_Page" })
	// public void Step11_Verify_Add_People_Modal_Window() {
	// canvas.coursePage.clickOnPeopleButton();
	// canvas.coursePage.verifyAddPeopleModalWindow();
	// }
	//
	// @Test(dependsOnMethods = { "Step11_Verify_Add_People_Modal_Window" })
	// public void Step12_Verify_User_Information() {
	// canvas.coursePage.enterUserDetails("Teacher", emailInstructor);
	// canvas.coursePage.verifyUserDetails(emailInstructor);
	// }
	//
	// @Test(dependsOnMethods = { "Step12_Verify_User_Information" })
	// public void Step13_Verify_Instructor_Is_Added_To_Course() {
	// canvas.coursePage.clickOnAddUserButton();
	// canvas.coursePage.verifyUserIsAddedToCourse(instructorName);
	// }
	//
	// @Test(dependsOnMethods = { "Step13_Verify_Instructor_Is_Added_To_Course"
	// })
	// public void Step14_Admin_Enroll_One_Student_To_Course() {
	// canvas.coursePage.clickOnPeopleButton();
	// canvas.coursePage.enterUserDetails("Student", emailFirstStudent);
	// canvas.coursePage.clickOnAddUserButton();
	// // canvas.coursePage.verifyStudentEnrollment();
	//
	// }
	//
	//
	// @Test(dependsOnMethods = { "Step14_Admin_Enroll_One_Student_To_Course" })
	// public void Step15_Admin_Add_Login_For_Three_Student() {
	// canvas.coursePage.clickOnPeopleNavigationLink();
	// canvas.coursePage.clickOnUserNameLink(firstStudentLogin);
	// canvas.coursePage.verifyUserDetailPage(firstStudentLogin);
	// canvas.coursePage.clickOnMoreUserDetails();
	// canvas.coursePage.verifyMembershipLoginInformationSection();
	// canvas.coursePage.clickOnAddLoginLink();
	// canvas.coursePage.verifyAddLoginModalWindow();
	//
	// canvas.coursePage.enterLoginDetails(firstStudentLogin, password);
	// canvas.coursePage.clickOnAddLoginButton();
	// canvas.coursePage.verifyUserLogin(firstStudentLogin);
	// }
	//
	// @Test(dependsOnMethods = { "Step15_Admin_Add_Login_For_Three_Student" })
	// public void Step16_Admin_Log_Out_Canvas_Application() {
	// canvas.leftMenu.logout();
	// canvas.loginPage.verifyLoginPage();
	// }
	// @Test(dependsOnMethods = { "Step16_Admin_Log_Out_Canvas_Application" })
	// public void Step17_Launch_Application() {
	// canvas.launchApplication();
	// canvas.loginPage.verifyLoginPage();
	// }
	//
	// @Test(dependsOnMethods = "Step17_Launch_Application")
	// public void Step18_Log_In_As_Instructor() {
	// canvas.loginPage.loginToTheApplication(instructor, "12345678");
	// }
	//
	// @Test(dependsOnMethods = "Step18_Log_In_As_Instructor")
	// public void Step19_Instructor_Accepts_AgreeTerm() {
	// canvas.dashboardPage.clickOnIAgreeTerm();
	// canvas.dashboardPage.clickOnCancelButton();
	// }
	//
	// @Test(dependsOnMethods = "Step19_Instructor_Accepts_AgreeTerm")
	// public void Step20_Instructor_Go_To_Dashboard_Page() {
	// // canvas.loginPage.loginToTheApplication(instructorUserName,
	// // instructorPassword);
	// // canvas.dashboardPage.acceptTermsOfUse();
	// canvas.dashboardPage.verifyDashboardPage();
	// }
	//
	// @Test(dependsOnMethods = "Step20_Instructor_Go_To_Dashboard_Page")
	// public void Step21_Instructor_Go_To_Course_Page() {
	// canvas.dashboardPage.acceptInvite();
	// canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	// }
	//
	// @Test(dependsOnMethods = "Step21_Instructor_Go_To_Course_Page")
	// public void Step22_Instructor_Go_To_Course_Details_Page() {
	// canvas.leftMenu.clickOnCoursesLeftMenu();
	// canvas.leftMenu.clickOnUserCourse(courseName);
	// canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	// canvas.coursePage.clickSettingsOnCoursePage();
	// canvas.coursePage.verifyCourseDetailsPage();
	// }
	//
	// @Test(dependsOnMethods = "Step22_Instructor_Go_To_Course_Details_Page")
	// public void Step23_Instructor_Go_To_Navigation_Tab() {
	// canvas.coursePage.clickNavigationTab();
	// canvas.coursePage.verifyNavigationTab();
	// }
	//
	// @Test(dependsOnMethods = "Step23_Instructor_Go_To_Navigation_Tab")
	// public void Step24_Instructor_Add_Macmillan_Tool() {
	// boolean
	// value=canvas.leftMenu.menuIsPresentOrNotAtLeftSide(external_Tool);
	// if(value)
	// {
	// canvas.macmillan2Page.clickLeftTab("Settings");
	// canvas.addMacTools.clickOnCourseStatisticsTab("Navigation");
	// canvas.coursePage.enableMacmillanTools(external_Tool);
	// }
	// }
	//
	// @Test(dependsOnMethods = "Step24_Instructor_Add_Macmillan_Tool")
	// public void Step25_Instructor_Navigate_To_Macmillan_Tool_Page() {
	// canvas.coursePage.enterIntoToolsSection(external_Tool);
	// canvas.toolsPage.verifyToolsPage();
	// canvas.toolsPage.runHandleSecurityExe();
	// }
	//
	// @Test(dependsOnMethods =
	// "Step25_Instructor_Navigate_To_Macmillan_Tool_Page")
	// public void Step26_Instructor_Navigates_To_Token_Registration_page() {
	// canvas.toolsPage.clickGettingStartedLink();
	// canvas.toolsPage.changeWindow(1);
	// //
	// canvas.provisionPage.fillNewInstructorDetails("autoInst","canvas","autoloadinst_canvas@fake123.com");
	// canvas.provisionPage.verifyTokenRegistrationPage();
	// }
	//
	// @Test(dependsOnMethods =
	// "Step26_Instructor_Navigates_To_Token_Registration_page")
	// public void Step27_Intructor_Navigate_To_Course_Integration_Page() {
	// canvas.provisionPage.authenticateToken();
	// canvas.provisionPage.verifyProvisionPageOpens();
	// }
	//
	// @Test(dependsOnMethods =
	// "Step27_Intructor_Navigate_To_Course_Integration_Page")
	// public void Step28_Instructor_Create_Course() {
	// canvas.provisionPage.createNewCourse(bookTitle, pxCourseName,
	// courseNumber, sectionNumber, instructorName,
	// academicTerm, false, "", school);
	// // courseTitle must be short enough so that <br> tag not added in course
	// // name in table
	// canvas.provisionPage.verifyCourseCreated(pxCourseName);
	// }
	//
	// @Test(dependsOnMethods = "Step28_Instructor_Create_Course")
	// public void
	// Step29_Instructor_Associate_Course_And_Verify_Course_Association() {
	// canvas.provisionPage.associateCourse(pxCourseName);
	// canvas.toolsPage.verifyToolsPageAfterCousreAssociation();
	// }
	//
	// @Test(dependsOnMethods =
	// "Step29_Instructor_Associate_Course_And_Verify_Course_Association")
	// public void Step30_Verify_Instructor_Navigate_To_Launchpad() {
	// if (bookTitle.contains("CM LaunchPad for Psychology")) {
	// canvas.toolsPage.clickLaunchPad();
	// } else {
	// canvas.toolsPage.clickWritesHelp();
	// }
	// canvas.coursePage.userNavigateToPxWindow();
	// }
	//
	// @Test(dependsOnMethods =
	// "Step30_Verify_Instructor_Navigate_To_Launchpad")
	// public void
	// Step31_Verify_That_Instructor_Is_Able_To_Create_And_Assign_Assignment() {
	// if (bookTitle.contains("CM LaunchPad for Psychology")) {
	// canvas.pxPage.verifyUserIsOnCourseHomePage(pxCourseName);
	// canvas.pxPage.createQuizAssignment("Quiz", quizTitle2, true, "10", "15",
	// true, chapterNumber,
	// selectQuestionFrom);
	// canvas.pxPage.userClosesPXWindowAndGoToPrimaryWindow();
	// } else {
	// canvas.pxPage.clickOnAssignmentsTab();
	// canvas.assignmentPage.clickOnAddNewAssignmentLink();
	// // canvas.assignmentPage.embedImage(imgURL);
	// assignmentName = canvas.assignmentPage.provideTitle();
	// canvas.assignmentPage.expandAssignment(assignmentName);
	// canvas.pxPage.clickOnHomeButtonTab();
	// canvas.pxPage.createQuizAssignmentWritershelp("Quiz", quizTitle1, true,
	// assignmentName, "10");
	// }
	// }
	//
	//
	//
	// @Test(dependsOnMethods =
	// "Step31_Verify_That_Instructor_Is_Able_To_Create_And_Assign_Assignment")
	// public void Step32_Instructor_Navigates_To_Macmillan_Content_Page() {
	// canvas.toolsPage.clickMacmillanContent();
	// canvas.toolsPage.verifyMacmillanContentPage();
	// }
	//
	// @Test(dependsOnMethods =
	// "Step32_Instructor_Navigates_To_Macmillan_Content_Page")
	// public void
	// Step33_Verify_Instructor_Successfully_Able_To_Deploy_Assignment() {
	// canvas.contentTocPage.ExpandToc("Assignments");
	// canvas.contentTocPage.selectContentTOC(quizTitle2);
	// canvas.contentTocPage.clicksOnAddSelectedContent();
	// canvas.contentTocPage.createNewModule(moduleName);
	// canvas.contentTocPage.selectModuleAndDeploy(moduleName);
	// canvas.contentTocPage.userClosesCurrentPageAndNavigatesToBasePage();
	// }
	//
	// @Test(dependsOnMethods =
	// "Step33_Verify_Instructor_Successfully_Able_To_Deploy_Assignment")
	// public void Step34_Verify_That_Instructor_Publish_Module() {
	// canvas.coursePage.clickModulesOnCoursePage();
	// canvas.modulePage.publishDeployedModule(moduleName);
	// }
	//
	// @Test(dependsOnMethods = "Step34_Verify_That_Instructor_Publish_Module")
	// public void Step35_Instructor_Logout() {
	// canvas.leftMenu.logout();
	// canvas.closeBrowserSession();
	// }

	@Test
	// (dependsOnMethods = "Step35_Instructor_Logout")
	public void Step36_Launch_Application() {
		canvas = new CanvasTestSessionInitiator();
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step36_Launch_Application" })
	public void Step37_Log_In_As_Student() {
		canvas.loginPage.loginToTheApplication(firstStudentLogin, "12345678");
		// canvas.leftMenu.goToUserCourse(courseName);
	}

	@Test(dependsOnMethods = "Step37_Log_In_As_Student")
	public void Step38_Student_Accepts_AgreeTerm() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}

	@Test(dependsOnMethods = "Step38_Student_Accepts_AgreeTerm")
	public void Step39_Student_Go_To_Dashboard_Page() {
		canvas.loginPage.loginToTheApplication(firstStudentLogin, password);
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyDashboardPage();
		canvas.dashboardPage.clickOnCanvasLogo();
		canvas.dashboardPage.verifyDashboardPage();
		canvas.dashboardPage.clickOnCalendarLink();
		canvas.dashboardPage.verifyCalendarLinkFields();
		canvas.dashboardPage.clickOnPlusIcon();
		canvas.dashboardPage.verifyPlusIconModalContent();
		canvas.dashboardPage.verifyCreateNewEvent("Event_Test");
		canvas.dashboardPage.clickOnPlusIcon();
		canvas.dashboardPage.clickOnMoreOptions();
		canvas.dashboardPage
				.verifyMoreOPtionsFieldOfEditEvent("Event_MoreOptions");
	}

	@Test(dependsOnMethods = "Step39_Student_Go_To_Dashboard_Page")
	public void Step40_Student_Go_To_Course_Page() {
		canvas.dashboardPage.acceptInvite();
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step40_Student_Go_To_Course_Page")
	public void Step41_Account_Tab_Verification() {
		canvas.leftMenu.clickAccountLogo();
		canvas.accountPage.verifyAccountTabContent();
		canvas.accountPage.clickOnCrossIcon();
		canvas.accountPage.verifyAccountTabContentNotDisplayed();
	}

	@Test(dependsOnMethods = "Step41_Account_Tab_Verification")
	public void Step42_Verify_User_is_On_Setting_Tab() {
		canvas.leftMenu.clickAccountLogo();
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
		canvas.accountPage.verifyUserIsOnAccountPage();
		canvas.accountPage.clickOnEmailLinkFromSettingsPanel();
		canvas.accountPage.verifyConfirmEmailAddressPopup(firstStudentLogin);
		canvas.accountPage.clickOnReSendConfirmationLink();
		canvas.accountPage
				.verifyMsgToast("Done! Message may take a few minutes.");
		canvas.accountPage.clickOnOkThanksButton();
		canvas.accountPage.verifyOkThanksButtonFunctionality();
		canvas.accountPage.clickOnAddEmailAddressButton();
		canvas.accountPage.verifyAddEmailAddressModalPopup("test@fake123.com");
		canvas.accountPage.clickOnAddEmailAddressButton();
		canvas.accountPage.verifyTextSmsTabOfAddEmailAddress("1234567890");
	}

	@Test(dependsOnMethods = "Step42_Verify_User_is_On_Setting_Tab")
	public void Step43_Verify_Fields_Are_Available_On_Clicking_Edit_Settings_Button() {
		canvas.accountPage.clickOnEditSettingsButton();
		canvas.accountPage.clickOnCancelButtonOfEditSettings();
		canvas.accountPage
				.verifyCancelButtonFunctionalityOfStudentSettingsPage();
		canvas.accountPage.clickOnEditSettingsButton();
		canvas.accountPage.verifyFieldsOnStudentSettingsPage();
		canvas.accountPage.verifyEditFieldOFSettingPage(firstStudentLogin,
				password, password + "9");
		canvas.leftMenu.logout();
		canvas.loginPage.loginToTheApplication(firstStudentLogin, password
				+ "9");
		canvas.dashboardPage.verifyDashboardPage();
		canvas.leftMenu.clickAccountLogo();
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
	}

	@Test(dependsOnMethods = "Step43_Verify_Fields_Are_Available_On_Clicking_Edit_Settings_Button")
	public void Step44_VerifyDownloadSubmissionPageNavigation() {
		canvas.accountPage.verifyDownloadSubmissionPage();
		canvas.leftMenu.clickAccountLogo();
		canvas.leftMenu.clickOnSettingsFromAccountPanel();
	}

	@Test(dependsOnMethods = "Step44_VerifyDownloadSubmissionPageNavigation")
	public void Step45_VerifyDeleteMyAccountPage() {
		canvas.accountPage.verifyDeleteMyAccountPage();
	}

	@Test(dependsOnMethods = "Step45_VerifyDeleteMyAccountPage")
	public void Step46_Verify_User_is_On_NotificationsLink() {
		canvas.leftMenu.clickAccountLogo();
		canvas.accountPage.clickNotificationsFromLeftPanel();
		canvas.accountPage.verfiyNotificationPageTitle();
	}

	@Test(dependsOnMethods = "Step46_Verify_User_is_On_NotificationsLink")
	public void Step47_Verify_User_is_On_FilesLink() {
		canvas.leftMenu.clickAccountLogo();
		canvas.accountPage.clickFilesFromLeftPanel();
		canvas.accountPage.verfiyFilesPageTitle();
	}

	@Test(dependsOnMethods = "Step47_Verify_User_is_On_FilesLink")
	public void Step48_Verify_User_is_On_FilesLink() {
		canvas.leftMenu.clickAccountLogo();
		canvas.accountPage.clickePortfoliosFromLeftPanel();
		canvas.accountPage.verfiyePortfoliosPageTitle();
	}
	@Test(dependsOnMethods = "Step47_Verify_User_is_On_FilesLink")
	public void Step49_Verify_Inbox_Fields() {
		canvas.leftMenu.clickOnInboxLeftMenu();
		canvas.leftMenu.verifyInboxPage(courseName);
	}
	@Test(dependsOnMethods = "Step47_Verify_User_is_On_FilesLink")
	public void Step50_Verify_Help_Overlay() {
		canvas.leftMenu.clickOnHelpLeftMenu();
		canvas.leftMenu.verifyHelpOverlay();
		canvas.leftMenu.clickOnHelpLeftOption("Ask Your Instructor a Question");
		canvas.leftMenu.verifyFieldsOfAskYourInstQuestion();
		canvas.leftMenu.clickOnHelpLeftOption("Report a Problem");
		canvas.leftMenu.verifyFieldsOfReportAProblem();
		canvas.leftMenu.clickOnHelpLeftOption("Submit a Feature Idea");
		canvas.leftMenu.verifyFieldsOfSubmitAFeatureIdea();
		canvas.leftMenu.clickOnHelpLeftOption("Search the Canvas Guides");
		canvas.leftMenu.verifyFieldsOfSearchTheCanvasGuides();
	}
	@Test(dependsOnMethods = "Step48_Verify_User_is_On_FilesLink")
	public void Step49_User_Is_On_Courses_Page() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.verifyCoursesOverlay();
		canvas.leftMenu.clickOnUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnAllCourses();
		canvas.accountPage.verifyAllCourses(courseName);
	}

	@Test(dependsOnMethods = "Step48_Verify_User_is_On_FilesLink")
	public void Step49_Student_Attempt_Assignment() {
		canvas.toolsPage.runHandleSecurityExe();
		canvas.coursePage.clickAssignmentsOnCoursePage();
		canvas.coursePage.clickOnAssignmentLink(quizTitle2);
	}

	@Test(dependsOnMethods = "Step49_Student_Attempt_Assignment")
	public void Step50_Verify_That_Student_Complete_SSO() {
		canvas.onboardingPage.newMWStudent(emailFirstStudent);
		canvas.onboardingPage.verifyEulaContentDisplayed();
		canvas.onboardingPage.agreeLegalTerms();
		canvas.onboardingPage.verifyTitle("Register");
		canvas.onboardingPage.fillFirstNameLastNameAndPassword(
				studentFirstName, studentLastName, px_password);
		canvas.onboardingPage.fillConfirmEmailAndPassword(emailFirstStudent,
				px_password);
		canvas.onboardingPage.clickRegister();
		canvas.studentAccessGrantPage.clickRequestFreeTrial();
		canvas.studentAccessGrantPage.clickContinueToSite();
		canvas.pxPage.userNavigateToPxWindow();
	}

	@Test(dependsOnMethods = { "Step50_Verify_That_Student_Complete_SSO" })
	public void Step51_Student_Attempt_Manual_Quiz() {
		canvas.fnePage.verifyStudentIsOnQuizStartPage();
		canvas.fnePage.attemptQuizCorrectly(quiz2CorrectAnswer1);
		canvas.fnePage.clickDoneButton();
		canvas.fnePage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = "Step51_Student_Attempt_Manual_Quiz")
	public void Step52_Student_Logout_LaunchPad() {
		canvas.pxPage.launchPadLogout();
	}

	@Test(dependsOnMethods = "Step52_Student_Logout_LaunchPad")
	public void Step53_Student_Logout_Canvas() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step53_Student_Logout_Canvas")
	public void Step54_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor, "12345678");
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step54_Log_In_As_Instructor")
	public void Step55_Go_To_Course_Homepage() {
		canvas.leftMenu.goToUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step55_Go_To_Course_Homepage")
	public void Step56_Go_To_Macmillan_Tools_Page_And_Refresh_Grades() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.clickOnMacmillanGradeRefreshLink();
		canvas.toolsPage.verifyGradeRefreshPage();
		canvas.toolsPage
				.clickSelectedButtonOnMacmillanHigherEducationGradeSyncRefresh();
		canvas.toolsPage
				.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle2);
		canvas.toolsPage
				.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
	}

	@Test(dependsOnMethods = "Step56_Go_To_Macmillan_Tools_Page_And_Refresh_Grades")
	public void Step57_Verify_Grades_In_Gradebook() {
		canvas.coursePage.clickGradesOnCoursePage();
		canvas.coursePage.verifyGradesInCanvasGradebook(firstStudentLogin,
				quizTitle2, quiz2Grade);
	}

	@Test(dependsOnMethods = "Step57_Verify_Grades_In_Gradebook")
	public void Step58_Instructor_Logout() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		// canvas.closeBrowserSession();
	}
}
