//package com.qait.canvas.tests;
//
//public class Check {
//	public static void main(String[] args) {
//		String s = "ajit"+1;
//		String value=""+function(s);
//	}
//	static int i=0;
//	public static char function(String str){
////		int length=str.length()-i--;
////		if(str.charAt(length)='')
////			return str.charAt(length);
////		else{
////			return function(str.charAt(length));
////		}
//	}
//
//}
//
