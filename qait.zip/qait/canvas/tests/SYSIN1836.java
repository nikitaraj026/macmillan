package com.qait.canvas.tests;

//The Instructor gets mapped (via the Getting Started flow) within the Macmillan 
//Middle ware (RA ID, LMS ID and LMS Installation course association Info) if necessary,
//in order to be presented with the Course Listing page.

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1836 extends Parent_Test{
	/*
	CanvasTestSessionInitiator canvas;
	private Long timeStamp = System.currentTimeMillis();
	private String courseName;
	private String instructor, instructorEmail, instructorPassword;
	private String externalTool;
	private String firstName, lastName, registerPassword;
	
	private void _initVars(){
		courseName = getData("course.nonAssociated1");
		instructor = "AutoInst_SYIN1836_" + timeStamp;
		instructorPassword = getData("users.instructor.password");
		instructorEmail = instructor + "@fake123.com";
		externalTool = getData("external_tool");
		firstName = "FName";
		lastName = "LName";
		registerPassword = getData("users.instructor.registerPassword");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();

	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step02_Log_In_As_Admin"})
	public void Step03_Admin_Create_A_New_Instructor_And_Enroll_Into_Course() {
		canvas.leftMenu.clickLeftMenu("Admin");
		canvas.leftMenu.clickMacmillan2();
		canvas.dashboardPage.createUser(instructor,instructorEmail);
		canvas.dashboardPage.enterIntoCourse(courseName);
		canvas.dashboardPage.addPeople("Teacher", instructorEmail);
		canvas.dashboardPage.createLoginInfoForUser(instructor, "123456");
	}
	
	@Test(dependsOnMethods={"Step03_Navigate_To_Account_Create_A_New_Instructor_And_Enroll_Into_Course"})
	public void Step04_Admin_Log_Out() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step04_User_Log_Out"})
	public void Step05_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor,instructorPassword);
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
		canvas.dashboardPage.acceptInvite();
	}

	@Test(dependsOnMethods = { "Step05_Log_In_As_Instructor" })
	public void Step06_Go_To_Course_Page() {
		canvas.leftMenu.goToUserCourse(courseName);
	}
	
	@Test(dependsOnMethods = { "Step06_Go_To_Course_Page" })
	public void Step07_Go_To_Tools_Tab() {
		canvas.coursePage.enterIntoToolsSection(externalTool);
	}
	
	@Test(dependsOnMethods = { "Step07_Go_To_Tools_Tab" })
	public void Step08_Getting_Started() {
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickGettingStartedLink();
	}
	
	@Test(dependsOnMethods = { "Step08_Getting_Started" })
	public void Step09_Pass_Instructor_Profile_Page() {
		canvas.MacmillanHigherEducationInstructorProfile.fillInstructorInformationAndSubmit(firstName, lastName, instructorEmail);
		canvas.MacmillanHigherEducationInstructorProfile.verifyProfilePageAfterInstructorIsNotRecognized();
		canvas.MacmillanHigherEducationInstructorProfile.userClosesCurrentPageAndNavigatesToBasePage();
	}
	
	@Test(dependsOnMethods = { "Step09_Pass_Instructor_Profile_Page" })
	public void Step10_Instructor_Logout() {
		canvas.leftMenu.logout();
	}
	/*
	@Test(dependsOnMethods = { "Step09_Pass_Mars_And_Eula_Page"})
	public void Step10_Pass_Registration_Page() {
		canvas.raPage.passRegistrationPage(firstName, lastName, registerPassword);
	}
	
	@Test(dependsOnMethods = { "Step10_Pass_Registration_Page"})
	public void Step11_Verify_User_lands_On_Provision_Page() {
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.userClosesCurrentPageAndNavigatesToBasePage();
	}

	@Test(dependsOnMethods = {"Step11_Verify_User_lands_On_Provision_Page"})
	public void Step12_User_Log_Out_Of_The_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
	*/
}