package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class SYSIN_4094 extends Parent_Test{

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();
	
	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor;
	private String instructor1, emailInstructor1;
	private String student1, emailStudent1;
	private String student2, emailStudent2;
//	private String instructor4, emailInstructor4;
	private String password;

	private void _initVars() {
		Long timeStamp = System.currentTimeMillis();
		courseName = "UoPhoenix_LT";
//		courseName = "Auto" + "Course" + timeStamp;
//		subAccount = getData("UoP.subAccount");
		instructor = "Auto" + "Inst" + timeStamp;
		emailInstructor = instructor + "@fake123.com";
		instructor1 = "inst_uoplt";
		emailInstructor1 = instructor1 + "@fake123.com";
		student1 = "Auto" + "Stud1" + timeStamp;
		emailStudent1 = student1 + "@fake123.com";
		password = "12345678";
		
		data.put("InstUserName", instructor);
		data.put("EmailInst", emailInstructor);
		data.put("InstUserName1", instructor1);
		data.put("EmailInst1", emailInstructor1);
		data.put("Student1", student1);
		data.put("EmailStudent1", emailStudent1);		
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
		canvas.coursePage.writeDataToYamlforUoP(data);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Launch_Application"})
	public void Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		canvas.dashboardPage.verifyDashboardPage();
		
	}
	
	@Test(dependsOnMethods={"Log_In_As_Admin"})
	public void Go_To_Macmillan2_Courses() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
	}
	
	@Test(dependsOnMethods={"Go_To_Macmillan2_Courses"})
	public void Create_New_User_Accounts() {
	
		canvas.macmillan2Page.refreshPage();
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.verifyAddNewUserModalWindow();
		canvas.macmillan2Page.createUser("test stud", emailStudent1);
	}
	
	@Test(dependsOnMethods={"Create_New_User_Accounts"})
	public void Find_Course_To_Enrol_Users() {
		
		canvas.macmillan2Page.enterIntoCourse(courseName);
	}
	
	@Test(dependsOnMethods={"Find_Course_To_Enrol_Users"})
	public void Publish_Course() {
		canvas.coursePage.publishCourse();
	}
	
	@Test(dependsOnMethods={"Publish_Course"})
	public void Remove_Existing_Users_From_Course() {
		
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
		canvas.macmillan2Page.removeAllUser();
	}
	
	@Test(dependsOnMethods={"Remove_Existing_Users_From_Course"})
	public void Go_To_People_Page_In_Course() {
		
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
	}
	
	@Test(dependsOnMethods={"Go_To_People_Page_In_Course"})
	public void Verify_Add_People_Modal_Window() {
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.verifyAddPeopleModalWindow();
	}
	
	@Test(dependsOnMethods={"Verify_Add_People_Modal_Window"})
	public void Enrol_Users_In_Course() {
		
		canvas.coursePage.enterUserDetails("Student", emailStudent1);
		canvas.coursePage.verifyUserDetails(emailStudent1);
		canvas.coursePage.clickOnAddUserButton();
		//canvas.coursePage.verifyUserIsAddedToCourse(student1);
	}
	
	@Test(dependsOnMethods={"Enrol_Users_In_Course"})
	public void Create_Logins_For_Instructors() {
		
		canvas.coursePage.createLoginForUserUoP(student1, password);
	}	

	@Test(dependsOnMethods={"Create_Logins_For_Instructors"})
	public void Admin_Log_Out_Canvas_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Admin_Log_Out_Canvas_Application"})
	public void Log_In_As_Student() {
		
		canvas.loginPage.loginToTheApplication(student1, password);
		//canvas.dashboardPage.verifyDashboardPage();	
	}
	
	@Test(dependsOnMethods={"Log_In_As_Student"})
	public void Accept_Terms_And_Course_Invitation() {
		
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyDashboardPage();
		canvas.dashboardPage.acceptInvite();
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}
	
	@Test(dependsOnMethods={"Accept_Terms_And_Course_Invitation"})
	public void Click_On_Macmillan_Tool_Static_Pairing_Tool() {
		
		canvas.coursePage.clickMacmillanLearningStaticPairingTool();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.verifyUserIsOnCourseHomePage("SmokeCourse_Jan1818");
	}
	
	@Test(dependsOnMethods = "Click_On_Macmillan_Tool_Static_Pairing_Tool")
	public void Student_Logout_LaunchPad(){
		canvas.pxPage.launchPadLogout();
	}
	
	@Test(dependsOnMethods = "Student_Logout_LaunchPad")
	public void Student_Logout_Canvas(){
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}