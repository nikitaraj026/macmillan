package com.qait.canvas.tests;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class WorkFlow_Associate_Course extends Parent_Test{
	CanvasTestSessionInitiator canvas;
	private String username, password;
	private String canvasURL;
	String courseName = "Cole";
	String exactCourseName = "Canvas Demo Course (NicoleS)";
	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	private String pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, school;
	String assignmentName;
	String chapterName, chapterIntroduction, chapterContent;
	String quizTitle1, quizTitle2;
	String chapterNumber, selectQuestionFrom;
	String bookTitle;
    String external_Tool;
    String moduleName;
	 String instructorUserName;
	
	private void _initVars(String book) {
		System.currentTimeMillis();
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";
		username = getData("users.admin.user_name");
		password = getData("users.admin.password");
		canvasURL = getData("app_url");
		instructorName = getData("users.instructor.name1");
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		academicTerm = "Fall 2016";
		external_Tool = getData("external_tool");
		school = "TEST University (New York, NY)";
		String bookIdentifier = null;
		if (book.contains("myers11e")) {
			bookTitle = getData("bookTitleLP");
			bookIdentifier = "myers";
		} else {
			bookTitle = getData("bookTitleWriterHelp");
			bookIdentifier = "lunsford";
		}
		if (bookIdentifier.contains("myers")) {
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
			chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		} else {
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		}
		moduleName = getData("moduleName");
	}
	
	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		_initVars(book);
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Step01_Launch_Application_And_Verify_Login_Page() {
		
		canvas.launchApplication();
		canvas.loginPage.verifyAllFieldsOnLoginPage();
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.user_name1"),
				getData("users.instructor.password"));
		//canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}
	@Test(dependsOnMethods = "Step01_Launch_Application_And_Verify_Login_Page")
	public void Step02_Verify_Admin_Is_On_Dashboard(){
		canvas.dashboardPage.verifyExistingInstDashboardPage();
	}
	@Test(dependsOnMethods = "Step02_Verify_Admin_Is_On_Dashboard")
	public void Step03_Verify_User_Navigated_To_Macmillan2_Page(){
		canvas.leftMenu.clickLeftMenu("Courses");
		canvas.leftMenu.clickOnUserCourse("Testing Purpose");
	}
	@Test(dependsOnMethods = "Step03_Verify_User_Navigated_To_Macmillan2_Page")
	public void Step04_Verify_AllLinksAfterClickingMacmillanLearningTool(){
		boolean value=canvas.leftMenu.menuIsPresentOrNotAtLeftSide(external_Tool);
		if(value)
		{
		canvas.macmillan2Page.clickLeftTab("Settings");
		canvas.addMacTools.clickOnCourseStatisticsTab("Navigation");
		canvas.coursePage.enableMacmillanTools(external_Tool);
		}
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.runHandleSecurityExe();
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.toolsPage.changeWindow(1);
		canvas.provisionPage.verifyTokenRegistrationPage();
	}
	@Test(dependsOnMethods = "Step04_Verify_AllLinksAfterClickingMacmillanLearningTool")
	public void Step_05_Verify_PrivacyPolicyPageContent()
	{
		canvas.provisionPage.clickOnFooterLink("Privacy Policy");
		canvas.toolsPage.changeWindow(2);
		canvas.provisionPage.verifyPrivacyPolicyPage();
		canvas.toolsPage.closeThirdWindowAndComeBacktoSecondWindow();
	}
	@Test(dependsOnMethods = "Step_05_Verify_PrivacyPolicyPageContent")
	public void Step_06_Verify_TermsOfUsePageContent()
	{
		canvas.provisionPage.clickOnFooterLink("Terms of Use");
		canvas.toolsPage.changeWindow(2);
		canvas.provisionPage.verifyTermsOfUsePage();
		canvas.toolsPage.closeThirdWindowAndComeBacktoSecondWindow();
	}
	
	@Test(dependsOnMethods = "Step_06_Verify_TermsOfUsePageContent")
	public void Step_07_Verify_AccessibilityPageContent()
	{
		canvas.provisionPage.clickOnFooterLink("Accessibility");
		canvas.toolsPage.changeWindow(2);
		canvas.provisionPage.verifyAccessibilityPage();
		canvas.toolsPage.closeThirdWindowAndComeBacktoSecondWindow();
	}
	@Test(dependsOnMethods = "Step_07_Verify_AccessibilityPageContent")
	public void Step_08_Verify_CustomerServiceSupportPageContent()
	{
		canvas.provisionPage.clickOnFooterLink("Customer Service/Support");
		canvas.toolsPage.changeWindow(2);
		canvas.toolsPage.verifyMacmillanTechnicalSupportPageContent();
		canvas.toolsPage.closeThirdWindowAndComeBacktoSecondWindow();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.verifyDifferentFieldAfterClickingOnMacTools();
	}
	@Test(dependsOnMethods = "Step_08_Verify_CustomerServiceSupportPageContent")
	public void Step09_Verify_MacmillanLearningDiagnosticsPageContent(){
		canvas.toolsPage.clickOnLinkOfMaclearningLearningTools("Macmillan Learning Diagnostics");
		canvas.toolsPage.changeWindow(1);
		canvas.toolsPage.verifyMacmillanLearningDiagnosticsPageContent();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = "Step09_Verify_MacmillanLearningDiagnosticsPageContent")
	public void Step10_Verify_MacmillanTechnicalSupportPageContent(){
		canvas.toolsPage.clickOnLinkOfMaclearningLearningTools("Macmillan Technical Support");
		canvas.toolsPage.changeWindow(1);
		canvas.toolsPage.verifyMacmillanTechnicalSupportPageContent();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	@Test(dependsOnMethods = "Step10_Verify_MacmillanTechnicalSupportPageContent")
	public void Step11_Verify_AppLoginPageAfterClickingAuthenicateButton(){
		canvas.toolsPage.switchToDefaultContent();
		canvas.toolsPage.switchToDefaulFrame();
		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.toolsPage.changeWindow(1);
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
	}
	@Test(dependsOnMethods = "Step11_Verify_AppLoginPageAfterClickingAuthenicateButton")
	public void Step12_Verify_ViewMacMillanLearningCatalogLink(){
		canvas.provisionPage.verifyMacmillanCatalogue();
		canvas.toolsPage.closeThirdWindowAndComeBacktoSecondWindow();
	}
	@Test(dependsOnMethods = "Step12_Verify_ViewMacMillanLearningCatalogLink")
	public void Step13_Verify_ViewLaunchpadCourses(){
		canvas.provisionPage.verifyViewLaunchpadCourses();
	}
	@Test(dependsOnMethods = "Step13_Verify_ViewLaunchpadCourses")
	public void Step14_Verify_MacmillanElearningPage(){
		canvas.provisionPage.clickOnViewLaunchPadCourses();
		canvas.provisionPage.verifyMacmillanElearningPage();
		canvas.toolsPage.closeThirdWindowAndComeBacktoSecondWindow();
	}
	@Test(dependsOnMethods = "Step14_Verify_MacmillanElearningPage")
	public void Step15_Verify_CancelButtonFunctionality(){
		canvas.provisionPage.clickOnViewLaunchPadCourses();
		canvas.provisionPage.ClickCancelButton();
		canvas.provisionPage.verifyProvisionPageOpens();
	}
	@Test(dependsOnMethods = "Step15_Verify_CancelButtonFunctionality")
	public void Step16_Verify_RefreshButton(){
		canvas.provisionPage.clickOnRefreshButton();
		canvas.provisionPage.verifyProvisionPageOpens();
	}
	@Test(dependsOnMethods = "Step16_Verify_RefreshButton")
	public void Step17_Instructor_Create_Course() {
		canvas.provisionPage.createNewCourse(bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName,
				academicTerm, false, "", school);
		canvas.provisionPage.verifyCourseCreated(pxCourseName);
		canvas.provisionPage.associateCourse(pxCourseName);
		canvas.toolsPage.verifyToolsPage();
	}
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		//canvas.closeBrowserSession();
	}
}
