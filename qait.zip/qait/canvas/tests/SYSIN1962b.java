package com.qait.canvas.tests;

//Instructor is able to access the PX Launch Pad TOC experience from rich content editor in Canvas in order to begin the process of importing a content item or chapter folder.

import java.io.IOException;
import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1962b extends Parent_Test{
/*
	CanvasTestSessionInitiator canvas;

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method)
    {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.associated"),
				getData("users.instructor.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = { "Step02_Log_In_As_Instructor" })
	public void Step03_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Course_Page" })
	public void Step04_Go_To_Discussion_Page(){
		canvas.coursePage.goToDiscussionsPage();
		canvas.discussionPage.verifyDiscussionPageOpens();
	}

	@Test(dependsOnMethods = { "Step04_Go_To_Discussion_Page" })
	public void Step05_Go_To_contentTocViaRichContentEditorPage() {
		canvas.discussionPage.clickOnAddDiscussionButton();
		canvas.discussionPage.clickOnIconMoreExternalTools();
		canvas.contentTocPage.verifyContentTocPageOpens();
		canvas.discussionPage.closeContentToc();
	}

	@Test(dependsOnMethods = {"Step05_Go_To_contentTocViaRichContentEditorPage"})
	public void Step06_User_Log_Out() {
		canvas.discussionPage.LogOut();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() throws IOException {
		canvas.closeBrowserSession();
	}
*/}