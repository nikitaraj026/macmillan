package com.qait.canvas.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class OBG_177_Test extends Parent_Test {
/*
	CanvasTestSessionInitiator canvas;
	
	private String external_Tool = "";
	private String quizPoints = "10";
	private String password = "123456";
	private String subAccountEnv, courseName, quizname;
	private Long timeStamp = System.currentTimeMillis();
	private String student = "Auto" + "Stud" + timeStamp;
	private String student2 = "RoleLandS";
	private String emailStudent = student + "@fake123.com";
	private String emailStudent2 = student2 + "@fake123.com";
	private String chapterName = "Prologue: The Story of Psychology";

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods={"Step02_Log_In_As_Admin"})
	public void Step03_Navigate_To_Account_Create_A_New_Student_And_Enroll_Into_Course() {
		subAccountEnv = getData("SubAccountEnv");
		courseName = getData("associated_courseName");
		
		canvas.dashboardPage.goToAccounts();
		canvas.dashboardPage.goToSubAccount();
		canvas.dashboardPage.goToEnvSubAccount(subAccountEnv);

		canvas.dashboardPage.createUser(student,emailStudent);
		canvas.dashboardPage.enterIntoCourse(courseName);

		canvas.dashboardPage.addPeople("Student", emailStudent);
		canvas.dashboardPage.createLoginInfoForUser(student, "123456");
	}

	@Test(dependsOnMethods={"Step03_Navigate_To_Account_Create_A_New_Student_And_Enroll_Into_Course"})
	public void Step04_User_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step04_User_Log_Out" })
	public void Step05_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(
				getData("users.instructor.associated"),
				getData("users.instructor.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = { "Step05_Log_In_As_Instructor" })	
	public void Step06_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step06_Go_To_Course_Page" })
	public void Step07_Expand_And_Open_Content_TOC(){
		external_Tool = getData("external_tool");
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickToolLink("lnk_MacmillanContent");
		canvas.contentTocPage.openChapterOfTOC(chapterName);
		canvas.contentTocPage.DismissPopup();
		canvas.contentTocPage.UserNavigateToPxSecondWindow();
	}

	@Test(dependsOnMethods = "Step07_Expand_And_Open_Content_TOC")
	public void Step08_Create_New_Quiz_Assign_Quiz() {
		canvas.pxPage.expandPXChapter(chapterName);
		canvas.pxPage.addNewQuiz(chapterName);
		quizname = canvas.pxPage.changeTitleAndAddQuestions();
		System.out.println("Quiz Name:  " + quizname);
		canvas.pxPage.clickAssignmentTab();
		canvas.pxPage.selectDateInDatePicker();
		canvas.pxPage.fillGradePointsForAssignment(quizPoints);
		canvas.pxPage.clickAssignButtonFromAssignmentTab();
		canvas.pxPage.addQuestion();
	}
	
	@Test(dependsOnMethods = "Step08_Create_New_Quiz_Assign_Quiz")
	public void Step09_Deploy_Content_TOC(){
		canvas.contentTocPage.userClosesPXWindow();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickToolLink("lnk_MacmillanContent");
		canvas.contentTocPage.ExpandToc(chapterName);
		canvas.contentTocPage.selectContentTOC(quizname);
		canvas.contentTocPage.clicksOnAddSelectedContent();
		canvas.contentTocPage.selectModuleAndDeploy("autoModule");
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = "Step09_Deploy_Content_TOC")
	public void Step10_Click_Modules_And_Publish_Deployed_Content(){
		canvas.coursePage.goToModulePage();
		canvas.modulePage.verifyModulePageOpens();
		canvas.modulePage.publishDeployedContent(quizname);
	}

	@Test(dependsOnMethods = "Step10_Click_Modules_And_Publish_Deployed_Content")
	public void Step11_Instructor_Log_Out() {
		canvas.discussionPage.LogOut();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step11_Instructor_Log_Out")
	public void Step12_Student_Logs_In(){
		canvas.loginPage.loginToTheApplication(student, getData("users.student.password"));
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods={"Step12_Student_Logs_In"})
	public void Step13_Accept_Invitation() {
		canvas.dashboardPage.acceptInvite();
	}

	@Test(dependsOnMethods = { "Step13_Accept_Invitation" })
	public void Step14_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step14_Go_To_Course_Page" })
	public void Step15_Go_To_Module_Page() {
		canvas.coursePage.goToModulePage();
		canvas.modulePage.verifyModulePageOpens();
		canvas.modulePage.openTheContentInModule(quizname);
	}

	@Test(dependsOnMethods = { "Step15_Go_To_Module_Page" })
	public void Step16_Go_To_TOC_Page() {
		canvas.modulePage.openButtonToLoadContentInANewWindow();
	}

	@Test(dependsOnMethods = { "Step16_Go_To_TOC_Page" })
	public void Step17_Pass_Mars_And_Eula_Page() {
		canvas.raPage.checkEmail(emailStudent);
	}

	@Test(dependsOnMethods = { "Step17_Pass_Mars_And_Eula_Page"})
	public void Step18_Pass_Registration_Page() {
		canvas.raPage.verifyRegistrationPageOpens();
		canvas.raPage.passRegistrationPage();
	}

	@Test(dependsOnMethods={"Step18_Pass_Registration_Page"})
	public void Step19_Verification_Free_Trial_Access() {
		canvas.raPage.verifyAndClickTemporaryAccessButton();
		canvas.raPage.verifyFreeTrialTextDisplayed();
		canvas.raPage.userClosesCurrentWindowAndGoToBaseWindow();
	}
	
	@Test(dependsOnMethods={"Step19_Verification_Free_Trial_Access"})
	public void Step20_Student_Log_Out() {
		canvas.modulePage.logOut();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods = "Step20_Student_Log_Out")
	public void Step21_Student_Logs_In(){
		canvas.loginPage.loginToTheApplication(student2, getData("users.student.password"));
		canvas.dashboardPage.verifyUserIsOnDashboardPage();
	}

	@Test(dependsOnMethods = { "Step21_Student_Logs_In" })
	public void Step22_Go_To_Course_Page() {
		canvas.dashboardPage.goToCoursePage();
		canvas.coursePage.verifyCoursePageOpens();
		canvas.coursePage.goToUserCourse();
	}

	@Test(dependsOnMethods = { "Step22_Go_To_Course_Page" })
	public void Step23_Go_To_Module_Page() {
		canvas.coursePage.goToModulePage();
		canvas.modulePage.verifyModulePageOpens();
		canvas.modulePage.openTheLastContentInModule();
	}
	
	@Test(dependsOnMethods = { "Step23_Go_To_Module_Page" })
	public void Step24_Go_To_TOC_Page() {
		canvas.modulePage.openButtonToLoadContentInANewWindow();
	}

	@Test(dependsOnMethods = { "Step24_Go_To_TOC_Page" })
	public void Step25_Pass_Mars_Page() {		
		canvas.raPage.checkEmail(emailStudent2);
		canvas.raPage.providePassword(password);
	}
	
	@Test(dependsOnMethods = { "Step25_Pass_Mars_Page" })
	public void Step26_Verify_Trial_Expiration() {
		canvas.raPage.verifyAndClickTemporaryAccessButton();
		canvas.raPage.verifyTrialEndedMessage();
		canvas.raPage.userClosesCurrentWindowAndGoToBaseWindow();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
	*/
}
