package com.qait.canvas.tests;


import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import io.restassured.RestAssured;


public class SYSIN_3974 {
	
	public static String json1;
	
	String relativePath;
	@BeforeClass
	public void setBaseUrlAndJsonSchemaPath()
	{
		//RestAssured.baseURI = "http://10.0.81.54/api/domain/";
		RestAssured.baseURI = "http://10.0.81.54/api/domain/";
	}
	
	@Test(priority = 1)
	public void authenticate() throws JSONException
	{
		relativePath = "checkandcreatedomainbyinstitution/103136";
		  
		  //RestAssured.baseURI = "http://10.0.81.54/api/domain";
//		String body = "{\"institution\":{ \"institutionid\": \"0694\"},\"isbn\": \"1457689340\",\"section\":{ \"timezone\": \"UTC-06:00\", \"sectionnumber\": \"126\", \"term\": \"201712\", \"sectionid\": \"ENGL.1101.126.201712\", \"sectionname\": \"126\" },\"user\":{ \"firstname\": \"Christopher\", \"role\": \"instructor\", \"userid\": \"900257140\", \"email\": \"cburdet7140@student.gwinnetttech.edu\", \"lmsuserid\": \"32_900257140\", \"lastname\": \"Burdett\" }}";
		
		  String responseBody = RestAssured
		   .given()
		    .log().all()
		     .auth()
		     .oauth("key", "secret", "", "")
		     .header("Content-Type","application/x-www-form-urlencoded")
		     .formParam("domainname","University of Rhode Island (Kingston, RI)")
		   .when()
		    .post(relativePath)
		   .then()
		    .statusCode(200)
		    .extract()
		     .asString();
		  
		  System.out.println(responseBody);
//-----------------------------------------------------
		  
//		  RestAssured.baseURI = "http://10.0.81.54/api/course";
//		  
//		  String responseBody = RestAssured
//		   .given()
//		    .log().all()
//		    .auth()
//		     .oauth("key", "secret", "", "")
//		   .when()
//		    .get("/details/4695490")
//		   .then()
//		    .statusCode(200)
//		    .extract()
//		     .asString();
//		
//		  System.out.println(responseBody);
		
//		
//		relativePath = "checkandcreatedomainbyinstitution/103136";
//		 String output = RestAssured.given().
//					header("Content-Type","application/x-www-form-urlencoded").
//					header("Authorization", "OAuth oauth_consumer_key=\"key\",oauth_signature_method=\"HMAC-SHA1\",oauth_timestamp=\"1498831422\",oauth_nonce=\"GxkfN7T271W\",oauth_version=\"1.0\",oauth_signature=\"Hvak%2Bl6BrHqvUTQ5UdRsWO5%2FzC0%3D\"")
//					.formParam("domainname","University of Rhode Island (Kingston, RI)")
//					.post(relativePath)
//					.then()
//					.extract().asString();
//		System.out.println(output);
//---------------------------------------------------------------------		
//		JSONObject json = new JSONObject(output);
//		System.out.println(json);
//		if(String.valueOf(json.get("status_code")).equalsIgnoreCase("0"))
//		{
//			json1 = "<b>PASS<br></br></b>" ;
//		}
//		else{
//			json1 = "<b>FAIL<br></br></b>" ;
//		}
//		json1 += output;
//		Assert.assertEquals(String.valueOf(json.get("status_code")),"0","PX API Call is failing");
	}
	

}
