package com.qait.canvas.tests;

import java.lang.reflect.Method;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SYSIN1989 extends Parent_Test {
/*
	CanvasTestSessionInitiator canvas;
	private String baseURL;
	
	private void initVars() {
		baseURL = getData("MW_Error_URL");
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		initVars();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication(baseURL);
		canvas.MiddlewarePage.verifyMiddlewareErrorPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
*/}