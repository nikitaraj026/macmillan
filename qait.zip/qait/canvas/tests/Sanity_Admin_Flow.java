package com.qait.canvas.tests;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.*;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import static com.qait.automation.utils.YamlReader.getData;

/**
 * Created by vijaykumar on 7/21/2017.
 */
public class Sanity_Admin_Flow extends Parent_Test {

    CanvasTestSessionInitiator canvas;
    Map<String, Object> data = new HashMap<String, Object>();

    private String subAccount;
    private String courseName;
    private String instructor, emailInstructor;
    private String firstStudent, emailFirstStudent;
    private String password, inst_password, px_password;
    private String externalTool;

    private void _initVars() {
        Long timeStamp = System.currentTimeMillis();
        courseName = getData("course.name2");
        subAccount = getData("subAccount");
        instructor = getData("users.instructor.user_name2");
        emailInstructor = getData("users.instructor.user_email2");
        firstStudent = "AutoFStud" + timeStamp;
        emailFirstStudent = firstStudent + "@fake123.com";

        inst_password = getData("users.instructor.password");
        password = getData("users.student.password");
        DashBoardPageAction.courseName = courseName;
        px_password = "Password1!";
        externalTool = getData("external_tool");

        data.put("InstUserName", instructor);
        data.put("EmailInst", emailInstructor);
        data.put("FirstStudent", firstStudent);
        data.put("EmailFirstStudent", emailFirstStudent);
        data.put("Password", password);
        data.put("inst_password", inst_password);
        data.put("PX_Password", px_password);
        data.put("CourseName", courseName);
    }

    @BeforeClass
    public void Start_Test_Session() {
        canvas = new CanvasTestSessionInitiator();
        _initVars();
        canvas.coursePage.writeDataToYaml(data);
    }

    @BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName());
    }

    @AfterMethod
    public void onFailure(ITestResult result) {
        afterMethod(canvas, result, this.getClass().getName());
    }

    @Test
    public void Launch_Application() {
        canvas.launchApplication();
        canvas.loginPage.verifyLoginPage();
    }

    @Test(dependsOnMethods={"Launch_Application"})
    public void Log_In_As_Instructor() {
        canvas.loginPage.loginToTheApplication(
                instructor,
                getData("users.instructor.password"));
        canvas.dashboardPage.verifyDashboardPage();

    }

    @Test(dependsOnMethods="Log_In_As_Instructor")
    public void Instructor_Go_To_Course_Details_Page() {
        canvas.leftMenu.clickOnCoursesLeftMenu();
        canvas.leftMenu.clickOnUserCourse(courseName);
        canvas.coursePage.verifyUserIsOnCoursePage(courseName);
    }

    @Test(dependsOnMethods = "Instructor_Go_To_Course_Details_Page")
    public void Remove_Already_Created_Assignment() {
        canvas.coursePage.clickModulesOnCoursePage();
        canvas.coursePage.verifyModulePresentAndSelectOptionFromSetting("Delete");
        canvas.coursePage.enterIntoToolsSection(externalTool);
        canvas.toolsPage.verifyToolsPage();
        if (!canvas.toolsPage.softVerifyCourseIsAssociated("Connect with LaunchPad")) {
            throw new SkipException("Content already removed");
        }
        canvas.toolsPage.clickOnUnlinkMacmillanToolLink();
        canvas.toolsPage.verifyEndCourseAssociationPage();
        canvas.toolsPage.clickOnRemoveMacmillanContent();
        canvas.toolsPage.disassociateCourse();
        canvas.toolsPage.verifyEndCourseAssociationPageAfterCourseIsDisassociated();
        canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
        canvas.toolsPage.verifyNonAssociatedToolsPage("Connect with LaunchPad");
    }

    @Test(dependsOnMethods="Remove_Already_Created_Assignment", alwaysRun = true)
    public void Instructor_Logout() {
        canvas.leftMenu.refreshPage();
        canvas.leftMenu.logout();
    }

    @Test(dependsOnMethods={"Instructor_Logout"})
    public void Log_In_As_Admin() {
        canvas.loginPage.loginToTheApplication(
                getData("users.admin.user_name"),
                getData("users.admin.password"));
        canvas.dashboardPage.verifyDashboardPage();

    }

    @Test(dependsOnMethods={"Log_In_As_Admin"})
    public void Go_To_Macmillan2_Courses() {
        canvas.leftMenu.clickOnAdminLeftMenu();
        canvas.leftMenu.clickMacmillan2();
    }

    @Test(dependsOnMethods={"Go_To_Macmillan2_Courses"})
    public void Verify_Add_New_User_Modal_Window() {
        canvas.macmillan2Page.clickOnAddNewUser();
        canvas.macmillan2Page.verifyAddNewUserModalWindow();
    }

    @Test(dependsOnMethods={"Verify_Add_New_User_Modal_Window"})
    public void Admin_Create_Users_Student() {
        //canvas.macmillan2Page.clickOnAddNewUser();
        canvas.macmillan2Page.createUser(firstStudent, emailFirstStudent);
    }

    @Test(dependsOnMethods={"Admin_Create_Users_Student"})
    public void Admin_Redirects_To_Newly_Created_Course() {
        canvas.macmillan2Page.enterIntoCourse(courseName);
    }

    @Test(dependsOnMethods={"Admin_Redirects_To_Newly_Created_Course"})
    public void Publish_Course() {
        canvas.coursePage.publishCourse();
    }

    @Test(dependsOnMethods={"Publish_Course"})
    public void Admin_Redirects_To_People_Page() {
        canvas.coursePage.clickOnPeopleNavigationLink();
        canvas.coursePage.verifyUserIsOnPeoplePage();
    }

    @Test(dependsOnMethods= {"Admin_Redirects_To_People_Page"})
    public void Verify_Add_People_Modal_Window() {
        canvas.coursePage.clickOnPeopleButton();
        canvas.coursePage.verifyAddPeopleModalWindow();
    }


    @Test(dependsOnMethods={"Verify_Add_People_Modal_Window"})
    public void Admin_Enroll_Student_To_Course() {
        canvas.coursePage.clickOnPeopleButton();
        canvas.coursePage.enterUserDetails("Student", emailFirstStudent);
        canvas.coursePage.clickOnAddUserButton();
        canvas.coursePage.verifyStudentEnrollment();
    }


    @Test(dependsOnMethods={"Admin_Enroll_Student_To_Course"})
    public void Admin_Add_Login_For_Student() {
        canvas.coursePage.clickOnPeopleNavigationLink();
        canvas.coursePage.clickOnUserNameLink(firstStudent);
        canvas.coursePage.verifyUserDetailPage(firstStudent);
        canvas.coursePage.clickOnMoreUserDetails();
        canvas.coursePage.verifyMembershipLoginInformationSection();
        canvas.coursePage.clickOnAddLoginLink();
        canvas.coursePage.verifyAddLoginModalWindow();
        canvas.coursePage.enterLoginDetails(firstStudent, password);
        canvas.coursePage.clickOnAddLoginButton();
        canvas.coursePage.verifyUserLogin(firstStudent);
    }


    @Test(dependsOnMethods={"Admin_Add_Login_For_Student"})
    public void Admin_Log_Out_Canvas_Application() {
        canvas.leftMenu.logout();
        canvas.loginPage.verifyLoginPage();
    }

    @AfterClass(alwaysRun = true)
    public void Stop_Test_Session() {
        canvas.closeBrowserSession();
    }

}
