package com.qait.canvas.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class UoP_Unknown_Instructor_Tries_To_Create_Course extends Parent_Test{

	CanvasTestSessionInitiator canvas;
	
	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor;
	private String password;

	private void _initVars() {
		Long timeStamp = System.currentTimeMillis();
		//courseName = "TestCourse_" + timeStamp;
		courseName = getData("UoP.courseName");
		subAccount = getData("subAccount");
		instructor = canvas.coursePage.readDataFromYamlforUoP("InstUserName");
		emailInstructor = canvas.coursePage.readDataFromYamlforUoP("EmailInst");
		password = "12345678";
		
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());     
	}	
	
	@Test
	public void Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Launch_Application"})
	public void Log_In_As_Instructor() {
		
		canvas.loginPage.loginToTheApplication(instructor, password);
		//canvas.dashboardPage.verifyDashboardPage();	
	}
	
	@Test(dependsOnMethods={"Log_In_As_Instructor"})
	public void Accept_Terms_And_Course_Invitation() {
		
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyDashboardPage();
		canvas.dashboardPage.acceptInvite();
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}
	
	@Test(dependsOnMethods={"Accept_Terms_And_Course_Invitation"})
	public void Click_On_Macmillan_Tool_Widget_To_Create_Course_And_Verify_Auto_Course_Provisioning() {
		
		canvas.coursePage.clickMacmillanLearningCreateCourseToolUoP();
		canvas.toolsPage.verifyInstructorAccountIsNotSetupForAutoProvisioning();
	}
	
	@Test(dependsOnMethods={"Click_On_Macmillan_Tool_Widget_To_Create_Course_And_Verify_Auto_Course_Provisioning"})
	public void Click_On_Macmillan_Tool_Master_Copy_Tool() {
		
		canvas.coursePage.clickMacmillanLearningMasterCopyTool();
		canvas.toolsPage.verifyInstructorAccountIsNotSetupForAutoProvisioning();
	}
	
	@Test(dependsOnMethods={"Click_On_Macmillan_Tool_Master_Copy_Tool"})
	public void Click_On_Macmillan_Tool_Static_Pairing_Tool() {
		
		canvas.coursePage.clickMacmillanLearningStaticPairingTool();
		canvas.toolsPage.verifyInstructorAccountIsNotSetupForAutoProvisioning();
	}
	
	@Test(dependsOnMethods={"Click_On_Macmillan_Tool_Static_Pairing_Tool"})
	public void Click_On_Macmillan_Learning_Tools_Widget() {
	
		canvas.coursePage.clickMacmillanLearningToolsWidget();
		canvas.toolsPage.verifyNonAssociatedToolsPage("Connect with LaunchPad");
	}

	@Test(dependsOnMethods={"Click_On_Macmillan_Learning_Tools_Widget"})
	public void Admin_Log_Out_Canvas_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}