package com.qait.canvas.sapling.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class SaplingFlowForCourseAndInstCreation extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();
	private String admin_user, password;
	private void _initVars() {
		String dateWithTime = canvas.getCurrentDateWithTime();
		admin_user = getData("sap_users.admin.user_name");
		password = getData("sap_users.admin.password");
		
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplicationForSapling();
	}
	//According to product, you have to change email and product 
	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Admin() {
		String product="Canvas";
		String email="test.inst.sapling.15oct@fake123.com";
		canvas.sapAdmin.navigateFromLoginToHome(admin_user,password);
		canvas.sapAdmin.userCreation(product, "sapling",email);
		canvas.sapAdmin.createCourse("Testing Courses",product,"Sapling","Sapling Learning","English");
		canvas.sapAdmin.enrollUser();
	}
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		 canvas.closeBrowserSession();
	}
}
