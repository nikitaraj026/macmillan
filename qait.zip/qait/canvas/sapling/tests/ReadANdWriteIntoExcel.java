package com.qait.canvas.sapling.tests;

import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadANdWriteIntoExcel {
	//@Test
	public static void writeExcel() throws IOException {
		Map<Integer, ArrayList> dataToWrite=new HashMap<Integer, ArrayList>();
		ArrayList al=new ArrayList();
		al.add("amit");
		al.add("amit");
		al.add("ajit");
		al.add("ajit");
		ArrayList al1=new ArrayList();
		al1.add("amit");
		al1.add("amit");
		al1.add("ajit");
		al1.add("ajit");
		ArrayList al2=new ArrayList();
		al2.add("amit");
		al2.add("amit");
		al2.add("ajit");
		al2.add("ajit");
		ArrayList al3=new ArrayList();
		al3.add("amit");
		al3.add("amit");
		al3.add("ajit");
		al3.add("ajit");
		ArrayList al4=new ArrayList();
		al4.add("amit");
		al4.add("amit");
		al4.add("ajit");
		al4.add("ajit");
		
		dataToWrite.put(0, al);
		dataToWrite.put(1, al1);
		dataToWrite.put(2, al2);
		dataToWrite.put(3, al3);
		dataToWrite.put(4, al4);
		for (Map.Entry entry : dataToWrite.entrySet()) {
			ArrayList aList = (ArrayList) entry.getValue();
			System.out.println("===== "+aList);
			for (int j = 0; j < aList.size(); j++) {
				System.out.println("***** "+aList.get(j));
			}
		}
	
		XSSFWorkbook workbook = new XSSFWorkbook();
		XSSFSheet sheet = workbook.createSheet("Test");
		int i = 0;
		Row row;
		for (Map.Entry entry : dataToWrite.entrySet()) {
//			System.out.println(++i);
			row = sheet.createRow(++i);
			System.out.println(row.getPhysicalNumberOfCells()+" "+row.getFirstCellNum());
			ArrayList aList = (ArrayList) entry.getValue();
		
			for (int j = 0; j < aList.size(); j++) {
				Cell cell = row.createCell(j);
				cell.setCellValue(aList.get(j).toString());
			}
			
		}

		String path = "./src/test/resources/WriteDataFile.xlsx";
		FileOutputStream outputStream = new FileOutputStream(path,true);
		workbook.write(outputStream);
		System.out.println("Done");
	}
	//@Test()
	public void date1()
	{
		Date today = new Date();               
		SimpleDateFormat formattedDate = new SimpleDateFormat("MMM dd, YYYY");            
		Calendar c = Calendar.getInstance();        
		c.add(Calendar.DATE, 1);  // number of days to add      
		String tomorrow = (String)(formattedDate.format(c.getTime()));
		System.out.println("Tomorrows date is " + tomorrow);
System.out.println("document.querySelectorAll('.datePicker-date.availableDate.hasDatepicker')[1].value='"+tomorrow+"'");
	}
	@Test()
	public void date2()
	{
		String s="ajit";
		 System.out.println("1 "+s.hashCode());
		 String s1=s+"Singh";
		 s = s+"natya";
		 System.out.println("2 "+s.hashCode());
		System.out.println(s);
		String s2="1223 ,777,666";
		 String s3=s2.replaceAll("[^1-9]","");
		 System.out.println("final : "+s3);
	}
}
