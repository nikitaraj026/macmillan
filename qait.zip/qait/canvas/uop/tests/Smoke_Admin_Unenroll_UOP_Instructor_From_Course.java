package com.qait.canvas.uop.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Smoke_Admin_Unenroll_UOP_Instructor_From_Course extends Parent_Test {
	CanvasTestSessionInitiator canvas;
	private String instructor;
	private String courseName;
	private String externalToolInst;
	private String moduleName;
	private String instructor_email, mytier;

	private void _initVars() {

		mytier=System.getProperty("env");
		if(mytier==null) 
		mytier=ConfigPropertyReader.getProperty("tier");
		courseName = getData("courseNameUOP");
		instructor = getData("users.instructorUOP.user_name1");
		externalToolInst = getData("external_tool_phoenix_inst");
		instructor_email = getData("users.instructorUOP.user_email1");
		moduleName = getData("moduleName");

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructor, getData("users.instructor.password"));
		canvas.dashboardPage.verifyDashboardPage();

	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Instructor_Go_To_Course_Details_Page() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step03_Instructor_Go_To_Course_Details_Page")
	public void Step04_Remove_Already_Created_Assignment() throws InterruptedException {
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.coursePage.verifyModulePresentAndSelectOptionFromSetting("Delete");
	}

	@Test(dependsOnMethods = "Step03_Instructor_Go_To_Course_Details_Page")
	public void Step05_InstructorUnlinkProfile() {
	}

	@Test(dependsOnMethods = "Step03_Instructor_Go_To_Course_Details_Page", alwaysRun = true)
	public void Step06_Instructor_Logout() {
		canvas.leftMenu.refreshPage();
		canvas.leftMenu.logout();
	}

	@Test(dependsOnMethods = { "Step06_Instructor_Logout" }, alwaysRun = true)
	public void Step07_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
	}

	@Test(dependsOnMethods = { "Step07_Log_In_As_Admin" })
	public void Step08_Go_To_Macmillan2_Courses() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
	}

	@Test(dependsOnMethods = { "Step08_Go_To_Macmillan2_Courses" })
	public void Step09_Uneroll_User_From_Course() {
		canvas.macmillan2Page.clickSubAccount();
		if (mytier.equalsIgnoreCase("prod")) {
			canvas.macmillan2Page.clickOnSubAccountLink("Phoenix PROD Smoke");
		} else {
			canvas.macmillan2Page.clickOnSubAccountLink("Phoenix LT");

		}
		canvas.macmillan2Page.enterIntoCourse(courseName);
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
		canvas.macmillan2Page.removeAllUser();
	}

	@Test(dependsOnMethods = "Step09_Uneroll_User_From_Course")
	public void Step10_Remove_Macmillan_Tool() {
		canvas.coursePage.clickSettingsOnCoursePage();
		canvas.coursePage.verifyCourseDetailsPage(courseName);
		canvas.coursePage.clickNavigationTab();
		canvas.coursePage.verifyNavigationTab();
	}

	@Test(dependsOnMethods = "Step10_Remove_Macmillan_Tool")
	public void Step11_Admin_Logout_Of_Canvas_Application() {
		canvas.leftMenu.refreshPage();
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}
}