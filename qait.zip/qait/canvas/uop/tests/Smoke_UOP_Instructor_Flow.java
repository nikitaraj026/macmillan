package com.qait.canvas.uop.tests;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;
import static org.testng.Assert.assertEquals;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.TestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.DataReadWrite;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

public class Smoke_UOP_Instructor_Flow extends Parent_Test {

	CanvasTestSessionInitiator canvas;

	private String courseName;
	private String instructorUserName;

	private String external_Tool;
	String bookTitle;
	String courseId;

	String instructorEmail, instructorPassword, instructorPasswordLaunchpad;
	private String pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, school;
	String assignmentName;
	String chapterName, chapterIntroduction, chapterContent;
	String quizTitle1, quizTitle2;
	String chapterNumber, selectQuestionFrom;
	String imgURL = "http://www.joomlaworks.net/images/demos/galleries/abstract/7.jpg";
	String moduleName, tier;
	String studentEmail, externalToolStud, courseIdStud,mytier;

	private void initVars(String book) {
		System.currentTimeMillis();
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";

		instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
		instructorEmail = canvas.coursePage.readDataFromYaml("EmailInst");
		studentEmail = canvas.coursePage.readDataFromYaml("FirstStudentLogin");
		instructorName = getData("users.instructor.name1");
		instructorPassword = canvas.coursePage.readDataFromYaml("inst_password");
		instructorPasswordLaunchpad = canvas.coursePage.readDataFromYaml("PX_Password");
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		academicTerm = "Fall 2016";
		mytier=System.getProperty("env");
		if(mytier==null) 
		mytier=ConfigPropertyReader.getProperty("tier");	
		external_Tool = getData("external_tool_phoenix_inst");
		externalToolStud = getData("external_tool_phoenix_stud");
		school = "TEST University (New York, NY)";

		String bookIdentifier = null;
		if (book.contains("myers11e")) {
			bookTitle = getData("bookTitleLP");
			bookIdentifier = "myers";
		} else {
			bookTitle = getData("bookTitleWriterHelp");
			bookIdentifier = "lunsford";
		}

		if (bookIdentifier.contains("myers")) {
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
			chapterContent = getData(bookIdentifier + ".TOC_chapter5_content1");
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			chapterNumber = getData(bookIdentifier + ".chapterNumber");
			selectQuestionFrom = getData(bookIdentifier + ".selectQuestionFrom");
		} else {
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
		}
		moduleName = getData("moduleName");
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		initVars(book);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Instructor_Accepts_AgreeTerm() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}

	@Test(dependsOnMethods = "Step03_Instructor_Accepts_AgreeTerm")
	public void Step04_Instructor_Go_To_Dashboard_Page() {
		
	}

	@Test(dependsOnMethods = "Step04_Instructor_Go_To_Dashboard_Page")
	public void Step05_Instructor_Go_To_Course_Page() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
	}

	@Test(dependsOnMethods = "Step05_Instructor_Go_To_Course_Page")
	public void Step06_Instructor_Go_To_Course_Details_Page() {

		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
		canvas.coursePage.clickSettingsOnCoursePage();
		canvas.coursePage.verifyCourseDetailsPage(courseName);
	}

	@Test(dependsOnMethods = "Step06_Instructor_Go_To_Course_Details_Page")
	public void Step07_Instructor_Go_To_Navigation_Tab() {
		canvas.coursePage.clickNavigationTab();
		canvas.coursePage.verifyNavigationTab();
	}

	@Test(dependsOnMethods = "Step07_Instructor_Go_To_Navigation_Tab")
	public void Step08_Instructor_Add_Macmillan_Tool() {
		boolean value = canvas.leftMenu.menuIsPresentOrNotAtLeftSide(external_Tool);
		if (value) {
			canvas.macmillan2Page.clickLeftTab("Settings");
			canvas.addMacTools.clickOnCourseStatisticsTab("Navigation");
			canvas.coursePage.enableMacmillanTools(external_Tool);
		}
	}

	@Test(dependsOnMethods = "Step08_Instructor_Add_Macmillan_Tool")
	public void Step09_Instructor_Navigate_To_LP_And_get_CourseCode() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.coursePage.changeWindow(1);
		courseId = canvas.coursePage.getCourseCode();
		DataReadWrite.writeDataToFile("CourseId", courseId);
	}

	@Test(dependsOnMethods = "Step09_Instructor_Navigate_To_LP_And_get_CourseCode")
	public void Step10_Instructor_Logout_fromLP() {
		canvas.pxPage.launchPadLogout();
	}

	@Test(dependsOnMethods = "Step10_Instructor_Logout_fromLP")
	public void Step11_Logout_From_Canvas() {
		canvas.leftMenu.logout();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}
}