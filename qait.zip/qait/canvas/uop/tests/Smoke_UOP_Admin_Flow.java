package com.qait.canvas.uop.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_UOP_Admin_Flow extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor, instructorName;
	private String firstStudent, firstStudentLogin, emailFirstStudent;
	private String secondStudent, secondStudentLogin, emailSecondStudent;
	private String thirdStudent, thirdStudentLogin, emailThirdStudent;
	private String password, inst_password, px_password, mytier;

	private void _initVars() {
		String dateWithTime = canvas.getCurrentDateWithTime();
		mytier=System.getProperty("env");
		if(mytier==null) 
		mytier=ConfigPropertyReader.getProperty("tier");
			courseName = getData("courseNameUOP");
			instructorName = getData("users.instructorUOP.name1");
			instructor = getData("users.instructorUOP.user_name1");
			emailInstructor = getData("users.instructorUOP.user_email1");
		subAccount = getData("subAccount");
		
		firstStudent = "Stud First";
		firstStudentLogin = "StudFirst" + dateWithTime;
		emailFirstStudent = firstStudentLogin + "@fake123.com";
		dateWithTime = canvas.getCurrentDateWithTime();
		secondStudent = "Stud Second";
		secondStudentLogin = "StudSecond" + dateWithTime;
		emailSecondStudent = secondStudentLogin + "@fake123.com";
		dateWithTime = canvas.getCurrentDateWithTime();
		thirdStudent = "Stud Third";
		thirdStudentLogin = "StudThird" + dateWithTime;
		emailThirdStudent = thirdStudentLogin + "@fake123.com";
		inst_password = getData("users.instructorUOP.password");
		password = getData("users.student.password");
		DashBoardPageAction.courseName = courseName;
		px_password = "Password1!";

		data.put("InstUserName", instructor);
		data.put("EmailInst", emailInstructor);
		data.put("FirstStudent", firstStudent);
		data.put("FirstStudentLogin", firstStudentLogin);
		data.put("EmailFirstStudent", emailFirstStudent);

		data.put("SecondStudent", secondStudent);
		data.put("SecondStudentLogin", secondStudentLogin);
		data.put("EmailSecondStudent", emailSecondStudent);

		data.put("ThirdStudent", thirdStudent);
		data.put("ThirdStudentLogin", thirdStudentLogin);
		data.put("EmailThirdStudent", emailThirdStudent);

		data.put("Password", password);
		data.put("inst_password", inst_password);
		data.put("PX_Password", px_password);
		data.put("CourseName", courseName);
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
		canvas.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
	}

	@Test(dependsOnMethods = { "Step02_Log_In_As_Admin" })
	public void Step03_Go_To_Macmillan2_Courses() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Macmillan2_Courses" })
	public void Step04_Verify_Add_New_Course_Modal_Window() {
		canvas.macmillan2Page.clickSubAccount();
		if (mytier.equalsIgnoreCase("prod")) {
			canvas.macmillan2Page.clickOnSubAccountLink("Phoenix PROD Smoke");
		} else {
			canvas.macmillan2Page.clickOnSubAccountLink("Phoenix LT");

		}
		canvas.macmillan2Page.clickOnAddNewCourse();
		canvas.macmillan2Page.verifyAddNewCourseModalWindow();
	}

	@Test(dependsOnMethods = { "Step04_Verify_Add_New_Course_Modal_Window" })
	public void Step05_Create_Course() {
		canvas.macmillan2Page.clickOnCancelButtonOverAddCourse();
	}

	@Test(dependsOnMethods = { "Step05_Create_Course" })
	public void Step06_Verify_Add_New_User_Modal_Window() {
		canvas.macmillan2Page.clickLeftTab("People");
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.verifyAddNewUserModalWindow();
	}

	@Test(dependsOnMethods = { "Step06_Verify_Add_New_User_Modal_Window" })
	public void Step07_Admin_Create_New_User_Instructor() {
		canvas.macmillan2Page.createUser(instructor, emailInstructor);
	}

	@Test(dependsOnMethods = { "Step07_Admin_Create_New_User_Instructor" })
	public void Step08_Admin_Create_A_User_Student() {
		canvas.macmillan2Page.createUser(firstStudent, emailFirstStudent);
	}

	@Test(dependsOnMethods = { "Step08_Admin_Create_A_User_Student" })
	public void Step09_Admin_Redirects_To_Newly_Created_Course() {
		canvas.macmillan2Page.clickLeftTab("Courses");
		canvas.macmillan2Page.enterIntoCourse(courseName);
	}

	@Test(dependsOnMethods = { "Step09_Admin_Redirects_To_Newly_Created_Course" })
	public void Step10_Admin_Redirects_To_People_Page() {
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
	}

	@Test(dependsOnMethods = { "Step10_Admin_Redirects_To_People_Page" })
	public void Step11_Verify_Add_People_Modal_Window() {
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.verifyAddPeopleModalWindow();
	}

	@Test(dependsOnMethods = { "Step11_Verify_Add_People_Modal_Window" })
	public void Step12_Verify_User_Information() {
		canvas.coursePage.enterUserDetails("Teacher", emailInstructor);
		canvas.coursePage.verifyUserDetails(emailInstructor);
	}

	@Test(dependsOnMethods = { "Step12_Verify_User_Information" })
	public void Step13_Verify_Instructor_Is_Added_To_Course() {
		canvas.coursePage.clickOnAddUserButton();
		canvas.coursePage.verifyUserIsAddedToCourse(instructorName);
	}

	@Test(dependsOnMethods = { "Step13_Verify_Instructor_Is_Added_To_Course" })
	public void Step14_Admin_Enroll_Student_To_Course() {
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.enterUserDetails("Student", emailFirstStudent);
		canvas.coursePage.clickOnAddUserButton();
	}

	@Test(dependsOnMethods = { "Step14_Admin_Enroll_Student_To_Course" })
	public void Step15_Admin_Add_Login_For_Student() {
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnUserNameLink(firstStudent);
		canvas.coursePage.verifyUserDetailPage(firstStudent);
		canvas.coursePage.clickOnMoreUserDetails();
		canvas.coursePage.verifyMembershipLoginInformationSection();
		canvas.coursePage.clickOnAddLoginLink();
		canvas.coursePage.verifyAddLoginModalWindow();
		canvas.coursePage.enterLoginDetails(firstStudentLogin, password);
		canvas.coursePage.clickOnAddLoginButton();
		canvas.coursePage.verifyUserLogin(firstStudentLogin);
	}

	@Test(dependsOnMethods = { "Step15_Admin_Add_Login_For_Student" })
	public void Step16_Admin_Log_Out_Canvas_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}
}