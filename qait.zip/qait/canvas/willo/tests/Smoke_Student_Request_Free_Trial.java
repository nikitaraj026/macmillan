package com.qait.canvas.willo.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Student_Request_Free_Trial extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String courseName;
	private String instructorUserName;
	private String firstStudent, emailFirstStudent;
	private String studentFirstName, studentLastName;
	private String external_Tool;
	private String password, px_password, inst_password;
	private String quizTitle1, quizTitle2, quiz1CorrectAnswer1, quiz2CorrectAnswer1, quiz1Grade, quiz2Grade;
	private String chapterName, chapterIntroduction;
	private String bookIdentifier, mytier;

	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		_initVars(book);
		px_password = "Password1!";
	}

	private void _initVars(String book) {
		if (book.contains("myers11e")) {
			bookIdentifier = "myers";
			getData(bookIdentifier + ".author");
			courseName = canvas.coursePage.readDataFromYaml("CourseName");
			instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
			inst_password = canvas.coursePage.readDataFromYaml("inst_password");
			firstStudent = canvas.coursePage.readDataFromYaml("FirstStudentLogin");
			emailFirstStudent = canvas.coursePage.readDataFromYaml("EmailFirstStudent");
			password = canvas.coursePage.readDataFromYaml("Password");
			external_Tool = getData("external_tool_willo");
			studentFirstName = "FSName";
			studentLastName = "LSName";
			px_password = "Password1!";

			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quiz1CorrectAnswer1 = getData(bookIdentifier + ".quiz1.correctAnswer1");
			quiz1Grade = getData(bookIdentifier + ".quiz1.grade");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			quiz2CorrectAnswer1 = getData(bookIdentifier + ".quiz2.correctAnswer1");
			quiz2Grade = getData(bookIdentifier + ".quiz2.grade");
			chapterName = getData(bookIdentifier + ".TOC_chapter5");
			chapterIntroduction = getData(bookIdentifier + ".TOC_chapter5_introduction");
			getData(bookIdentifier + ".TOC_chapter5_content1");
			getData(bookIdentifier + ".TOC_chapter5_subcontent1");

		} else {
			bookIdentifier = "lunsford";
			courseName = canvas.coursePage.readDataFromYaml("CourseName");
			instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
			firstStudent = canvas.coursePage.readDataFromYaml("FirstStudent");
			emailFirstStudent = canvas.coursePage.readDataFromYaml("EmailFirstStudent");
			password = canvas.coursePage.readDataFromYaml("Password");
			external_Tool = getData("external_tool");
			studentFirstName = "FSName";
			studentLastName = "LSName";
			px_password = "Password1!";

			quizTitle1 = getData(bookIdentifier + ".quiz1.name");
			quiz1CorrectAnswer1 = getData(bookIdentifier + ".quiz1.correctAnswer1");
			quiz1Grade = getData(bookIdentifier + ".quiz1.grade");
			quizTitle2 = getData(bookIdentifier + ".quiz2.name");
			quiz2CorrectAnswer1 = getData(bookIdentifier + ".quiz2.correctAnswer1");
			quiz2Grade = getData(bookIdentifier + ".quiz2.grade");
			chapterName = "The Top Twenty";
			chapterIntroduction = "Quick Help: Taking a writing inventory";
		}
		mytier = System.getProperty("env");
		if (mytier == null)
			mytier = ConfigPropertyReader.getProperty("tier");

	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.toolsPage.clearBrowserCache();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Student() {
		for (int i = 0; i < 2; i++) {
			canvas.loginPage.loginToTheApplication(firstStudent + "1", password + "1");
		}
		canvas.loginPage.verifyErrorMessageForInvalidLogIn();
		canvas.loginPage.loginToTheApplication(firstStudent, password);
//		canvas.leftMenu.goToUserCourse(courseName);	
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Student")
	public void Step03_Student_Accept_Agree_Term_Of_Application() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}

	@Test(dependsOnMethods = "Step03_Student_Accept_Agree_Term_Of_Application")
	public void Step04_Student_Go_To_Dashboard_Page() {
		canvas.loginPage.loginToTheApplication(firstStudent, password);
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickSubmitTermsBtn();
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step04_Student_Go_To_Dashboard_Page")
	public void Step05_Student_Go_To_Course_Page() {
		canvas.dashboardPage.acceptInvite();
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step05_Student_Go_To_Course_Page")
	public void Step06_Student_Attempt_Assignment() {
//		canvas.toolsPage.runHandleSecurityExe();
		canvas.coursePage.clickAssignmentsOnCoursePage();
		canvas.coursePage.clickOnAssignmentLinkWillo(quizTitle2);
		canvas.toolsPage.click_BtnContinueToQuiz("Manual_Quiz");
	}

	@Test(dependsOnMethods = "Step06_Student_Attempt_Assignment")
	public void Step07_Verify_That_Student_Complete_SSO() {
		canvas.MiddlewarePage.willo_SSO();
		canvas.pxPage.userNavigateToPxWindow();
	}

	@Test(dependsOnMethods = { "Step07_Verify_That_Student_Complete_SSO" })
	public void Step08_Student_Attempt_Manual_Quiz() {
//		canvas.fnePage.verifyStudentIsOnQuizStartPageWillo();
		canvas.fnePage.attemptQuizCorrectlyWillo(quiz2CorrectAnswer1);
		canvas.fnePage.clickDoneButton();
		canvas.fnePage.clickOnHomeButton();
	}

	@Test(dependsOnMethods = { "Step08_Student_Attempt_Manual_Quiz" })
	public void Step09_Student_Attempt_Auto_Quiz() {
		if (bookIdentifier.contains("myers")) {
			canvas.pxPage.clickAssignedTOCItem(quizTitle1);
			canvas.fnePage.verifyStudentIsOnQuizStartPageWillo();
			canvas.fnePage.attemptQuizCorrectlyWillo(quiz1CorrectAnswer1);
			canvas.fnePage.clickDoneButton();
			canvas.fnePage.clickOnHomeButton();
		} else {
			canvas.pxPage.clickOnAssignmentsTab();
			canvas.pxPage.clickAssignedTOCItem(quizTitle1);
			canvas.fnePage.verifyStudentIsOnQuizStartPageWillo();
			canvas.fnePage.attemptQuizCorrectly(quiz1CorrectAnswer1);
			canvas.fnePage.clickDoneButton();
			canvas.fnePage.clickOnHomeButton();
		}

	}

	@Test(dependsOnMethods = { "Step09_Student_Attempt_Auto_Quiz" })
	public void Step10_Student_Attemp_TOC_EBook() {
		if (bookIdentifier.contains("myers")) {
			canvas.pxPage.clickAssignedTOCItem(chapterName);
			canvas.pxPage.clickAssignedTOCItem(chapterIntroduction);
			canvas.fnePage.clickOnHomeButton();
		} else {
			canvas.pxPage.clickOnAssignmentsTab();
			canvas.pxPage.clickAssignedTOCItem(chapterIntroduction);
			canvas.fnePage.clickOnHomeButton();
			canvas.pxPage.clickOnHomeButtonTab();
		}

	}

	@Test(dependsOnMethods = "Step10_Student_Attemp_TOC_EBook")
	public void Step11_Student_Logout_LaunchPad_Request() {
		canvas.pxPage.launchPadLogout();
	}

	@Test(dependsOnMethods = "Step11_Student_Logout_LaunchPad_Request")
	public void Step12_Student_Navigate_To_Lp() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPageForWillo();
		canvas.toolsPage.click_BtnContinueToWilloMacmillan();
//		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.runHandleSecurityExe();
		canvas.toolsPage.clickLaunchPad();
		canvas.coursePage.userNavigateToPxWindow();
//		canvas.pxPage.verify_freeTrialMessageIsDisplayed();
		canvas.pxPage.launchPadLogout();
	}

	@Test(dependsOnMethods = "Step12_Student_Navigate_To_Lp")
	public void Step_13_Student_Verify_Diagnostics_Page() {
		canvas.toolsPage.clickOnMacmillanDiagnosticsLink();
		canvas.toolsPage.verifyMacmillanDiagnosticsPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = "Step_13_Student_Verify_Diagnostics_Page")
	public void Step_14_Student_Verify_User_Profile_Page() throws InterruptedException {
		canvas.toolsPage.clickOnMacmillanUserProfile();
//		canvas.toolsPage.verifyMacmillanUserProfilePage(firstStudent + "@yopmail.com");
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = "Step_14_Student_Verify_User_Profile_Page")
	public void Step_15_Student_Verify_Technical_Support_Page() {
		canvas.toolsPage.clickOnMacmillanTechnicalSupportLink();
		canvas.toolsPage.verifyMacmillanTechnicalSupportPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = "Step_15_Student_Verify_Technical_Support_Page")
	public void Step16_Student_Logout_Canvas_Request() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step16_Student_Logout_Canvas_Request")
	public void Step17_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructorUserName, inst_password);
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step17_Log_In_As_Instructor")
	public void Step18_Go_To_Course_Homepage() {
		canvas.leftMenu.goToUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step18_Go_To_Course_Homepage")
	public void Step19_Go_To_Macmillan_Tools_Page_And_Refresh_Grades_Request() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPageForWillo();
	canvas.toolsPage.click_BtnContinueToWilloMacmillan();
		canvas.toolsPage.clickOnMacmillanGradeRefreshLink();
		canvas.toolsPage.verifyGradeRefreshPage();
		canvas.toolsPage.clickSelectedButtonOnMacmillanHigherEducationGradeSyncRefresh();
		canvas.toolsPage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle2);
		canvas.toolsPage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(chapterIntroduction);
		canvas.toolsPage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
	}

	@Test(dependsOnMethods = "Step19_Go_To_Macmillan_Tools_Page_And_Refresh_Grades_Request")
	public void Step20_Verify_Grades_In_Gradebook_Request() {
		canvas.coursePage.clickGradesOnCoursePage();
		canvas.coursePage.verifyGradesInCanvasGradebook(firstStudent, quizTitle2, quiz2Grade);
	}

	@Test(dependsOnMethods = "Step20_Verify_Grades_In_Gradebook_Request")
	public void Step21_Instructor_Logout() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}

}