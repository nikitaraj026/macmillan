package com.qait.canvas.willo.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.ConfigPropertyReader;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Admin_FlowWillo extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor, instructorName;
	private String firstStudent, firstStudentLogin, emailFirstStudent;
	private String secondStudent, secondStudentLogin, emailSecondStudent;
	private String thirdStudent, thirdStudentLogin, emailThirdStudent;
	private String password, inst_password, px_password, mytier, randomCourseName;

	private void _initVars() {
		String dateWithTime = canvas.getCurrentDateWithTime();

		// courseName = "TestCourse_" + timeStamp;
		mytier = System.getProperty("env");
		if (mytier == null)
			mytier = ConfigPropertyReader.getProperty("tier");
		courseName = getData("courseNameWillo");
		subAccount = getData("subAccount");
		instructorName = getData("users.instructorWillo.name1");
		instructor = getData("users.instructorWillo.user_name1");
		// instructor = "Autoinst_"+timeStamp;
		// emailInstructor = instructor + "@fake123.com";
		emailInstructor = getData("users.instructorWillo.user_email1");
		firstStudent = "StudFirst last";
		firstStudentLogin = "StudFirst" + dateWithTime;
		emailFirstStudent = firstStudentLogin + "@yopmail.com";
		dateWithTime = canvas.getCurrentDateWithTime();
		secondStudent = "StudSecond last";
		secondStudentLogin = "StudSecond" + dateWithTime;
		emailSecondStudent = secondStudentLogin + "@yopmail.com";
		dateWithTime = canvas.getCurrentDateWithTime();
		thirdStudent = "StudThird last";
		thirdStudentLogin = "StudThird" + dateWithTime;
		emailThirdStudent = thirdStudentLogin + "@yopmail.com";
		inst_password = getData("users.instructorWillo.password");
		password = getData("users.student.password");
		DashBoardPageAction.courseName = courseName;
		px_password = "Password1!";
		randomCourseName = RandomStringUtils.randomAlphabetic(5);

		data.put("InstUserName", instructor);
		data.put("EmailInst", emailInstructor);
		data.put("FirstStudent", firstStudent);
		data.put("FirstStudentLogin", firstStudentLogin);
		data.put("EmailFirstStudent", emailFirstStudent);

		data.put("SecondStudent", secondStudent);
		data.put("SecondStudentLogin", secondStudentLogin);
		data.put("EmailSecondStudent", emailSecondStudent);

		data.put("ThirdStudent", thirdStudent);
		data.put("ThirdStudentLogin", thirdStudentLogin);
		data.put("EmailThirdStudent", emailThirdStudent);

		data.put("Password", password);
		data.put("inst_password", inst_password);
		data.put("PX_Password", px_password);
		data.put("CourseName", courseName);
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
		canvas.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.toolsPage.clearBrowserCache();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.invalidLogin(getData("users.admin.user_name"), getData("users.admin.password"));
		canvas.loginPage.verifyErrorMessageForInvalidLogIn();
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
	}

	@Test(dependsOnMethods = { "Step02_Log_In_As_Admin" })
	public void Step03_Go_To_Macmillan2_Courses() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Macmillan2_Courses" })
	public void Step04_Verify_Add_New_Course_Modal_Window() {
		canvas.macmillan2Page.clickOnAddNewCourse();
		canvas.macmillan2Page.verifyAddNewCourseModalWindow();
//	canvas.macmillan2Page.delete_Course(randomCourseName);
	}

	@Test(dependsOnMethods = { "Step04_Verify_Add_New_Course_Modal_Window" })
	public void Step05_Create_Course() {
//		canvas.leftMenu.clickOnAdminLeftMenu();
//		canvas.leftMenu.clickMacmillan2();
	}

	@Test(dependsOnMethods = { "Step05_Create_Course" })
	public void Step06_Verify_Add_New_User_Modal_Window() {
		canvas.macmillan2Page.clickLeftTab("People");
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.verifyAddNewUserModalWindow();
	}

	@Test(dependsOnMethods = { "Step06_Verify_Add_New_User_Modal_Window" })
	public void Step07_Admin_Create_New_User_Instructor() {
		canvas.macmillan2Page.createUser(instructor, emailInstructor);
	}

	@Test(dependsOnMethods = { "Step07_Admin_Create_New_User_Instructor" })
	public void Step08_Admin_Create_3_Users_Student() {
		canvas.macmillan2Page.createUser(firstStudent, emailFirstStudent);
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.createUser(secondStudent, emailSecondStudent);
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.createUser(thirdStudent, emailThirdStudent);
	}

	@Test(dependsOnMethods = { "Step08_Admin_Create_3_Users_Student" })
	public void Step09_Admin_Redirects_To_Newly_Created_Course() {
		canvas.macmillan2Page.clickLeftTab("Courses");
		canvas.macmillan2Page.enterIntoCourseName(courseName);
	}

	@Test(dependsOnMethods = { "Step09_Admin_Redirects_To_Newly_Created_Course" })
	public void Step10_Publish_Course() {
		// canvas.coursePage.publishCourse();
	}

	@Test(dependsOnMethods = { "Step10_Publish_Course" })
	public void Step11_Admin_Redirects_To_People_Page() {
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
	}

	@Test(dependsOnMethods = { "Step11_Admin_Redirects_To_People_Page" })
	public void Step12_Verify_Add_People_Modal_Window() {
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.verifyAddPeopleModalWindow();
	}

	@Test(dependsOnMethods = { "Step12_Verify_Add_People_Modal_Window" })
	public void Step13_Verify_User_Information() {
		canvas.coursePage.enterUserDetails("Teacher", emailInstructor);
		canvas.coursePage.verifyUserDetails(emailInstructor);
	}

	@Test(dependsOnMethods = { "Step13_Verify_User_Information" })
	public void Step14_Verify_Instructor_Is_Added_To_Course() {
		canvas.coursePage.clickOnAddUserButton();
		canvas.coursePage.verifyUserIsAddedToCourse(instructorName);
	}

	@Test(dependsOnMethods = { "Step14_Verify_Instructor_Is_Added_To_Course" })
	public void Step15_Admin_Enroll_Three_Student_To_Course() {
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.enterUserDetails("Student", emailFirstStudent);
		canvas.coursePage.clickOnAddUserButton();

		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.enterUserDetails("Student", emailSecondStudent);
		canvas.coursePage.clickOnAddUserButton();

		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.enterUserDetails("Student", emailThirdStudent);
		canvas.coursePage.clickOnAddUserButton();

//		canvas.coursePage.verifyStudentEnrollment();
	}

	@Test(dependsOnMethods = { "Step15_Admin_Enroll_Three_Student_To_Course" })
	public void Step16_Admin_Redirects_To_UserName_Details_Page() {
		// canvas.coursePage.clickOnUserNameLink(instructor);
		// canvas.coursePage.verifyUserDetailPage(instructor);
	}

	@Test(dependsOnMethods = { "Step16_Admin_Redirects_To_UserName_Details_Page" })
	public void Step17_Verify_Membership_LoginInformation_Section() {
		// canvas.coursePage.clickOnMoreUserDetails();
		// canvas.coursePage.verifyMembershipLoginInformationSection();
	}

	@Test(dependsOnMethods = { "Step17_Verify_Membership_LoginInformation_Section" })
	public void Step18_Verify_Add_Login_Modal_Window() {
		// canvas.coursePage.clickOnAddLoginLink();
		// canvas.coursePage.verifyAddLoginModalWindow();
	}

	@Test(dependsOnMethods = { "Step18_Verify_Add_Login_Modal_Window" })
	public void Step19_Admin_Add_Login_For_Instructor() {
		// canvas.coursePage.enterLoginDetails(instructor, password);
		// canvas.coursePage.clickOnAddLoginButton();
		// canvas.coursePage.verifyUserLogin(instructor);
	}

	@Test(dependsOnMethods = { "Step19_Admin_Add_Login_For_Instructor" })
	public void Step20_Admin_Add_Login_For_Three_Student() {
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnUserNameLink(firstStudent);
		canvas.coursePage.verifyUserDetailPage(firstStudent);
		canvas.coursePage.clickOnMoreUserDetails();
		canvas.coursePage.verifyMembershipLoginInformationSection();
		canvas.coursePage.clickOnAddLoginLink();
		canvas.coursePage.verifyAddLoginModalWindow();
		canvas.coursePage.enterLoginDetails(firstStudentLogin, password);
		canvas.coursePage.clickOnAddLoginButton();
		canvas.coursePage.verifyUserLogin(firstStudentLogin);

		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnUserNameLink(secondStudent);
		canvas.coursePage.clickOnMoreUserDetails();
		canvas.coursePage.clickOnAddLoginLink();
		canvas.coursePage.enterLoginDetails(secondStudentLogin, password);
		canvas.coursePage.clickOnAddLoginButton();
		canvas.coursePage.verifyUserLogin(secondStudentLogin);

		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnUserNameLink(thirdStudent);
		canvas.coursePage.clickOnMoreUserDetails();
		canvas.coursePage.clickOnAddLoginLink();
		canvas.coursePage.enterLoginDetails(thirdStudentLogin, password);
		canvas.coursePage.clickOnAddLoginButton();
		canvas.coursePage.verifyUserLogin(thirdStudentLogin);
	}

//	@Test(dependsOnMethods = { "Step20_Admin_Add_Login_For_Three_Student" })
//	public void Step21_Admin_Log_Out_Canvas_Application() {
//		canvas.leftMenu.logout();
//		canvas.loginPage.verifyLoginPage();
//	}
//
//	@AfterClass(alwaysRun = true)
//	public void Stop_Test_Session() {
//		canvas.closebrowserSession();
//	}
}