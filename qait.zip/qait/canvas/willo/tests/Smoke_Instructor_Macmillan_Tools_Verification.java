package com.qait.canvas.willo.tests;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import static com.qait.automation.utils.CustomFunctions.getStringWithTimestamp;
import static com.qait.automation.utils.YamlReader.getData;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Smoke_Instructor_Macmillan_Tools_Verification extends Parent_Test {

	CanvasTestSessionInitiator canvas;

	private String courseName;
	private String instructorUserName;
	private String external_Tool;
	private String instructorEmail, instructorPassword;
	private String bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName, academicTerm, school;
	String quizTitle1, quizTitle2;

	private void initVars() {
		System.currentTimeMillis();
		instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
		instructorEmail = canvas.coursePage.readDataFromYaml("EmailInst");
		instructorPassword = canvas.coursePage.readDataFromYaml("inst_password");
		courseName = canvas.coursePage.readDataFromYaml("CourseName");
		external_Tool = getData("external_tool_willo");

		String bookIdentifier = "myers";
		quizTitle1 = getData(bookIdentifier + ".quiz1.name");
		quizTitle2 = getData(bookIdentifier + ".quiz2.name");

		bookTitle = getData("bookTitleLP");
		pxCourseName = getStringWithTimestamp("CANVAS");
		courseNumber = "";
		sectionNumber = "";
		instructorName = getData("users.instructor.name1");
		academicTerm = "Fall 2016";
		school = "TEST University (New York, NY)";

	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		initVars();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step01_Launch_Application")
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructorUserName, instructorPassword);
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Instructor")
	public void Step03_Go_To_Course_Page() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Course_Page" })
	public void Step04_Navigate_To_Macmillan_Tools_Page() {
		canvas.toolsPage.runHandleSecurityExe();
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.verifyToolsPageForWillo();
		canvas.toolsPage.click_BtnContinueToWilloMacmillan();
	}

	@Test(dependsOnMethods = { "Step04_Navigate_To_Macmillan_Tools_Page" })
	public void Step05_Verify_Ebook_Link() {

		canvas.toolsPage.clickEbook();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.verifyEbookSectionIsOpen();
		canvas.pxPage.clickOnLPHomeLink();
		canvas.pxPage.launchPadLogout();
	}

	@Test(dependsOnMethods = { "Step05_Verify_Ebook_Link" })
	public void Step06_Verify_Gradebook_Link() {

		canvas.toolsPage.clickGradebook();
		canvas.coursePage.userNavigateToPxWindow();
		// canvas.pxPage.handleGuideModalWindow();
		canvas.pxPage.verifyGradeBookPageOpens();
		canvas.pxPage.clickOnHomeButton();
		canvas.pxPage.launchPadLogout();
	}

	@Test(dependsOnMethods = { "Step06_Verify_Gradebook_Link" })
	public void Step07_Verify_Diagnostics_Page() {

		canvas.toolsPage.clickOnMacmillanDiagnosticsLink();
		canvas.toolsPage.verifyMacmillanDiagnosticsPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = { "Step07_Verify_Diagnostics_Page" })
	public void Step08_Verify_Roster_Page() {

		//canvas.toolsPage.clickOnMacmillanRosterLink();
		//canvas.toolsPage.verifyMacmillanRosterPage(instructorEmail);
		//canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = { "Step08_Verify_Roster_Page" })
//	public void Step09_Verify_Technical_Support_Page() {
//		
//		canvas.toolsPage.clickOnMacmillanTechnicalSupportLink();
//		canvas.toolsPage.verifyMacmillanTechnicalSupportPage();
//		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
//	}

//	@Test(dependsOnMethods = { "Step09_Verify_Technical_Support_Page" })
	public void Step10_Verify_User_Profile_Page() throws InterruptedException {

		canvas.toolsPage.clickOnMacmillanUserProfile();
		canvas.toolsPage.verifyMacmillanUserProfilePage(instructorEmail);
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = { "Step10_Verify_User_Profile_Page" })
	public void Step11_Verify_Macmillan_Content_Refresh_Page() {
		canvas.toolsPage.clickLaunchPad();
		canvas.coursePage.userNavigateToPxWindow();
		canvas.pxPage.updateGradeValueOfAssignedTOCItem(quizTitle1, true, "12");
		canvas.pxPage.launchPadLogout();
		canvas.toolsPage.clickOnMacmillanContentRefreshLink();
		canvas.toolsPage.verifyContentRefreshPage();
		canvas.toolsPage.selectAssignmentsForProcessing();
		canvas.toolsPage.clickOnRefreshContentButton();
		canvas.toolsPage.clickOnOKButtonOnTaskInProgressPopUp();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.modulePage.verifyGradesOnModulesPage("12");
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.click_BtnContinueToWilloMacmillan();
	}

	@Test(dependsOnMethods = { "Step11_Verify_Macmillan_Content_Refresh_Page" })
	public void Step12_Verify_Macmillan_Background_Updates_Page() {

		canvas.toolsPage.clickOnMacmillanBackgroundUpdatesLink();
		canvas.toolsPage.verifyMacmillanBackgroundUpdatesPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = { "Step12_Verify_Macmillan_Background_Updates_Page" })
	public void Step13_Verify_Macmillan_Token_Registration() {

		canvas.toolsPage.clickOnTokenRegistrationLink();
		canvas.toolsPage.verifyTokenRegistrationPage();
		canvas.toolsPage.clickOnAutheticateButtonOnTokenRegistrationPage();
		canvas.toolsPage.verifyMacmillanLMSIntegrationPage();
		canvas.toolsPage.clickOnAuthorizeButtonOnLMSIntegrationPage();
		canvas.toolsPage.verifySuccessfulTokenRegistration();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = { "Step13_Verify_Macmillan_Token_Registration" })
	public void Step14_Unlink_Macmillan_Course() {

		canvas.toolsPage.clickOnUnlinkMacmillanToolLink();
		canvas.toolsPage.verifyEndCourseAssociationPage();
		canvas.toolsPage.disassociateCourse();
		canvas.toolsPage.verifyEndCourseAssociationPageAfterCourseIsDisassociated();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.verifyNonAssociatedToolsPage("Connect with LaunchPad");
	}

	@Test(dependsOnMethods = { "Step14_Unlink_Macmillan_Course" })
	public void Step15_Associate_New_Course_And_Verify_Missing_Content_Link() {

		canvas.toolsPage.clickGettingStartedLink("Connect with LaunchPad");
		canvas.provisionPage.authenticateToken();
		canvas.provisionPage.verifyProvisionPageOpens();
		canvas.provisionPage.createNewCourse(bookTitle, pxCourseName, courseNumber, sectionNumber, instructorName,
				academicTerm, false, "", school);
		// courseTitle must be short enough so that <br> tag not added in course name in
		// table
		canvas.provisionPage.verifyCourseCreated(pxCourseName);
		canvas.provisionPage.associateCourse(pxCourseName);
		canvas.toolsPage.verifyToolsPage();
		canvas.toolsPage.clickOnMacmillanMissingContentLink();
		canvas.toolsPage.verifyMacmillanMissingContentPage();
		canvas.toolsPage.selectAssignmentsForProcessing();
		canvas.toolsPage.clickOnDeleteSelectedContentButton();
		canvas.toolsPage.clickOnOKButtonOnTaskInProgressPopUp();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.modulePage.verifyQuizAssignmentsAreRemovedFromModulesPage(quizTitle1);
		canvas.modulePage.verifyQuizAssignmentsAreRemovedFromModulesPage(quizTitle2);

	}

//	@Test(dependsOnMethods = { "Step15_Associate_New_Course_And_Verify_Missing_Content_Link" })
	public void Step16_Verify_Technical_Support_Page() {
		canvas.toolsPage.clickOnMacmillanTechnicalSupportLink();
		canvas.toolsPage.verifyMacmillanTechnicalSupportPage();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}

	@Test(dependsOnMethods = "Step15_Associate_New_Course_And_Verify_Missing_Content_Link")
	public void Step17_Instructor_Logout() {
		canvas.leftMenu.logout();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closeBrowserSession();
	}
}