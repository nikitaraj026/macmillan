package com.qait.canvas.achieve.tests;

import static com.qait.automation.utils.YamlReader.getData;

import java.lang.reflect.Method;

import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

public class Smoke_Admin_Unenroll_Instructor_From_Course extends Parent_Test{
	CanvasTestSessionInitiator canvas;
	private String instructor,instremail;
	private String courseName;
	private String externalTool;
	private String moduleName;
	
	private void _initVars() {
		instructor = getData("achieve_users.instructor.user_name1");
		instremail= getData("achieve_users.instructor.user_email1");
		courseName = getData("courseName_achieve");
		externalTool = getData("external_tool");
		moduleName = getData("moduleName");
	}
	
	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}
	
	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
	}
	
	@BeforeMethod
    public void handleTestMethodName(Method method) {
        canvas.stepStartMessage(method.getName()); 
    }
	
	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}
	
	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}
	
	@Test(dependsOnMethods={"Step01_Launch_Application"})
	public void Step02_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(
				instructor,
				getData("users.instructor.password"));
		canvas.dashboardPage.verifyDashboardPage();
		
	}
	
	@Test(dependsOnMethods="Step02_Log_In_As_Instructor") 
	public void Step03_Instructor_Go_To_Course_Details_Page() {
		canvas.leftMenu.clickOnCoursesLeftMenu();
		canvas.leftMenu.clickOnUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}
	
	@Test(dependsOnMethods = "Step03_Instructor_Go_To_Course_Details_Page")
	public void Step04_Remove_Already_Created_Assignment() {
		canvas.coursePage.clickAssignmentsOnCoursePage();
		canvas.coursePage.deleteAssignmentsIfPresent("Delete");
		canvas.coursePage.refreshPage();
		canvas.coursePage.clickModulesOnCoursePage();
		canvas.coursePage.verifyModulePresentAndSelectOptionFromSetting("Delete");
		canvas.coursePage.enterIntoToolsSection(externalTool);
		canvas.toolsPage.verifyToolsPage();
		if (!canvas.toolsPage.softVerifyCourseIsAssociated("Connect with Achieve")) {
			throw new SkipException("Content already removed");
		}
		canvas.toolsPage.clickOnUnlinkMacmillanToolLink();
		canvas.toolsPage.verifyEndCourseAssociationPage();
		canvas.toolsPage.clickOnRemoveMacmillanContent();
		canvas.toolsPage.disassociateCourse();
		canvas.toolsPage.verifyEndCourseAssociationPageAfterCourseIsDisassociated();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
		canvas.toolsPage.verifyNonAssociatedToolsPage("Connect with Achieve");
	}
	
	@Test(dependsOnMethods="Step03_Instructor_Go_To_Course_Details_Page")
	public void Step05_InstructorUnlinkProfile() throws InterruptedException {
		//canvas.coursePage.enterIntoToolsSection(externalTool);
//		canvas.toolsPage.click_BtnContinueToWilloMacmillanLTNew();
		canvas.toolsPage.clickOnMacmillanUserProfile();
		if (!canvas.profilePage.softVerifyProfileIsLinked()) {
			canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
			throw new SkipException("Profile already disconnected");
		}
		canvas.toolsPage.verifyMacmillanUserProfilePageWhenConnected(instremail);
		canvas.profilePage.clickOnDisconnectThisAccount();
		canvas.profilePage.clickBtnConfirmDisconnect();
		canvas.toolsPage.closeSecondryWindowAndComeBacktoMainWindow();
	}
	
	@Test(dependsOnMethods="Step03_Instructor_Go_To_Course_Details_Page", alwaysRun = true)
	public void Step06_Instructor_Logout() {
		canvas.leftMenu.refreshPage();
		canvas.leftMenu.logout();
	}
	
	@Test(dependsOnMethods={"Step06_Instructor_Logout"}, alwaysRun = true)
	public void Step07_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(
				getData("users.admin.user_name"),
				getData("users.admin.password"));
		//canvas.dashboardPage.verifyDashboardPage();
	}
	
	@Test(dependsOnMethods={"Step07_Log_In_As_Admin"})
	public void Step08_Go_To_Macmillan2_Courses() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
	}
	
	@Test(dependsOnMethods={"Step08_Go_To_Macmillan2_Courses"})
	public void Step09_Uneroll_User_From_Course() {
		//canvas.macmillan2Page.unenrollUserFromAllCourses(instructor);
		canvas.macmillan2Page.enterIntoCourse(courseName);
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
		canvas.macmillan2Page.removeAllUser();
	}
	
	@Test(dependsOnMethods="Step09_Uneroll_User_From_Course")
	public void Step10_Remove_Macmillan_Tool() {
		canvas.coursePage.clickSettingsOnCoursePage();
		canvas.coursePage.verifyCourseDetailsPage(courseName);
		canvas.coursePage.clickNavigationTab();
		canvas.coursePage.verifyNavigationTab();
		//canvas.coursePage.disableExternalTool(externalTool);
	}
	
	@Test(dependsOnMethods= "Step10_Remove_Macmillan_Tool")
	public void Step11_Admin_Logout_Of_Canvas_Application() {
		canvas.leftMenu.refreshPage();
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage(); 
	}
	
	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}
}
