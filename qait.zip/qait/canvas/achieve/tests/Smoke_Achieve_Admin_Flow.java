package com.qait.canvas.achieve.tests;

import java.awt.AWTException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.RandomStringUtils;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.automation.utils.PropFileHandler;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Achieve_Admin_Flow extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor, instructorName;
	private String firstStudent, firstStudentLogin, emailFirstStudent;
	private String password, inst_password, px_password;
	String emailAdmin, passwordAdmin, newCourseName, courseCode, emailForNewAccount;
	String template,tempCode,tempISBN;
	String copyCourse,copyCourseCode;

	private void _initVars() {
		String dateWithTime = canvas.getCurrentDateWithTime();
		emailAdmin = getData("achieve_users.admin.user_name");
		passwordAdmin = getData("achieve_users.admin.password");
		template=RandomStringUtils.randomAlphabetic(6);
		tempCode=RandomStringUtils.randomAlphanumeric(5);
		tempISBN=RandomStringUtils.randomAlphabetic(13);
		newCourseName = RandomStringUtils.randomAlphabetic(6);
		courseCode = RandomStringUtils.randomAlphanumeric(5);
		courseName = getData("courseName_achieve");
		subAccount = getData("subAccount");
		copyCourse="canvas_Achieve"+dateWithTime;
		
		copyCourseCode=RandomStringUtils.randomAlphanumeric(5);
		instructorName = getData("achieve_users.instructor.name1");
		instructor = getData("achieve_users.instructor.user_name1");
		emailInstructor = getData("achieve_users.instructor.user_email1");

		firstStudent = "Stud First";
		firstStudentLogin = "StudFirst" + dateWithTime;
		emailFirstStudent = firstStudentLogin + "@yopmail.com";
		inst_password = getData("users.instructor.password");
		password = getData("users.student.password");
		DashBoardPageAction.courseName = courseName;
		px_password = "Password1!";
		if (PropFileHandler.readProperty("tier").equalsIgnoreCase("lt"))
			emailForNewAccount = "adminflowtest@yopmail.com";
		else
		emailForNewAccount = "adminflowtestprod@yopmail.com";
	}

	@BeforeSuite
	@Parameters({ "suiteType", "productID", "suiteID" })
	public void testrunSetup(@Optional("0") String suiteType, @Optional("0") String productID,
			@Optional("0") String suiteID) {
		beforeSuiteMethod(suiteType, productID, suiteID);
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
		canvas.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		
		canvas.toolsPage.clearBrowserCache();
		canvas.launchAchieveApplication();
		
		}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Verfiy_Admin_Able_To_Login() {

		canvas.achieveAdminPage.login_TO_Achieve(emailAdmin, passwordAdmin);
	}

	@Test(dependsOnMethods = { "Step02_Verfiy_Admin_Able_To_Login" })
	public void Step03_Verfiy_Admin_Able_To_Create_TemplateAndCourse() {
		canvas.achieveAdminPage.create_template(template, tempCode, tempISBN);
		canvas.achieveAdminPage.find_TestCourse(template);
		canvas.achieveAdminPage.input_Content(template);
		canvas.achieveAdminPage.copy_Course(copyCourse, copyCourseCode);
		canvas.achieveAdminPage.find_TestCourse(copyCourse);
		canvas.achieveAdminPage.create_Content(copyCourse);
		canvas.achieveAdminPage.assignAssigments();
		
		//canvas.achieveAdminPage.Admin_Create_Course(newCourseName, courseCode);
	}

	@Test(dependsOnMethods = { "Step03_Verfiy_Admin_Able_To_Create_TemplateAndCourse" })
	public void Step04_Verfiy_Admin_Able_To_Find_Test_Course() {
		
		canvas.achieveAdminPage.find_TestCourse(copyCourse);
		
	}

	@Test(dependsOnMethods = { "Step04_Verfiy_Admin_Able_To_Find_Test_Course" })
	public void Step05_Verfiy_Admin_Able_To_Enroll_Instructor() {
		canvas.achieveAdminPage.verify_Enroll_Instructor_Modal_Window();
		canvas.achieveAdminPage.add_Instructor_Email(emailForNewAccount);

	}

	@Test(dependsOnMethods = { "Step05_Verfiy_Admin_Able_To_Enroll_Instructor" })
	public void Step06_Verify_Admin_Able_To_Unenroll_Instructor() {
		canvas.achieveAdminPage.remove_Instructor(emailForNewAccount);
	}

	@Test(dependsOnMethods = { "Step06_Verify_Admin_Able_To_Unenroll_Instructor" })
	public void Step07_Verify_Admin_Able_To_Edit_Course_Details() {
		//canvas.achieveAdminPage.editTestCourseDetails();
	}

	@Test(dependsOnMethods = { "Step07_Verify_Admin_Able_To_Edit_Course_Details" })
	public void Step08_Verify_Admin_Able_To_Provide_Content_For_Instructor() throws InterruptedException, AWTException {
		//canvas.achieveAdminPage.add_Activity();
		//canvas.achieveAdminPage.find_TestCourse(newCourseName);
	}

	@Test(dependsOnMethods = { "Step08_Verify_Admin_Able_To_Provide_Content_For_Instructor" })
	public void Step09_Verfiy_Admin_Able_To_Delete_Course() {
		canvas.achieveAdminPage.delete_Course();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}
}