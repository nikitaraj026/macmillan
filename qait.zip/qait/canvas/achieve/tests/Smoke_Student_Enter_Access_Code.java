package com.qait.canvas.achieve.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Student_Enter_Access_Code extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String courseName, accessCode;
	private String pxCoursename;
	private String instructorUserName;
	private String firstStudent, emailFirstStudent;
	private String studentFirstName, studentLastName;
	private String external_Tool;
	private String password, px_password, inst_password;
	private String quizTitle1, quizTitle2, quiz1CorrectAnswer1, quiz2CorrectAnswer1, quiz1Grade, quiz2Grade;
	private String chapterName, chapterIntroduction;
	private String bookIdentifier, answer, grade, firstStudentLogin;

	@BeforeClass
	@Parameters("book")
	public void Start_Test_Session(@Optional("myers11e") String book) {
		canvas = new CanvasTestSessionInitiator();
		_initVars(book);
		px_password = "Password1!";
	}

	private void _initVars(String book) {
		if (book.contains("myers11e")) {
			bookIdentifier = "myers";
			getData(bookIdentifier + ".author");
			courseName = canvas.coursePage.readDataFromYaml("CourseName");

			instructorUserName = canvas.coursePage.readDataFromYaml("InstUserName");
			inst_password = canvas.coursePage.readDataFromYaml("inst_password");
			firstStudent = canvas.coursePage.readDataFromYaml("FirstStudent");
			firstStudentLogin = canvas.coursePage.readDataFromYaml("FirstStudentLogin");
			emailFirstStudent = canvas.coursePage.readDataFromYaml("EmailFirstStudent");
			password = canvas.coursePage.readDataFromYaml("Password");
			external_Tool = getData("external_tool");
			studentFirstName = "FSName";
			accessCode = getData("accessCodeAch");
			pxCoursename = getData("achieve_users.instructor.pxCourseName");
			studentLastName = "LSName";
			px_password = "Password1!";
			quizTitle1 = "Apostrophes";
		}
	}

	@BeforeSuite
	public void deleteExecutionFile() {
		beforeSuiteMethod();
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Student() {
		canvas.loginPage.loginToTheApplication(firstStudentLogin, password);
//		canvas.leftMenu.goToUserCourse(courseName);
	}

	@Test(dependsOnMethods = "Step02_Log_In_As_Student")
	public void Step03_Student_Accept_Agree_Term_Of_Application() {
		canvas.dashboardPage.clickOnIAgreeTerm();
		canvas.dashboardPage.clickOnCancelButton();
	}

	@Test(dependsOnMethods = "Step03_Student_Accept_Agree_Term_Of_Application")
	public void Step04_Student_Go_To_Dashboard_Page() {
		canvas.loginPage.loginToTheApplication(firstStudentLogin, password);
		canvas.dashboardPage.acceptTermsOfUse();
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step04_Student_Go_To_Dashboard_Page")
	public void Step05_Student_Go_To_Course_Page() {
		canvas.dashboardPage.acceptInvite();
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step05_Student_Go_To_Course_Page")
	public void Step06_Student_Attempt_Assignment() {
		canvas.toolsPage.runHandleSecurityExe();
		// canvas.coursePage.clickAssignmentsOnCoursePage();
		// canvas.coursePage.clickOnAssignmentLink(quizTitle1);

		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.clickAchieve();
		canvas.provisionPage.fillNewInstructorDetailsForAchieve("Stud", "canvas", emailFirstStudent);
		canvas.provisionPage.submit_SSOPageAndContinue();
	}

	@Test(dependsOnMethods = "Step06_Student_Attempt_Assignment")
	public void Step07_Verify_That_Student_AttemptQuiz() {

		canvas.achieveStudentPage.verifyEnrollmentOptionsModalWindow();
		canvas.achieveStudentPage.useAccessCodedAsEnrollmentOption(accessCode, pxCoursename);

//		grade = canvas.achieveStudentPage.attempt_AchieveQuiz();
//		canvas.onboardingPage.newMWStudent(emailFirstStudent);
//		canvas.onboardingPage.studentAttemptFlowUptoQuestion("Yes",answer);
	}

	@Test(dependsOnMethods = "Step07_Verify_That_Student_AttemptQuiz")
	public void Step12_Student_Logout_Canvas() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = "Step12_Student_Logout_Canvas")
	public void Step13_Log_In_As_Instructor() {
		canvas.loginPage.loginToTheApplication(instructorUserName, inst_password);
		canvas.dashboardPage.verifyDashboardPage();
	}

	@Test(dependsOnMethods = "Step13_Log_In_As_Instructor")
	public void Step14_Go_To_Course_Homepage() {
		canvas.leftMenu.goToUserCourse(courseName);
		canvas.coursePage.verifyUserIsOnCoursePage(courseName);
	}

	@Test(dependsOnMethods = "Step14_Go_To_Course_Homepage")
	public void Step15_Go_To_Macmillan_Tools_Page_And_Refresh_Grades() {
		canvas.coursePage.enterIntoToolsSection(external_Tool);
		canvas.toolsPage.clickOnMacmillanGradeRefreshLink();
		canvas.toolsPage.verifyGradeRefreshPage();
		canvas.toolsPage.clickSelectedButtonOnMacmillanHigherEducationGradeSyncRefresh();
		canvas.toolsPage.selectContentOnMacmillanHigherEducationGradeSyncRefresh(quizTitle1);
		canvas.toolsPage.clickSubmitOnMacmillanHigherEducationGradeSyncRefresh();
	}

	@Test(dependsOnMethods = "Step15_Go_To_Macmillan_Tools_Page_And_Refresh_Grades")
	public void Step16_Verify_Grades_In_Gradebook() {
		canvas.coursePage.clickGradesOnCoursePage();
		canvas.coursePage.verifyGradesInCanvasGradebook(firstStudent, quizTitle1, "30");
	}

	@Test(dependsOnMethods = "Step16_Verify_Grades_In_Gradebook")
	public void Step17_Instructor_Logout() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		canvas.closebrowserSession();
	}

}