package com.qait.canvas.achieve.tests;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.qait.automation.CanvasTestSessionInitiator;
import com.qait.automation.utils.Parent_Test;
import com.qait.canvas.keywords.DashBoardPageAction;

import static com.qait.automation.utils.YamlReader.getData;

public class Smoke_Admin_Flow extends Parent_Test {

	CanvasTestSessionInitiator canvas;
	Map<String, Object> data = new HashMap<String, Object>();

	private String subAccount;
	private String courseName;
	private String instructor, emailInstructor, instructorName;
	private String firstStudent, firstStudentLogin, emailFirstStudent;
	private String password, inst_password, px_password;

	private void _initVars() {
		String dateWithTime = canvas.getCurrentDateWithTime();
	
		courseName = getData("courseName_achieve");
		subAccount = getData("subAccount");
		
		instructorName = getData("achieve_users.instructor.name1");
		instructor = getData("achieve_users.instructor.user_name1");
		emailInstructor = getData("achieve_users.instructor.user_email1");
		
		firstStudent = "Stud First";
		firstStudentLogin = "StudFirst"+dateWithTime;
		emailFirstStudent = firstStudentLogin + "@yopmail.com";
		inst_password = getData("users.instructor.password");
		password = getData("users.student.password");
		DashBoardPageAction.courseName = courseName;
		px_password = "Password1!";

		data.put("InstUserName", instructor);
		data.put("EmailInst", emailInstructor);
		
		data.put("FirstStudent", firstStudent);
		data.put("FirstStudentLogin", firstStudentLogin);
		data.put("EmailFirstStudent", emailFirstStudent);


		data.put("Password", password);
		data.put("inst_password", inst_password);
		data.put("PX_Password", px_password);
		data.put("CourseName", courseName);
	}

	@BeforeClass
	public void Start_Test_Session() {
		canvas = new CanvasTestSessionInitiator();
		_initVars();
		canvas.coursePage.writeDataToYaml(data);
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		canvas.stepStartMessage(method.getName());
	}

	@AfterMethod
	public void onFailure(ITestResult result) {
		afterMethod(canvas, result, this.getClass().getName());
	}

	@Test
	public void Step01_Launch_Application() {
		canvas.launchApplication();
		canvas.loginPage.verifyLoginPage();
	}

	@Test(dependsOnMethods = { "Step01_Launch_Application" })
	public void Step02_Log_In_As_Admin() {
		canvas.loginPage.loginToTheApplication(getData("users.admin.user_name"), getData("users.admin.password"));
		//canvas.dashboardPage.verifyDashboardPage();

	}

	@Test(dependsOnMethods = { "Step02_Log_In_As_Admin" })
	public void Step03_Go_To_Macmillan2_Courses() {
		canvas.leftMenu.clickOnAdminLeftMenu();
		canvas.leftMenu.clickMacmillan2();
	}

	@Test(dependsOnMethods = { "Step03_Go_To_Macmillan2_Courses" })
	public void Step04_Verify_Add_New_Course_Modal_Window() {
		canvas.macmillan2Page.clickOnAddNewCourse();
		canvas.macmillan2Page.verifyAddNewCourseModalWindow();
	}

	@Test(dependsOnMethods = { "Step04_Verify_Add_New_Course_Modal_Window" })
	public void Step05_Create_Course() {
		// canvas.macmillan2Page.AddNewCourse(courseName, " "+subAccount);
		canvas.macmillan2Page.clickOnCancelButtonOverAddCourse();// For
																			// add
																			// course
																			// cancel=0,add
																			// course=1,For
																			// add
																			// user
																			// cancel=2,add
																			// user=3,
	}

	@Test(dependsOnMethods = { "Step05_Create_Course" })
	public void Step06_Verify_Add_New_User_Modal_Window() {
		canvas.macmillan2Page.clickLeftTab("People");
		canvas.macmillan2Page.clickOnAddNewUser();
		canvas.macmillan2Page.verifyAddNewUserModalWindow();
	}

	@Test(dependsOnMethods = { "Step06_Verify_Add_New_User_Modal_Window" })
	public void Step07_Admin_Create_New_User_Instructor() {
		 canvas.macmillan2Page.createUser(instructor, emailInstructor);
	}

	@Test(dependsOnMethods = { "Step07_Admin_Create_New_User_Instructor" })
	public void Step08_Admin_Create_User_Student() {
		canvas.macmillan2Page.createUser(firstStudent, emailFirstStudent);
	}

	@Test(dependsOnMethods = { "Step08_Admin_Create_User_Student" })
	public void Step09_Admin_Redirects_To_Newly_Created_Course() {
		canvas.macmillan2Page.clickLeftTab("Courses");
		canvas.macmillan2Page.enterIntoCourse(courseName);
	}

	@Test(dependsOnMethods = { "Step09_Admin_Redirects_To_Newly_Created_Course" })
	public void Step10_Publish_Course() {
		//canvas.coursePage.publishCourse();
	}

	@Test(dependsOnMethods = { "Step10_Publish_Course" })
	public void Step11_Admin_Redirects_To_People_Page() {
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.verifyUserIsOnPeoplePage();
	}

	@Test(dependsOnMethods = { "Step11_Admin_Redirects_To_People_Page" })
	public void Step12_Verify_Add_People_Modal_Window() {
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.verifyAddPeopleModalWindow();
	}

	@Test(dependsOnMethods = { "Step12_Verify_Add_People_Modal_Window" })
	public void Step13_Verify_User_Information() {
		canvas.coursePage.enterUserDetails("Teacher", emailInstructor);
		canvas.coursePage.verifyUserDetails(emailInstructor);
	}

	@Test(dependsOnMethods = { "Step13_Verify_User_Information" })
	public void Step14_Verify_Instructor_Is_Added_To_Course() {
		canvas.coursePage.clickOnAddUserButton();
		canvas.coursePage.verifyUserIsAddedToCourse(instructorName);
	}

	@Test(dependsOnMethods = { "Step14_Verify_Instructor_Is_Added_To_Course" })
	public void Step15_Admin_Enroll_Three_Student_To_Course() {
		canvas.coursePage.clickOnPeopleButton();
		canvas.coursePage.enterUserDetails("Student", emailFirstStudent);
		canvas.coursePage.clickOnAddUserButton();
//		canvas.coursePage.verifyStudentEnrollment();
	}

	@Test(dependsOnMethods = { "Step15_Admin_Enroll_Three_Student_To_Course" })
	public void Step16_Admin_Redirects_To_UserName_Details_Page() {
		// canvas.coursePage.clickOnUserNameLink(instructor);
		// canvas.coursePage.verifyUserDetailPage(instructor);
	}

	@Test(dependsOnMethods = { "Step16_Admin_Redirects_To_UserName_Details_Page" })
	public void Step17_Verify_Membership_LoginInformation_Section() {
		// canvas.coursePage.clickOnMoreUserDetails();
		// canvas.coursePage.verifyMembershipLoginInformationSection();
	}

	@Test(dependsOnMethods = { "Step17_Verify_Membership_LoginInformation_Section" })
	public void Step18_Verify_Add_Login_Modal_Window() {
		// canvas.coursePage.clickOnAddLoginLink();
		// canvas.coursePage.verifyAddLoginModalWindow();
	}

	@Test(dependsOnMethods = { "Step18_Verify_Add_Login_Modal_Window" })
	public void Step19_Admin_Add_Login_For_Instructor() {
		// canvas.coursePage.enterLoginDetails(instructor, password);
		// canvas.coursePage.clickOnAddLoginButton();
		// canvas.coursePage.verifyUserLogin(instructor);
	}

	@Test(dependsOnMethods = { "Step19_Admin_Add_Login_For_Instructor" })
	public void Step20_Admin_Add_Login_For_Three_Student() {
		canvas.coursePage.clickOnPeopleNavigationLink();
		canvas.coursePage.clickOnUserNameLink(firstStudent);
		canvas.coursePage.verifyUserDetailPage(firstStudent);
		canvas.coursePage.clickOnMoreUserDetails();
		canvas.coursePage.verifyMembershipLoginInformationSection();
		canvas.coursePage.clickOnAddLoginLink();
		canvas.coursePage.verifyAddLoginModalWindow();
		canvas.coursePage.enterLoginDetails(firstStudentLogin, password);
		canvas.coursePage.clickOnAddLoginButton();
		canvas.coursePage.verifyUserLogin(firstStudentLogin);
	}

	@Test(dependsOnMethods = { "Step20_Admin_Add_Login_For_Three_Student" })
	public void Step21_Admin_Log_Out_Canvas_Application() {
		canvas.leftMenu.logout();
		canvas.loginPage.verifyLoginPage();
	}

	@AfterClass(alwaysRun = true)
	public void Stop_Test_Session() {
		 canvas.closebrowserSession();
	}
}